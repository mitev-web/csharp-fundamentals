﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task17
{
    class Program
    {
        static void Main(string[] args)
        {
            //* Write a program that reads three integer numbers N, K and S and 
            //an array of N elements from the console. Find in the array a subset 
            //of K elements that have sum S or indicate about its absence.

        }
    }
}
