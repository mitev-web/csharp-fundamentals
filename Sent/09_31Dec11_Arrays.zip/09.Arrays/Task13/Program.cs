﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task13
{
    class Program
    {
        static void Main(string[] args)
        {
            //* Write a program that sorts an array of integers using the merge sort
            //    algorithm (find it in Wikipedia).

        }
    }
}
