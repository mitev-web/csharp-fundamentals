﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task19
{
    class Program
    {
        static void Main(string[] args)
        {
    //        * Write a program that reads a number N and generates and prints 
    //            all the permutations of the numbers [1 … N]. Example:
    //n = 3  {1, 2, 3}, {1, 3, 2}, {2, 1, 3}, {2, 3, 1}, {3, 1, 2}, {3, 2, 1}

        }
    }
}
