﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task12
{
    class Program
    {
        static void Main(string[] args)
        {
           // Write a program that creates an array containing all letters from the alphabet
           //(A-Z). Read a word from the console and print the index of each of its letters 
           // in the array.

        }
    }
}
