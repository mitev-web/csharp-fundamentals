﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task16
{
    class Program
    {
        static void Main(string[] args)
        {
            //* We are given an array of integers and a number S. 
            //Write a program to find if there exists a subset of the elements of the 
            //array that has a sum S. Example:
            //    arr={2, 1, 2, 4, 3, 5, 2, 6}, S=14  yes (1+2+5+6)

        }
    }
}
