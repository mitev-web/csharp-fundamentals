﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task14
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that sorts an array of strings using the quick sort algorithm 
            //(find it in Wikipedia).

        }
    }
}
