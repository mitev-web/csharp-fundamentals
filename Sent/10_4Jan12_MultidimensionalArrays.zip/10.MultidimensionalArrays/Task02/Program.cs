﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that reads a rectangular matrix of
            //    size N x M and finds in it the square 3 x 3 
            //that has maximal sum of its elements.

        }
    }
}
