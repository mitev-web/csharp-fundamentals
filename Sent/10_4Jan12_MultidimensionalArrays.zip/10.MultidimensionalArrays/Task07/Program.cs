﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task07
{
    class Program
    {
        static void Main(string[] args)
        {
            //* Write a program that finds the largest area of equal neighbor elements
            //in a rectangular matrix and prints its size. Example:
            //Hint: you can use the algorithm "Depth-first search" or "Breadth-first search"
            //    (find them in Wikipedia).


        }
    }
}
