﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task05
{
    class Program
    {
        static void Main(string[] args)
        {
           //You are given an array of strings. Write a method that sorts 
           //the array by the length of its elements
           //(the number of characters composing them).

        }
    }
}
