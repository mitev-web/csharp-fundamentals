﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03
{
    class Program
    {
        static void Main(string[] args)
        {
            //We are given a matrix of strings of size N x M. 
            //Sequences in the matrix we define as sets of several
            //    neighbor elements located on the same line, column 
            //or diagonal. Write a program that finds the longest 
            //    sequence of equal strings in the matrix. Example:

        }
    }
}
