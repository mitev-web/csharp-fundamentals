﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task06
{
    class Program
    {
        static void Main(string[] args)
        {
            //* Write a class Matrix, to holds a matrix of integers. 
            //Overload the operators for adding, subtracting and multiplying of matrices,
            //    indexer for accessing the matrix content and ToString().

        }
    }
}
