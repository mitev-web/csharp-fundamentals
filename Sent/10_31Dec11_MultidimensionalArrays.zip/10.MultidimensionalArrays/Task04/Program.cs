﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program, that reads from the console an array
            //    of N integers and an integer K, sorts the array and 
            //using the method Array.BinSearch() finds the largest number 
            //in the array which is ≤ K. 

        }
    }
}
