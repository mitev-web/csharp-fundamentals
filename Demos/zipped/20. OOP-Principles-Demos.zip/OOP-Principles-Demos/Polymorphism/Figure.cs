﻿using System;

abstract class Figure
{
    public abstract double CalcSurface();
}
