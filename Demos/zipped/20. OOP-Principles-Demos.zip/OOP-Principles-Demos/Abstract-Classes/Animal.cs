﻿using System;

public abstract class Animal
{
    public abstract string GetName();
    abstract public int Speed { get; }
}
