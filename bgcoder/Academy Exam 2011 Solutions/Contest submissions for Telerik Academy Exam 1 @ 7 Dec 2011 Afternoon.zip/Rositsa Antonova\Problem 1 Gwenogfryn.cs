using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad1Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            int N;
            N = int.Parse(Console.ReadLine());
            int k, l;
            k = 0;
            l = 0;
            for (int i = 1; i <= N; i++)
            {
                if ((N + 1) / 2 >= i)
                {
                    k = i - 1;
                }
                else
                {
                    k = k -1;
                }

                for (int j = 1; j <= k; j++)
                {
                    Console.Write(".");
                }
                for (int j = 1; j <= (N-2*k); j++)
                {
                    Console.Write("*");
                }
                for (int j = 1; j <= k; j++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
        }
    }
}
