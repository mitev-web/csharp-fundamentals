using System;
using System.Numerics;

namespace _3.SpecialAlgorithm
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string N = input.Replace(".", "");
            string removeMinus = N.Replace("-","");  
            BigInteger number = BigInteger.Parse(removeMinus);      

            bool found = false;
            BigInteger sum = 0;
            int counter = 0;

            while (found == false)
            {
                while (number > 0)
                {
                    counter++;
                    sum += number % 10;
                    number /= 10;
                }

                if (sum > 9)
                {

                    number = sum;
                    sum = 0;
                }
                else
                {
                    found = true;
                }
            }
            Console.WriteLine(sum);
        }
    }
}