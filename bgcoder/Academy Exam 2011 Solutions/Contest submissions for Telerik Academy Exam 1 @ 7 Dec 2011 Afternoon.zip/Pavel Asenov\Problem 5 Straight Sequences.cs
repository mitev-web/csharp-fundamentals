using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_5
{
    class Program
    {
            
      
         static void Main(string[] args)
        {
            byte[,] matrix = new byte[8, 8];
            int input;

            for (int i = 0; i < 8; i++)
            {
                input = Int32.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    if ((input & (1 << j)) != 0)
                        matrix[i, j] = 1;
                }
            }
            int longestSequense = 0;
            int countOfLongestSequense = 0;
              int currentlongestSequense = 0;

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (matrix[i, j] == 1)
                    {
                      currentlongestSequense=1;
                      int tempJ = j;  
                    while (tempJ<7 && matrix[i,tempJ+1]==1)
	                        {
	                       currentlongestSequense++;
                            tempJ++;

	                        }
                    
                    
                      if (longestSequense == currentlongestSequense)
                      {
                         
                          countOfLongestSequense++;

                      }
                      if (longestSequense < currentlongestSequense)
                      {
                          longestSequense = currentlongestSequense;
                          countOfLongestSequense = 1;

                      }

                      int tempI = i;
                      currentlongestSequense = 1;
                      while (tempI < 7 && matrix[tempI+1, j] == 1)
                      {
                          currentlongestSequense++;
                          tempI++;

                      }

                     
                      if (longestSequense == currentlongestSequense)
                      {

                          countOfLongestSequense++;

                      }
                      if (longestSequense < currentlongestSequense)
                      {
                          longestSequense = currentlongestSequense;
                          countOfLongestSequense = 1;

                      }



                    }


                        

                }
  
            }

         
                Console.WriteLine("{0}", longestSequense);
                Console.WriteLine("{0}", countOfLongestSequense);

            }
        }
    }

