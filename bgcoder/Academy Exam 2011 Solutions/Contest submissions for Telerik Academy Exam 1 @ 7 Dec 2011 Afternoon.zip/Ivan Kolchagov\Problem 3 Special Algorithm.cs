using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace T03.SpecialAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            //decimal.Parse(Console.ReadLine());
            string input = Console.ReadLine();
            uint n = 0;
            foreach (var ch in input)
            {
                if ((ch >= '0') && (ch <= '9'))
                {
                    n += ch - (uint)'0';
                }
            }
            do
            {
                uint sum = 0;
                while (n > 0)
                {
                    sum += (uint)n % 10;
                    n /= 10;
                }
                n = sum;
            } while (n > 9);
            Console.WriteLine((int)n);
        }
    }
}
