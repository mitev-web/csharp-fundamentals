using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task01.Gwenogfryn1
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int k = n;
            int m = 0;
            for (int i = 0; i <= (n /2 )-1; i++)
            {
                Console.WriteLine(("".PadLeft(m,'.')) + ("".PadLeft(k, '*')) + ("".PadLeft(m, '.')));
                m++;
                k -= 2;

            }
            for (int i = 0; i <= (n / 2); i++)
            {
                Console.WriteLine(("".PadLeft(m, '.')) + ("".PadLeft(k, '*')) + ("".PadLeft(m, '.')));
                m--;
                k += 2;

            }


        }
    }
}
