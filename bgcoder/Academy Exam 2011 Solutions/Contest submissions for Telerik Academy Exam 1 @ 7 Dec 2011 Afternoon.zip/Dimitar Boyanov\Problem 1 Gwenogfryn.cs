using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());

            for (byte row = 1; row <= n; row++)
            {
                for (byte col = 1; col <= n; col++)
                {
                    if (row > col && row + col <= n )
                    {
                        Console.Write(".");
                    }
                    else if (row < col && row + col > n + 1)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }

                }
                Console.WriteLine();
            }
        }
    }
}
