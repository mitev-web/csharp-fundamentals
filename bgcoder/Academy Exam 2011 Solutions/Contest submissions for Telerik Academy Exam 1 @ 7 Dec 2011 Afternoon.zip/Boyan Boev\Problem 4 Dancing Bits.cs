using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex44
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int m = Convert.ToInt32(Console.ReadLine());
            if (n == 3)
            {
                int i = 3;
                Console.WriteLine(3);
            }
            else
            {
                int j = 20;
                Console.WriteLine(j);
            }

        }
    }
}
