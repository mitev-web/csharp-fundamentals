using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            for (int height = 0; height < (number)/2+1; height++)
            {
                char character1 = '*';
                char character2 = '.';
                if (height == 0)
                {
                    for (int width = 0; width <number; width++)
                    {
                        Console.Write(character1);
                    }
                }
                if (height !=0)
                {
                    for (int width = 0; width < number; width++)
                    {
                        if (width>=height && width < number-height)
                        {
                            Console.Write(character1);
                        }
                        else
                        {
                            Console.Write(character2);
                        }
                    }
                }
                Console.WriteLine();
            }
            for (int height = (number/2); height > 0; height--)
            {
                char character1 = '*';
                char character2 = '.';
                if (height == 1)
                {
                    for (int width = 0; width < number; width++)
                    {
                        Console.Write(character1);
                    }
                }
                if (height != 1)
                {
                    for (int width = 0; width < number; width++)
                    {
                        if (width >= height-1 && width <= number - height)
                        {
                            Console.Write(character1);
                        }
                        else
                        {
                            Console.Write(character2);
                        }
                    }
                }
                Console.WriteLine();
            }
        }
    }
}