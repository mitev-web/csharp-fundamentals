using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam_Task1_Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());  

            char[] matrix = new char[n];

            if (n % 2 == 1 && n > 3 && n < 101)
            {
                for (int i = 0; i < n; i++)
                {
                    matrix[i] = '*';
                }
                Console.WriteLine(matrix);
                for (int i = n-1; i < n; i++)
                {
                    matrix[i] = '.';
                }
                Console.WriteLine(matrix);
                for (int i = 1; i < n - 1; i++)
                {
                    matrix[i] = '*';
                }
                Console.WriteLine(matrix);
                for (int i = 0; i < n; i++)
                {
                    matrix[i] = '.';
                }
                Console.WriteLine(matrix);
                for (int i = 2; i < n-2; i++)
                {
                    matrix[i] = '*';
                }
                Console.WriteLine(matrix);

                for (int i = 0; i > n; i++)
                {
                    matrix[i] = '.';
                }
                Console.WriteLine(matrix);
                for (int i = -1; i < n + 1; i++)
                {
                    matrix[i] = '*';
                }
                Console.WriteLine(matrix);
 
            }

        }
    }
}
