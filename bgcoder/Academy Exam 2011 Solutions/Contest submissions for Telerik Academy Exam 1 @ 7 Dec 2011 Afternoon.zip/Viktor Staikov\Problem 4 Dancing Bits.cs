using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            long e;
            int currBit = 0;
            int seqLenght = 0;
            int counter = 0;
            int numBits;

            e = long.Parse(Console.ReadLine());
            
            for (numBits = 0; (long)(1 << numBits) <= e && (long)(1<<numBits) >0; numBits++)
                ;
            numBits--;
            currBit = (int)((e>>numBits)%2);
            seqLenght = 1;

            for (int j = numBits-1; j>=0 ; j--)
            {
                if (currBit == ((e>>j)%2))
                    seqLenght++;
                else
                {
                    if (seqLenght == k)
                        counter++;
                    currBit ^= 1;
                    seqLenght = 1;
                }
                //Console.Write(currBit);
            }

            for (int i = 1; i < n; i++)
            {
                e = long.Parse(Console.ReadLine());

                for (numBits = 0; (long)(1 << numBits) <= e && (long)(1 << numBits) > 0; numBits++)
                    ;
                numBits -= 1;
                
                for (int j = numBits; j>=0 ; j--)
                {
                    if (currBit == ((e>>j)%2))
                        seqLenght++;
                    else
                    {
                        if (seqLenght == k)
                            counter++;
                        currBit ^= 1;
                        seqLenght = 1;
                    }
                    //Console.Write(currBit);
                }
            }
            if (seqLenght == k)
                counter++;
            Console.WriteLine(counter);
        }
    }
}
