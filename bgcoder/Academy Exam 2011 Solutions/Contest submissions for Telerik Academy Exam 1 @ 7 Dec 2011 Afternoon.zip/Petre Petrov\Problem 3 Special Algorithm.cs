static void Main(string[] args)

        {

 

            int total = 0;

            Console.Write("enter Number :\n");

            string s  = Console.ReadLine();

            char[] x = s.ToCharArray();

 

            foreach (char c in x)

            {

 

                total += int.Parse(c.ToString()); 

            }

 

            Console.WriteLine("Total of Digits :=" + total);

            Console.ReadKey();   

        }

