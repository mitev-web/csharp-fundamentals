using System;
class Gwenogfryn
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int a = 1;
        int b = n;
        for (int row = 1; row <= n / 2; row++)
        {
            for (int col = 1; col <= n; col++)
            {
                if ((col < a) || (col > b))
                {
                    Console.Write(".");
                }
                else
                {
                    Console.Write("*");
                }
            }
            Console.WriteLine();
            a++;
            b--;
        }
        a = (n / 2) + 1;
        b = (n / 2) + 1;
        for (int row = (n / 2) + 1; row <= n; row++)
        {
            for (int col = 1; col <= n; col++)
            {
                if ((col >= a) && (col <= b) )
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
            a--;
            b++;
        }
        


    }
}