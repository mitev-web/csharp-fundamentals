using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace test_5
{
    class Program
    {
        // create a coppy of the matrix that is easy to check for columns
        static byte[,] convertToMatrix(string[] stringMatrix)
        {
            byte[,] matrix = new byte[8, 8];
  
            for(int i=0; i<8 ; i++)
            {
                for(int j=0;j<8;j++)
                {
                    string currentString=stringMatrix[i].ToString();
  
                    if (currentString[j] == '1')
                    {
                        matrix[i, j] = 1;
                    }
                    else
                    {
                        matrix[i, j] = 0;
                    }
                }
            }
  
            return matrix;
          
        }
  
        static int findLargestLenght(byte[,] matrix)
        {
  
            int largestRowLenght=0;
            int currentRowLength = 0;
  
            //horizontal rows
            for (int i = 0; i < 8; i++)
            {
                for(int j=0;j<8;j++)
                {
                    if (j == 7 && matrix[i, j] == 1) { currentRowLength++; }// special case
                    if (currentRowLength > largestRowLenght)
                    {
                        largestRowLenght = currentRowLength;
                    }
                    if (matrix[i, j] == 1)
                    {
                        currentRowLength++;
                    }
                    else
                    {
                        currentRowLength = 0;
                    }
                }
                currentRowLength = 0;// reset current row lenght at the beginning of every new line
            }// end  for(int i=0; i<8 ; i++)
              
            // vertical rows
  
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (j == 7 && matrix[j, i] == 1) { currentRowLength++; }// special case
                    if (currentRowLength > largestRowLenght)
                    {
                        largestRowLenght = currentRowLength;
                    }
                    if (matrix[j, i] == 1)
                    {
                        currentRowLength++;
                    }
                    else
                    {
                        currentRowLength = 0;
                    }
                }
                currentRowLength = 0;// reset current row lenght at the beginning of every new column
  
            }// end  for(int i=0; i<8 ; i++)
  
            return largestRowLenght;
        }// end  static int findLargestLenght(byte[,] matrix)
  
        static int findLargestRowCount(byte[,] matrix,int largestRowLenght)
        {
            int largestRowCount =  0;
            int currentRowLength = 0;
  
            //horizontal rows
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (j == 7 && matrix[i, j] == 1) { currentRowLength++; }// special case
                    if (currentRowLength == largestRowLenght)
                    {
                        largestRowCount++;
                        // delete the row that we just found so that we don't count it again
                        for (int deleteCount = largestRowLenght; deleteCount >= 0 && j - deleteCount >= 0; deleteCount--)
                        {
                            matrix[i, j - deleteCount] = 0;
                        }
                    }
  
                    if (matrix[i, j] == 1)
                    {
                        currentRowLength++;
                    }
                    else
                    {
                        currentRowLength = 0;
                    }
                }
                currentRowLength = 0;// reset current row lenght at the beginning of every new line
            }// end  for(int i=0; i<8 ; i++)
  
            //vertical rows
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (j == 7 && matrix[j, i] == 1) { currentRowLength++; }// special case
                    if (currentRowLength == largestRowLenght)
                    {
                        largestRowCount++;
                        // delete the row that we just found so that we don't count it again
                        for (int deleteCount = largestRowLenght; deleteCount >= 0 && j - deleteCount >= 0; deleteCount--)
                        {
                             matrix[j-deleteCount, i ] = 0;
                        }
                    }
  
                    if (matrix[j, i] == 1)
                    {
                        currentRowLength++;
                    }
                    else
                    {
                        currentRowLength = 0;
                    }
                }
                currentRowLength = 0;// reset current row lenght at the beginning of every new column
            }// end  for(int i=0; i<8 ; i++)
  
  
            return largestRowCount;
        }// end  static int findLargestRowCount(byte[,] matrix,int largestRowLenght)
  
  
        static void Main(string[] args)
        {
            string[] strigMatrix = new string[8];
  
            // input
            for (byte i = 0; i < 8; i++)
            {
                byte input = Convert.ToByte(Console.ReadLine());
                strigMatrix[i] = Convert.ToString(input, 2).PadLeft(8,'0');
            }// end input
  
            // create a coppy of the matrix that is easy to check for columns
            byte[,] matrix = convertToMatrix(strigMatrix);
  
            Console.WriteLine(findLargestLenght(matrix));
            Console.WriteLine(findLargestRowCount(matrix,findLargestLenght(matrix)));
  
         
  
        }
    }
}