using System;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = Int32.Parse(Console.ReadLine());
            int n = Int32.Parse(Console.ReadLine());
            int[] arr = new int[n];

            for (int i = 0; i < n; i++)
            {
                arr[i] = Int32.Parse(Console.ReadLine());
            }

            string result = "";
            for (int i = 0; i < n; i++)
            {
                result += Convert.ToString(arr[i], 2);
            }
            char[] charArr = result.ToCharArray();
        
            int counter = 0;
            int dancingBits = 0;
            for (int i = 0; i < charArr.Length - 1; i++)
            {
                if (charArr[i] == '1')
                {
                    counter++;
                  
                    //else
                    //{
                    //    counter++;
                    //}
                    if (counter == k && charArr[i + 1] == '0')
                    {
                        dancingBits++;
                    }
                }
                else
                {
                    counter = 0;
                }
                
            }
            for (int i = 0; i < charArr.Length - 1; i++)
            {
                if (charArr[i] == '0')
                {
                    counter++;
                    if (counter == k && charArr[i + 1] == '1')
                    {
                        dancingBits++;
                    }
                }
                else
                {
                    counter = 0;
                }
            }
            if (k == 1)
            {
                dancingBits++;
            }
            Console.WriteLine(dancingBits);

           // int number = Convert.ToInt32(result, 2);
            //Console.WriteLine(number);

        //    int mask = 1;
        //    int counter = 0;
        //    int counter2 = 0;
        //    int res = 0;
        //    int dancingBits = 0;
        //    for (int i = 0; i < charArr.Length; i++)
        //    {
        //        res = number & mask;
        //        if (res != 0)
        //        {
        //            counter++;
        //            if((counter == k) && (res = (number & (mask << 1))) == 0)
        //            {
        //                dancingBits++;
        //                counter = 0;
        //            }
        //        }
                
        //        else if(res == 0)
        //        {
        //            if ((counter2 == k) && (res = (number & (mask << 1))) != 0)
        //            {
        //                dancingBits++;
        //                counter2 = 0;
        //            }
        //        }
                
        //        mask = mask << 1;
        //    }
        //    Console.WriteLine(dancingBits);
        }
    }
}
