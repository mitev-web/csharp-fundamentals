using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad2War
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1;
            px1 = int.Parse(Console.ReadLine());
            int py1;
            py1 = int.Parse(Console.ReadLine());
            int px2;
            px2 = int.Parse(Console.ReadLine());
            int py2;
            py2 = int.Parse(Console.ReadLine());
            int fx;
            fx = int.Parse(Console.ReadLine());
            int fy;
            fy = int.Parse(Console.ReadLine());
            int d;
            d = int.Parse(Console.ReadLine());
            int x, y;
            x = fx + d;
            y = fy;
            int x1, x2,y1, y2;
            if (px1 < px2)
            {
                x1 = px1;
                x2 = px2;
            }
            else
            {
                x1 = px2;
                x2 = px1;
            }
            if (py1 < py2)
            {
                y1 = py1;
                y2 = py2;
            }
            else
            {
                y1 = py2;
                y2 = py1;
            }
            int result=0;;
            
            if (x>=x1 && x<=x2 && y>=y1 && y<=y2) 
            {
                result=result+100;
            }
            if (x>=x1 && x<=x2 && y-1>=y1 && y-1<=y2) 
            {
                result=result+50;
            }
            if (x >= x1 && x <= x2 && y + 1 >= y1 && y + 1 <= y2)
            {
                result = result + 50;
            }
            if (x+1 >= x1 && x+1 <= x2 && y >= y1 && y <= y2)
            {
                result = result + 75;
            }
            Console.WriteLine("{0}%",result);
        }
    }
}
