using System;
 
    class Program
    {
        public static void Main(string[] args)
        {
            //input
            //n = 8;
            const int n = 8;
 
 
            //int[] numbers =
            //{
            //    8, 72, 8, 8, 16, 28, 240, 0
            //    //246, 247, 248, 249, 250, 251, 252, 253
            //};
            int[] numbers = new int[n];
            for (int i = 0; i < n; i++)
            {
                numbers[i] = EnterIntNumber();
            }
 
            char[,] matrixNumbers = new char[n, n];
            string numberAsString = "";
            for (int i = 0; i < n; i++)
            {
                numberAsString = Convert.ToString(numbers[i], 2).PadLeft(8, '0');
                //Console.WriteLine(numberAsString);
                for (int j = 0; j < n; j++)
                {
                    matrixNumbers[i, j] = numberAsString[j];
                }
            }
 
            //for (int i = 0; i < n; i++)
            //{
            //    for (int j = 0; j < n; j++)
            //    {
            //        Console.Write(matrixNumbers[i, j]);
            //    }
            //    Console.WriteLine();
            //}
 
            int maxLength = 0;
            int numberOfLines = 0;
 
            //rows
            for (int i = 0; i < n; i++)
            {
                int currentMaxLength = 0;
                for (int j = 0; j < n - 1; j++)
                {
                    if (matrixNumbers[i, j] == '1' && matrixNumbers[i, j + 1] == '1')
                    {
                        currentMaxLength++;
                    }
                }
 
                currentMaxLength++;
                 
                if (currentMaxLength > maxLength)
                {
                    maxLength = currentMaxLength;
                    numberOfLines = 1;
                }
 
                if (currentMaxLength == maxLength)
                {
                    numberOfLines++;
                }
 
                 
            }
            //Console.WriteLine("rows");    
            //Console.WriteLine(maxLength);
            //Console.WriteLine(numberOfLines);
            //columns
            for (int i = 0; i < n - 1; i++)
            {
                int currentMaxLengthColumns = 1;
                for (int j = 0; j < n; j++)
                {
                    if (matrixNumbers[i, j] == '1' && matrixNumbers[i + 1, j] == '1')
                    {
                        currentMaxLengthColumns++;
                    }
                }
 
                currentMaxLengthColumns++;
 
                //Console.WriteLine("cols max length = " + currentMaxLengthColumns );
 
                if (currentMaxLengthColumns > maxLength)
                {
                    maxLength = currentMaxLengthColumns;
                    numberOfLines = 1;
                }
 
                if (currentMaxLengthColumns == maxLength)
                {
                    numberOfLines++;
                }
 
            }
 
            //Console.WriteLine("rows and cols");
            Console.WriteLine(maxLength);
            Console.WriteLine(numberOfLines );
 
        }
 
        public static int EnterIntNumber()
        {
            string inputNumber = Console.ReadLine();
            int number = Convert.ToInt32(inputNumber);
            return number;
 
        }
    }