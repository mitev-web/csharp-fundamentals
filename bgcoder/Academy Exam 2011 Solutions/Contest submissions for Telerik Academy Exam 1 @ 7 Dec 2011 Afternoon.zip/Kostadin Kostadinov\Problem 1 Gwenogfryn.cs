using System;


namespace _01.SandClock
{
    class Program
    {
        static void Main()
        {
            int x;
            int y;
            int n = int.Parse(Console.ReadLine());

            for (x = n/2+1; x >= 1; x--)
            {
                for (y = -n; y <= n - x; y++)
                {
                    Console.Write(".");
                }
                for (y = 1; y <= 2 * x - 1; y++)
                {
                    Console.Write("*");
                }
                Console.Write("\n");
            }

            for (x = 2; x < n/2+2; x++)
            {
                for (y = -n; y <= n - x; y++)
                {
                    Console.Write(".");
                }
                for (y = 1; y <= 2 * x - 1; y++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();

            }    

        }
    }
}
            
