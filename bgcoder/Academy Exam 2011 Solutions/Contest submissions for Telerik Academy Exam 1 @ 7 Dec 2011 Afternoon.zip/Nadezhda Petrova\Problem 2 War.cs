using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_War
{
    class War
    {
        static void Main(string[] args)
        {
            int px1 = Convert.ToInt32(Console.ReadLine());
            int py1 = Convert.ToInt32(Console.ReadLine());
            int px2 = Convert.ToInt32(Console.ReadLine());
            int py2 = Convert.ToInt32(Console.ReadLine());
            int fx = Convert.ToInt32(Console.ReadLine());
            int fy = Convert.ToInt32(Console.ReadLine());
            int d = Convert.ToInt32(Console.ReadLine());

            int startX = new int();
            int endX = new int();
            int startY = new int();
            int endY = new int();

            if (px1 < px2)
            {
                startX = px1;
                endX = px2;
            }
            else
            {
                startX = px2;
                endX = px1;
            }
            if (py1 < py2)
            {
                startY = py1;
                endY = py2;
            }
            else
            {
                startY = py2;
                endY = py1;
            }

            int hitX = fx + d;
            int hitY = fy;

            int damage = 0;

            if (IsInside(startX, endX, startY, endY, hitX, hitY))
            {
                damage = damage + 100;
            }
            if (IsInside(startX, endX, startY, endY, hitX + 1, hitY))
            {
                damage = damage + 75;
            }
            if (IsInside(startX, endX, startY, endY, hitX, hitY + 1))
            {
                damage = damage + 50;
            }
            if (IsInside(startX, endX, startY, endY, hitX, hitY - 1))
            {
                damage = damage + 50;
            }

            Console.WriteLine("{0}%", damage);
        }

        private static bool IsInside(int startX, int endX, int startY, int endY, int x, int y)
        {
            if (x >= startX && x <= endX && y >= startY && y <= endY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}


