using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem03_SpecialAlgorithum
{
    class SpecialAlgorithum
    {
        static void Main(string[] args)
        {
            string inputLine = Console.ReadLine();
            int result = 0;
            foreach (char symbol in inputLine)
            {
                switch (symbol)
                {
                    case '0':
                        result = result + 0;
                        break;
                    case '1':
                        result = result + 1;
                        break;
                    case '2':
                        result = result + 2;
                        break;
                    case '3':
                        result = result + 3;
                        break;
                    case '4':
                        result = result + 4;
                        break;
                    case '5':
                        result = result + 5;
                        break;
                    case '6':
                        result = result + 6;
                        break;
                    case '7':
                        result = result + 7;
                        break;
                    case '8':
                        result = result + 8;
                        break;
                    case '9':
                        result = result + 9;
                        break;
                    default:                        
                        break;
                }
            }
            while (result > 9)
            {
                inputLine ="" + result;
                result = 0;
                foreach (char symbol in inputLine)
                {
                    switch (symbol)
                    {
                        case '0':
                            result = result + 0;
                            break;
                        case '1':
                            result = result + 1;
                            break;
                        case '2':
                            result = result + 2;
                            break;
                        case '3':
                            result = result + 3;
                            break;
                        case '4':
                            result = result + 4;
                            break;
                        case '5':
                            result = result + 5;
                            break;
                        case '6':
                            result = result + 6;
                            break;
                        case '7':
                            result = result + 7;
                            break;
                        case '8':
                            result = result + 8;
                            break;
                        case '9':
                            result = result + 9;
                            break;
                        default:
                            break;
                    }
                }
            }
            Console.WriteLine(result);
        }
    }
}
