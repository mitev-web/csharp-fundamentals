using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad4DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int K;
            K = int.Parse(Console.ReadLine());
            int N;
            N = int.Parse(Console.ReadLine());
            int[] numbers;
            numbers = new int[800];
            int[] concat;
            concat = new int[25600];
            for (int i = 0; i < N; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());

            }
            

            int mask;
            int B = 1;
            int br1 = 0;
            int flag=1;
            int brTo3=0;
            int brCon=0;
            for (int j = 0; j < N; j++)
            {
                flag = 0;

                for (int i = 0; i < 32; i++)
                {

                    mask = 1 << i;
                    if ((numbers[j] & mask) == mask)
                    {
                       // br1 = br1 + 1;
                        flag = i;
                    }
                }
                //Console.WriteLine("flag= {0}", flag);
                //Console.WriteLine("num[j]={0}", numbers[j]);
                for (int i = flag; i >= 0; i--)
                {
                    mask = 1 << i;
                    if ((numbers[j] & mask) == mask)
                    {
                        concat[brCon] = 1;
                    }
                    else
                    {
                        concat[brCon] = 0;
                    }
                   // Console.WriteLine("conc= {0},brcon={1}", concat[brCon],brCon);
                    brCon = brCon + 1;
                }
            }
            //Console.WriteLine("conc= {0}", brCon);
            //for (int i = 0; i < brCon; i++)
            //{
            //    Console.WriteLine(concat[i]);
            //}
            for (int i = 0; i < brCon-K; i++)
            {
                int s = concat[i];
                int brK = 1;
                for (int j = i+1; j <= i+K; j++)
                {
                    if (concat[j]==s)
                    {
                        //Console.WriteLine("j={0}",j);
                        brK = brK + 1;
                    }
                }
                if (brK == K && (concat[i + K] != s))
                {
                    br1 = br1 + 1;
                }
            }
            int flag1 = 0;
            for (int i = 0; i < brCon; i++)
            {
                
                int m =concat[0];
                if (K == 1)
                {
                    if ((i % 2) == 0 && concat[i]==1)
                    {
                        flag1 = flag1+1;
                    }
                    if ((i % 2) != 0 && concat[i] == 0)
                    {
                        flag1 = flag1 + 1;
                    }
                }

            }
            //Console.WriteLine(" flag1={0},brcon = {1} ",flag1,brCon);
            if (flag1 > 0)
            {
                Console.WriteLine(flag1);
            }
            else
            {
                Console.WriteLine(br1);
            }
        }
        static uint ConcatInt(uint x, uint y)
        {
            int length=0;
            double z= y;
            do
            {
                z = Math.Floor(z/10);
                length = length + 1;
                
            }
            while(z>1);
           // Console.WriteLine("y={0} ,l= {1}",y,length);
            for (int i = 1; i <= length; i++)
            {
                x = x * 10;
            }
            return x + y;
            //return (x * Math.Pow(10, length)) + y;
        }
        public static int GetBit(int x, int m)
        {
            int i = 1;
            int mask = i << x;
            if ((m & mask) == mask)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
