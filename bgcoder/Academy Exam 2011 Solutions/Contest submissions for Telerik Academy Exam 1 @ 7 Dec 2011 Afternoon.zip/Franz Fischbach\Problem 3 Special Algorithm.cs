using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test_zad_3
{
    class Program
    {
        static string sumOfNumbsInString(string str)
        {
           string newString = (string)str.Clone();

           int sum = 0;
           for (int i = 0; i < newString.Length; i++)
           {
               if (newString[i] == '.' || newString[i] == '-')
               {
                   continue;
               }
               sum = sum + Convert.ToInt32(newString[i]) - 48;
               // Console.WriteLine(Convert.ToInt32(input[i]));
           }

           if (sum > 9)
           {
               string stringOfSum=Convert.ToString(sum);
               sum = Convert.ToInt32(sumOfNumbsInString(stringOfSum));
           }

           return Convert.ToString(sum);
        
        }

        static void Main(string[] args)
        {
            string input;
            input= Console.ReadLine();
           Console.WriteLine(sumOfNumbsInString(input));

        }
    }
}
