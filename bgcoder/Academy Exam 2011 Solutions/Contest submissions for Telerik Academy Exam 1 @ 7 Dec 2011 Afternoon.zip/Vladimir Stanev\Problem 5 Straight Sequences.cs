using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5_Exam
{

    class Program
    {
        static void Main()
        {
            byte n0=0;
            byte n1=0;
            byte n2=0;
            byte n3=0;
            byte n4=0;
            byte n5=0;
            byte n6=0;
            byte n7=0;

            byte m0=0;
            byte m1=0;
            byte m2=0;
            byte m3=0;
            byte m4=0;
            byte m5=0;
            byte m6=0;
            byte m7=0;

            string line = Console.ReadLine();
            n0 = byte.Parse(line);

            line = Console.ReadLine();
            n1 = byte.Parse(line);

            line = Console.ReadLine();
            n2 = byte.Parse(line);

            line = Console.ReadLine();
            n3 = byte.Parse(line);

            line = Console.ReadLine();
            n4 = byte.Parse(line);

            line = Console.ReadLine();
            n5 = byte.Parse(line);
            
            line = Console.ReadLine();
            n6 = byte.Parse(line);

            line = Console.ReadLine();
            n7 = byte.Parse(line);

            byte one = 1;

            if ((n0>>0&1) == 1)
            { m0 += 1; }
            if ((n1 >> 0 & 1) == 1)
            { m0 += 2; }
            if ((n2 >> 0 & 1) == 1)
            { m0 += 4; }
            if ((n3 >> 0 & 1) == 1)
            { m0 += 8; }
            if ((n4 >> 0 & 1) == 1)
            { m0 += 16; }
            if ((n5 >> 0 & 1) == 1)
            { m0 += 32; }
            if ((n6 >> 0 & 1) == 1)
            { m0 += 64; }
            if ((n7 >> 0 & 1) == 1)
            { m0 += 128; }

            if ((n0 >> 1 & 1) == 1)
            { m1 += 1; }
            if ((n1 >> 1 & 1) == 1)
            { m1 += 2; }
            if ((n2 >> 1 & 1) == 1)
            { m1 += 4; }
            if ((n3 >> 1 & 1) == 1)
            { m1 += 8; }
            if ((n4 >> 1 & 1) == 1)
            { m1 += 16; }
            if ((n5 >> 1 & 1) == 1)
            { m1 += 32; }
            if ((n6 >> 1 & 1) == 1)
            { m1 += 64; }
            if ((n7 >> 1 & 1) == 1)
            { m1 += 128; }

            if ((n0 >> 2 & 1) == 1)
            { m2 += 1; }
            if ((n1 >> 2 & 1) == 1)
            { m2 += 2; }
            if ((n2 >> 2 & 1) == 1)
            { m2 += 4; }
            if ((n3 >> 2 & 1) == 1)
            { m2 += 8; }
            if ((n4 >> 2 & 1) == 1)
            { m2 += 16; }
            if ((n5 >> 2 & 1) == 1)
            { m2 += 32; }
            if ((n6 >> 2 & 1) == 1)
            { m2 += 64; }
            if ((n7 >> 2 & 1) == 1)
            { m2 += 128; }

            if ((n0 >> 3 & 1) == 1)
            { m3 += 1; }
            if ((n1 >> 3 & 1) == 1)
            { m3 += 2; }
            if ((n2 >> 3 & 1) == 1)
            { m3 += 4; }
            if ((n3 >> 3 & 1) == 1)
            { m3 += 8; }
            if ((n4 >> 3 & 1) == 1)
            { m3 += 16; }
            if ((n5 >> 3 & 1) == 1)
            { m3 += 32; }
            if ((n6 >> 3 & 1) == 1)
            { m3 += 64; }
            if ((n7 >> 3 & 1) == 1)
            { m3 += 128; }

            if ((n0 >> 4 & 1) == 1)
            { m4 += 1; }
            if ((n1 >> 4 & 1) == 1)
            { m4 += 2; }
            if ((n2 >> 4 & 1) == 1)
            { m4 += 4; }
            if ((n3 >> 4 & 1) == 1)
            { m4 += 8; }
            if ((n4 >> 4 & 1) == 1)
            { m4 += 16; }
            if ((n5 >> 4 & 1) == 1)
            { m4 += 32; }
            if ((n6 >> 4 & 1) == 1)
            { m4 += 64; }
            if ((n7 >> 4 & 1) == 1)
            { m4 += 128; }

            if ((n0 >> 5 & 1) == 1)
            { m5 += 1; }
            if ((n1 >> 5 & 1) == 1)
            { m5 += 2; }
            if ((n2 >> 5 & 1) == 1)
            { m5 += 4; }
            if ((n3 >> 5 & 1) == 1)
            { m5 += 8; }
            if ((n4 >> 5 & 1) == 1)
            { m5 += 16; }
            if ((n5 >> 5 & 1) == 1)
            { m5 += 32; }
            if ((n6 >> 5 & 1) == 1)
            { m5 += 64; }
            if ((n7 >> 5 & 1) == 1)
            { m5 += 128; }

            if ((n0 >> 6 & 1) == 1)
            { m6 += 1; }
            if ((n1 >> 6 & 1) == 1)
            { m6 += 2; }
            if ((n2 >> 6 & 1) == 1)
            { m6 += 4; }
            if ((n3 >> 6 & 1) == 1)
            { m6 += 8; }
            if ((n4 >> 6 & 1) == 1)
            { m6 += 16; }
            if ((n5 >> 6 & 1) == 1)
            { m6 += 32; }
            if ((n6 >> 6 & 1) == 1)
            { m6 += 64; }
            if ((n7 >> 6 & 1) == 1)
            { m6 += 128; }

            if ((n0 >> 7 & 1) == 1)
            { m7 += 1; }
            if ((n1 >> 7 & 1) == 1)
            { m7 += 2; }
            if ((n2 >> 7 & 1) == 1)
            { m7 += 4; }
            if ((n3 >> 7 & 1) == 1)
            { m7 += 8; }
            if ((n4 >> 7 & 1) == 1)
            { m7 += 16; }
            if ((n5 >> 7 & 1) == 1)
            { m7 += 32; }
            if ((n6 >> 7 & 1) == 1)
            { m7 += 64; }
            if ((n7 >> 7 & 1) == 1)
            { m7 += 128; }

            // 8
            int ok8 = 0;
            byte mask = 255;

            if  ((n0 & mask) == mask)
            { ok8 += 1; }
            if ((n1 & mask) == mask)
            { ok8 += 1; }
            if ((n2 & mask) == mask)
            { ok8 += 1; }
            if ((n3 & mask) == mask)
            { ok8 += 1; }
            if ((n4 & mask) == mask)
            { ok8 += 1; }
            if ((n5 & mask) == mask)
            { ok8 += 1; }
            if ((n6 & mask) == mask)
            { ok8 += 1; }
            if ((n7 & mask) == mask)
            { ok8 += 1; }

            if ((m0 & mask) == mask)
            { ok8 += 1; }
            if ((m1 & mask) == mask)
            { ok8 += 1; }
            if ((m2 & mask) == mask)
            { ok8 += 1; }
            if ((m3 & mask) == mask)
            { ok8 += 1; }
            if ((m4 & mask) == mask)
            { ok8 += 1; }
            if ((m5 & mask) == mask)
            { ok8 += 1; }
            if ((m6 & mask) == mask)
            { ok8 += 1; }
            if ((m7 & mask) == mask)
            { ok8 += 1; }

            // 7 
            mask = 254;
            byte mask1 = 127;
            int ok7=0;

            if  (((n0 & mask) == mask) || ((n0 & mask1) == mask1))
            { ok7 += 1; }
            if (((n1 & mask) == mask) || ((n1 & mask1) == mask1))
            { ok7 += 1; }
            if (((n2 & mask) == mask) || ((n2 & mask1) == mask1))
            { ok7 += 1; }
            if (((n3 & mask) == mask) || ((n3 & mask1) == mask1))
            { ok7 += 1; }
            if (((n4 & mask) == mask) || ((n4 & mask1) == mask1))
            { ok7 += 1; }
            if (((n5 & mask) == mask) || ((n5 & mask1) == mask1))
            { ok7 += 1; }
            if (((n6 & mask) == mask) || ((n6 & mask1) == mask1))
            { ok7 += 1; }
            if (((n7 & mask) == mask) || ((n7 & mask1) == mask1))
            { ok7 += 1; }

            if (((m0 & mask) == mask) || ((m0 & mask1) == mask1))
            { ok7 += 1; }
            if (((m1 & mask) == mask) || ((m1 & mask1) == mask1))
            { ok7 += 1; }
            if (((m2 & mask) == mask) || ((m2 & mask1) == mask1))
            { ok7 += 1; }
            if (((m3 & mask) == mask) || ((m3 & mask1) == mask1))
            { ok7 += 1; }
            if (((m4 & mask) == mask) || ((m4 & mask1) == mask1))
            { ok7 += 1; }
            if (((m5 & mask) == mask) || ((m5 & mask1) == mask1))
            { ok7 += 1; }
            if (((m6 & mask) == mask) || ((m6 & mask1) == mask1))
            { ok7 += 1; }
            if (((m7 & mask) == mask) || ((m7 & mask1) == mask1))
            { ok7 += 1; }

            // 6
            mask = 252;
            mask1 = 126;
            byte mask2 = 63;
            int ok6 = 0;

            if (((n0 & mask) == mask) || ((n0 & mask1) == mask1) || ((n0 & mask2) == mask2))
            { ok6 += 1; }
            if (((n1 & mask) == mask) || ((n1 & mask1) == mask1) || ((n1 & mask2) == mask2))
            { ok6 += 1; }
            if (((n2 & mask) == mask) || ((n2 & mask1) == mask1) || ((n2 & mask2) == mask2))
            { ok6 += 1; }
            if (((n3 & mask) == mask) || ((n3 & mask1) == mask1) || ((n3 & mask2) == mask2))
            { ok6 += 1; }
            if (((n4 & mask) == mask) || ((n4 & mask1) == mask1) || ((n4 & mask2) == mask2))
            { ok6 += 1; }
            if (((n5 & mask) == mask) || ((n5 & mask1) == mask1) || ((n5 & mask2) == mask2))
            { ok6 += 1; }
            if (((n6 & mask) == mask) || ((n6 & mask1) == mask1) || ((n6 & mask2) == mask2))
            { ok6 += 1; }
            if (((n7 & mask) == mask) || ((n7 & mask1) == mask1) || ((n7 & mask2) == mask2))
            { ok6 += 1; }

            if (((m0 & mask) == mask) || ((m0 & mask1) == mask1) || ((m0 & mask2) == mask2))
            { ok6 += 1; }
            if (((m1 & mask) == mask) || ((m1 & mask1) == mask1) || ((m1 & mask2) == mask2))
            { ok6 += 1; }
            if (((m2 & mask) == mask) || ((m2 & mask1) == mask1) || ((m2 & mask2) == mask2))
            { ok6 += 1; }
            if (((m3 & mask) == mask) || ((m3 & mask1) == mask1) || ((m3 & mask2) == mask2))
            { ok6 += 1; }
            if (((m4 & mask) == mask) || ((m4 & mask1) == mask1) || ((m4 & mask2) == mask2))
            { ok6 += 1; }
            if (((m5 & mask) == mask) || ((m5 & mask1) == mask1) || ((m5 & mask2) == mask2))
            { ok6 += 1; }
            if (((m6 & mask) == mask) || ((m6 & mask1) == mask1) || ((m6 & mask2) == mask2))
            { ok6 += 1; }
            if (((m7 & mask) == mask) || ((m7 & mask1) == mask1) || ((m7 & mask2) == mask2))
            { ok6 += 1; }

            // 5
            mask = 248;
            mask1 = 124;
            mask2 = 62;
            byte mask3 = 31;
            int ok5 = 0;

            if (((n0 & mask) == mask) || ((n0 & mask1) == mask1) || ((n0 & mask2) == mask2) || ((n0 & mask3) == mask3))
            { ok5 += 1; }
            if (((n1 & mask) == mask) || ((n1 & mask1) == mask1) || ((n1 & mask2) == mask2) || ((n1 & mask3) == mask3))
            { ok5 += 1; }
            if (((n2 & mask) == mask) || ((n2 & mask1) == mask1) || ((n2 & mask2) == mask2) || ((n2 & mask3) == mask3))
            { ok5 += 1; }
            if (((n3 & mask) == mask) || ((n3 & mask1) == mask1) || ((n3 & mask2) == mask2) || ((n3 & mask3) == mask3))
            { ok5 += 1; }
            if (((n4 & mask) == mask) || ((n4 & mask1) == mask1) || ((n4 & mask2) == mask2) || ((n4 & mask3) == mask3))
            { ok5 += 1; }
            if (((n5 & mask) == mask) || ((n5 & mask1) == mask1) || ((n5 & mask2) == mask2) || ((n5 & mask3) == mask3))
            { ok5 += 1; }
            if (((n6 & mask) == mask) || ((n6 & mask1) == mask1) || ((n6 & mask2) == mask2) || ((n6 & mask3) == mask3))
            { ok5 += 1; }
            if (((n7 & mask) == mask) || ((n7 & mask1) == mask1) || ((n7 & mask2) == mask2) || ((n7 & mask3) == mask3))
            { ok5 += 1; }

            if (((m0 & mask) == mask) || ((m0 & mask1) == mask1) || ((m0 & mask2) == mask2) || ((m0 & mask3) == mask3))
            { ok5 += 1; }
            if (((m1 & mask) == mask) || ((m1 & mask1) == mask1) || ((m1 & mask2) == mask2) || ((m1 & mask3) == mask3))
            { ok5 += 1; }
            if (((m2 & mask) == mask) || ((m2 & mask1) == mask1) || ((m2 & mask2) == mask2) || ((m2 & mask3) == mask3))
            { ok5 += 1; }
            if (((m3 & mask) == mask) || ((m3 & mask1) == mask1) || ((m3 & mask2) == mask2) || ((m3 & mask3) == mask3))
            { ok5 += 1; }
            if (((m4 & mask) == mask) || ((m4 & mask1) == mask1) || ((m4 & mask2) == mask2) || ((m4 & mask3) == mask3))
            { ok5 += 1; }
            if (((m5 & mask) == mask) || ((m5 & mask1) == mask1) || ((m5 & mask2) == mask2) || ((m5 & mask3) == mask3))
            { ok5 += 1; }
            if (((m6 & mask) == mask) || ((m6 & mask1) == mask1) || ((m6 & mask2) == mask2) || ((m6 & mask3) == mask3))
            { ok5 += 1; }
            if (((m7 & mask) == mask) || ((m7 & mask1) == mask1) || ((m7 & mask2) == mask2) || ((m7 & mask3) == mask3))
            { ok5 += 1; }

            // 4
            mask = 240;
            mask1 = 120;
            mask2 = 60;
            mask3 = 30;
            byte mask4 = 15 ;
            int ok4 = 0;

            if (((n0 & mask) == mask) || ((n0 & mask1) == mask1) || ((n0 & mask2) == mask2) || ((n0 & mask3) == mask3))
            { ok4 += 1; }

            if (((n1 & mask) == mask) || ((n1 & mask1) == mask1) || ((n1 & mask2) == mask2) || ((n1 & mask3) == mask3))
            { ok4 += 1; }
            if (((n2 & mask) == mask) || ((n2 & mask1) == mask1) || ((n2 & mask2) == mask2) || ((n2 & mask3) == mask3))
            { ok4 += 1; }
            if (((n3 & mask) == mask) || ((n3 & mask1) == mask1) || ((n3 & mask2) == mask2) || ((n3 & mask3) == mask3))
            { ok4 += 1; }
            if (((n4 & mask) == mask) || ((n4 & mask1) == mask1) || ((n4 & mask2) == mask2) || ((n4 & mask3) == mask3))
            { ok4 += 1; }
            if (((n5 & mask) == mask) || ((n5 & mask1) == mask1) || ((n5 & mask2) == mask2) || ((n5 & mask3) == mask3))
            { ok4 += 1; }
            if (((n6 & mask) == mask) || ((n6 & mask1) == mask1) || ((n6 & mask2) == mask2) || ((n6 & mask3) == mask3))
            { ok4 += 1; }
            if (((n7 & mask) == mask) || ((n7 & mask1) == mask1) || ((n7 & mask2) == mask2) || ((n7 & mask3) == mask3))
            { ok4 += 1; }
            if ((n0 & mask4) == mask4)
            { ok4 += 1; }
            if ((n1 & mask4) == mask4)
            { ok4 += 1; }
            if ((n2 & mask4) == mask4)
            { ok4 += 1; }
            if ((n3 & mask4) == mask4)
            { ok4 += 1; }
            if ((n4 & mask4) == mask4)
            { ok4 += 1; }
            if ((n5 & mask4) == mask4)
            { ok4 += 1; }
            if ((n6 & mask4) == mask4)
            { ok4 += 1; }
            if ((n7 & mask4) == mask4)
            { ok4 += 1; }

            if (((m0 & mask) == mask) || ((m0 & mask1) == mask1) || ((m0 & mask2) == mask2) || ((m0 & mask3) == mask3))
            { ok4 += 1; }
            if (((m1 & mask) == mask) || ((m1 & mask1) == mask1) || ((m1 & mask2) == mask2) || ((m1 & mask3) == mask3))
            { ok4 += 1; }
            if (((m2 & mask) == mask) || ((m2 & mask1) == mask1) || ((m2 & mask2) == mask2) || ((m2 & mask3) == mask3))
            { ok4 += 1; }
            if (((m3 & mask) == mask) || ((m3 & mask1) == mask1) || ((m3 & mask2) == mask2) || ((m3 & mask3) == mask3))
            { ok4 += 1; }
            if (((m4 & mask) == mask) || ((m4 & mask1) == mask1) || ((m4 & mask2) == mask2) || ((m4 & mask3) == mask3))
            { ok4 += 1; }
            if (((m5 & mask) == mask) || ((m5 & mask1) == mask1) || ((m5 & mask2) == mask2) || ((m5 & mask3) == mask3))
            { ok4 += 1; }
            if (((m6 & mask) == mask) || ((m6 & mask1) == mask1) || ((m6 & mask2) == mask2) || ((m6 & mask3) == mask3))
            { ok4 += 1; }
            if (((m7 & mask) == mask) || ((m7 & mask1) == mask1) || ((m7 & mask2) == mask2) || ((m7 & mask3) == mask3))
            { ok5 += 1; }
            if ((m0 & mask4) == mask4)
            { ok4 += 1; }
            if ((m1 & mask4) == mask4)
            { ok4 += 1; }
            if ((m2 & mask4) == mask4)
            { ok4 += 1; }
            if ((m3 & mask4) == mask4)
            { ok4 += 1; }
            if ((m4 & mask4) == mask4)
            { ok4 += 1; }
            if ((m5 & mask4) == mask4)
            { ok4 += 1; }
            if ((m6 & mask4) == mask4)
            { ok4 += 1; }
            if ((m7 & mask4) == mask4)
            { ok4 += 1; }


            // 3
            mask = 224;
            mask1 = 112;
            mask2 = 56;
            mask3 = 28;
            mask4 = 14;
            byte mask5 = 7;
            int ok3 = 0;

            if (((n0 & mask) == mask) || ((n0 & mask1) == mask1) || ((n0 & mask2) == mask2))
            { ok3 += 1; }
            if (((n0 & mask) == mask3) || ((n0 & mask4) == mask4) || ((n0 & mask5) == mask5))
            { ok3 += 1; }
            if (((n1 & mask) == mask) || ((n1 & mask1) == mask1) || ((n1 & mask2) == mask2))
            { ok3 += 1; }
            if (((n1 & mask) == mask3) || ((n1 & mask4) == mask4) || ((n1 & mask5) == mask5))
            { ok3 += 1; }
            if (((n3 & mask) == mask) || ((n3 & mask1) == mask1) || ((n3 & mask2) == mask2))
            { ok3 += 1; }
            if (((n3 & mask) == mask3) || ((n3 & mask4) == mask4) || ((n3 & mask5) == mask5))
            { ok3 += 1; }
            if (((n4 & mask) == mask) || ((n4 & mask1) == mask1) || ((n4 & mask2) == mask2))
            { ok3 += 1; }
            if (((n4 & mask) == mask3) || ((n4 & mask4) == mask4) || ((n4 & mask5) == mask5))
            { ok3 += 1; }
            if (((n5 & mask) == mask) || ((n5 & mask1) == mask1) || ((n5 & mask2) == mask2))
            { ok3 += 1; }
            if (((n5 & mask) == mask3) || ((n5 & mask4) == mask4) || ((n5 & mask5) == mask5))
            { ok3 += 1; }
            if (((n6 & mask) == mask) || ((n6 & mask1) == mask1) || ((n6 & mask2) == mask2))
            { ok3 += 1; }
            if (((n6 & mask) == mask3) || ((n6 & mask4) == mask4) || ((n6 & mask5) == mask5))
            { ok3 += 1; }
            if (((n7 & mask) == mask) || ((n7 & mask1) == mask1) || ((n7 & mask2) == mask2))
            { ok3 += 1; }
            if (((n7 & mask) == mask3) || ((n7 & mask4) == mask4) || ((n7 & mask5) == mask5))
            { ok3 += 1; }

            if (((m0 & mask) == mask) || ((m0 & mask1) == mask1) || ((m0 & mask2) == mask2))
            { ok3 += 1; }
            if (((m0 & mask) == mask3) || ((m0 & mask4) == mask4) || ((m0 & mask5) == mask5))
            { ok3 += 1; }
            if (((m1 & mask) == mask) || ((m1 & mask1) == mask1) || ((m1 & mask2) == mask2))
            { ok3 += 1; }
            if (((m1 & mask) == mask3) || ((m1 & mask4) == mask4) || ((m1 & mask5) == mask5))
            { ok3 += 1; }
            if (((m3 & mask) == mask) || ((m3 & mask1) == mask1) || ((m3 & mask2) == mask2))
            { ok3 += 1; }
            if (((m3 & mask) == mask3) || ((m3 & mask4) == mask4) || ((m3 & mask5) == mask5))
            { ok3 += 1; }
            if (((m4 & mask) == mask) || ((m4 & mask1) == mask1) || ((m4 & mask2) == mask2))
            { ok3 += 1; }
            if (((m4 & mask) == mask3) || ((m4 & mask4) == mask4) || ((m4 & mask5) == mask5))
            { ok3 += 1; }
            if (((m5 & mask) == mask) || ((m5 & mask1) == mask1) || ((m5 & mask2) == mask2))
            { ok3 += 1; }
            if (((m5 & mask) == mask3) || ((m5 & mask4) == mask4) || ((m5 & mask5) == mask5))
            { ok3 += 1; }
            if (((m6 & mask) == mask) || ((m6 & mask1) == mask1) || ((m6 & mask2) == mask2))
            { ok3 += 1; }
            if (((m6 & mask) == mask3) || ((m6 & mask4) == mask4) || ((m6 & mask5) == mask5))
            { ok3 += 1; }
            if (((m7 & mask) == mask) || ((m7 & mask1) == mask1) || ((m7 & mask2) == mask2))
            { ok3 += 1; }
            if (((n7 & mask) == mask3) || ((n7 & mask4) == mask4) || ((n7 & mask5) == mask5))
            { ok3 += 1; }

            // 2
            mask = 192;
            mask1 = 96;
            mask2 = 48;
            mask3 = 24;
            mask4 = 12;
            mask5 = 6;
            byte mask6 = 3;
            int ok2 = 0;

            if (((n0 & mask) == mask) || ((n0 & mask1) == mask1))
            { ok2 += 1; }
            if (((n0 & mask2) == mask2) || ((n0 & mask3) == mask3))
            { ok2 += 1; }
            if (((n0 & mask4) == mask4) || ((n0 & mask5) == mask5))
            { ok2 += 1; }
            if (((n0 & mask6) == mask6))
            { ok2 += 1; }
            if (((n1 & mask) == mask) || ((n1 & mask1) == mask1))
            { ok2 += 1; }
            if (((n1 & mask2) == mask2) || ((n1 & mask3) == mask3))
            { ok2 += 1; }
            if (((n1 & mask4) == mask4) || ((n1 & mask5) == mask5))
            { ok2 += 1; }
            if (((n1 & mask6) == mask6))
            { ok2 += 1;}
            if (((n2 & mask) == mask) || ((n2 & mask1) == mask1))
            { ok2 += 1; }
            if (((n2 & mask2) == mask2) || ((n2 & mask3) == mask3))
            { ok2 += 1; }
            if (((n2 & mask4) == mask4) || ((n2 & mask5) == mask5))
            { ok2 += 1; }
            if (((n2 & mask6) == mask6))
            { ok2 += 1; }
            if (((n3 & mask) == mask) || ((n3 & mask1) == mask1))
            { ok2 += 1; }
            if (((n3 & mask2) == mask2) || ((n3 & mask3) == mask3))
            { ok2 += 1; }
            if (((n3 & mask4) == mask4) || ((n3 & mask5) == mask5))
            { ok2 += 1; }
            if (((n3 & mask6) == mask6))
            { ok2 += 1; }
            if (((n4 & mask) == mask) || ((n4 & mask1) == mask1))
            { ok2 += 1; }
            if (((n4 & mask2) == mask2) || ((n4 & mask3) == mask3))
            { ok2 += 1; }
            if (((n4 & mask4) == mask4) || ((n4 & mask5) == mask5))
            { ok2 += 1; }
            if (((n4 & mask6) == mask6))
            { ok2 += 1; }
            if (((n5 & mask) == mask) || ((n5 & mask1) == mask1))
            { ok2 += 1; }
            if (((n5 & mask2) == mask2) || ((n5 & mask3) == mask3))
            { ok2 += 1; }
            if (((n5 & mask4) == mask4) || ((n5 & mask5) == mask5))
            { ok2 += 1; }
            if (((n5 & mask6) == mask6))
            { ok2 += 1;}
            if (((n6 & mask) == mask) || ((n6 & mask1) == mask1))
            { ok2 += 1; }
            if (((n6 & mask2) == mask2) || ((n6 & mask3) == mask3))
            { ok2 += 1; }
            if (((n6 & mask4) == mask4) || ((n6 & mask5) == mask5))
            { ok2 += 1; }
            if (((n6 & mask6) == mask6))
            { ok2 += 1; }
            if (((n7 & mask) == mask) || ((n7 & mask1) == mask1))
            { ok2 += 1; }
            if (((n7 & mask2) == mask2) || ((n7 & mask3) == mask3))
            { ok2 += 1; }
            if (((n7 & mask4) == mask4) || ((n7 & mask5) == mask5))
            { ok2 += 1; }
            if (((n7 & mask6) == mask6))
            { ok2 += 1; }

            if (((m0 & mask) == mask) || ((m0 & mask1) == mask1))
            { ok2 += 1; }
            if (((m0 & mask2) == mask2) || ((m0 & mask3) == mask3))
            { ok2 += 1; }
            if (((m0 & mask4) == mask4) || ((m0 & mask5) == mask5))
            { ok2 += 1; }
            if (((m0 & mask6) == mask6))
            { ok2 += 1; }
            if (((m1 & mask) == mask) || ((m1 & mask1) == mask1))
            { ok2 += 1; }
            if (((m1 & mask2) == mask2) || ((m1 & mask3) == mask3))
            { ok2 += 1; }
            if (((m1 & mask4) == mask4) || ((m1 & mask5) == mask5))
            { ok2 += 1; }
            if (((m1 & mask6) == mask6))
            { ok2 += 1; }
            if (((m2 & mask) == mask) || ((m2 & mask1) == mask1))
            { ok2 += 1; }
            if (((m2 & mask2) == mask2) || ((m2 & mask3) == mask3))
            { ok2 += 1; }
            if (((m2 & mask4) == mask4) || ((m2 & mask5) == mask5))
            { ok2 += 1; }
            if (((m2 & mask6) == mask6))
            { ok2 += 1; }
            if (((m3 & mask) == mask) || ((m3 & mask1) == mask1))
            { ok2 += 1; }
            if (((m3 & mask2) == mask2) || ((m3 & mask3) == mask3))
            { ok2 += 1; }
            if (((m3 & mask4) == mask4) || ((m3 & mask5) == mask5))
            { ok2 += 1; }
            if (((m3 & mask6) == mask6))
            { ok2 += 1; }
            if (((m4 & mask) == mask) || ((m4 & mask1) == mask1))
            { ok2 += 1; }
            if (((m4 & mask2) == mask2) || ((m4 & mask3) == mask3))
            { ok2 += 1; }
            if (((m4 & mask4) == mask4) || ((m4 & mask5) == mask5))
            { ok2 += 1; }
            if (((m4 & mask6) == mask6))
            { ok2 += 1; }
            if (((m5 & mask) == mask) || ((m5 & mask1) == mask1))
            { ok2 += 1; }
            if (((m5 & mask2) == mask2) || ((m5 & mask3) == mask3))
            { ok2 += 1; }
            if (((m5 & mask4) == mask4) || ((m5 & mask5) == mask5))
            { ok2 += 1; }
            if (((m5 & mask6) == mask6))
            { ok2 += 1; }
            if (((m6 & mask) == mask) || ((m6 & mask1) == mask1))
            { ok2 += 1; }
            if (((m6 & mask2) == mask2) || ((m6 & mask3) == mask3))
            { ok2 += 1; }
            if (((m6 & mask4) == mask4) || ((m6 & mask5) == mask5))
            { ok2 += 1; }
            if (((m6 & mask6) == mask6))
            { ok2 += 1; }
            if (((m7 & mask) == mask) || ((m7 & mask1) == mask1))
            { ok2 += 1; }
            if (((m7 & mask2) == mask2) || ((m7 & mask3) == mask3))
            { ok2 += 1; }
            if (((m7 & mask4) == mask4) || ((m7 & mask5) == mask5))
            { ok2 += 1; }
            if (((m7 & mask6) == mask6))
            { ok2 += 1; }


            if (ok8 > 0)
            {
                Console.WriteLine("8");
                Console.WriteLine(ok8);
            }
            else if (ok7 > 0)
            {
                Console.WriteLine("7");
                Console.WriteLine(ok7);
            }
            else if (ok6 > 0)
            {
                Console.WriteLine("6");
                Console.WriteLine(ok6);
            }
            else if (ok5 > 0)
            {
                Console.WriteLine("5");
                Console.WriteLine(ok5);
            }
            else if (ok4 > 0)
            {
                Console.WriteLine("4");
                Console.WriteLine(ok4);
            }
            else if (ok3 > 0)
            {
                Console.WriteLine("3");
                Console.WriteLine(ok3);
            }
            else if (ok2>0)
            {
                Console.WriteLine("2");
                Console.WriteLine(ok2);
            }


        }
    }
}
       