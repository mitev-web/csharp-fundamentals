using System;
using System.Numerics;

namespace Problem01
{
    class Problem01_
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                if ((i == 0) || (i == (n - 1)))
                {
                    Console.WriteLine(new string('*', n));
                }
                else if (i == (n / 2))
                {
                    Console.WriteLine(new string('.', (n / 2)) + "*" + new string('.', (n / 2)));
                }
                else if (i < (n / 2))
                {
                    Console.WriteLine(new string('.', i) + new string('*', (n - (i * 2))) + new string('.', i));
                }
                else if (i > (n / 2))
                {
                    Console.WriteLine(new string('.', (n - i - 1)) + new string('*', (n - ((n - i - 1) * 2))) + new string('.', (n - i - 1)));
                }
            }
        }
    }
}
