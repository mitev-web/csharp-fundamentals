using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2_Exam
{
    class Program
    {
        static void Main(string[] args)
        {

            string line = Console.ReadLine();
            int px1 = int.Parse(line);
            line = Console.ReadLine();
            int py1 = int.Parse(line);
            line = Console.ReadLine();
            int px2 = int.Parse(line);
            line = Console.ReadLine();
            int py2 = int.Parse(line);
            line = Console.ReadLine();
            int fx = int.Parse(line);
            line = Console.ReadLine();
            int fy = int.Parse(line);
            line = Console.ReadLine();
            int d = int.Parse(line);

            int leftBotomCornerX;
            int leftBottomCornerY;
            int rightTopCornerX=1;
            int rightTopCornerY=1;

            if (px1 < px2)
            {
                leftBotomCornerX = px1;
                rightTopCornerX = px2;
            }
            else
            {
                leftBotomCornerX = px2;
                rightTopCornerX = px1;
            }

            if (py1 < py2)
            {
                leftBottomCornerY= py1;
                rightTopCornerY = py2;
            }
            else
            {
                leftBottomCornerY = py2;
                rightTopCornerY = py1;
            }

            sbyte delta = 0; //ok
            sbyte delta2 = 0; //ok
            byte damage = 0;


            // 100%
            if (((fx + d + delta ) >= leftBotomCornerX) && ((fx + d + delta2) <= rightTopCornerX) && (fy >= leftBottomCornerY) && (fy <= rightTopCornerY))
            { damage += 100; }
            if (((fx + d + delta) >= leftBotomCornerX) && ((fx + d + delta2) <= rightTopCornerX) && ((fy - 1) >= leftBottomCornerY) && ((fy - 1) <= rightTopCornerY))
            { damage += 50; }
            if (((fx + d + delta ) >= leftBotomCornerX) && ((fx + d + delta2) <= rightTopCornerX) && ((fy + 1) >= leftBottomCornerY) && ((fy + 1) <= rightTopCornerY))
            { damage += 50; }
            if (((fx + d + 1 + delta ) >= leftBotomCornerX) && ((fx + d + 1 + delta2) <= rightTopCornerX) && (fy >= leftBottomCornerY) && (fy <= rightTopCornerY))
            { damage += 75; }

            Console.WriteLine("{0}%", damage);
        }
    }
}
