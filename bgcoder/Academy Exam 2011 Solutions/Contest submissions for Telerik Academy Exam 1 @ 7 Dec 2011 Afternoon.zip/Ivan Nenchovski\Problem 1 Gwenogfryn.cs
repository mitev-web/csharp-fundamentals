using System;
using System.Collections.Generic;

namespace MyFirstTelerikExam
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            char[] hourGlass = new char[n * (n + 1)];
            int outputPos = 0;
            for (int y = 0; y < n; y++, outputPos++)
            {
                for (int x = 0; x < n; x++, outputPos++)
                {
                    bool cellIsSand = (x >= y && x < (n - y)) || (x >= (n-y-1) && x <= y);
                    hourGlass[outputPos] = cellIsSand ? '*' : '.';
                }
                hourGlass[outputPos] = '\n';
            }
            Console.WriteLine(hourGlass);
        }
    }
}
