using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task03.SpecialAlgorithm
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {
            string stringNumber = Console.ReadLine();
            decimal number = decimal.Parse(stringNumber);
            BigInteger sum = 0;
            BigInteger temp = 0;
            BigInteger n = 0;
            for (int j = 0; j < 22; j++)
            {
                number *= 10;
            }

            n = (BigInteger)number;

            while (true)
            {
                if (n > 0)
                {
                    while (n != 0)
                    {
                        temp = n % 10;
                        n = n / 10;
                        sum += temp;
                    }
                }
                else
                {
                    while (n != 0)
                    {
                        temp = n % 10;
                        n = n / 10;
                        sum -= temp;
                    }
                }

                if (sum <= 9)
                {
                    Console.WriteLine(sum);
                    break;
                }
                else
                {
                    n = sum;
                    sum = 0;
                }

            }
        }
    }
}
