using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace RealExam
{
    class RealExam
    {
        static void Main(string[] args)
        {
            dancingBits();
        }

        static void dancingBits()
        {
            int K = 0;
            int N = 0;
            K = int.Parse(Console.ReadLine());
            N = int.Parse(Console.ReadLine());
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < N; i++)
            {
                int number = int.Parse(Console.ReadLine());

                sb.Append(Convert.ToString(number, 2));
            }

            string[] zeros = (sb.ToString()).Split('0');
            string[] ones = (sb.ToString()).Split('1');

            int result = 0;

            for (int j = 0; j < zeros.Length; j++)
            {
                if (zeros[j].Length == K) result++;
            }
            for (int j = 0; j < ones.Length; j++)
            {
                if (ones[j].Length == K) result++;
            }

            Console.WriteLine(result);
        }
    }
}
