using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int count = 0;

            int[] numbers = new int[n];
            for (int i = 0; i < n; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
            int countSeq = 0;
            int mask = 1 & numbers[n-1];
            for (int i = n-1; i >= 0; i--)
            {
                
                int number = numbers[i];
                
                while (number > 0)
                {
                    if ((number & 1) == mask)
                    {
                        countSeq++;
                    }
                    else
                    {
                        mask = number & 1;
                        if (countSeq == k)
                        {
                            count++;
                        }
                        countSeq = 1;
                    }
                    number >>= 1;
                }
                
            }
            if (countSeq == k)
            {
                count++;
            }
            Console.WriteLine(count);
        }
    }
}
