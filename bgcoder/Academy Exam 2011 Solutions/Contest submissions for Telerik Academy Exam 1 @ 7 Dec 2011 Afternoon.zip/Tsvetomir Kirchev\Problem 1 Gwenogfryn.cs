using System;

namespace Gwenogfryn
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine());
            char[,] matrix = new char[n, n];

            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    matrix[row, col] = '*';
                }   
            }
            int counter = 0;
            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < counter; col++)
                {
                    matrix[row, col] = '.';
                }

                if (counter == (n) / 2)
                {
                    break;
                }
                else
                {
                    counter++;
                }
            }
            counter = n / 2;
            for (int row = n / 2; row < n; row++)
            {
                for (int col = 0; col < counter; col++)
                {
                    matrix[row, col] = '.';
                }

                if (counter == 0)
                {
                    break;
                }
                else
                {
                    counter--;
                }
            }
            counter = n - 1;
            for (int row = 0; row < n; row++)
            {
                for (int col = n - 1; col > counter; col--)
                {
                    matrix[row, col] = '.';
                }

                if (counter == n / 2)
                {
                    break;
                }
                else
                {
                    counter--;
                }
            }
            counter = n / 2 + 1;
            for (int row = (n / 2) + 1; row < n; row++)
            {
                for (int col = n - 1; col > counter; col--)
                {
                    matrix[row, col] = '.';
                }

                if (counter == n)
                {
                    break;
                }
                else
                {
                    counter++;
                }
            }

            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    Console.Write(matrix[row, col]);
                }
                Console.WriteLine();
            }
        }
    }
}
