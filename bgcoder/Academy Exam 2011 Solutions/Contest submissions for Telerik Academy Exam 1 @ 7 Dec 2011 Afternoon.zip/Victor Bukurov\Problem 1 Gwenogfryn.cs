using System;

namespace Hourglass
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = Byte.Parse(Console.ReadLine());

            for (int i = 0; i < ((n / 2) + 1); i++)
            {
                PrintLine(n, i);
            }
            for (int i = ((n / 2) - 1); i >= 0; i--)
            {
                PrintLine(n, i);
            }
        }

        static void PrintLine(byte cols, int row)
        {
            for (int i = 0; i < cols; i++)
            {
                if ((i >= row) && i < (cols - row))
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.Write("\n");
        }
    }
}
