using System;

class DancingBits
{
    static void Main(string[] args)
    {
        int k = int.Parse(Console.ReadLine());
        int n = int.Parse(Console.ReadLine());

        int[] numbers = new int[n];
        string[] binaryNum = new string[n];
        string fullBinary = "";

        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = int.Parse(Console.ReadLine());
            binaryNum[i] = Convert.ToString(numbers[i], 2);
            fullBinary += string.Concat(binaryNum[i]);
        }
        //Console.WriteLine(fullBinary);
        char[] arr = new char[fullBinary.Length];
        arr = fullBinary.ToCharArray();
        string zeros = "", ones = "";
        for (int i = 0; i < k; i++)
        {
            zeros += "0";
            ones += "1";
        }
        string temp = "";
        int count = 0;
        int onePlus = 0;
        for (int i = 1; i <= arr.Length; i++)
        {
            for (int j = 0; j < k; j++)
            {
                if (onePlus == arr.Length || onePlus > arr.Length)
                {
                    break;
                }
                temp += arr[onePlus];
                onePlus++;
            }
            //Console.WriteLine(temp);
            
            if (temp == zeros || temp==ones)
            {
                count++;
                onePlus = i + k - 1;
            }
            temp = "";
            
        }
        Console.WriteLine(count);
    }
}