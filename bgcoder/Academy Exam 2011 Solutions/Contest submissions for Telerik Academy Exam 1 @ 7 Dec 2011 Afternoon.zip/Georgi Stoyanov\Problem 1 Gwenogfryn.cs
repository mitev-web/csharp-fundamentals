using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
           
            /* printing top triangle */
            for (int i = 0; i < n/2; i++)
            {
                for (int k = 0; k < i; k++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < n - 2*i; j++)
                {
                    Console.Write("*");
                }
                for (int k = 0; k < i; k++)
                {
                    Console.Write(".");
                }
                Console.WriteLine("");
            }

            /* printing mid row */
            for (int i = 0; i < n - 1; i++)
            {
                Console.Write(".");
                if (i == (n / 2 - 1))
                    Console.Write("*");
            }
            Console.WriteLine("");

            /* printing bottom triangle */
            for (int i = n/2-1; i >= 0; i--)
            {
                for (int k = 0; k < i; k++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < n - 2*i; j++)
                {
                    Console.Write("*");
                }
                for (int k = 0; k < i; k++)
                {
                    Console.Write(".");
                }
                Console.WriteLine("");
            }
        }
    }
}
