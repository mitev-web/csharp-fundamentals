using System;


namespace ConsoleApplication1111111
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
             int counter = n - (n-1);
            int o = n;
            for (int row = n; row >= 0; row--)
            {
                if (row != 0)
                {
                    for (int column = row; column > 0; column--)
                    {
                        Console.Write("*", column);
                    }
                    //Console.Write("*");
                    //   if (row == n)
                    // {
                    //   for (int i = (n - 2); i >= 0; i--)
                    // {
                    //   Console.Write("*");
                    //}
                    // }


                    Console.WriteLine();
                    if (row == n)
                    {
                        Console.Write(".");
                        for (int i = n - 2; i > 0; i--)
                        {
                            Console.Write("*");
                        }
                        Console.Write(".");

                    }


                    else if (row == n - (n - 3))
                    {
                        for (int b = (n - (n - 3)); b > 0; b--)
                        {
                            Console.Write(".");
                        }

                    }
                }
                else
                {
                    Console.WriteLine();
                    for (int i = 0; i < n; i++)
                    {
                        Console.Write("*");
                    }

                }
            }
        }
    }
        }
    

