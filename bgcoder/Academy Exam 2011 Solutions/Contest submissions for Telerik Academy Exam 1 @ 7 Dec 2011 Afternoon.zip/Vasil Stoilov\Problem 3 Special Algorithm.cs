using System;

class SpecialAlgorithm
{
    static void Main(string[] args)
    {
        decimal n = decimal.Parse(Console.ReadLine());
        int intPart = (int)n;
        decimal zero = n - intPart;
        //Console.WriteLine(zero);
        decimal decimalPart = n - intPart;
        double sum = 0;
        if (n < 0)
        {
            n = Math.Abs(n);
        }

        byte[] digits = new byte[n.ToString().Length];

        //Console.WriteLine(decimalPart);
        for (int i = 0; i < digits.Length; i++)
        {
            digits[i] = (byte)(n % 10);
            n /= 10;
            sum += digits[i];
            //Console.WriteLine(digits[i]);
        }
        bool condition = (n - intPart != 0);
        if (zero != 0)
        {
            //Console.WriteLine(decimalPart);
            int[] digitsDec = new int[decimalPart.ToString().Length - 2];
            for (int i = 0; i < digitsDec.Length; i++)
            {
                if (decimalPart == 0)
                {
                    break;
                }
                decimalPart *= 10;
                //Console.WriteLine(decimalPart);
                digitsDec[i] = (int)(decimalPart % 10);
                decimalPart -= digitsDec[i];
                //Console.WriteLine(decimalPart);
                sum += digitsDec[i];
                //Console.WriteLine(digitsDec[i]);
            }
        }
        //sum = Math.Abs(sum);
        //Console.WriteLine(sum);
        //int newSum = 0;
        
        while (sum > 9)
        {
            byte[] digitsSum = new byte[sum.ToString().Length];
            for (int i = 0; i < digitsSum.Length; i++)
            {
                digitsSum[i] = (byte)(sum % 10);
                sum /= 10;
                //newSum += digitsSum[i];
                //Console.WriteLine(digitsSum[i]);
            }
            sum = 0;
            for (int i = 0; i < digitsSum.Length; i++)
            {
                sum += digitsSum[i];
            }
        }
        Console.WriteLine(sum);
    }
}

