using System;

namespace Task5_StraightSequences
{
    class StraightSequences
    {

        struct Couple
        {
            public byte number;
            public byte count;

            Couple(byte number, byte count)
            {
                this.number = number;
                this.count = count;
            }
        };

        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                byte currentNumber = Convert.ToByte(Console.ReadLine());
                numbers[i] = currentNumber;
            }
            Couple[] sequences = new Couple[16];
            FillFromRows(numbers, sequences);
            FillFromColumns(numbers, sequences);
            byte max = 0;
            for (int i = 0; i < sequences.Length; i++)
            {
                if (sequences[i].number > max)
                {
                    max = sequences[i].number;
                }
            }
            int result = 0;
            for (int i = 0; i < sequences.Length; i++)
            {
                if (sequences[i].number == max)
                {
                    result = result + sequences[i].count;
                }
            }
            Console.WriteLine(max);
            Console.WriteLine(result);
        }

        //private static void FillFromColumns(byte[] numbers, Couple[] sequences)
        //{
        //    for (int i = 0; i < 8; i++)
        //    {
        //        byte[] bits = new byte[8];
        //        for (int j = 0; j < numbers.Length; j++)
        //        {
        //            bits[j] = BitAtPosition(numbers[j], i);
        //        }
        //        byte maxSeqLength = GetMaxSequenceLength(bits);
        //        sequences[i + 8].number = maxSeqLength;

        //        byte prevBit = bits[0];
        //        byte result = 0;
        //        int currentSequenceCount = 1;
        //        for (int j = 1; j < 8; j++)
        //        {
        //            byte currentBit = bits[j];
        //            if (prevBit == currentBit)
        //            {
        //                currentSequenceCount++;
        //            }
        //            else
        //            {
        //                if (currentSequenceCount == maxSeqLength && prevBit == 1)
        //                {
        //                    result++;
        //                }
        //                currentSequenceCount = 1;
        //            }
        //            prevBit = currentBit;
        //        }
        //        if (currentSequenceCount == maxSeqLength && prevBit == 1)
        //        {
        //            result++;
        //        }

        //        sequences[i + 8].count = result;
        //    }
        //}

        private static void FillFromColumns(byte[] numbers, Couple[] sequences)
        {
            bool[] prev = new bool[8];
            byte[] currentLength = new byte[8] {1, 1, 1, 1, 1, 1, 1, 1};
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                byte result = (byte)(numbers[i] & numbers[i + 1]);
                for (int j = 0; j < 8; j++)
                {
                    byte currentBit = BitAtPosition(result, j);
                    if (currentBit == 1)
                    {
                        if (prev[j] == true)
                        {
                            currentLength[j]++;
                        }
                        prev[j] = true;
                    }
                    else
                    {
                        if (currentLength[j] > sequences[8 + j].number && prev[j] != false)
                        {
                            sequences[8 + j].number = (byte)(currentLength[j] + 1);
                            sequences[8 + j].count = 1;
                            currentLength[j] = 1;
                            prev[j] = false;
                        }
                        if (currentLength[j] + 1 == sequences[8 + j].number && prev[j] != false)
                        {
                            sequences[8 + j].count++;
                            currentLength[j] = 1;
                            prev[j] = false;
                        }
                    }
                }
            }
            for (int j = 0; j < 8; j++)
            {
                if (currentLength[j] > sequences[8 + j].number && prev[j] != false)
                {
                    sequences[8 + j].number = (byte)(currentLength[j] + 1);
                    sequences[8 + j].count = 1;
                    currentLength[j] = 1;
                    prev[j] = false;
                }
                if (currentLength[j] + 1 == sequences[8 + j].number && prev[j] != false)
                {
                    sequences[8 + j].count++;
                    currentLength[j] = 1;
                    prev[j] = false;
                }
            }
        }

        private static byte GetMaxSequenceLength(byte[] bits)
        {
            byte prevBit = bits[0];
            byte maxLength = byte.MinValue;
            byte currentLength = 1;
            for (int i = 1; i < bits.Length; i++)
            {
                byte currentBit = bits[i];
                if (currentBit == 1)
                {
                    if (prevBit == currentBit)
                    {
                        currentLength++;
                        maxLength = currentLength;
                    }
                    else
                    {
                        if (currentLength > maxLength)
                        {
                            maxLength = currentLength;
                        }
                    }
                }
                else
                {
                    currentLength = 1;
                }
                prevBit = currentBit;
            }
            return maxLength;
        }

        private static void FillFromRows(byte[] numbers, Couple[] sequences)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                byte seqLength = FindSequenceLength(numbers[i]);
                sequences[i].number = seqLength;
                sequences[i].count = FindCountRow(numbers[i], seqLength);
            }
        }

        private static byte FindCountRow(byte number, byte length)
        {
            byte prevBit = BitAtPosition(number, 0);
            byte result = 0;
            int currentSequenceCount = 1;
            for (int i = 1; i < 8; i++)
            {
                byte currentBit = BitAtPosition(number, i);
                if (prevBit == currentBit)
                {
                    currentSequenceCount++;
                }
                else
                {
                    if (currentSequenceCount == length && prevBit == 1)
                    {
                        result++;
                    }
                    currentSequenceCount = 1;
                }
                prevBit = currentBit;
            }
            if (currentSequenceCount == length && prevBit == 1)
            {
                result++;
            }
            return result;
        }

        private static byte FindSequenceLength(byte number)
        {
            byte prevBit = BitAtPosition(number, 0);
            byte maxLength = byte.MinValue;
            byte currentLength = 1;
            for (int i = 1; i < 8; i++)
            {
                byte currentBit = BitAtPosition(number, i);
                if (currentBit == 1)
                {
                    if (prevBit == currentBit)
                    {
                        currentLength++;
                        maxLength = currentLength;
                    }
                    else
                    {
                        if (currentLength > maxLength)
                        {
                            maxLength = currentLength;
                        }
                    }
                }
                else
                {
                    if (prevBit == 1 && i == 1)
                    {
                        maxLength = 1;
                    }
                    currentLength = 1;
                }
                prevBit = currentBit;
            }
            return maxLength;
        }

        private static byte BitAtPosition(byte number, int position)
        {
            byte mask = (byte)(1 << position);
            if ((number & mask) == 0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }
}
