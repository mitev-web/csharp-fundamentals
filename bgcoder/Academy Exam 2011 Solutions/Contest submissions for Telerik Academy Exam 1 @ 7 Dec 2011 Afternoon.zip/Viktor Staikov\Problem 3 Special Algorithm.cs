using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpecialAlgorithm
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {
            char c;
            int n = 0;
            int sum = 0;
            while (true)
            {
                c = (char)Console.Read();
                if (c == '.' || c=='-')
                    continue;
                if (c < '0' || c > '9')
                    break;
                sum += c - '0';
            }

            n = sum;

            do
            {
                sum = 0;
                while (n!=0)
	            {
                    sum += n % 10;
                    n /= 10;
	            }
                n = sum;
            } while (n>9);

            Console.WriteLine(n);
        }
    }
}
