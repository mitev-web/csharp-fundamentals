using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task1
{
    class task1
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            
            }
            Console.WriteLine();
            
            
            
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");

            }
            Console.WriteLine();
        }
    }
}