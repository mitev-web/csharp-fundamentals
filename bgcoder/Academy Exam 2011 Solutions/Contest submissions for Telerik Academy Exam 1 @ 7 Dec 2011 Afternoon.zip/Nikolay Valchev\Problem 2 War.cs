using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem
{
    class Program_2
    {
        static void Main(string[] args)
        {


            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int result = 0;



            if (px1 > px2)
            {
                px1 = px1 + px2;
                px2 = px1 - px2;
                px1 = px1 - px2;
            }

            if (py1 > py2)
            {
                py1 = py1 + py2;
                py2 = py1 - py2;
                py1 = py1 - py2;
            }

            if ((fx + d) >= px1 && (fx + d) <= px2 && (fy >= py1) && (fy <= py2))
            {
                result += 100;



            }

            if ((fx + d) >= px1 && (fx + d) <= px2 && (fy + 1) >= py1 && (fy + 1) <= py2)
            {
                result += 50;
            }



            if ((fx + d) >= px1 && (fx + d) <= px2 && (fy - 1) >= py1 && (fy - 1) <= py2)
            {
                result += 50;
            }

            
            if ((fx + d + 1) >= px1 && (fx + d + 1) <= px2 && (fy >= py1) && (fy <= py2))
            {
                result += 75;
            }

            Console.WriteLine("{0}%", result);

        }
    }
}