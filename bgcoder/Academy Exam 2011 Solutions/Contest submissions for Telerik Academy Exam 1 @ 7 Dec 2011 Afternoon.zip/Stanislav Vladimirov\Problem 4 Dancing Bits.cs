using System;
using System.Numerics;

namespace Problem04
{
    class Problem04
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            long input = new long();

            string binaryTEMP = null;
            string binary = null;

            for (int i = 0; i < n; i++)
            {
                input = long.Parse(Console.ReadLine());                
                do
	            {
                    binaryTEMP = ((input % 2 == 0) ? "0" : "1") + binaryTEMP;
                    input = input / 2;	         
	            } while (input != 0);
                binary = binary + binaryTEMP;
                binaryTEMP = null;
            }
            //Console.WriteLine(binary);

            int counter = 0;
            int dancingbits = 0;
            int j = 0;
            Char Temp = new char();

            for (int i = 0; i < (binary.Length - k); i++)
            {
                Temp = binary[i];
                counter = 1;
                for (int bits = i + 1; bits < binary.Length; bits++)
                {
                    if (binary[bits] == Temp)
                    {
                        counter++;
                    }
                    else
                    {
                        i = bits - 1;
                        break;
                    }                    
                }
                if (counter == k)
                {
                    dancingbits++;
                }
            }
            if (k == 1)
            {
                dancingbits++;
            }

            Console.WriteLine(dancingbits);
        }
    }
}
