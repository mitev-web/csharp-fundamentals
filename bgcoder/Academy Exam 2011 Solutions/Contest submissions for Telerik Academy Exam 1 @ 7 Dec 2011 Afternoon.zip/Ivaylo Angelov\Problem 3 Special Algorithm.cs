using System;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace ProblemThree
{
    class ProblemThree
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-us");
            string input = Console.ReadLine();
            char[] array = input.ToCharArray();
            for (int i = 0; i < array.Length; i++)
            {
                if ((array[i] == '.') || (array[i] == '-')) array[i] = '0';
            }
            string a = new string(array);
            BigInteger newInt = BigInteger.Parse(a);
            BigInteger sum = 0;
            bool more = true;
            while (more)
            {
                do
                {
                    sum += newInt % 10;
                    newInt = newInt / 10;
                } 
                while (newInt >= 1);

                if (sum <= 9)
                {
                    Console.WriteLine(sum);
                    more = false;
                }
                else
                {
                    newInt = sum;
                    sum = 0;
                    continue;
                }
            } 
            
            
            
        }
    }
}
