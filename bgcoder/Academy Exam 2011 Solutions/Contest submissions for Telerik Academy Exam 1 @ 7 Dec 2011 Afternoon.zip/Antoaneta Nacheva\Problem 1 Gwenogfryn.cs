using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.wizard
{
    class Program
    {
        static void Main(string[] args)
        {

            int height = int.Parse(Console.ReadLine());

            int v = height;
            int b;
            b = v % 2;
            if (b == 0)
            {
                Console.WriteLine();
            }
            else
            {
                if (height <= 101)
                {


                    height = Convert.ToInt32(height);
                    string x = "*";


                    for (int counter = 0; counter < height; counter++)
                    {
                        Console.Write("\n");
                        for (int counter2 = 0; counter2 < height; counter2++)
                        {
                            Console.Write(x);
                        }
                    }

                    Console.WriteLine("");
                }
            }



        }
    }
}