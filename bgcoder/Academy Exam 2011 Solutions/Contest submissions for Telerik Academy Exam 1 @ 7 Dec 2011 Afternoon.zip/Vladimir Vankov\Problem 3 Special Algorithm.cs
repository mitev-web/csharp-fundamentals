using System;


namespace PROBLEM3333
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal n = decimal.Parse(Console.ReadLine());
            int sign = 1;
            if (n * sign < 0)
            {
                n = -1 * n;
            }


            string m = Convert.ToString(n);


            //string number;
            //int code1 = 0;
            int sum = 0;
            if (m.Length > 1)
            {
                for (int i = 0; i <= m.Length; i++)
                {





                    int code = 0;
                    if (i != m.Length)
                    {
                        if ((int)m[i] == 46)
                        {
                            continue;
                        }
                        string k = m[i].ToString();
                        code = int.Parse(k);
                    }
                    else
                    {
                        code = 0;
                    }


                    sum = sum + code;
                    if (i == (m.Length))
                    {
                        if (sum > 9)
                        {

                            m = Convert.ToString(sum);
                            i = i - (i + 1);
                            sum = 0;
                        }
                        else
                        {
                            Console.WriteLine("{0}", sum);
                        }
                    }


                    // else
                    // {
                    //     continue;
                    // }

                }
            }
            else
            {
                Console.WriteLine("{0}",n);
            }

        }
            

            

        
    }
}
