using System;
using System.Numerics;

namespace Problem03
{
    class Problem03_
    {
        static void Main(string[] args)
        {
            decimal n = Math.Abs(decimal.Parse(Console.ReadLine()));

            while ((n % 1) != 0)
            {
                n = n * 10;
            }

            ulong N = (ulong)n;
            ulong sum = 0;
            ulong add = 0;

            while (N > 9)
            {
                while ((N % 10 > 0) && (N > 10))
                {
                    add = N % 10;
                    sum = sum + add;
                    N = N / 10;            
                }
                if (N == 10)
                {
                    N = sum + 1;
                }
                else
                {
                    N = N + sum;
                }
                sum = 0;
            }

            Console.WriteLine(N);
        }
    }
}
