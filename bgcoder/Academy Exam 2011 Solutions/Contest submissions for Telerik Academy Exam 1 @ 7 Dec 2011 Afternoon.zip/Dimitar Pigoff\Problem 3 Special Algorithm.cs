using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam4
{
    class Program
    {
        static void Main()
        {
            double N = double.Parse(Console.ReadLine());

            if (N < 9)
            {
                Console.WriteLine(N);
            }
            else
            {
                for (int i = 0; i < N; i++)
                {
                    Console.WriteLine();

                }
            }
        }
    }
}