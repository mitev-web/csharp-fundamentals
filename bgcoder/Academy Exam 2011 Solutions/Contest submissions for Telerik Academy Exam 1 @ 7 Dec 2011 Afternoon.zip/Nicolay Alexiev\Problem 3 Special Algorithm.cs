using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem_3___Special_Algorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            double N = double.Parse(Console.ReadLine());
            N = Math.Abs(N);
            double sum = 0;

            do
            {
                double check = N;
                while (check != 0)
                {
                    int x = (int)(check % 10);
                    sum += x;
                    check /= 10;
                }
                N = sum;
            } while (N > 9);

            Console.WriteLine((int)N);

            
        }
    }
}
