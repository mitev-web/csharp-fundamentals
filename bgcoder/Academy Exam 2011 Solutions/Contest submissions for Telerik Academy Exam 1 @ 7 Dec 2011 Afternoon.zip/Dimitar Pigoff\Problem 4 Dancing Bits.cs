using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam40
{
    class Program
    {
        static void Main()
        {
            ushort K = ushort.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            uint newN;
            for (int i = 0; i < N; i++)
            {
                newN = N ;
                Console.WriteLine(Convert.ToString(newN, 2));
                N = ushort.Parse(Console.ReadLine());
               
            }
            
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
