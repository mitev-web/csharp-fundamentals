using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.War
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int M1x100 = Fx + D;
            int M1y100 = Fy;
            int M2x75 = Fx + D + 1;
            int M2y75 = Fy;
            int M3xLeft50 = Fx + D;
            int M3yLeft50 = Fy + 1 ;
            int M4xLeft50 = Fx + D;
            int M4yLeft50 = Fy - 1;
            int sum = 0;
            if (M1x100 >= Px1 || M1x100 <= Px2 || M1y100 >=Py1 || M1y100 <=Py2)
            {
                sum += 100;
            }
            if (M2x75 >= Px1 || M2x75 <= Px2 || M2y75 >= Py1 || M2y75 <= Py2)
            {
                sum += 75;
            }
            if (M3xLeft50 >= Px1 || M3xLeft50 <= Px2 || M3yLeft50 >= Py1 || M3yLeft50 <= Py2)
            {
                sum += 50;
            }
            if (M4xLeft50 >= Px1 || M4xLeft50 <= Px2 || M4yLeft50 >= Py1 || M4yLeft50 <= Py2)
            {
                sum += 50;
            }
            Console.WriteLine(sum);
        }
    }
}
