using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.damage
{
    class Program
    {
        static void Main(string[] args)
        {
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());

            int a = pX1 - pX2;
            int b = pY1 - pY2;
            int area = a * b;
            
            
            if (area <= Fx && area<=Fy)
            {
                Console.WriteLine("225%");
            }
            else if (area>=Fx && area>=Fy)
            {
                Console.WriteLine("100%");
            }
 
        }
    }
}