using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int a=0;
            int b=0;
            int c=0;
            int de=0;
            bool sto = false;
            bool petdeset1 = false;
            bool petdeset2 = false;
            bool sedempet = false;
            int centerx = fx + d;
            int centery = fy;
            if (((centerx >= px1 && centerx <= px2) || (centerx <= px1 && centerx >= px2)) && ((centery >= py1 && centery <= py2) || centery <= py1 && centery >= py2))
            {
                sto = true;
            }
            int upx = centerx ;
            int upy = centery + 1;
            if (((upx >= px1 && upx <= px2) || (upx <= px1 && upx >= px2)) && ((upy >= py1 && upy <= py2) || upy <= py1 && upy >= py2))
            {
                petdeset1 = true;
            }

            int downx = centerx;
            int downy = centery - 1;
            if (((downx >= px1 && downx <= px2) || (downx <= px1 && downx >= px2)) && ((downy >= py1 && downy <= py2) || downy <= py1 && downy >= py2))
            {
                petdeset2 = true;
            }

            int forwardx = centerx + 1;
            int forwardy = centery;
            if (((forwardx >= px1 && forwardx <= px2) || (forwardx <= px1 && forwardx >= px2)) && ((forwardy >= py1 && forwardy <= py2) || forwardy <= py1 && forwardy >= py2))
            {
                sedempet = true;
            }
            if (sto)
            {
                a = 100;
            }
            if (petdeset1)
            {
                b = 50;
            }
            if (petdeset2)
            {
                c = 50;
            }
            if (sedempet)
            {
                de = 75;
            }
            int damage = a + b + c + de;
            Console.WriteLine("{0}%", damage);
        }
    }
}
