using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace RealExam
{
    class RealExam
    {
        static void Main(string[] args)
        {
            SpecialAlgorithm();
        }

        static void SpecialAlgorithm()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            BigInteger intPart = 0;
            BigInteger modePart = 0;
            int sum = 0;

            string input = Console.ReadLine();

            int index = 0;
            string[] parts = new string[3];
            parts = input.Split(new char[] {'-', '.'});

            if ( parts[0].Equals("")) index = 1;

            BigInteger.TryParse(parts[index], out intPart);
            sum += DigitSum(intPart);

            if ( ((parts.Length > 2) && ( parts[0].Equals("") )) || ((parts.Length == 2) && !(parts[0].Equals(""))) )
            {
                BigInteger.TryParse(parts[index + 1], out modePart);
                sum += DigitSum(modePart);
            }

            while (sum > 9)
            {
                sum = DigitSum(sum);
            }

            Console.WriteLine(sum);
        }

        static int DigitSum(BigInteger number)
        {
            int sum = 0;

            while (number > 0)
            {
                sum += (int)(number % 10);
                number /= 10;
            }

            return sum;
        }
    }
}
