using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rectangle
{
    class War
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int px1Temp = px1;
            int py1 = int.Parse(Console.ReadLine());
            int py1Temp = py1;
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());


            if (px1 > px2)
            {
                px1 = px2;
                px2 = px1Temp;
            }

            if (py1 > py2)
            {
                py1 = py2;
                py2 = py1Temp;
            }


            if (((fy >= py1 && fy <= py2)) && ((Math.Abs(fx) - Math.Abs(px1)) <= d))
            {
                Console.WriteLine("275%");
            }
            else
            {
                Console.WriteLine("0%");
            }

        }
    }
}
