using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace War_Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            string consoleLine = Console.ReadLine();
            int PX1 = int.Parse(consoleLine);
            consoleLine = Console.ReadLine();
            int PY1 = int.Parse(consoleLine);
            consoleLine = Console.ReadLine();
            int PX2 = int.Parse(consoleLine);
            consoleLine = Console.ReadLine();
            int PY2 = int.Parse(consoleLine);
            consoleLine = Console.ReadLine();
            int FX = int.Parse(consoleLine);
            consoleLine = Console.ReadLine();
            int FY = int.Parse(consoleLine);
            consoleLine = Console.ReadLine();
            int D = int.Parse(consoleLine);
            int temp;

            if (PX1  > PX2 )
            {
                temp = PX1;
                PX1 = Math.Min(PX1, PX2);
                PX2 = temp;
            }
            if (PY1 > PY2)
            {
                temp = PY1;
                PY1 = Math.Min(PY1, PY2);
                PY2 = temp;
            }

            if (PY1 + 1 == PY2)
            {
                Console.WriteLine("175%");
            }
            if (PY1 + 1 == PY2 && (FX + D < PX1) )
            {
                Console.WriteLine("75%");
            }

            if (FY < PY1 - 1 || FY > PY2 +1 || FX + D < PX1 - 1 || FX + D > PX2 )
            {
                Console.WriteLine("0%");
            }
            else
            {
                if ((FY == PY1 - 1 || FY == PY2 +1) && (FX + D >= PX1 && FX + D <= PX2))
                {
                    Console.WriteLine("50%");
                }
                if ((FY == PY1 || FY == PY2) && (FX + D >= PX1 && FX + D <= PX2 - 1))
                {
                    Console.WriteLine("225%");
                }
                else if ((FY == PY1 || FY == PY2) &&  (FX + D == PX2))
                {
                    Console.WriteLine("50%");
                }
                else if ((FY > PY1 && FY < PY2) && (FX + D >= PX1 && FX + D <= PX2 - 1))
                {
                    Console.WriteLine("275%");
                }
                else if ((FY >= PY1 && FY <= PY2) && (FX + D == PX1 - 1))
                {
                    Console.WriteLine("75%");
                }
                else if ((FY == PY2 && (FX + D == PX2)) || (FY == PY1 && (FX + D == PX2)))
                {
                    Console.WriteLine("150%");
                }
               


            }


        }
    }
}
