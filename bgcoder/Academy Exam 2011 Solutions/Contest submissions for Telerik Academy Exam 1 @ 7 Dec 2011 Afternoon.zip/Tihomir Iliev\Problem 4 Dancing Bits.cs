using System;

namespace _4.DancingBits
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            int K = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());

            int[] numbers = new int[N];

            for (int inputing = 0; inputing < N; inputing++)
            {
                numbers[inputing] = int.Parse(Console.ReadLine());
            }
      
            int tempCounter = 0;
            int finalCounter = 0;
            int previousBit = -1;
            int currentBit = 0;

            for (int current = N - 1; current >= 0; current--)
            {
                int lengthOfcurrent = howMany(numbers[current]);               
                for (int each = 0; each < lengthOfcurrent; each++)
                {
                    currentBit = ((numbers[current] & (1 << each))) > 0? 1 : 0;
                    if (currentBit == 1)
	                {
                        if (previousBit == 0)
                        {
                            if (tempCounter == K)
                            {
                                finalCounter++;
                            }
                            tempCounter = 1;
                        }
                        else
                        {
                            tempCounter++;
                        }
	                }
                    else
                    {
                        if (previousBit == 1)
                        {
                            if (tempCounter == K)
                            {
                                finalCounter++;
                            }
                            tempCounter = 1;
                        }
                        else
                        {
                            tempCounter++;
                        }
                    }
                    previousBit = currentBit;                                                                 
                }            
            }
            if (tempCounter == K)
            {
                finalCounter++;
            }
            Console.WriteLine(finalCounter);
        }

        static int howMany(int number)
        {
            int counter = 0;
            while (number > 0)
            {
                number /= 2;
                counter++;
            }
            return counter;
        }
    }
}