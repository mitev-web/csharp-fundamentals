using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            // squares with damages
            int xa1, ya1; //100%
            int xa2, ya2; //75%
            int xa3, ya3; //50%
            int xa4, ya4; //50%
            //
            int sum ;
            int px1, py1;
            int px2, py2;
            int fx, fy;
            int d;
                    
            // input data.
            //------------------
            px1 = int.Parse(Console.ReadLine());
            py1 = int.Parse(Console.ReadLine());
            px2 = int.Parse(Console.ReadLine());
            py2 = int.Parse(Console.ReadLine());
            fx = it.Parse(Console.ReadLine());
            fy = int.Parse(Console.ReadLine());
            d = int.Parse(Console.ReadLine());
            //-------------------
             // coordinates of squares with damages
            xa1 = fx + d;
            ya1 = fy ;

            xa2 = fx + d + 1;
            ya2 = fy;
            
            xa3 = fx + d;
            ya3 = fy + 1;
            
            xa4 = fx + d;
            ya4 = fy - 1;
            //--------------------
            // testing if the four squares are in the rectangle
            //
            sum = 0;
            // a1 is in the rectangle?
            bool x1, y1;
            x1 = ((xa1 >= px1) && (xa1 <= px2));
            y1 = ((ya1 >= py1) && (ya1 <= py2));
            if ((x1) && (y1))
            {
                sum = sum +100;
            }
            // a2 is in the rectangle?
            bool x2, y2;
            x2 = ((xa2 >= px1) && (xa2 <= px2));
            y2 = ((ya2 >= py1) && (ya2 <= py2));
            if ((x2) && (y2))
            {
                sum = sum + 75;
            }
            // a3 is in the rectangle?
            bool x3, y3;
            x3 = ((xa3 >= px1) && (xa3 <= px2));
            y3 = ((ya3 >= py1) && (ya3 <= py2));
            if ((x3) && (y3))
                      
            {
                sum = sum + 50;
            }
            // a4 is in the rectangle?
            bool x4, y4;
            x4 = ((xa4 >= px1) && (xa4 <= px2));
            y4 = ((ya4 >= py1) && (ya4 <= py2));
            if ((x4) && (y4))
                         
            {
                sum = sum + 50;
            }
            //
            // print the result
            //

            Console.WriteLine ("The sum of the damages is {0}", sum);


        }


    }
}
