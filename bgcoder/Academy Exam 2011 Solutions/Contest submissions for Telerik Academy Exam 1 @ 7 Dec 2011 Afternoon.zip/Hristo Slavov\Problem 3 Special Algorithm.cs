using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            decimal N = decimal.Parse(Console.ReadLine());
            decimal acc;
            int sum;
            do
            {
                acc = 0;
                while (N > 0)
                {
                    
                    acc += N % 10;
                    N /= 10;
                }
                
                while (N < 0)
                {
                   
                    acc += -N % 10;
                    acc += -N % 10;
                    N = -N / 10;
                }
                N = acc;
                
            } while (acc >= 9);
            sum = (int)acc;
            Console.WriteLine(sum);
        }
    }
}
