using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine());
            int k =0;
            int counter = 0;
            string digit = "";
            for (int i = 0; i < n; i++)
            {
                k = Int32.Parse(Console.ReadLine());
                digit += Convert.ToString(k, 2); 
            }
            if (digit.IndexOf("000") > -1)
            {
                counter++;
            }
            if (digit.IndexOf("111") > -1)
            {
                counter++;
            }
            if (digit.IndexOf("101") > -1)
            {
                counter++;
            }
            Console.WriteLine(counter);
           
        }
    }
}
