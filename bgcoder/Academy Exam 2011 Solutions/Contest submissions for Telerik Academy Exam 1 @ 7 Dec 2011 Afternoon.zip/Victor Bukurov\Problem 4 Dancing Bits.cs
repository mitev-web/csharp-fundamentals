using System;
using System.Numerics;

namespace dancingZeroes
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort K = UInt16.Parse(Console.ReadLine()); // 1 to 25 600
            ushort N = UInt16.Parse(Console.ReadLine()); // 1 to 800
            int inputNumber;
            BigInteger numberBits;
            BigInteger allBits = 0;
            BigInteger power;
            for (int i = 0; i < N; i++)
            {
                numberBits = 0;
                power = 1;
                inputNumber = Int32.Parse(Console.ReadLine());
                while (inputNumber > 0)
                {
                    numberBits = numberBits + (inputNumber % 2) * power;
                    inputNumber /= 2;
                    power *= 10;
                }
                allBits = allBits * power + numberBits;
            }

            uint output = 0;

            string allBitsString = allBits.ToString();
            string dancingZeroes = new string('0',K);
            int startIndex = 0;
            int index;
            do
            {
                index = allBitsString.IndexOf(dancingZeroes, startIndex);
                if (index == -1)
                {
                    break;
                }
                else
                {
                    if ((index + K) < (allBitsString.Length) && allBitsString[index + K] == '1')
                    {
                        output++;
                        startIndex = index + K;
                    }
                    else if (index + K == allBitsString.Length)
                    {
                        output++;
                        break;
                    }
                    else
                    {
                        startIndex = allBitsString.IndexOf('1', index);
                        if (startIndex == -1)
                        {
                            break;
                        }
                    }
                }
            } while (true);



            string dancingOnes= new string('1', K);
            startIndex = 0;

            do
            {
                index = allBitsString.IndexOf(dancingOnes, startIndex);
                if (index == -1)
                {
                    break;
                }
                else
                {
                    if ((index + K) < (allBitsString.Length) && allBitsString[index + K] == '0')
                    {
                        output++;
                        startIndex = index + K;
                    }
                    else if (index + K == allBitsString.Length)
                    {
                        output++;
                        break;
                    }
                    else
                    {
                        startIndex = allBitsString.IndexOf('0', index);
                        if (startIndex == -1)
                        {
                            break;
                        }
                    }
                }
            } while (true);


            Console.WriteLine(output);
        }
    }
}
