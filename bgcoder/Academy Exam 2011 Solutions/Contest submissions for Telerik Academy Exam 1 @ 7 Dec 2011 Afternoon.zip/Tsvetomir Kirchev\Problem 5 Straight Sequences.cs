using System;

namespace StraightSequences
{
    class StraightSequences
    {
        static void Main(string[] args)
        {
            byte[] bytes = new byte[8];
            for (int i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Byte.Parse(Console.ReadLine());
            }

            byte[,] matrix = FillMatrix(bytes);
            //PrintMatrix(matrix);
            //Console.WriteLine();
            FindSequences(matrix);
        }

        static void FindSequences(byte[,] matrix)
        {
            int length = 1;
            int biggerSequence = 0;
            int counter = 1;
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    if (matrix[row, col] == 1 && matrix[row, col + 1] == 1)
                    {
                        length++;
                    }
                    else
                    {
                        length = 1;
                    }
                    if (length > biggerSequence)
                    {
                        biggerSequence = length;
                        counter = 1;
                    }
                    else if(biggerSequence == length)
                    {
                        counter++;
                    }
                }
                length = 1;
            }

            for (int col = 0; col < 8; col++)
            {
                for (int row = 0; row < 7; row++)
                {
                    if ((matrix[row, col] == 1) && (matrix[row + 1, col] == 1))
                    {
                        length++;
                    }
                    else
                    {
                        length = 1;
                    }
                    if(length > biggerSequence)
                    {
                        biggerSequence = length;
                        counter = 1;
                    }
                    else if(biggerSequence == length)
                    {
                        counter++;
                    }
                }
                length = 1;
            }
            if (biggerSequence == 1)
            {
                counter = 0;
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        if (matrix[row, col] == 1)
                        {
                            counter++;
                        }
                    }
                }
            }
            Console.WriteLine(biggerSequence);
            Console.WriteLine(counter);
        }

        static byte[,] FillMatrix(byte[] bytes)
        {
            byte[,] matrix = new byte[8, 8];
            int mask = 1;
            int result = 0;
            for (int row = 0; row < 8; row++)
            {
                for (int col = 7; col >= 0; col--)
                {
                    result = bytes[row] & mask;
                    if (result != 0)
                    {
                        matrix[row, col] = 1;
                    }
                    mask = mask << 1;
                }
                mask = 1;
            }

            return matrix;
        }

        static void PrintMatrix(byte[,] matrix)
        {
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    Console.Write(matrix[row, col]);
                }
                Console.WriteLine();
            }
        }
    }
}
