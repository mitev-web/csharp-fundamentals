using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EXAM
{
    class Task01
    {
        static void Main(string[] args)
        {
            byte mapWidth = byte.Parse(Console.ReadLine());
            for (int i = 0; i < (mapWidth+1)/2 ; i++)
            {
                Console.Write("*".PadLeft((i+1),'.'));
                for (int j = i+1; j<(mapWidth-i); j++)
                {
                    Console.Write("*");
                }
                if (i != 0 && i!=(mapWidth+1)/2)
                {
                    int p = 0;
                    while (p != i)
                    {
                        Console.Write(".");
                        p++;
                    }
                }
                Console.WriteLine();
            }

            //2 for
            for (int i = (mapWidth -1)/2; i >= 1 ; i--)
            {
                
                    Console.Write("*".PadLeft((i), '.'));
                
                for (int j = i; j <= (mapWidth-i); j++)
                {
                    Console.Write("*");
                }
                if (i != 0 && i != (mapWidth + 1) / 2)
                {
                    int p = 0;
                    while (p != (i-1))
                    {
                        Console.Write(".");
                        p++;
                    }
                }
                Console.WriteLine();
            }

            }
        }
    }
