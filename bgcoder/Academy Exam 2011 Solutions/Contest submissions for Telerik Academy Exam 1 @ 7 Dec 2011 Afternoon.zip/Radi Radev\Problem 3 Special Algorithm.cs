using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace task_3
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double n1 = (double.Parse(Console.ReadLine()));
            double n = Math.Abs(n1);
            begin:;
            BigInteger na = (BigInteger)(n);
            BigInteger a = 0;
            BigInteger b = na % 10;
            
            
            //double a = 1234;
            //Console.WriteLine((a%10000-a%1000)/1000);
            
            
            for (int i = 2; i <= 304; i++)
            {

                a = ((((BigInteger)na % (BigInteger)Math.Pow(10, i)) - (na % (BigInteger)Math.Pow(10, i - 1))) / (BigInteger)Math.Pow(10, i - 1));
                b = b + a;
            }

            //Console.WriteLine(b);
            double ny = (((double)n - (double)na));
            string z = Convert.ToString(ny);
            BigInteger c = 0;
            if (ny != 0)
            {
                //Console.WriteLine(z);
                z = z.Remove(0, 2);
                //Console.WriteLine(z);
                BigInteger nx = BigInteger.Parse(z);
                BigInteger d = 0;
               c = nx % 10;
                for (int i = 2; i <= 304; i++)
                {

                    d = (BigInteger)((nx % ((BigInteger)Math.Pow(10, i)) - nx % ((BigInteger)Math.Pow(10, i - 1))) / (BigInteger)Math.Pow(10, i - 1));
                    c = c + d;
                }
            }
            
            //Console.WriteLine(c);            
            n = (int)(b + c);
            if (n>9)
            {   
            goto begin; 
            }
            Console.WriteLine((n));
            
        }
    }
}
