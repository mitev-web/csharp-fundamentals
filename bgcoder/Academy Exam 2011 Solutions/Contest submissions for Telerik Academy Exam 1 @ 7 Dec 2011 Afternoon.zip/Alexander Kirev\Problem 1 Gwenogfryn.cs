using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int half = n / 2;
            int count = 0;
            for (int i = 0; i < n ; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            for (int i = 0; i < half; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if ((j > i) && (j < n - i - 1))
                    {
                        Console.Write("*");
                        continue;
                    }
                    Console.Write(".");
                }
                count++;
                Console.WriteLine();
            }
            for (int i = 0; i < half -1 ; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (j < count-1)
                    {
                        Console.Write(".");
                        continue;
                    }
                    if (j>i+half+1 )
                    {
                        Console.Write(".");
                        continue;
                    }

                    Console.Write("*");
                }
                count--;
                Console.WriteLine();
            }
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }
}
