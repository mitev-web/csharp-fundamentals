using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());

            int fighterX = int.Parse(Console.ReadLine());
            int fighterY = int.Parse(Console.ReadLine());

            int bomb = int.Parse(Console.ReadLine());

            int bombFly100X = fighterX + bomb;
            int bombFly100Y = fighterY;

            int bombFly75X = (fighterX + bomb)+1;
            int bombFly75Y = fighterY;

            int bombFly50X1 = bombFly100X;
            int bombFly50Y1 = fighterY + 1;

            int bombFly50X2 = bombFly100X;
            int bombFly50Y2 = fighterY - 1;

            int damage100 = 0;
            int damage75 = 0;
            int damage50 = 0;
            int damage50Second = 0;
            int result = 0;

            if ((bombFly100X >= x1 && bombFly100X <= x2) && (bombFly100Y >= y1 && bombFly100Y <= y2))
            {
                damage100 = 100;
            }
            if ((bombFly75X >= x1) && (bombFly75X <= x2) && (bombFly75Y >= y1) && (bombFly75Y <= y2))
            {
                damage75 = 75;
            }
            if ((bombFly50X1 >= x1 && bombFly50X1 <= x2) && (bombFly50Y1 >= y1 && bombFly50Y1 <= y2))
            {
                damage50 = 50;
            }
            if ((bombFly50X2 >= x1 && bombFly50X2 <= x2) && (bombFly50Y2 >= y1 && bombFly50Y2 <= y2))
            {
                damage50Second = 50;
            }


            result = damage100 + damage75 + damage50 + damage50Second;
            Console.WriteLine("{0}%",result);
        }
    }
}
