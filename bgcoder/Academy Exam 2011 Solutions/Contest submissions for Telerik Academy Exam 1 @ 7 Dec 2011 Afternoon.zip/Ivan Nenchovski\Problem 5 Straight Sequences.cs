using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// my heavy artillery :)
namespace ExamUtils
{
    public sealed class BitwiseOps
    {
        private static int GetOutputArrayLength(int inputArrayLength, int dataTypeSizeBytes, DigitGroupingStyles style)
        {
            int NumBits = inputArrayLength * dataTypeSizeBytes * 8;
            int NumberGroups = 0;
            int NibbleGroups = 0;
            if (style == DigitGroupingStyles.GROUP_NUMBERS || style == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS)
            {
                NumberGroups = inputArrayLength - 1;
            }
            if (style == DigitGroupingStyles.GROUP_NIBBLES || style == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS)
            {
                NibbleGroups = inputArrayLength * dataTypeSizeBytes * 2 - 1;
            }
            return NumBits + NibbleGroups + NumberGroups;
        }

        public enum DigitGroupingStyles { NO_GROUPING, GROUP_NIBBLES, GROUP_NUMBERS, GROUP_NIBBLES_NUMBERS };

        // Generics/templates don't work with bitwise ops; lots of copypasta ensues
        public static string PrintBits(byte[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(byte) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(byte), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    int GetBitAtPos = 1 << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(sbyte[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(sbyte) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(sbyte), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    int GetBitAtPos = 1 << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(short[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(short) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(short), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    int GetBitAtPos = 1 << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(ushort[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(ushort) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(ushort), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    int GetBitAtPos = 1 << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(int[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(int) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(int), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    int GetBitAtPos = 1 << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(uint[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(uint) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(uint), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    int GetBitAtPos = 1 << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(long[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(long) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(long), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    long GetBitAtPos = 1u << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static string PrintBits(ulong[] inputArray, DigitGroupingStyles groupDigitsStyle)
        {
            int TypeSizeInBits = sizeof(ulong) * 8;
            int OutputArrayLength = GetOutputArrayLength(inputArray.Length, sizeof(ulong), groupDigitsStyle);
            char[] Output = new char[OutputArrayLength];
            int OutputArrayIndex = 0;
            bool GroupNibbles = groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            bool GroupNumbers = groupDigitsStyle == DigitGroupingStyles.GROUP_NUMBERS || groupDigitsStyle == DigitGroupingStyles.GROUP_NIBBLES_NUMBERS;
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int j = TypeSizeInBits - 1; j >= 0; j--)
                {
                    if (OutputArrayIndex != 0)
                    {
                        if (GroupNibbles && (j + 1) % 4 == 0)
                        {
                            Output[OutputArrayIndex] = ' ';
                            OutputArrayIndex++;
                        }
                    }
                    ulong GetBitAtPos = 1u << j;
                    if ((inputArray[i] & GetBitAtPos) != 0)
                    {
                        Output[OutputArrayIndex] = '1';
                    }
                    else
                    {
                        Output[OutputArrayIndex] = '0';
                    }
                    OutputArrayIndex++;
                }
                if (GroupNumbers && (i + 1) != inputArray.Length)
                {
                    Output[OutputArrayIndex] = ' ';
                    OutputArrayIndex++;
                }
            }
            return new string(Output);
        }

        public static void RotateLeft(byte[] inputArray, int nRotations)
        {
            int minRotations = (nRotations % (inputArray.Length * sizeof(byte) * 8));
            int minElemRotations = minRotations / (sizeof(byte) * 8);
            for (int i = 0; i < minElemRotations; i++)
            {
                byte tmp = inputArray[0];
                for (int j = 0; j < inputArray.Length - 1; j++)
                {
                    inputArray[j] = inputArray[j + 1];
                }
                inputArray[inputArray.Length - 1] = tmp;
            }
            int minBitRotations = minRotations - (minElemRotations * sizeof(byte) * 8);
            for (int i = 0; i < minBitRotations; i++)
            {

            }
        }
    }

    public sealed class ParsingUtils
    {

    }

    namespace Combinatorics
    {

    }

    namespace Sorting
    {

    }

    namespace Graphs
    {

    }
}


namespace _5_Straight_Sequences
{
    class Program
    {
            public static bool GetBitAt(byte[] input, int y, int x)
            {
                return ((input[y] & (1 << (7 - x))) != 0);
            }

            public static byte[] GetTransposedGrid(byte[] input)
            {
                byte[] transposedInput = new byte[input.Length];
                for (int y = 0; y < input.Length; y++)
                {
                    for (int x = 0; x < sizeof(byte) * 8; x++)
                    {
                        transposedInput[x] |= (byte)(input[y] & (1 << x));
                    }
                }
                return transposedInput;
            }

            public static int GetLongestRaisedBitsLineLength(int input)
            {
                int result = 0;
                int currentLine = 0;
                for (int i = 0; i <= sizeof(byte) * 8; i++)
                {
                    if ((input & (1 << i)) != 0)
                    {
                        currentLine++;
                    }
                    else
                    {
                        result = Math.Max(result, currentLine);
                        currentLine = 0;
                    }
                }
                return result;
            }

            public static char[,] ConvertToCharMatrix(byte[] input)
            {
                char[,] normalizedInput = new char[8, 8];
                string inputToBitsString = ExamUtils.BitwiseOps.PrintBits(input, ExamUtils.BitwiseOps.DigitGroupingStyles.NO_GROUPING);
                for (int y = 0; y < 8; y++)
                {
                    for (int x = 0; x < 8; x++)
                    {
                        normalizedInput[y, x] = inputToBitsString.ElementAt(y * sizeof(byte) * 8 + x);
                    }
                }
                return normalizedInput;
            }

            public static void PrintMatrix(char[,] matrix)
            {
                for (int y = 0; y < 8; y++)
                {
                    for (int x = 0; x < 8; x++)
                    {
                        Console.Write(matrix[y, x]);
                    }
                    Console.WriteLine();
                }
                //Console.WriteLine();
                //for (int x = 0; x < 8; x++)
                //{
                //    for (int y = 0; y < 8; y++)
                //    {
                //        Console.Write(matrix[y, x]);
                //    }
                //    Console.WriteLine();
                //}
            }

        public static byte[] ReadInput()
            {
                byte[] result = new byte[8];
                for (int i = 0; i < 8; i++)
                {
                    result[i] = Convert.ToByte(Console.ReadLine());
                }
                return result;
            }

            static void Main(string[] args)
            {
                byte[] input = ReadInput();
                char[,] inputMatrix = ConvertToCharMatrix(input);
                int longestSequenceCandidate1;
                int longestSequenceCandidate1Count;
                GetLongestLine(inputMatrix, out longestSequenceCandidate1, out longestSequenceCandidate1Count);
                int longestSequenceCandidate2;
                int longestSequenceCandidate2Count;
                GetLongestColumn(inputMatrix, out longestSequenceCandidate2, out longestSequenceCandidate2Count);
                if (longestSequenceCandidate1 == longestSequenceCandidate2)
                {
                    Console.WriteLine(longestSequenceCandidate1);
                    Console.WriteLine(longestSequenceCandidate1Count + longestSequenceCandidate2Count);
                }
                else
                {
                    if (longestSequenceCandidate1 > longestSequenceCandidate2)
                    {
                        Console.WriteLine("{0}\n{1}", longestSequenceCandidate1, longestSequenceCandidate1Count);
                    }
                    else
                    {
                        Console.WriteLine("{0}\n{1}", longestSequenceCandidate2, longestSequenceCandidate2Count);
                    }
                    //Console.WriteLine(Math.Max(longestSequenceCandidate1, longestSequenceCandidate2));
                    //Console.WriteLine(Math.Max(longestSequenceCandidate1Count, longestSequenceCandidate2Count));
                }
            }

            public static void GetLongestLine(char[,] inputMatrix, out int lineSize, out int lineOccurrences)
            {
                int longestRaisedBitsLine = 0;
                int longestRaisedBitsLineOccurrences = 0;
                for (int y = 0; y < 8; y++)
                {
                    int currentRaisedBitsLine = 0;
                    for (int x = 0; x < 8; x++)
                    {
                        if (inputMatrix[y, x] == '1')
                        {
                            currentRaisedBitsLine++;
                            if (currentRaisedBitsLine > longestRaisedBitsLine)
                            {
                                longestRaisedBitsLine = currentRaisedBitsLine;
                                longestRaisedBitsLineOccurrences = 1;
                            }
                            else if (longestRaisedBitsLine != 0 && currentRaisedBitsLine == longestRaisedBitsLine)
                            {
                                longestRaisedBitsLineOccurrences++;
                            }
                        }
                        else
                        {
                            //if (currentRaisedBitsLine > longestRaisedBitsLine)
                            //{
                            //    longestRaisedBitsLine = currentRaisedBitsLine;
                            //    longestRaisedBitsLineOccurrences = 1;
                            //}
                            //else if (longestRaisedBitsLine != 0 && currentRaisedBitsLine == longestRaisedBitsLine)
                            //{
                            //    longestRaisedBitsLineOccurrences++;
                            //}
                            currentRaisedBitsLine = 0;
                        }
                    }
                }
                lineSize = longestRaisedBitsLine;
                lineOccurrences = longestRaisedBitsLineOccurrences;
            }

            public static void GetLongestColumn(char[,] inputMatrix, out int columnSize, out int columnOccurrences)
            {
                int longestRaisedBitsColumn = 0;
                int longestRaisedBitsColumnOccurrences = 0;
                for (int x = 0; x < 8; x++)
                {
                    int currentRaisedBitsColumn = 0;
                    for (int y = 0; y < 8; y++)
                    {
                        if (inputMatrix[y, x] == '1')
                        {
                            currentRaisedBitsColumn++;
                            if (currentRaisedBitsColumn > longestRaisedBitsColumn)
                            {
                                longestRaisedBitsColumn = currentRaisedBitsColumn;
                                longestRaisedBitsColumnOccurrences = 1;
                            }
                            else if (longestRaisedBitsColumn != 0 && currentRaisedBitsColumn == longestRaisedBitsColumn)
                            {
                                longestRaisedBitsColumnOccurrences++;
                            }
                        }
                        else
                        {
                            //if (currentRaisedBitsColumn > longestRaisedBitsColumn)
                            //{
                            //    longestRaisedBitsColumn = currentRaisedBitsColumn;
                            //    longestRaisedBitsColumnOccurrences = 1;
                            //}
                            //else if (longestRaisedBitsColumn != 0 && currentRaisedBitsColumn == longestRaisedBitsColumn)
                            //{
                            //    longestRaisedBitsColumnOccurrences++;
                            //}
                            currentRaisedBitsColumn = 0;
                        }
                    }
                }
                columnSize = longestRaisedBitsColumn;
                columnOccurrences = longestRaisedBitsColumnOccurrences;
            }
        }
}
