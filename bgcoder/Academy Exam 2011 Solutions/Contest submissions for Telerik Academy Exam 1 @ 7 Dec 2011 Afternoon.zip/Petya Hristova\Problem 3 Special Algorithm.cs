using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Problem_3___Special_Algorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal number = decimal.Parse(Console.ReadLine());
            long sum = 0;
            long newSum = 0;
            long sumNew = 0;
            decimal newNum = 0;

            for (int i = 0; i < decimal.MaxValue; i++)
            {
                newNum = number * 10;
                number = newNum;
                if (number - (long)number == 0)
                {
                    break;
                }
            }
            long intValue = (long)Math.Abs(newNum);
            long newValue = intValue;
            for (int i = 0; i < 100000; i++)
            {
                sum += intValue % 10;
                newValue = intValue / 10;
                intValue = newValue;
                if (intValue == 0)
                {
                    break;
                }
            }
            if (sum > 9)
            {
                for (int i = 0; i <1000000; i++)
                {
                    newSum += sum % 10;
                    sumNew = sum / 10;
                    sum = sumNew;
                    if (sum == 0)
                    {
                        break;
                    }
                }
                Console.WriteLine(newSum);
            }
            else
            {
                Console.WriteLine(sum);
            }
            
        }
    }
}
