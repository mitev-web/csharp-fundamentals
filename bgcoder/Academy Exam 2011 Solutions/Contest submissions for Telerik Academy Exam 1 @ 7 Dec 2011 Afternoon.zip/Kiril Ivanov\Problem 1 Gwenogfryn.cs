using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Grenogfryn
{
    class Program
    {
        static void Main()
        {
            char ch = '*';
            string num =Console.ReadLine();
            int  n = int.Parse(num);
            int a = n;
            for (int row = n; row >= 1;row=row-2)
            {
                Console.Write(new String('.', n-a));
                for (int column = row; column >= 1; column--)
                {
                    Console.Write("{0}", ch);
                }
                Console.Write(new String('.', n - a));
                Console.WriteLine();
                a--;
            }
            for (int row = 3; row <= n; row = row + 2)
            {
                Console.Write(new String('.', ((n - row) / 2)));
                for (int column = 1; column <= row; column++)
                {
                    Console.Write("{0}", ch);
                }
                Console.Write(new String('.', ((n - row) / 2)));
                Console.WriteLine();
            }
        }
    }
}
