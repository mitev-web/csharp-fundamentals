using System;

namespace War
{
    class War
    {
        static void Main(string[] args)
        {
            int pX1 = Int32.Parse(Console.ReadLine());
            int pY1 = Int32.Parse(Console.ReadLine());
            int pX2 = Int32.Parse(Console.ReadLine());
            int pY2 = Int32.Parse(Console.ReadLine());

            int fX = Int32.Parse(Console.ReadLine());
            int fY = Int32.Parse(Console.ReadLine());

            int d = Int32.Parse(Console.ReadLine());

            if((fX + d) == pX2 && fY == pY1)
            {
                Console.WriteLine("150%");
            }
            else if ((((fX + d) >= pX1) && ((fX + d) < pX2)) &&
                ((fY < pY1) && (fY >= pY2)))
            {
                Console.WriteLine("225%");
            }
            else if((((fX + d) >= pX1) && ((fX + d) == pX2)) &&
                ((fY < pY1) && (fY >= pY2)))
            {
                Console.WriteLine("175%");
            }
            else if ((fX + d) == (pX1 - 1))
            {
                Console.WriteLine("75%");
            }
            else if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) &&
                (fY == (pY2 - 1)))
            {
                Console.WriteLine("75%");// changed to 75% from 50%
            }
            else if((fX + d) == pX2 && (fY == pY2))
            {
                Console.WriteLine("100%");
            }
            else if((fX == pX2) && (fY == pY1))
            {
                Console.WriteLine("175%");
            }
            else if((fX + d) == pX2 + 1 && ((fY <= pY1) && (fY) >= pY2))
            {
                Console.WriteLine("75%");
            }
            else
            {
                Console.WriteLine("0%");
            }
        }
    }
}