using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Task1
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int asterix = n - 2;
            int dots = 1;
            int counter = n / 2;
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            for (int i = 0; i < counter; i++)
            {
                for (int j = 0; j < n; j++)
                {
                 
                    if (j < dots )
                    {
                        Console.Write(".");
                    }
                    else if (j < n - dots)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                    
                }
                Console.WriteLine();
                dots++;
            }
            dots -=2;
            for (int i = 0; i < counter; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    
                    if (j < dots)
                    {
                        Console.Write(".");
                    }
                    else if (j < n - dots)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
                dots--;
            }
        }
    }
}
