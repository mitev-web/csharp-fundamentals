using System;

namespace Task1_Gwenogfryn
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int counter = n;
            for (int i = 0; i < n / 2 + 1; i++)
            {
                for (int j = 0; j < (n - counter) / 2; j++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < counter; j++)
                {
                    Console.Write("*");
                }
                for (int j = 0; j < (n - counter) / 2; j++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
                counter = counter - 2;
            }
            counter = 3;
            for (int i = 0; i < n / 2; i++)
            {
                for (int j = 0; j < (n - counter) / 2; j++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < counter; j++)
                {
                    Console.Write("*");
                }
                for (int j = 0; j < (n - counter) / 2; j++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
                counter = counter + 2;
            }
        }
    }
}
