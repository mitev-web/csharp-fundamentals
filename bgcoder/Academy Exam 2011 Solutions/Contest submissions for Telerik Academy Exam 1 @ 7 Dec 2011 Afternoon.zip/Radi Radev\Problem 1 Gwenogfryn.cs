using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {

            bool iseven = false;
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                if (n % 2 == 0)
                {
                    iseven = true;
                }
                else
                {
                    iseven = false;
                }
                for (int k = 0; k < i; k++)
                {
                    if ((i >= n / 2 + 1 && iseven == false) || (i >= n / 2 && iseven == true))
                    {                        
                        break;
                    }
                    Console.Write(".");
                }
                for (int k = 0; k < n-2*i; k++)
                {
                    Console.Write("*");
                }
                for (int k = 0; k < i; k++)
                {
                    
                    if ((i >= n / 2 + 1 && iseven == false) || (i >= n / 2 && iseven == true))
                    {                        
                        break;
                    }
                    Console.Write(".");
                }
                if ((i >= n / 2 + 1 && iseven == false) || (i >= n / 2 && iseven == true))
                {

                    for (int k = 1; k < (n-i); k++)
                    {
                        Console.Write(".");
                    }
                }
                
                if ((i >= n / 2 + 1 && iseven == false) || (i >= n / 2 && iseven == true))
                {
                    for (int k = -1; k < 2 * i-n+1; k++)
                    {
                        Console.Write("*");
                    }
                }
                if ((i >= n / 2 + 1 && iseven == false) || (i >= n / 2 && iseven == true))
                {

                    for (int k = 1; k < (n - i); k++)
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine("");
                }
        }
    }
}
