using System;

namespace Problem1_Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            short n = short.Parse(Console.ReadLine());
            int go = n;

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    if (i == 1 || i == n)
                    {
                        Console.Write("*");
                    }
                    else if (i == (n + 1) / 2 && j == (n + 1) / 2)
                    {
                        Console.Write("*");
                    }
                    //else if ((i != 1 || i != n || i != ((n + 1) / 2) ) && (j == 1 || j == n))
                    //{
                    //    Console.Write(".");
                    //}
                    else
                    {
                        Console.Write(".");
                    }
                    
                }
                Console.WriteLine();
                go--;
 
            }
        }
    }
}
