using System;

namespace Gwenogfryn
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            string input;
            byte n;
            input = Console.ReadLine();
            byte.TryParse(input, out n);

            int leftPosition = 0;
            int rightPosition = (n + 1);

            for (int row = 1; row <= n; row++)
            {
                string printData = "";

                for (int col = 1; col <= n; col++)
                {
                    if ((row == 1) || (row == n))
                    {
                        printData = printData + "*";
                    }
                    else if ((col <= leftPosition) || (col >= rightPosition))
                    {
                        printData = printData + ".";
                    }
                    else
                    {
                        printData = printData + "*";
                    }
                }
                if (row < (n / 2) + 1)
                {
                    leftPosition++;
                    rightPosition--;
                }
                else
                {
                    leftPosition--;
                    rightPosition++;
                }
                Console.WriteLine(printData);
            }
        }
    }
}