using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlassProject
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());

            for (int col = 1; col <= n; col++)
            {
                Console.Write("*");
                
            }
            Console.WriteLine();

            for (int row = 1; row <= n-2; row++)
            {
                for (int col = 1; col <= n; col++)
                {
                    if (row <= (n-2) / 2 + 1)
                    {
                        if ((row >= col) || (row + col >= n + 1))
                        {
                            Console.Write(".");
                            if (col == n)
                            {
                                Console.WriteLine();
                            }
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                    else
                    {
                        if ((row < col - 1) || (row + col) <= (n-1))
                        {
                            Console.Write(".");
                            if (col == n)
                            {
                                Console.WriteLine();
                            }
                            
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                }      
            }

            for (int col = 1; col <= n; col++)
            {
                Console.Write("*");
                
            }
            Console.WriteLine();
        }
    }
}
