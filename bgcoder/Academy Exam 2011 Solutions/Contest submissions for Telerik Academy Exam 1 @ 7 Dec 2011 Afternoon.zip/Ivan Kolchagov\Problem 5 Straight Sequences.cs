using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace T05.StraightSeq
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] horizData = { 8,72,8,8,16,28,240,0};
            byte[] vertData = { 0, 0, 0, 0, 0, 0, 0, 0 };
            for (int i = 0; i < horizData.Length; i++)
            {
                horizData[i] = byte.Parse(Console.ReadLine());
            }

            byte data = 28;
            byte maxLine = 0, lineCount = 0;
            for (int y = 0; y < 8; y++)
            {
                data = horizData[y];
                for (int x = 0; x < 8; x++)
                {
                    byte mask = 0;
                    if ((data & 1) == 1)
                    {
                        mask = 1;
                        mask <<= y;
                        vertData[x] |= mask;
                    }
                    data >>= 1;
                }
            }
            for (int x = 0; x < 16; x++)
            {
                if (x < horizData.Length)
                {
                    data = horizData[x];
                }
                else
                {
                    data = vertData[x - 8];
                }
                byte bitCount = 0;
                for (int i = 0; i < 8; i++)
                {
                    if ((data & 1) == 1)
                    {
                        bitCount++;
                        if (bitCount > maxLine)
                        {
                            maxLine = bitCount;
                            lineCount = 1;
                        }
                        else if (bitCount == maxLine)
                        {
                            lineCount++;
                        }
                    }
                    else bitCount = 0;
                    data >>= 1;
                }
            }
            Console.WriteLine("{0}\n{1}", maxLine, lineCount);
        }
    }
}
