using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int temp;
            int fireball = fx + d;
            int demage=0;
            if (px1 > px2)
            {
                temp = px1;
                px1 = px2;
                px2 = temp;
                if (py2 > py1)
                {
                    temp = py1;
                    py1 = py2;
                    py2 = temp;
                }
            }
            else
            {
                if (py2 > py1)
                {
                    temp = py1;
                    py1 = py2;
                    py2 = temp;
                }
            }
            if (fireball >= px1 && fireball <= px2 && fy <= py1 && fy >= py2)
            {
                demage += 100;
            }
            if (fireball + 1 >= px1 && fireball + 1 <= px2 && fy <= py1 && fy >= py2)
            {
                demage += 75;
            }
            if (fireball >= px1 && fireball <= px2 && (fy - 1 <= py1 && fy - 1 >= py2) || (fy + 1 <= py1 && fy + 1 >= py2))
            {
                demage += 50;
            }
            Console.WriteLine(demage + "%");
        }
    }
}