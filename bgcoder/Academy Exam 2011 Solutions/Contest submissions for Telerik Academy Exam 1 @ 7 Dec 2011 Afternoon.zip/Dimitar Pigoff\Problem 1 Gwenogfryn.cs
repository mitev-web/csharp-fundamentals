using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            for (int row = 0; row < n; row++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            Console.Write(".");
            for (int row = 0; row < n-2; row++)
            {
                Console.Write("*");
            }
            Console.Write(".");
            Console.WriteLine();
            
        }



    }
}