using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskFour
{
    class Program
    {
        static void Main(string[] args)
        {
            uint k = uint.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());
            uint[] arr = new uint[n];
            uint all=0;
            uint number;
            uint reversedN=0;
            uint mask=1;
            uint num;
            int counter=0;
            int countZero=0;
            int countOne=0;
            bool flagZero=false;
            bool flagOne=false;
            uint temp;
            for (int i = 0; i < n; i++)
            {
                number = uint.Parse(Console.ReadLine());
                num=number;
                if (i == 0)
                {
                    all = number;
                }
                else
                {
                    while (num != 0)
                    {
                        num >>= 1;
                        counter++;
                    }
                    all <<=counter;
                    all |= number;
                }
                counter = 0;
            }
            counter = 0;
            while (all != 0)
            {
                if ((all & mask) == 0)
                {
                    if(flagOne)
                    {
                        countZero=0;
                        flagOne=false;
                    }
                    
                    countZero++;
                    flagZero = true;
                }
                else
                {
                    if (flagZero)
                    {
                        countOne= 0;
                        flagZero = false;
                       
                    }
                    countOne++;
                    flagOne = true;
                }
                
                if (countZero  == k)
                {
                    temp = all;
                    temp >>= 1;
                    if ((temp & mask) != 0)
                    {
                        counter++;
                    }
                }
                if (countOne == k)
                {
                    temp = all;
                    temp >>= 1;
                    if ((temp & mask) == 0)
                    {
                        counter++;
                    }
                }

                
                all >>= 1;
            }
            Console.WriteLine(counter);
        }
    }
}