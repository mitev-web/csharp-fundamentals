using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            int pX1 = int.Parse(Console.ReadLine());//plant postion
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
 
            int fX = int.Parse(Console.ReadLine());//plane position
            int fY = int.Parse(Console.ReadLine());
 
            int distance = int.Parse(Console.ReadLine());
 
            if ((-fX + pX1 < distance - 1) &&
                (fY > pY1) ||
                fY < pY1 - 3)
            {
                Console.WriteLine("0%");
            }
            if ((fY == pY1-1) &&
                (distance >= -fX + pX1) &&
                (distance  < -fX + pX2))
            {
                Console.WriteLine("275%");
            }
            if ((-fX + pX1 - distance == 1) &&
                (fY == pY1 || fY == pY1 - 1 || fY == pY1 + 2))
            {
                Console.WriteLine("75%");
            }
            if ((fY==pY2)&&((distance>=-fX+pX1)&&(distance<-fX+pX2)))
            {
                Console.WriteLine("225%");
            }
            if ((fY==pY1)&&((distance>=-fX+pX1)&&(distance<-fX+pX2)))
            {
                Console.WriteLine("225%");
            }
            if ((fY+1==pY2)&&((distance>=-fX+pX1)&&(distance<-fX+pX2)))
            {
                Console.WriteLine("50%");
            }
            if ((fY + 1 == pY1) && ((distance >= -fX + pX1) && (distance < -fX + pX2)))
            {
                Console.WriteLine("50%");
            }
        }
    }
}