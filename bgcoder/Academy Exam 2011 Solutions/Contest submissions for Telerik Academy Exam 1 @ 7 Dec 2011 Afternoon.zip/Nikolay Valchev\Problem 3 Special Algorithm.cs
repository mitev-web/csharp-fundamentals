using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            double n = double.Parse(str);
            long result = 0;
            int from = 0;
            if (n < 0)
            {
                from = 1;
            }
           
            for (int i = from; i < str.Length; i++)
            {
                if (str[i]!='.')
                {
                    result += (int)str[i] - 48;
                }
            }


            while (result > 9)
            {
                long keepRes = result;
                result = 0;
                while (keepRes > 0)
                {
                    result += keepRes % 10;
                    keepRes /= 10;
                }
            }
            Console.WriteLine(result);
        }
    }
}
