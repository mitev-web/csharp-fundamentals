using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N / 2; i++)
            {
                for (int q = 0; q < i; q++)
                {
                    Console.Write(".");
                }
                    for (int j = 0; j < N - 2 * i; j++)
                    {
                        Console.Write("*");
                    }
                    for (int k = 0; k < i; k++)
                    {
                        Console.Write(".");
                    }
                    Console.WriteLine();
                
            }
            
            for (int l =0; l <N-1; l++)
            {
                Console.Write(".");
                if (l==((N/2)-1))
	            {
                    Console.Write("*");
		        }
            }    
            Console.WriteLine();
            
                for (int i = (N/2)-1; i >=0; i--)
			{
			
                for (int q = 0; q<i; q++)
                {
                    Console.Write(".");
                }

                for (int j = 0; j < N-2*i; j++)
                {
                    Console.Write("*");
                }
                for (int k = 0; k < i; k++)
                {
                    Console.WriteLine(".");
                }
            }
                Console.WriteLine();
        }
            
        }
    }

