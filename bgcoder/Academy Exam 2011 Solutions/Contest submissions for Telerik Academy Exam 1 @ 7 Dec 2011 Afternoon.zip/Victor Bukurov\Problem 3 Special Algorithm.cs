using System;
using System.Numerics;

namespace SpecialAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputNumber = Console.ReadLine();
            string[] parts = new string[2];
            BigInteger N;
            if (inputNumber.IndexOf('.') != -1)
            {
                parts = inputNumber.Split('.');
                N = BigInteger.Parse(parts[0]);
                if (N < 0)
                {
                    N = -N;
                }
                BigInteger power = 1;
                for (int i = 0; i < parts[1].Length; i++)
                {
                    power *= 10;
                }
                N = N * power + BigInteger.Parse(parts[1]);
            }
            else
            {
                N = BigInteger.Parse(inputNumber);
                if (N < 0)
                {
                    N = -N;
                }
            }

            BigInteger sum;
            do
            {
                sum = 0;
                while (N != 0)
                {
                    sum += (N % 10);
                    N /= 10;
                }
                N = sum;
            } while (N > 9);
            Console.WriteLine(N);
        }
    }
}
