using System;

namespace Problem_1
{
    class Program
    {
        static void Main()
        {
            byte n = byte.Parse(Console.ReadLine());
            int dots = 0;
            int stars = 0;

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();

            for (int i = 0; i < n - 1; i++)
            {
                dots += 2;
                stars = n - dots;
                for (int j = 0; j < dots/2; j++)
                {
                    Console.Write(".");
                }
                for (int k = 0; k < stars; k++)
                {
                    Console.Write("*");
                }
                for (int g = 0; g < dots / 2; g++)
                {
                    Console.Write(".");
                }
                if (dots == n - 1)
                {
                    break;
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            for (int i = 0; i < n - 1; i++)
            {
                dots -= 2;
                stars = n - dots;
                for (int j = 0; j < dots / 2; j++)
                {
                    Console.Write(".");
                }
                for (int k = 0; k < stars; k++)
                {
                    Console.Write("*");
                }
                for (int g = 0; g < dots / 2; g++)
                {
                    Console.Write(".");
                }

                if (dots == 0)
                {
                    break;
                }
                Console.WriteLine();
            }
        }
    }
}
