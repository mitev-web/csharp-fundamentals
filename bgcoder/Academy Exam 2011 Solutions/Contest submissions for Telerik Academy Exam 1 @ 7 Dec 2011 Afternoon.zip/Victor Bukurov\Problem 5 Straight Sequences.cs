using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StraighSequences
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                numbers[i] = Byte.Parse(Console.ReadLine());
            }

            int maxLengthHor;
            int countHor;
            HorizontalLines(numbers, out maxLengthHor, out countHor);
            //Console.WriteLine(maxLengthHor);
            //Console.WriteLine(countHor);
            int maxLengthVer;
            int countVer;
            VerticalLines(numbers, out maxLengthVer, out countVer);
            //Console.WriteLine(maxLengthVer);
            //Console.WriteLine(countVer);
            if (maxLengthVer == maxLengthHor)
            {
                Console.WriteLine(maxLengthVer);
                if (maxLengthVer != 1)
                {
                    Console.WriteLine(countVer + countHor);
                }
                else
                {
                    Console.WriteLine(countVer);
                }
            }
            else if (maxLengthHor > maxLengthVer)
            {
                Console.WriteLine(maxLengthHor);
                Console.WriteLine(countHor);
            }
            else
            {
                Console.WriteLine(maxLengthVer);
                Console.WriteLine(countVer);
            }
        }

        static void HorizontalLines(byte[] numbers, out int maxLength, out int count)
        {
            maxLength = 0;
            count = 0;
            int length;
            for (int i = 0; i < 8; i++)
            {
                length = 0;
                for (int bit = 0; bit < 8; bit++)
                {
                    if (((numbers[i] >> bit) & 1) == 1)
                    {
                        length++;
                        if (length > maxLength)
                        {
                            count = 1;
                            maxLength = length;
                        }
                        else if (length == maxLength)
                        {
                            count++;
                        }
                    }
                    else
                    {
                        length = 0;
                    }
                }
            }
        }

        static void VerticalLines(byte[] numbers, out int maxLength, out int count)
        { 
            maxLength = 0;
            count = 0;
            int length;
            for (int bit = 0; bit < 8; bit++)
            {
                length = 0;
                for (int i = 0; i < 8; i++)
                {
                    if (((numbers[i] >> bit) & 1) == 1)
                    {
                        length++;
                        if (length > maxLength)
                        {
                            count = 1;
                            maxLength = length;
                        }
                        else if (length == maxLength)
                        {
                            count++;
                        }
                    }
                    else
                    {
                        length = 0;
                    }
                }
            }
        }
    }
}
