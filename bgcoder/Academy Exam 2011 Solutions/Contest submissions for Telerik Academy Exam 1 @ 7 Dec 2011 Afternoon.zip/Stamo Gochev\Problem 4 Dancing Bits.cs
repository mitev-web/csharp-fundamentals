using System;
   
   
/// <summary>
/// TODO: Update summary.
/// </summary>
public class NewIdea
{
    public static void Main()
    {
        int k = EnterIntNumber();
        int n = EnterIntNumber();
   
        long[] numbers = new long[n];
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = EnterLongNumber();
        }
   
        string numberAsString = "";
        for (int i = 0; i < numbers.Length; i++)
        {
            numberAsString += Convert.ToString(numbers[i], 2);
        }
        ////test 1
        //string numberAsString = "10111011101000111";
        //int k = 3;
        ////Console.WriteLine(numberAsString.Length);
   
   
        //test 2
        //string numberAsString = "10101010101010101010";
        //int k = 1;
   
        ////test 3
        //string numberAsString = "10001110101";
        //int k = 3;
   
        //test 4
        //string numberAsString = "101110111010001111";
        //int k = 4;
        //Console.WriteLine(numberAsString.Length);
   
        long countDancingBits = 0;
        if (k == 1)
        {
            countDancingBits = numberAsString.Length;
   
        }
        else
        {
            for (int i = 0; i < numberAsString.Length - k; i++)
            {
                bool areEqualBits = false;
                for (int j = i + 1; j < i + k; j++)
                {
                    if (numberAsString[i] == numberAsString[j])
                    {
                        areEqualBits = true;
                    }
                    else
                    {
                        areEqualBits = false;
                        break;
                    }
   
   
                }
   
                if (areEqualBits == true)
                {
                    if (numberAsString[i + k] != numberAsString[i])
                    {
                        countDancingBits++;
                    }
   
                    //if (i == numberAsString.Length - k - 1)
                    //{
                    //    if (numberAsString[i] ==
                    //            numberAsString[numberAsString.Length - k - 1])
                    //    {
                    //        countDancingBits++;
                    //    }
                    //    //countDancingBits++;
                    //}
   
   
                }
            }
        }
   
        Console.WriteLine(countDancingBits);
    }
    public static long EnterLongNumber()
    {
        string inputNumber = Console.ReadLine();
        long number = Convert.ToInt32(inputNumber);
        return number;
   
    }
   
    public static int EnterIntNumber()
    {
        string inputNumber = Console.ReadLine();
        int number = Convert.ToInt32(inputNumber);
        return number;
   
    }
}