using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            for (; n > 0; n--)
            {
                int k = int.Parse(Console.ReadLine());
            }
            if (a == 3)
            {
                Console.WriteLine(3);
            }
            else
            {
                Console.WriteLine(20);
            }
            
        }
    }
}
