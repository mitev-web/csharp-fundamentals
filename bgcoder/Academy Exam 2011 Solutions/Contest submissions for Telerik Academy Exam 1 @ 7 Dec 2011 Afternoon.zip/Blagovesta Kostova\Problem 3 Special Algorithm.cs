using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace SpecialProject
{
    class Program
    {
        static void Main(string[] args)
        {
            string n = Console.ReadLine();

            char[] separators = new char[] { '-', '.' };
            string[] numbers = n.Split(separators);
             

            int index = numbers.Length;
            for (int l = 0; l < index-1; l++)
            {
                n = numbers[l] + numbers[l + 1];
            }

            BigInteger sum, subSum;
            sum = 0;
            subSum = 0;

            
                BigInteger m = BigInteger.Parse(n);

                for (int i = 1; ; i++)
                {
                    if (sum + m <= 9 )
                    {
                         sum = sum + m;
                         Console.WriteLine(sum);
                         return;
                         
                    }
                        else if (m == 0)
                        {
                            subSum = subSum + sum%10;
                            sum = sum / 10;
                            if (subSum + sum < 9)
                            {
                                subSum = subSum + sum;
                                Console.WriteLine(subSum);
                                return;
                            }
                        }
                    else
                    {
                        sum = sum + m % 10;
                        m = m / 10;
                    }
                }
            }


        }
    }
