using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string Line = Console.ReadLine();
            int n = int.Parse(Line);
            {

                Console.WriteLine(new String('*', n));
                for (int row = 1; row <= n / 2; row++)
                {
                    for (int column = 1; column <= row; column++)
                    {
                        Console.Write(".");

                    }
                    Console.WriteLine();


                }
                for (int row = n / 2; row > 1; row--)
                {
                    for (int column = 1; column < row; column++)
                    {
                        Console.Write(".");
                    }
                    Console.WriteLine();

                } Console.WriteLine(new String('*', n));
            }
        }
        }

    


}