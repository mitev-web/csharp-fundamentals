using System;

namespace _1.Gwenogfryn
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            for (int rows = 0; rows < N; rows++)
            {
                for (int each = 0; each < N; each++)
                {
                    if (rows < N/ 2+1)
                    {
                        if ((each >= rows) && (each < N - rows))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    else
                    {
                        if ((each >= N - rows - 1) && (each <= rows))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                Console.WriteLine();
            }
        }
    }
}