using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Solution2
{
    class SpecialAlgorthm
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int sumDigits = 0;

            number = Math.Abs(number);

           
                while (number != 0)
                {
                    sumDigits = sumDigits + number % 10;
                    number /= 10;
                }

            Console.WriteLine(sumDigits);

        }
    }
}
