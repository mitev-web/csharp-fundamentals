using System;

namespace ProblemTwo
{
    struct Point
    {
        public int x;
        public int y;
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }

    class ProblemTwo
    {
        static void Main()
        {
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());

            Point topLeft;
            Point bottomRight;
            if (pX1 > pX2)
            {
                bottomRight.x = pX1;
                topLeft.x = pX2;
            }

            else
            {
                bottomRight.x = pX2;
                topLeft.x = pX1;
            }

            if (pY1 > pY2)
            {
                topLeft.y = pY1;
                bottomRight.y = pY2;
            }

            else
            {
                topLeft.y = pY2;
                bottomRight.y = pY1;
            }

            int result = 0;
            Point plane = new Point(fX, fY);
            Point missileHit = new Point((fX + D), fY);
            Point right, left, up;
            right = new Point(missileHit.x, missileHit.y - 1);
            left = new Point(missileHit.x, missileHit.y + 1);
            up = new Point(missileHit.x + 1, missileHit.y);

            if ((missileHit.y >= bottomRight.y && missileHit.y <= topLeft.y) && (missileHit.x >= topLeft.x && missileHit.x <= bottomRight.x))
            {
                result += 100;
            }

            if ((left.y >= bottomRight.y && left.y <= topLeft.y) && (left.x >= topLeft.x && left.x <= bottomRight.x))
            {
                result += 50;
            }

            if ((right.y >= bottomRight.y && right.y <= topLeft.y) && (right.x >= topLeft.x && right.x <= bottomRight.x))
            {
                result += 50;
            }

            if ((up.y >= bottomRight.y && up.y <= topLeft.y) && (up.x >= topLeft.x && up.x <= bottomRight.x))
            {
                result += 75;
            }
            Console.WriteLine(result + "%");

        }
    }
}
