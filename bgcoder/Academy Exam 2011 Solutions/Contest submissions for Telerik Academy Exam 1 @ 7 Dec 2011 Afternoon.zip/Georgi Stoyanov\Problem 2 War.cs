using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
            int pXone = int.Parse(Console.ReadLine());
            int pYone = int.Parse(Console.ReadLine());
            int pXtwo = int.Parse(Console.ReadLine());
            int pYtwo = int.Parse(Console.ReadLine());
            int buff;

            if (pXtwo < pXone)
            {
                buff = pXone;
                pXone = pXtwo;
                pXtwo = buff;
            }
            if (pYone > pYtwo)
            {
                buff = pYone;
                pYone = pYtwo;
                pYtwo = buff;
            }

            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int sum = 0;

            /* checks whether the main point within the reach of the plant */
            if (fX + d <= pXtwo && fX + d >= pXone)
            {
                if (fY <= pYtwo && fY >= pYone)
                {
                    sum += 100;
                }

                if (fY + 1 <= pYtwo && fY + 1 >= pYone)
                {
                    sum += 50;
                }
                if (fY - 1 <= pYtwo && fY - 1 >= pYone)
                {
                    sum += 50;
                }
            }
            if (fX + d + 1 <= pXtwo && fX + d + 1 >= pXone)
            {
                if (fY <= pYtwo && fY >= pYone)
                {
                    sum += 75;
                }
            }
            
            
            /*
            if (fX + d > pXtwo)
            {
                if (fY >= pYtwo && fY <= pYone)
                {
                    sum += 100;
                    if (fX + d + 1 <= pXtwo && fX + d + 1 >= pXone)
                    {
                        sum += 75;
                    }
                }

                if (fY + 1 >= pYtwo && fY + 1 <= pYone)
                {
                    sum += 50;
                }
                else if (fY - 1 >= pYtwo && fY - 1 <= pYone)
                {
                    sum += 50;
                }
            }*/
            /*
            if (fX + d + 1 <= pXtwo && fX + d + 1 >= pXone)
            {
                if (fY >= pYtwo && fY <= pYone)
                {
                    sum += 75;
                }
            }
            */
            Console.WriteLine("{0}%", sum);
        }
    }
}
