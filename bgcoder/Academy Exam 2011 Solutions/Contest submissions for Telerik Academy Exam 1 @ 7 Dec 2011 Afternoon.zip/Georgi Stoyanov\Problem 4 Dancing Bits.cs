using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task4
{
    class Program
    {
        static void Main(string[] args)
        {
            uint k = uint.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());
            
            uint[] numbers = new uint[n];
            for (int i = 0; i < n; i++)
            {
                numbers[i] = uint.Parse(Console.ReadLine());
            }
            uint mask = 0x80000000;
            uint counter = 0;
            for (int i = 0; i < n; i++)
            {
                mask = 0x80000000;
                while ((mask & numbers[i]) == 0)
                {
                    mask >>= 1;
                }
                while (mask != 0)
                {
                    mask >>= 1;
                    counter++;
                }
            }

            bool[] dancingNumbers = new bool[counter];
            counter = 0;

            for (int i = 0; i < n; i++)
            {
                mask = 0x80000000;
                while ((mask & numbers[i]) == 0)
                {
                    mask >>= 1;
                }
                while (mask != 0)
                {
                    if ((mask & numbers[i]) == mask)
                    {
                        dancingNumbers[counter] = true;
                    }
                    else
                    {
                        dancingNumbers[counter] = false;
                    }
                    mask >>= 1;
                    counter++;
                }
            }
            bool prevDigit = dancingNumbers[0];
            bool currDigit;
            int kCount = 0;
            int danceCount = 0;
            for (int i = 0; i < counter; i++)
            {
                currDigit = dancingNumbers[i];
                if (prevDigit != currDigit)
                {
                    if (kCount == k)
                    {
                        danceCount++;
                        kCount = 1;
                    }
                    if (kCount!=k)
                        kCount = 1;
                }

                if (prevDigit == currDigit)
                    kCount++;
                prevDigit = currDigit;
            }
            if (kCount == k)
                danceCount++;
            Console.WriteLine(danceCount);
        }
    }
}
