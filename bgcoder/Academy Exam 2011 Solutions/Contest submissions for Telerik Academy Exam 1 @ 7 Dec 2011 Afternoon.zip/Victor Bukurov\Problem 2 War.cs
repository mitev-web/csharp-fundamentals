using System;

namespace War
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1, Px2, Py1, Py2, Fx, Fy, D; // int 100 000 to 100 000
            Px1 = Int32.Parse(Console.ReadLine());
            Py1 = Int32.Parse(Console.ReadLine());
            Px2 = Int32.Parse(Console.ReadLine());
            Py2 = Int32.Parse(Console.ReadLine());
            Fx = Int32.Parse(Console.ReadLine());
            Fy = Int32.Parse(Console.ReadLine());
            D = Int32.Parse(Console.ReadLine());

            int bombX = Fx + D;
            double damage = 0;

            damage += IsSuccessfulHit(Px1, Py1, Px2, Py2, bombX, Fy) ? 100 : 0;
            damage += IsSuccessfulHit(Px1, Py1, Px2, Py2, bombX, Fy + 1) ? 50 : 0;
            damage += IsSuccessfulHit(Px1, Py1, Px2, Py2, bombX, Fy - 1) ? 50 : 0;
            damage += IsSuccessfulHit(Px1, Py1, Px2, Py2, bombX + 1, Fy) ? 75 : 0;
            Console.WriteLine("{0}%", damage);
        }

        static bool IsSuccessfulHit(int x1, int y1, int x2, int y2, int hitX, int hitY)
        {
            if(hitX >= Math.Min(x1, x2) && hitX <= Math.Max(x1, x2))
            {
                if (hitY >= Math.Min(y1, y2) && hitY <= Math.Max(y1, y2))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
