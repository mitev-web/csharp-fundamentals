using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03
{
    class Task03
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            int sum = 0;

            while (n != 0)
            {
                sum += (int)n % 10;
                n /= 10;
            }
            //Console.WriteLine(Math.Abs(sum));
            if (Math.Abs(sum) <= 9)
            {
                Console.WriteLine(Math.Abs(sum));
            }
            else
            {
                int m = Math.Abs(sum);
                int sum2 = 0;
                while (m != 0)
                {
                    sum2 += m % 10;
                    m /= 10;
                   
                }
                Console.WriteLine(Math.Abs(sum2));
            }

        }
    }
}
