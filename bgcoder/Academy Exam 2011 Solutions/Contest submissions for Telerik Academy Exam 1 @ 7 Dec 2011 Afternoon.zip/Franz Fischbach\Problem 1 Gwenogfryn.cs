using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n;
            n = byte.Parse(Console.ReadLine());
            byte i = 0;
            // upper part of sand glas
            for (  ; i<(n/2)+1 ; i++)
            {
                for (byte dots = 0; dots < i; dots++) // write the dots at the begining of the row
                {
                    Console.Write(".");
                }

                for (byte star = 0; star < n - (2 * i); star++)// write the stars 
                {
                    Console.Write("*");
                }

                for (byte dots = 0; dots < i; dots++) // write the dots at the end of the row 
                {
                    Console.Write(".");
                }

                Console.WriteLine();

            }// end  for ( ; i < (n/2)+1 ; i++) // upper part of sand glas

            // lower part of sandbox, i starts from where last cycle ended
            for (i++; i <= n; i++)
            {
                for (byte dots = 0; dots <n - i; dots++) // write the dots at the begining of the row
                {
                    Console.Write(".");
                }

                for (byte star = 0; star< n-(n-i)*2 ; star++)// write the stars 
                {
                    Console.Write("*");
                }
                
                for (byte dots = 0; dots <n - i; dots++) // write the dots at the end of the row
                {
                    Console.Write(".");
                }

                Console.WriteLine();

            }// end  for (i++; i <= n; i++)


        }// end static void Main(string[] args)
    }
}
