using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace RealExam
{
    class RealExam
    {
        static void Main(string[] args)
        {
            War();
        }

        static void War()
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());


            if ((Fx - Px1 > D) & (Fx - Px2) < D) {

            }
            else if ((Fx - Px1 < D) & (Fx - Px2) < D)
            {
                
            }
            if (Py1 == Py2 &&  Py1 == Fy) {
                Console.WriteLine("175%");
            }
            if ((Py1 == Fy || Py2 == Fy) && (Py1 != Py2)) {
                Console.WriteLine("225%");
            }
            if ((Py1 < Fy) & (Py2 > Fy))
            {
                Console.WriteLine("275%");
                return;
            }
            else if ((Py1 < Fy) | (Py2 > Fy))
            {
                Console.WriteLine("0%");
                return;
            }

        }
    }
}
