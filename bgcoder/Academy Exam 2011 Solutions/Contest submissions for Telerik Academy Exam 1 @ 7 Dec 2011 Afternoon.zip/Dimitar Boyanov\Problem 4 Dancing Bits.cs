using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());
            int count = 0;
            string bits = "";

            for (int i = 1; i <= n; i++)
            {
                int input = int.Parse(Console.ReadLine());
                bits = bits + Convert.ToString(input, 2);
            }

            string firstSearchString = "0";
            string secondSearchString = "1";

            if (k > 1)
            {
                for (int i = 0; i < k; i++)
                {
                    firstSearchString = firstSearchString + "1";
                    secondSearchString = secondSearchString + "0";

                    if (i == k - 1)
                    {
                        firstSearchString = firstSearchString + "0";
                        secondSearchString = secondSearchString + "1";
                    }
                }
            }

            int position = 0;
            while (bits.IndexOf(firstSearchString, position) != -1)
            {
                position = bits.IndexOf(firstSearchString, position);
                position++;
                count++;
            }

            position = 0;
            while (bits.IndexOf(secondSearchString, position) != -1)
            {
                position = bits.IndexOf(secondSearchString, position);
                position++;
                count++;
            }

            Console.WriteLine(count);

        }
    }
}
