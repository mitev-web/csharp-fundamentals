using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int a=0;
            int b=n-1;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (j >= a && j <= b&&i<=((n/2)+1))
                    {
                        Console.Write('*');
                    }
                    else if(j<=a &&j>=b&&i>=((n/2)+1))
                    {
                        Console.Write('*');
                    }

                    else
                    {
                        Console.Write('.');
                    }
                }
               
                    a++;
                    b--;
                Console.WriteLine();
            }
        }
    }
}