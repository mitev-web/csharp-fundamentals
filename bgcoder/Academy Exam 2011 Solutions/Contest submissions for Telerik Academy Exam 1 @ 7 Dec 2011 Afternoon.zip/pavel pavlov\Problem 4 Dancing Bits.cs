using System;

namespace Problem_4
{
    class Program
    {
        static void Main()
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int equal = 0;
            int danceTogether = 0;
            string bitWord = null;
            for (int i = 0; i < n; i++)
            {
                int givenNumber = int.Parse(Console.ReadLine());
                bitWord += Convert.ToString(givenNumber, 2);
            }
            
            for (int i = 0; i < bitWord.Length - 2*k; i++)
            {
                if (bitWord[i] == bitWord[i + 1])
                {
                    equal++;
                }            
                if (equal == k - 1 && bitWord[i + 1] != bitWord[i + 2])
                {
                    danceTogether++;
                    equal = 0;
                }
            }
            Console.WriteLine(danceTogether);
        }
    }
}
