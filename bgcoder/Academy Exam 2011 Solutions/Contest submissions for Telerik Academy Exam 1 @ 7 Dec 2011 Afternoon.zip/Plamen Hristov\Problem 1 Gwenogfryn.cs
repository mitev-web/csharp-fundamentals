using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string[,] matrix = new string[N, N];
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    matrix[i, j] = ".";
                }
            }
            for (int row = 0; row < N; row++)
            {
                for (int col = 0; col < N; col++)
                {
                    if (col == row || col + row == N - 1 ) //|| row == 0 || row == N - 1
                    {
                        matrix[row, col] = "*";
                        for (int i = col+1; i < N/2+1 ; i++)
                        {
                            matrix[row, i] = "*";
                        }

                        }
                    for (int i = col; i > N / 2; i--)
                    {
                        if (row + col == N - 1 )
                        {
                            matrix[row, i] = "*";
                        }
                    }
                    for (int i = row; i > N / 2; i--)
                    {
                        if (row == col)
                        {
                            matrix[col, i] = "*";
                        }
                    }
          
                    }
       
                }
     
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + "");
                }
                Console.WriteLine("");
            }
        }
    }
}
