using System;

namespace ProblemFour
{
    class ProblemFour
    {
        static void Main()
        {
            short K = short.Parse(Console.ReadLine());
            short N = short.Parse(Console.ReadLine());
            uint[] numbers = new uint[N];
            string[] num = new string[N];
            for (int i = 0; i < N; i++)
            {
                numbers[i] = uint.Parse(Console.ReadLine());
                num[i] = Convert.ToString(numbers[i], 2);
            }
            
            
            string sum = "";
            for (int i = 0; i < num.Length; i++)
            {
                sum += num[i];
            }
            char[] array = sum.ToCharArray();
            short localSum = 0;
            short total = 0;
            int check = 0;

            for (int i = 0; i < (array.Length - (K+1)); i++)
            {    
                for (int j = 0, k = i; j < K; j++, k++)
                {
                        check = k;
                        if (array[k] == array[i]) localSum++;
                }

                if (array[check + 1] == array[check])
                {
                    localSum = 0;
                    continue;
                }
                else
                {
                    if (localSum == K)
                    {
                        total++;
                        localSum = 0;
                        continue;
                    }

                    else
                    {
                        localSum = 0;
                        continue;
                    }
                }
            }
            
            Console.WriteLine(total);
            
        }
    }
}
