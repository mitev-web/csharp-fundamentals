using System;
using System.Numerics;

namespace Task_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();

            int result = 0;

            do
            {

                result = 0;
                for (int i = 0; i < number.Length; i++)
                {
                    if (number[i] != '-' && number[i] != '.')
                    {
                        string element = Convert.ToString(number[i]);
                        int temp = int.Parse(element);

                        result = result + temp;

                    }

                }
               
                  number = Convert.ToString(result);
               
            }
            while (result >= 9);


            Console.WriteLine(result);
        }
    }
}

