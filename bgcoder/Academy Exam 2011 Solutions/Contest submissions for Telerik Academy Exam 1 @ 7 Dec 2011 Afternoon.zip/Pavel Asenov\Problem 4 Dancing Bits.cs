using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_4_Dancing_Bits
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            string number="";
            for (int i = 0; i < n ; i++)
                {

                    number = number + Convert.ToString(int.Parse(Console.ReadLine()), 2);


                }
             char searchedItem= number[0];
             int counterOfDancingBits = 0;
             int counterOfSequense = 1;
            for (int i = 1; i < number.Length; i++)
            {


                if (number[i] == searchedItem)
                {
                    counterOfSequense++;
                    if (counterOfSequense == k && i != number.Length-1)
                    {
                        if (number[i + 1] != searchedItem)
                        {
                            counterOfDancingBits++;
                            counterOfSequense = 0;
                            if (searchedItem == '0') searchedItem = '1';
                            else searchedItem = '0';

                        }
                        else if (number[i + 1] == searchedItem && counterOfSequense == k)
                        {
                            counterOfSequense = 0;

                            if (searchedItem == '0') searchedItem = '1';
                            else searchedItem = '0';
                        }
                    }
                   


                }
                else
                {
                    searchedItem = number[i];
                    counterOfSequense = 1;
                }  

            }

           // Console.WriteLine(number);
            Console.WriteLine(counterOfDancingBits);
        }
    }
}
