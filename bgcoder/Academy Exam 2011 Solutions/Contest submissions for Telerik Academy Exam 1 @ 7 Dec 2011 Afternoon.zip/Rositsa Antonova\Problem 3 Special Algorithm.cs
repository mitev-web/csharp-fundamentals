using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad3SpecialAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            double N;
            N = double.Parse(Console.ReadLine());
            N = Math.Abs(N);
          //  N=(double)(N*1000);
            
            //Console.WriteLine(Math.Floor(53535.2));
            double result=0;
            do
            {
            mark:
                result = 0;
                do
                {
                    result = result + N % 10;
                    N =Math.Floor(N / 10);
                    //Console.WriteLine(N);
                    //Console.WriteLine(result);
                } while (N > 0);
                if (result > 9)
                {
                    N = result;
                    goto mark;
                }
            }
            while (result > 9);
            Console.WriteLine(result);
        }
    }
}
