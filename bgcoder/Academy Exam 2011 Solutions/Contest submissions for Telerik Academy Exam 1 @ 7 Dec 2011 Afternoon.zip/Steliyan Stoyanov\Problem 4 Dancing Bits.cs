using System;

namespace DancingBits
{
    class Program
    {
        static byte GetBit(byte number, int position)
        {
            return (byte)((number >> position) & 1);
        }

        static int FindExactOccurance(string str, string occur)
        {
            int totalCount = 0;
            int index = str.IndexOf(occur);

            bool first = false;
            bool last = false;

            while(index != -1)
            {
                if(index - 1 >= 0)
                {
                    if(str[index - 1] != occur[0])
                    {
                        first = true;
                    }
                }
                else
                    first = true;

                if(index + occur.Length < str.Length)
                {
                    if(str[index + occur.Length] != occur[0])
                    {
                        last = true;
                    }

                }
                else
                    last = true;

                if(first == true && last == true)
                    totalCount++;

                first = false;
                last = false;


                index = str.IndexOf(occur, index + occur.Length);


            }

            return totalCount;
        }

        static void Main(string[] args)
        {
            int n, k;
            
            k = Int32.Parse(Console.ReadLine());
            n = Int32.Parse(Console.ReadLine());

            uint[] arr = new uint[n];
            string pattern0 = new string('0', k);
            string pattern1 = new string('1', k);

            for(int i = 0; i < n; i++)
                arr[i] = uint.Parse(Console.ReadLine());

            string res = "";

            for(int i = 0; i < n; i++)
                res += Convert.ToString(arr[i], 2);

            int totalCount = FindExactOccurance(res, pattern0) + FindExactOccurance(res, pattern1);
            Console.WriteLine(totalCount);
        }
    }
}
