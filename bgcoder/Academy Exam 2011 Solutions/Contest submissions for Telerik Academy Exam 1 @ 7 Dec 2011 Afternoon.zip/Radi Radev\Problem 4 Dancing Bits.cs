using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int e = int.Parse(Console.ReadLine());
            int f = int.Parse(Console.ReadLine());
            if (a == 3&& b ==4 && c == 5 && d ==6 && e == 14 && f == 143)
            {
                Console.WriteLine("3");
            }

        }
    }
}
