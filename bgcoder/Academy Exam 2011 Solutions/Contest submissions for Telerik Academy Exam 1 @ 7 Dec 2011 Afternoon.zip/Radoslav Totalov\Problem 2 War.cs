using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace War
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int Px1 = int.Parse(line);
            line = Console.ReadLine();
            int Py1 = int.Parse(line);
            line = Console.ReadLine();
            int Px2 = int.Parse(line);
            line = Console.ReadLine();
            int Py2 = int.Parse(line);
            line = Console.ReadLine();
            int Fx = int.Parse(line);
            line = Console.ReadLine();
            int Fy = int.Parse(line);
            line = Console.ReadLine();
            int D = int.Parse(line);



            //int bestDamage = Fx + D;
            //int halfDamage = Fy + 1;
            //int middleDamage = Fy + 1;
            //if ((Px1<Px2)&&(Py1<Py2))
            //{
              if(((Fy < Py1-2)&&(Fx + D < Px1-2))||
                  ((Fy > Py1+2)&& (Fx + D < Px1-2)))
                {
                    Console.WriteLine("0%");
                }
           
              if  (((Fy == Py1) && ((Fx + D) == (Px1 - 1)) ||
                  ((Fy == Py1) && ((Fx + D) == (Px2 - 1)) ||
                  ((Fy == Py2) && ((Fx + D) == (Px1 - 1)) ||
                  ((Fy == Py2) && ((Fx + D) == (Px2 - 1)))))))
              {
                  Console.WriteLine("75%");
              }

              if (((Fy == Py1) && ((Fx + D) == (Px1 )) ||
                    ((Fy == Py1) && ((Fx + D) == (Px2)) ||
                    ((Fy == Py2) && ((Fx + D) == (Px1)) ||
                    ((Fy == Py2) && ((Fx + D) == (Px2)))))))
              {
                  Console.WriteLine("100%");
              }
            
         
            
        }
    }
}

