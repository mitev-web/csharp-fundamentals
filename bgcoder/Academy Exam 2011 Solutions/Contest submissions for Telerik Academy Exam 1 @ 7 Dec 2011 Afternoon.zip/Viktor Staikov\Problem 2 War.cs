using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace War
{
    class War
    {
        static void Main(string[] args)
        {
            int x1, y1, x2, y2, fx, fy, d;
            x1 = int.Parse(Console.ReadLine());
            y1 = int.Parse(Console.ReadLine());
            x2 = int.Parse(Console.ReadLine());
            y2 = int.Parse(Console.ReadLine());
            fx = int.Parse(Console.ReadLine());
            fy = int.Parse(Console.ReadLine());
            d = int.Parse(Console.ReadLine());

            if (x1 > x2)
            {
                x1 -= x2;
                x2 += x1;
                x1 = x2 - x1;
            }
            if (y1 > y2)
            {
                y1 -= y2;
                y2 += y1;
                y1 = y2 - y1;
            }

            int dmg=0;
            fx += d;

            if ((fy < y1 - 1 || y2 + 1 < fy) || (fx < x1 - 1 || x2 < fx))
                dmg = 0;
            else
            if ((fy<y1 || y2<fy) && (x1<=fx && fx<=x2))
            {
                dmg = 50;
            }
            else
            if ((y1<=fy && fy<=y2) && (fx == x1 - 1))
            {
                dmg = 75;
            }
            else
            if (y1 == y2 && y1 == fy && fx == x2)
            {
                dmg = 100;
            }
            else
            if (fx==x2 && (fy == y1 || fy == y2))
            {
                dmg = 150;
            }
            else
            if (fy == y1 && y1==y2 && x1<=fx && fx<x2)
            {
                dmg = 175;    
            }
            else
            if (y1 < fy && fy < y2 && fx == x2)
            {
                dmg = 200;
            }
            else
            if ((fy == y1 || fy == y2) && y1!=y2 && (x1 <= fx && fx < x2))
            {
                dmg = 225;
            }
            else
            if ((y1<fy && fy<y2) && y2-y1>1 && (x1<=fx && fx<x2))
            {
                dmg = 275;
            }

            Console.WriteLine("{0}%", dmg);
        }
    }
}