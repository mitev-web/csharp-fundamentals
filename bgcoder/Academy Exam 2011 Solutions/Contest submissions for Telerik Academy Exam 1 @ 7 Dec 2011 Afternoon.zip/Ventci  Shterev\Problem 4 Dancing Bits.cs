using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem04_DancingBits
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            string inputStr = Console.ReadLine();
            short kBits = short.Parse(inputStr);
            inputStr = Console.ReadLine();
            short nNumbers = short.Parse(inputStr);
            uint[] arrayOfNum = new uint[nNumbers];
            for (int i = 0; i < arrayOfNum.Length; i++)
            {
                inputStr = Console.ReadLine();
                arrayOfNum[i] = uint.Parse(inputStr);
            }

            BigInteger concatenatedNum = 0;
            for (short i = 0; i < arrayOfNum.Length; i++)
            {
                uint tempNum = arrayOfNum[i];
                int bitCount = 0;
                uint worckValue = 0;
                for (int j = 0; j < 32; j++)
                {
                    uint mask = tempNum >> j;
                    if (mask == 0)
                    {
                        break;
                    }                    
                    mask = mask & 1;
                    mask = mask << j;
                    worckValue = worckValue | mask;
                    bitCount++;
                }
                concatenatedNum = (concatenatedNum << bitCount) | worckValue;
            }
            BigInteger dancingBits = 0;
            while (concatenatedNum != 0)
            {                
                int firstBit = (int)(concatenatedNum & 1);
                int bitCount = 1;
                for (int i = 1; i < kBits; i++)
                {
                    if ((int)((concatenatedNum >> i) & 1) == firstBit)
                    {
                        bitCount++;
                    }
                    else
                    {
                        break;
                    }
                }
                if ((bitCount == kBits) && (int)((concatenatedNum >> kBits) & 1) == firstBit)
                {
                    dancingBits = 0;
                    concatenatedNum = concatenatedNum >> kBits+1;
                }
                else if ((bitCount == kBits) && (int)((concatenatedNum >> kBits) & 1) != firstBit)
                {
                    dancingBits++;
                    concatenatedNum = concatenatedNum >> kBits;
                }
                else 
                {
                    concatenatedNum = concatenatedNum >> 1;
                }
            }
            Console.WriteLine(dancingBits);
        }
    }
}
