using System;

class Trapezoid
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        byte n = byte.Parse(line);
        
        for (int l = 0; l < n/2+1; l++)
        {
            for (int i = 0; i < n; i++)
            {
                if ((i < l) || (i > n - l - 1)) 
                {
                    Console.Write(".");
                }                
                else
                {
                    Console.Write("*");
                }             
                
            }
            Console.WriteLine();
        }
        for (int l = n / 2 + 1; l < n; l++)
        {
            for (int i = 0; i < n; i++)
            {
                if ((i > l) || (i < n - l - 1))
                {
                    Console.Write(".");
                }
                else
                {
                    Console.Write("*");
                }

            }
            Console.WriteLine();
        }     
        
    }
}