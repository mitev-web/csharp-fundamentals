using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace ConsoleApplication1
{
    class specialAlgo
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            decimal n = decimal.Parse(Console.ReadLine());
            if(n<0)
            {
                n=n*-1;
            }
            
            decimal stepen = 0;
            decimal a = 1;
            decimal cqlo;
            cqlo = (ulong)n;
            decimal k = n - cqlo;
            decimal br = cqlo;
            decimal cqlo1 = cqlo;
            decimal cqlo2 = cqlo;
            decimal sum = 0;
            ulong sum5=0;
            while (br > 1)
            {
                br=br / 10;
                stepen++;
            }
            decimal stepen2 = stepen;
            for (; stepen > 1; stepen--)
            {
                a = a * 10;
            }
            ulong broqch5 = 0;
            ulong sum3 = 0;
            decimal cqlo5 = k;
            for (; broqch5 < 300; broqch5++)
            {
                cqlo5 = cqlo5 * 10;
                ulong c = (ulong)cqlo5;
                if (c > 0)
                {
                    sum3 = sum3 + c;
                }
                cqlo5 = cqlo5 - c;
            }
            while (cqlo1 > 9)
            {
                while (cqlo1 > 0)
                {
                    cqlo1 = cqlo1 / a;
                    sum = sum + cqlo1;
                    sum5 = (ulong)sum;
                    ulong cqlo10 = (ulong)cqlo1;
                    cqlo1 = cqlo2 - (cqlo10 * a);
                    cqlo2 = cqlo1;
                    a = a / 10;

                }
                cqlo1 = sum5+sum3;
                cqlo2 = sum5+sum3;
                sum3 = 0;
                a = 1;
                decimal cqlo3 = cqlo1;
                while (cqlo3 > 10)
                {
                    cqlo3 = cqlo3 / 10;
                    stepen++;
                }
                for (; stepen > 0; stepen--)
                {
                    a = a * 10;
                }
                sum = 0;
            }
            if (cqlo1 == 0)
            {
                cqlo1 = sum3;
            }
               
            Console.WriteLine(cqlo1);
            
        }
    }
}
