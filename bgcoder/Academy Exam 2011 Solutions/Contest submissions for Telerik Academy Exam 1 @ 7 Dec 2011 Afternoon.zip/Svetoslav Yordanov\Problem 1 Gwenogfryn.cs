{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please eneter positive intiger n between 3 and 101= ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine();
            
            for (int row = 0; row < n; row++)
            {
                for (int col = 1; col <= n; col++)
                {
                    if (col <= row)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
