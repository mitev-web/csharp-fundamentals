using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RealExam
{
    class RealExam
    {
        static void Main(string[] args)
        {
            Gwenogfryn();
        }

        static void Gwenogfryn()
        {
            int sandClockHeight = 0;
            sandClockHeight = int.Parse(Console.ReadLine());
            StringBuilder sb = new StringBuilder();
            char sandClock = '*';
            char emptySpace = '.';

            for (int i = 0; i < sandClockHeight; i++)
            {
                for (int k = 0; k < sandClockHeight; k++)
                {
                    if (((sandClockHeight / 2) + 1) > i)
                    {
                        if ((k >= i) && (k < sandClockHeight - i))
                        {
                            sb.Append(sandClock);
                        }
                        else
                        {
                            sb.Append(emptySpace);
                        }
                    }
                    else
                    {
                        if ((k <= i) && (k >= (sandClockHeight - i - 1)))
                        {
                            sb.Append(sandClock);
                        }
                        else
                        {
                            sb.Append(emptySpace);
                        }
                    }
                }
                sb.Append("\n");
            }
            Console.WriteLine(sb);
        }
    }
}
