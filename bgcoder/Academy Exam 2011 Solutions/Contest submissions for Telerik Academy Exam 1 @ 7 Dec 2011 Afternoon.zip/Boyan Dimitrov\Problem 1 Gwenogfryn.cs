using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass_Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            string consoleLine = Console.ReadLine();
            int n = int.Parse(consoleLine);

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }

            Console.WriteLine();

            for (int i = 0, k = 0; i < n / 2 ; i++, k++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (j <= k || j >= n - k -1)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                    
                }
                Console.WriteLine();
            }

            for (int i = 1, k = n / 2; i < n / 2; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (j < k - i || j > k + i)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }

                }
                Console.WriteLine();
            }

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
        }
    }
}
