using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Task_2_WAR
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal px1 = decimal.Parse(Console.ReadLine());
            decimal py1 = decimal.Parse(Console.ReadLine());
            decimal px2 = decimal.Parse(Console.ReadLine());
            decimal py2 = decimal.Parse(Console.ReadLine());
            decimal fx = decimal.Parse(Console.ReadLine());
            decimal fy = decimal.Parse(Console.ReadLine());
            decimal d = decimal.Parse(Console.ReadLine());
            decimal result = 0;
 
            if (px1 > px2)
            {
                if (py1 > py2)
                {
                    if ((fy >= py2) && (fy <= py1) && (fx + d <= px1) && (fx + d >= px2))
                    {
                        result = result + 100;
 
                    }
                    if ((fy + 1 >= py2) && (fy + 1 <= py1) && (fx + d <= px1) && (fx + d >= px2))
                    {
                        result = result + 50;
 
                    }
                    if ((fy - 1 >= py2) && (fy - 1 <= py1) && (fx + d <= px1) && (fx + d >= px2))
                    {
                        result = result + 50;
 
                    }
 
                    if ((fy >= py2) && (fy <= py1) && (fx + d + 1 <= px1) && (fx + d + 1 >= px2))
                    {
                        result = result + 75;
                    }
                    else
                    {
                        if ((fy <= py2) && (fy >= py1) && (fx + d >= px2) && (fx + d <= px1))
                        {
                            result = result + 100;
 
                        }
                        if ((fy + 1 <= py2) && (fy + 1 >= py1) && (fx + d >= px2) && (fx + d <= px1))
                        {
                            result = result + 50;
 
                        }
                        if ((fy - 1 <= py2) && (fy - 1 >= py1) && (fx + d >= px2) && (fx + d <= px1))
                        {
                            result = result + 50;
 
                        }
 
                        if ((fy <= py2) && (fy >= py1) && (fx + d + 1 >= px2) && (fx + d + 1 <= px1))
                        {
                            result = result + 75;
                        }
 
                    }
                }
            }
            else
            {
                //(px1 < px2)
                if (py1 > py2)
                {
                    if ((fy >= py2) && (fy <= py1) && (fx + d >= px1) && (fx + d <= px2))
                    {
                        result = result + 100;
 
                    }
                    if ((fy + 1 >= py2) && (fy + 1 <= py1) && (fx + d >= px1) && (fx + d <= px2))
                    {
                        result = result + 50;
 
                    }
                    if ((fy - 1 >= py2) && (fy - 1 <= py1) && (fx + d >= px1) && (fx + d <= px2))
                    {
                        result = result + 50;
 
                    }
 
                    if ((fy >= py2) && (fy <= py1) && (fx + d + 1 >= px1) && (fx + d + 1 <= px2))
                    {
                        result = result + 75;
 
                    }
                }
                else
                {
                    if ((fy >= py1) && (fy <= py2) && (fx + d >= px1) && (fx + d <= px2))
                    {
                        result = result + 100;
 
                    }
                    if ((fy + 1 >= py1) && (fy + 1 <= py2) && (fx + d >= px1) && (fx + d <= px2))
                    {
                        result = result + 50;
 
                    }
                    if ((fy - 1 >= py1) && (fy - 1 <= py2) && (fx + d >= px1) && (fx + d <= px2))
                    {
                        result = result + 50;
 
                    }
 
                    if ((fy >= py1) && (fy <= py2) && (fx + d + 1 >= px1) && (fx + d + 1 <= px2))
                    {
                        result = result + 75;
 
                    }
                }
 
            }
            Console.Write(result + "%");
        }
    }
}