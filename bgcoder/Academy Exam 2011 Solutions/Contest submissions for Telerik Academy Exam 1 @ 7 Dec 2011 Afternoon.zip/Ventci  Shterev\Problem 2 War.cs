using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem02_War
{
    class War
    {
        static void Main(string[] args)
        {
            string inputStr = Console.ReadLine();
            int pointX1 = int.Parse(inputStr);
            inputStr = Console.ReadLine();
            int pointY1 = int.Parse(inputStr);
            inputStr = Console.ReadLine();
            int pointX2 = int.Parse(inputStr);
            inputStr = Console.ReadLine();
            int pointY2 = int.Parse(inputStr);
            if (pointX1 > pointX2)
            {
                int temp = pointX1;
                pointX1 = pointX2;
                pointX2 = temp;
            }
            if (pointY1 > pointY2)
            {
                int temp = pointY1;
                pointY1 = pointY2;
                pointY2 = temp;
            }
            inputStr = Console.ReadLine();
            int fighterX = int.Parse(inputStr);
            inputStr = Console.ReadLine();
            int fighterY = int.Parse(inputStr);
            inputStr = Console.ReadLine();
            int distance = int.Parse(inputStr);

            int missileDirectX = fighterX + distance;
            int missileDirectY = fighterY;

            int missileFrontX = (fighterX + distance) + 1;
            int missileFrontY = fighterY;

            int missileLeftX = fighterX + distance;
            int missileLeftY = fighterY + 1;

            int missileRightX = fighterX + distance;
            int missileRightY = fighterY - 1;

            int result = 0;
            if ((missileDirectX >= pointX1) && (missileDirectX <= pointX2) && (missileDirectY >= pointY1) && (missileDirectY <= pointY2))
            {
                result += 100;
            }
            if ((missileFrontX >= pointX1) && (missileFrontX <= pointX2) && (missileFrontY >= pointY1) && (missileFrontY <= pointY2))
            {
                result += 75;
            }
            if ((missileLeftX >= pointX1) && (missileLeftX <= pointX2) && (missileLeftY >= pointY1) && (missileLeftY <= pointY2))
            {
                result += 50;
            }
            if ((missileRightX >= pointX1) && (missileRightX <= pointX2) && (missileRightY >= pointY1) && (missileRightY <= pointY2))
            {
                result += 50;
            }
            Console.WriteLine("{0}%",result);
        }
    }
}
