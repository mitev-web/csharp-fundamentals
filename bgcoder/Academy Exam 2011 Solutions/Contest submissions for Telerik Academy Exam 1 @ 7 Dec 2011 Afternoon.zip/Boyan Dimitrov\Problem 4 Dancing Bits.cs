using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dancing_Bits_Exercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            string consoleLine = Console.ReadLine();
            long k = long.Parse(consoleLine);

            consoleLine = Console.ReadLine();
            int n = int.Parse(consoleLine);

            long firstNumber = 0;
            int count = 0;
            long lastBit = 0;
            int dancingBitsCount = 0;
            int count1 = 0;
            long tempNumber = 0;


            int[] numbers = new int[n];

            for (int i = 0; i < n; i++)
            {
                consoleLine = Console.ReadLine();
                numbers[i] = int.Parse(consoleLine);
            }

            firstNumber = numbers[0];

            for (int i = 1; i < numbers.Length; i++)
            {
                int temp = numbers[i];
                count = 0;
                while (temp / 2 != 0)
                {
                    temp /= 2;
                    count++;
                }

                if (temp == 1)
                {
                    count++;
                } 

                firstNumber <<= count;
                firstNumber |= numbers[i];
            }

            lastBit = firstNumber % 2;
            for (int i = 0; i < count; i++)
            {
                firstNumber >>= 1;
                if ((firstNumber & 1) == 0)
                {
                    if (lastBit == 0)
                    {
                        count1++;
                    }
                    else
                    {
                        lastBit = firstNumber % 2;
                    }
                }
                else
                {
                    if (lastBit == 1)
                    {
                        count1++;
                    }
                    else
                    {
                        lastBit = firstNumber % 2;
                    }
                }

                if ((count1 == k) && (firstNumber % 2 != lastBit) )
                {
                    dancingBitsCount++;
                }

            }

            Console.WriteLine(dancingBitsCount);
        }
    }
}
