using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Motherfucking_War
{
    class Program
    {
        public static int PlantCorner1X = 6;
        public static int PlantCorner1Y = 5;
        public static int PlantCorner2X = 2;
        public static int PlantCorner2Y = 3;

        public static int FighterCoordX = 0;
        public static int FighterCoordY = 1;

        public static int Distance = -3;

        public static int TargetCellCoordX;
        public static int TargetCellCoordY;

        public static bool CellBelongsToPlant(int x, int y)
        {
            int upperCornerY = Math.Max(PlantCorner1Y, PlantCorner2Y);
            int lowerCornerY = Math.Min(PlantCorner1Y, PlantCorner2Y);
            bool isBetweenYCoords = y >= lowerCornerY && y <= upperCornerY;

            int rightmostCornerX = Math.Max(PlantCorner1X, PlantCorner2X);
            int leftmostCornerX = Math.Min(PlantCorner1X, PlantCorner2X);
            bool isBetweenXCoords = x >= leftmostCornerX && x <= rightmostCornerX;

            return isBetweenXCoords && isBetweenYCoords;
        }

        public static void ReadInputData()
        {
            PlantCorner1X = Convert.ToInt32(Console.ReadLine());
            PlantCorner1Y = Convert.ToInt32(Console.ReadLine());
            PlantCorner2X = Convert.ToInt32(Console.ReadLine());
            PlantCorner2Y = Convert.ToInt32(Console.ReadLine());

            FighterCoordX = Convert.ToInt32(Console.ReadLine());
            FighterCoordY = Convert.ToInt32(Console.ReadLine());

            Distance = Convert.ToInt32(Console.ReadLine());
        }

        static void Main(string[] args)
        {
            ReadInputData();
            TargetCellCoordX = FighterCoordX + Distance;
            TargetCellCoordY = FighterCoordY;

            int totalDamage = 0;
            if (CellBelongsToPlant(TargetCellCoordX, TargetCellCoordY))
            {
                totalDamage += 100;
            }
            if (CellBelongsToPlant(TargetCellCoordX + 1, TargetCellCoordY))
            {
                totalDamage += 75;
            }
            if (CellBelongsToPlant(TargetCellCoordX, TargetCellCoordY + 1))
            {
                totalDamage += 50;
            }
            if (CellBelongsToPlant(TargetCellCoordX, TargetCellCoordY - 1))
            {
                totalDamage += 50;
            }
            Console.WriteLine(totalDamage + "%");
        }
    }
}
