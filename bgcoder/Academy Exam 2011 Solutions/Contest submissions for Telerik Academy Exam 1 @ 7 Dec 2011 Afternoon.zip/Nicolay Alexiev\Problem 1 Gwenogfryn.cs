using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_1___Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int temp = N;
            for (int i = temp; i >= 1; i-=2)
            {
                if (i != temp)
                {
                    for (int j = i; j < temp; j+=2)
                    {

                        Console.Write(".");
                    }
                    for (uint k = 1; k <= i; k++)
                    {
                        Console.Write("*");
                    }
                    for (int l = i; l < temp; l+=2)
                    {
                        Console.Write(".");
                    }
                }
                else if(i==temp)
                {
                    for (uint k = 1; k <= i; k++)
                    {
                        Console.Write("*");
                    }
                }
                
                Console.WriteLine();
            
            }
            for (int i = 3; i <= temp; i += 2)
            {
                if (i != temp)
                {
                    for (int j = i; j < temp; j += 2)
                    {

                        Console.Write(".");
                    }
                    for (uint k = 1; k <= i; k++)
                    {
                        Console.Write("*");
                    }
                    for (int l = i; l < temp; l += 2)
                    {
                        Console.Write(".");
                    }
                }
                else if (i == temp)
                {
                    for (uint k = 1; k <= i; k++)
                    {
                        Console.Write("*");
                    }
                }

                Console.WriteLine();

            }
            }
        }
    }