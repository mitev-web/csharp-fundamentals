using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestExam
{
    class Gwenogfryn
    {
        static void DisplayRow(int n, int dotCount)
        {
            for (int j = 0; j < n; j++)
            {
                if (j < dotCount)
                {
                    Console.Write(".");
                }
                if ((j >= dotCount) && j < (n - dotCount))
                {
                    Console.Write("*");
                }
                if (j >= (n - dotCount))
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            for (int i = 0; i < 2*n; i+=2)
            {
                int dotCount = i / 2;
                if(i>n) {
                    dotCount= ((2*n)-i-1)/2;
                }
                DisplayRow(n, dotCount);
            }
        }
    }
}
