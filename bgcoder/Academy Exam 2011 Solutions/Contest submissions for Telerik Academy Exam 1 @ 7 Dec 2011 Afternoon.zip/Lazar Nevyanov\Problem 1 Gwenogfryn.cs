using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam07
{
    class Problem1
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            
            for (int row = 1,p=1,s=n; row <=n; row++,p++,s--)
            {
                for (int col = 1; col <=n; col++)
                {
                    if (col<=p&&col>=s||col>=p&&col<=s)
                    {
                        Console.Write("*");
                    }
                    else 
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
