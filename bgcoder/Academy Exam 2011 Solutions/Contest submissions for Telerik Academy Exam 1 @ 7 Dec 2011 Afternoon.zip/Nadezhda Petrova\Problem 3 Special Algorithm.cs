using System;

namespace Task3_SpecialAlgorithm
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();

            while (number.Length > 1)
            {
                int digitSum = 0;
                for (int i = 0; i < number.Length; i++)
                {
                    string digitString = number.Substring(i, 1);
                    int digit = new int();
                    if (!int.TryParse(digitString, out digit))
                    {
                        continue;
                    }
                    digitSum = digitSum + digit;
                }
                number = digitSum.ToString();
            }
            Console.WriteLine(number);
        }
    }
}
