using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3_Special_Algorithm_For_The_Special_Olympics
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
            string input = Console.ReadLine();
            input.Replace('.', '0');
            input.Replace(',', '0');
            input.Replace('-', '0');
            string sumOfDigits = input;
            int astrologicalDigit = -1;
            while (astrologicalDigit < 0 || astrologicalDigit > 9)
            {
                astrologicalDigit = 0;
                for (int i = 0; i < sumOfDigits.Length; i++)
                {
                    char currentDigit = sumOfDigits.ElementAt(i);
                    if (currentDigit < '0' || currentDigit > '9')
                    {
                        currentDigit = '0';
                    }
                    astrologicalDigit += Convert.ToInt32(currentDigit.ToString());
                }
                sumOfDigits = astrologicalDigit.ToString();
            }
            Console.WriteLine(astrologicalDigit);
        }
    }
}
