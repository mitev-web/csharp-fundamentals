using System;

    class Program
    {
        public static void Main()
        {
            int px1 = EnterNumber();
            int py1 = EnterNumber();
            int px2 = EnterNumber();
            int py2 = EnterNumber();
            int fx = EnterNumber();
            int fy = EnterNumber();
            int d = EnterNumber();

            //test 1
            //int px1 = 2;
            //int py1 = 5;
            //int px2 = 6;
            //int py2 = 3;
            //int fx = -6;
            //int fy = 3;
            //int d = 9;

            

            
            //test 2
            //int px1 = 2;
            //int py1 = 5;
            //int px2 = 6;
            //int py2 = 3;
            //int fx = -6;
            //int fy = 5;
            //int d = 7;

            ////test 3
            //int px1 = 6;
            //int py1 = 5;
            //int px2 = 2;
            //int py2 = 3;
            //int fx = 0;
            //int fy = 1;
            //int d = -3;

            //test 3
            //int px1 = 0;
            //int py1 = 0;
            //int px2 = 0;
            //int py2 = 0;
            //int fx = 4;
            //int fy = 0;
            //int d = -4;



            int hittingPointX = fx + d;
            int hittingPointY = fy;

            int leftHittingPointX = hittingPointX;
            int leftHittingPointY = hittingPointY + 1;

            int rightHittingPointX = hittingPointX;
            int rightHittingPointY = hittingPointY - 1;

            int frontHittingPointX = hittingPointX + 1;
            int frontHittingPointY = hittingPointY;

            long hittingPercents = 0;

            //check for only one cell for plant and (0.0)
            //if (px1  == 0 && px2 == 0 && py1 == 0 && py2 == 0)
            //{
            //    if (true)
            //    {
            //        if (IsPointInThePlant(px1, py1, px2, py2, hittingPointX, hittingPointY) == true)
            //        {
            //            hittingPercents += 100;   
            //        }
            //    }
            //}
            //hittingpoint
            if (IsPointInThePlant(px1, py1, px2, py2, hittingPointX, hittingPointY) == true)
            {
                hittingPercents += 100;   
            }

            //lefthittingpoint
            if (IsPointInThePlant(px1, py1, px2, py2, leftHittingPointX, leftHittingPointY) == true)
            {
                hittingPercents += 50;
            }

            //righthittingpoint
            if (IsPointInThePlant(px1, py1, px2, py2, rightHittingPointX, rightHittingPointY) == true)
            {
                hittingPercents += 50;
            }

            //center hitting point
            if (IsPointInThePlant(px1, py1, px2, py2, frontHittingPointX, frontHittingPointY) == true)
            {
                hittingPercents += 75;
            }

            ///APPEND % and convert to string
            string hittingPercentsAsString = hittingPercents + "%";
            Console.WriteLine(hittingPercentsAsString);
        }

        public static int EnterNumber()
        {
            string inputNumber = Console.ReadLine();
            int number = Convert.ToInt32(inputNumber);
            return number;

        }
        public static bool IsPointInThePlant(int px1, int py1, int px2, int py2, int x, int y)
        {
            int maxPx = Math.Max(px1, px2);
            int minPx = Math.Min(px1, px2);
            px1 = minPx;
            px2 = maxPx;

            int maxPy = Math.Max(py1, py2);
            int minPy = Math.Min(py1, py2);
            py1 = maxPy;
            py2 = minPy;

            if (x >= px1 && x <= px2)
            {
                if (y >= py2 && y <= py1)
                {
                    return true;
                }
            }

            return false;
        }
    }

