using System;

namespace _05.StraightSequance
{
    class Program
    {
        static void Main()
        {
            int mask = 1;
            int zeros = 0;
            int ones = 0;
            int twos = 0;
            int threes = 0;
            int fours = 0;
            int fives = 0;
            int sixes = 0;
            int sevens = 0;
            int number0 = 0;
            int number1 = 0;
            int number2 = 0;
            int number3 = 0;
            int number4 = 0;
            int number5 = 0;
            int number6 = 0;
            int number7 = 0;
            int result = 0;

            for (int g = 0; g <= 7; g++)
	        {
            long givenNumber = long.Parse(Console.ReadLine());// Next number
	        for (int i = 0; i <= Math.Log(givenNumber, 2); i++)
	            {
                    mask = 1 << i;
	                bool checker = (mask & givenNumber) != 0;
                    if (checker)
                         {
                            switch (i)
                                {
                                case 0: zeros++; break;
	                            case 1: ones++; break;
	                            case 2: twos++; break;
	                            case 3: threes++; break;
	                            case 4: fours++; break;
	                            case 5: fives++; break;
	                            case 6: sixes++; break;
	                            case 7: sevens++; break;
	                            default: break;
	                            }
	                     }
                 }
	       }
	   }
    }
}