using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Izpit07._12._11
{
    class Program
    {
        static void Main(string[] args)
        {
            

            int n = int.Parse(Console.ReadLine());
            int nn = n - 2;
            string[][] sandGlass = new string[nn][];
            for (byte x = 0; x < nn; x++)
            {
                sandGlass[x] = new string[n];
            }

            int row = (n-2)/2 +1;

            for (byte i = 0; i < nn; i++)
            {
                for (byte j = 0; j < n ; j++)
                {

                    if (i < row)
                    {
                        sandGlass[i][j] = "*";
                        if (i >= j)
                        {
                            sandGlass[i][j] = ".";
                        }

                        if (j >= n - 1 - i)
                        {
                            sandGlass[i][j] = ".";
                        }
                    }
                    if (i >= row)
                    {
                        sandGlass[i][j] = "*";

                        if (nn - i > j)
                        {
                            sandGlass[i][j] = ".";
                        }

                        if (j > i + 1)
                        {
                            sandGlass[i][j] = ".";
                        }

                    }
                        
                    
                   
                }
            }

            ////////////////////////////////////////////top
            
            for (int i = 0; i < n ; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            /////////////////////////////////////////middle

            foreach (var array in sandGlass)
            {
                foreach (var item in array)
                {
                    Console.Write(item);
                }
                Console.WriteLine();
            }
            //////////////////////////////////////////////bottom
            for (int i = 0; i < n ; i++)
            {
                Console.Write("*");
            }
        }
    }
}
