using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Algorithm
{
    class Program
    {
        public static int Metod(string num, int sum)
        {
            List<char> number = new List<char>(num.Length);

            for (int i = 0; i < num.Length; i++)
            {
                number.Add(num[i]);
            }

            number.Sort();
            number.Reverse();

            for (int i = 0; i < number.Count; i++)
            {
                if (number[i] < '0')
                {
                    break;
                }
                sum = sum + Convert.ToInt32(Convert.ToString(number[i]));
            }

            return sum;
            
        }

        static void Main(string[] args)
        {
            string num = Console.ReadLine();
            int sum = 0;
            sum = Metod(num, sum);
            while (true)
            {
                if (sum < 10)
                {
                    Console.WriteLine(sum);
                    break;
                }
                else
                {
                    int suma = 0;
                   sum = Metod(sum.ToString(), suma);
                }
            }
        }
    }
}