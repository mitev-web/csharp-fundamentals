using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace test_zad_2
{
    class Program
    {
        static void Main(string[] args)
        {
 
            double p1x, p1y, p2x, p2y, fighterX, fighterY, distance;
            int totalDamage = 0;
            double inpactX, inpactY;
            p1x = double.Parse(Console.ReadLine());
            p1y = double.Parse(Console.ReadLine());
            p2x = double.Parse(Console.ReadLine());
            p2y = double.Parse(Console.ReadLine());
            fighterX = double.Parse(Console.ReadLine());
            fighterY = double.Parse(Console.ReadLine());
            distance = double.Parse(Console.ReadLine());
 
            //if (p1x > p2x)
            //{
            //    double exchange = p1x;
            //    p1x = p2x;
            //    p1x = exchange;
            //}
            if (p1y < p2y)
            {
                double exchange = p1y;
                p1y = p2y;
                p1y = exchange;
            }
 
 
 
            // check if direct inpact did hit
            inpactX = fighterX + distance;
            inpactY = fighterY;
 
            if (inpactX >= p1x && inpactX <= p2x)
            {
                if (inpactY <= p1y && inpactY >= p2y)
                {
                    totalDamage += 100;
                }
            }
 
            // check if did hit in front of direct inpact
            inpactX = fighterX + distance + 1;
            inpactY = fighterY;
 
            if (inpactX >= p1x && inpactX <= p2x)
            {
                if (inpactY <= p1y && inpactY >= p2y)
                {
                    totalDamage += 75;
                }
            }
 
            // check if did hit left of direct in
            inpactX = fighterX + distance;
            inpactY = fighterY - 1;
 
            if (inpactX >= p1x && inpactX <= p2x)
            {
                if (inpactY <= p1y && inpactY >= p2y)
                {
                    totalDamage += 50;
                }
            }
 
            // check if did hit right of direct in
            inpactX = fighterX + distance;
            inpactY = fighterY + 1;
 
            if (inpactX >= p1x && inpactX <= p2x)
            {
                if (inpactY <= p1y && inpactY >= p2y)
                {
                    totalDamage += 50;
                }
            }
 
            Console.WriteLine("{0}%", totalDamage);
 
 
 
        }// end  static void Main(string[] args)
    }
}