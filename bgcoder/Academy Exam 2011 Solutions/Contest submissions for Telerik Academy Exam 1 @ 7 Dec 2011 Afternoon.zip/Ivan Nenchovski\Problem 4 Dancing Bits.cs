using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.Dancing_Bits
{
    class Program
    {
        public static List<char> ConcatenatedNumbers = new List<char>();

        public static int GetFirstRaisedBitPosition(int x)
        {
            int result = -1;
            for (int i = sizeof(uint) * 8 - 1; i >= 0; i--)
            {
                if ((x & (1 << i)) != 0)
                {
                    result = i;
                    break;
                }
            }
            return result;
        }

        public static void InsertBinaryRepresentation(int x)
        {
            for (int i = GetFirstRaisedBitPosition(x); i >= 0; i--)
            {
                ConcatenatedNumbers.Add(((x & (1 << i)) != 0) ? '1' : '0');
            }
        }

        public static int CountDancers(int dancersInGroup)
        {
            int lastEqualitySequenceLength = 1;
            int dancingBitSequences = 0;
            for (int i = 0; i < ConcatenatedNumbers.Count; i++)
            {
                if (i != ConcatenatedNumbers.Count - 1 && (ConcatenatedNumbers.ElementAt(i) == ConcatenatedNumbers.ElementAt(i + 1)))
                {
                    lastEqualitySequenceLength++;
                }
                else
                {
                    if (lastEqualitySequenceLength == dancersInGroup)
                    {
                        dancingBitSequences++;
                    }
                    lastEqualitySequenceLength = 1;
                }
            }
            return dancingBitSequences;
        }

        static void Main(string[] args)
        {
            int dancersToCount = Convert.ToInt32(Console.ReadLine());
            int numbersToConcatenate = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numbersToConcatenate; i++)
            {
                int newInputNumber = Convert.ToInt32(Console.ReadLine());
                InsertBinaryRepresentation(newInputNumber);
            }
            int dancingGroups = CountDancers(dancersToCount);
            Console.WriteLine(dancingGroups);
        }
    }
}
