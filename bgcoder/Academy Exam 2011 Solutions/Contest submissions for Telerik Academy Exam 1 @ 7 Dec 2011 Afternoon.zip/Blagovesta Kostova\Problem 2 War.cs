using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WarProject
{
    class Program
    {
        static void Main(string[] args)
        {
            int pXOne = int.Parse(Console.ReadLine());

            int pYOne = int.Parse(Console.ReadLine());

            int pXTwo = int.Parse(Console.ReadLine());

            int pYTwo = int.Parse(Console.ReadLine());

            int fX = int.Parse(Console.ReadLine());

            int fY = int.Parse(Console.ReadLine());

            int d = int.Parse(Console.ReadLine());

            int result;
            result = 0;

            pXOne = Math.Min(pXOne, pXTwo);
            pYOne = Math.Max(pYOne, pYTwo);

            pXTwo = Math.Max(pXOne, pXTwo);
            pYTwo = Math.Min(pXOne, pYTwo);

           
            if (((fX + d) >= pXOne) && ((fX + d) <= pXTwo) && (fY <= pYOne) && (fY >= pYTwo))
            {
                result = result + 100;
            }
            if (((fX + d) >= pXOne) && ((fX + d) <= pXTwo) && ((fY - 1) < pYOne) && ((fY - 1) > pYTwo))
            {
                result = result + 50;
            }
            if (((fX + d) >= pXOne) && ((fX + d) <= pXTwo) && ((fY + 1) < pYOne) && ((fY + 1) > pYTwo))
            {
                result = result + 50;
            }
            if (((fX + d + 1) >= pXOne) && ((fX + d + 1) <= pXTwo) && (fY <= pYOne) && (fY > pYTwo))
            {
                result = result + 75;
            }
            
            Console.WriteLine("{0}%", result);
        }
    }
}
