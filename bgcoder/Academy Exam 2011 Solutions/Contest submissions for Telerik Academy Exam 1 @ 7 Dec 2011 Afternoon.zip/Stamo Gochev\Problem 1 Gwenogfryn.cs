using System;

    class Program
    {
        public static void Main(string[] args)
        {
            int N = EnterNumber();
            int numberOfLeftDots = 0;
            int numberOfRightDots = 0;
            int numberOfStars = N;

            for (int star = numberOfStars; star >= 1; star = star - 2)
            {
                for (int leftdot = 1; leftdot <= numberOfLeftDots; leftdot++)
                {
                    Console.Write('.');
                }

                for (int printedStar = 1; printedStar <= star; printedStar++)
                {
                    Console.Write('*');
                }

                for (int rightDot = 1; rightDot <= numberOfRightDots; rightDot++)
                {
                    Console.Write('.');
                }

                Console.WriteLine();

                numberOfLeftDots++;
                numberOfRightDots++;
                
            }

            numberOfLeftDots = (N - 3) / 2;
            numberOfRightDots = numberOfLeftDots;
            numberOfStars = 3;

            for (int star = numberOfStars; star <= N; star = star + 2)
            {
                for (int leftdot = 1; leftdot <= numberOfLeftDots; leftdot++)
                {
                    Console.Write('.');
                }

                for (int printedStar = 1; printedStar <= star; printedStar++)
                {
                    Console.Write('*');
                }

                for (int rightDot = 1; rightDot <= numberOfRightDots; rightDot++)
                {
                    Console.Write('.');
                }

                Console.WriteLine();

                numberOfLeftDots--;
                numberOfRightDots--;

            }

            
        }

        public static int EnterNumber()
        {
            string inputNumber = Console.ReadLine();
            int number = Convert.ToInt32(inputNumber);
            return number;

        }
    }

