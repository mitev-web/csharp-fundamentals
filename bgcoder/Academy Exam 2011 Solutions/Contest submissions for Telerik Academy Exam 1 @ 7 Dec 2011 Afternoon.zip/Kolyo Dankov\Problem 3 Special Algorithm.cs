using System;

namespace Test
{
    class Program
    {
        static void Main()
        {
            int number = int.Parse(Console.ReadLine());
            int digit = 0;
            int sum = 0;

            if (number < 0)
            {
                number = -number;
            }

            do
            {
                do
                {
                    digit = (number % 10);
                    number = number / 10;
                    sum = sum + digit;
                }
                while (number >= 1);
                number = sum;
                sum = 0;

            }
            while (number > 9);
            
            Console.WriteLine(number);
                       

        }
    }
}