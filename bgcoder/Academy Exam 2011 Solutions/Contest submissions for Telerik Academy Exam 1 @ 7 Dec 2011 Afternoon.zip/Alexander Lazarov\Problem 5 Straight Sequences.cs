using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            int mask = 1;
            int zeros = 0;
            int ones = 0;
            int twos = 0;
            int threes = 0;
            int fours = 0;
            int fives = 0;
            int sixes = 0;
            int sevens = 0;

            for (int g = 0; g <= 7; g++)
            {
                long givenNumber = long.Parse(Console.ReadLine());// Next number
                for (int i = 0; i <= Math.Log(givenNumber, 2); i++)
                {
                    mask = 1 << i;
                    bool checker = (mask & givenNumber) != 0;
                    if (checker)
                    {
                        switch (i)
                        {
                            case 0: zeros++; break;
                            case 1: ones++; break;
                            case 2: twos++; break;
                            case 3: threes++; break;
                            case 4: fours++; break;
                            case 5: fives++; break;
                            case 6: sixes++; break;
                            case 7: sevens++; break;
                            default: break;
                        }
                    }
                }
            }

            for (int j = 0; j <= 7; j++)
            {

                if (zeros > 0)
                {
                    zeros += 1;
                }
                if (ones > 0)
                {
                    ones += 1;
                }
                if (twos > 0)
                {
                    twos+=1;
                }
                if (threes > 0)
                {
                    threes+=1;
                }
                if (fours > 0)
                {
                    fours += 1;
                }
                if (fives > 0)
                {
                    fives += 1;
                }

                if (sixes > 0)
                {
                    sixes += 1;
                }
                if (sevens > 0)
                {
                    sevens += 1;
                }

                
            }
            int max = Math.Max(Math.Max(Math.Max(Math.Max(Math.Max((Math.Max((Math.Max(ones, twos)), threes)), zeros),fives),sixes),fours),sevens);
            
            if (max == zeros)
            {
                Console.WriteLine("1");
            }
            else if (max == ones)
            {
                Console.WriteLine("2");
            }
            else if (max == twos)
            {
                Console.WriteLine("3");
            }
            else if (max == threes)
            {
                Console.WriteLine("4");
            }
            else if (max == fours)
            {
                Console.WriteLine("5");
            }
            else if (max == fives)
            {
                Console.WriteLine("6");
            }
            else if (max == sixes)
            {
                Console.WriteLine("7");
            }
            else if (max == sevens)
            {
                Console.WriteLine("8");
            }
            Console.WriteLine("2");
        }
        }
    }
