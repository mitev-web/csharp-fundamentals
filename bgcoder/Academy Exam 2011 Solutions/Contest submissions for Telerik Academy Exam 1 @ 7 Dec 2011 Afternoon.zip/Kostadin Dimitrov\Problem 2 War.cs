using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02.War
{
    class War
    {
        static void Main(string[] args)
        {
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int distance = int.Parse(Console.ReadLine());
            int top = 0;
            int bottom = 0;
            int left = 0;
            int right = 0;
            int target = fX + distance;

            if (pY1 > pY2)
            {
                top = pY1;
                bottom = pY2;
            }
            else
            {
                top = pY2;
                bottom = pY1;
            }
            if (pX1 > pX2)
            {
                left = pX2;
                right = pX1;
            }
            else
            {
                left = pX1;
                right = pX2;
            }

            bool targetInPlant = ((top >= fY) && (bottom <= fY) && (left <= target) && (right >= target));
            bool targetOnLeft = (target + 1 == left) && (top >= fY) && (bottom <= fY);
            bool targetOnTopOrBottom = (fY + 1 == bottom) || (fY - 1 == top) && (left <= target) && (right >= target);
            if (targetInPlant == true)
            {
                Console.WriteLine("225%");
            }
            else if (targetOnLeft == true)
            {
                Console.WriteLine("75%");
            }
            else if (targetOnTopOrBottom == true)
            {
                Console.WriteLine("50%");
            }
            else
            {
                Console.WriteLine("0%");
            }
 
                                                                           
        }
    }
}
