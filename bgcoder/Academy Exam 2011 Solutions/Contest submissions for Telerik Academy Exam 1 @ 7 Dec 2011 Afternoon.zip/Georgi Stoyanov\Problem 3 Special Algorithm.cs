using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            string stringNumber = Console.ReadLine();
            int size = stringNumber.Length;
            char[] convNumber = stringNumber.ToCharArray();
            int intVal;
            int firstSum = 0;
            for (int i = 0; i < size; i++)
            {   
                intVal = (int)(convNumber[i] - '0');
                if (intVal >= 0 && intVal <= 9)
                    firstSum += intVal;
            }
            int number = firstSum;
            int sum = firstSum;
            int buff = 0;
            while (number > 9)
            {
                buff = number;
                sum = 0;
                while (buff != 0)
                {
                    sum += buff % 10;
                    buff = (buff / 10);
                }
                number = sum;
            }
            Console.WriteLine(sum);
        }
    }
}
