using System;
using System.Numerics;
  
namespace Problem05
{
    class Problem05
    {
        static void Main(string[] args)
        {
  
            int[] rows = new int[8];
  
            for (int i = 0; i < 8; i++)
            {
                rows[i] = int.Parse(Console.ReadLine());
            }
  
  
            int[] columns = new int[8];
  
            for (int column = 0; column < 8; column++)
            {
                for (int row = 0; row < 8; row++)
                {
                    if ((rows[row] & (1 << column)) != 0)
                    {
                        columns[column] = columns[column] | (1 << row);
                    }
                }
            }
  
            //for (int i = 0; i < 8; i++)
            //{
            //    Console.WriteLine(columns[i]);
            //}
            int tempRow = 0;
            int tempColumn = 0;
            int counter = 1;
            int lines = 0;
            int maxcounter = 1;
  
            for (int row = 0; row < 8; row++)
            {
                tempColumn = rows[row] & 1;
                counter = 1;
                for (int column = 1; column < 8; column++)
                {
                    if (tempColumn != 0 )
                    {
                        if ((rows[row] & (1 << column)) != 0)
                        {
                            counter++;
                        }
                        else
                        {
                            tempColumn = rows[row] & (1 << column);
                            counter = 1;
                        }
                    }
                    else
                    {
                        tempColumn = rows[row] & (1 << column);
                        counter = 1;
                    }
                    if (counter > maxcounter)
                    {
                        maxcounter = counter;
                    }
                }
  
            }
  
            for (int column = 0; column < 8; column++)
            {
                tempRow = columns[column] & 1;
                counter = 1;
                for (int row = 1; row < 8; row++)
                {
                    if (tempRow != 0)
                    {
                        if ((columns[column] & (1 << row)) != 0)
                        {
                            counter++;
                        }
                        else
                        {
                            tempRow = columns[column] & (1 << column);
                            counter = 1;
                        }
                    }
                    else
                    {
                        tempRow = columns[column] & (1 << column);
                        counter = 1;
                    }
                    if (counter > maxcounter)
                    {
                        maxcounter = counter;
                    }
                }
            }
  
            for (int row = 0; row < 8; row++)
            {
                tempColumn = rows[row] & 1;
                counter = 1;
                for (int column = 1; column < 8; column++)
                {
                    if (tempColumn != 0)
                    {
                        if ((rows[row] & (1 << column)) != 0)
                        {
                            counter++;
                        }
                    }
                    else
                    {
                        tempColumn = rows[row] & (1 << column);
                        counter = 1;
                    }
                    if (counter == maxcounter)
                    {
                        lines++;
                    }
                }
  
            }
  
            for (int column = 0; column < 8; column++)
            {
                tempRow = columns[column] & 1;
                counter = 1;
                for (int row = 1; row < 8; row++)
                {
                    if (tempRow != 0)
                    {
                        if ((columns[column] & (1 << row)) != 0)
                        {
                            counter++;
                        }
                    }
                    else
                    {
                        tempRow = columns[column] & (1 << column);
                        counter = 1;
                    }
                    if (counter == maxcounter)
                    {
                        lines++;
                    }
                }
            }
  
            Console.WriteLine(maxcounter);
            Console.WriteLine(lines);
        }
    }
}