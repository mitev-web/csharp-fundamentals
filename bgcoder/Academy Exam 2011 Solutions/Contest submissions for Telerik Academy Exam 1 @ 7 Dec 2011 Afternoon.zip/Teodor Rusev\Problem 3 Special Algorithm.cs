using System;

namespace SpecialAlgorithm
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {
            string buffer;
            decimal n, temp, sum = 0;
            buffer = Console.ReadLine();
            decimal.TryParse(buffer, out n);

            temp = Math.Abs(n);
            buffer = temp.ToString();
            
            sbyte[] digit = new sbyte[buffer.Length];

            if (buffer.Length == 1)
            {
                if (n <= 9)
                {
                    Console.WriteLine(n);
                }
            }
            else
            {
                temp = n;
                do
                {
                    // putting the digits into array
                    for (int i = 0; i < buffer.Length; i++)
                    {
                        if (n < 0)
                        {
                            if (i != buffer.Length - 1)
                            {
                                digit[i] = (sbyte)(-1 * (temp % 10));
                                temp = temp / 10;
                            }
                            else
                            {
                                digit[i] = (sbyte)(temp % 10);
                                temp = temp / 10;
                            }
                        }
                        else
                        {
                            digit[i] = (sbyte)(temp % 10);
                            temp = temp / 10;
                        }
                    }
                    // summing the digits
                    for (int i = 0; i < buffer.Length; i++)
                    {
                        sum = sum + digit[i];
                    }
                    buffer = sum.ToString();
                    temp = sum;
                } while (sum > 9);

                Console.WriteLine(sum);
            }
        }
    }
}