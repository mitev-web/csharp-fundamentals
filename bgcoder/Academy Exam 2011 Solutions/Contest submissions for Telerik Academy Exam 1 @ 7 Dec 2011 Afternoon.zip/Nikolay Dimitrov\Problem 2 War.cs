using System;
class War
{
    static void Main()
    {
        int px1 = int.Parse(Console.ReadLine());
        int py1 = int.Parse(Console.ReadLine());
        int px2 = int.Parse(Console.ReadLine());
        int py2 = int.Parse(Console.ReadLine());
        int fx = int.Parse(Console.ReadLine());
        int fy = int.Parse(Console.ReadLine());
        int d = int.Parse(Console.ReadLine());
        int damage = 0;
        fx += d;
        int fx1 = fx+1;
        int fyLeft = fy + 1;
        int fyRight = fy - 1;
        
        if ((((fy >= py1) && (fy <= py2)) || ((fy <= py1) && (fy >= py2))) && (((fx >= px1) && (fx <= px2))||((fx <= px1) && (fx >= px2))))
        {
            damage += 100;
        }
        if ((((fy >= py1) && (fy <= py2)) || ((fy <= py1) && (fy >= py2))) && (((fx1 >= px1) && (fx1 <= px2)) || ((fx1 <= px1) && (fx1 >= px2))))
        {
            damage += 75;
        }
        if ((((fyLeft >= py1) && (fyLeft <= py2)) || ((fyLeft <= py1) && (fyLeft >= py2))) && (((fx >= px1) && (fx <= px2)) || ((fx <= px1) && (fx >= px2))))
        {
            damage += 50;
        }
        if ((((fyRight >= py1) && (fyRight <= py2)) || ((fyRight <= py1) && (fyRight >= py2))) && (((fx >= px1) && (fx <= px2)) || ((fx <= px1) && (fx >= px2))))
        {
            damage += 50;
        }


        Console.WriteLine("{0}%",damage);



    }
}