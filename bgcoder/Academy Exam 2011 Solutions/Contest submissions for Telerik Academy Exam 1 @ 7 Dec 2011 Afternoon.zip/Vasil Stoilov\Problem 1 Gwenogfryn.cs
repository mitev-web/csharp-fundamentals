using System;

class Gwenogfryn
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        if (n % 2 == 1 && n >= 3 && n <= 101)
        {
            int counter = (n - 1) / 2;
            int c = (n + 1) / 2;
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    if (i == 1 || i == n)
                    {
                        Console.Write("*");
                    }
                    else if (((j < i && j < ((n + 1) / 2) || (j > n - i + 1))) && i <= (n+1)/2)
                    {
                        Console.Write(".");
                    }
                    else if ((j <= n-i || j >= i+1 ) && i > (n + 1) / 2)
                    {
                        Console.Write(".");
                    } 
                    else
                    {
                        Console.Write("*");
                    }
                    

                }
                Console.WriteLine();

            }
        }
    }
}