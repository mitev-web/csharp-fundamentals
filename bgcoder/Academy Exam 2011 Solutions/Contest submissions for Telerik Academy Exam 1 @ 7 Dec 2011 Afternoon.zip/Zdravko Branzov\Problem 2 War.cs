using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace War
{
    class Program
    {
        static void Main(string[] args)
        {
            double x1 =int.Parse(Console.ReadLine());
            double y1 =int.Parse(Console.ReadLine());
            double x2 =int.Parse(Console.ReadLine());
            double y2 =int.Parse(Console.ReadLine());
            double Fx = int.Parse(Console.ReadLine());
            double Fy =int.Parse(Console.ReadLine());
            double D = int.Parse(Console.ReadLine());
            int hit = 0;
            Fx = Fx + 0.5;
            Fy = Fy + 0.5;
            y1 = y1 + 1;
            x2 = x2 + 1;
 
 
            if ((Fx + D < x2) && (Fx + D > x1) && (Fy < y1) && (Fy > y2))
            {
                hit = hit + 100;
                 
            }
 
            if ((Fx + D + 1 < x2) && (Fx + D + 1 > x1) && (Fy < y1) && (Fy > y2))
            {
                hit = hit + 75;
            }
 
            if ((Fx + D < x2) && (Fx + D > x1) && (Fy + 1 < y1 ) && (Fy + 1 > y2))
            {
                hit = hit + 50;
 
            }
 
            if ((Fx + D < x2) && (Fx + D > x1) && (Fy - 1 < y1) && (Fy - 1 > y2))
            {
                hit = hit + 50;
 
            }
 
            Console.WriteLine("{0}%",hit);
 
        }
    }
}