using System;
using System.Numerics;

namespace Task4_DancingBits
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            int k = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());
            BigInteger sequence = new BigInteger();
            BigInteger allBitsCounter = 0;
            for (int i = 0; i < n; i++)
            {
                uint currentNumber = Convert.ToUInt32(Console.ReadLine());
                int bitsCounter = CountBits(currentNumber);
                sequence = (sequence << bitsCounter) | currentNumber;
                allBitsCounter = allBitsCounter + bitsCounter;
            }

            byte prevBit = BitAtPosition(sequence, 0);
            ulong result = 0;
            int currentSequenceCount = 1;
            for (int i = 1; i < allBitsCounter; i++)
            {
                byte currentBit = BitAtPosition(sequence, i);
                if (prevBit == currentBit)
                {
                    currentSequenceCount++;
                }
                else
                {
                    if (currentSequenceCount == k)
                    {
                        result++;
                    }
                    currentSequenceCount = 1;
                }
                prevBit = currentBit;
            }
            if (currentSequenceCount == k)
            {
                result++;
            }

            Console.WriteLine(result);
        }

        private static byte BitAtPosition(BigInteger number, int position)
        {
            BigInteger mask = 1 << position;
            if ((number & mask) == 0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        private static int CountBits(uint number)
        {
            int bitsCounter = 0;
            while (number > 0)
            {
                bitsCounter++;
                number = number / 2;
            }
            return bitsCounter;
        }
    }
}
