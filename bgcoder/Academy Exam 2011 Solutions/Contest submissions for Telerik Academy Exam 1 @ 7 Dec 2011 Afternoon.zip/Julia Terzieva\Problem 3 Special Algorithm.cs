using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            double N = double.Parse(Console.ReadLine());
            int sum = 0;
            int sum1 = 1;
            if (N==0)
            {
                Console.WriteLine(0);
            }

            while (N != 0)
            {
                sum +=(int) (N % 10);
                N /= 10;

            }
            
            if (sum<=9 && sum>0)
            {
                Console.WriteLine(sum);
            }
            if (sum > 9)
            {
                sum1 +=(int) (sum % 10);
                sum /= 10;
                Console.WriteLine(sum1);
            }
            if (sum < 0)
            {
                sum = -sum;
                sum1 +=(int) sum % 10;
                sum /= 10;
                Console.WriteLine(sum1);
            }
        }
    }
}
