using System;


namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int p = n;


            for (int i = 0; i < n; i++)
            {
                Console.Write("*");

            }
            Console.WriteLine();
            p--;

            for (int firstHalf = 0; firstHalf < (n / 2); firstHalf++)
            {
                
           


                    for (int i = 0; i <n - p; i++)
                    {
                        Console.Write(".");
                    }
                    for (int j = 0; j < p - 1 - firstHalf; j++)
                    {
                        Console.Write("*");
                    }
                    for (int k= 0; k < n - p; k++)
                    {
                        Console.Write(".");
                    }
                    p--;
                    Console.WriteLine();
            }
            p = p + 2;
            for (int secondHalf = (n / 2) - 1; secondHalf> 0; secondHalf--)
            {




                for (int i = 0; i < n - p; i++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < p - secondHalf; j++)
                {
                    Console.Write("*");
                }
                for (int k = 0; k < n - p; k++)
                {
                    Console.Write(".");
                }
                p++;
                Console.WriteLine();
            }

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");

            }
            Console.WriteLine();

        }
    }
}
