using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StraightSequences
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n0 = byte.Parse(Console.ReadLine());
            byte n1 = byte.Parse(Console.ReadLine());
            byte n2 = byte.Parse(Console.ReadLine());
            byte n3 = byte.Parse(Console.ReadLine());
            byte n4 = byte.Parse(Console.ReadLine());
            byte n5 = byte.Parse(Console.ReadLine());
            byte n6 = byte.Parse(Console.ReadLine());
            byte n7 = byte.Parse(Console.ReadLine());

            int first = n0;
            int second = n1;
            int third = n2;
            int forth = n3;
            int fifth = n4;
            int sixth = n5;
            int seventh = n6;
            int eighth = n7;

            int numberOfLongestSequence = 0;
            int currentBit;
            int max = 0;

            for (int i = 0; i < 8; i++)
            {
                int currentMax = 0;

                currentBit = first % 2;
                first = first / 2;
                if (currentBit==1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = second % 2;
                second = second / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = third % 2;
                third = third / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = forth % 2;
                forth = forth / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = fifth % 2;
                fifth = fifth / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = sixth % 2;
                sixth = sixth / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = seventh % 2;
                seventh = seventh / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                currentBit = eighth % 2;
                eighth = eighth / 2;
                if (currentBit == 1)
                {
                    currentMax++;
                }
                else
                {
                    if (currentMax > max)
                    {
                        max = currentMax;
                        numberOfLongestSequence = 1;
                    }
                    if (currentMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentMax = 0;
                }

                if (currentMax == max)
                {
                    numberOfLongestSequence++;
                }

                if (currentMax > max)
                {
                    max = currentMax;
                    numberOfLongestSequence = 1;
                }
                
            }

            int currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n0 % 2;
                n0 = (byte)(n0 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n1 % 2;
                n1 = (byte)(n1 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n2 % 2;
                n2 = (byte)(n2 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n3 % 2;
                n3 = (byte)(n3 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n4 % 2;
                n4 = (byte)(n4 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n5 % 2;
                n5 = (byte)(n5 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n6 % 2;
                n6 = (byte)(n6 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            currentReverseMax = 0;

            for (int i = 0; i < 8; i++)
            {
                currentBit = n7 % 2;
                n7 = (byte)(n7 / 2);
                if (currentBit == 1)
                {
                    currentReverseMax++;
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                }
                else
                {
                    if (currentReverseMax > max)
                    {
                        max = currentReverseMax;
                        numberOfLongestSequence = 0;
                    }
                    if (currentReverseMax == max)
                    {
                        numberOfLongestSequence++;
                    }
                    currentReverseMax = 0;
                }
            }

            Console.WriteLine(max);
            Console.WriteLine(numberOfLongestSequence);
        }
    }
}
