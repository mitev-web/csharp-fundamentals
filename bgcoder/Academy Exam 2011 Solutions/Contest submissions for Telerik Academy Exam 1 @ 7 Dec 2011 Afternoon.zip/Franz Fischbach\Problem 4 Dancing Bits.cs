using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test_zadacha_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string concentration="";
            int n, k;
            k = Convert.ToInt32( Console.ReadLine());
            n = Convert.ToInt32(Console.ReadLine());
            int sumOfDancing = 0;

            // input
            for (int i = 0; i < n; i++) 
            {
                int input = Convert.ToInt32(Console.ReadLine());
                concentration += Convert.ToString(input, 2);
            }// end input

          
            int currentCount = 1;
            for (int i = 1; i < concentration.Length; i++)
            {
                if (concentration[i - 1] != concentration[i])
                {
                    if (currentCount == k)
                    {
                        sumOfDancing++;
                    }
                    currentCount = 1;
                }
                else
                {
                    currentCount++;
                }

                // special case
                if (i == concentration.Length - 1 && k == currentCount)
                {
                    sumOfDancing++;
                }
            }// end  for (int i = 1; i < concentration.Length; i++)
            
            

            Console.WriteLine(sumOfDancing);
        }
    }
}
