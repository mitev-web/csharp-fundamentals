using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace TaskThree
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            BigInteger n1=(BigInteger)Math.Abs(n);
            decimal n3 = (decimal)n - (int)n;
            BigInteger n2 = 10000000000000000000L*(BigInteger)n3;
            BigInteger sum=0;
            BigInteger sum2 = 0;
            BigInteger sum3;
            bool flag1 = true;
            bool flag2=true;
            bool flag3 = true;
            do
            {
                if (flag1)
                {
                    sum += n1 % 10;
                    n1 /= 10;
                    if (n1 == 0)
                        flag1 = false;
                }
                if (flag2)
                {
                    sum2 += n2 % 10;
                    n2 /= 10;
                    if (n2 == 0)
                        flag2 = false;
                }
            } while (flag1||flag2);
            sum3 = sum + sum2;
            if (sum3 > 9)
            {
                n1 = sum3;
                sum3 =0;
                while (n1 != 0&&flag3)
                {
                    sum3 += n1 % 10;
                    n1 /= 10;
                    if (n1 == 0 && sum3 >9)
                    {
                        n1 = sum3;
                        sum3 = 0;
                        flag3 = true;
                    }
                    else if (n1 == 0 && sum3 <= 9)
                    {
                        flag3 = false;
                    }
                }
            }
            Console.WriteLine(sum3);
        }
    }
}