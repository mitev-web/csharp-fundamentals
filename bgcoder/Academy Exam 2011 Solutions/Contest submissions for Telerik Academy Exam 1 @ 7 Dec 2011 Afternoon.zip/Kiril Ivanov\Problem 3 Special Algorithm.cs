using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Special_Algorithm
{
    class Program
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-Us");
            double x = 0;
            double n = double.Parse(Console.ReadLine());
            n = Math.Abs(n);
            string number = Convert.ToString(n);
            int length = number.Substring(number.IndexOf(".") + 1).Length;
            double n1 = n % 10;
            string number1 = Convert.ToString(n1);
            int length1 = number1.Substring(number1.IndexOf(".") + 1).Length;
            if (length1 > 1)
            {
                for (int i = 1; i <= length; i++)
                {
                    n = n * 10;
                }
                double z = n;
                for (int i = 0; i <= (n % 100); i++)
                {
                    double b = z % 10;
                    x += b;
                    z = (int)z / 10;
                }
                int c = (int)x % 9;
                switch (c)
                {
                    case 1: Console.WriteLine(1);
                        break;
                    case 2: Console.WriteLine(2);
                        break;
                    case 3: Console.WriteLine(3);
                        break;
                    case 4: Console.WriteLine(4);
                        break;
                    case 5: Console.WriteLine(5);
                        break;
                    case 6: Console.WriteLine(6);
                        break;
                    case 7: Console.WriteLine(7);
                        break;
                    case 8: Console.WriteLine(8);
                        break;
                    case 0: Console.WriteLine(9);
                        break;
                }
            }
            if (length1 == 1)
            {
                double z = n;
                for (int i = 0; i < (n%100); i++)
                {
                    double b = z % 10;
                    x += b;
                    z = (int)z / 10;
                }
                int c = (int)x % 9;
                switch (c)
                {
                    case 1: Console.WriteLine(1);
                        break;
                    case 2: Console.WriteLine(2);
                        break;
                    case 3: Console.WriteLine(3);
                        break;
                    case 4: Console.WriteLine(4);
                        break;
                    case 5: Console.WriteLine(5);
                        break;
                    case 6: Console.WriteLine(6);
                        break;
                    case 7: Console.WriteLine(7);
                        break;
                    case 8: Console.WriteLine(8);
                        break;
                    case 0: Console.WriteLine(9);
                        break;
                }
            }
        }
    }
}