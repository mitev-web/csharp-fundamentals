using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_2___War
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int dist = int.Parse(Console.ReadLine());
            int biggerX = Px2;
            int smallerX = Px1;
            int biggerY = Py1;
            int smallerY = Py2;
            int damage = 0;
            if (Px1 > biggerX)
            {
                biggerX = Px1;
                smallerX = Px2;
            }
            if (Py2 > biggerY)
            {
                biggerY = Py2;
                smallerY = Py1;
            }
            if (Fy <= biggerY && Fy >= smallerY && dist != 0)
            {
                if (Fx + dist <= biggerX && Fx + dist >= smallerX)
                {
                    damage += 100;
                    if ((Fy + 1) <= biggerY)
                    {
                        damage += 50;
                    }
                    if ((Fy - 1) >= smallerY)
                    {
                        damage += 50;
                    }
                    if ((Fx + dist + 1) >= smallerX && (Fx + dist + 1) <= biggerX)
                    {
                        damage += 75;
                    }
                    Console.WriteLine("{0}%", damage);
                }
                else if ((Fx + dist) == smallerX - 1)
                {
                    damage += 75;
                    Console.WriteLine("{0}%", damage);
                }
                else
                {
                    Console.WriteLine("{0}%", damage);
                }
            }
            else if (Fy - 1 <= biggerY || Fy+1 >= smallerY)
            {
                if (Fx + dist <= biggerX && Fx + dist >= smallerX && dist !=0)
                {
                    damage = 50;
                    Console.WriteLine("{0}%", damage);
                }
                else
                {
                    Console.WriteLine("{0}%", damage);
                }
            }
            else
            {
                Console.WriteLine("{0}%", damage);
            }
        }
    }
}
