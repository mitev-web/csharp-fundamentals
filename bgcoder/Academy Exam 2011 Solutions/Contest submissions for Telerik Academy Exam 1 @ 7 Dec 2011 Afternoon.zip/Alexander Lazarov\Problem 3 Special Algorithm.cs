using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _3_zad
{
    class Program
    {
        static void Main(string[] args)
        {
            string numString = Console.ReadLine();
            int num = 0;
            bool canConvert = Int32.TryParse(numString, out num);
            if (canConvert == true)
            {
                int n = Math.Abs(num);
                int sum = 0;
                int sumTwo = 0;
                if (num >= 0 && 9 >= num)
                {
                    Console.WriteLine(num);
                }
                else
                {
                    while (n != 0)
                    {
                        sum += n % 10;
                        n /= 10;
                    }
                    if (sum <= 9)
                    {
                        Console.WriteLine(sum);
                    }
                    else if (sum > 9)
                    {
                        while (sum != 0)
                        {

                            sumTwo += sum % 10;
                            sum /= 10;
                        }
                        Console.WriteLine(sumTwo);
                    }
                }
            }

            else
            {
                numString = numString.Replace(".", "");
                BigInteger n = (BigInteger.Parse(numString));
                BigInteger sum = 0;
                BigInteger sumTwo = 0;
                if (n >= 0 && 9 >= n)
                {
                    Console.WriteLine(n);
                }
                else
                {
                    while (n != 0)
                    {
                        sum += (n % 10);
                        n /= 10;
                    }
                    if (sum <= 9)
                    {
                        Console.WriteLine(sum);
                    }
                    else if (sum > 9)
                    {
                        while (sum != 0)
                        {
                            if (sum != 0)
                            {
                                sumTwo += (sum % 10);
                                sum /= 10;
                            }
                        }
                       
                            Console.WriteLine(sumTwo);
                        
                        
                    }


                }

            }
        }
    }
}
