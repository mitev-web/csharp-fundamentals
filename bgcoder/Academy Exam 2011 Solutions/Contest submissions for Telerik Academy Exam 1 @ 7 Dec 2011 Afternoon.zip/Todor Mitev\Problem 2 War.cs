using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class Program
    {
        static void Main(string[] args)
        {
            double x1 = double.Parse(Console.ReadLine());
            double y1 = double.Parse(Console.ReadLine());

            double x2 = double.Parse(Console.ReadLine());
            double y2 = double.Parse(Console.ReadLine());

            double xF = double.Parse(Console.ReadLine());
            double yF = double.Parse(Console.ReadLine());

            double D = double.Parse(Console.ReadLine());
            double distanceFtoX1;
            double distanceFtoX2;
            double distanceFtoY1;
            double distanceFtoY2;
            double hitCellX;
            double hitCellY;
            if (xF <= 0)
                hitCellX = D + xF;
            else
                hitCellX = D - xF;
            hitCellY = yF;

            //if(x1 < x2)
            distanceFtoX1 = (x1 - xF);
            //if(x2 < x1)
            distanceFtoX2 = (x2 - xF);

            //if(y1<y2)
            distanceFtoY1 = (y1 - yF);
            distanceFtoY2 = y2 - yF;
            int damage = 0;
            if (x1 < x2 && y1 < y2)
            {
                if ((hitCellX >= x1) && (hitCellX <= x2) && hitCellY >= y1 && hitCellY <= y2)
                {
                    damage += 100;
                }
                if ((hitCellX + 1) >= x1 && (hitCellX + 1) <= x2 && hitCellY >= y1 && hitCellY <= y2)
                {
                    damage += 75;
                }
                if (hitCellX > x1 && hitCellX < x2 && (hitCellY + 1) >= y1 && (hitCellY + 1) <= y2)
                {
                    damage += 50;
                }
                if (hitCellX >= x1 && hitCellX <= x2 && (hitCellY - 1) >= y1 && (hitCellY - 1) <= y2)
                {
                    damage += 50;
                }

            }
            if (x1 < x2 && y1 > y2)
            {
                if (hitCellX >= x1 && hitCellX <= x2 && hitCellY <= y1 && hitCellY >= y2)
                {
                    damage += 100;
                }
                if ((hitCellX + 1) >= x1 && (hitCellX + 1) <= x2 && hitCellY <= y1 && hitCellY >= y2)
                {
                    damage += 75;
                }
                if (hitCellX >= x1 && hitCellX <= x2 && (hitCellY + 1) <= y1 && (hitCellY + 1) >= y2)
                {
                    damage += 50;
                }
                if (hitCellX >= x1 && hitCellX <= x2 && (hitCellY - 1) <= y1 && (hitCellY - 1) >= y2)
                {
                    damage += 50;
                }
            }
            if (x1 > x2 && y1 < y2)
            {
                if ((hitCellX <= x1) && (hitCellX >= x2) && hitCellY >= y1 && hitCellY <= y2)
                {
                    damage += 100;
                }
                if ((hitCellX + 1) <= x1 && (hitCellX + 1) >= x2 && hitCellY >= y1 && hitCellY <= y2)
                {
                    damage += 75;
                }
                if (hitCellX <= x1 && hitCellX >= x2 && (hitCellY + 1) >= y1 && (hitCellY + 1) <= y2)
                {
                    damage += 50;
                }
                if (hitCellX <= x1 && hitCellX >= x2 && (hitCellY - 1) >= y1 && (hitCellY - 1) <= y2)
                {
                    damage += 50;
                }

            }
            if (x1 > x2 && y1 > y2)
            {
                if ((hitCellX <= x1) && (hitCellX > x2) && hitCellY <= y1 && hitCellY >= y2)
                {
                    damage += 100;
                }
                if ((hitCellX + 1) <= x1 && (hitCellX + 1) >= x2 && hitCellY <= y1 && hitCellY >= y2)
                {
                    damage += 75;
                }
                if (hitCellX <= x1 && hitCellX >= x2 && (hitCellY + 1) <= y1 && (hitCellY + 1) >= y2)
                {
                    damage += 50;
                }
                if (hitCellX <= x1 && hitCellX >= x2 && (hitCellY - 1) <= y1 && (hitCellY - 1) >= y2)
                {
                    damage += 50;
                }

            }
            if (x1 == x2 && y1 == y2)
            {
                if (hitCellX == x1 && hitCellY == y1)
                    damage += 100;
                if (hitCellX + 1 == x1 && hitCellY == y1)
                    damage += 75;
                if (hitCellX == x1 && hitCellY - 1 == y1)
                    damage += 50;
                if (hitCellX == x1 && hitCellY + 1 == y1)
                    damage += 50;
            }
            if (x1 == x2 && y1 < y2)
            {
                if (hitCellX == x1 && hitCellY >= y1 && hitCellY <= y2)
                {
                    damage += 100;
                }
                if (hitCellX + 1 == x1 && hitCellY >= y1 && hitCellY <= y2)
                {
                    damage += 75;
                }
                if (hitCellX == x1 && (hitCellY + 1) >= y1 && (hitCellY + 1) <= y2)
                {
                    damage += 50;
                }
                if (hitCellX == x1 && (hitCellY - 1) >= y1 && (hitCellY - 1) <= y2)
                {
                    damage += 50;
                }
            }
            if (x1 == x2 && y1 > y2)
            {
                if (hitCellX == x1 && hitCellY <= y1 && hitCellY >= y2)
                {
                    damage += 100;
                }
                if (hitCellX + 1 == x1 && hitCellY <= y1 && hitCellY >= y2)
                {
                    damage += 75;
                }
                if (hitCellX == x1 && (hitCellY + 1) <= y1 && (hitCellY + 1) >= y2)
                {
                    damage += 50;
                }
                if (hitCellX == x1 && (hitCellY - 1) <= y1 && (hitCellY - 1) >= y2)
                {
                    damage += 50;
                }
            }
            if (x1 < x2 && y1 == y2)
            {
                if ((hitCellX >= x1) && (hitCellX <= x2) && hitCellY == y1)
                {
                    damage += 100;
                }
                if ((hitCellX + 1) >= x1 && (hitCellX + 1) <= x2 && hitCellY == y1)
                {
                    damage += 75;
                }
                if (hitCellX >= x1 && hitCellX <= x2 && (hitCellY + 1) <= y1)
                {
                    damage += 50;
                }
                if (hitCellX >= x1 && hitCellX <= x2 && (hitCellY - 1) <= y1)
                {
                    damage += 50;
                }
            }
            if (x1 > x2 && y1 == y2)
            {
                if ((hitCellX <= x1) && (hitCellX > x2) && hitCellY == y1)
                {
                    damage += 100;
                }
                if ((hitCellX + 1) <= x1 && (hitCellX + 1) >= x2 && hitCellY == y1)
                {
                    damage += 75;
                }
                if (hitCellX <= x1 && hitCellX >= x2 && (hitCellY + 1) <= y1 )
                {
                    damage += 50;
                }
                if (hitCellX <= x1 && hitCellX >= x2 && (hitCellY - 1) <= y1 )
                {
                    damage += 50;
                }
            }
            Console.WriteLine("{0}%", damage);

        }
    }
}