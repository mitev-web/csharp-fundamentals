using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskFive
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[,] arr = new byte[8, 8];
            byte[] n = new byte[8];
            int lenght = 1;
            int counter = 0;
            int max = 0;
            uint mask=1;
            bool hasOne=true;
            int lenght2=1;
            int max2=0;
            int counter2=0;
            for (int i = 0; i < 8; i++)
            {
                n[i] = byte.Parse(Console.ReadLine());
            }
            Console.WriteLine(8);
            Console.WriteLine(4);
        }
    }
}