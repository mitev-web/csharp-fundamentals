using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());

            if (n < 9&&n>-9)
            {
                if (n < 0)
                {
                    Console.WriteLine(-n);
                }
                else
                {
                    Console.WriteLine(n);
                }
            }
            else 
            {
                int sum = 0;
            }
        }
    }
}
