using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace RealExam
{
    class RealExam
    {
        static void Main(string[] args)
        {
            StraightSequence();
        }

        static void StraightSequence()
        {
            int length = 8;
            bool check = false;
            string[] horizontal = new string[length];

            for (int i = 0; i < length; i++)
            {

                int number = int.Parse(Console.ReadLine());
                if (number > 0) check = true;
                horizontal[i] = Convert.ToString(number, 2).PadLeft(length, '0');
            }

            int countOfMaxLength = 0;
            int maxLength = 0;

            string[] vertical = new string[length];

            if (check)
            {
                for (int k = 0; k < length; k++)
                {
                    StringBuilder sb = new StringBuilder();
                    string[] line = horizontal[k].Split('0');
                    for (int j = 0; j < line.Length; j++)
                    {
                        if (line[j].Length == maxLength && !(line[j].Equals("")))
                        {
                            countOfMaxLength++;
                        }
                        if (maxLength < line[j].Length)
                        {
                            maxLength = line[j].Length;
                            countOfMaxLength = 1;
                        }
                    }
                    for (int i = 0; i < length; i++)
                    {
                        char[] chars = horizontal[i].ToCharArray();
                        sb.Append(chars[k]);
                    }
                    vertical[k] = sb.ToString();
                }

                for (int k = 0; k < horizontal.Length; k++)
                {
                    string[] line = vertical[k].Split('0');
                    for (int j = 0; j < line.Length; j++)
                    {
                        if (line[j].Length == maxLength && !(line[j].Equals("")))
                        {
                            countOfMaxLength++;
                        }
                        if (maxLength < line[j].Length)
                        {
                            maxLength = line[j].Length;
                            countOfMaxLength = 1;
                        }
                    }
                }
            }
            if (maxLength == 1)
            {
                countOfMaxLength = 0;
                for (int i = 0; i < length; i++)
                {
                    for (int j = 0; j < length; j++)
                    {
                        if (horizontal[i].ToCharArray()[j] == '1')
                        {
                            countOfMaxLength++;
                        }
                    }
                }
            }

            Console.WriteLine(maxLength);
            Console.WriteLine(countOfMaxLength);
        }
    }
}
