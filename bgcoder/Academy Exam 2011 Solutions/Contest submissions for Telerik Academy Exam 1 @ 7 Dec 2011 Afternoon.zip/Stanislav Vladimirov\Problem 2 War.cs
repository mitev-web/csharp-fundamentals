using System;
using System.Numerics;

namespace Problem02
{
    class Problem02_
    {
        static void Main(string[] args)
        {
            long Px1 = long.Parse(Console.ReadLine());
            long Py1 = long.Parse(Console.ReadLine());
            long Px2 = long.Parse(Console.ReadLine());
            long Py2 = long.Parse(Console.ReadLine());
            long Fx = long.Parse(Console.ReadLine());
            long Fy = long.Parse(Console.ReadLine());
            long D = long.Parse(Console.ReadLine());

            long dmgX = Fx + D;
            long dmgY = Fy;
            long temp = 0;

            if (Px1 > Px2)
            {
                temp = Px1;
                Px1 = Px2;
                Px2 = temp;
            }

            if (Py2 > Py1)
            {
                temp = Py1;
                Py1 = Py2;
                Py2 = temp;
            }

            if (dmgX == (Px1 - 1))
            {
                if ((dmgY <= Py1) && (dmgY >= Py2))
                {
                    Console.WriteLine("75%");
                }
                else
                {
                    Console.WriteLine("0%");
                }
            }
            else if (dmgX == Px1)
            {
                if ((dmgY == Py1) || (dmgY == Py2))
                {
                    if ((Px2 - Px1) > 1)
                    {
                        if ((Py1 - Py2) > 1)
                        {
                            Console.WriteLine("225%");
                        }
                        else
                        {
                            Console.WriteLine("175%");
                        }
                    }
                    else
                    {
                        if ((Py1 - Py2) > 1)
                        {
                            Console.WriteLine("150%");
                        }
                        else
                        {
                            Console.WriteLine("100%");
                        }
                    }
                }
                if ((dmgY < Py1) && (dmgY > Py2))
                {
                    if ((Px2 - Px1) > 1)
                    {
                        //
                        Console.WriteLine("275%");
                    }
                    else
                    {
                        Console.WriteLine("200%");
                    }
                }
            }
            else if ((dmgX > Px1) && (dmgX < (Px2 - 1)))
            {
                if ((dmgY == Py1) || (dmgY == Py2))
                {
                    if ((Py1 - Py2) > 1)
                    {
                        Console.WriteLine("225%");
                    }
                    else
                    {
                        Console.WriteLine("175%");
                    }
                }
                else if ((dmgY > Py2) && (dmgY < Py2))
                {
                    Console.WriteLine("275%");
                }
                else
                {
                    Console.WriteLine("0%");
                }
            }
            else if (dmgX == Px2)
            {
                if ((dmgY == Py1) || (dmgY == Py2))
                {
                    if ((Py1 - Py2) > 1)
                    {
                        Console.WriteLine("150%");
                    }
                    else
                    {
                        Console.WriteLine("100%");
                    }
                }
                else if ((dmgY > Py2) && (dmgY < Py2))
                {
                    Console.WriteLine("200%");
                }
                else
                {
                    Console.WriteLine("0%");
                }
            }
            else
            {
                Console.WriteLine("0%");
            }
            if ((dmgY == (Py1 + 1)) || (dmgY == (Py2 - 1)))
            {
                if ((dmgX >= Px1) && (dmgX <= Px2))
                {
                    Console.WriteLine("50%");
                }
                else
                {
                    Console.WriteLine("0%");
                }
            }                             
        }
    }
}
