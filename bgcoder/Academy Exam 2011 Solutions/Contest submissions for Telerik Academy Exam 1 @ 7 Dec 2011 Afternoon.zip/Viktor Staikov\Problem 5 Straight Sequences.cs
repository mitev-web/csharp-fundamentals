using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StraightSequences
{
    class StraightSequences
    {
        static void Main(string[] args)
        {
            int[,] a = new int[8, 8];

            int e;
            for (int i = 0; i < 8; i++)
            {
                e = int.Parse(Console.ReadLine());

                for (int j = 0; j < 8; j++)
                {
                    a[i, j] = (e & (1<<j))>>j;
                }
            }

            int currLenght = 0;
            int maxLenght = 0;
            int count = 0;
            
            for (int i = 0; i < 8; i++)
            {
                currLenght = 0;
                for (int j = 0; j < 8; j++)
                {
                    if (a[j, i] == 1)
                        currLenght++;
                    else
                    {
                        if (currLenght == maxLenght)
                            count++;
                        if (currLenght > maxLenght)
                        {
                            maxLenght = currLenght;
                            count = 1;
                        }
                        currLenght = 0;
                    }
                }
                if (currLenght == maxLenght)
                    count++;
                if (currLenght > maxLenght)
                {
                    maxLenght = currLenght;
                    count = 1;
                }
            }

            for (int i = 0; i < 8; i++)
            {
                currLenght = 0;
                for (int j = 0; j < 8; j++)
                {
                    if (a[i, j] == 1)
                        currLenght++;
                    else
                    {
                        if (currLenght == maxLenght)
                            count++;
                        if (currLenght > maxLenght)
                        {
                            maxLenght = currLenght;
                            count = 1;
                        }
                        currLenght = 0;
                    }
                }
                if (currLenght == maxLenght)
                    count++;
                if (currLenght > maxLenght)
                {
                    maxLenght = currLenght;
                    count = 1;
                }
            }

            Console.WriteLine(maxLenght);
            Console.WriteLine(count);
        }
    }
}
