using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //sand clock
            int N = 0;
            int i = 0;
            int k = 0;
            N = (int)Console.Read();
            //-----------------------------//

            print1:
            for (k=0; k==i; k++)
            {
            Console.Write(".");
            }
             for (k=0; k<(N-2*i); k++)
            {
            Console.Write("*");
            }
             for (k=0; k==i; k++)
            {
            Console.Write(".");
            }
            i= i+1;
            if (i>=(N+1)/2) goto second;
            goto print1;
            //-----------------------------//
            // i = nu,ber of points, = half of 
            second:
            for (k=0; k==i; k++)
            {
            Console.Write(".");
            }
             for (k=0; k<=(N-2*i); k++)
            {
            Console.Write("*");
            }
             for (k=0; k==i; k++)
            {
            Console.Write(".");
            }
            i= i-1;
            if (i>= 0) goto second;
           

        }
    }
}
