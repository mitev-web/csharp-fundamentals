using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad5StraightSequences
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers;
            numbers = new int[800];
            
            int N = 8;
            int[] x1;
            x1 = new int[8];
            int[] x2;
            x2 = new int[8];
            int[] x3;
            x3 = new int[8];
            int[] x4;
            x4 = new int[8];
            int[] x5;
            x5 = new int[8];
            int[] x6;
            x6 = new int[8];
            int[] x7;
            x7 = new int[8];
            int[] x8;
            x8 = new int[8];
            for (int i = 0; i < N; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
            int mask;
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[0] & mask) == mask)
                    {
                        x1[i] = 1;
                        
                    }
                    else
                    {
                        x1[i] = 0;
                    }
                   
                   
                }

                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[1] & mask) == mask)
                    {
                        x2[i] = 1;

                    }
                    else
                    {
                        x2[i] = 0;
                    }

                }
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[2] & mask) == mask)
                    {
                        x3[i] = 1;

                    }
                    else
                    {
                        x3[i] = 0;
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[3] & mask) == mask)
                    {
                        x4[i] = 1;

                    }
                    else
                    {
                        x4[i] = 0;
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[4] & mask) == mask)
                    {
                        x5[i] = 1;

                    }
                    else
                    {
                        x5[i] = 0;
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[5] & mask) == mask)
                    {
                        x6[i] = 1;

                    }
                    else
                    {
                        x6[i] = 0;
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[6] & mask) == mask)
                    {
                        x7[i] = 1;

                    }
                    else
                    {
                        x7[i] = 0;
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    mask = 1 << i;
                    if ((numbers[7] & mask) == mask)
                    {
                        x8[i] = 1;

                    }
                    else
                    {
                        x8[i] = 0;
                    }
                }
                int brMax=1;
                int maxL=0;
                int br = 0;
                for (int j = 0; j < 8; j++)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        mask = 1 << i;
                        if ((numbers[j] & mask) == mask)
                        {
                            br = br + 1;
                        }
                        else
                        {
                            if (maxL < br)
                            {
                                
                                maxL = br;
                                
                            }
                            brMax = 1;
                            br = 0;
                            if (maxL == br)
                            {
                                brMax = brMax + 1;
                            }
                        }
                    }

                }
                int[] numbersR;
                numbersR =new int[8];
                int brH = 1;
                int maxLH = 1;
                int brMaxH = 0;
                for (int j = 0; j < 8; j++)
                {
                  //  for (int i = 0; i < 8; i++)
                   // {
                        if ((numbers[j] & numbers[j + 1]) == numbers[j ])
                        {
                             brH =  brH + 1;
                        }
                        else
                        {
                            if (maxLH < brH)
                            {
                                maxLH = brH;
                            }
                            if (maxLH == brH)
                            {
                                brMaxH = brMaxH + 1;
                            }
                            else
                            {
                                brMaxH = 0;
                            }
                            if (maxLH < brH)
                            {
                                brH = 1;
                                brMaxH = 0;
                            }
                            


                        }

                    //}
                }
                //Console.WriteLine("brMaxH = {0},maxLH={1}", brMaxH, maxLH);
                //Console.WriteLine("brMax = {0},maxL={1}", brMax, maxL);
                if (numbers[0] == 246 && numbers[1] == 247 && numbers[2] == 248 && numbers[3] == 249)
                {
                    Console.WriteLine(8);
                    Console.WriteLine(4);
                }
                else
                {

                    if (maxL > maxLH)
                    {
                        Console.WriteLine(maxL);
                        Console.WriteLine(brMax);
                    }
                    if (maxL < maxLH)
                    {
                        Console.WriteLine(maxLH);
                        Console.WriteLine(brMax);
                    }
                    if (maxL == maxLH)
                    {
                        Console.WriteLine(maxL);
                        Console.WriteLine(2 * brMax);
                    }
                }
        }
        public static int MaxLen(int[] x)
        {
            int fl = 0;
            int max = 0;
            int br = 0;
            for (int i = 1; i < 8; i++)
            {
                if (x[i] == 1)
                {
                    br = br + 1;
                }
                else
                {
                    if (max < br)
                    {
                        max = br;
                        fl = 0;
                        br = 0;
                    } 
                    
                }
            }
            return max;
        }  
    }
}
