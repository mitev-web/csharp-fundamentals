using System;

namespace _2.War
{
    class War
    {
        static void Main(string[] args)
        {
            int PX1 = int.Parse(Console.ReadLine());
            int PY1 = int.Parse(Console.ReadLine());
            int PX2 = int.Parse(Console.ReadLine());
            int PY2 = int.Parse(Console.ReadLine());

            int FX = int.Parse(Console.ReadLine());
            int FY = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());

            FX += D;
            int percent = 0;

            if (PX1 > PX2)
            {
                int temp = PX1;
                PX1 = PX2;
                PX2 = temp;              
            }

            if (PY2 > PY1)
            {
                int temp = PY1;
                PY1 = PY2;
                PY2 = temp;        
            }
            
            //center
            if ((FX >= PX1) && (FX <= PX2) && (FY >= PY2) && (FY <= PY1))
            {
                percent += 100;
            }


            //right
            FY -= 1;
            if ((FX >= PX1) && (FX <= PX2) && (FY >= PY2) && (FY <= PY1))
            {
                percent += 50;
            }

            //left
            FY += 2;

            if ((FX >= PX1) && (FX <= PX2) && (FY >= PY2) && (FY <= PY1))
            {
                percent += 50;
            }

            //front
            FY -= 1;
            FX += 1;
            if ((FX >= PX1) && (FX <= PX2) && (FY >= PY2) && (FY <= PY1))
            {
                percent += 75;
            }
            

            Console.WriteLine("{0}%", percent);
        
        }
    }
}