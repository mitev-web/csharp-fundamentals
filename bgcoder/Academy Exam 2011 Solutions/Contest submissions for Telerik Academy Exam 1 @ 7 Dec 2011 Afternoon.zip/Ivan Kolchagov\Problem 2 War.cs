using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace T02.War
{
    class Program
    {
        static bool CheckHit(int hitX, int hitY, int x1, int y1, int x2, int y2) 
        {
            bool test=false;
            if((hitY<= y1) && (hitY>=y2)) {
                if((hitX>=x1) && (hitX<=x2)) test=true;
            }
            return test;
        }

        static void Main(string[] args)
        {
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int distance = int.Parse(Console.ReadLine());
            //int pX1 = 2;
            //int pY1 = 3;
            //int pX2 = 2;
            //int pY2 = 3;
            //int fX = -6;
            //int fY = 2;
            //int distance = 8;
            int hitX = fX + distance;
            if (pX1 > pX2)
            {
                pX1 ^= pX2;
                pX2 ^= pX1;
                pX1 ^= pX2;
            }
            if (pY1 < pY2)
            {
                pY1 ^= pY2;
                pY2 ^= pY1;
                pY1 ^= pY2;
            }
            ushort damage = 0;
            //check for 100% damage
            if (CheckHit(hitX, fY, pX1, pY1, pX2, pY2))
            {
                damage += 100;
            }
            //check for 75% damage
            if (CheckHit(hitX + 1, fY, pX1, pY1, pX2, pY2))
            {
                damage += 75;
            }
            //check for 50% damage
            if (CheckHit(hitX, fY - 1, pX1, pY1, pX2, pY2))
            {
                damage += 50;
            }
            if (CheckHit(hitX, fY + 1, pX1, pY1, pX2, pY2))
            {
                damage += 50;
            }
            Console.WriteLine("{0}%",damage);                
        }
    }
}
