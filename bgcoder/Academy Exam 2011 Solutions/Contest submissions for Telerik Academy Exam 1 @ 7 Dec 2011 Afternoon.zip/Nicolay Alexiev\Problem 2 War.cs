using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_2___WAR
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int damageCenter = new int();
            int damageUp = new int();
            int damageDown = new int();
            int damageFront = new int();
            
            //first scenario X
            if (Px1 < Px2 && Py1 > Py2)
            {
                if ((Fx + D >= Px1 && Fx + D <= Px2)&&(Fy >= Py2 && Fy <= Py1))
                {
                    damageCenter = 100;
                    if (Fx + D+1<=Px2)
                {
                    damageFront = 75;
                }
                    if(Fy+1<=Py1)
                    {
                        damageUp = 50;
                    }
                    if(Fy-1>=Py2)
                    {
                        damageDown = 50;
                    }
                    
                }
                
                if ((Fx+D == Px1 - 1) && (Fy <= Py1 && Fy >= Py2))
                {
                    damageFront = 75;
                }
                if ((Fx + D >= Px1 && Fx + D <= Px2)&&(Fy==Py1+1||Fy==Py2-1))
                {
                    damageUp = 50;
                }
            }
            
            //second Scenario
            if (Px1 < Px2 && Py1 < Py2)
            {
                if ((Fx + D >= Px1 && Fx + D <= Px2) && (Fy <= Py2 && Fy >= Py1))
                {
                    damageCenter = 100;
                    if (Fx + D + 1 <= Px2)
                    {
                        damageFront = 75;
                    }
                    if (Fy + 1 <= Py2)
                    {
                        damageUp = 50;
                    }
                    if (Fy - 1 >= Py1)
                    {
                        damageDown = 50;
                    }

                }

                if ((Fx + D == Px1 - 1) && (Fy <= Py2 && Fy >= Py1))
                {
                    damageFront = 75;
                }
                if ((Fx + D >= Px1 && Fx + D <= Px2) && (Fy == Py1 - 1 || Fy == Py2 + 1))
                {
                    damageUp = 50;
                }
            }
            //third Scenario
            if (Px1 > Px2 && Py1 < Py2)
            {
                if ((Fx + D <= Px1 && Fx + D >= Px2) && (Fy <= Py2 && Fy >= Py1))
                {
                    damageCenter = 100;
                    if (Fx + D + 1 <= Px1)
                    {
                        damageFront = 75;
                    }
                    if (Fy + 1 <= Py2)
                    {
                        damageUp = 50;
                    }
                    if (Fy - 1 >= Py1)
                    {
                        damageDown = 50;
                    }

                }

                if ((Fx + D == Px2 - 1) && (Fy <= Py2 && Fy >= Py1))
                {
                    damageFront = 75;
                }
                if ((Fx + D <= Px1 && Fx + D >= Px2) && (Fy == Py1 - 1 || Fy == Py2 + 1))
                {
                    damageUp = 50;
                }
            }
            //fourth Scenario
            if (Px1 > Px2 && Py1 > Py2)
            {
                if ((Fx + D <= Px1 && Fx + D >= Px2) && (Fy >= Py2 && Fy <= Py1))
                {
                    damageCenter = 100;
                    if (Fx + D + 1 <= Px1)
                    {
                        damageFront = 75;
                    }
                    if (Fy + 1 <= Py1)
                    {
                        damageUp = 50;
                    }
                    if (Fy - 1 >= Py2)
                    {
                        damageDown = 50;
                    }

                }

                if ((Fx + D == Px2 - 1) && (Fy <= Py1 && Fy >= Py2))
                {
                    damageFront = 75;
                }
                if ((Fx + D >= Px2 && Fx + D <= Px1) && (Fy == Py1 + 1 || Fy == Py2 - 1))
                {
                    damageUp = 50;
                }
            }
            if (Px1 == Px2 && Py1 == Py2) 
            {
                if(Fx+D==Px1&&Fy==Py1)
                {
                    damageCenter = 100;
                }
                if (Fx + D == Px1 - 1 && Fy == Py1)
                {
                    damageFront = 75;
                }
                if(Fx+D==Px1&&(Fy==Py1+1||Fy==Py1-1))
                {
                    damageUp = 50;
                }
            }
            
            if(Px1==Px2)
            {
                if (Py1 > Py2)
                {
                    if (Fx+D==Px1&&(Fy<=Py1&&Fy>=Py2))
                    {
                        damageCenter = 100;
                        if(Fy+1<=Py1)
                        {
                            damageUp = 50;
                        }
                        if (Fy - 1 >= Py2)
                        {
                            damageDown = 50;
                        }
                    }
                    if (Fx + D == Px1 - 1 && (Fy >= Py2 && Fy <= Py1))
                    {
                        damageFront = 75;
                    }
               
                }
                if (Py1 < Py2)
                {
                    if (Fx + D == Px1 && (Fy >= Py1 && Fy <= Py2))
                    {
                        damageCenter = 100;
                        if (Fy + 1 <= Py2)
                        {
                            damageUp = 50;
                        }
                        if (Fy - 1 >= Py1)
                        {
                            damageDown = 50;
                        }
                    }
                    if (Fx + D == Px1 - 1 && (Fy >= Py1 && Fy <= Py2))
                    {
                        damageFront = 75;
                    }

                }
            }
            if (Py1==Py2)
            {
                if (Px1 > Px2) 
                
                {
                    if((Fx+D>=Px2&&Fx+D<=Px1)&&(Fy==Py1))
                {
                damageCenter=100;
                        if(Fx+D+1<=Px1)
                        {
                            damageFront = 75;
                        }

                }
                    if (Fx+D==Px2-1&&Fy==Py1)
                    {
                        damageFront = 75;
                    }
                    if((Fx+D>=Px2&&Fx+D<=Px1)&&(Fy==Py1+1||Fy==Py1-1))
                    {
                        damageUp = 50;
                    }
                
                }
                if (Px1 < Px2)
                {
                    if ((Fx + D >= Px1 && Fx + D <= Px2) && (Fy == Py1))
                    {
                        damageCenter = 100;
                        if (Fx + D + 1 <= Px2)
                        {
                            damageFront = 75;
                        }

                    }
                    if (Fx + D == Px1 - 1 && Fy == Py1)
                    {
                        damageFront = 75;
                    }
                    if ((Fx + D >= Px1 && Fx + D <= Px2) && (Fy == Py1 + 1 || Fy == Py1 - 1))
                    {
                        damageUp = 50;
                    }

                }
            
            }
            int totalDamage = damageUp + damageFront + damageDown + damageCenter;
            Console.WriteLine(totalDamage + "%");
        }
    }
}
