using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            
            for (int i = 1; i <= N; i++)
            {
                Console.WriteLine("");
                for (int j = 0; j <= N - 1; j++)
                {
                    if (i == j)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                    
                    
                    



                }
            }

        }
    }
}
