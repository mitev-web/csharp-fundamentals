using System;
using System.Threading;
using System.Globalization;
using System.Numerics;
class SpecialAlgorithm
{
    
    static void Main()
    {
        Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
        string line = Console.ReadLine();
        BigInteger n = BigInteger.Parse(line);
        BigInteger sum = 0;

        if (n < 0)
        {
            n *= -1;
        }
        for (; ; )
        {
            while (n != 0)
            {
                sum += n % 10;
                n /= 10;
            }
            if ((sum <= 9) & (sum > 0))
            {
                Console.WriteLine(sum); break;
            }
            else
            {
                n = sum;
                sum = 0;
            }
        }
    }
}