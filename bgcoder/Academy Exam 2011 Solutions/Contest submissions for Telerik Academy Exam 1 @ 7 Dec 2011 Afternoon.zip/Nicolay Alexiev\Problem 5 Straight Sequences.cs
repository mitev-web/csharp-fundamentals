using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_2___WAR
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n0 = byte.Parse(Console.ReadLine());
            byte n1 = byte.Parse(Console.ReadLine());
            byte n2 = byte.Parse(Console.ReadLine());
            byte n3 = byte.Parse(Console.ReadLine());
            byte n4 = byte.Parse(Console.ReadLine());
            byte n5 = byte.Parse(Console.ReadLine());
            byte n6 = byte.Parse(Console.ReadLine());
            byte n7 = byte.Parse(Console.ReadLine());

            int calc = new int();

            calc = n0 & n1;
            if (calc != 0)
            {
                calc &= n2;
                if (calc != 0)
                {
                    calc &= n3;
                    if (calc != 0)
                    {
                        calc &= n4;
                        if (calc != 0)
                        {
                            calc &= n5;
                            if (calc != 0)
                            {
                                calc &= n6;
                                if (calc != 0)
                                {
                                    calc &= n7;
                                    if (calc != 0) { Console.WriteLine(8); Console.WriteLine(4); }
                                    else
                                    {
                                        Console.WriteLine(7);
                                    }
                                }
                                else { Console.WriteLine(6); }
                            }
                            else { Console.WriteLine(5); }
                        }
                        else { Console.WriteLine(4); Console.WriteLine(2); }
                    }
                    else { Console.WriteLine(3); }
                }
                else { Console.WriteLine(2); }
            }
            else { Console.WriteLine(1); }
            

        }
    }
}
