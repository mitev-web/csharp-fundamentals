using System;


namespace PROBLEM2222222
{
    class Program
    {
        static void Main(string[] args)
        {
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            int fx1 = int.Parse(Console.ReadLine());
            int fy1 = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            
                        
                if ((d + fx1 >= x1) && (d + fx1 <= x2) && (fy1 < y1) && (fy1 > y2))
                {
                    Console.WriteLine("275%");
                }
                else if ((d + fx1 <= x1) && (d + fx1 >= x2) && (fy1 > y1) && (fy1 < y2))
                {
                    Console.WriteLine("275%");
                }
                else if ((d + fx1 < x1) && (d + fx1 < x2) && (fy1 <= y1) && (fy1 >= y2))
                {
                    Console.WriteLine("75%");
                }
                else if ((d + fx1 < x1) && (d + fx1 < x2) && (fy1 >= y1) && (fy1 <= y2))
                {
                    Console.WriteLine("75%");
                }
                else if ((d + fy1 < 0) && (fx1 == 0)) //&& (d + fx1 < x1) && (d + fx1 < x2) && (fy1 >= y1) && (fy1 <= y2))
                {
                    Console.WriteLine("0%");
                }
                //else if ((d + fy1 < x1) && (d + fx1 < x2) && (fy1 <= y1) && (fy1 >= y2)&&(d+fx1 < 0)&&(fx1 ==0))
                //{
                //  Console.WriteLine("0%");
                //}
            
          
                else if ((d + fx1 >= x1) && (d + fx1 >= x2) && (fy1 <= y1) && (fy1 >= y2))
                {
                    Console.WriteLine("75%");
                }
                else if ((d + fx1 > x1) && (d + fx1 < x2) && (fy1 < y1) && (fy1 < y2))
                {
                    Console.WriteLine("50%");
                }
                else if ((d + fx1 > x1) && (d + fx1 < x2) && (fy1 > y1) && (fy1 > y2))
                {
                    Console.WriteLine("50%");
                }
                else if ((d + fx1 >= x1) && (d + fx1 <= x2) && (fy1 == y1) && (fy1 > y2))
                {
                    Console.WriteLine("225%");
                }
                else if ((d + fx1 >= x1) && (d + fx1 <= x2) && (fy1 < y1) && (fy1 == y2))
                {
                    Console.WriteLine("225%");
                }
        }

    }
}
