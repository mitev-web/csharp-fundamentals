using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            string n = Console.ReadLine();
            int result = 0;
            for (int i = 0; i < n.Length; i++)
            {
                if (n[i] >= '0' && n[i] <= '9')
                {
                    result = result + int.Parse(n[i].ToString());
                }
            }

            while (result > 9)
            {
                int tempRes = 0;
                while (result > 0)
                {
                    tempRes = tempRes + result % 10;
                    result = result / 10;
                }
                result = tempRes;
            }

            Console.WriteLine(result);
        }
    }
}