using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal n = Convert.ToDecimal(Console.ReadLine());

            if (n < 0)
            {
                n *=-1;
            }

            n *= 100000000000000;
            long sum = 0;
            long newN;
            newN =(long)n;


        cikal:
            while (newN != 0)
            {
                sum += newN % 10;
                newN /= 10;
            }
            if (sum > 9)
            {
                newN = sum;
                sum = 0;
                goto cikal;
            }

            Console.WriteLine((long)sum);

             
        }
    }
}
