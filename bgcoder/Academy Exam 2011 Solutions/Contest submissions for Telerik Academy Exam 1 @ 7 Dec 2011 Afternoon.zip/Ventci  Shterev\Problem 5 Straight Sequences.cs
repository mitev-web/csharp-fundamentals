using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem05_StraightSequences
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] byteArray = new byte[8];
            for (byte i = 0; i < byteArray.Length; i++)
            {
                string inputLine = Console.ReadLine();
                byteArray[i] = byte.Parse(inputLine);
            }
            byte[,] byteMatrix = new byte[8, 8];
            for (int i = 0; i < byteArray.Length; i++)
            {
                for (int j = 7, k = 0; k < 8; j--, k++)
                {
                    int tempByte = byteArray[i] >> j;
                    tempByte = tempByte & 1;
                    byteMatrix[i, k] = (byte)tempByte;
                }
            }
            int[] resultRow = new int[2];
            resultRow[0] = 0;
            resultRow[1] = 1;
            int[] resultCol = new int[2];
            resultCol[0] = 0;
            resultCol[1] = 1;
            for (int i = 0; i < byteMatrix.GetLongLength(0); i++)
            {
                int tempSequenceRow = 0;
                int tempSequenceCol = 0;
                for (int j = 0; j < byteMatrix.GetLongLength(1); j++)
                {
                    if (byteMatrix[i, j] == 1)
                    {
                        tempSequenceRow++;
                        if (resultRow[0] < tempSequenceRow)
                        {
                            resultRow[0] = tempSequenceRow;
                            resultRow[1] = 1;
                        }
                        else if (resultRow[0] == tempSequenceRow)
                        {
                            resultRow[1]++;
                        }
                        else { }
                    }
                    else
                    {
                        tempSequenceRow = 0;
                    }

                    if (byteMatrix[j, i] == 1)
                    {
                        tempSequenceCol++;
                        if (resultCol[0] < tempSequenceCol)
                        {
                            resultCol[0] = tempSequenceCol;
                            resultCol[1] = 1;
                        }
                        else if (resultCol[0] == tempSequenceCol)
                        {
                            resultCol[1]++;
                        }
                        else { }
                    }
                    else
                    {
                        tempSequenceCol = 0;
                    }
                }
            }
            int[] result = new int[2];
            if (resultRow[0] == resultCol[0])
            {
                result[0] = resultRow[0];
                result[1] = resultCol[1] + resultRow[1];
            }
            else if (resultCol[0] > resultRow[0])
            {
                result[0] = resultCol[0];
                result[1] = resultCol[1];
            }
            else
            {
                result[0] = resultRow[0];
                result[1] = resultRow[1];
            }
            Console.WriteLine(result[0]); 
            Console.WriteLine(result[1]);
        }
    }
}
