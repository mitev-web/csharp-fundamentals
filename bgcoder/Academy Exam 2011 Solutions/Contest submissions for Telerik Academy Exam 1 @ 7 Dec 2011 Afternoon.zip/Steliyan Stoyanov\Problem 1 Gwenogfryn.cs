using System;

namespace Gweno
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine());

            string[] arr = new string[n / 2 + 1];
            

            for(int i = 0; i <= n/2; i++)
            {
                for(int k = 0; k < i; k++)
                     arr[i] += '.';

                for(int j = i; j < n; j++)
                {
                    if(j < n - i)
                        arr[i] += '*';
                    else
                        arr[i] += '.';
                }
            }

            for(int i = 0; i <= n/2; i++)
                Console.WriteLine(arr[i]);

            for(int i = n/2-1; i >= 0; i--)
                Console.WriteLine(arr[i]);
        }
    }
}
