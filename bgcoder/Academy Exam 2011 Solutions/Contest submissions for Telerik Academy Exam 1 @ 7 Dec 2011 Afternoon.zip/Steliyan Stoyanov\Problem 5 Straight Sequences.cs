using System;

namespace Sequence
{
    class Program
    {
        static byte GetBit(byte number, int position)
        {
            return (byte)((number >> position) & 1);
        }

     
        static void Main(string[] args)
        {
            const int N = 8;
            byte[] n = new byte[N];

            for(int i = 0; i < N; i++)
                n[i] = byte.Parse(Console.ReadLine());

            //for(int i = 0; i < N; i++) Console.WriteLine(Convert.ToString(n[i], 2).PadLeft(N, '0'));

            int maxRow = 0;
            int prevMaxRow = 0;
            int totalMaxRow = 0;
             
            for(int i = 0; i < N; i++)
            {
                int count = 0;

                for(int j = N - 1; j >= 0; j--)
                    if(GetBit(n[i], j) == 1)
                        count++;
                    else
                    {
                        if(maxRow <= count)
                        {
                            maxRow = count;

                            if(maxRow != prevMaxRow)
                                totalMaxRow = 1;
                            else
                                totalMaxRow++;

                            prevMaxRow = maxRow;
                        }
                        count = 0;
                        continue;
                    }
                

                if(maxRow <= count)
                {
                    maxRow = count;

                    if(maxRow != prevMaxRow)
                        totalMaxRow = 1;
                    else
                            totalMaxRow++;

                    prevMaxRow = maxRow;
                }

                count = 0;
            }

            
             

            int maxCol = 0;
            int prevMaxCol = 0;
            int totalMaxCol = 0;

            for(int i = 0; i < N; i++)
            {
                int count = 0;

                for(int j = 0; j < N; j++ )
                    if(GetBit(n[j], i) == 1)
                        count++;
                    else
                    {
                        if(maxCol <= count)
                        {
                            maxCol = count;

                            if(maxCol != prevMaxCol)
                                totalMaxCol = 1;
                            else
                                
                                    totalMaxCol++;

                            prevMaxCol = maxCol;
                        }

                        count = 0;

                        continue;
                    }

                if(maxCol <= count)
                {
                    maxCol = count;

                    if(maxCol != prevMaxCol)
                        totalMaxCol = 1;
                    else
                        totalMaxCol++;

                    prevMaxCol = maxCol;
                }

                count = 0;
            }

            //Console.WriteLine("Row: {0} -> {1}", totalMaxRow, maxRow);
           // Console.WriteLine("Col: {0} -> {1}", totalMaxCol, maxCol);

            if(maxRow == maxCol)
            {
                Console.WriteLine(maxRow);

                if(maxRow != 1)
                    Console.WriteLine(totalMaxCol+totalMaxRow);
                else
                    Console.WriteLine(totalMaxRow);
            }
            else
            {
                if(maxRow > maxCol)
                {
                    Console.WriteLine(maxRow);
                    Console.WriteLine(totalMaxRow);
                }
                else
                {
                    Console.WriteLine(maxCol);
                    Console.WriteLine(totalMaxCol);
                }
            }
        }
    }
}
