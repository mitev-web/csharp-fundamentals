using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace special_Algorithm_eXERCISE_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string consoleLine = Console.ReadLine();
            double n = double.Parse(consoleLine);

            int temp = 0;
            n = Math.Abs(n);

            while (((n % 2) != 0))
            {
                if (n % 2 == 1)
                {
                    break;
                }
                n *= 10;
            }
     
            while (n > 9)
            {
                while ((n / 10) != 0)
                {
                    temp += (int)(n % 10);
                    n /= 10;
                }

                temp += (int)n;

                if (temp > 9)
                {
                    n = temp;
                    temp = 0;
                }
                else
                {
                    n = temp;
                }

            }
            Console.WriteLine(n);

            
        }
    }
}
