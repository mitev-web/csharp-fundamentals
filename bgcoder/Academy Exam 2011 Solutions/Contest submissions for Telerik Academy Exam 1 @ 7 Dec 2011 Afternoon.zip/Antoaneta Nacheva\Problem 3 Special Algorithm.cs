using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mytests
{
    class Program
    {
        static void Main(string[] args)
        {

            {
                float n = float.Parse(Console.ReadLine());
                float sum = 0;

                while (n != 0)
                {
                    float c = (int) n % 10;
                    sum += c;
                    n /= 10;
                }
                Console.WriteLine(sum);
                

            }
        }
    }
}