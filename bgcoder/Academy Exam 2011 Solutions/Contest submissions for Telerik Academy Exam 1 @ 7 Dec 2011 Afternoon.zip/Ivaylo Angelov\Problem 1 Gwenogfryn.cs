using System;

namespace ProblemOne
{
    class ProblemOne
    {
        static void Main()
        {
            const char dot = '.';
            const char asterisk = '*';
            sbyte input = sbyte.Parse(Console.ReadLine());
            char[,] matrix = new char[input, input];

            for (int i = 0; i < input; i++)
            {
                for (int j = 0; j < input; j++)
                {
                    matrix[i, j] = dot;
                }
            }

                int start = 0;
                int end = input;

                for (int i = 0; i <= input / 2; i++)
                {
                    for (int j = start; j < end; j++)
                    {
                        matrix[i, j] = asterisk;
                    }
                    start++;
                    end--;
                }

                start = start - 2;
                end = end + 2;

                for (int i = input / 2 + 1; i < input; i++)
                {
                    for (int j = start; j < end; j++)
                    {
                        matrix[i, j] = asterisk;
                    }
                    start--;
                    end++;
                }

                // print

                for (int i = 0; i < input; i++)
                {
                    for (int j = 0; j < input; j++)
                    {
                        Console.Write(matrix[i, j]);
                    }
                    Console.WriteLine();
                }

            }
        }
}

