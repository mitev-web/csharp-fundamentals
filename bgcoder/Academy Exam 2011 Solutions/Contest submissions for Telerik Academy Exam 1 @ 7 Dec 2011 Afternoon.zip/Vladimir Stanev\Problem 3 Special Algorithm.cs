using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace _3_Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            string line = Console.ReadLine();
            double N = double.Parse(line);

            if (N < 0)
            {
                line = line.Substring(1, (line.Length - 1));
            }

            int l = line.Length;
            int l1 = 1;
            int digit=0;
            BigInteger Left = (int)N;
            int Result=0;

            // Entire part
            while (Left != 0)
            {
                digit = (int)(Left % (10));
                Left /= 10;
                l1 = l1 + 1;
            }

            for (int i = 0; i < l; i++)
            {
                if (i!=(l1-1))
                {
                digit = byte.Parse(line.Substring(i, 1));
                Result += digit;
                // Console.WriteLine(digit);
                }
            }

            // Result - integer
            int newResult =0;

            while (Result > 9)
            { 
            
            newResult = 0;
                        while (Result != 0)
                        {
                            digit = Result % (10);
                            Result /= 10;
                            newResult += digit;
                        }
                        Result = newResult; 
            }

            Console.WriteLine(Result);

            Console.WriteLine();
        }
    }
}
