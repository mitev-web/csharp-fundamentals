using System;

namespace SpecialAlogrithm
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine());

            int result = Calculate(n);

            Console.WriteLine(result);
        }

        static int Calculate(int n)
        {
            int sum = 0;
            while (n != 0)
            {
                sum += n % 10;
                n /= 10;
            }
            if (sum > 9)
            {
                Calculate(sum);
                return 0;
            }
            else
            {
                return sum;
            }
        }
    }
}
