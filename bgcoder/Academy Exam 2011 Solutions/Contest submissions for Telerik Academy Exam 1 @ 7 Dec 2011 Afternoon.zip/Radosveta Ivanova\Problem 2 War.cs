using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace Airoplane
{
    class Program
    {
        static void Main(string[] args)
        {

            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            double Px1 = double.Parse(Console.ReadLine());
            double Py1 = double.Parse(Console.ReadLine());
            double Px2 = double.Parse(Console.ReadLine());
            double Py2 = double.Parse(Console.ReadLine());
            double Fx = double.Parse(Console.ReadLine());
            double Fy = double.Parse(Console.ReadLine());
            double D = double.Parse(Console.ReadLine());

            
           
           

            if (((Py2 < Fy) && (Fy< Py1) && (D == Px1 - Fx) && (D == Px2 - Fx)))
            {
                double totalDamage = (0.100 + 0.50 + 0.50 + 0.75);
                Console.Write("{0:P}", 0.275);
            }
            if ((Fy < Py2) && (Py2 < Py1))
            {
                double noDamage = 0.0;
                Console.Write("{0:P}", 0.0);
            }
            if ((Py2 < Fy) && (Fy < Py1) && (D < (Px2 - Fx)))
            {
               double partialDamage = 0.75;
                Console.Write("{0:P}", 0.75);
            }
            if ((Py2 < Fy)&&(Fy < Py1)&& (D < Px1 -Fx))
            {
                double partialDamage = 0.75;
                Console.Write("{0:P}", 0.75);
            }
            if (Fy > Py1)
            {
                double noDamage = 0.0;
                Console.Write("{0:P}", 0.0);
            }
        }
    }
}
