using System;
using System.Globalization;
using System.Threading;
using System.Collections;

namespace Problem_3
{
    class Problem3
    {
        static int Algorithm(string start)
        {
            string digit = null;
            int sumOfDigits = 0;
            for (int j = 0; j < start.Length; j++)
            {
                digit = Convert.ToString(start[j]);
                sumOfDigits += Convert.ToByte(digit);
            }
            return sumOfDigits;
        }
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-US");
            decimal number = decimal.Parse(Console.ReadLine());
            string start = Convert.ToString(number.ToString());
            IEnumerator thisIEnum = start.GetEnumerator();
            while (thisIEnum.MoveNext())
            {
                start = start.Replace("-", "");
                start = start.Replace(".", "");
                start = start.Replace("0", "");
            }
            bool end = false;
            int sumOfDigits = 0;
            sumOfDigits = Algorithm(start);            
            while (!end)
            {
                if (sumOfDigits <= 9)
                {
                    break;
                }
                else if (sumOfDigits > 9)
                {
                    start = Convert.ToString(sumOfDigits);
                    sumOfDigits = 0;
                    sumOfDigits = Algorithm(start);
                }
            }   
            Console.WriteLine(sumOfDigits);
        }
    }
}