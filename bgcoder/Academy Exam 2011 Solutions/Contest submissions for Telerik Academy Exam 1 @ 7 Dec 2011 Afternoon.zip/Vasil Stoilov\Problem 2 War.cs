using System;

class War
{
    static void Main(string[] args)
    {
        int rectCoordX1 = int.Parse(Console.ReadLine());
        int rectCoordY1 = int.Parse(Console.ReadLine());
        int rectCoordX2 = int.Parse(Console.ReadLine());
        int rectCoordY2 = int.Parse(Console.ReadLine());
        int fx = int.Parse(Console.ReadLine());
        int fy = int.Parse(Console.ReadLine());
        int d = int.Parse(Console.ReadLine());

        int rectHeight = Math.Abs(rectCoordY1 - rectCoordY2);
        int rectWidth = Math.Abs(rectCoordX1 - rectCoordX2);
        bool isWithinRectangle = ((fx + d < Math.Min(rectCoordX1, rectCoordX2) || fx + d > Math.Max(rectCoordX1, rectCoordX2))
                                  || (fy < Math.Min(rectCoordY1, rectCoordY2) || fy > Math.Max(rectCoordY1, rectCoordY2)));
        //true - outside;
        int damage = 0;
        if (!isWithinRectangle)
        {
            if (fx + d >= Math.Min(rectCoordX1, rectCoordX2) && fx + d <= Math.Max(rectCoordX1, rectCoordX2)
                && (fy == Math.Min(rectCoordY1, rectCoordY2) || fy == Math.Max(rectCoordY1, rectCoordY2)))
            {
                damage = 225;
                if (fx + d == Math.Max(rectCoordX1, rectCoordX2))
                {
                    damage = 150;
                }
            }
            else if (fx + d >= Math.Min(rectCoordX1, rectCoordX2) && fx + d <= Math.Max(rectCoordX1, rectCoordX2))
            {
                damage = 275;
                if (fx + d == Math.Max(rectCoordX1, rectCoordX2))
                {
                    damage = 200;
                }
            }
            
        }
        else if (fx + d == Math.Min(rectCoordX1, rectCoordX2)-1)
        {
            damage = 75;
        }
        else if (fy + 1 == Math.Min(rectCoordY1, rectCoordY2) || fy - 1 == Math.Max(rectCoordY1, rectCoordY2))
        {
            damage = 50;
        }
        else
        {
            damage = 0;
        }
        Console.WriteLine("{0}%", damage);
    }
}

