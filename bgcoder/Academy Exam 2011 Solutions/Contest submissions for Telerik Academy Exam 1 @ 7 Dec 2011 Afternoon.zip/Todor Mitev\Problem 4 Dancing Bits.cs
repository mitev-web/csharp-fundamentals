using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort k = ushort.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            uint[] numbers = new uint[n];
            string numbersInBits = "";
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = uint.Parse(Console.ReadLine());
                numbersInBits += Convert.ToString(numbers[i], 2);
            }
            if(k==1)
            {
                Console.WriteLine(numbersInBits.Length);
            }
            else if (k == 2)
            {
                int final2 = 0;
                for (int i = 0; i < numbersInBits.Length - 1; i++)
                {
                    int count = 1;
                    int result = 1;
                    int j = i + 1;
                    while (j < numbersInBits.Length && count <= k && numbersInBits[i] == numbersInBits[j])
                    {
                        result++;
                        j++;
                        count++;
                    }
                    if (result == k)
                    {
                        final2++;
                    }
                       
                }
                Console.WriteLine(final2);
            }
             
            else
            {
                int final = 0;
                for (int i = 0; i < numbersInBits.Length - k - 1; i++)
                {
                    int count = 1;
                    int result = 1;
                    int j = i + 1;
                    while (j <= numbersInBits.Length  && numbersInBits[i] == numbersInBits[j])
                    {
                        result++;
                        j++;
                        count++;
                    }
                    if (result == k && count<=k)
                    {
                        final++;
                    }
                }
                Console.WriteLine(final);
            }

        }
    }
}
