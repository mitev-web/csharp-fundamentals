using System;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
           //int n = Int32.Parse(Console.ReadLine());
           //double m = SumDigits(n);
           //Console.WriteLine(m);


            int total = 0;

            string s = Console.ReadLine();

            char[] x = s.ToCharArray();

            do
            {

                foreach (char c in x)
                {



                    total += int.Parse(c.ToString());

                }

            }
            while (total > 9);

            Console.WriteLine(total);

         }

        //public static int SumDigits(int value)
        //{
        //    int sum = 0;
        //    while (value != 0)
        //    {
        //        int rem;
        //        value = Math.DivRem(value, 10, out rem);
        //        sum += rem;
        //    }
        //    return sum;
        //} 
    }
}