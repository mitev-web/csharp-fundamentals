using System;

namespace _5.SS
{
    class SS
    {
        static void Main(string[] args)
        {
            int size = 8;
            byte[] numbers = new byte[size];

            for (int inputing = 0; inputing < size; inputing++)
            {
                numbers[inputing] = byte.Parse(Console.ReadLine());
            }

            int[] answers = new int[size + 1];
            int rowOfOnes = 0;
            int currentBit = 0;     

            for (int every = 0; every < size; every++)
            {
                for (int bit = 0; bit < size; bit++)
                {
                    currentBit = size - bit - 1;                
                    
                    if ((numbers[every] & (1 << currentBit)) > 0)              
                    {
                        rowOfOnes++;                         
                    }
                    else
                    {                  
                        answers[rowOfOnes]++;
                        rowOfOnes = 0;
                    }                    
                }
                if (rowOfOnes > 0)
                {
                    answers[rowOfOnes]++;
                }
                rowOfOnes = 0;
            }

            int columnOfOnes = 0;

            for (int every = 0; every < size; every++)
            {

                for (int bit = 0; bit < size; bit++)
                {
                    if ((numbers[bit] & (1 << every)) > 0)
                    {
                        columnOfOnes++;                                                                        
                    }
                    else
                    {                      
                        answers[columnOfOnes]++;
                        columnOfOnes = 0;
                    }
                }
                if (columnOfOnes > 0)
                {
                    answers[columnOfOnes]++;
                }
                columnOfOnes = 0;
            }

            answers[1] = 0;          

            for (int every = 0; every < size; every++)
            {              
                for (int bit = 0; bit < size; bit++)
                {
                    currentBit = size - bit - 1;

                    if ((numbers[every] & (1 << currentBit)) > 0)
                    {
                        rowOfOnes++;                     
                    }
                    else
                    {
                        if (rowOfOnes == 1)
                        {
                            answers[1]++;
                            numbers[every] = (byte)(numbers[every] & ~(1 << currentBit + 1));  
                                                    
                        }                     
                        rowOfOnes = 0;
                    }
                }
                if (rowOfOnes == 1)
                {
                    numbers[every] = (byte)(numbers[every] & ~(1 << currentBit + 1));
                }
                rowOfOnes = 0;
            }

            columnOfOnes = 0;

            for (int every = 0; every < size; every++)
            {

                for (int bit = 0; bit < size; bit++)
                {
                    if ((numbers[bit] & (1 << every)) > 0)
                    {
                        columnOfOnes++;
                    }
                    else
                    {
                        if (columnOfOnes == 1)
                        {
                            answers[1]++;                                                 
                        }
                        
                        columnOfOnes = 0;
                    }
                }
                if (columnOfOnes == 1)
                {            
                    answers[1]++;
                }
                columnOfOnes = 0;
            }       

            bool searchForBiggest = false;
            int counter = 8;

            while ((searchForBiggest == false) && (counter > 0))
            {
                if (answers[counter] != 0)
                {
                    searchForBiggest = true;
                    Console.WriteLine(counter);
                    Console.WriteLine(answers[counter]);
                }
                counter--;                
            }
            if (searchForBiggest == false)
            {
                Console.WriteLine("0");
                Console.WriteLine("0");
            }
        }
    }
}