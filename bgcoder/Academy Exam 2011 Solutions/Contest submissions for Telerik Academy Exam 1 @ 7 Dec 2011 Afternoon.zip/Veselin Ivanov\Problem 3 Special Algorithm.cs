using System;


namespace SpecialAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            double sum = 0;
            while (n != 0)
            {
                sum += n % 10;
                n /= 10;
                
            }
            n = sum;
            if (n > 9)
            {
                sum = 0;
                while (n != 0)
                {
                    
                    sum += n % 10;
                    n /= 10;
                }
                n = sum;
                Console.WriteLine((int)n);
            }
            else
            {
                Console.WriteLine((int)n);
            }

        }
    }
}
