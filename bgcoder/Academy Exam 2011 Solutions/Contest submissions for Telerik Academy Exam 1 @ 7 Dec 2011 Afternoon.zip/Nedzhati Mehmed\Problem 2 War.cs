using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int bomb100x=fx+d;
            int bomb100y = fy;
            int bomb75x = bomb100x + 1;
            int bomb75y = fy;
            int bomb50x = bomb100x;
            int bomb50y1 = bomb100y + 1;
            int bomb50y2 = bomb100y - 1;
            int damage = 0;
            int change = 0;
            if (px1 > px2)
            {
                change = px1;
                px1 = px2;
                px2 = change;
            }
            if (py1 < py2)
            {
                change = py1;
                py1 = px2;
                py2 = change;
            }
            if (px1 <= bomb100x && bomb100x <= px2 && py2 <= bomb100y && bomb100y <=py1 )
            {
                damage = damage + 100;
            }
            if (px1 <= bomb75x && bomb75x <= px2 && py2 <= bomb75y && bomb75y <= py1)
            {
                damage = damage + 75;
            }
            if (px1 <= bomb50x && bomb50x <= px2 && py2 <= bomb50y1 && bomb50y2 <= py1)
            {
                damage = damage + 50;
            }
            if (px1 <= bomb50x && bomb50x <= px2 && py2 <= bomb50y2 && bomb50y2 <= py1)
            {
                damage = damage + 50;
            }
            Console.WriteLine(damage +"%");
           
           
        }
    }
}
