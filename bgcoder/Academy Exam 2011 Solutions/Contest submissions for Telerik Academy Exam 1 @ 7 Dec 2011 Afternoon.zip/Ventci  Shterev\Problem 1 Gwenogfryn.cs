using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem01_Gwenogfryn
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            string inputStr = Console.ReadLine();
            byte numN = byte.Parse(inputStr);
            char[,] sandGlass = new char[numN, numN];
            for (byte i = 0; i < sandGlass.GetLength(0); i++)
            {
                for (int j = 0; j < sandGlass.GetLength(1); j++)
                {
                    if ((i <= (numN / 2)) && (j >= i) && (j + i <= numN - 1))
                    {
                        sandGlass[i, j] = '*';
                    }
                    else if ((i > (numN / 2)) && (i + j >= numN - 1) && (i >= j))
                    {
                        sandGlass[i, j] = '*';
                    }
                    else
                    {
                        sandGlass[i, j] = '.';
                    }
                    Console.Write(sandGlass[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
