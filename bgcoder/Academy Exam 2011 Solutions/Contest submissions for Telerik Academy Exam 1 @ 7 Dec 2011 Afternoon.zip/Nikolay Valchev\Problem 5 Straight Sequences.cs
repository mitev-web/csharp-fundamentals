using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] rows = new int[8];
            int[] cols = new int[8];
            int[] temp = new int[8];
            int maxInRow = 0;
            int count = 0;


            for (int i = 0; i < 8; i++)
            {
                rows[i] = int.Parse(Console.ReadLine());
                int number = rows[i];
                int countSeq = 0;

                for (int j = 0; j < 8; j++)
                {
                    if (((number>>j) & 1) == 1)
                    {
                        countSeq++;
                    }
                    else if (countSeq > maxInRow)
                    {
                        maxInRow = countSeq;
                        countSeq = 0;
                    }
                    else
                    {
                        
                        countSeq = 0;
                    }
                }
                if (countSeq > maxInRow)
                {
                    maxInRow = countSeq;
                    countSeq = 0;
                }
                else if (countSeq == maxInRow)
                {
                    countSeq = 0;
                }
            }
            
            for (int i = 0; i < 8; i++)
            {
                cols[i] = 0;
                for (int j = 0; j < 8; j++)
                {
                    cols[i] = cols[i] | ((rows[j] >> i) & 1) << j;
                };
            }
            temp = rows;
            rows = cols;
            // -------------------------------
            for (int i = 0; i < 8; i++)
            {
                int number = rows[i];
                int countSeq = 0;

                for (int j = 0; j < 8; j++)
                {
                    if (((number >> j) & 1) == 1)
                    {
                        countSeq++;
                    }
                    else if (countSeq > maxInRow)
                    {
                        maxInRow = countSeq;
                        countSeq = 0;
                    }
                    else
                    {

                        countSeq = 0;
                    }
                }
                if (countSeq > maxInRow)
                {
                    maxInRow = countSeq;
                    countSeq = 0;
                }
                else if (countSeq == maxInRow)
                {
                    countSeq = 0;
                }
            }
            //---------------------------------
            rows = temp;
            for (int i = 0; i < 8; i++)
            {
                int number = rows[i];
                int countSeq = 0;

                for (int j = 0; j < 8; j++)
                {
                    if (((number >> j) & 1) == 1)
                    {
                        countSeq++;
                    }
                    else if (countSeq == maxInRow)
                    {
                        count++;
                        countSeq = 0;
                    }
                    else
                    {
                        countSeq = 0;
                    }
                }

                if (countSeq == maxInRow)
                {
                    count++;
                }
            }

            rows = cols;
            if (maxInRow != 1)
            {
                for (int i = 0; i < 8; i++)
                {
                    int number = rows[i];
                    int countSeq = 0;

                    for (int j = 0; j < 8; j++)
                    {
                        if (((number >> j) & 1) == 1)
                        {
                            countSeq++;
                        }
                        else if (countSeq == maxInRow)
                        {
                            count++;
                            countSeq = 0;
                        }
                        else
                        {
                            countSeq = 0;
                        }
                    }

                    if (countSeq == maxInRow)
                    {
                        count++;
                    }
                }
            }
            Console.WriteLine(maxInRow);
            Console.WriteLine(count);
        }
    }
}
