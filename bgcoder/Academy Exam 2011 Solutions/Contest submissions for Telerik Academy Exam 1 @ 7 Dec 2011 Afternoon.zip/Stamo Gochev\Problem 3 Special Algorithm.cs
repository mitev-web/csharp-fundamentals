using System;

    class Program
    {
        public static void Main(string[] args)
        {
            string inputNumber = Console.ReadLine();
            //test 1
            //string inputNumber = "8";

            //test 1
            //string inputNumber = "-1337";
            //test 3
            //string inputNumber = "1234567.8900";

            long startingSum = 0;
            for (int i = 0; i < inputNumber.Length; i++)
            {
                if (inputNumber[i] != '.' && inputNumber[i] != '-')
                {
                    startingSum += (Convert.ToInt32(inputNumber[i]) -
                        Convert.ToInt32('0'));
                }
            }

            //Console.WriteLine(startingSum);

            long finalSum = startingSum;

            //long currentSum = startingSum;
            //long sumOfCurrentSum = 0;
            //while (currentSum > 0)
            //{
            //    int lastDigit = GetLastDigit(currentSum);
            //    //Console.WriteLine(lastDigit);
            //    sumOfCurrentSum += lastDigit;

            //    currentSum /= 10;
            //}

            //Console.WriteLine(sumOfCurrentSum);

            while (startingSum > 9)
            {
                long currentSum = startingSum;
                long sumOfCurrentSum = 0;
                while (currentSum > 0)
                {
                    int lastDigit = GetLastDigit(currentSum);
                    sumOfCurrentSum += lastDigit;
                    currentSum /= 10;
                }


                startingSum = sumOfCurrentSum;
            }

            Console.WriteLine(startingSum);

        }

        public static int GetLastDigit(long number)
        {
            int lastDigit = (int) number % 10;
            return lastDigit;
        }
    }

