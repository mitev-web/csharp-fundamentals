using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ExamSample03
{
	class ExamSample03
	{
		static void Main(string[] args)
		{
			decimal num = decimal.Parse(Console.ReadLine());
			decimal number = Math.Abs(num);
			while (number % 1 > 0)
			{
				number *= 10;
			}
			BigInteger num1 = (BigInteger)number;
			BigInteger acc;
			do
			{
				acc = 0;
				while (num1 > 0)
				{
					acc += num1 % 10;
					num1 /= 10;
				}
				num1 = acc;
			} while (acc >= 10);
			Console.WriteLine(acc);
		}
	}
}