using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2
{
    class Task2
    {
        static void Main(string[] args)
        {
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            int x3 = int.Parse(Console.ReadLine());
            int y3 = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int maxX;
            maxX = Math.Max(x1, x2);
            int maxY;
            maxY = Math.Max(y1, y2);
            int minx = Math.Min(x1, x2);
            int miny = Math.Min(y1, y2);
            if (d <= x3)
            {
                Console.WriteLine("0%");
            }
            else if (x3 + d < minx -1)
            {
                Console.WriteLine("0%");
            }
            else if (x3 + d > maxX)
            {
                Console.WriteLine("0%");
            }
            else if (y3 >= miny && y3 <= maxY && x3 + d == minx - 1)
            {
                Console.WriteLine("75%");
            }
            else if (y3 > maxY + 1)
            {
                Console.WriteLine("0%");
            }
            else if (y3 == maxY + 1)
            {
                Console.WriteLine("50%");
            }
            else if (y3 < miny -1 )
            {
                Console.WriteLine("0%");
            }
            else if (y3 == miny - 1)
            {
                Console.WriteLine("50%");
            }
            else if (y3 > miny + 1 && y3 <maxY - 1)
            {
                if (x3 + d >= minx && x3 + d <= maxX -1)
                {
                    Console.WriteLine("275%");
                }
                else if (x3 + d >= minx && x3 + d == maxX)
                {
                    Console.WriteLine("200%");
                }
            }
            else if (y3 == miny && x3 == minx && x3 == maxX)
            {
                Console.WriteLine("225%");
            }
            else if (y3 == maxY && x3 == minx && x3 == maxX)
            {
                Console.WriteLine("225%");
            }
        }
    }
}
