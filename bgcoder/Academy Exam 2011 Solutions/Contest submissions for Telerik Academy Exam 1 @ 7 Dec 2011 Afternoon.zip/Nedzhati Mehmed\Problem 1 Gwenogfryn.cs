using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Gwenogfryn
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int firstline=n;
            int pqsuk=n;
            int broqch = 0;
            int broqchDve = 0;
            int postionOne = 0;
            int positionLast =n;
            int count = 1;
            int crahspoint = 3;
            int lastline = n;
            for (; firstline > 0; firstline--) 
            {

                Console.Write("*");
                            
            }
            Console.Write("\n");
            while(broqchDve<n-2)
            {
            for (; pqsuk > 0; pqsuk--)
            {
                if (postionOne <= broqch||count>=positionLast)
                {
                    Console.Write(".");
                    postionOne++;
                }
               
                else
                {
                    Console.Write("*");
                }

                count++;
            }
            if (positionLast - broqch > crahspoint)
            {
                count = 1;
                pqsuk = n;
                postionOne = 0;
                broqch++;
                positionLast--;
                Console.Write("\n");
                broqchDve++;
            }
            else
            {
                pqsuk = n;
                count = 1;
                positionLast++;
                postionOne = 0;
                broqch--;
                Console.Write("\n");
                broqchDve++;
               crahspoint=10000000;
               
            }
            
            }
            for (; lastline > 0; lastline--)
            {

                Console.Write("*");

            }
        }
    }
}
