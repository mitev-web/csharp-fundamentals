using System;

namespace Gwenogfryn
{
    class Gwenogfryn
    {
        static void Main()
        {
            // Read input
            int N = int.Parse(Console.ReadLine());

            // Write first part
            for (int i = 1; i <= N/2+1; i++)
            {
                for (int j = 1; j <= N; j++)
                {
                    if (j <= (i - 1) || j >= (N - i + 2))
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }

            // Write second part
            for (int i = N/2; i >= 1; i--)
            {
                for (int j = 1; j <= N; j++)
                {
                    if (j <= (i - 1) || j >= (N - i + 2))
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}