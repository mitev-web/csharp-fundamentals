using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace straightSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int maxLength = 0;
            int p = 1;
            int broiEdinici = 0;
            int number1 = int.Parse(Console.ReadLine());
            int number2 = int.Parse(Console.ReadLine());
            int number3 = int.Parse(Console.ReadLine());
            int number4 = int.Parse(Console.ReadLine());
            int number5 = int.Parse(Console.ReadLine());
            int number6 = int.Parse(Console.ReadLine());
            int number7 = int.Parse(Console.ReadLine());
            int number8 = int.Parse(Console.ReadLine());
            int maxNumber = Math.Max(Math.Max(Math.Max(number1,number2),Math.Max(number3,number4)),Math.Max(Math.Max(number5,number6),Math.Max(number7,number8)))
            for (int s = 31; s >= 0; s--)
            {
                    int mask = p << s;
                    if ((maxNumber & mask) == 0)
                    {
                        broiEdinici++;
                    }
            }            
            Console.WriteLine(broiEdinici);
        }
    }
}