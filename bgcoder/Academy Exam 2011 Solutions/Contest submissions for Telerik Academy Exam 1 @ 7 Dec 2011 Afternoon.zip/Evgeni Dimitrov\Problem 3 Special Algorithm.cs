using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Globalization;
using System.Text;
 
namespace Exam_Task3_Special_Algorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture =
            CultureInfo.GetCultureInfo("en-US");
 
            long n = long.Parse(Console.ReadLine());
            long sum = 0;
            //sum = Math.Round(sum, 0, MidpointRounding.AwayFromZero);
            //long sum1 = 0;
                if (n > 9||n<0)
                {
 
 
                    for (long i = n; i != 0 || i < 0; sum += i % 10, i /= 10)
                        {
                        }
 
                    if (sum < 0)
                    {
                        sum = sum * (-1);  
                      
                        Console.WriteLine(sum);
                    }
                    else
                    {
                        Console.WriteLine(sum);
                    }            
                }
                 
                else if (n <= 9)
                {
                    Console.WriteLine(n);
 
                }
                 
             
        }
    }
}