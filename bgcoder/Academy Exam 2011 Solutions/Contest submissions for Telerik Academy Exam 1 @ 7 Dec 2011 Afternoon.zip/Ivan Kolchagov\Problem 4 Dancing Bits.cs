using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace T04.DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort k = ushort.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            //ushort k = 1;
            //uint[] n = { 0x80000000, 0x80000000, 0x80000000, 0xffff };
            int onesCount = 0, zeroesCount = 0;

            ushort dancingBits = 0;
            bool isPreviousOne = false;
            //for (int i = 0; i < n.Length; i++)
                for (int i = 0; i < n; i++)
            {
                uint number = uint.Parse(Console.ReadLine());
                //uint number = n[i];
                uint mirror = 0, bitCount = 0;
                while (number > 0)
                {
                    mirror <<= 1;
                    if ((number & 1) == 1) mirror |= 1;
                    number >>= 1;
                    bitCount++;
                }

                while (bitCount-- > 0)
                {
                    if ((mirror & 1) == 1)
                    {
                        if (isPreviousOne)
                        {
                            onesCount++;
                        }
                        else if (zeroesCount == k)
                        {
                            // count dancing bits
                            dancingBits++;
                            onesCount = 1;
                            zeroesCount = 0;
                        }
                        else
                        {
                            onesCount = 1;
                        }
                        isPreviousOne = true;
                    }
                    else
                    {
                        if (!isPreviousOne)
                        {
                            zeroesCount++;
                        }
                        else if (onesCount == k)
                        {
                            // count dancing bits
                            dancingBits++;
                            zeroesCount = 1;
                            onesCount = 0;
                        }
                        else
                        {
                            zeroesCount = 1;
                        }
                        isPreviousOne = false;
                    }
                    mirror >>= 1;
                }
            }
            //last check 
            if (zeroesCount == k) dancingBits++;
            if (onesCount == k) dancingBits++;
            Console.WriteLine(dancingBits);
        }
    }
}