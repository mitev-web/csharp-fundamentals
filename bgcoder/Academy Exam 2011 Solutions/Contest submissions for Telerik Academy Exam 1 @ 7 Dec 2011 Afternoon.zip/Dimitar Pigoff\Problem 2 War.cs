using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam4
{
    class Program
    {
        static void Main()
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx1 = int.Parse(Console.ReadLine());
            int Fy1 = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int P = 0;

            if (Fx1 + D > Px1 - 1 && Fx1 + D < Px1 + 4)
            {
                P = 225;
            }
            if (Fx1 + D == Px1 - 1)
            {
                P = 75;
            }
            if (D < 0)
            {
                P = 0;
            }
            Console.WriteLine("{0}%", P);
        }
    }
}
