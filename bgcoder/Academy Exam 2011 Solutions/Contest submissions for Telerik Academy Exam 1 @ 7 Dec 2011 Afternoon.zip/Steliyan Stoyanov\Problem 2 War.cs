using System;

namespace War
{
    class Program
    {
        static void Swap(ref int a, ref int b)
        {
            int tmp = a;
            a = b;
            b = tmp;
        }

        static bool Hit(int pX1, int pY1, int pX2, int pY2, int X, int Y)
        {
            if(pX1 > pX2)
            {
                Swap(ref pX1, ref pX2);
                Swap(ref pY1, ref pY2);
            }

            bool isInX = false;
            bool isInY = false;

            if(X >= pX1 && X <= pX2)
                isInX = true;

            if((Y >= pY1 && Y <= pY2) || (Y <= pY1 && Y >= pY2))
                isInY = true;

            return (isInX && isInY);
        }

        static void Main(string[] args)
        {
            int pX1, pY1;
            int pX2, pY2;
            int fX, fY;
            int d;

            
            pX1 = Int32.Parse(Console.ReadLine());
            pY1 = Int32.Parse(Console.ReadLine());
            pX2 = Int32.Parse(Console.ReadLine());
            pY2 = Int32.Parse(Console.ReadLine());
            fX = Int32.Parse(Console.ReadLine());
            fY = Int32.Parse(Console.ReadLine());
            d = Int32.Parse(Console.ReadLine());
            

            int res = 0;


            if(Hit(pX1, pY1, pX2, pY2, fX + d, fY))
                res += 100;

            if(Hit(pX1, pY1, pX2, pY2, fX + d + 1, fY))
                res += 75;

            if(Hit(pX1, pY1, pX2, pY2, fX + d, fY+1))
                res += 50;
           
            if(Hit(pX1, pY1, pX2, pY2, fX + d, fY-1))
                res += 50;

            Console.WriteLine("{0}%", res);
        }
    }
}
