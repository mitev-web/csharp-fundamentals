using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Astrological_numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            double N = double.Parse(Console.ReadLine());
            double sum = 0;
            while (N != 0)
            {
                sum += N % 10;
                N /= 10;
                if (sum > 9)
                {
                    continue;
                }
                else
                {
                    Console.Write(sum);
                }


            }
            //



        }
    }
}