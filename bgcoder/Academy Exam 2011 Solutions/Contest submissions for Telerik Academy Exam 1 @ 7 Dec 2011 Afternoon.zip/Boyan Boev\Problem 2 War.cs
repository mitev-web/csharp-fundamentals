using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = Convert.ToInt32(Console.ReadLine()); //1;
            int Py1 = Convert.ToInt32(Console.ReadLine()); //4;
            int Px2 = Convert.ToInt32(Console.ReadLine()); //5;
            int Py2 = Convert.ToInt32(Console.ReadLine()); //1;
            int Fx1 = Convert.ToInt32(Console.ReadLine()); //-3;
            int Fy1 = Convert.ToInt32(Console.ReadLine()); //3;
            int Fx2 = Fx1 + 1;
            int Fy2 = Fy1 - 1;
            int D = Convert.ToInt32(Console.ReadLine()); //5;

            int NewFx1 = Fx1 + D;
            int NewFy1 = Fy1;
            int NewFx2 = Fx2 + D;
            int NewFy2 = Fy2;
            
           
            if(((Px1<NewFx1)&(NewFx1<Px2)) & ((Py1>NewFy1)&(NewFy1>Py2)) & ((Px1<NewFx2&NewFx2<Px2)) & (Py1>NewFy2&NewFy2>Py2))
            {
                Console.WriteLine("275%");
            }
            else if ((NewFx1 == Px2)&Fy1!=Py2)
            {
                Console.WriteLine("150%");
            }

            else if (NewFx1 == Px2)
            {
                Console.WriteLine("150%");
            }
             else if (Fy1 == Py2 )
            {
                Console.WriteLine("225%");
            }
            else if ((Fy1 == Py2) & (Fy1 == Py1))
            {
                Console.WriteLine("75%");
            }
            
            else
            {
                Console.WriteLine("0%");
            }
            




        }
    }
}
