using System;

namespace ProblemFive
{
    struct Number
    {
        public int value;
        public int ones;
        public Number(int value, int ones)
        {
            this.value = value;
            this.ones = ones;
        }
    }
 
    class ProblemFive
    {


        public static int countOnes(int a)
        {
            int count = 1;
            for (int i = 1; i < 7; i++)
            {
                int firstBit = a >> i;
                if (firstBit != 1) continue;
                int secondBit = a >> i + 1;
                if (firstBit == secondBit) count++;
            }
            return count;        
            
        }
        static void Main()
        {
            Number[] values = new Number[8];
  
            for (int i = 0; i < 8; i++)
            {
                values[i].value = int.Parse(Console.ReadLine());
                values[i].ones = countOnes(values[i].value);
            }
            int max = values[0].ones;
            for (int i = 1; i < 8; i++)
            {
                if (values[i].ones > max) max = values[i].ones;
            }
            Console.WriteLine(max);
            Console.WriteLine(max);

        }
    }
}
