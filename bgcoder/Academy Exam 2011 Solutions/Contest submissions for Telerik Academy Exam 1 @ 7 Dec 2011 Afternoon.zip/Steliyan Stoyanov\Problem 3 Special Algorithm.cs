using System;

namespace Special
{
    class Program
    {
        static int SumDigits(int n)
        {
            if(n < 0)
                n *= -1;

            int sum = 0;

            while(true)
            {
                while(n > 0)
                {
                    sum += n % 10;
                    n = n / 10;
                }

                if(sum <= 9)
                    break;

                n = sum;
                sum = 0;
            }

            return sum;
        }

        static void Main(string[] args)
        {
            string str = Console.ReadLine();

            int sum = 0;

            for(int i = 0; i < str.Length; i++)
                if(str[i] >= '0' && str[i] <= '9')
                    sum += (int)(str[i]-'0');



             Console.WriteLine(SumDigits(sum));

            
        }
    }
}
