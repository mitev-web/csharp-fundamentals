using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int m = int.Parse( Console.ReadLine());
            int n;
            int i;
            int p;

            for (n = m; n >= 1; n--)
            {

                for (i = 1; i <= n; i++)
                {
                    Console.Write("*");


                }

                for (
                Console.WriteLine();
            }
                
        }
    }
}
