using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task5
{
    class Program
    {
        static void Main(string[] args)
        {
            byte mask = 0x80;
            byte[] numbers = new byte[8];
           
            bool[,] matrix = new bool[8,8];
            for (int i = 0; i < 8; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
                mask = 0x80;
                for (int j = 0; j < 8; j++)
                {
                    if ((mask & numbers[i]) == mask)
                        matrix[i,j] = true;
                    else if ((mask & numbers[i]) == 0)
                        matrix[i,j] = false;
                    mask >>= 1;
                }
            }
            /*
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (matrix[i, j])
                        Console.Write("1 ");
                    else
                        Console.Write("0 ");
                }
                Console.WriteLine("");
            }*/
            bool currEl;
            int len = 0;
            int maxLen = 0;
            int maxLenCount = 0;
            for (int i = 0; i < 8; i++)
            {
                len = 0;
                for (int j = 0; j < 8; j++)
                {
                    currEl = matrix[i, j];
                    if (currEl)
                    {
                        len++;
                        if (len > maxLen)
                        {
                            maxLen = len;
                            maxLenCount = 0;
                        }
                        if (len == maxLen)
                            maxLenCount++;
                    }
                    else
                        len = 0;
                }   
            }
            for (int j = 0; j < 8; j++)
            {
                len = 0;
                for (int i = 0; i < 8; i++)
                {
                    currEl = matrix[i, j];
                    if (currEl)
                    {
                        len++;
                        if (len > maxLen)
                        {
                            maxLen = len;
                            maxLenCount = 0;
                        }
                        if (len == maxLen && len>1)
                            maxLenCount++;
                    }
                    else
                        len = 0;
                }
            }
            Console.WriteLine(maxLen);
            Console.WriteLine(maxLenCount);
        }
    }
}
