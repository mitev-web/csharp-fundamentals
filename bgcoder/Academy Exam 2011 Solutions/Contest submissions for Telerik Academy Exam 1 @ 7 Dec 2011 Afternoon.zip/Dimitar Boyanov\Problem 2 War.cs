using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace War
{
    class Program
    {
        static void Main()
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            if (d < 0)
            {
                Console.WriteLine(0 + "%");
                return;
            }

            int missileX = fx + d;
            int missileY = fy;
            int score=0;

            px1 = Math.Min(px1, px2);
            px2 = Math.Max(px1, px2);
            py1 = Math.Min(py1, py2);
            py2 = Math.Max(py1, py2);

            if ((px1 <= missileX) && (missileX <= px2) &&
                (py1 <= missileY) && (missileY <= py2))
            {
                score = score + 100;
            }

            if ((px1 <= missileX + 1) && (missileX + 1 <= px2) &&
                (py1 <= missileY) && (missileY <= py2))
            {
                score = score + 75;
            }

            if ((px1 <= missileX) && (missileX <= px2) &&
                (py1 <= missileY - 1) && (missileY - 1 <= py2))

            {
                score = score + 50;
            }

            if ((px1 <= missileX) && (missileX <= px2) &&
                (py1 <= missileY + 1) && (missileY + 1 <= py2))
            {
                score = score + 50;
            }

            Console.WriteLine(score + "%");
        }
    }
}
