using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplicatio
{
    class SpecialAlgorithm
    {
        static void Main(string[] args)
        {            
            double number = double.Parse(Console.ReadLine().Replace('.', ','));
            double temp = number;
            int sum = 0;
            int sum2 = 0;
            for (int i = 0; i < 300; i++)
            {
                do
                {
                    sum += ((int)temp % 10);
                    temp = (temp / 10);
                } while (Math.Round(temp)!=0);                
                if (sum>9)
                {
                    sum2 = sum;
                    sum = 0;
                    temp = sum2;
                    continue;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine(sum);
        }
    }
}
