using System;

namespace Problem_2_War
{
    class Program
    {
        static void Main()
        {
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            double a = 0;
            
            if (pX1 == pX2 && pY1 != pY2)
            {
                if ((d == (pX1 - fX) && fY > pY1 && fY < pY2) || (d == (pX1 - fX) && fY > pY2 && fY < pY1))
                {
                    a = 200;
                }
                else if (d == (pX1 - fX) && (fY == pY1 || fY == pY2))
                {
                    a = 150;
                }
                else if ((d == (pX1 - fX - 1) && fY > pY1 && fY < pY2) || (d == (pX1 - fX - 1) && fY > pY2 && fY < pY1))
                {
                    a = 75;
                }
            }
            else if (pX1 != pX2 && pY1 == pY2)
            {
                if ((pX1 < pX2) && d >= (pX1 - fX) && d < (pX2 - fX) || (pX2 < pX1) && d < (pX1 - fX) && d >= (pX2 - fX))
                {
                    a = 175;
                }
                else if ((pX1 < pX2) && d == (pX2 - fX) || (pX2 < pX1) && d == (pX2 - fX))
                {
                    a = 100;
                }
                else if ((d == (pX1 - fX - 1) && fY == pY1) || (d == (pX1 - fX - 1) && fY == pY1))
                {
                    a = 75;
                }
            }
            else if ((pX1 == pX2 && pY1 == pY2))
            {
                if (d == (pX1 - fX))
                {
                    a = 100;
                }
                else if (d == (pX1 - fX - 1))
                {
                    a = 75;
                }
            }
            else if (fY > pY1 && fY < pY2 || fY > pY2 && fY < pY1)
            {
                if ((pX1 < pX2) && d > (pX1-fX) && d < (pX2-fX) || (pX2 < pX1) && d < (pX1-fX) && d >= (pX2-fX))
                {
                    a = 275;
                }
                else if ((pX1 < pX2) && d == (pX2 - fX) || (pX2 < pX1) && d == (pX1 - fX))
                {
                    a = 200; 
                }
                else if ((pX1 < pX2) && d == (pX1 - fX - 1) || (pX2 < pX1) && d == (pX2 - fX - 1))
                {
                    a = 75; 
                }
            }
            else if (fY == pY1 || fY == pY2)
            {
                if (d >= (pX1 - fX) && d < (pX2 - fX) || d < (pX1 - fX) && d >= (pX2 - fX))
                {
                    a = 225;
                }
                else if ((pX1 < pX2) && d == (pX2 - fX) || (pX2 < pX1) && d == (pX1 - fX))
                {
                    a = 150;
                }
                else if ((pX1 < pX2) && d == (pX1 - fX - 1) || (pX2 < pX1) && d == (pX2 - fX - 1))
                {
                    a = 75;
                }
            }


            Console.WriteLine("{0}%", a);
        }
    }
}      
 