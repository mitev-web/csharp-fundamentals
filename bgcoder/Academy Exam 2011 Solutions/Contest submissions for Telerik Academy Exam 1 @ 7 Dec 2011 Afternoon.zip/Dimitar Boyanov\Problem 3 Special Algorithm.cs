using System;
 
namespace SpecialAlgorithm
{
    class Program
    {
        static void Main()
        {
            double n = double.Parse(Console.ReadLine());
            n = Math.Abs(n);
            double sumOfDigits = n;
 
            while (0 <= n && n >= 10)
            {
                sumOfDigits = 0;
                for (int i = 0; i < 300; i++)
                {
                    if (i == 0)
                    {
                        n = Math.Round(n);
                    }
                    sumOfDigits = sumOfDigits + Math.Floor(n % 10);
                    n = Math.Floor(n / 10);
                }
                n = sumOfDigits;
            }
 
            Console.WriteLine(Math.Round(sumOfDigits));
        }
    }
}