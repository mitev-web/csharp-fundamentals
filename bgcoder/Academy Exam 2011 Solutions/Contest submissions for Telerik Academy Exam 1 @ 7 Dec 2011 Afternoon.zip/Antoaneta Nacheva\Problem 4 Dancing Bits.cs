using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.dancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort K = ushort.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            int input = N;
            
          
            for (int i = 1; i <= N; i++)
            {
                string userInput = Console.ReadLine();
                
            }
                     
           
        }
    }
}
