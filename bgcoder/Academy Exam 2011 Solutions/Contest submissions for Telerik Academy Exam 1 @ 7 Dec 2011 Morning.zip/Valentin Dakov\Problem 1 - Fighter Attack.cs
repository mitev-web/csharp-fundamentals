using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = 0;
            int py1 = 0;
            int px2 = 0;
            int py2 = 0;
            int fx = 0;
            int fy = 0;
            int d = 0;
            px1 = int.Parse(Console.ReadLine());
            py1 = int.Parse(Console.ReadLine());
            px2 = int.Parse(Console.ReadLine());
            py2 = int.Parse(Console.ReadLine());
            fx = int.Parse(Console.ReadLine());
            fy = int.Parse(Console.ReadLine());
            d = int.Parse(Console.ReadLine());
            int damage = 0;
            int right, left, top, bot;
            if (px2 < px1)
            {
                right = px1;
                left = px2;
            }
            else
            {
                right = px2;
                left = px1;
            }
            if (py2 < py1)
            {
                top = py1;
                bot = py2;
            }
            else
            {
                top = py2;
                bot = py1;
            }
            if (fx + d <= right && fx + d >= left && fy >= bot && fy <= top)
            {
                damage =damage + 100;
                if (fy-1 >= bot)
                    damage =damage + 50;
                if (fy+1 <= top)
                    damage += 50;
                if (fx + d + 1 <= right)
                    damage += 75;
            }
            else if (fx + d <= left && fy >= bot && fy <= top)
            {
                if (fx + d + 1 >= left)
                    damage += 75;
            }
            else if (fy <= bot && fy >= top)
            {
                if (fy + 1 >= bot)
                    damage += 50;
                if (fy - 1 <= top)
                    damage += 50;
            }
            Console.WriteLine("{0}%", damage);
        }
    }
}
