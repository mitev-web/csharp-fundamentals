using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            int plantX1 = int.Parse(Console.ReadLine());
            int plantY1 = int.Parse(Console.ReadLine());
            int plantX2 = int.Parse(Console.ReadLine()); 
            int plantY2 = int.Parse(Console.ReadLine()); 
            int fighterX = int.Parse(Console.ReadLine()); 
            int fighterY = int.Parse(Console.ReadLine()); 
            int distance = int.Parse(Console.ReadLine()); 
            int hitSpot = distance + fighterX;
            if (hitSpot + 1 == plantX1 || hitSpot - 1 == plantX2)
            {
                if (fighterY >= plantY2 && fighterY <= plantY1) Console.WriteLine("75%");
            }
            else if (fighterY == plantY1 + 1 || fighterY == plantY2 -1) Console.WriteLine("50%");
            else if (hitSpot - 1 < plantX1 || hitSpot > plantX2 ||
                fighterY > plantY1 + 1 || fighterY < plantY2 - 1)
            {
                Console.WriteLine("0%");
            }

            else if (fighterY == plantY1 ||
                    fighterY == plantY2)
            {
                
                
                    if (hitSpot > plantX1 && hitSpot < plantX2) Console.WriteLine("225%");
                    if (hitSpot == plantX2) Console.WriteLine("150%");
            }
            else if ( hitSpot == plantX2 && fighterY!=plantY1 ||
                      hitSpot == plantX2 && fighterY != plantY2) Console.WriteLine("200%");
            else Console.WriteLine("275%");
                
            
            
        }
    }
}
