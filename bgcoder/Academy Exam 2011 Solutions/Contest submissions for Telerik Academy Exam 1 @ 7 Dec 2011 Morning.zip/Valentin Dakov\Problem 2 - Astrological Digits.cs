using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstroBits
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            input = Console.ReadLine();
            long nNumber = 0;
            long.TryParse(input,out nNumber);
            decimal theNumber = 0;
            decimal.TryParse(input, out theNumber);
            if (nNumber < 0)
                nNumber = nNumber * (-1);
            else if (theNumber < 0)
                theNumber = theNumber * (-1);
            long temp = 0;
            if (nNumber != 0)
            {

                do
                {
                        temp = temp + nNumber % 10;
                        nNumber /= 10;
                        if (nNumber == 0 && temp > 9)
                        {
                            nNumber = temp;
                            temp = 0;
                        }
                } while (temp > 9 || nNumber > 0);
            }
            Console.WriteLine(temp);
        }
    }
}
