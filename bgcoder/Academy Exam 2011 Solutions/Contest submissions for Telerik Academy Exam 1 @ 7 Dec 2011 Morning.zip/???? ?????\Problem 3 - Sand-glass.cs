using System;

namespace SandGlass
{
    class SandGlass
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            // upper side
            int count0 = n;
            int count1 = 0;
            int count2 = n;

            for (int i = 0; i < count0; i++)
            {
                for (int j = 0; j < count1; j++)
                {
                    Console.Write(".");
                }
                for (int k = 0; k < count2; k++)
                {
                    Console.Write("*");
                }
                for (int j = 0; j < count1; j++)
                {
                    Console.Write(".");
                }
                count0--;
                count1++;
                count2 -= 2;
                Console.WriteLine();
            }
            // lower side (without middle point)

            int ct0 = n;
            int ct1 = count1 - 2;
            int ct2 = count2 + 4;
            
            for (int i = 0; i < ct0 - 1; i++)
            {
                for (int j = 0; j < ct1; j++)
                {
                    Console.Write(".");
                }
                for (int k = 0; k < ct2; k++)
                {
                    Console.Write("*");
                }
                for (int j = 0; j < ct1; j++)
                {
                    Console.Write(".");
                }
                ct0--;
                ct1--;
                ct2 += 2;
                Console.WriteLine();
            }
        }
    }
}