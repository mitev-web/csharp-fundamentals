using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] arr = new byte[8];
            byte[,] arr2 = new byte[8,8];
            int max = 0;
            int tocount = 0;

            for (int i = 0; i < arr.Length; i++ )
            {
                arr[i] = byte.Parse(Console.ReadLine());
            }

            for (int i = 0; i < arr.Length; i++)
            {
                int count = 0;
                do
                {
                    if (arr[i] % 2 == 1)
                        arr2[i,count] = 1;
                } while (arr[i] != 0);
            }

            for (int i = 0; i < 8; i++)
            {
                int count = 0;
                for (int i2 = 0; i2 < 8; i2++)
                {
                    if (arr2[i,i2] == 1)
                    {
                        count++;
                        if (max < count)
                              max = count;
                    }
                    else
                        count = 0;
                }
                int count2 = 0;
                for (int i3 = 0; i3 < 8; i3++)
                {
                    if (arr2[i3,i] == 1)
                    {
                        count2++;
                        if (max < count2)
                              max = count2;
                    }
                    else
                        count = 0;

                }
            }

            for (int i = 0; i < 8; i++)
            {
                int count = 0;
                for (int i2 = 0; i2 < 8; i2++)
                {
                    if (arr2[i, i2] == 1)
                    {
                        count++;
                    }
                    else
                        count = 0;
                    if (count == max)
                        tocount++;
                }
                int count2 = 0;
                for (int i3 = 0; i3 < 8; i3++)
                {
                    if (arr2[i3, i] == 1)
                    {
                        count2++;
                    }
                    else
                        count = 0;
                    if (count2 == max)
                        tocount++;
                }
            }
            Console.WriteLine(max);
            Console.WriteLine(tocount);
        }
    }
}
