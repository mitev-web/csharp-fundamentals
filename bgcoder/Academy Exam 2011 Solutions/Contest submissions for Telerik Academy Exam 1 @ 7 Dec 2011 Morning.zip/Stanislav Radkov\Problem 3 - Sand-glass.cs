using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03
{
    class Program
    {
        static void Main(string[] args)
        {
            char dot = '.', star = '*';
            char newLine = '\n';

            Int32 N = Int32.Parse(Console.ReadLine());

            for (int rowCnt = 0; rowCnt < N / 2 + 1; rowCnt++)
            {
                for (int leftDotsCnt = 0; leftDotsCnt < rowCnt; leftDotsCnt++)
                {
                    Console.Write(dot);
                }

                for (int starCnt = 0; starCnt < N- rowCnt*2; starCnt++)
                {
                    Console.Write(star);
                }

                for (int rightDotsCnt = 0; rightDotsCnt < rowCnt; rightDotsCnt++)
                {
                    Console.Write(dot);
                }

                Console.Write(newLine);
            }

            Int32 starCount = 3;
            Int32 dotsCount = N - starCount;

            for (int rowCnt = 0; rowCnt < N / 2; rowCnt++)
            {
                for (int leftDotsCnt = 0; leftDotsCnt < dotsCount/2; leftDotsCnt++)
                {
                    Console.Write(dot);
                }

                for (int starCnt = 0; starCnt < starCount; starCnt++)
                {
                    Console.Write(star);
                }

                for (int rightDotsCnt = 0; rightDotsCnt < dotsCount/2; rightDotsCnt++)
                {
                    Console.Write(dot);
                }

                Console.Write(newLine);
                starCount += 2;
                dotsCount = N - starCount;
            }
        }
    }
}
