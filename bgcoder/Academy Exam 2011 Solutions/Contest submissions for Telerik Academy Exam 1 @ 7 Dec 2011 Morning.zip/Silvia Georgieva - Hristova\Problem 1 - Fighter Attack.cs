using System;

class FighterAttack //problem 1
{
    static void Main()
    {
        string line = Console.ReadLine();
        int px1 = Convert.ToInt32(line);
        line = Console.ReadLine();
        int py1 = Convert.ToInt32(line);
        line = Console.ReadLine();
        int px2 = Convert.ToInt32(line);
        line = Console.ReadLine();
        int py2 = Convert.ToInt32(line);
        line = Console.ReadLine();
        int fx = Convert.ToInt32(line);
        line = Console.ReadLine();
        int fy = Convert.ToInt32(line);
        line = Console.ReadLine();
        int d = Convert.ToInt32(line);
        if (px1 > px2)
        {
            int t = px1;
            px1 = px2;
            px2 = t;
        }
        if (py1 > py2)
        {
            int t = py1;
            py1 = py2;
            py2 = t;
        }
        fx += d;
        int dam = 0;
        if (px1 <= fx && fx <= px2 && py1 <= fy && fy <= py2)
            dam += 100;
        if (px1 <= (fx+1) && (fx+1) <= px2 && py1 <= fy && fy <= py2)
            dam += 75;
        if (px1 <= fx && fx <= px2 && py1 <= (fy + 1) && (fy + 1) <= py2)
            dam += 50;
        if (px1 <= fx && fx <= px2 && py1 <= (fy - 1) && (fy - 1) <= py2)
            dam += 50;
        Console.WriteLine("{0}%", dam);
    }
}
