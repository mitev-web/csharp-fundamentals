using System;


    class Program
    {
        static void Main(string[] args)
        {
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            if (fx+d>=Math.Min(x1,x2) && (fx+d)<=Math.Max(x1,x2) && fy==Math.Max(y1,y2)-1 || fy==Math.Min(y1,y2)+1 )
            {
                Console.WriteLine("50%");
            }
            else if ((fx+d)==(Math.Min(x1,x2)-1) && fy>=Math.Min(y1,y2) && fy<=Math.Max(y1,y2))
            {
                Console.WriteLine("75%");

            }
            else if (fy == y1 && fy == y2 && fx - d == Math.Max(x1, x2) )
            {
                Console.WriteLine("100%");
            }
            else if (fy==y1 || fy==y2 && fx+d == Math.Max(x1,x2) )
            {
                Console.WriteLine("150");
            }
            else if (fy == y1 || fy == y2 && fx + d >= Math.Min(x1, x2) && fx + d < Math.Max(x1, x2) && Math.Max(y1, y2) - Math.Min(y1, y2) > 1 && Math.Max(x1, x2) - Math.Min(x1, x2) > 1)
            {
                Console.WriteLine("225%");
            }
            else if (fy>Math.Min(y1,y2) && fy<Math.Max(y1,y2) && fx-d==Math.Max(x1,x2))
            {
                Console.WriteLine("200%");
            }
            else if(fy>Math.Min(y1,y2) && fy<Math.Min(y1,y2) && fx-d >= Math.Min(x1,x2) && fx-d < Math.Max(x1,x2))
            {
                Console.WriteLine("275%");
            }
            else if (fy==y1 && fy == y2 && fx+d >= Math.Min(x1,x2) && fx+d <Math.Max(x1,x2) )
            {
                Console.WriteLine("175%");
            }
            else if (fy==y1 && fy == y2 && fx-d==Math.Max(x1,x2))
            {
                Console.WriteLine("100%");
            }
            else if (fx==x1 && fx==x2 && fx-d==Math.Max(x1,x2) && fy==y1 && fy==y2)
            {
                Console.WriteLine("100%");
            }
            else
            {
                Console.WriteLine("0%");
            }
        }
    }

