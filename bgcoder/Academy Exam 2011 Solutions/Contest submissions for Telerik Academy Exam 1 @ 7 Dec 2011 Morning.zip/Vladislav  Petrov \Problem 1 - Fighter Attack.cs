using System;

    class FighterAttack
    {
        static void Main(string[] args)
        {
            int x1 =  int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int y2 =  int.Parse(Console.ReadLine());
            int f1 = int.Parse(Console.ReadLine());
            int f2 =  int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            int damage = 0; 

            int xStart = 0; int xFinish = 0;
            int yStart = 0; int yFinish = 0;

           

            if (x1 < x2) 
            {
                xStart = x1;
                xFinish = x2;
            } 
            else 
            {
                xStart = x2;
                xFinish = x1;
            }

            if (y1 < y2)
            {
                yStart = y1;
                yFinish = y2;
            }
            else
            {
                yStart = y2;
                yFinish = y1;
            }

           
            int distanceX = Math.Abs(f1) + Math.Abs(xStart);

            bool check = (f2 >= yStart) && (f2 <= yFinish);

            if (distanceX > d) { damage = 0; }
            if (f2 < yStart) { damage = 0; }

            if ((distanceX  <= d) && check)
            {
                damage += 100;

                if (((f2 + 1) >= yStart) && ((f2 + 1) <= yFinish))
                {
                    damage += 50;
                }
                if (((f2 - 1) >= yStart) && ((f2 - 1) <= yFinish))
                {
                    damage += 50;
                }

                if ((distanceX - 1) <= d)
                {
                    damage += 75;
                }


            }

            if (((distanceX - 1) == d) && check)
            {
                damage += 75;
            }

            Console.WriteLine(damage+"%");
        }
    }

