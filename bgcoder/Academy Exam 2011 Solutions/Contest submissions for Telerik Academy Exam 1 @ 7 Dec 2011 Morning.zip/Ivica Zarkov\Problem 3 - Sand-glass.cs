using System;

    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            for (int i = 1; i < (n+1)/2; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    
                    if (j<i)
                    {
                        Console.Write(".");
                    }
                    if (j >= i && (n - j) > i)
                    {
                        Console.Write("*");
                    }
                    if ((n-j)<i+1)
                    {
                        Console.Write(".");
                    }
                 
                }
              Console.WriteLine();  
            }
            for (int i = 1; i < (n - 1) / 2; i++)
            {
                for (int j = 0; j < n; j++)
                {

                    if ((i+j)<(n-1)/2)
                    {
                        Console.Write(".");
                    }
                    if (((i+j)>=(n-1)/2) && (j-i)<((n+1)/2))
                    {
                        Console.Write("*");
                    }
                    if ((j-i)>=((n+1)/2))
                    {
                        Console.Write(".");
                    }  
                }
                Console.WriteLine();
            }
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }