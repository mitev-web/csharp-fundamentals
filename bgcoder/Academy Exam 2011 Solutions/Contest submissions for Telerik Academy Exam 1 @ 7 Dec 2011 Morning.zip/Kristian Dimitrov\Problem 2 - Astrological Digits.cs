using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
 
namespace _02AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfoByIetfLanguageTag("en-US");
            double n = double.Parse(Console.ReadLine());
            bool real = false;
            if (n < 0)
                n *= -1;
            while (!real)
            {
                decimal m = (decimal)(n % 10);
                if (m != 0)
                {
                    n *= 10;
                }
                if (m == 0)
                {
                    n /= 10;
                    real = true;
                }
            }
 
            if (n == 0)
            {
                Console.WriteLine("0");
                return;
            }
            if (1 <= n && n <= 9)
            {
                Console.WriteLine(n);
                return;
            }
            double p = n / 9;
            double h = Math.Truncate(p);
            int result = (int)n - 9 * (int)h;
            if (result == 0)
                result += 9 - ((int)n - 9 * (int)h);
            Console.WriteLine(Math.Abs(result));
        }
    }
}
