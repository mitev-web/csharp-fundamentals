using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sand_glass
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            /*for (byte i = 0; i < n; i++)
            {
                
                Console.Write("*");
                
            }
            Console.Write("\n");
            */
            byte nstars = n;
            for (byte i = 1; i <= (n/2)+1; i++)
            {
                for (byte z = 1; z < i; z++)
                {
                    Console.Write(".");
                }
                
                for (byte j =1 ; j <= nstars; j++)
                {
                    Console.Write("*");

                }
                for (byte jj =(byte)(i+nstars); jj <= n; jj++)
                {
                    Console.Write(".");

                }
                nstars -= 2;

                Console.Write("\n");
                
            }
            nstars = 3;
            for (byte i = (byte)(n/2); i > 0 ; i--)
            {
                for (byte z = 1; z < i; z++)
                {
                    Console.Write(".");
                }

                for (byte j = 1; j <= nstars; j++)
                {
                    Console.Write("*");

                }
                for (byte jj = (byte)(i + nstars); jj <= n; jj++)
                {
                    Console.Write(".");

                }
                nstars += 2;

                Console.Write("\n");

            }
            
        }
    }
}
