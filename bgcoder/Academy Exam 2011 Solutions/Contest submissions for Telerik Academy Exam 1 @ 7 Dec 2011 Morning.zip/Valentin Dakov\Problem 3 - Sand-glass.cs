using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sand
{
    class Program
    {
        static void Main(string[] args)
        {
            int height;
            height = int.Parse(Console.ReadLine());
            for (byte i = 0; i <= height/2; i++)
            {
                for (byte i1 = 1; i1 <= i; i1++)
                {
                    Console.Write(".");
                }
                for (byte i2 = 1; i2 <= height - i * 2; i2++)
                    Console.Write("*");
                for (byte i3 = 1; i3 <= i; i3++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
            for (int i = height / 2 - 1; i >= 0; i--)
            {
                for (byte i1 = 1; i1 <= i; i1++)
                {
                    Console.Write(".");
                }
                for (byte i2 = 1; i2 <= height - i * 2; i2++)
                    Console.Write("*");
                for (byte i3 = 1; i3 <= i; i3++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
        }
    }
}
