using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());

            char[,] matrix = new char[N, N];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    matrix[i, j] = '.';

                }
            }

            for (int i = 0; i < N/2+1; i++)
            {
                for (int j = i; j < N-i; j++)
                {
                    matrix[i, j] = '*';
                } 
            }

            for (int i = N-1; i > N / 2 ; i--)
            {
                for (int j =N-i-1; j <i+1; j++)
                {
                    matrix[i, j] = '*';
                }
            }




            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j <N; j++)
                {
                    Console.Write(matrix[i,j]);
                }

                Console.WriteLine();
            }


        }
    }
}
