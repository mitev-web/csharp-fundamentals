using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4_DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n=int.Parse(Console.ReadLine());
           
            int[] numbers = new int[n];
            for (int i = 1; i <= n; i++)
            {
                int number = int.Parse(Console.ReadLine());
                numbers[i - 1] = number;
            }
            int result = 0;
            int carryOnes = 0;
            int carryZeros = 0;
            for (int i = n-1; i >= 0; i--)
            {
                int curNumber = numbers[i];
                while (curNumber > 0)
                {
                    int bit = curNumber & 1;
                    curNumber >>= 1;
                    if (bit == 1)
                    {
                        if (carryZeros == k)
                        {
                            result++;
                        }
                        carryZeros = 0;
                        carryOnes++;
                    }
                    else
                    {
                        if (carryOnes == k)
                        {
                            result++;
                        }
                        carryOnes = 0;
                        carryZeros++;
                    }
                }
            }
            if (carryOnes == k)
            {
                result++;
            }
            if (carryZeros == k)
            {
                result++;
            }
            Console.WriteLine(result);
        }
    }
}
