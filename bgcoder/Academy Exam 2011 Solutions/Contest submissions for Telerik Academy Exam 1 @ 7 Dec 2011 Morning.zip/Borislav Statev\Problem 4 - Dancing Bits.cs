using System;
using System.Collections.Generic;

namespace _4.DancingBits
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            ushort k = ushort.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            char lastBit = '0';
            char beforeBit = '0';
            int numberOfDancingSequence = 0;
            int dancingLength = 1;
            string numberBits = "";
            for (int i = 0; i < n; i++)
            {
                int number = int.Parse(Console.ReadLine());
                numberBits = Convert.ToString(number, 2);
                beforeBit = lastBit;
                for (int j = 0; j < numberBits.Length; j++)
                {
                    if (i > 0 || j > 0)
                    {
                        if (numberBits[j] == beforeBit)
                        {
                            dancingLength++;
                        }
                        else
                        {
                            dancingLength = 1;
                        }
                        if (dancingLength == k)
                        {
                            numberOfDancingSequence++;
                        }
                        else if (dancingLength == k + 1)
                        {
                            numberOfDancingSequence--;
                        }
                    }
                    else
                    {
                        if (k == 1)
                        {
                            numberOfDancingSequence++;
                        }
                    }
                    beforeBit = numberBits[j];
                }
                lastBit = beforeBit;
            }
            Console.WriteLine(numberOfDancingSequence);
        }
    }
}
