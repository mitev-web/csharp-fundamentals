using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            long number = 0;

            do
            {
                number = 0;
                foreach (char digit in input)
                {
                    if( Char.IsDigit( digit))
                    {
                        number += long.Parse(digit.ToString());
                    }
                }

                input = number.ToString();               
             }
            while (number > 9) ;

            Console.WriteLine(number);
        }
    }
}
