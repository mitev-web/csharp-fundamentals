using System;

class FightAttacker
{
    static void Main()
    {
        int x1 = int.Parse(Console.ReadLine());
        int y1 = int.Parse(Console.ReadLine());
        int x2 = int.Parse(Console.ReadLine());
        int y2 = int.Parse(Console.ReadLine());
        int fX = int.Parse(Console.ReadLine());
        int fY = int.Parse(Console.ReadLine());
        int d = int.Parse(Console.ReadLine());

        ushort damage = 0;

        int minX = x1;
        int maxX = x2;
        if (x1 > x2)
        {
            minX = x2;
            maxX = x1;
        }

        int minY = y1;
        int maxY = y2;
        if (y1 > y2)
        {
            minY = y2;
            maxY = y1;
        }

        bool centered  =(minX<=fX+d)&&(maxX>=fX+d)&&(minY<=fY)&&(maxY>=fY);
        if (centered)
        {
            damage+=100;
        }

        bool frontDamage = (minX <= fX + d + 1) && (maxX >= fX + d + 1) && (minY <= fY) && (maxY >= fY);
        if (frontDamage)
        {
            damage+=75;
        }

        bool upDamage = (minX <= fX + d) && (maxX >= fX + d) && (minY <= fY + 1) && (maxY >= fY + 1);
        if (upDamage)
        {
            damage += 50;
        }

        bool downDamage = (minX <= fX + d) && (maxX >= fX + d) && (minY <= fY - 1) && (maxY >= fY - 1);
        if (downDamage)
        {
            damage += 50;
        }

        Console.WriteLine("{0}%",damage);
    }
}
