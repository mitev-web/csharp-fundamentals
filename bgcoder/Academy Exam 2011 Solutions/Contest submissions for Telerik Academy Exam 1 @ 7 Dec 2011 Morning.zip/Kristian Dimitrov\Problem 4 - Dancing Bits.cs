using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _04DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int[] numbers = new int[n];
            string allNim=string.Empty;
            int countBits=0;
            for (int i = 0; i < n; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
            for (int z = 0; z < n; z++)
            {
                string s = Convert.ToString(numbers[z], 2);
                allNim += s;
            }
            int r=allNim.Count();
            int[] m= new int[r];
            int count=0;
            foreach (char p in allNim)
            {
                m[count]=int.Parse(p.ToString());
                count++;
            }

            for (int i = 0; i < count-k; i++)
            {
                bool differnt=false;
                bool equal =true;
                for (int z = i+1; z < i+k; z++)
                {
                    if (k > 1)
                    {
                        if (m[i] != m[z])
                            equal = false;
                        if (i + k > count)
                            differnt = true;
                        else if (m[i] != m[i + k])
                            differnt = true;
                    }
                    else
                    {
                        if (m[i] == m[z])
                        {
                            equal = false;
                            differnt = true;
                        }

                    }
                }
                if (differnt && equal)
                {
                    countBits++;
                }
            }
            Console.WriteLine(countBits);

        }
    }
}