using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            string s = Convert.ToString(n);
            int count = s.Length;
            double result = 0;
            double result2 = 0;
            int v = 0;
            double res = 0;
            string s2 = "";
            string re = "";
            int count1 = 0;
            int y = 0;
            string s3 = "";
            double res1 = 0;
            double result1 = 0;
            for (int i = 1; i < count; i++)
            {
                string new1 = s.Remove(count - (count - i));
                if (new1 == ".")
                {
                    break;
                }
                if (i > 1)
                {


                    new1 = new1.Remove(v, v + 1);
                    v = v + 1;
                }
                s2 = s.Remove(0, count - 1);
                res = Convert.ToDouble(s2);
                result = Convert.ToInt32(new1);
                result2 = result2 + result;
                // Console.WriteLine(result);


            }
            result2 = result2 + res;

            for (double x = 0; x < 1000000; x++)
            {
                if (result2 > 9)
                {
                    re = Convert.ToString(result2);
                    count1 = re.Length;
                    for (int i1 = 1; i1 < count1; i1++)
                    {
                        string new2 = re.Remove(count1 - (count1 - i1));
                        if (new2 == ".")
                        {
                            break;
                        }
                        if (i1 > 1)
                        {


                            new2 = new2.Remove(y, y + 1);
                            y = y + 1;
                        }
                        s3 = new2.Remove(0, count - 1);
                        res1 = Convert.ToInt32(s3);
                        result1 = Convert.ToInt32(new2);
                        result2 = result2 + result1;
                        // Console.WriteLine(result);


                    }
                    result2 = result2 + res1;
                }

            }
            Console.WriteLine(result2);

        }
    }
}