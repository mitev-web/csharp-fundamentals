using System;

class jet
{
    static void Main()
    {

        int pX1=2;
        int pX2=5;
        int pY1=6;
        int pY2=3;

        int fX=-6;
        int fY=3;

        int distance=9;

        int hitPointX;
        int hitPointY;

        
        int damageUp ;
        int damageDown;
        int damageFront;
        int totalDamage = 0;

        
        pX1=int.Parse(Console.ReadLine());
        pY1 = int.Parse(Console.ReadLine());
        
        pX2=int.Parse(Console.ReadLine());
        pY2=int.Parse(Console.ReadLine());

        
        fX=int.Parse(Console.ReadLine());
        
        fY=int.Parse(Console.ReadLine());
        
        distance=int.Parse(Console.ReadLine());

        hitPointX=fX+distance;
        hitPointY=fY;

        damageUp = hitPointY + 1;
        damageDown = hitPointY - 1;
        damageFront = hitPointX + 1;
      
        if (((hitPointX >= pX1) && (hitPointX <= pX2))) //&& ((hitPointY >= pY1) && (hitPointY <= pY2)))
        //{
        //    Console.WriteLine("hit");
        //}
        //else Console.WriteLine("miss");
        {
            totalDamage = totalDamage + 100;
        }
        if ((damageUp >= pY1) && (damageUp <= pY2))
        {

            totalDamage = totalDamage + 50;
        }
        else if ((damageUp <= pY1) && (damageUp >= pY2))
        {
            totalDamage = totalDamage + 50;
        }
        
        if ((damageDown >= pY1) && (damageDown <= pY2))
        {
            totalDamage = totalDamage + 50;
         }
        else if ((damageDown <= pY1) && (damageDown >= pY2))
        {
            totalDamage = totalDamage + 50;
 
        }
        if ((damageFront >= pX1) && (damageFront <= pX2))
        {
            totalDamage = totalDamage + 75;
        }
        Console.WriteLine("{0}%", totalDamage);
      

        }
}