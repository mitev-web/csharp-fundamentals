using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad3_izpit
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            for (int i = 0; i < n /2 + 1; i++)
            {
                for (int j = 0; j <= n - 1; j++)
                {
                    if (i == 0)
                    {
                        Console.Write("*");
                    }
                    else if (((i + j < n - 1) && (j > i)) || (i==j) || (i +j == n - 1))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
            for (int i = n / 2 + 2; i <= n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == n)
                    {
                        Console.Write("*");
                    }
                    else if ((i + j > n - 1) && (i > j))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
