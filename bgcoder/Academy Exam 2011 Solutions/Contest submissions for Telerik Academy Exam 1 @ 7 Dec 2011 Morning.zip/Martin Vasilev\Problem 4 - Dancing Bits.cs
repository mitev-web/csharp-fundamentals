using System;
using System.Numerics;

namespace task4BigInt
{
    class Program
    {
        static void Main(string[] args)
        {
            //2147483647
            ushort K = ushort.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            BigInteger[] numbers = new BigInteger[N];
            int[] counters = new int[N];
            BigInteger Conc = 0;//The Concatenated Number
            int sumOfConc = 0;
            for (ulong i = 0; i < N; i++)
            {
                numbers[i] = BigInteger.Parse(Console.ReadLine());
            }
            for (ulong s = 0; s < N; s++)
            {
                for (int i = 0; i < 32; i++)
                {
                    uint mask = (uint)(2147483648 >> i);
                    if ((mask & numbers[s]) == mask)
                    {
                        sumOfConc += 32 - i;
                        counters[s] += (32 - i);
                        break;
                    }
                }

            }
            int length = sumOfConc;
            for (ulong p = 0; p < N; p++)
            {
                numbers[p] = numbers[p] << (sumOfConc - counters[p]);
                sumOfConc = sumOfConc - counters[p];
                Conc = Conc | numbers[p];
            }
            //do tuk namiram konkateniranoto 4islo
            BigInteger K1 = 1;//tancuvashti edinici
            for (int i = 1; i < K; i++)
            {
                K1 = K1 | (BigInteger)(1 << i);
            }
            int counter = 0;
            int t = 0;//counter za da proverq dali poredicata edinici e nai vdqsno
            for (int i = 0; i < length; i++)
            {
                if (((K1 & Conc) == K1) && (((K1 << 1) & Conc) != (K1 << 1)) && ((((Conc << 1) & K1) != K1) || (t == 0)))
                {
                    counter++;
                }


                if (((K1 & Conc) == 0) && (((K1 << 1) & Conc) != 0) && ((((K1 >> 1) & Conc) != 0) || (t == 0)))
                {
                    counter++;
                }
                K1 = K1 << 1;
                t++;
            }
            Console.WriteLine(counter);
        }
    }
}
