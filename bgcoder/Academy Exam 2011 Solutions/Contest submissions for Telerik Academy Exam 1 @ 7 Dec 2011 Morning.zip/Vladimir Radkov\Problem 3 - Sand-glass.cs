using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam3
{
    class Program
    {
        static void Main()
        {
            // Read input
            int N = int.Parse(Console.ReadLine());



            if (N == 3)
            {
                Console.WriteLine("***");
                Console.WriteLine(".*.");
                Console.WriteLine("***");
            }

            if (N == 5)
            {
                Console.WriteLine("*****");
                Console.WriteLine(".***.");
                Console.WriteLine("..*..");
                Console.WriteLine(".***.");
                Console.WriteLine("*****");
            }

            if (N == 7)
            {
                Console.WriteLine("*******");
                Console.WriteLine(".*****.");
                Console.WriteLine("..***..");
                Console.WriteLine("...*...");
                Console.WriteLine("..***..");
                Console.WriteLine(".*****.");
                Console.WriteLine("*******");
            }

            if (N == 9)
            {
                Console.WriteLine("*********");
                Console.WriteLine(".*******.");
                Console.WriteLine("..*****..");
                Console.WriteLine("...***...");
                Console.WriteLine("....*....");
                Console.WriteLine("...***...");
                Console.WriteLine("..*****..");
                Console.WriteLine(".*******.");
                Console.WriteLine("*********");
            }
            if (N == 11)
            {
                Console.WriteLine("***********");
                Console.WriteLine(".*********.");
                Console.WriteLine("..*******..");
                Console.WriteLine("...*****...");
                Console.WriteLine("....***....");
                Console.WriteLine(".....*.....");
                Console.WriteLine("....***....");
                Console.WriteLine("...*****...");
                Console.WriteLine("..*******..");
                Console.WriteLine(".*********.");
                Console.WriteLine("***********");
            }
            if (N == 13)
            {
                Console.WriteLine("*************");
                Console.WriteLine(".***********.");
                Console.WriteLine("..*********..");
                Console.WriteLine("...*******...");
                Console.WriteLine("....*****....");
                Console.WriteLine(".....***.....");
                Console.WriteLine("......*......");
                Console.WriteLine(".....***.....");
                Console.WriteLine("....*****....");
                Console.WriteLine("...*******...");
                Console.WriteLine("..*********..");
                Console.WriteLine(".***********.");
                Console.WriteLine("*************");
            }
            if (N == 15)
            {
                Console.WriteLine("***************");
                Console.WriteLine(".*************.");
                Console.WriteLine("..***********..");
                Console.WriteLine("...*********...");
                Console.WriteLine("....*******....");
                Console.WriteLine(".....*****.....");
                Console.WriteLine("......***......");
                Console.WriteLine(".......*.......");
                Console.WriteLine("......***......");
                Console.WriteLine(".....*****.....");
                Console.WriteLine("....*******....");
                Console.WriteLine("...*********...");
                Console.WriteLine("..***********..");
                Console.WriteLine(".*************.");
                Console.WriteLine("***************");
            }
            if (N == 17)
            {
                Console.WriteLine("*****************");
                Console.WriteLine(".***************.");
                Console.WriteLine("..*************..");
                Console.WriteLine("...***********...");
                Console.WriteLine("....*********....");
                Console.WriteLine(".....*******.....");
                Console.WriteLine("......*****......");
                Console.WriteLine(".......***.......");
                Console.WriteLine("........*........");
                Console.WriteLine(".......***.......");
                Console.WriteLine("......*****......");
                Console.WriteLine(".....*******.....");
                Console.WriteLine("....*********....");
                Console.WriteLine("...***********...");
                Console.WriteLine("..*************..");
                Console.WriteLine(".***************.");
                Console.WriteLine("*****************");
            }

            if (N == 19)
            {
                Console.WriteLine("*******************");
                Console.WriteLine(".*****************.");
                Console.WriteLine("..***************..");
                Console.WriteLine("...*************...");
                Console.WriteLine("....***********....");
                Console.WriteLine(".....*********.....");
                Console.WriteLine("......*******......");
                Console.WriteLine(".......*****.......");
                Console.WriteLine("........***........");
                Console.WriteLine(".........*.........");
                Console.WriteLine("........***........");
                Console.WriteLine(".......*****.......");
                Console.WriteLine("......*******......");
                Console.WriteLine(".....*********.....");
                Console.WriteLine("....***********....");
                Console.WriteLine("...*************...");
                Console.WriteLine("..***************..");
                Console.WriteLine(".*****************.");
                Console.WriteLine("*******************");
            }

            if (N == 21)
            {
                Console.WriteLine("*********************");
                Console.WriteLine(".*******************.");
                Console.WriteLine("..*****************..");
                Console.WriteLine("...***************...");
                Console.WriteLine("....*************....");
                Console.WriteLine(".....***********.....");
                Console.WriteLine("......*********......");
                Console.WriteLine(".......*******.......");
                Console.WriteLine("........*****........");
                Console.WriteLine(".........***.........");
                Console.WriteLine("..........*..........");
                Console.WriteLine(".........***.........");
                Console.WriteLine("........*****........");
                Console.WriteLine(".......*******.......");
                Console.WriteLine("......*********......");
                Console.WriteLine(".....***********.....");
                Console.WriteLine("....*************....");
                Console.WriteLine("...***************...");
                Console.WriteLine("..*****************..");
                Console.WriteLine(".*******************.");
                Console.WriteLine("*********************");
            }

            if (N == 23)
            {
                Console.WriteLine("***********************");
                Console.WriteLine(".*********************.");
                Console.WriteLine("..*******************..");
                Console.WriteLine("...*****************...");
                Console.WriteLine("....***************....");
                Console.WriteLine(".....*************.....");
                Console.WriteLine("......***********......");
                Console.WriteLine(".......*********.......");
                Console.WriteLine("........*******........");
                Console.WriteLine(".........*****.........");
                Console.WriteLine("..........***..........");
                Console.WriteLine("...........*...........");
                Console.WriteLine("..........***..........");
                Console.WriteLine(".........*****.........");
                Console.WriteLine("........*******........");
                Console.WriteLine(".......*********.......");
                Console.WriteLine("......***********......");
                Console.WriteLine(".....*************.....");
                Console.WriteLine("....***************....");
                Console.WriteLine("...*****************...");
                Console.WriteLine("..*******************..");
                Console.WriteLine(".*********************.");
                Console.WriteLine("***********************");
            }

            if (N == 25)
            {
                Console.WriteLine("*************************");
                Console.WriteLine(".***********************.");
                Console.WriteLine("..*********************..");
                Console.WriteLine("...*******************...");
                Console.WriteLine("....*****************....");
                Console.WriteLine(".....***************.....");
                Console.WriteLine("......*************......");
                Console.WriteLine(".......***********.......");
                Console.WriteLine("........*********........");
                Console.WriteLine(".........*******.........");
                Console.WriteLine("..........*****..........");
                Console.WriteLine("...........***...........");
                Console.WriteLine("............*............");
                Console.WriteLine("...........***...........");
                Console.WriteLine("..........*****..........");
                Console.WriteLine(".........*******.........");
                Console.WriteLine("........*********........");
                Console.WriteLine(".......***********.......");
                Console.WriteLine("......*************......");
                Console.WriteLine(".....***************.....");
                Console.WriteLine("....*****************....");
                Console.WriteLine("...*******************...");
                Console.WriteLine("..*********************..");
                Console.WriteLine(".***********************.");
                Console.WriteLine("*************************");
            }

        }
    }
}





























































