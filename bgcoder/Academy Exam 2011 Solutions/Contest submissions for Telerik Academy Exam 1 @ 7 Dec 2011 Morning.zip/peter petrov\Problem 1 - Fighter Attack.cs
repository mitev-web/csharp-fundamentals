
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

 

namespace exam1

{

    class Program

    {

        

 

        static void Main(string[] args)

        {

            int px1 = int.Parse(Console.ReadLine());

            int py1 = int.Parse(Console.ReadLine());

            int px2 = int.Parse(Console.ReadLine());

            int py2 = int.Parse(Console.ReadLine());

            int fx = int.Parse(Console.ReadLine());

            int fy = int.Parse(Console.ReadLine());

            int d = int.Parse(Console.ReadLine());

            int damage1 =0;

            int damage2 =0;

            int damage3 =0;

            int damage4 =0;

            int temp =fx + fy - d;

 

             

             

                if (temp > px1)

                {

                    damage1 = 100;

                }

                if (temp <= px2 )

                {

                    damage2 = 75;

                }

                if (temp >= py1 )

                {

                    damage3 = 50;

                }

                if (temp <= py2 )

                {

                    damage4 = 50;

                }

                 

             

 

            Console.WriteLine(damage1 + damage2 + damage3 + damage4 + "%");

             

 

            

        }

    }

}