using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrologicalDigits
{
    class AstrologicalDigits
    {
        static void Main()
        {
            decimal digEnter = decimal.Parse(Console.ReadLine());
            if (digEnter == 0) Console.WriteLine("0");
            else
            {
                int intpart = (int)digEnter;
                decimal decpart = digEnter - intpart;
                decimal secDecpart = decpart;

                if (decpart > 0)
                {
                    decimal twodecpart = 1;
                    while (twodecpart > 0)
                    {
                        secDecpart = secDecpart * 10;
                        decimal poop = (int)secDecpart;
                        twodecpart = secDecpart - poop;
                        if (twodecpart == 0) break;
                    }
                    decpart = secDecpart;
                }
                int digit = (int)digEnter + (int)decpart;
                int valueD;
                int sum = 0;
                while ((sum > 9) || (sum == 0))
                {
                    sum = 0;
                    while (digit > 0)
                    {
                        valueD = (digit % 10);
                        sum += valueD;
                        digit = digit / 10;
                    }
                    digit = sum;

                }
                Console.WriteLine(digit);
            }
        }
    }
}

