using System;

    class Program
    {
        static void Main()
        {

            string InputString = Console.ReadLine();
            InputString = InputString.Replace(".", "");
            
            long n = long.Parse(InputString);
            
            if (n < 0)
            {
                n = Math.Abs(n);
            }


            long remain = 1; long sum = 0;
            
            while ((remain != 0) || (n != 0))
            {
                remain = (long)n % 10;
                n = n / 10;
                sum += remain;
            }

            

            while (sum > 9)
            {
                remain = sum % 10;
                sum = sum / 10;
                sum += remain;
            }

            Console.WriteLine(sum);
            
        }
    }

