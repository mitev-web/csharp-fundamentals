using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.SandGlass
{
    class SandGlass
    {
        static void Main(string[] args)
        {
            int witches = int.Parse(Console.ReadLine());
            for (int  i = 0;  i < witches;  i+=2)
            {
                for (int j = 0; j < i; j+=2)
                {
                    Console.Write(".");
                }
                for (int k = 0; k < witches-i; k++)
                {
                    Console.Write("*");

                }
                for (int j = 0; j < i; j+=2)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }

            for (int i = 3; i < witches+1; i+=2)
            {
                for (int k = 0; k < witches - i; k+=2)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < i; j ++)
                {
                    Console.Write("*");

                }
                for (int k = 0; k < witches - i; k += 2)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
            
        }
    }
}
