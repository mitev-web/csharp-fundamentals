using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {

        static string GetIntBinaryStringRemoveZeros(int n)
        {
            char[] b = new char[32];
            int pos = 31;
            int i = 0;

            while (i < 32)
            {
                if ((n & (1 << i)) != 0)
                {
                    b[pos] = '1';
                }
                else
                {
                    b[pos] = '0';
                }
                pos--;
                i++;
            }
            return new string(b).TrimStart('0');
        }

        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            int[] v = new int[n];

            string stringRep = "";

            for (int i = 0; i < n; i++)
            {
                v[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < n; i++)
               stringRep += GetIntBinaryStringRemoveZeros(v[i]);

            char lastChar = stringRep[0];
            int counter = 1;
            int patternCounter = 0;

            for (int i = 1; i < stringRep.Length; i++)
            {
                if (stringRep[i] == lastChar)
                    counter++;
                else
                {
                    counter = 1;
                    lastChar = stringRep[i];
                }

                if ((counter == k) && (i + 1 < stringRep.Length) && (stringRep[i + 1] != lastChar))  
                    patternCounter++;

                if ((counter == k) && (i + 1 == stringRep.Length))
                    patternCounter++;
            }

            Console.WriteLine(patternCounter);
        }
    }
}