using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
           
           for (int i = 0; i <= N / 2; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (j < N / 2 && i > j)
                        Console.Write(".");
                    else if (j > N / 2 && i+j>=N)
                        Console.Write(".");
                    else
                        Console.Write("*");
                }
                Console.WriteLine();
            }

           for (int i = N/2+1; i < N ; i++)
           {
               for (int j = 0; j < N; j++)
               {
                   if (j < N / 2 - 1 && i+j<=N-2)
                       Console.Write(".");
                   else if (j > N / 2 + 1 && j>i)
                       Console.Write(".");
                   else Console.Write("*");
               }
               Console.WriteLine();
           }
        }
    }
}
