using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p1
{
    class Program
    {
        static void Main(string[] args)
        {

            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            Console.WriteLine(isin(px1,py1,px2,py2,fx,fy,d)+"%");

        }
        static int isin(int px1,int py1,int px2,int py2,int fx, int fy,int d)
        {
            int dam=0;
            if ((fx + d) <=px2 && (fx + d)>= px1 && (fy>=py2)&&(fy<=py1))
                dam = 100;
            if ((fx + 1 + d) <= px2 && (fx + 1 + d) >= px1 && (fy >= py2)&&(fy <= py1))
                dam = dam + 75;
            if ((fx + d) <=px2 && (fx + d)>= px1 && (fy+1>=py2)&&(fy<=py1))
                dam=dam+50;
            if ((fx + d) <= px2 && (fx + d) >= px1 && (fy-1 >= py2) && (fy-1 <= py1))
                dam = dam + 50;
            return dam;


        }
    }
}
