using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{

    class Program
    {
        static void Main()
        {

            int n = Convert.ToInt32(Console.ReadLine());
           
            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                {

                    if (i == 0 || i == n - 1) Console.Write('*');

                    else
                    {
                        if (i < n / 2 + 1)
                        {
                            if (j < i || j > n - i - 1) Console.Write('.');

                            else Console.Write('*');
                        }

                        else
                        {
                            if (j > i || j < n - i - 1) Console.Write('.');

                            else Console.Write('*');
                        
                        }
                    }
                  
                 
                }
              
                
                Console.WriteLine();
            }
           



        }
    }
}
