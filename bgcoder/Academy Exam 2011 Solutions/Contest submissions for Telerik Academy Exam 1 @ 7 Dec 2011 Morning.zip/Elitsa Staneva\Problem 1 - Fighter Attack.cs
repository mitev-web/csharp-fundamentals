using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());

            int Sum = 0;

            int minPx;
            int minPy;
            int width=0;
            int height=0;
            if (Px1 < Px2)
            {
                minPx = Px1;
                width = Px2-Px1;
            }
            else
            {
                minPx = Px2;
                width = Px1-Px2;
            }

            if (Py1 < Py2)
            {
                minPy = Py1;
                height = Py2-Py1;
            }
            else
            {
                minPy = Py2;
                height = Py1-Py2;
            }

            int mx = Fx+D;
            int my = Fy;

            int mxl = mx;
            int myl = my + 1;

            int mxr = mx;
            int myr = my - 1;

            int mxf = mx + 1;
            int myf = my;

            if (mx >= minPx && mx <=minPx + width && my>=minPy && my<=minPy+height)
            {
                Sum += 100;
            }

            if (mxl >=minPx && mxl <=minPx + width && myl >= minPy && myl <= minPy + height)
            {
                Sum += 50;
            }
            if (mxr >= minPx && mxr <=minPx + width && myr >=minPy && myr <=minPy + height)
            {
                Sum += 50;
            }

            if (mxf >= minPx && mxf <= minPx + width && myf >= minPy && myf <= minPy + height)
            {
                Sum += 75;
            }

     
            Console.WriteLine(Sum+"%");

        }
    }
}
