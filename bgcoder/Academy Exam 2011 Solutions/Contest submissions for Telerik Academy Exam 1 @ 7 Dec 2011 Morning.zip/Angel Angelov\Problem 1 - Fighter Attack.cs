using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test1New
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int damage = 0;
            int pxmax;
            int pxmin;
            int pymax;
            int pymin;

            if (px1 > px2)
            {
                pxmax = px1;
                pxmin = px2;
            }
            else
            {
                pxmax = px2;
                pxmin = px1;
            }
            if (py1 > py2)
            {
                pymax = py1;
                pymin = py2;
            }
            else
            {
                pymax = py2;
                pymin = py1;
            }

            if (fy >= pymin && fy <= pymax)
            {
                int dx1 = fx + d;
                int dx2 = fx + d + 1;
                if (dx1 <= pxmax && dx1 >=pxmin)
                {
                    damage += 100;
                }
                if (dx2 <= pxmax && dx2 >= pxmin)
                {
                    damage += 75;
                }
            }

            if (fy + 1 >= pymin && fy-1 <= pymax)
            {
                int dx3 = fx + d;
                if (dx3 <= pxmax && dx3 >= pxmin)
                {
                    damage += 50;
                }  
            }
            if (fy - 1 >= pymin && fy-1 <= pymax)
            {
                int dx3 = fx + d;
                if (dx3 <= pxmax && dx3 >= pxmin)
                {
                    damage += 50;
                }  
            }
            
            Console.WriteLine(damage + "%");
        }
    }
}
