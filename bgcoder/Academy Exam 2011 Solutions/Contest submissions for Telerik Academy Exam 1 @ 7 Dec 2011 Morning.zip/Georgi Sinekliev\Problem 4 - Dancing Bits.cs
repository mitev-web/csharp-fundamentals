using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            short bitsPerGroup = short.Parse(Console.ReadLine());
            short numbersCount = short.Parse(Console.ReadLine());
            StringBuilder number = new StringBuilder();
            for (int i = 0; i < numbersCount; i++)
            {
                int currentNumber = Int32.Parse(Console.ReadLine());
                string current = Convert.ToString(currentNumber, 2);
                //Console.WriteLine(current);
                number.Append(current);
            }
            int numberOfDancingBits = 0;
            for (int i = 0; i < number.Length; i++)
            {
                int current = 0;
                int j;
                if(number[i] == '0')
                {
                    current = i;
                    j = i;
                    while(j<number.Length && number[j]=='0')
                    {
                        j++;                    
                    }
                    j--;
                    if (j - i + 1 == bitsPerGroup) numberOfDancingBits++;
                    i = j;
                }
                if (number[i] == '1')
                {
                    current = i;
                    j = i;
                    while (j<number.Length && number[j] == '1')
                    {
                        j++;
                    }
                    j--;
                    if (j - i + 1 == bitsPerGroup) numberOfDancingBits++;
                    i = j;
                }       
            }
            Console.WriteLine(numberOfDancingBits);

        }
    }
}
