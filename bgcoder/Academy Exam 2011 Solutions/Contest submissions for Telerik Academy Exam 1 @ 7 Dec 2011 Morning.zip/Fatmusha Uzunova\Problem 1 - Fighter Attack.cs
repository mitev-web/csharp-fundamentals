using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int pX1=int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int cX;
            int cY;
            int fX=int.Parse(Console.ReadLine());
            int fY=int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            cX = fX + d;
            cY = fY;

            //if ((cX>pX1)&&(cX<pX2)&&(cY>pY1)&&(cY<pY2)&&((cX+1)<=pX2)&&((cX-1)>=pX1)&&((cY+1)<=pY2))
            if ((cX>pX1)&&(cX<pX2))
            {
                if ((cY>pY1)&&(cY<pY2))
                {
                    if (((cX + 1) <= pX2) && ((cX - 1) >= pX1))
                    {
                        if ((cY+1)<=pY2)
                        {
                            Console.WriteLine("275%");
                        }

                    }

                }

            }
            // second case
            if ((cX >= pX1) && (cX <= pX2))
            {
                if ((cY > pY1) && (cY <= pY2))
                {
                    if (((cX + 1) < pX1) && ((cX + 1) > pX2))
                    {
                        if ((cY + 1) > pY2)
                        {
                            Console.WriteLine("225%");
                        }

                    }

                }

            }
            // case 3
            if ((cX< pX1) && (cX >pX2))
            {
                if ((cY < pY1) && (cY > pY2))
                {
                    
                 Console.WriteLine("0%");
                       

                }

            }






        }
    }
}
