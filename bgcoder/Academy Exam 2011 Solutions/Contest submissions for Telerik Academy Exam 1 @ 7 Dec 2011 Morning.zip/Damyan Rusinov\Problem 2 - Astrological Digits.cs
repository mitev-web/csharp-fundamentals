using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            s = s.Trim().Replace(".", " ").Replace(" ", "");
            BigInteger n = BigInteger.Parse(s);
            BigInteger sum = 0;

            if (n < 0)
                n *= -1;
            if (n == 0)
            {
                n = 0;
                goto cw;
            }

            do
            {
                do
                {
                    if (n % 10 == 0)
                    {
                        n /= 10;
                    }
                } while (n % 10 == 0);

                while (n % 10 != 0)
                {
                    sum = sum + (n % 10);
                    n = n / 10;
                }
                n = sum;
                sum = 0;
            } while (n >= 10);
        cw: Console.WriteLine("{0:F0}", n);
        }
    }
}
