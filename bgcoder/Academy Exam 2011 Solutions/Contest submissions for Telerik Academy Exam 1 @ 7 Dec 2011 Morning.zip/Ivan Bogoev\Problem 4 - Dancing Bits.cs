using System;


namespace TaskFour
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            //uint[] array = new uint[n];
            //int [,]binaryArray = new int[,8];
            string finalString = null;
            string masterString = null;
            bool isTheSame = false;
            char previous = '0';
            char current;
            int counter = 1;
            int dancingBits = 0;
            int mask = 0;

            for (int d = 0; d < n; d++)
            {
                long givenNumber = long.Parse(Console.ReadLine());// Next number
                for (int i = 0; i <= Math.Log(givenNumber, 2); i++)
                {
                    mask = 1 << i;
                    bool checker = (mask & givenNumber) != 0;
                    if (checker)
                    {
                        masterString += "1";
                        //ones++;
                    }
                    else
                    {
                        masterString += "0";
                        //zeros++;
                    }
                }




                for (int i = 0; i < masterString.Length; i++)
                {
                    finalString += masterString[masterString.Length - 1 - i];
                }
                masterString = null;
            }

            for (int i = 1; i < finalString.Length; i++)
            {
                if (k != 1)
                {
                    if (finalString[i] == finalString[i - 1])
                    {
                        counter++;
                    }
                    else
                    {
                        counter = 1;
                    }
                    if (counter == k)
                    {
                        dancingBits++;
                    }
                    if (counter > k)
                    {
                        dancingBits--;
                    }
                }
                else
                {
                    if (finalString[i] != finalString[i - 1])
                    {
                        dancingBits++;
                    }
                }
            }

            if (k == 1)
            {
                dancingBits++;
            }
            
            Console.WriteLine(dancingBits);
        }
    }
}