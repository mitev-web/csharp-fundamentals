using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Forest
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N = byte.Parse(Console.ReadLine());
            string s = "*";
            string dot = ".";
            string[,] forest = new string[N, N];

            for (int i = 0; i < N; i++)
            {
                for (int f = 0; f < N; f++)
                {
                    forest[i, f] = dot;
                }
            }
            int n = N;

            for (int i = 0, d = 0; i < N; i++)
            {
                for (; d < n; d++)
                {
                    forest[i, d] = s;
                }
                if (i < N / 2)
                {
                    d = i;
                    d++;
                    n--;
                }
                else
                {
                    if (N % 2 != 0)
                    {
                        for (int g = 0; i < N; i++)
                        {
                            for (d = 0; d < N; d++)
                            {
                                forest[i, d] = string.Copy(forest[i - g, d]);
                            }
                            g++;
                            g++;
                        }
                        break;
                    }
                    else
                    {
                        for (int g = 1; i < N; i++)
                        {
                            for (d = 0; d < N; d++)
                            {
                                forest[i, d] = string.Copy(forest[i - g, d]);
                            }
                            g++;
                            g++;
                        }
                        break;
                    }

                }
                //else
                //{
                //    d = 2;
                //    d--;
                //    n++;
                //}
            }
            for (int i = 0; i < N; i++)
            {
                for (int f = 0; f < N; f++)
                {
                    Console.Write(forest[i, f]);
                }
                Console.WriteLine();
            }
        }
    }
}
