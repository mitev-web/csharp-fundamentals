using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Sand_glass
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            string userInput = Console.ReadLine();
            byte n = byte.Parse(userInput);

            for (int i = 0; i < (n / 2) + 1; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == 0)
                    {
                        Console.Write("*");
                        continue;
                    }
                    else if (i <= (n / 2) + 1)
                    {
                        if (i <= j && j < n - i)
                        {
                            Console.Write("*");
                            continue;
                        }
                        else
                        {
                            Console.Write(".");
                            continue;
                        }
                    }
                }
                Console.WriteLine();
            }
            for (int i = (n / 2) - 1; i >= 0; i--)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == 0)
                    {
                        Console.Write("*");
                        continue;
                    }
                    else if (i == n / 2)
                    {
                        break;
                    }
                    else if (i < (n / 2))
                    {
                        if (i <= j && j < n - i)
                        {
                            Console.Write("*");
                            continue;
                        }
                        else
                        {
                            Console.Write(".");
                            continue;
                        }
                    }
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }
}
