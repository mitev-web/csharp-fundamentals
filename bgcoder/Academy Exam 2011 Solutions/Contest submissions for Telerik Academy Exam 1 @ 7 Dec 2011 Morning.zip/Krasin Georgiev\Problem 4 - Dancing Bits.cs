using System;

class DancingBits
{
    static void Main()
    {
        ushort k = ushort.Parse(Console.ReadLine());
        ushort n = ushort.Parse(Console.ReadLine());
        string tmp;
        uint tmpNumber;
        string dancingRow = "";
        int count = 0;

        //uint n1 = 3;
        //uint n2 = 5;
        //uint n3 = 199;

        for (int i = 0; i < n; i++)
        {
            tmp = Console.ReadLine();
            tmpNumber = uint.Parse(tmp);
            dancingRow += Convert.ToString(tmpNumber, 2);
        }

        //dancingRow = Convert.ToString(n1, 2) + Convert.ToString(n2, 2) + Convert.ToString(n3, 2);
        //Console.WriteLine(dancingRow);
        //Console.WriteLine(dancingRow.Length);
        long dancingRowNum=Convert.ToInt64(dancingRow,2);
        long dancingRowNumMasked;

        long mask = (long)(Math.Pow(2, (k + 2))-1);
        long mask2;
        long searchOnes = (long)(Math.Pow(2, (k + 1))-2);
        long searchZeroes = (long)(Math.Pow(2, (k + 1)) + 1);
        bool yes=false;


        for (int i = 0; i < dancingRow.Length-k-2; i++)
        {
            mask2 = mask << i;
            dancingRowNumMasked = dancingRowNum & mask2;
            yes= (((searchOnes<<i)^dancingRowNumMasked) ==0) || (((searchZeroes<<i)^dancingRowNumMasked) ==0);
            if (yes)
            {
                count++;
            }
        }

        mask2 = mask >> 1;
        dancingRowNumMasked = dancingRowNum & mask2;
        yes = (((searchOnes >>1) ^ dancingRowNumMasked) == 0) || (((searchZeroes >>1) ^ dancingRowNumMasked) == 0);
        if (yes)
        {
            count++;
        }
        mask2 = mask << dancingRow.Length - k - 1;
        dancingRowNumMasked = dancingRowNum & mask2;
        yes = (((searchOnes << dancingRow.Length - k) ^ dancingRowNumMasked) == 0) || (((searchZeroes << dancingRow.Length - k) ^ dancingRowNumMasked) == 0);
        if (yes)
        {
            count++;
        }


        Console.WriteLine(count);

    }
}
