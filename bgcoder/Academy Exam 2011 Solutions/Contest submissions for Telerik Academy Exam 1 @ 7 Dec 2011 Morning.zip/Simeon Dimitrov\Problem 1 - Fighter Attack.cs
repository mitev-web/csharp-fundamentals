using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int missile100 = fx + d;
            int missile50 = fx + d;
            int missile75 = fx + d + 1;
            int points = 0;
            int points2 = 0;
            int change;
            if (px1 > px2)
            {
                change = px1;
                px1 = px2;
                px2 = change;
            }
            if (py1 > py2)
            {
                change = py1;
                py1 = py2;
                py2 = change;
            }
            if (missile100 >= px1 && missile100 <= px2 && fy >= py1 && fy <=py2)
            {
                points = points + 100;
            }
            if (missile75 >= px1 && missile75 <= px2 && fy >= py1 && fy <= py2)
            {
                points = points + 75;
            }
            if (missile50 >= px1 && missile50 <= px2 && fy +1 >= py1 && fy +1 <= py2)
            {
                points = points + 50;
            }
            if (missile50 >= px1 && missile50 <= px2 && fy - 1 >= py1 && fy - 1 <= py2)
            {
                points = points + 50;
                
            }

            Console.WriteLine("{0}%", points);
        }
    }
}
