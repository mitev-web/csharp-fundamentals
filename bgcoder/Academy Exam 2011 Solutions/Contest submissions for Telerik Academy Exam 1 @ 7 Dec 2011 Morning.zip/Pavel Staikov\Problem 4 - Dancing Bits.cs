using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p4
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int []a= new int[n];
            int sum=0;
            for (int i = 0; i < n; i++)
            {
                 a[i] = int.Parse(Console.ReadLine());
                sum=sum+(bitstart(a[i])+1);
               // Console.WriteLine("starts="+bitstart(a[i]));
            }
           // Console.WriteLine("sum" + sum);
            int[] b = new int[sum];
            
           // Console.WriteLine("blength"+sum1);
            int broi = 0;
            for (int i = 0; i < n; i++)
            {
                
                for (int p = bitstart(a[i]); p >= 0; p--)
                {
                    b[broi] = takebit(a[i], p);
                    //Console.WriteLine("b=" +b[br]);
                    broi++;
                }
            }

            
            int b0=0;
            int b1=0;

            for( int i=1;i<sum-k-2;i++)
            {
                if ((suma(i, k, b) == 0)) //&& b[i] != b[i - 1] && b[i + k - 1] != b[i + k])
                b0++;
            }
            //Console.WriteLine("b0=" + b0);
            for (int i = 1; i < sum-k-2; i++)
            {
                if((suma(i, k, b) == 1))//&& b[i]!=b[i-1] && b[i+k-1]!=b[i+k])
                    b1++;
            }
            //Console.WriteLine("b1=" + b1);
            Console.WriteLine(b0+b1);

          }
        static int takebit(int n, int p)
        {
            if ((n & (1 << p)) != 0) return 1;
            else
                return 0;
        }
        static int bitstart(int n)
        {
           int br=0;
            for (int p = 8 * sizeof(int) - 1; p >= 0; p--)
            {
                
                if (takebit(n, p) == 1) break;
                else
                br++;
            }
            return (8 * sizeof(int) - 1 - br);
        }


        static int suma(int n, int k, int[] a)
        {
            int suma = 0;
            for (int i = n; i <=n+ k-1; i++)
            {
                suma = suma+ a[i];
            }
            return suma;
        }

    }
}
