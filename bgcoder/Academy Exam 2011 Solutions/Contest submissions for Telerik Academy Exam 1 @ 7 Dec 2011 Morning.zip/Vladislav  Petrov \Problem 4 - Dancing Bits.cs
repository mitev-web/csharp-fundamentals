using System;
using System.Numerics;


    class Program
    {
        static void Main(string[] args)
        {
            int k = 3;
            int n1 = 3;
            int n2 = 4;
            int n3 = 5; 
            int n4 = 6; 
            int n5 = 14;
            int n6 = 143;
            string strN1 = Convert.ToString(n1, 2);
            string strN2 = Convert.ToString(n2, 2);
            string strN3 = Convert.ToString(n3, 2);
            string strN4 = Convert.ToString(n4, 2);
            string strN5 = Convert.ToString(n5, 2);
            string strN6 = Convert.ToString(n6, 2);

            string resultString = strN1 + strN2 + strN3 + strN4 + strN5 + strN6;
            //Console.WriteLine(resultString);

            int counter0 = 0;
            int counter1 = 0;

            for (int i = 0; i < resultString.Length; i++)
            {
                if (i < resultString.Length-2)
                {
                    if ((resultString[i] == '0') && (resultString[i + 1] == '0') && (resultString[i + 2] == '0'))
                    {
                        counter0++;
                    }
                    if ((resultString[i] == '1') && (resultString[i + 1] == '1') && (resultString[i + 2] == '1'))
                    {
                        counter1++;
                    }
                }
            }
            Console.WriteLine(counter1 + counter0);
            
        }
    }

