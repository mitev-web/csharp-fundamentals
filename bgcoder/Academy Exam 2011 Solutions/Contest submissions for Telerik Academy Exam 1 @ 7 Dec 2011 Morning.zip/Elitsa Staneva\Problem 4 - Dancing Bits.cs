using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        public static string Reverse(string str)
        {
            int len = str.Length;
            char[] arr = new char[len];

            for (int i = 0; i < len; i++)
            {
                arr[i] = str[len - 1 - i];
            }

            return new string(arr);
        }

        static void Main(string[] args)
        {
            int K = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            int [] conc = new int[25600];
            int rem = 0;
            int br = 0;
            string str = "";
            int count = 0;

           /* for (int i = 0; i < N; i++)
            {
                int dec = int.Parse(Console.ReadLine());
                while (dec > 0)
                {
                    rem = dec % 2;
                    dec /= 2;
                    conc[br] = rem;
                    br++;
                }
            }

            for (int i = 0; i < br; i++)
                Console.WriteLine(conc[i]);*/
            string str1 = "";

            for (int i = 0; i < N; i++)
            {
                int dec = int.Parse(Console.ReadLine());
                str1 = "";
                while (dec > 0)
                {
                    rem = dec % 2;
                    dec /= 2;
                    str1 += rem;
                    br++;
                }
                str1 = Reverse(str1);
                str += str1;
            }
           // Console.WriteLine(str);
            if (K == 1)
                Console.WriteLine(br);
            else
            {
                for (int j = 0; j < br - K; j++)
                {
                    if (str[j + K - 1] != str[j + K])
                    {
                        bool fl = true;
                        for (int f = j; f < j + K-1; f++)
                        {
                        
                            if (str[f] != str[f + 1])
                            {
                                fl = false;
                            }
                        }
                        if (fl == true)
                            count++;
                    }
                }
                
                Console.WriteLine(count);
            }

            
        }
    }
}
