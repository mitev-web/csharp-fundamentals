using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int count = n;

            for (int i = 0; i < n; i++)
            {

                if (i < n)
                {
                    System.Console.Write("*");
                }

                else
                {
                    System.Console.Write(".");
                }
            }
            Console.WriteLine();

            for (int i = 2; i <= (n); i++)
            {

                for (int j = 1; j <= (n); j++)
                {

                    if (j == count || j == ( n))
                    {
                        Console.Write("*");
                    }

                    else
                    {
                        System.Console.Write(".");
                    }
                }
                System.Console.WriteLine();
                count--;
            }




            for (int i = 0; i <n; i++)
            {
                System.Console.Write("*");
            }
        }
    }
}