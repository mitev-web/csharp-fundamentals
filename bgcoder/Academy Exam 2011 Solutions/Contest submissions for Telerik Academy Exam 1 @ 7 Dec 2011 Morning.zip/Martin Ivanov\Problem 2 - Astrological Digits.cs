using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace AstrologicalDigitsString
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            BigInteger sum = 0;
            BigInteger newNum;

            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] != '.' && input[i] != '-')
                {
                    sum += (BigInteger)input[i] - 48;
                }
            }

            if (sum <= 9)
            {
                Console.WriteLine(sum);
            }

            else
            {
                newNum = sum;
                sum = 0;
                while (true)
                {
                    while (newNum != 0)
                    {
                        sum += (newNum % 10);
                        newNum /= 10;
                    }
                    if (sum <= 9)
                    {
                        break;
                    }
                    newNum = sum;
                    sum = 0;
                }
                Console.WriteLine(sum);
            }
        }
    }
}
