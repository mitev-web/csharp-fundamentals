using System;
 
class AstrologicalDigit
{
    static void Main()
    {
        string numberString = Console.ReadLine();
        decimal N = decimal.Parse(numberString);
        //decimal N = -1337M;
        int modulNumber = (int)Math.Abs(N);
        decimal digit=0;
        //int doubleLength = (modulNumber % 1).ToString().Length - 2;
        for (int i = 1; i < 600; i++)
        {
           // if (doubleLength != -1)
           // {
            //    modulNumber = modulNumber * (int)Math.Pow(10, doubleLength);
           // }
            decimal resultDigit = modulNumber % 10;
            int length = modulNumber.ToString().Length - 2;
            digit = digit + resultDigit;
            modulNumber = modulNumber / 10;
            if (digit <= 9 && length == -1)
            {
                Console.WriteLine(digit);
                break;
            }
            else if (digit > 9 && length == -1)
            {
                modulNumber = (int)digit;
                digit = 0;
            }
        }
         
         
    }
}