using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace Task04
{
    class Program
    {
        static void Main(string[] args)
        {
            int K = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            int[] numbers = new int[N];
            int count = 0;
            int zeros = 0;
            int ones = 0;
  
            for (int i = 0; i < N; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
            StringBuilder sb = new StringBuilder();
            for (int i = N-1; i > -1; i--)
            {
                int tempnumb = numbers[i];
                while (tempnumb != 0)
                {
                    if ((tempnumb & 1) == 1)
                    {
                        sb.Insert(0, "1");
                    }
                    else
                    {
                        sb.Insert(0, "0");
                    }
                    tempnumb = tempnumb >> 1;
                }
            }
            string numberStr = sb.ToString();
  
            for (int i = 1; i < numberStr.Count(); i++)
            {
                if (numberStr[i] == '0')
                {
                    zeros++;
                }
                else
                {
                    ones++;
                }
                if (numberStr[i] == numberStr[i - 1])
                {
                    if (numberStr[i] == '0')
                    {
                        zeros++;
                        if (zeros == K)
                        {
                            if (i < N)
                            {
                                if (numberStr[i + 1] != '0')
                                {
                                    count++;
                                    zeros = 0;
                                }
                                else
                                {
                                    ones = 0;
                                }
                            }
                            else
                            {
                                count++;
                            }
                        }
                    }
                    else
                    {
                        if (ones == K)
                        {
                            if (i < N)
                            {
                                if (numberStr[i + 1] != '1')
                                {
                                    count++;
                                    ones = 0;
                                }
                                else
                                {
                                    ones = 0;
                                }
                            }
                            else
                            {
                                count++;
                            }
                          
                        }
                        ones++;
                    }
                }
                else
                {
                    zeros = 0;
                    ones = 0;
                }
            }
           Console.WriteLine(count);
                 
              
        }
    }
}