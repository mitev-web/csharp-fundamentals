using System;
using System.Collections.Generic;

namespace _5.Lines
{
    class Lines
    {
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            byte maxLineLength = 0;
            byte someLineLength = 0;
            byte numberOfLines = 0;
            for (byte i = 0; i < 8; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
                for (byte j = 0; j < 8; j++)
                {
                    if ((numbers[i] & ((byte)1 << j)) != 0)
                    {
                        someLineLength++;
                        if (someLineLength > maxLineLength)
                        {
                            maxLineLength = someLineLength;
                            numberOfLines = 1;
                        }
                        else if (someLineLength == maxLineLength)
                        {
                            numberOfLines++;
                        }
                    }
                    else
                    {
                        someLineLength = 0;
                    }
                }
                someLineLength = 0;
            }

            for (int i = 0; i < 8; i++)
            {
                for (byte j = 0; j < 8; j++)
                {
                    if ((numbers[j] & ((byte)1 << i)) != 0)
                    {
                        someLineLength++;
                        if (someLineLength > maxLineLength)
                        {
                            maxLineLength = someLineLength;
                            numberOfLines = 1;
                        }
                        else if (someLineLength == maxLineLength)
                        {
                            numberOfLines++;
                        }
                    }
                    else
                    {
                        someLineLength = 0;
                    }
                }
                someLineLength = 0;
            }
            if (maxLineLength == 1)
            {
                numberOfLines /= 2;
            }
            Console.WriteLine(maxLineLength);
            Console.WriteLine(numberOfLines);
        }
    }
}
