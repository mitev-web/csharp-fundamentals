using System; 
using System.Collections.Generic; 
using System.Linq; 
using System.Text; 
  
namespace Problem1Second 
{ 
    class Program 
    { 
        static void Main(string[] args) 
        {   double p1 = double.Parse(Console.ReadLine()); 
            double p2 = double.Parse(Console.ReadLine()); 
            double p3 = double.Parse(Console.ReadLine()); 
            double p4 = double.Parse(Console.ReadLine()); 
  
            double f1 = double.Parse(Console.ReadLine()); 
            double f2 = double.Parse(Console.ReadLine()); 
  
            double d = double.Parse(Console.ReadLine()); 
            d = Math.Abs(d); 
  
            int result = 0; 
  
            if (f1+d >= p1 && f1+d <= p3 && f2 >= p4 && f2 <= p2) 
            { 
                result += 100; 
            } 
  
            if (f1+d+1 >= p1 && f1+d+1 <= p3 && f2 >= p4 && f2 <= p2) 
            { 
                result += 75; 
            } 
  
            if (f1+d >= p1 && f1+d <= p3 && f2+1 >= p4 && f2+1 <= p2) 
            { 
                result += 50; 
            } 
  
            if (f1+d >= p1 && f1+d <= p3 && f2-1 >= p4 && f2-1 <= p2) 
            { 
                result += 50; 
            } 
  
            Console.WriteLine(result + "%"); 
        } 
    } 
} 

