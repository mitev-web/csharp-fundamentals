using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            ushort dmg = 0;
            if ((pX1 <= pX2) && (pY1 >= pY2))
            {
                if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) && ((fY >= pY2) && (fY <= pY1)))
                    dmg += 100;

                if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) && ((fY + 1 >= pY2) && (fY + 1 <= pY1)))
                    dmg += 50;

                if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) && ((fY - 1 >= pY2) && (fY - 1 <= pY1)))
                    dmg += 50;

                if ((((fX + d + 1) >= pX1) && ((fX + d + 1) <= pX2)) && ((fY >= pY2) && (fY <= pY1)))
                    dmg += 75;
            }
            else if ((pX1 >= pX2) && (pY1 >= pY2))
            {
                if ((((fX + d) <= pX1) && ((fX + d) >= pX2)) && ((fY >= pY2) && (fY <= pY1)))
                    dmg += 100;

                if ((((fX + d) <= pX1) && ((fX + d) >= pX2)) && ((fY + 1 >= pY2) && (fY + 1 <= pY1)))
                    dmg += 50;

                if ((((fX + d) <= pX1) && ((fX + d) >= pX2)) && ((fY - 1 >= pY2) && (fY - 1 <= pY1)))
                    dmg += 50;

                if ((((fX + d + 1) <= pX1) && ((fX + d + 1) >= pX2)) && ((fY >= pY2) && (fY <= pY1)))
                    dmg += 75;
            }
            else if ((pX1 <= pX2) && (pY1 <= pY2))
            {
                if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) && ((fY <= pY2) && (fY >= pY1)))
                    dmg += 100;

                if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) && ((fY + 1 <= pY2) && (fY + 1 >= pY1)))
                    dmg += 50;

                if ((((fX + d) >= pX1) && ((fX + d) <= pX2)) && ((fY - 1 <= pY2) && (fY - 1 >= pY1)))
                    dmg += 50;

                if ((((fX + d + 1) >= pX1) && ((fX + d + 1) <= pX2)) && ((fY <= pY2) && (fY >= pY1)))
                    dmg += 75;
            }
            else
            {
                if ((((fX + d) <= pX1) && ((fX + d) >= pX2)) && ((fY <= pY2) && (fY >= pY1)))
                    dmg += 100;

                if ((((fX + d) <= pX1) && ((fX + d) >= pX2)) && ((fY + 1 <= pY2) && (fY + 1 >= pY1)))
                    dmg += 50;

                if ((((fX + d) <= pX1) && ((fX + d) >= pX2)) && ((fY - 1 <= pY2) && (fY - 1 >= pY1)))
                    dmg += 50;

                if ((((fX + d + 1) <= pX1) && ((fX + d + 1) >= pX2)) && ((fY <= pY2) && (fY >= pY1)))
                    dmg += 75;
            }
            Console.WriteLine((dmg / 100.0).ToString("0%"));
        }
    }
}
