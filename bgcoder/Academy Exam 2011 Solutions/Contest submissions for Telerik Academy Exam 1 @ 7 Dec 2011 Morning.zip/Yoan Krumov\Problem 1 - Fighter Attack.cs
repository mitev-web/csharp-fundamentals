using System;

namespace FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {

            //Console.WriteLine("Px1:");
            string userInput = Console.ReadLine();
            int Px1 = int.Parse(userInput);
            //Console.WriteLine("Py1:");
            userInput = Console.ReadLine();
            int Py1 = int.Parse(userInput);
            //Console.WriteLine("Px2:");
            userInput = Console.ReadLine();
            int Px2 = int.Parse(userInput);
            //Console.WriteLine("Py2:");
            userInput = Console.ReadLine();
            int Py2 = int.Parse(userInput);
            //Console.WriteLine("Fx:");
            userInput = Console.ReadLine();
            int Fx = int.Parse(userInput);
            //Console.WriteLine("Fy:");
            userInput = Console.ReadLine();
            int Fy = int.Parse(userInput);
            //Console.WriteLine("D:");
            userInput = Console.ReadLine();
            int D = int.Parse(userInput);

            int hit = Fx + D;
            int centralMissile = Fx + D;
            int frontMissile = centralMissile + 1;
            int topMissile = Fy + 1;
            int bottomMissile = Fy - 1;
            int result = 0;
            //if (hit>=Px1&&hit>=Py1+1&&hit<=Px2&&hit<=Py2-1)
            //{
            //    Console.WriteLine("275%");
            //}
            //if (centralMissile>=Px1&&bottomMissile>=Py1&&topMissile<=Py2&&frontMissile<=Px2)
            //{
            //    Console.WriteLine("275%");
            //}
            if (centralMissile >= Px1 && centralMissile <= Px2&&Fy>=Py1&&Fy<=Py2)
            {
                result = 100;

                if (frontMissile >= Px1 && frontMissile <= Px2)
                {
                    result = result + 75;
                }
                if (topMissile >= Py1 && topMissile <= Py2)
                {
                    result = result + 50;
                }
                if (bottomMissile >= Py1 && bottomMissile <= Py2)
                {
                    result = result + 50;
                }

            }
            else if (centralMissile < Px1)
            {
                result = 0;
                if ((Fy>=Py1&&Fy<=Py2)||(Fy<Py1&&Fy>Py2))
                {
                    result = result + 75;
                }
                else
                {
                    result = 0;
                }
            }
            else if (centralMissile >= Px2)
            {
                result = 0;

                

            }
            else if (Fy < Py1 ||Fy>Py2)
            {
                result = 0;

                if (frontMissile >= Px1 && frontMissile <= Px2)
                {
                    result = result + 75;
                }
                if (topMissile == Py1 || topMissile == Py2)
                {
                    result = result + 50;
                }
                if (bottomMissile <= Py1 && bottomMissile >= Py2)
                {
                    result = result + 50;
                }

            }

            Console.WriteLine(result + "%");
        }
    }
}