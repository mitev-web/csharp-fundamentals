using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[,] sand = new string[n, n];
            int temp = 1;
            int row = 0;
            int col = 0;
            string dot = ".";
            string star = "*";

            for (row = 0; row < n; row++)
            {
                if (row == 0 || row == n - 1)
                {
                    for (col = 0; col < n; col++)
                    {
                        sand[row, col] = star; 
                    }
                }
            }

            for (row = 1; row < n / 2 + 1; row++)
            {
                for (col = 0; col < row; col++)
                {
                    sand[row, col] = dot;
                }
                for (col = row; col < n - row; col++)
                {
                    sand[row, col] = star;
                }
                for (col = n - row; col < n; col++)
                {
                    sand[row, col] = dot;
                }
            }

            for (row = n - 2; row >= n / 2 + 1; row--)
            {
                for (col = 0; col < temp; col++)
                {
                    sand[row, col] = dot;
                }
                for (col = temp; col < n - temp; col++)
                {
                    sand[row, col] = star;
                }
                for (col = n - temp; col < n; col++)
                {
                    sand[row, col] = dot;
                }
                temp++;
            }

                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        Console.Write(sand[i, j]);
                    }
                    Console.WriteLine();
                }
        }
    }
}