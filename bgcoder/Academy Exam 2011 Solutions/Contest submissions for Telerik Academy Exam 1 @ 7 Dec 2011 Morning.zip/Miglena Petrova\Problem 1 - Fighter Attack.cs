using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad1_izpit
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int x1 = 0;
            int y1 = 0;
            int x2 = 0;
            int y2 = 0;
            if (Px2 >= Px1)
            {
                x1 = Px1;
                x2 = Py2;
            }
            else
            {
                x1 = Px2;
                x2 = Px1;
            }
            if (Py2 >= Py1)
            {
                y1 = Py1;
                y2 = Py2;
            }
            else
            {
                y1 = Py2;
                y2 = Py1;
            }
            if ((Fy <= y2) && (Fy >= y1) && (x1 - Fx <= D) && (x2 - Fx >= D))
            {
                Console.WriteLine("275%");
            }
            if ((Fy <= y2) && (Fy >= y1) && (x1 - Fx > D))
            {
                Console.WriteLine("75%");
            }
            if (((Fy == y1) || (Fy == y2)) && (x1 - Fx < D) && (x2 - Fx > D))
            {
                Console.WriteLine("225%");
            }
            if ((Fy <y2) && (Fy > y1) && (x2 - Fx == D))
            {
                Console.WriteLine("200%");
            }
            if ((x2 - Fx < D) || (Fy < y1 - 1) || (Fy > y2 + 1) || (x1 - Fx > D + 1))
            {
                Console.WriteLine("0%");
            }
            if (((Fy == y2 + 1) || (Fy == y1 - 1)) && (x1 - Fx <= D) && (x2 - Fx >= D))
            {
                Console.WriteLine("50%");
            }
            if (((Fy == y1) || (Fy == y2)) && (x2 - Fx == D))
            {
                Console.WriteLine("150%");
            }
        }
    }
}
