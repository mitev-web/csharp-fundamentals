using System;

class SandGlass
{
    static void Main()
    {
        string line = Console.ReadLine();
        byte N = Convert.ToByte(line);
        int k = (N + 1) / 2;
        for (int i = 0; i < k; i++)
        {
            PrintChars(i, '.');
            PrintChars(N-2*i, '*');
            PrintChars(i, '.');
            Console.WriteLine();
        }
        for (int i = k-2; i>=0; i--)
        {
            PrintChars(i, '.');
            PrintChars(N-2*i, '*');
            PrintChars(i, '.');
            Console.WriteLine();
        }
    }
    static void PrintChars(int n, char c)
    {
        for (int i = 0; i < n; i++)
        {
            Console.Write(c);
        }
    }
}