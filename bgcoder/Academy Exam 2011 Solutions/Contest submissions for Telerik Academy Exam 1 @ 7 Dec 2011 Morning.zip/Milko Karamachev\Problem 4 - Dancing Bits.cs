using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int K = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());

            int[] arrayN = new int[N];

            int nullCounter=0;
            int oneCounter=0;
            int bigCounter=0;

            for (int i = 0; i < N; i++)
            {
                arrayN[i]=int.Parse(Console.ReadLine());
            }
                


                for (int i =N-1; i>=0; i--)
                {
                    int temp = arrayN[i];

                    while (temp >= 1)
                    {
                        if (temp % 2 == 0)
                        {
                            oneCounter = 0;
                            nullCounter = nullCounter + 1;
                            
                            if (nullCounter == K)
                            {
                                bigCounter = bigCounter + 1;
                               
                            }

                            if (nullCounter == K + 1)
                            {
                                bigCounter = bigCounter - 1;
                                nullCounter = 0;
                            }
                           // Console.Write("0");

                        }
                        if (temp % 2 != 0)
                        {
                            nullCounter= 0;
                            oneCounter = oneCounter+1;
                            if (oneCounter == K)
                            {
                                bigCounter = bigCounter + 1;
                                
                            }

                            if (oneCounter == K + 1)
                            {
                                bigCounter = bigCounter - 1;
                                oneCounter = 0;
                            }
                           // Console.Write("1");
                        }
                        temp = temp / 2;
                       
                    }

                }
             Console.WriteLine(bigCounter);
        }

           
        }
    
}
