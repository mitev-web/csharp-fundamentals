using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int astroNumber = 0;
            int digitCount = 0;

            do
            {
                astroNumber = 0;
                digitCount = 0;

                for (int i = 0; i < input.Length; i++)
                {
                    if ((input[i] >= '0') && (input[i] >= '0'))
                    {
                        astroNumber += (int)(input[i] - '0');
                        digitCount++;
                    }
                }

                input = astroNumber.ToString();

            } while (digitCount > 1);

            Console.WriteLine(astroNumber);
        }
    }
}