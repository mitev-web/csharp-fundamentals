using System;
using System.Numerics;

class AstrologicalDigits
{
    static void Main()
    {
        double number = double.Parse(Console.ReadLine());
        int sum = 0;
        if (number == 0)
        {
            sum = 0;
            Console.WriteLine(sum);
            return;
        }
        if (number < 0)
        {
            number *= (-1);
        }
        BigInteger nBig = (BigInteger)number; //34
        decimal n = (decimal)nBig;
        decimal nPart = (decimal)number % n; // 34,5 - 34 = 0.5
        decimal mod = 0;
        int modInt = (int)mod;
        while (sum > 9 || sum == 0)
        {
            sum = 0;
            while (n != 0)
            {
                mod = (decimal)n % 10;
                modInt = (int)mod;
                sum += modInt;
                n = n / 10;
            }
            while (nPart != 0)
            {
                mod = nPart * 10;
                modInt = (int)mod;
                sum += modInt;
                nPart = mod - modInt;
            }
            nPart = 0;
            n = (decimal)sum;
        }
        Console.WriteLine(sum);
    }
}