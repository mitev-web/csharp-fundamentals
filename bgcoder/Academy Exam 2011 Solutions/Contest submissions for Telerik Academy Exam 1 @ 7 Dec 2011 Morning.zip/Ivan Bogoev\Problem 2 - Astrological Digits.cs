using System;

namespace Task2.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = Console.ReadLine();

            int digitContainer = 0;
            

            for (; ; )
            {
                for (int i = 0; i < number.Length; i++)
                {
                    switch (number[i])
                    {
                        case '0':
                            break;
                        case '1': digitContainer += 1;
                            break;
                        case '2': digitContainer += 2;
                            break;
                        case '3': digitContainer += 3;
                            break;
                        case '4': digitContainer += 4;
                            break;
                        case '5': digitContainer += 5;
                            break;
                        case '6': digitContainer += 6;
                            break;
                        case '7': digitContainer += 7;
                            break;
                        case '8': digitContainer += 8;
                            break;
                        case '9': digitContainer += 9;
                            break;
                        default:
                            break;
                    }


                }
                if (digitContainer > 9)
                {
                    number = null;
                    number = Convert.ToString(digitContainer);
                    digitContainer = 0;
                }
                else
                {
                    break;
                }
            }

            Console.WriteLine(digitContainer);

        }
    }
}
