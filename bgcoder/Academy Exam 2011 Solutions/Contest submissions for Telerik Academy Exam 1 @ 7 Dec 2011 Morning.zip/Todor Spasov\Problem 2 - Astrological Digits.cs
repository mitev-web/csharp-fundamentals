using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{

    class Program
    {
        static void Main()
        {


        

            double destinyNumber = Convert.ToDouble(Console.ReadLine());
            if (destinyNumber < 0) destinyNumber = destinyNumber*(-1);

           
            int sum = 0;
            int sum2 = 0;
            if (destinyNumber / 10 < 1) Console.WriteLine(destinyNumber);
            else
            {
                while (destinyNumber > 0)
                {




                    sum += Convert.ToInt32(destinyNumber % 10);

                    destinyNumber = Convert.ToInt32(destinyNumber / 10);


                }
                if (sum / 10 < 1) Console.WriteLine(sum);

                else
                {
                    while (sum > 0)
                    {

                                                
                        sum2 += sum % 10;
                        sum = sum / 10;


                    }
                    Console.WriteLine(sum2);

                }

            }



        }
    }
}
