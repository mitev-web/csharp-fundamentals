using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {



            double N = double.Parse(Console.ReadLine());

            while (N > 9)
            {
                for (int i = 0; i < N; i++)
                {
                    N = N + N;
                }
            }
            Console.WriteLine(N);


        }
    }
}
