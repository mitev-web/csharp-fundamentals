using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test4
{
    class Program
    {
        static void Main(string[] args)
        {
            int K = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            int [] arr = new int [N];
            for (int i = 0; i < N; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            string binaryString = "";
            for (int i = 0; i < arr.Length; i++)
            {
                string temp = Convert.ToString(arr[i],2);
                binaryString = binaryString + temp;
            }


            int dancinBits = 0;
            for (int i = 0; i < (binaryString.Length-K); i ++)
            {
                char fBit =  binaryString[i];
                bool isValid = false;
                if (K > 1)
                {
                    int count = 0;
                    for (int j = 1; j < K; j++)
                    { 
                       
                        char test = binaryString[i + j];
                        if (fBit == test)
                        {
                            count++;
                        }
                        if (count  == (K-1))
	                        {
                                isValid = true;
	                        }
                    }
                }
                else
                {
                    isValid = true;    
                }
                //char firstBit = binaryString[i];
                //char secondBit = binaryString[i+1];
                //char thirdBit = binaryString[i+2];
                if (isValid)
                {

                    char fourthBit = ' ';
                    if (i < binaryString.Length - K)
                    {
                        fourthBit = binaryString[i + K];
                    }

                    char fiftBit = ' ';
                    if (i > 0)
                    {
                        fiftBit = binaryString[i - 1];
                    }


                    if (fBit != fourthBit && fBit != fiftBit)
                    {

                        dancinBits++;
                        //i += N;

                    }
                }
               
            }
            Console.WriteLine(dancinBits);
        }
    }
}
