using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lines
{
    class Program
    {
        static void Main(string[] args)
        {

            byte[] bytes = new byte[8];
            int[,] map = new int[8, 8];
            for (int i = 0; i < 8; i++)
            {
                bytes[i] = byte.Parse(Console.ReadLine());
                int j = 0;
                while (bytes[i] > 0)
                {
                    if (bytes[i] - Math.Pow(2, 7 - j) >= 0)
                    {
                        bytes[i] -= (byte)Math.Pow(2, 7 - j);
                        map[i, j] = 1;
                    }
                    j++;
                }
                j = 0;
            }
            //int MaxLineLength = 0;
            //int MaxLengthCount = 1;
            int maxVerticalLength = 0;
            int maxVerticalLengthCount = 1;
            int maxHorizontalLength = 0;
            int maxHorizontalLengthCount = 1;
            //bool vertical = false;
            //bool horizontal = false;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    //find vertical limes from this point
                    if (map[i, j] == 1)
                    {
                        int currentLineLength = 0;
                        int k = i, l = j;
                        do
                        {
                            if (map[k, l] == 0) break;
                            currentLineLength++;
                            k--;
                        }
                        while (k >= 0);
                        k = i + 1;
                        while (k < 8)
                        {
                            if (map[k, l] == 0) break;
                            currentLineLength++;
                            k++;
                        }
                        k--;
                        if (currentLineLength == maxVerticalLength)
                        {
                            maxVerticalLengthCount++;
                        }
                        if (currentLineLength > maxVerticalLength)
                        {
                            maxVerticalLength = currentLineLength;
                            maxVerticalLengthCount = 1;
                        }
                        //Check the horizontals
                       currentLineLength = 0;
                        k = i;  l = j;
                        do
                        {
                            if (map[k, l] == 0) break;
                            currentLineLength++;
                            l--;
                        }
                        while (l >= 0);
                        l = j + 1;
                        while (l < 8)
                        {
                            if (map[k, l] == 0) break;
                            currentLineLength++;
                            l++;
                        }
                        l--;
                        if (currentLineLength == maxHorizontalLength)
                        {
                            maxHorizontalLengthCount++;
                        }
                        if (currentLineLength > maxHorizontalLength)
                        {
                            maxHorizontalLength = currentLineLength;
                            maxHorizontalLengthCount = 1;
                        }




                    }
                    map[i, j] = 0;

                }
 

            }
            if (maxVerticalLength > maxHorizontalLength)
            {
                Console.WriteLine(maxVerticalLength);
                Console.WriteLine(maxVerticalLengthCount);
            }
            else if (maxVerticalLength < maxHorizontalLength)
            {
                Console.WriteLine(maxHorizontalLength);
                Console.WriteLine(maxHorizontalLengthCount);
            }
            else
            {
                if (maxHorizontalLength == 1)
                {
                    Console.WriteLine("1");
                    Console.WriteLine(maxHorizontalLengthCount);
                }
                else
                {
                    Console.WriteLine(maxHorizontalLength);
                    Console.WriteLine(maxHorizontalLengthCount + maxVerticalLengthCount);

                }
            }
            //Console.WriteLine("Maximal Horizontal length {0}",maxHorizontalLength);
            //Console.WriteLine("Maximal Horizontal length count {0}", maxHorizontalLengthCount);
            //Console.WriteLine("Maximal vertical length {0}", maxVerticalLength);
            //Console.WriteLine("Maximal vertical length count {0}", maxVerticalLengthCount);

            //Console.WriteLine(MaxLineLength);
            //Console.WriteLine(MaxLengthCount);
            
            
        }
    }
}
