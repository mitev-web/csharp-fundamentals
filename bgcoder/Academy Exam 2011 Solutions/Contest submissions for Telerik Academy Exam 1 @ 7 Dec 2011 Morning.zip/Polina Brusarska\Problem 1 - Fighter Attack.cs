using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
        static void Main(string[] args)
        {
            double Px1, Px2, Py1, Py2, Fx, Fy, D;
            string input;
            input=Console.ReadLine();
            Px1 = double.Parse(input);
            input=Console.ReadLine();
            Px2 = double.Parse(input);
            input=Console.ReadLine();
            Py1 = double.Parse(input);
            input=Console.ReadLine();
            Py2 = double.Parse(input);
            input=Console.ReadLine();
            Fx = double.Parse(input);
            input=Console.ReadLine();
            Fy = double.Parse(input);
            input=Console.ReadLine();
            D = double.Parse(input);
            
            
            
            
            bool inDotTarget=false;
            bool intargetObjectDown = false;
            bool intargetObjectTop = false;
            bool intargetObjectBehind = false;
            double targetObjectX = (Fx + D);
            double targetObjectY = Fy;
            double targetObject = 0;
            double targetObjectTopX = (Fx + D);
            double targetObjectTopY = (Fy + 1);
            double targetObjectTop = 0;
            double targetObjectDownX = (Fx + D);
            double targetObjectDownY = (Fy - 1);
            double targetObjectDown = 0;
            double targetObjectBehindX = (Fx + D + 1);
            double targetObjectBehindY = Fy;
            double targetObjectBehind = 0;

            

     
            
            if ((targetObjectX>= Px1) && (targetObjectX <=Px2) && (targetObjectY<= Py1)&& (targetObjectY >= Py2))
            {
                inDotTarget = true;
            }
            else
            {
                inDotTarget = false;

            }
            if ((targetObjectTopX >= Px1) && (targetObjectTopX <= Px2) && (targetObjectTopY <= Py1) && (targetObjectTopY >= Py2))
            {
                    intargetObjectTop = true;
                
            }
            else
            {
                intargetObjectTop = false;

            }

            if ((targetObjectDownX >= Px1) && (targetObjectDownX <= Px2) && (targetObjectDownY <= Py1) && (targetObjectDownY >= Py2))
            {
                intargetObjectDown = true;

            }
            else
            {
                intargetObjectDown = false;

            }
            if ((targetObjectBehindX >= Px1) && (targetObjectBehindX <= Px2) && (targetObjectBehindY <= Py1) && (targetObjectBehindY >= Py2))
            {
                intargetObjectBehind = true;

            }
            else
            {
                intargetObjectBehind = false;

            }

            if (intargetObjectTop)
            {
                targetObjectTop = 50;
            }
            if (intargetObjectDown)
            {
                targetObjectDown = 50;
            }
            if (intargetObjectBehind)
            {
                targetObjectBehind = 75;
            }
            if (inDotTarget)
            {
                targetObject = 100;
            }
            if (inDotTarget || intargetObjectTop || intargetObjectDown || intargetObjectBehind)
            {
                Console.Write(targetObject + targetObjectTop + targetObjectDown + targetObjectBehind);
                Console.WriteLine("%");
            }
            else
            {
                Console.WriteLine("0%");
            }








        }
 }

