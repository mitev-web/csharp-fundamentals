using System;

class DancingBits
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int maskAndnumber;
        int maxLenght = 0;
        int[] numbers = new int[8];
        for (int i = 0; i < 8; i++)
        {
            numbers[i] = int.Parse(Console.ReadLine());
        }
        int[] counterRow = new int[8];
        int[] counterCol = new int[8];

        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                maskAndnumber = numbers[j] & (1 << i);
                maskAndnumber = maskAndnumber >> i;
                counterCol[i] += maskAndnumber;
            }
        }
        for (int i = 0; i < 8; i++)
        {
            counterRow[i] = 0;
            while (numbers[i] != 0)
            {
                maskAndnumber = numbers[i] & 1;
                numbers[i] = numbers[i] >> 1;
                counterRow[i] += maskAndnumber;
            }
        }
        int nCount = 0;
        Array.Sort(counterCol);

        maxLenght = counterCol[7];
        if (counterCol[7] < counterRow[7])
        {
            maxLenght = counterRow[7];
        }
        for (int i = 0; i < 8; i++)
        {
            if (counterRow[i] == maxLenght)
            {
                nCount++;
            }
            if (counterCol[i] == maxLenght)
            {
                nCount++;
            }
            
        }
        Console.WriteLine(maxLenght);
        Console.WriteLine(nCount);
    }
}
