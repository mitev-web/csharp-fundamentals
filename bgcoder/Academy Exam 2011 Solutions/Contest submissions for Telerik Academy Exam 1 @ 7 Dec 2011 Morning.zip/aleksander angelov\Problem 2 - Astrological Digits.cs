using System;
using System.Collections.Generic;
using System.Linq;


namespace AstrologicalNumbers_task2_
{
    class Program
    {
        static void Main(string[] args)
        {

            string input = Console.ReadLine();
            input.Replace(".", "");
            input.Replace("-", "");
            int sum = 0;
            while (true)
            {
                if (sum != 0)
                {
                    input = sum.ToString();
                    sum = 0;
                }

                int lenghtInputChars = input.Length;
                for (int i = 0; i < lenghtInputChars; i++)
                {
                    sum += int.Parse(input[i].ToString());
                    Console.WriteLine(sum);
                }
                if (sum <= 9)
                {
                    break;
                }

            }
        }
    }
}
