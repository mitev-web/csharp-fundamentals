using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex3_SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {

            
            string consoleInput = Console.ReadLine();
            int n = int.Parse(consoleInput);
            
         
            for (int row = 0; row < n; row++)
            {
                
                for (int col = 0; col < n; col++)
                {
                    if (row <= ((n / 2) + 1) && ((col >= row) && (col < n - row)))
                    {
                        Console.Write('*');

                    }
                    else
                    {
                        if ((col <= row) && (col >= n - row - 1))
                        {
                            Console.Write('*');
                        }
                        else Console.Write('.');
                    }          
                }
                Console.WriteLine();
            }
            
     
        }
    }
}
