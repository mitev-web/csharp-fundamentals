using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task2_again
{
    class Program
    {
        static void Main(string[] args)
        {
            double numbers = double.Parse(Console.ReadLine());
            numbers = Math.Abs(numbers);
            double lastDigit;
            double sumDigits;
            double n;
            sumDigits = 0;
            n = numbers;

            while (n > 0)
            {
                lastDigit = (numbers % 10);
                sumDigits = sumDigits + lastDigit;
                n =(int) (numbers / 10);

            }
            n = sumDigits;
            if (n > 9)
            {
                numbers = sumDigits;

                while (n > 0)
                {
                    lastDigit = (numbers % 10);
                    sumDigits = sumDigits + lastDigit;
                    n = (int)(numbers / 10);

                }
                Console.WriteLine(sumDigits);
            }
            else
            {
                if (n <= 9)
                {
                    Console.WriteLine(n);
                }
            }
           
        }
    }
}

