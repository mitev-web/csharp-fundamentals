using System;
using System.Collections.Generic;
using System.Linq;
 
 
namespace Task02
{
    class Program
    {
        static void Main(string[] args)
        {
            double N = double.Parse(Console.ReadLine());
 
            while (N != Math.Round(N))
            {
                N *= 10;
            }
            if (N < 0)
            {
                N *= -1;
            }
 
            if (N >= 0 && N < 10)
            {
                Console.Write(N);
                return;
            }
            string number = N.ToString();
 
            List<int> numbers = new List<int>();
            int tempNumb = 0;
            foreach (char c in number)
            {
                int.TryParse(c.ToString(), out tempNumb);
                numbers.Add(tempNumb);
            }
 
            ReturnNineOrLess(numbers.Sum());
        }
 
        public static void ReturnNineOrLess(int n)
        {
            double N = n;
            if (n >= 0 && n < 9)
            {
                Console.WriteLine(n);
            }
            else
            {
                string number = n.ToString();
                List<int> numbers = new List<int>();
                int tempNumb = 0;
                foreach (char c in number)
                {
                    int.TryParse(c.ToString(), out tempNumb);
                    numbers.Add(tempNumb);
                }
 
                ReturnNineOrLess(numbers.Sum());
            }
        }
    }
}