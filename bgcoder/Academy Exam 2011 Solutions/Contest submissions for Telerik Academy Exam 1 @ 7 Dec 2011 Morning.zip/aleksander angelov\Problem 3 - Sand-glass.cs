using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sand_glass_task3_
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            int firstPart = n/2;
            
            for (int i = 0; i < firstPart; i++)
            {
                for (int a = 0; a < n; a++)
                {
                    if (i >= a || ((n - i) <= (a+1)))
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }
            for (int i = (firstPart+2); i < n; i++)
            {
                for (int a = 0; a < n; a++)
                {
                    if (i <= a || ((n - i) >= (a + 1)))
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }
                for (int i = 0; i < n; i++)
                {
                    Console.Write("*");
                }
            
        }
    }
}