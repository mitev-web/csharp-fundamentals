using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int low1 = 0;
            int high1 = n;
            int low2 = (n - 1) / 2 - 1;
            int high2 = (n + 1) / 2 + 1;

            for (int i = 0; i < n; i++)
            {
                if (i < (n - 1) / 2 + 1)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (j >= low1 && j < high1)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    low1++;
                    high1--;
                    Console.WriteLine();
                }
                else
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (j >= low2 && j < high2)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    low2--;
                    high2++;
                    Console.WriteLine();
                }
            }

            Console.WriteLine();
        }
    }
}