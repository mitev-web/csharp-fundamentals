using System;
using System.Linq;
using System.Text;

namespace Problem4_DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            StringBuilder sBk0 = new StringBuilder();
            StringBuilder sBk1 = new StringBuilder();
            for (int count = 0; count < k; count++)
			{
                sBk0.Append("0");
                sBk1.Append("1");
			}
            //sBk0.Append("1");
            //sBk1.Append("0");
            string k0 = sBk0.ToString();
            string k1 = sBk1.ToString();
            int n = int.Parse(Console.ReadLine());
            StringBuilder sB = new StringBuilder();
            for (int count = 0; count < n; count++)
            {
                sB.Append(Convert.ToString(uint.Parse(Console.ReadLine()),2));
            }
            string numberWitBit = sB.ToString();
            int lastResult = -1;
            int indexResult = -1;
            int counterResult = 0;
            bool stop = false;
            string nextDigit="1";
            //find 0
            while (true)
            {
                indexResult = -1;
                indexResult = numberWitBit.IndexOf(k0, lastResult + 1);
                if (indexResult != -1)
                {
                    if (indexResult+1<numberWitBit.Length)
                    {
                        nextDigit = numberWitBit.Substring(indexResult + 1, 1);
                        if (nextDigit.Equals("1"))
                        {
                            lastResult = indexResult;
                            counterResult++;  
                        }
                    }
                    else
                    {
                        lastResult = indexResult;
                        counterResult++;  
                    }

                }
                else
                {
                    break;
                }
            }
            //find 1
            lastResult = -1;
            while (true)
            {
                indexResult = -1;
                indexResult = numberWitBit.IndexOf(k1, lastResult + 1);
                if (indexResult != -1)
                {
                    if (indexResult + 1 <numberWitBit.Length)
                    {
                        nextDigit = numberWitBit.Substring(indexResult + 1, 1);
                        if (nextDigit.Equals("0"))
                        {
                            lastResult = indexResult;
                            counterResult++;
                        }
                    }
                    else
                    {
                        lastResult = indexResult;
                        counterResult++;
                    }

                }
                else
                {
                    break;
                }
            }
            Console.WriteLine(counterResult);
        }
    }
}
