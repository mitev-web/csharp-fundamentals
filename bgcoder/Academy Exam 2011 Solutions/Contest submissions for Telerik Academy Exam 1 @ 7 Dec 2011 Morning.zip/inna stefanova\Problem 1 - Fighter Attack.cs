using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using System.Globalization;

namespace Promlem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture =CultureInfo.GetCultureInfo("en-US");
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int total_damagex;
            int total_damagey=Fy;
            if (Fx < 0)
            {
                total_damagex = Fx + D + 1;
            }
            else
            {

                total_damagex = Fx + D;
            }
            



            


            if ((total_damagex >= Px1 && total_damagex <= Px2) && (total_damagey >= Py1 ||total_damagey <= Py2))
            {
            
            
                    if((Px2==(Px1+1) && Py2==(Py1+1) ))
                    {
                        
                        
                   
                
                        {
                             if ((total_damagex>=Px1&&total_damagex<=Px2)&&((total_damagey>Py1&&total_damagey<=Py1-1)||((total_damagey>Py2&&total_damagey<=Py2+1))))

                                {
                                  Console.WriteLine("50 %");
                                }
                             if((total_damagex>=Px2&&total_damagex<=Px2+1)&&(total_damagey>=Py1&&total_damagey<=Py2))
                                {
                                    Console.WriteLine("75 %");
                                }
                             else
                             {
                                 Console.WriteLine("100 %");
                             }
                        }
                   
                    }
                
                 
                      else
                    {
                            Console.WriteLine("225%");
                    }
                }
          
             else
               {
                  Console.WriteLine("0%");
                }





                
                



        }
    }
}

  