using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            string numberString = Console.ReadLine();
            int sum = 10;
            while (sum > 9)
            {
                sum = 0;
                foreach (var character in numberString)
                {
                    switch (character)
                    {
                        case '1':
                            sum += 1;
                            break;
                        case '2':
                            sum += 2;
                            break;
                        case '3':
                            sum += 3;
                            break;
                        case '4':
                            sum += 4;
                            break;
                        case '5':
                            sum += 5;
                            break;
                        case '6':
                            sum += 6;
                            break;
                        case '7':
                            sum += 7;
                            break;
                        case '8':
                            sum += 8;
                            break;
                        case '9':
                            sum += 9;
                            break;
                        default:
                            break;
                    }
                }
                numberString = sum.ToString();
            }
            Console.WriteLine(sum);
        }
    }
}
