using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sandss
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int t = 2;
            int p = 1;
            int change = 1;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == 0)
                    {
                        Console.Write("*");
                    }


                    if (i > 0)
                    {
                        if (j == p && p!=n-1)
                        {
                            Console.Write("*");
                            p++;
                            
                        }
                        

                        else  if (i == n - 1)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                        
                    }


                    
                }

                Console.WriteLine();
                



            }
        }

    }
}

