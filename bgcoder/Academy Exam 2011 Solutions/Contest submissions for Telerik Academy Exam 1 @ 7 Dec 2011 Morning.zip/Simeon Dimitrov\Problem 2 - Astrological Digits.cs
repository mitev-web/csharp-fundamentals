using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {
          int  sum = 0;
          int num = 0;
            char x='0';
            string n = Console.ReadLine();
            for (int i = 0; i < n.Length; i++)
            {
                x = n[i];
                //Console.WriteLine(x);
                if (x != '.' && x != '-')
                {
                    num = num + int.Parse(x.ToString());
                }
            }
           // Console.WriteLine(num);
            num = Math.Abs(num);
            while(true)
			{
                while (num != 0)
                {

                    sum += num % 10;
                    num /= 10;

                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                }
                else
                {
                    Console.WriteLine(sum);
                    break;
                }

            }
            

        }
    }
}
