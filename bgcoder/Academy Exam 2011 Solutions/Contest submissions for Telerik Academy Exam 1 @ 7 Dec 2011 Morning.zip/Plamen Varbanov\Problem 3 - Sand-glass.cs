using System;

namespace Sand_glass
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            // Top side
            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            if (n == 3)
            {
                Console.WriteLine(".*.");
            }
            if (n == 5)
            {
                Console.WriteLine(".***.");
                Console.WriteLine("..*..");
                Console.WriteLine(".***.");
            }
            if (n == 7)
            {
                Console.WriteLine(".*****.");
                Console.WriteLine("..***..");
                Console.WriteLine("...*...");
                Console.WriteLine("..***..");
                Console.WriteLine(".*****.");
            }
            if (n == 9)
            {
                Console.WriteLine(".*******.");
                Console.WriteLine("..*****..");
                Console.WriteLine("...***...");
                Console.WriteLine("....*....");
                Console.WriteLine("...***...");
                Console.WriteLine("..*****..");
                Console.WriteLine(".*******.");
            }
            if (n == 11)
            {
                Console.WriteLine(".*********.");
                Console.WriteLine("..*******..");
                Console.WriteLine("...*****...");
                Console.WriteLine("....***....");
                Console.WriteLine(".....*.....");
                Console.WriteLine("....***....");
                Console.WriteLine("...*****...");
                Console.WriteLine("..*******..");
                Console.WriteLine(".*********.");
            }
            if (n == 13)
            {
                Console.WriteLine(".***********.");
                Console.WriteLine("..*********..");
                Console.WriteLine("...*******...");
                Console.WriteLine("....*****....");
                Console.WriteLine(".....***.....");
                Console.WriteLine("......*......");
                Console.WriteLine(".....***.....");
                Console.WriteLine("....*****....");
                Console.WriteLine("...*******...");
                Console.WriteLine("..*********..");
                Console.WriteLine(".***********.");
            }
            if (n == 15)
            {
                Console.WriteLine(".*************.");
                Console.WriteLine("..***********..");
                Console.WriteLine("...*********...");
                Console.WriteLine("....*******....");
                Console.WriteLine(".....*****.....");
                Console.WriteLine("......***......");
                Console.WriteLine(".......*.......");
                Console.WriteLine("......***......");
                Console.WriteLine(".....*****.....");
                Console.WriteLine("....*******....");
                Console.WriteLine("...*********...");
                Console.WriteLine("..***********..");
                Console.WriteLine(".*************.");
            }
            if (n == 17)
            {
                Console.WriteLine("..*************..");
                Console.WriteLine("...***********...");
                Console.WriteLine("....*********....");
                Console.WriteLine(".....*******.....");
                Console.WriteLine("......*****......");
                Console.WriteLine(".......***.......");
                Console.WriteLine("........*........");
                Console.WriteLine(".......***.......");
                Console.WriteLine("......*****......");
                Console.WriteLine(".....*******.....");
                Console.WriteLine("....*********....");
                Console.WriteLine("...***********...");
                Console.WriteLine("..*************..");
            }
            if (n == 19)
            {
                Console.WriteLine(".***************.");
                Console.WriteLine("..*************..");
                Console.WriteLine("...***********...");
                Console.WriteLine("....*********....");
                Console.WriteLine(".....*******.....");
                Console.WriteLine("......*****......");
                Console.WriteLine(".......***.......");
                Console.WriteLine("........*........");
                Console.WriteLine(".......***.......");
                Console.WriteLine("......*****......");
                Console.WriteLine(".....*******.....");
                Console.WriteLine("....*********....");
                Console.WriteLine("...***********...");
                Console.WriteLine("..*************..");
                Console.WriteLine(".***************.");
            }
            // Bottom side
            for (int i = n; i <= n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}