using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i <= n/2-1; i++)
            {
                Console.WriteLine(new string('.',i) + new string('*',n-2*i) + new string('.',i));
            }
            for (int i = n/2; i>=0; i--)
            {
                if (i == n / 2)
                {
                    Console.WriteLine(new string('.', i) + '*' + new string('.', i));
                }
                else 
                    Console.WriteLine(new string('.', i) + new string('*',n-2*i ) + new string('.', i));
            }
        }
    }
}
