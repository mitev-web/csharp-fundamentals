using System;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
             byte num = byte.Parse(Console.ReadLine());
            int half = num / 2 + 1;
            int wayBack = num;
            for (int i = 0; i < half; i++)
            {                
                for (int j = 0; j < num; j++)
                {
                    if (j < i || j >= wayBack)//  || i <= j - 1)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                    
                }
                wayBack--;                
                Console.WriteLine(); //wayback=2
            }
            wayBack--;
            for (int i = half; i < num ; i++) //wayback=1
            {
                for (int j = 0; j < num; j++)
                {
                    if (j < wayBack || j > i)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                wayBack--;                
                Console.WriteLine();
            }
        }
    }
}
