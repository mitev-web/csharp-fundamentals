using System;

class AstrologicalDigits    //problem 2
{
    static void Main()
    {
        int sum = 0;
        string line = Console.ReadLine();
        string number;
        if (line[0] == '-' || line[0] == '+')
            number = line.Substring(1,line.Length-1);
        else
            number = line;
        for (int i = 0; i < number.Length; i++)
        {
            char ch = number[i];
            if (ch == '.') continue;
            int t = Convert.ToInt32(ch)-48;
            sum += t;
        }
        while (sum > 9)
        {
            int t = 0;
            while (sum != 0)
            {
                t += sum % 10;
                sum /= 10;
            }
            sum = t;
        }
        Console.WriteLine(sum);
    }
}