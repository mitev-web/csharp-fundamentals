using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n0 = byte.Parse(Console.ReadLine());
            byte n1 = byte.Parse(Console.ReadLine());
            byte n2 = byte.Parse(Console.ReadLine());
            byte n3 = byte.Parse(Console.ReadLine());
            byte n4 = byte.Parse(Console.ReadLine());
            byte n5 = byte.Parse(Console.ReadLine());
            byte n6 = byte.Parse(Console.ReadLine());
            byte n7 = byte.Parse(Console.ReadLine());
            byte largest = 0;
            byte repeats = 0;

            byte[] arr = { n0, n1, n2, n3, n4, n5, n6, n7 };
            byte[,] mainArr = new byte[8, 8];
            byte position = 1;
            for (int i = 0; i < 8; i++)
            {
                for (int y = 0; y < 8; y++)
                {
                    if ((arr[i] & position) == position)
                        mainArr[i, y] = 1;
                    position *= 2;
                }
                position = 1;
            }
            for (int i = 0; i < 8; i++)
            {
                for (int y = 0; y < 8; y++)
                {
                    if (mainArr[i, y] == 1)
                    {
                        byte a = 1;
                        byte b = 1;
                        while ((y + a < 8) && mainArr[i, y + a] == 1)
                        {
                            b++;
                            a++;
                        }
                        if (b > largest)
                        {
                            largest = b;
                            repeats = 1;
                        }
                        else if (b == largest)
                            repeats++;
                    }
                }
            }
            for (int y = 0; y < 8; y++)
            {
                for (int i = 0; i < 8; i++)
                {
                    if (mainArr[i, y] == 1)
                    {
                        byte a = 1;
                        byte b = 1;
                        while ((i + a < 8) && mainArr[i + a, y] == 1)
                        {
                            b++;
                            a++;
                        }
                        if (b > largest)
                        {
                            largest = b;
                            repeats = 1;
                        }
                        else if (b == largest)
                            repeats++;
                    }
                }
            }
            if (largest == 1)
            {
                Console.WriteLine(largest);
                Console.WriteLine(repeats / 2);
            }
            else
            {
                Console.WriteLine(largest);
                Console.WriteLine(repeats);
            }
        }
    }
}