using System;
using System.Linq;

namespace Problem5_Lines
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            int row = 8;
            int[] numbers = new int[row];
            //enter numbers
            for (int counter = 0; counter < row; counter++)
            {
                numbers[counter] = byte.Parse(Console.ReadLine());
            }
            int howManyTimesInRowGlobal;
            int maxBitGlobalRow;
            int howManyTimesInColGlobal;
            int maxBitGlobalCol;
            GetMaxInRow(row, numbers, out howManyTimesInRowGlobal, out maxBitGlobalRow);
            GetMaxInColum(numbers, out howManyTimesInColGlobal, out maxBitGlobalCol);

            if (maxBitGlobalRow>maxBitGlobalCol)
            {
                Console.WriteLine(maxBitGlobalRow);
                Console.WriteLine(howManyTimesInRowGlobal);
            }
            if(maxBitGlobalRow<maxBitGlobalCol)
            {
                Console.WriteLine(maxBitGlobalCol);
                Console.WriteLine(howManyTimesInColGlobal);
            }
            if (maxBitGlobalRow==maxBitGlobalCol)
            {
                Console.WriteLine(maxBitGlobalCol);
                Console.WriteLine(howManyTimesInColGlobal+howManyTimesInRowGlobal);
            }
        }

        private static void GetMaxInColum(int[] numbers, out int howManyTimesInColGlobal, out int maxBitGlobalCol)
        {
            maxBitGlobalCol = 0;
            howManyTimesInColGlobal = 0;
            for (int counterCol = 0; counterCol < 8; counterCol++)
            {
                int countBitInCol = 0;
                int maxBitInCol = 0;
                int howManyTimesInCol = 0;
                bool newValue = false;
                for (int counterBit = 0; counterBit < 8; counterBit++)
                {
                    int bit = GetBitAtPosition(counterCol, numbers, counterBit);
                    if (bit == 1)
                    {
                        countBitInCol++;
                    }
                    else
                    {
                        if (maxBitInCol < countBitInCol)
                        {
                            maxBitInCol = countBitInCol;
                            newValue = true;
                        }
                        if (maxBitInCol == countBitInCol && countBitInCol != 0)
                        {
                            if (newValue)
                            {
                                howManyTimesInCol = 1;
                                newValue = false;
                            }
                            else
                            {
                                howManyTimesInCol++;
                            }
                        }
                        countBitInCol = 0;
                    }
                       
                   
                }
                if (maxBitInCol < countBitInCol)
                {
                    maxBitInCol = countBitInCol;
                    newValue = true;
                }
                if (maxBitInCol == countBitInCol && countBitInCol != 0)
                {
                    if (newValue)
                    {
                        howManyTimesInCol = 1;
                        newValue = false;
                    }
                    else
                    {
                        howManyTimesInCol++;
                    }
                }

                //new row
                if (maxBitGlobalCol < maxBitInCol)
                {
                    maxBitGlobalCol = maxBitInCol;
                    howManyTimesInColGlobal = howManyTimesInCol;
                }
                else if (maxBitGlobalCol == maxBitInCol)
                {
                    howManyTimesInColGlobal += howManyTimesInCol;
                }
            }
        }

        private static void GetMaxInRow(int row, int[] numbers, out int howManyTimesInRowGlobal, out int maxBitGlobalRow)
        {
            maxBitGlobalRow = 0;
            howManyTimesInRowGlobal = 0;
            for (int counterRow = 0; counterRow < row; counterRow++)
            {
                int countBitInRow = 0;
                int maxBitInRow = 0;
                int howManyTimesInRow = 0;
                bool newValue = false;
                for (int counterBit = 0; counterBit < 8; counterBit++)
                {
                    int bit = GetBitAtPosition(counterBit, numbers, counterRow);
                    if (bit == 1)
                    {
                        countBitInRow++;
                    }
                    else
                    {
                        if (maxBitInRow < countBitInRow)
                        {
                            maxBitInRow = countBitInRow;
                            newValue = true;
                        }
                        if (maxBitInRow == countBitInRow && countBitInRow != 0)
                        {
                            if (newValue)
                            {
                                howManyTimesInRow = 1;
                                newValue = false;
                            }
                            else
                            {
                                howManyTimesInRow++;
                            }
                        }
                        countBitInRow = 0;
                    }
                }
                if (maxBitInRow < countBitInRow)
                {
                    maxBitInRow = countBitInRow;
                    newValue = true;
                }
                if (maxBitInRow == countBitInRow && countBitInRow != 0)
                {
                    if (newValue)
                    {
                        howManyTimesInRow = 1;
                        newValue = false;
                    }
                    else
                    {
                        howManyTimesInRow++;
                    }
                }

                //new row
                if (maxBitGlobalRow < maxBitInRow)
                {
                    maxBitGlobalRow = maxBitInRow;
                    howManyTimesInRowGlobal = howManyTimesInRow;
                }
                else if (maxBitGlobalRow == maxBitInRow)
                {
                    howManyTimesInRowGlobal += howManyTimesInRow;
                }
                
            }
        }
        private static int GetBitAtPosition(int bitPosition, int[] numbers, int counterRow)
        {
            int bit = 0;
            int mask = 1;
            mask = mask << bitPosition;
            int nAndMask = numbers[counterRow] & mask;
            bit = nAndMask >> bitPosition;
            return bit;
        }
    }
}
