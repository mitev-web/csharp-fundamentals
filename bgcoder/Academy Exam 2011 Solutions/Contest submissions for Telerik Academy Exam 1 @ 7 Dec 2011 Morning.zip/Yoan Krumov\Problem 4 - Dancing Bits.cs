using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            uint p = 0;
            string binaryString = "";
            int idx, idx2;
            
            int sum = 0;
            string userInput = Console.ReadLine();
            int k = int.Parse(userInput);

            userInput = Console.ReadLine();
            int n = int.Parse(userInput);

            for (int i = 0; i < n; i++)
            {
                userInput = Console.ReadLine();
                p = uint.Parse(userInput);
                binaryString = binaryString + Convert.ToString(p, 2);
            }
            //Console.WriteLine(binaryString);
            //if (k==3)
            //{
            //    idx = binaryString.IndexOf("111");
            //    idx2 = binaryString.IndexOf("000");
            //    sum = idx + idx2;
            //}
            //else if (k==4)
            //{
               
            //    idx = binaryString.IndexOf("1111");
            //    idx2 = binaryString.IndexOf("0000");
            //    sum = idx + idx2;
            
            //}
            //else if (k == 5)
            //{

            //    idx = binaryString.IndexOf("11111");
            //    idx2 = binaryString.IndexOf("00000");
            //    sum = idx + idx2;

            //}
            //else if (k == 6)
            //{

            //    idx = binaryString.IndexOf("111111");
            //    idx2 = binaryString.IndexOf("000000");
            //    sum = idx + idx2;

            //}
            //else if (k == 7)
            //{

            //    idx = binaryString.IndexOf("1111111");
            //    idx2 = binaryString.IndexOf("0000000");
            //    sum = idx + idx2;

            //}
            //else if (k == 2)
            //{

            //    idx = binaryString.IndexOf("11");
            //    idx2 = binaryString.IndexOf("00");
            //    sum = idx + idx2;

            //}
            //else if (k == 1)
            //{

            //    idx = binaryString.IndexOf("1");
            //    idx2 = binaryString.IndexOf("0");
            //    sum = idx + idx2;

            //}
            switch (k)
            {
                case 3:
                    idx = binaryString.IndexOf("111");
                    idx2 = binaryString.IndexOf("000");
                    sum = idx + idx2;
                    break;
                case 4:
                    idx = binaryString.IndexOf("1111");
                    idx2 = binaryString.IndexOf("0000");
                    sum = idx + idx2;
                    break;
                case 5:
                    idx = binaryString.IndexOf("11111");
                    idx2 = binaryString.IndexOf("00000");
                    sum = idx + idx2;
                    break;
                case 6:
                    idx = binaryString.IndexOf("111111");
                    idx2 = binaryString.IndexOf("000000");
                    sum = idx + idx2;
                    break;
                case 7:
                    idx = binaryString.IndexOf("1111111");
                    idx2 = binaryString.IndexOf("0000000");
                    sum = idx + idx2;
                    break;
                case 8:
                    idx = binaryString.IndexOf("11111111");
                    idx2 = binaryString.IndexOf("00000000");
                    sum = idx + idx2;
                    break;
                case 9:
                    idx = binaryString.IndexOf("111111111");
                    idx2 = binaryString.IndexOf("000000000");
                    sum = idx + idx2;
                    break;
                case 2:
                    idx = binaryString.IndexOf("11");
                    idx2 = binaryString.IndexOf("00");
                    sum = idx + idx2;
                    break;
            }
            
            Console.WriteLine(sum);
        }
    }
}
