using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_4
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            //int k = 3;
            //int n = 4;
            //int[] numbers = new int[4] { 5, 6, 14, 143 };

            int k = int.Parse(Console.ReadLine());
            long n = long.Parse(Console.ReadLine());
            long[] numbers = new long[n];

            for (int i = 0; i < n; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }

            string binaryConcatenation = "";

            for (int i = 0; i < n; i++)
            {
                string StringNumber = Convert.ToString(numbers[i], 2);

                binaryConcatenation += StringNumber;
            }

            string currentBit = "";
            int sequance = 0;
            int sequanceCount = 0;
            string prevBit = "begining";
            int lenght = binaryConcatenation.Length;

            if (k != 1)
            {
                for (int i = 1; i < lenght; i++)
                {
                    currentBit = binaryConcatenation.Substring(0, 1);
                    binaryConcatenation = binaryConcatenation.Remove(0, 1);

                    if (currentBit == prevBit)
                    {
                        sequance += 1;
                    }
                    else
                    {
                        if (sequance == k - 1)
                        {
                            sequanceCount++;
                        }
                        sequance = 0;
                    }

                    if (prevBit == "begining")
                    {
                        prevBit = currentBit;
                    }
                    else
                    {
                        prevBit = currentBit;
                    }
                }
            }
            else
            {
                sequanceCount = lenght;
            }
            Console.WriteLine(sequanceCount);
        }
    }
}