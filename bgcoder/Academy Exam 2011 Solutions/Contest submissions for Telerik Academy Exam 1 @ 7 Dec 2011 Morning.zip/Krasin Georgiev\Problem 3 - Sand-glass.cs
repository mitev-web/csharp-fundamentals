using System;

    class SandGlass
    {
        static void Main()
        {
            byte n = byte.Parse(Console.ReadLine());


            for (int i = 0; i < n; i++)
            {

                    for (int j = 0; j < n; j++)
                    {
                        if ((j >= i && j < n - i && i<=n/2)||(i > n/2 && j>=n-1-i && j<=i))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    Console.WriteLine();
            }
         


        }
    }
