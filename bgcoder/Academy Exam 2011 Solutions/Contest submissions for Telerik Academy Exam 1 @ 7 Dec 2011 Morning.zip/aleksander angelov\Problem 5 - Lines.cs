using System;
using System.Linq;
using System.Text;

namespace LineGrid_task5_
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] check = { 0, 1 };
            int currentCheck = 0;
            int[] n = new int[8];
            int[,] matrice = new int[8, 8];
            int digit;
            for (int i = 0; i < 8; i++)
            {
                n[i] = int.Parse(Console.ReadLine());
                digit = n[i];
                for (int a = 0; a < 8; a++)
                {
                    matrice[i, a] = digit & 1;
                    digit = digit >> 1;                    
                    if (matrice[i, a] == 1)
                    {
                        currentCheck++;

                    }
                    else if (currentCheck > check[0])
                    {
                        check[0] = currentCheck;
                        currentCheck = 0;
                        check[1] = 1;
                    }
                    else if (currentCheck == check[0])
                    {
                        check[1]++;
                        currentCheck = 0;
                    }
                    else
                    {
                        currentCheck = 0;
                    }

                    
                       
                    }
            
                    if (currentCheck > check[0])
                    {
                        check[0] = currentCheck;
                        currentCheck = 0;
                        check[1] = 1;
                    }
                    else if (currentCheck == check[0])
                    {
                        check[1]++;
                    }
                    else
                    {
                        currentCheck = 0;
                    }
                    
                }
                
            
            for (int i = 0; i < 8; i++)
            {
                for (int a = 0; a < 8; a++)
                {
                    if (matrice[a, i] == 1)
                    {
                        currentCheck++;

                    }
                    else if (currentCheck > check[0])
                    {
                        check[0] = currentCheck;
                        currentCheck = 0;
                        check[1] = 1;
                    }
                    else if (currentCheck == check[0])
                    {
                        check[1]++;
                        currentCheck = 0;
                    }
                    else
                    {
                        currentCheck = 0;
                    }
                }
                if (currentCheck > check[0])
                {
                    check[0] = currentCheck;
                    currentCheck = 0;
                    check[1] = 1;
                }
                else if (currentCheck == check[0])
                {
                    check[1]++;
                    currentCheck = 0;
                }
                else
                {
                    currentCheck = 0;
                }
            }

            Console.WriteLine(check[0]);
            Console.WriteLine(check[1]);

        }
    }
}
