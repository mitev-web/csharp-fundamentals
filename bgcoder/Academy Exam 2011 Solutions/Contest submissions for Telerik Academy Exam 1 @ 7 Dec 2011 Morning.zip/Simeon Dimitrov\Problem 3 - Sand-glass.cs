using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gwenogfryn
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            bool flag = false;
            int end = n;
            //n = n / 2;
            //n++;
           // Console.WriteLine(n);
            int start = -1;
            
            for (int i = 0; i < n; i++)
            {
                if (i == n/2 + 1)
                {
                    flag = true;
                }
                if (flag == false)
                {
                    end--;
                    start++;
                }
                else
                {
                    end++;
                    start--;
                }
                for (int j = 0; j < n; j++)
                {
                    if (j >= start && j <= end)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
