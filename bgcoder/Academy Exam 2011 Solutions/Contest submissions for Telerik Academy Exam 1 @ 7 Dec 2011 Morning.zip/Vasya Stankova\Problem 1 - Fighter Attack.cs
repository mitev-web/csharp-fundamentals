using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1FighterAttack
{
    class FighterAttack
    {
        static void Main(string[] args)
        {
            string inputLine = Console.ReadLine();
            int pX1 = int.Parse(inputLine);

            inputLine = Console.ReadLine();
            int pY1 = int.Parse(inputLine);

            inputLine = Console.ReadLine();
            int pX2 = int.Parse(inputLine);

            inputLine = Console.ReadLine();
            int pY2 = int.Parse(inputLine);

            inputLine = Console.ReadLine();
            int fX = int.Parse(inputLine);

            inputLine = Console.ReadLine();
            int fY = int.Parse(inputLine);

            inputLine = Console.ReadLine();
            int d = int.Parse(inputLine);

            int damage = CalculateDamage(pX1, pY1, pX2, pY2, fX, fY, d);

            Console.WriteLine("{0}%", damage);
        }

        private static int CalculateDamage(int pX1, int pY1, int pX2, int pY2, int fX, int fY, int d)
        {
            int damage = 0;

            int hitPointX = fX + d;
            int hitPointY = fY;

            if (IsInsideRectangle(pX1, pY1, pX2, pY2, hitPointX, hitPointY))
            {
                damage += 100;
            }

            if (IsInsideRectangle(pX1, pY1, pX2, pY2, hitPointX + 1, hitPointY))
            {
                damage += 75;
            }

            if (IsInsideRectangle(pX1, pY1, pX2, pY2, hitPointX, hitPointY + 1))
            {
                damage += 50;
            }

            if (IsInsideRectangle(pX1, pY1, pX2, pY2, hitPointX, hitPointY - 1))
            {
                damage += 50;
            }

            return damage;
        }

        private static bool IsInsideRectangle(int pX1, int pY1, int pX2, int pY2, int x, int y)
        {
            int minX = Math.Min(pX1, pX2);
            int maxX = Math.Max(pX1, pX2);
            int minY = Math.Min(pY1, pY2);
            int maxY = Math.Max(pY1, pY2);

            bool result = (minX <= x) && (x <= maxX)
                && (minY <= y) && (y <= maxY);

            return result;
        }
    }
}

