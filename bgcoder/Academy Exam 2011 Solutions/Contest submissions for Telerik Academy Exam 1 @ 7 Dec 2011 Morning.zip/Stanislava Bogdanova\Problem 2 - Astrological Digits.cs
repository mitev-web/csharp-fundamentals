using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Ex._02
{
    class Program
    {
        static void Main(string[] args)
        {
            double N = (double.Parse(Console.ReadLine()));
            
            int nInt = (int)N;
            //double nDouble = N - nInt;
            BigInteger sumInt = 0;
            BigInteger sumDoub = 0;
            BigInteger sum = 0;
            sumInt = ReturnSumOfIntPart(nInt);
            sumDoub = ReturnSumOfNOTIntPart(N);
            sum = sumDoub + sumInt;
            while (sum > 9)
            {
                sum = FindSum(sum);
                
            }
            Console.WriteLine(sum);
            //Console.WriteLine(sumDoub);
        }
        static BigInteger ReturnSumOfIntPart(BigInteger n)
        {
            if (n < 0)
            {
                n = -n;
            }
            BigInteger sum = 0;
            while (n > 0)
            {
                sum = sum + n % 10;
                n = n / 10;
            }
            return sum;
        }
        static BigInteger FindSum(BigInteger sum)
        {
            BigInteger sumResult = 0;
            while(sum>0)
            {
                sumResult = sum % 10 + sumResult;
                sum = sum / 10;
            }
            return sumResult;
        }


        static BigInteger ReturnSumOfNOTIntPart(double n)
        {
            BigInteger sum = 0;
           
            
            
            return sum;
        }
    }
}
