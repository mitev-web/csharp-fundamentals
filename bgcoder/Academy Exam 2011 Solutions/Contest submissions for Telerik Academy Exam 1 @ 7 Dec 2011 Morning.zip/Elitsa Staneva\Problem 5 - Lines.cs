using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lines
{
    class Program
    {
        static void Main(string[] args)
        {
            int n0 = int.Parse(Console.ReadLine());
            int n1 = int.Parse(Console.ReadLine());
            int n2 = int.Parse(Console.ReadLine());
            int n3 = int.Parse(Console.ReadLine());
            int n4 = int.Parse(Console.ReadLine());
            int n5 = int.Parse(Console.ReadLine());
            int n6 = int.Parse(Console.ReadLine());
            int n7 = int.Parse(Console.ReadLine());

            int[,] arr = new int[8, 8];

            for (int j = 7; j >= 0; j--)
            {
                if (n0 >= Math.Pow(2, j))
                {
                    arr[0, j] = 1;
                    n0 -= (int)Math.Pow(2, j);
                }
                else if(n0<Math.Pow(2,j))
                {
                    arr[0, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n1 >= Math.Pow(2, j))
                {
                    arr[1, j] = 1;
                    n1 -= (int)Math.Pow(2, j);
                }
                else if (n1 < Math.Pow(2, j))
                {
                    arr[1, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n2 >= Math.Pow(2, j))
                {
                    arr[2, j] = 1;
                    n2 -= (int)Math.Pow(2, j);
                }
                else if (n2 < Math.Pow(2, j))
                {
                    arr[2, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n3 >= Math.Pow(2, j))
                {
                    arr[3, j] = 1;
                    n3 -= (int)Math.Pow(2, j);
                }
                else if (n3 < Math.Pow(2, j))
                {
                    arr[3, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n4 >= Math.Pow(2, j))
                {
                    arr[4, j] = 1;
                    n4 -= (int)Math.Pow(2, j);
                }
                else if (n4 < Math.Pow(2, j))
                {
                    arr[4, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n5 >= Math.Pow(2, j))
                {
                    arr[5, j] = 1;
                    n5 -= (int)Math.Pow(2, j);
                }
                else if (n5 < Math.Pow(2, j))
                {
                    arr[5, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n6 >= Math.Pow(2, j))
                {
                    arr[6, j] = 1;
                    n6 -= (int)Math.Pow(2, j);
                }
                else if (n6 < Math.Pow(2, j))
                {
                    arr[6, j] = 0;
                }
            }

            for (int j = 7; j >= 0; j--)
            {
                if (n7 >= Math.Pow(2, j))
                {
                    arr[7, j] = 1;
                    n0 -= (int)Math.Pow(2, j);
                }
                else if (n7 < Math.Pow(2, j))
                {
                    arr[7, j] = 0;
                }
            }


           /* for (int i = 0; i <= 7; i++)
            {
                for (int j = 7; j >= 0; j--)
                    Console.Write(arr[i, j] + " ");
                Console.WriteLine();
            }
            */

            //int maxlength = 0;
            int number = 0;
          //  Console.WriteLine(arr[0,7]);
            /*int start=0;
            int end = 0;
            int len = 0;
            while (start < 8 && end < 8)
            {
                while (arr[0, start] == 0)
                    start++;
                end = start;
                while (end<8&&arr[0, end] == 1)
                    end++;
                len = end - start;
                if (len > maxlength)
                    maxlength = len;
                start = end + 1;
                Console.WriteLine(maxlength);
            }*/

            int[,] lens = new int[2, 8];

           for (int i = 0; i < 8; i++)
            {
                int start = 0;
                int end =0;
                int maxlength = 0;
               // while (end < 8 && start <8)
               // {
                    while (start<7&&arr[i,start] == 0)
                        start++;
                    //Console.WriteLine("start: " + start);
                    end = start;
                    while (end<=7&&arr[i, end] == 1)
                        end++;
                    //Console.WriteLine("end: " + end);
                    int len = end-start;
                    if (len > maxlength)
                        maxlength = len;
                    start = end;
                //}
               // Console.WriteLine(maxlength);
                lens[0, i] = maxlength;
            }

           for (int i = 0; i < 8; i++)
           {
               int start = 0;
               int end = 0;
               int maxlength = 0;
              // while (end < 8 && start < 8)
              // {
                   while (start < 7 && arr[start,i] == 0)
                       start++;
                   //Console.WriteLine("start: " + start);
                   end = start;
                   while (end <= 7 && arr[end,i] == 1)
                       end++;
                   //Console.WriteLine("end: " + end);
                   int len = end - start;
                   if (len > maxlength)
                       maxlength = len;
                   start = end;
              // }
               //Console.WriteLine(maxlength);
               lens[1, i] = maxlength;
           }

            int m=0;
            for (int i = 0; i < 2; i++)
                for (int j = 0; j < 8; j++)
                    if (lens[i,j] > m)
                        m = lens[i,j];

            for (int i = 0; i < 2; i++)
                for (int j = 0; j < 8; j++)
                    if (lens[i,j] == m)
                        number++;

           

            Console.WriteLine(m);
            Console.WriteLine(number);


          
        }
    }
}
