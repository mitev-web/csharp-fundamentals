using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int row = 1; row <= n/2+1; row++)
            {
                
                for (int col = 1; col <= n; col++)
                {
                    if((col<row)|(col>n-row+1))
                    Console.Write(".");
                    else if((row==n/2+1)&&(col==n/2+1))
                    Console.Write("*");
                    else
                        Console.Write("*");
                }     
                Console.WriteLine();
            }
            for (int row = n/2+2; row <= n ; row++)
            {

                for (int col = 1; col <= n; col++)
                {
                    if ((col<n-row+1) | (col>row  ))
                        Console.Write(".");
                    
                        
                    else
                        Console.Write("*");
                }
                Console.WriteLine();
            }

        }
    }
}
