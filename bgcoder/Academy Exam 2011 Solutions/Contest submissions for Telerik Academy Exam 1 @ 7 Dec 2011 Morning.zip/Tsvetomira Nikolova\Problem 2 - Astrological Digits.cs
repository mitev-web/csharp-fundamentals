using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime startTime = DateTime.Now;
            decimal n = decimal.Parse(Console.ReadLine());
            decimal sum = 0m;
            int length=n.ToString().Length;
            string strNum = n.ToString();
            for (int i = 0; i < length; i++)
            {
                sum = sum + Convert.ToDecimal(strNum[i].ToString());
            }
            Console.WriteLine(sum);


            Console.WriteLine(DateTime.Now - startTime);



        }
    }
}
