using System;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            if (Px1>Px2)
	        {
                Px1 = Px1+Px2;
		        Px2 = Px1-Px2;
                Px1 = Px1-Px2;
	        }
            if (Py1>Py2)
	        {
                Py1 = Py1+Py2;
		        Py2 = Py1-Py2;
                Py1 = Py1-Py2;		 
	        }
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int hit = Fx + D;
            int result = 0;
            if ((hit >= Px1)&&(hit<=Px2)&&(Fy>=Py1)&&(Fy<=Py2))
            {
                result += 100;
            }
            if (((hit + 1) >= Px1) && ((hit + 1) <= Px2) && (Fy >= Py1) && (Fy <= Py2))
            {
                result += 75;
            }
            if (((Fy + 1) >= Py1) && ((Fy + 1) <= Py2) && (hit >= Px1) && (hit <= Px2))
            {
                result += 50;
            }
            if (((Fy - 1) >= Py1) && ((Fy - 1) <= Py2) && (hit >= Px1) && (hit <= Px2))
            {
                result += 50;
            }
            Console.WriteLine(result+"%");
            
        }
    }
}
