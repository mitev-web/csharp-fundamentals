using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task3_SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int row = 0; row < n+1; row++)
            {
                if (n - 2 * row == 1)
                {
                    continue;
                }
                for (int points = 0; points < (n - Math.Abs(n - 2 * row))/2; points++)
                {
                    Console.Write('.');
                }
               
                for (int stars = 0; stars < Math.Abs(n-2*row); stars++)
                {
                    Console.Write('*');
                }
                for (int points = 0; points < (n - Math.Abs(n - 2 * row)) / 2; points++)
                {
                    Console.Write('.');
                }
                Console.WriteLine(  );
            }
        }
    }
}
