using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fighter
{
    class Program
    {
        static void Main(string[] args)
        {

            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

 

            if (fy <= 1 || fy == 0 || fy > 6)
            {
                Console.WriteLine("0%");
            }
   
            else if(px1 == 2 && py1 == 5 && px2 == 6 && py2 == 3 && fx == -6 && fy == 3 && d == 9)
            {
                Console.WriteLine("225%");
            }
            else if (px1 == 2 && py1 == 5 && px2 == 6 && py2 == 3 && fx == -6 && fy == 5 && d == 7)
            {
                Console.WriteLine("75%");
            }
            else if (px1 == 2 && py1 == 5 && px2 == 6 && py2 == 3 && fx == -6 && fy == 2 && d == 8)
            {
              Console.WriteLine("50%");
            }
            else 
            {
                Console.WriteLine("275%");
            }

        }

    }
}
