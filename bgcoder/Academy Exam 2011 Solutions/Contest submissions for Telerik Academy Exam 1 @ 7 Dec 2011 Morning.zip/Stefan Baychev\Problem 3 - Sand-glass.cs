using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class SandGlass
    {
        static void Main(string[] args)
        {
            byte nWidth = byte.Parse(Console.ReadLine());
            byte p = nWidth;

            for (byte i = 1; i <= nWidth; i++)
            {
                if (i < (nWidth / 2) + 1)
                {
                    for (byte j = 1; j <= nWidth; j++)
                    {
                        if ( (i == j) && (i > 1)  )
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                    Console.WriteLine();
                }
                else
                {
                    p--;
                    for (byte t = 1; t <= nWidth; t++)
                    {

                        if (t < (nWidth / 2))
                        {
                            for (byte k = 1; k <= nWidth; k++)
                            {
                                if ( (Math.Abs(k - p) == p - 1 && (p > 2) ) )
                                //Math.Abs(k - p) == p + 1  || p == k + 1
                                {
                                    Console.Write(".");
                                }
                                else
                                {
                                    Console.Write("*");
                                }

                            }
                            Console.WriteLine();
                        }
                    }
                }
            }
        }
    }
}