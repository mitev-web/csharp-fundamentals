using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex4_DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string consoleInput = Console.ReadLine();
            int k = int.Parse(consoleInput);
            
            consoleInput = Console.ReadLine();
            int n = int.Parse(consoleInput);
            string concatenatedBits="";
            for (int i = 0; i < n; i++)
            {
              
                consoleInput = Console.ReadLine();
                int number = int.Parse(consoleInput);
                string stringNumber = Convert.ToString(number, 2);
                concatenatedBits += stringNumber;
            }
            
            int dancingBits = 0;
            int result = 0;
            for (int i = 0; i < concatenatedBits.Length; i++)
            {
                if (dancingBits > k)
                {
                    i = i + dancingBits;
                }
                dancingBits = 1;
                for (int j = i+1; j < concatenatedBits.Length; j++)
                {
                    if (concatenatedBits[i] == concatenatedBits[j])
                    {
                        dancingBits++;
                    }
                    else
                    {
                        break;
                    }
                }
                if (dancingBits == k)
                {
                    result++;
                }
                
            }
            Console.WriteLine(result);
        }
    }
}
