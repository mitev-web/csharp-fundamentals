using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    
    class Program
    {
        static void Main()
        {
            int Px1, Px2, Py1, Py2, Fx, Fy, d;

           
            Px1 = Convert.ToInt32(Console.ReadLine());
      
           
            Px2 = Convert.ToInt32(Console.ReadLine());

          
            Py2 = Convert.ToInt32(Console.ReadLine());
          
           
            Py1 = Convert.ToInt32(Console.ReadLine());
      
       
          
            Fx = Convert.ToInt32(Console.ReadLine());
           
          
            Fy = Convert.ToInt32(Console.ReadLine());
           

          
            d = Convert.ToInt32(Console.ReadLine());

            int hit;

            hit = Fx + d;

            if (hit >= (Px1-1) && hit < Px2+1)
            {
                if (Fy >=  Py1 && Fy <= Py2 )
                {
                    if (hit == (Px1 - 1) && (Fy >= Py1 && Fy <= Py2)) Console.WriteLine("75%");

                    if (hit >= Px1){
                    
                    if (Fy == (Py1 - 1) ||Fy == (Py2 + 1)) Console.WriteLine("50%");
                    if (Fy == Py1 || Fy == Py2) Console.WriteLine("225%");
                    if (Fy > (Py1 + 1) && Fy < (Py2 - 1)) Console.WriteLine("275%");    

                    
                    }


                               
                }
                
            
            }
             else Console.WriteLine("0%");
            /* -------------------------- */



        }
    }
}
