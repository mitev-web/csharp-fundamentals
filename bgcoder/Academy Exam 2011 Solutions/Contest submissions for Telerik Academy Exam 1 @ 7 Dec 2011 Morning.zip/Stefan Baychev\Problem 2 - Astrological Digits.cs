using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace AstrologicalDigits
{
    class AstrologicalDigits
    {
      
        static void Main(string[] args)
        {
            string nNumber = Console.ReadLine();
            decimal nVar = decimal.Parse(nNumber);
            long length = nNumber.Substring(nNumber.IndexOf(".") + 1).Length;
            BigInteger count = 0;
            decimal afterN = nVar - Math.Truncate(nVar);
            decimal nVarWhole = Math.Truncate(nVar);
            decimal fractionReal = 0;
            if (afterN > 0)
            {
                fractionReal = (long)(Math.Pow(10, length)) * afterN;
                string fR = fractionReal.ToString();
                string aFn = nVarWhole.ToString();
                string tempFrAfn = aFn + fR;

                nVar = decimal.Parse(tempFrAfn);
            }
            if (nVar < 0)
            {
                nVar = nVar * (-1);
            }
            while (nVar != 0)
            {
                count += (BigInteger)nVar % 10;
                nVar /= 10;
                if (count > 9)
                {
                    count = count - 9;
                }
            } 
            Console.WriteLine(count);
        }
    }
}