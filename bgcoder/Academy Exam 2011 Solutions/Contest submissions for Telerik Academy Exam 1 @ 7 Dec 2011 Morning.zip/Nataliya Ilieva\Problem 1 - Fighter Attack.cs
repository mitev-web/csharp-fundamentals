using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int damage = new int();
            if (Px1 < Px2 && Py1 > Py2)
            {
                if (Fx + D >= Px1 && Fx + D < Px2 && (Fy == Py2 || Fy == Py1)) //вътре в растението
                {
                    damage = 225;
                }
                else if ((Fx + D == Px2 || Fx + D == Px1) && (Fy == Py1 || Fy == Py2))
                {
                    damage = 150;
                }
                else if (Fx + D == Px2 && Fy > Py2 && Fy < Py1 - Py2)
                {
                    damage = 200;
                }
                else if (Fx + D >= Px1 && Fx + D < Px2 && Fy < Py1 && Fy > Py1 - Py2)
                {
                    damage = 275;
                }
                else if (Fx + D == (Px1 - 1) && Fy >= Py1 - Py2 && Fy <= Py1) // точно пред растението
                {
                    damage = 75;
                }
                else if (Fx + D >= Px1 && Fx + D <= Px2 && (Fy < Py1 - Py2 || Fy > Py1)) // точно над растението или под него
                {
                    damage = 50;
                }
 
                else
                {
                    damage = 0;
                }
 
            }
 
            if (Px1 < Px2 && Py1 < Py2)
            {
                if (Fx + D >= Px1 && Fx + D < Px2 && (Fy == Py2 || Fy ==  Py1)) // вътре в растението
                {
                    damage = 225;
                }
                else if ((Fx + D == Px2 || Fx + D == Px1) && (Fy == Py1 || Fy == Py2))
                {
                    damage = 150;
                }
                else if (Fx + D >= Px1 && Fx + D < Px2 && Fy < Py2 && Fy > Py2 - Py1)
                {
                    damage = 275;
                }
                else if (Fx + D == Px2 && Fy > Py1 && Fy < Py2 - Py1)
                {
                    damage = 200;
                }
 
                else if (Fx + D == (Px1 - 1) && Fy >= Py2 - Py1 && Fy <= Py2) // точно пред растението
                {
                    damage = 75;
                }
                else if (Fx + D >= Px1 && Fx + D <= Px2 && (Fy < Py2 - Py1 || Fy > Py2)) // точно над него или под него
                {
                    damage = 50;
                }
 
                else
                {
                    damage = 0;
                }
            }
 
            if (Px1 > Px2 && Py1 > Py2)
            {
                if (Fx + D >= Px2 && Fx + D < Px1 && (Fy == Py2 || Fy == Py1)) //вътре в растението
                {
                    damage = 225;
                }
                else if ((Fx + D == Px1 || Fx + D == Px2) && (Fy == Py1 || Fy == Py2))
                {
                    damage = 150;
                }
                else if (Fx + D == Px1 && Fy > Py2 && Fy < Py1 - Py2)
                {
                    damage = 200;
                }
                else if (Fx + D >= Px2 && Fx + D < Px1 && Fy < Py1 && Fy > Py1 - Py2)
                {
                    damage = 275;
                }
                else if (Fx + D == (Px2 - 1) && Fy >= Py1 - Py2 && Fy <= Py1) // точно пред растението
                {
                    damage = 75;
                }
                else if (Fx + D >= Px2 && Fx + D <= Px1 && (Fy < Py1 - Py2 || Fy > Py1)) // точно над растението или под него
                {
                    damage = 50;
                }
 
                else
                {
                    damage = 0;
                }
 
            }
 
            if (Px1 > Px2 && Py1 < Py2)
            {
                if (Fx + D >= Px2 && Fx + D < Px1 && (Fy == Py2 || Fy == Py1)) // вътре в растението
                {
                    damage = 225;
                }
                else if ((Fx + D == Px1 || Fx + D == Px2) && (Fy == Py1 || Fy == Py2))
                {
                    damage = 150;
                }
                else if (Fx + D >= Px2 && Fx + D < Px1 && Fy < Py2 && Fy > Py2 - Py1)
                {
                    damage = 275;
                }
                else if (Fx + D == Px1 && Fy > Py1 && Fy < Py2 - Py1)
                {
                    damage = 200;
                }
 
                else if (Fx + D == (Px2 - 1) && Fy >= Py2 - Py1 && Fy <= Py2) // точно пред растението
                {
                    damage = 75;
                }
                else if (Fx + D >= Px2 && Fx + D <= Px1 && (Fy < Py2 - Py1 || Fy > Py2)) // точно над него или под него
                {
                    damage = 50;
                }
 
                else
                {
                    damage = 0;
                }
 
            }
            Console.WriteLine("{0}%", damage);
 
        }
    }
}