using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task05
{
    class Program
    {
        private const int numberOfRows = 8;
        private const int numberOfCols = 8;

        private static int maxLength = 0;
        private static int numberOfMaxLengthLines = 0;

        static void Main(string[] args)
        {
            const int numberCount = 8;


            byte[] numbers = new byte[numberCount];

            ReadNumbers(numbers);
            SearchVertically(numbers);
            SearchHorizontally(numbers);

            if (maxLength == 1)
            {
                numberOfMaxLengthLines /= 2;
            }

            Console.WriteLine(maxLength);
            Console.WriteLine(numberOfMaxLengthLines);
        }

        private static void SearchVertically(byte[] numbers)
        {
            int lineLength = 0;

            for (int colCnt = 0; colCnt < numberOfCols; colCnt++)
            {
                for (int rowCnt = 0; rowCnt < numberOfRows; rowCnt++)
                {
                    if (GetBit(numbers[rowCnt], colCnt))
                    {
                        lineLength++;
                    }
                    else
                    {
                        CompareLenghts(ref lineLength);
                    }
                }
                CompareLenghts(ref lineLength);
            }
        }


        private static void SearchHorizontally(byte[] numbers)
        {
            int lineLength = 0;

            for (int rowCnt = 0; rowCnt < numberOfRows; rowCnt++)
            {
                for (int colCnt = 0; colCnt < numberOfCols; colCnt++)
                {
                    if (GetBit(numbers[rowCnt], colCnt))
                    {
                        lineLength++;
                    }
                    else
                    {
                        CompareLenghts(ref lineLength);
                    }
                }
                CompareLenghts(ref lineLength);
            }
        }


        private static void CompareLenghts(ref int lineLength)
        {
            if (lineLength == 0)
            {
                return;
            }

            if (lineLength == maxLength)
            {
                numberOfMaxLengthLines++;
            }
            else if (lineLength > maxLength)
            {
                maxLength = lineLength;
                numberOfMaxLengthLines = 1;
            }

            lineLength = 0;
        }

        private static void ReadNumbers(byte[] numbers)
        {
            for (int numberCnt = 0; numberCnt < numbers.Length; numberCnt++)
            {
                numbers[numberCnt] = byte.Parse(Console.ReadLine());
            }
        }

        private static bool GetBit(byte number, int bitPosition)
        {
            if ((number & (1 << bitPosition)) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
