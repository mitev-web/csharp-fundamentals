using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {



            {
                double value = double.Parse(Console.ReadLine());
                int sign = 0;
                if (value < 0)
                {
                    value = -value;
                    sign = 1;
                }
                if (value <= 9)
                {
                    Console.WriteLine(value);
                }
                else if (value <= 99)
                {
                    Console.WriteLine(sign + 2);
                }
                else if (value <= 999)
                {
                    Console.WriteLine(sign + 3);
                }
                else if (value <= 9999)
                {
                    Console.WriteLine(sign + 4);
                }
                else if (value <= 99999)
                {
                    Console.WriteLine(sign + 5);
                }
                else if (value <= 999999)
                {
                    Console.WriteLine(sign + 6);
                }
                else if (value <= 9999999)
                {
                    Console.WriteLine(sign + 7);
                }
                else if (value <= 99999999)
                {
                    Console.WriteLine(sign + 8);
                }
                else if (value <= 999999999)
                {
                    Console.WriteLine(sign + 9);
                }
                else Console.WriteLine(sign + 10);
               

            }
        }
    }
}
