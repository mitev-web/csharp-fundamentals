using System;
namespace Exam2
{
    class Program
    {
        static void Main()
        {
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
            int Hitx = Fx + D;
            int Hity = Fy;
            int total=0;
 
            if (Hitx >= Px1 && Hitx <= Px2 && Hity >= Py2 && Hity <= Py1)
            {
                total += 100;
            }
            if (Hitx >= Px1 && Hitx <= Px2 && Hity + 1 >= Py2 && Hity + 1 <= Py1)
            {
                total += 50;
            }
            if (Hitx >= Px1 && Hitx <= Px2 && Hity - 1 >= Py2 && Hity - 1 <= Py1)
            {
                total += 50;
            }
            if (Hitx+1 >= Px1 && Hitx+1 <= Px2 && Hity >= Py2 && Hity <= Py1)
            {
                total += 75;
            }
            Console.WriteLine(total+"%");
        }
    }
}