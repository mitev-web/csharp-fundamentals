using System;
 
namespace SundayExam05
{
    class SundayExam05
    {
        static void Main()
        {
            int mask = 1;
            int zeros = 0;
            int ones = 0;
            int twos = 0;
            int threes = 0;
            int fours = 0;
            int fives = 0;
            int sixes = 0;
            int sevens = 0;
            int number0 = 0;
            int number1 = 0;
            int number2 = 0;
            int number3 = 0;
            int number4 = 0;
            int number5 = 0;
            int number6 = 0;
            int number7 = 0;
            int result = 0;
 
            for (int g = 0; g <= 7; g++)
            {
                long givenNumber = long.Parse(Console.ReadLine());// Next number
                for (int i = 0; i <= Math.Log(givenNumber, 2); i++)
                {
                    mask = 1 << i;
                    bool checker = (mask & givenNumber) != 0;
                    if (checker)
                    {
                        switch (i)
                        {
                            case 0: zeros++; break;
                            case 1: ones++; break;
                            case 2: twos++; break;
                            case 3: threes++; break;
                            case 4: fours++; break;
                            case 5: fives++; break;
                            case 6: sixes++; break;
                            case 7: sevens++; break;
                            default: break;
                        }
                    }
                }
            }
 
            for (int j = 0; j <= 7; j++)
            {
 
                if (zeros > 0)
                {
                    result += 1;
                    zeros--;
                }
                if (ones > 0)
                {
                    result += 2;
                    ones--;
                }
                if (twos > 0)
                {
                    result += 2 * 2;
                    twos--;
                }
                if (threes > 0)
                {
                    result += 2 * 2 * 2;
                    threes--;
                }
                if (fours > 0)
                {
                    result += 2 * 2 * 2 * 2;
                    fours--;
                }
                if (fives > 0)
                {
                    result += 2 * 2 * 2 * 2 * 2;
                    fives--;
                }
 
                if (sixes > 0)
                {
                    result += 2 * 2 * 2 * 2 * 2 * 2;
                    sixes--;
                }
                if (sevens > 0)
                {
                    result += 2 * 2 * 2 * 2 * 2 * 2 * 2;
                    sevens--;
                }
 
                switch (j)
                {
                    case 0: number0 = result; ; break;
                    case 1: number1 = result; break;
                    case 2: number2 = result; break;
                    case 3: number3 = result; break;
                    case 4: number4 = result; break;
                    case 5: number5 = result; break;
                    case 6: number6 = result; break;
                    case 7: number7 = result; break;
                    default: break;
                }
                result = 0;
            }
            Console.WriteLine(number7);
            Console.WriteLine(number6);
            Console.WriteLine(number5);
            Console.WriteLine(number4);
            Console.WriteLine(number3);
            Console.WriteLine(number2);
            Console.WriteLine(number1);
            Console.WriteLine(number0);
        }
    }
}