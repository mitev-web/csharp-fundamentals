using System;

namespace task3
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N = byte.Parse(Console.ReadLine());
            for (int i = 0; i < (N+1)/2; i++)
            {
                string dots = new string('.', i);
                string stars = new string('*',N-(2*i));
                Console.WriteLine(dots+stars+dots);
            }
            for (int i = (N-1)/2; i > 0; i--)
            {
                string dots2 = new string('.', i - 1);
                string stars2 = new string('*', N-(2*i)+2);
                Console.WriteLine(dots2+stars2+dots2);
            }
        }
    }
}
