using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem4DancingBits
{
    class DancingBits
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            int[] numbers = new int[n];

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }

            int countOfDancingBits = CountOfDancingBits(numbers, k);
            Console.WriteLine(countOfDancingBits);
        }

        private static int CountOfDancingBits(int[] numbers, int k)
        {
            int count = 0;

            BigInteger wholeNumber = new BigInteger();

            int length = 0;

            for (int i = numbers.Length - 1; i >= 0; i--)
            {
                wholeNumber |= (numbers[i] << length);

                int rounded = RoundToNextDegreeOf2(numbers[i]);

                for (int p = 0; p < 32; p++)
                {
                    if ((1 << p) == rounded)
                    {
                        if (PthBit(numbers[i], p) == 0)
                        {
                            length += p;
                        }
                        else
                        {
                            length += (p + 1);
                        }
                        break;
                    }
                }
            }

            for (int i = 0; i < length; )
            {
                int bit = PthBit(wholeNumber, i);
                bool found = true;
                for (int j = 1; j < k; j++)
                {
                    int nextBit = PthBit(wholeNumber, i + j);
                    if (bit != nextBit)
                    {
                        i++;
                        found = false;
                        break;
                    }
                }
                if (!found)
                {
                    continue;
                }
                if (i + k >= length)
                {
                    count++;
                    break;
                }
                else
                {
                    int bit1 = PthBit(wholeNumber, i + k);
                    if (bit != bit1)
                    {
                        count++;
                        i += k;
                    }
                    else
                    {
                        int position = k + 1;
                        int nextBit = PthBit(wholeNumber, position);
                        while (nextBit == bit)
                        {
                            position++;
                            nextBit = PthBit(wholeNumber, position);
                        }
                        i += position;
                    }
                }

            }

            return count;
        }

        static int RoundToNextDegreeOf2(int number)
        {
            int result = number;
            result--;
            result |= result >> 1;
            result |= result >> 2;
            result |= result >> 4;
            result |= result >> 8;
            result |= result >> 16;
            result++;
            return result;
        }

        private static int PthBit(BigInteger number, int position)
        {
            BigInteger pthBit = (number >> position) & 1;
            return (int)pthBit;
        }
    }
}
