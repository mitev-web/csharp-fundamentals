using System;

class Program
{
    static void Main()
    {
        
        byte N = byte.Parse(Console.ReadLine());
        char asterisk = '*';
        char dot = '.';

        for(byte i = 1; i <= N; i++)
        {
            Console.Write(asterisk);
        }
        Console.WriteLine();

        for (byte i = 1; i <= N - 2; i++)
        {
            for (byte j = 1; j <= N; j++)
            {
                int k = 0;

                if (i <= ((N - 2) / 2))
                {
                    if (j == (i - k) || j == (N - k) || j == N || j == i)
                    {
                        Console.Write(dot);
                    }
                    else
                    {
                        Console.Write(asterisk);
                    }
                }

                if (i == ((N - 2)) / 2 + 1)
                {
                    if (j == (N / 2 + 1))
                    {
                        Console.Write(asterisk);
                    }
                    else
                    {
                        Console.Write(dot);
                    }
                }
                k++;
            }
            Console.WriteLine(); 
        } 
        
        for(byte i = 1; i <= N; i++)
        {
             Console.Write(asterisk);
        }
        Console.WriteLine();
    }
}