using System;
using System.Linq;
using System.Threading;
using System.Globalization;

namespace _01.FighterJet
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            decimal Px1 = decimal.Parse(Console.ReadLine());
            decimal Py1 = decimal.Parse(Console.ReadLine());
            decimal Px2 = decimal.Parse(Console.ReadLine());
            decimal Py2 = decimal.Parse(Console.ReadLine());
            decimal Fx = decimal.Parse(Console.ReadLine());
            decimal Fy = decimal.Parse(Console.ReadLine());
            decimal D = decimal.Parse(Console.ReadLine());
            decimal hitx = Fx + D;
            decimal hity = Fy;
            int dmg = 0;
            if (Px2 > Px1 && Py1 > Py2)
            {
                if (hitx >= Px1 && hity <= Py1 && hitx <= Px2 && hity >= Py2)
                {
                    dmg = dmg + 100;
                }
                if (hitx + 1 >= Px1 && hity <= Py1 && hitx + 1 <= Px2 && hity >= Py2)
                {
                    dmg = dmg + 75;
                }
                if (hitx >= Px1 && hity + 1 <= Py1 && hitx <= Px2 && hity + 1 >= Py2)
                {
                    dmg = dmg + 50;
                }
                if (hitx >= Px1 && hity - 1 <= Py1 && hitx <= Px2 && hity - 1 >= Py2)
                {
                    dmg = dmg + 50;
                }
            }
            
            
                if (hitx >= Px1 && hity >= Py1 && hitx <= Px2 && hity <= Py2)
                {
                    dmg = dmg + 100;
                }
                if (hitx + 1 >= Px1 && hity >= Py1 && hitx + 1 <= Px2 && hity <= Py2)
                {
                    dmg = dmg + 75;
                }
                if (hitx >= Px1 && hity + 1 >= Py1 && hitx <= Px2 && hity + 1 <= Py2)
                {
                    dmg = dmg + 50;
                }
                if (hitx >= Px1 && hity - 1 >= Py1 && hitx <= Px2 && hity - 1 <= Py2)
                {
                    dmg = dmg + 50;
                }

 
            
            if(Px1>Px2 && Py1<Py2)
                if (hitx <= Px1 && hity >= Py1 && hitx >= Px2 && hity <= Py2)
                {
                    dmg = dmg + 100;
                }
            if (hitx+1 <= Px1 && hity >= Py1 && hitx+1 >= Px2 && hity <= Py2)
            {
                dmg = dmg + 75;
            }
            if (hitx <= Px1 && hity+1 >= Py1 && hitx >= Px2 && hity+1 <= Py2)
            {
                dmg = dmg + 50;
            }
            if (hitx <= Px1 && hity-1 >= Py1 && hitx >= Px2 && hity-1 <= Py2)
            {
                dmg = dmg + 50;
            }

            
            Console.WriteLine("{0}%", dmg);
        }
    }
}
