using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem5
{
    class Problem5
    {
        static void Main()
        {
            byte[,] grid = new byte[8, 8];
            int number = new int();
            byte onCounter;
            int tempLine = 0;
            int maxLinesCount = 0;
            int maxLine = 1;

            for (int i = 0; i < 8; i++)
            {
                number = int.Parse(Console.ReadLine());
                for (int j = 7; j >= 0; j--)
                {
                    if ((number & 1) == 1)
                    {
                        grid[i, j] = 1;
                    }
                    else
                    {
                        grid[i, j] = 0;
                    }
                    number = number >> 1;
                }
            }




            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (grid[i,j] == 1)
                    {
                        tempLine++;
                    }
                    if ((grid[i, j] == 0) || (j == 7))
                    {
                        if (tempLine == maxLine) maxLinesCount++;

                        if (tempLine > maxLine)
                        {
                            maxLinesCount = 1;
                            maxLine = tempLine;
                        }
                        tempLine = 0;

                    }

                }
                tempLine = 0;
            }

            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    if (grid[i, j] == 1)
                    {
                        tempLine++;
                    }
                    if ((grid[i, j] == 0) || (i == 7))
                    {
                        if (tempLine == maxLine) maxLinesCount++;

                        if (tempLine > maxLine)
                        {
                            maxLinesCount = 1;
                            maxLine = tempLine;
                        }
                        tempLine = 0;

                    }

                }
                tempLine = 0;
            }

            if (maxLine == 1)
            {
                maxLinesCount = 0;
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        maxLinesCount += grid[i, j];
                    }
                }
            }


            Console.WriteLine(maxLine);
            Console.WriteLine(maxLinesCount);
        }
    }
}