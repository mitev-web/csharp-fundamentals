using System;

namespace TaskTwo
{
    class Task2
    {
        static void Main(string[] args)
        {
            string tmp = Console.ReadLine();
            double n = double.Parse(tmp);
            int max = tmp.Length;
            int flag = 0;
            int res = new int();
            int pos = tmp.IndexOf(".");
            if (tmp.IndexOf("-")==0)
            {
                max--;
                flag = -1;
            }
            if (pos == -1 &&  flag == 0)
            {
                char[] arr = tmp.ToCharArray();
                res = int.Parse(arr[0].ToString());
                for (int i = 1; i < tmp.Length; i++)
                {
                    res += int.Parse(arr[i].ToString());
                    if (res > 10)
                    {
                        res = res / 10 + res % 10;
                    }
                }
            }
            if (pos == -1 && flag == -1)
            {
                char[] arr = tmp.ToCharArray();
                res = int.Parse(arr[1].ToString());
                for (int i = 2; i < tmp.Length; i++)
                {
                    res += int.Parse(arr[i].ToString());
                    if (res > 10)
                    {
                        res = res / 10 + res % 10;
                    }
                }
            }
            if (pos != -1 && flag == 0)
            {
                char[] arr = tmp.ToCharArray();
                res = int.Parse(arr[0].ToString());
                for (int i = 1; i < pos; i++)
                {
                    res += int.Parse(arr[i].ToString());
                    if (res > 10)
                    {
                        res = res / 10 + res % 10;
                    }
                }
                for (int i = pos + 1; i < tmp.Length; i++)
                {
                    res += int.Parse(arr[i].ToString());
                    if (res > 10)
                    {
                        res = res / 10 + res % 10;
                    }
                }
            }
            if (pos != -1 && flag == -1)
            {
                char[] arr = tmp.ToCharArray();
                res = int.Parse(arr[1].ToString());
                for (int i = 2; i < pos; i++)
                {
                    res += int.Parse(arr[i].ToString());
                    if (res > 10)
                    {
                        res = res / 10 + res % 10;
                    }
                }
                for (int i = pos + 1; i < tmp.Length; i++)
                {
                    res += int.Parse(arr[i].ToString());
                    if (res > 10)
                    {
                        res = res / 10 + res % 10;
                    }
                }
            }
            Console.WriteLine(res);
        }
    }
}
