using System;

namespace TaskThree
{
    class Task3
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int red = 0;
            for (int j = 0; j < n/2 + 1; j++)
            {
                for (int i = 0; i < n; i++)
                {
                    if (i >= red && i < n - red)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
                red++;
            }
            red--;
            red--;
            for (int j = n / 2 + 1; j < n; j++)
            {
                for (int i = 0; i < n; i++)
                {
                    if (i >= red && i < n - red)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
                red--;
            }
            
        }
    }
}
