using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad5
{
    class Program
    {
        static void Main(string[] args)
        {
            int maxDamage = 0;
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            if (pX1 > pX2)
            {
                int buf = pX1;
                pX1 = pX2;
                pX2 = buf;
            }
            if (pY1<pY2)
            {
                int buf = pY1;
                pY1 = pY2;
                pY2 = buf;
            }
            if (fX + d >= pX1 && fX + d <= pX2 && fY <= pY1 && fY >=pY2)
            {
                maxDamage += 100;
            }
            if (fX + d >= pX1 && fX + d <= pX2 && fY + 1<= pY1 && fY + 1>= pY2)
            {
                maxDamage += 50;
            }
            if (fX + d >= pX1 && fX + d <= pX2 && fY - 1<= pY1 && fY - 1 >= pY2)
            {
                maxDamage += 50;
            }
            if (fX + d + 1 >= pX1 && fX + d + 1<= pX2 && fY <= pY1 && fY >= pY2)
            {
                maxDamage += 75;
            }
            Console.WriteLine("{0}%",maxDamage);
 
        }
    }
}
