using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test2
{
    class Program
    {
        static void Main(string[] args)
        {


            decimal N = decimal.Parse(Console.ReadLine());
            string S = Convert.ToString(N);
            int sum1 = 0;

            for (int i = 0; i < S.Length; i++)
            {
                char b = S[i];
                if (b != '-' && b != '+' && b != '.')
                {
                    int q = Convert.ToInt32(new string(b, 1));
                    sum1 += q;
                } 
            }
            

            while (sum1 > 9)
            {
                //int sum2 = 0;
                //int b = sum1;
                //while (b % 10 != 0)
                //{
                    
                //  int a = b % 10;
                //  sum2 += a;
                //  b = b / 10;
                  
                //}
                
                //sum1 = sum2;
                string c = Convert.ToString(sum1);
                int sum2 = 0;
                for (int i = 0; i < c.Length; i++)
                {
                    char b = c[i];
                    int q = Convert.ToInt32(new string(b, 1));
                    sum2 += q;
                }
                sum1 = sum2;
 
            }
            
                Console.WriteLine(sum1);
            }
        }
    }
