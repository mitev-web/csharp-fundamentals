using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TELERIKexamONE
{
    class FigterAttack
    {
        static void Main()
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int damage=0;
            int changer;
            if (px1 > px2)
            {
                changer = px1;
                px1 = px2;
                px2 = changer;
                changer = py1;
                py1 = py2;
                py2 = changer;
            }
            if (((fx + d) >= px1) && ((fx + d) <= px2) && (fy <= py1) && (fy >= py2))
            {
                if (((fx + d) >= (px2 - 1)) && (fy == py1)) damage = 225;
                if (((fx + d) >= (px2 - 1)) && (fy == py2)) damage = 225;
                if (((fx + d) >= (px2 - 1)) && (fy <= py1 - 1) && (fy >= py2 + 1)) damage = 250;
                if (((fx + d) == (px2)) && (fx == py1)) damage = 150;
                if (((fx + d) == (px2)) && (fx == py2)) damage = 150;
                if (((fx + d) == (px2)) && (fy <= py1 - 1) && (fy >= py2 + 1)) damage = 200;
            }
            else 
                if(((fx+d)==px1-1)&&(fy <= (py1 - 1)) && (fy >= (py2 + 1))) damage=75;
                else damage = 0;
            Console.WriteLine("{0}%",damage);
        }
    }
}
