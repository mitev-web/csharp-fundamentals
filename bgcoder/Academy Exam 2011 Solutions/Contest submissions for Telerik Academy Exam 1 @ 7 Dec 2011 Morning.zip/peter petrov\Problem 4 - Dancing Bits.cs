using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem4
{
    class Program
    {
        static void Main(string[] args)
        {
            int i1 = int.Parse(Console.ReadLine());
            
            int i3 = 0;
            string i4;
            
           
            for (int i2 = 0; i1>i2; i2++)
            

            {
                i3=int.Parse(Console.ReadLine());
                
                
            }
            i4 = Convert.ToString(i3, 2).PadLeft(4, '0');
            Console.WriteLine(i4);


        }
    }
}
