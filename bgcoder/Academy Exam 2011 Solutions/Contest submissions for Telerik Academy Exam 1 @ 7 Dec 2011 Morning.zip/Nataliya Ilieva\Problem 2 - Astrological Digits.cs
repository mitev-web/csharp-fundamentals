using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            int temp = new int();
            int sum = 0;
            n = Math.Abs(n);
            for (int i = 1; i <= 300; i++)
            {
                while (n != 0)
                {
                    temp = (int)(n % 10);
                    n = n / 10;
                    sum = sum + temp;
                     
                }
                if (sum <= 9)
                {
                    Console.WriteLine(sum);
                    break;
                }
                else
                {
                    n = sum;
                    sum = 0;
                }
            }
 
        }
    }
}