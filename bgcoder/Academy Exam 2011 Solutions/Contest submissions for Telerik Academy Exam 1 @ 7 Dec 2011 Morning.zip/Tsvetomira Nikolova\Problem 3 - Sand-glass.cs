using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            char[,] sandglass = new char[n, n];
            for (int i = 0; i < n; i++)

                for (int j = 0; j < n; j++)
                {
                    sandglass[i, j] = '.';


                    for (int k = n - 1; k >= 0; k--)
                        sandglass[k, n - k - 1] = '*';
                    if (i == j) sandglass[i, j] = '*';

                    Console.Write(sandglass[i, j]);
                    if (j == n - 1) Console.WriteLine(" ");


                  
                   

                }

        }
        }
    }