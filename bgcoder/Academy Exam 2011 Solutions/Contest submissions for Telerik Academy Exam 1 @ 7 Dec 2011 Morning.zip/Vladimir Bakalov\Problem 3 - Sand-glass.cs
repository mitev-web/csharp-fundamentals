using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Program
    {
        static string PrintDots(sbyte number)
        {
            string dots = new string('.', number);
            return dots;
        }
        static string PrintAsterisks(byte number)
        {
            string asterisks = new string('*', number);
            return asterisks;
        }
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            sbyte dots = -1;
            byte asterisks = (byte)(n + 2);
            for (byte i = 1; i <= n; i++)
            {
                if (i <= n / 2 + 1)
                {
                    asterisks -= 2;
                    dots += 1;
                    Console.WriteLine(PrintDots(dots) + PrintAsterisks(asterisks) + PrintDots(dots));
                    
                }
                else
                {
                    asterisks += 2;
                    dots -= 1;
                    Console.WriteLine(PrintDots(dots) + PrintAsterisks(asterisks) + PrintDots(dots));
                }
            }
        }
    }
}