using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            if (px1 > px2)
            {
                int temp = px2;
                px2 = px1;
                px1 = temp;
            }
            if (py1 < py2)
            {
                int temp = py2;
                py2 = py1;
                py1 = temp;
            }
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int shot=fx+d;
            int damage=0;
            if (shot >= px1 && shot <= px2 && fy <= py1 && fy >= py2)
            {
                damage += 100;
                if (fy + 1 <= py1)
                    damage += 50;
                if (shot + 1 <= px2)
                    damage += 75;
                if (fy - 1 >= py2)
                    damage += 50;
            }
            if (shot < px1 && fy <= py1 && fy >= py2)
            {
                if (shot + 1 >= px1)
                    damage += 75;
            }
            if (fy < py2 && shot >= px1 && shot <= px2)
            {
                if (fy + 1 >= py2)
                    damage += 50;
            }
            if (fy > py1 && shot >= px1 && shot <= px2)
            {
                if (fy - 1 >= py1)
                    damage += 50;
            }
            Console.WriteLine("{0}%",damage);

        }
    }
}