using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task2
{
    class Task2
    {
        static BigInteger SumDigits(BigInteger n, string input)
        {
            BigInteger result = 0;
            BigInteger length = input.Length;

            for (int i = 0; i < length; i++)
            {
                result = result + (n / (BigInteger)Math.Pow(10, i) % 10);
            }

            return result;
        }

        static void Main(string[] args)
        {
            string inputInit = Console.ReadLine();
            string inputNegative = inputInit.Replace('-', '0');
            string input = inputNegative.Replace('.', '0');
            
            BigInteger result;
            BigInteger.TryParse(input, out result); 

            while (result > 9)
            {
                result = SumDigits(result, input);
            }
            Console.WriteLine(result);
        }
    }
}
