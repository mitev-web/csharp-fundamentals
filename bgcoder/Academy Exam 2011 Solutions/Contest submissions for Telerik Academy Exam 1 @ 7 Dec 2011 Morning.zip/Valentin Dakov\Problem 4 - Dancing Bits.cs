using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int dance = 0;
            dance = int.Parse(Console.ReadLine());
            short n = 0;
            n = short.Parse(Console.ReadLine());
            int dancingNumbers;
            int theZeros = 0;
            int theOnes = 0;
            int result = 0;

            do
            {
                int counter = 0;
                dancingNumbers = int.Parse(Console.ReadLine());
                int temp = dancingNumbers;
                do
                {
                    dancingNumbers = dancingNumbers / 2;
                    counter++;
                } while (dancingNumbers > 0);
                int check;
                for (int i = counter - 1; i >= 0; i--)
                {
                    check = temp >> i;
                    if (check % 2 == 1)
                    {
                        theOnes++;
                        if (theZeros == dance)
                            result++;
                        theZeros = 0;
                    }
                    else
                    {
                        theZeros++;
                        if (theOnes == dance)
                            result++;
                        theOnes = 0;
                    }
                    if ( n == 1 && i == 0 && (theOnes ==dance || theZeros == dance))
                        result++;
                }
                n--;
            } while (n > 0);
            Console.WriteLine(result);
        }
    }
}
