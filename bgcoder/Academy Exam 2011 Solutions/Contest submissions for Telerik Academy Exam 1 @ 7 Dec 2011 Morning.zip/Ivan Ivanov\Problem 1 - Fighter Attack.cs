using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.FighterAttack
{
    class FighterAttack
    {
        static void Main(string[] args)
        {
            int fXcordP;
            int fYcordP;

            int sXcordP;
            int sYcordP;

            int xCordF;
            int yCordF;

            int dist;

            int sidePlantX;
            int sidePlantY;

            int CornerX;
            int CornerY;

            fXcordP = int.Parse(Console.ReadLine());
            fYcordP = int.Parse(Console.ReadLine());

            sXcordP = int.Parse(Console.ReadLine());
            sYcordP = int.Parse(Console.ReadLine());

            xCordF = int.Parse(Console.ReadLine());
            yCordF = int.Parse(Console.ReadLine());

            dist = int.Parse(Console.ReadLine());

            if (fXcordP > sXcordP)
            {
                sidePlantX = sXcordP - fXcordP;
                CornerX = sXcordP;
            }
            else
            {
                sidePlantX = fXcordP - sXcordP;
                CornerX = fXcordP;
            }


            if (fYcordP > sYcordP)
            {
                sidePlantY = sYcordP - fYcordP;
                CornerY = sYcordP;
            }
            else
            {
                sidePlantY = fYcordP - sYcordP;
                CornerY = fYcordP;
            }

            int resutDmg = 0;

            int exactHitX = xCordF+dist;
            int exactHitY = yCordF;

            if ((exactHitX >= CornerX && exactHitX <= (CornerX-sidePlantX)) && (exactHitY >= CornerY && exactHitY <= (CornerY - sidePlantY)))
            {
                resutDmg += 100;
            }

            if ((exactHitX >= CornerX && exactHitX <= (CornerX - sidePlantX)) && ((exactHitY +1) >= CornerY && (exactHitY+1) <= (CornerY - sidePlantY)))
            {
                resutDmg += 50;
            }

            if ((exactHitX >= CornerX && exactHitX <= (CornerX - sidePlantX)) && ((exactHitY-1) >= CornerY && (exactHitY-1) <= (CornerY - sidePlantY)))
            {
                resutDmg += 50;
            }



            if (((exactHitX+1) >= CornerX && (exactHitX+1) <= (CornerX - sidePlantX)) && (exactHitY >= CornerY && exactHitY <= (CornerY - sidePlantY)))
            {
                resutDmg += 75;
            }

            Console.WriteLine(resutDmg + "%");

        }
    }
}