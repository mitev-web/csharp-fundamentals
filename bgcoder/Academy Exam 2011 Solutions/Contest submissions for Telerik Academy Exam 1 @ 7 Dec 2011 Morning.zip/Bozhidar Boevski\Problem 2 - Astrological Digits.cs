
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

 

namespace ConsoleApplication2

{

    class Program

    {

        static void Main(string[] args)

        {

            decimal n;

            decimal num;

            long sum = 0;

            long temp;

            long number;

 

            string cInput = Console.ReadLine();

            n = Convert.ToDecimal(cInput);

 

            do

            {

                num = n - Convert.ToInt64(n);

                n *= 10;

            } while (num != 0);

 

            temp = Convert.ToInt64(n);

 

            do

            {

                number = temp % 10;

                sum += Math.Abs(number);

                temp /= 10;

            } while (temp != 0);

 

            if (sum >= 0 && sum <= 9)

            {

                Console.WriteLine(sum);

            }

            else if (sum > 9)

            {

                do

                {

                    sum -= 9;

                } while (sum > 9);

                Console.WriteLine(sum);

            }

        }

    }

}