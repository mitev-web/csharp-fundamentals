using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace fa
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int checkhit = fx + d;
             
            short damage = 0;
            if (((checkhit >= px1) && (checkhit <= px2)) && (fy >= py2) && (fy <= py1))
            {
                damage += 100;
                if ((fy-1) >= py2)
                {
                    damage += 50;
                    fy++;
                }
                if ((fy+1) <= py1)
                {
                    damage += 50;
                    fy--;
                }
                if ((checkhit+1) <= px2)
                {
                    damage += 75;
                    checkhit--;
                }
            }
            else
            {
 
                if ((fy-1) >= py2)
                {
                    damage += 50;
                    fy++;
                }
                if ((fy+1) <= py1)
                {
                    damage += 50;
                    fy--;
                }
                if ((checkhit+1) <= px2)
                {
                    damage += 75;
                    checkhit--;
                }
                 
            }
            Console.WriteLine(damage + "%");
        }
    }
}