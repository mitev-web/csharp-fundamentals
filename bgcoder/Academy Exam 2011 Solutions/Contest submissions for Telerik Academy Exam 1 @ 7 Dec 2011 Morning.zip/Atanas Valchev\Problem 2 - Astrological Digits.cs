using System;
using System.Linq;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace _02.AstrologicalNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            string input = Console.ReadLine();
            long N = 0; //double.Parse(Console.ReadLine());
            if (N < 0) { N = -N; }
            string number = input;
            int length = number.Length;
            long sum = 0;
            long counter = 10;

            while (counter > 9)
            {
                if (N < 0)
                {
                    Console.WriteLine(N);
                    break;
                }
                for (int i = 0; i < length; i++)
                {
                    char num = number[i];
                    if (num == '1')
                    {
                        sum = sum + 1;
                    }
                    if (num == '2')
                    {
                        sum = sum + 2;
                    }
                    if (num == '3')
                    {
                        sum = sum + 3;
                    }
                    if (num == '4')
                    {
                        sum = sum + 4;
                    }
                    if (num == '5')
                    {
                        sum = sum + 5;
                    }
                    if (num == '6')
                    {
                        sum = sum + 6;
                    }
                    if (num == '7')
                    {
                        sum = sum + 7;
                    }
                    if (num == '8')
                    {
                        sum = sum + 8;
                    }
                    if (num == '9')
                    {
                        sum = sum + 9;
                    }

                }
                if (sum > 9)
                {
                    N = sum;
                    number = Convert.ToString(N);
                    length = number.Length;
                    int i = 0;
                    counter = sum;
                    if (sum < 10)
                    { }
                    else
                    { sum = 0; }

                }
                else { break; }
                


            }
            Console.WriteLine(sum);
        }
    }
}








