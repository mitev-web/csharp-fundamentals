using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex1_FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
           
            string consoleInput = Console.ReadLine();
            int px1 = int.Parse(consoleInput);
            
            consoleInput = Console.ReadLine();
            int py1 = int.Parse(consoleInput);
           
            consoleInput = Console.ReadLine();
            int px2 = int.Parse(consoleInput);
            
            consoleInput = Console.ReadLine();
            int py2 = int.Parse(consoleInput);
         
            consoleInput = Console.ReadLine();
            int fx = int.Parse(consoleInput);
            
            consoleInput = Console.ReadLine();
            int fy = int.Parse(consoleInput);
          
            consoleInput = Console.ReadLine();
            int d = int.Parse(consoleInput);
            
        }
    }
}
