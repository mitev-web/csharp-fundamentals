using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem2AstrologicalDigits
{
    class AstrologicalDigits
    {
        static void Main(string[] args)
        {
            decimal number = decimal.Parse(Console.ReadLine());

            BigInteger astroNumber = CalculateAstrologicalNumber(number);
            Console.WriteLine(astroNumber);
        }

        private static BigInteger CalculateAstrologicalNumber(decimal number)
        {
            number = Math.Abs(number);

            while ((number - Math.Floor(number)) != 0)
            {
                number *= 10;
            }

            BigInteger n = (BigInteger)number;
            BigInteger result = CalculateAstrologicalNumberBigInteger(n);
            return result;
        }

        private static BigInteger CalculateAstrologicalNumberBigInteger(BigInteger number)
        {
            BigInteger result = 0;
            while (number != 0)
            {
                result += number % 10;
                number = number / 10;
            }

            number = result;

            if (number > 9)
            {
                return CalculateAstrologicalNumberBigInteger(number);
            }
            else
            {
                return number;
            }
        }
    }
}
