using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskOne.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            int damage = 0;

            if (fx + d <= px2 && fx + d >= px1 && fy <=py1 && fy >=py2)
            {
                if (px2 - px1 == 1)
                {
                    damage += 100;
                }
                else
                {
                    if (fx + d == px2)
                    {
                        damage += 100;
                    }
                    if (fx + d < px2)
                    {
                        damage += 175;
                    }
                }
            
            
                if (py1 - py2 >= 2)
                {
                    if (fy + 1 <= py1 && fy - 1 >= py2)
                    {
                        damage += 100;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
            }
            if (fy == py1 + 1 || fy == py2 - 1)
            {
                if (fx + d <= px2 && fx + d >= px1)
                {
                    damage += 50;
                }
            }
            if (fx + d == px1 - 1)
            {
                damage += 75;
            }
            Console.WriteLine(damage +"%");

        }
    }
}
