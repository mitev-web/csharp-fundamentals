using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem_2
{
    class AstrologicalDigits
    {
        static void Main(string[] args)
        {
            string n = Console.ReadLine();
            string sumString = getSumOfDigits(n);
            int sum = int.Parse(sumString);

            while (sum > 9)
            {
                sumString = getSumOfDigits(sumString);
                sum = int.Parse(sumString);
            }
            Console.WriteLine(sum);
        }

        private static string getSumOfDigits(string n)
        {
            int sum = 0;
            string numberInString = n;
            string number = "";
            int digit = 0;

            while (numberInString != "")
            {
                if (numberInString != "")
                {
                    number = numberInString.Substring(0, 1);
                }

                if (int.TryParse(number, out digit) && numberInString != "")
                {
                    sum += digit;
                }
                numberInString = numberInString.Remove(0, 1);
            }
            string sumString = Convert.ToString(sum);
            return sumString;
        }
    }
}