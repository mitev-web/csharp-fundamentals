using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Astrological_Digits
{
    class Program
    {
        static void Main(string[] args)
        {
            double N = double.Parse(Console.ReadLine());
            byte result;
            byte digit;
            int br_digit;
            int p1;
            
                
           
           p1 = ((int)N % 10);
           int p2 =(int) (N / 100) % 10;
           int p3 = (int)(N / 1000) % 10;
           int sum = p1 + p2 + p3;
           Console.WriteLine(sum);


            

        }
    }
}
