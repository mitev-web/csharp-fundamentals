using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Problem3
    {
        static void Main()
        {
            int glassHeight;
            glassHeight = int.Parse(Console.ReadLine());

            for (int i = 0; i < glassHeight/2 + 1; i++) //up glass
            {
                for (int j = 0; j < i; j++)
                {
                    Console.Write(".");
                }

                for (int j = 0; j < glassHeight - 2* i ; j++)
                {
                    Console.Write("*");
                }

                for (int j = 0; j < i; j++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }

            for (int i = 0; i < glassHeight/2; i++)//down glass
            {
                for (int j = 0; j < (glassHeight - 3 - 2*i)/2; j++)
                {
                    Console.Write(".");
                }

                for (int j = 0; j < 3 + 2*i ; j++)
                {
                    Console.Write("*");
                }

                for (int j = 0; j < (glassHeight - 3 - 2 * i) / 2; j++)
                {
                    Console.Write(".");
                }

                Console.WriteLine();
            }
        }
    }
}