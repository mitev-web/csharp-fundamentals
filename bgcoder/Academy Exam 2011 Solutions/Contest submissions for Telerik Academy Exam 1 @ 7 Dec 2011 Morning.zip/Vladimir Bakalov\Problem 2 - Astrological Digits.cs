using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem2
{
    class Program
    {

        static BigInteger SumDigits(decimal number)
        {
            if (number < 0)
                number *= -1;
            BigInteger sum = 0;
            if (number % 1 == 0)
            {
                BigInteger num = (BigInteger)number;
                for (BigInteger n = num; n > 0; sum += n % 10, n /= 10) ;
                return sum;
            }
            else
            {
                int intLength = (number % 1).ToString().Length - 2;
                number = (number * (decimal)(Math.Pow(10, intLength)));
                BigInteger num = (BigInteger)number;
                for (BigInteger n = num; n > 0; sum += n % 10, n /= 10) ;
                return sum;
            }
        }
        static void Main(string[] args)
        {
            decimal n = decimal.Parse(Console.ReadLine());
            while (Math.Abs(n) > 9)
                n = (decimal)SumDigits(n);
            Console.WriteLine(n);
        }
    }
}