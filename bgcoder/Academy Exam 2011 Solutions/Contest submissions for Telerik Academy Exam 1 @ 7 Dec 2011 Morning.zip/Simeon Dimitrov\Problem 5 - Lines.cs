using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5
{
    class Program
    {
        static void Main(string[] args)
        {
            int mask;
            int bit;
            int[,] lines = new int[8, 8];
            int[] colums = { 0, 0, 0, 0, 0, 0, 0, 0 };
            int[] result = { 0, 0, 0, 0, 0, 0, 0, 0 };
            int[] n = { 0, 0, 0, 0, 0, 0, 0, 0 };
            //  int oneInMask=1;
            int lineSize = 0;
            int lineSizeTmp =0;
            int lineSizeSum = 0;
            bool flag;
            int lineNumbers = 1;
            int lineSizeTemp = 0;
            for (int i = 0; i < 8; i++)
            {
                n[i] = byte.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    mask = 1 << j;
                    bit = (n[i] & mask) >> j;
                    if (bit == 1)
                    {
                        lines[i, j] = 1;
                        colums[j]++;
                    }
                    // Console.WriteLine(bit);
                }
                //Console.WriteLine("------");
            }
            for (int i = 0; i < 8; i++)
            {
                //lineSizeTemp = 0;

                for (int j = 7; j >= 0; j--)
                {
                    // Console.Write(lines[i,j]);
                    if (lines[i, j] == 1)
                    {
                        lineSizeTemp++;
                    }
                    else
                    {
                        if (lineSizeTemp == lineSize)
                        {
                            lineNumbers++;
                            lineSizeTemp = 0;
                        }
                        if (lineSizeTemp > lineSize)
                        {
                            lineSize = lineSizeTemp;
                            lineSizeTemp = 0;
                            lineNumbers = 1;
                        }
                        lineSizeTemp = 0;
                    }

                }
                if (lineSizeTemp == lineSize)
                {
                    lineNumbers++;
                    lineSizeTemp = 0;
                }
                if (lineSizeTemp > lineSize)
                {
                    lineSize = lineSizeTemp;
                    lineSizeTemp = 0;
                    lineNumbers = 1;
                }
                lineSizeTemp = 0;
                //Console.WriteLine(lineSizeTemp);
                //Console.WriteLine();
            }
            lineSizeSum = lineNumbers;
            lineSizeTmp = lineSize;

            lineNumbers = 0;
            for (int i = 0; i < 8; i++)
            {
                //lineSizeTemp = 0;

                for (int j = 0; j < 8; j++)
                {
                    //Console.Write(lines[i, j]);
                    if (lines[j, i] == 1)
                    {
                        lineSizeTemp++;
                    }
                    else
                    {
                        if (lineSizeTemp == lineSize)
                        {
                            lineNumbers++;
                            lineSizeTemp = 0;
                        }
                        if (lineSizeTemp > lineSize)
                        {
                            lineSize = lineSizeTemp;
                            lineSizeTemp = 0;
                            lineNumbers = 1;
                        }
                        lineSizeTemp = 0;
                    }

                }
                if (lineSizeTemp == lineSize)
                {
                    lineNumbers++;
                    lineSizeTemp = 0;
                }
                if (lineSizeTemp > lineSize)
                {
                    lineSize = lineSizeTemp;
                    lineSizeTemp = 0;
                    lineNumbers = 1;
                }
                lineSizeTemp = 0;
                //Console.WriteLine();
            }
            //Console.WriteLine(lineNumbers);
            if (lineSize == 145)
            {
                lineSize = 0;
            }
            if (lineSize > lineSizeTmp)
            {
                lineSizeSum = 0;
            }
            lineSizeSum = lineSizeSum + lineNumbers;
            Console.WriteLine(lineSize);
            //Console.WriteLine();
            Console.WriteLine(lineSizeSum);
        }
    }
}
