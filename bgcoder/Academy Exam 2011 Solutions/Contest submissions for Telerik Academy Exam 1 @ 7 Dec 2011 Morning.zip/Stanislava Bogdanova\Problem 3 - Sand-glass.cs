using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex._03.II
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Triangle6(n/2+1);
            Triangle5(n /2+1);
        }
        static void Triangle6(int n)
        {
            

                for (int i = n, star = n + n - 1; i > 0; i--, star -= 2)
                {
                    string strEmpty = new string('.', n - i);
                    string strStar = new string('*', star);
                    Console.WriteLine(strEmpty + strStar+strEmpty);
                }

            
        }



        static void Triangle5(int n)
        {
           
                for (int i = 1, star = 1; i <= n; i++, star += 2)
                {
                    if (star > 1)
                    {
                        string strEmpty = new string('.', n - i);
                        string strStar = new string('*', star);
                        Console.WriteLine(strEmpty + strStar+strEmpty);
                    }
                }

            
        }
    }
}
