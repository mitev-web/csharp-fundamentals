using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class Task4
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            string numbers = "";

            for (int i = 0; i < n; i++)
            {
                int temp = int.Parse(Console.ReadLine());
                string tempStr = Convert.ToString(temp, 2);

                numbers = numbers + tempStr;
            }

            int counter = 0;
            //Console.WriteLine(numbers);

            for (int index = 0; index < numbers.Length - k + 1; index++)
            {
                string temp = numbers.Substring(index, k);
                string temp0, tempK;
                if (index == 0)
                {
                    temp0 = "start";
                }
                else
                {
                    temp0 = numbers.Substring(index - 1, 1);
                }

                if (index == numbers.Length - k)
                {
                    tempK = "end";
                }
                else
                {
                    tempK = numbers.Substring(index + k, 1);
                }
                
                //Console.WriteLine(index + " -> " + " " + temp0 + " " + temp + " " + tempK);

                string check0 = new string('0', k);
                string check1 = new string('1', k);

                if (temp == check0 && temp0 != "0" && tempK != "0") 
                {                    
                    counter++;
                }
                else if (temp == check1 && temp0 != "1" && tempK != "1")
                {
                    counter++;
                }
            }
            
            Console.WriteLine(counter);
        }
    }
}
