using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort k = ushort.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            uint[] arr = new uint[n];
            ushort result = 0;
            Queue<byte> q = new Queue<byte>();

            for (int i = 0; i < n; i++)
            {
                arr[i] = uint.Parse(Console.ReadLine());
                uint y = 1;
                for (uint z = arr[i]; z >= 2; z /= 2)
                {
                    y *= 2;
                }
                for (uint z = y; z >= 1; z /= 2)
                {
                    if ((arr[i] & z) == z) q.Enqueue(1);
                    else q.Enqueue(0);
                }
            }
            ushort k0 = 0;
            ushort k1 = 0;

            foreach (byte b in q)
            {
                if (b == 1)
                {
                    if (k0 == k) result++;
                    k0 = 0;
                    k1++;
                }
                else
                {
                    if (k1 == k) result++;
                    k1 = 0;
                    k0++;
                }
            }
            if ((k1 == k) || (k0 == k)) result++;
            Console.WriteLine(result);
        }
    }
}