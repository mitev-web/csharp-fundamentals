using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.AstrologicalDigits
{
    class AstrologicalDigits
    {
        static void Main(string[] args)
        {
            int digit;
           

            int temResult = 0;


            
            digit = Console.Read();
            

            long result = 0;




            while (digit != 13)
            {

                if (digit != '-' && digit!= '.')
                {
                    result += (digit - 48);
                }
                digit = Console.Read();

            }

           

            if (result < 10)
            {
                Console.WriteLine(result);
            }
            else
            {
                do
                {
                    do
                    {
                        
                        digit = (byte)(result % 10);
                        result = result / 10;
                        temResult += digit;


                    } while (result > 0);
                    result = temResult;
                } while (result > 9);

                Console.WriteLine(result);
            }

           
            




        }
    }
}