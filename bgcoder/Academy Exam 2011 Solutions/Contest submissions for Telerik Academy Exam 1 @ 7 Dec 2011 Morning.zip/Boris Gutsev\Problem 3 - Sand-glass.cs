using System;
using System.Linq;

namespace Problem3_SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            int n = int.Parse(Console.ReadLine());
            int countRowDown = 0;
            for (; (n - countRowDown*2)>=0; countRowDown++)
            {
                for (int countbegin = 0; countbegin < countRowDown; countbegin++)
                {
                    Console.Write(".");   
                }
                for (int countAsterisk = 0; countAsterisk < (n-countRowDown*2); countAsterisk++)
                {
                    Console.Write("*");
                }
                for (int countEnd = 0; countEnd < countRowDown; countEnd++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
            countRowDown--;
            countRowDown--;
            for (; countRowDown>=0; countRowDown--)
            {
                for (int countbegin = 0; countbegin < countRowDown; countbegin++)
                {
                    Console.Write(".");   
                }
                for (int countAsterisk = 0; countAsterisk < (n - countRowDown * 2); countAsterisk++)
                {
                    Console.Write("*");
                }
                for (int countEnd = 0; countEnd < countRowDown; countEnd++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
               
            }
        }
    }
}
