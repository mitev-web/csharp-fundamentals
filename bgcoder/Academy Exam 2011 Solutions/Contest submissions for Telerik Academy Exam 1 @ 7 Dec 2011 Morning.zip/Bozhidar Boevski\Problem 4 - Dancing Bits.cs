using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            int k, n;
            ulong number;
            ulong temp;
            int[] array;
            string str1 = "";
            int count1 = 0;
            int count0 = 0;
            int result = 0;

            string cInput = Console.ReadLine();
            k = Convert.ToInt32(cInput);

            cInput = Console.ReadLine();
            n = Convert.ToInt32(cInput);
            array = new int[n];

            for (int i = 0; i < n; i++)
            {
                cInput = Console.ReadLine();
                array[i] = Convert.ToInt32(cInput);
            }
            for (int i = n - 1; i >= 0; i--)
            {
                temp = Convert.ToUInt64(array[i]);
                do
                {
                    number = temp % 2;
                    str1 += Convert.ToString(number);
                    temp /= 2;
                } while(temp > 0);
            }
            number = Convert.ToUInt64(str1);
            do
            {
                temp = number & 1;
                if (temp == 1)
                {
                    count1++;
                    if (count1 == k)
                    {
                        result++;
                    }
                }
                else
                {
                    count0++;
                    if (count0 == k)
                    {
                        result++;
                    }
                }
                number = number >> 1;
            } while (number > 0);
            Console.WriteLine(result);
        }
    }
}
