using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine(" ");
            string topDots = ".";
            for (int i = 1; i <= n/2; i++)
            {
                Console.Write(topDots);
                for (int j = i+2; j <= n-i+1 ;j++)
                {
                    Console.Write("*");
                }
                Console.Write(topDots);
                topDots = topDots + ".";
                Console.WriteLine(" ");
            }
            int dotsCounter = n / 2 - 1;
            for (int i = n/2-1; i >= 1; i--)
            {
               string bottomDots = topDots.Remove(dotsCounter);
                Console.Write(bottomDots);
                for (int j = n-i ;j >= i+1 ; j--)
                {
                    Console.Write("*");

                }
                Console.Write(bottomDots);
                dotsCounter--;
                Console.WriteLine(" ");
            }
            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine(" ");
                      
        }
    }
}
