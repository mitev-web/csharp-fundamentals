using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex._04.IIII
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            string binValue;
            int number;
            List<int> myList = new List<int>();


            for (int i = 0; i < n; i++)
            {
                number = int.Parse(Console.ReadLine());
                binValue = Convert.ToString(number, 2);
                int cur = int.Parse(binValue);

            }
            int[] myArr = myList.ToArray();


        }
        static void PrintSubset(int n, int[] myArr)
        {
            List<List<int>> searchedSubsets = new List<List<int>>();

            for (int i = 1; i < Math.Pow(2, n); i++)
            {
                List<int> subset = new List<int>();

                for (int k = 0; k < n; k++)
                {
                    if (((i >> k) & 1) == 1)
                    {
                        subset.Add(myArr[k]);
                    }
                }

                searchedSubsets.Add(subset);
            }
        }
    }
}
