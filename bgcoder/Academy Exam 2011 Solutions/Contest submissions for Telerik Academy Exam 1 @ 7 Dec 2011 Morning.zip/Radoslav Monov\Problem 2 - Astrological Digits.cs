using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex2_AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
         
            string consoleInput = Console.ReadLine();
            decimal n=decimal.Parse(consoleInput);
          
            int sumOfDigits=0;
            do
            {
                sumOfDigits = 0;
                for (int i = 0; i < consoleInput.Length; i++)
                {
                    if ((consoleInput[i] != '.') && (consoleInput[i] != '-')&&(consoleInput[i]!='0'))
                    {
                        sumOfDigits += Convert.ToInt32(consoleInput[i] - 48);
                    }
                }
                n = sumOfDigits;
                consoleInput = Convert.ToString(n);

            }
            while (n >9); 
            Console.WriteLine(sumOfDigits);
            
            
        }
    }
}
