using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sand_glass
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());

            for (int i = n; i > 0; i -= 2)
            {
                for (int y = (n - i) / 2; y > 0; y--)
                {
                    Console.Write(".");
                }
                for (int y = i; y > 0; y--)
                {
                    Console.Write("*");
                }
                for (int y = (n - i) / 2; y > 0; y--)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
            for (int i = 3;i <= n; i += 2)
            {
                for (int y = (n - i) / 2; y > 0; y--)
                {
                    Console.Write(".");
                }
                for (int y = i; y > 0; y--)
                {
                    Console.Write("*");
                }
                for (int y = (n - i) / 2; y > 0; y--)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
        }
    }
}
