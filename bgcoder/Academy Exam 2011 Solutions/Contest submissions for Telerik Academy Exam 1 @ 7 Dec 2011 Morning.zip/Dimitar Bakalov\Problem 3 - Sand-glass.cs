using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());

            string blank = "";

            for (int i = 0; i < size; i++)
                blank += '.';

            for (int i = 0; i <= size; i++)
            {
                int m,n;
                char[] line = blank.ToCharArray();

                if (i < size - i)
                {
                    m = i;
                    n = size - i;
                }
                else
                {
                    m = size - i;
                    n = i;
                }

                if (i == size - i - 1)
                    continue;
                
                for ( int k = m; k < n; k++)
                    line[k] = '*';

                Console.WriteLine(line);
            }
        }
    }
}
