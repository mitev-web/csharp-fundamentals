using System;
using System.Collections.Generic;

namespace _1.FighterAttack
{
    class FighterAttack
    {
        static bool isItHit(int hitX, int hitY, int px1, int px2, int py1, int py2)
        {
            if (hitX >= Math.Min(px1, px2) && hitX <= Math.Max(px1, px2) &&
                hitY >= Math.Min(py1, py2) && hitY <= Math.Max(py1, py2))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            ushort allDamage = 0;
            int[] centralDamage = new int[] { fx + d, fy };
            int[] leftDamage = new int[] { fx + d, fy + 1 };
            int[] rightDamage = new int[] { fx + d, fy - 1 };
            int[] frontDamage = new int[] { fx + d + 1, fy };
            if (isItHit(centralDamage[0],centralDamage[1],px1,px2,py1,py2))
            {
                allDamage += 100;
            }
            if (isItHit(leftDamage[0], leftDamage[1], px1, px2, py1, py2))
            {
                allDamage += 50;
            }
            if (isItHit(rightDamage[0], rightDamage[1], px1, px2, py1, py2))
            {
                allDamage += 50;
            }
            if (isItHit(frontDamage[0], frontDamage[1], px1, px2, py1, py2))
            {
                allDamage += 75;
            }
            Console.WriteLine("{0}%",allDamage);
        }
    }
}
