using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem5Lines
{
    class Lines
    {
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }

            int[] lengths = new int[9];

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    int length = 0;
                    while (j < 8 && PthBit(numbers[i], j) == 1)
                    {
                        j++;
                        length++;
                    }
                    if (length != 0)
                    {
                        lengths[length]++;
                    }
                }
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    int length = 0;
                    while (j < 8 && PthBit(numbers[j], i) == 1)
                    {
                        j++;
                        length++;
                    }
                    if (length != 0)
                    {
                        lengths[length]++;
                    }
                }
            }

            int longestLine = 0;
            int count = 0;
            for (int i = 8; i >= 0; i--)
            {
                if (lengths[i] != 0)
                {
                    longestLine = i;
                    count = lengths[i];
                    break;
                }
            }

            if (longestLine == 1)
            {
                count = count / 2;
            }

            Console.WriteLine(longestLine);
            Console.WriteLine(count);
        }

        private static int PthBit(byte number, int position)
        {
            int pthBit = (number >> position) & 1;
            return pthBit;
        }
    }
}
