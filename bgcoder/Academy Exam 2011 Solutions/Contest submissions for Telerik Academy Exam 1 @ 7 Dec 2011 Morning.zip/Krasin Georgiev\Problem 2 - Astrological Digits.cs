using System;

class AstrologicalDigits
{
    static void Main()
    {
        //double n = 1234567.891;
        double n = double.Parse(Console.ReadLine());
        //double n = double.Parse(Console.ReadLine());
        n = Math.Abs(n);
        decimal nDecimal;

        if ((n < 1) && (n > 0))
        {
            while (n < 1)
            {
                n *= 10;
            }
            nDecimal = (decimal)n;
            nDecimal = nDecimal * (decimal)1e15;

        }
        else if (n > 1)
        {
            while (n > 1)
            {
                n /= 10;
            }
            nDecimal = (decimal)n;
            nDecimal = nDecimal * (decimal)1e16;
        }
        else
            nDecimal = (decimal)n;

        long nLong = (long)nDecimal;
        nLong = Math.Abs(nLong);

        long sum = 0;

        while (nLong > 10)
        {
            sum = 0;
            do
            {
                sum += nLong % 10;
                nLong /= 10;
            }
            while (nLong != 0);
            nLong = sum;            
        }

        if (nLong != 10)
        {
            Console.WriteLine(nLong);
        }
        else
        {
            Console.WriteLine(1);
        }
    }
}
