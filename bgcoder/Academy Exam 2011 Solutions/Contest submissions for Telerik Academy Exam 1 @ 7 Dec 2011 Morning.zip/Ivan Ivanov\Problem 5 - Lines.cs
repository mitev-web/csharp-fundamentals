using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.MatrixLenght
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[,] matrix = new byte[8, 8];

            byte[] nums = new byte[8];

            //byte[] nums = { 246,247,248,249,250,251,252,253};

            byte maxSum = 0;
            byte maxSumFinal = 0;
            byte countSum = 0;


            //Fill numbers
            for (int i = 0; i < 8; i++)
            {
                nums[i] = byte.Parse(Console.ReadLine());
            }

          


            //Fill matrix
            //Every row is bits of one byte number [0-255]
            for (int i = 0; i < 8; i++)
            {
                for (int k = 0; k < 8; k++)
                {

                    if ((nums[i] & (1 << k)) != 0)
                    {
                        matrix[i, k] = 1;
                    }
                }
            }

          


            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {

                    if (matrix[i, j] == 1)
                    {
                        maxSum++;
                    }
                    else
                    {
                        maxSum = 0;
                    }

                    if (maxSum > maxSumFinal)
                    {
                        countSum = 0;
                        maxSumFinal = maxSum;
                        countSum++;
                    }
                    else if (maxSum == maxSumFinal)
                    {
                        countSum++;
                    }
                    
                        
                }
                maxSum = 0;
            }


            //for (int i = 0; i < 8; i++)
            //{
            //    for (int k = 0; k < 8; k++)
            //    {

            //        if ((nums[i] & (1 << k)) != 0)
            //        {
            //            matrix[i, k] = 1;
            //        }
            //    }
            //}


            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {

                    if (matrix[j, i] == 1)
                    {
                        maxSum++;
                    }
                    else
                    {
                        maxSum = 0;
                    }

                    if (maxSum > maxSumFinal)
                    {
                        countSum = 0;
                        maxSumFinal = maxSum;
                        countSum++;
     
                    }
                    else if (maxSum == maxSumFinal)
                    {
                        //if (maxSumFinal == 0)
                        //{
                        //    continue;
                        //}
                        if(!(maxSumFinal==1))
                        {
                            countSum++;
                        }
                    }


                }
                maxSum = 0;
            }
            
            Console.WriteLine(maxSumFinal);
            Console.WriteLine(countSum);
        }
    }
}