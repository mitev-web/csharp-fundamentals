using System;
using System.Linq;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1, px2, py1, py2;
            int fx, fy, d;
            int rocketPX, rocketPY;
            int totalDamage = 0;
            string cInput = Console.ReadLine();
            px1 = Convert.ToInt32(cInput);
            cInput = Console.ReadLine();
            py1 = Convert.ToInt32(cInput);
            cInput = Console.ReadLine();
            px2 = Convert.ToInt32(cInput);
            cInput = Console.ReadLine();
            py2 = Convert.ToInt32(cInput);
            cInput = Console.ReadLine();
            fx = Convert.ToInt32(cInput);
            cInput = Console.ReadLine();
            fy = Convert.ToInt32(cInput);
            cInput = Console.ReadLine();
            d = Convert.ToInt32(cInput);
            rocketPX = fx + d;
            rocketPY = fy;
            if (rocketPX > px1 && rocketPX < px2 && rocketPY > py1 && rocketPY < py2)
            {
                totalDamage = 275;
            }
            else if (rocketPX == px1 && rocketPY > py1 && rocketPY < py2)
            {
                totalDamage = 275;
            }
            else if (rocketPX == px1 && (rocketPY == py1 || rocketPY == py2))
            {
                totalDamage = 225;
            }
            else if (rocketPX == px2 && (rocketPY > py1 && rocketPY < py2))
            {
                totalDamage = 200;
            }
            else if (rocketPX == px2 && (rocketPY == py1 || rocketPY == py2))
            {
                totalDamage = 150;
            }
            else if (rocketPY == py1 && (rocketPX > px1 && rocketPX < px2))
            {
                totalDamage = 225;
            }
            else if (rocketPY == py2 && (rocketPX > px1 && rocketPX < px2))
            {
                totalDamage = 225;
            }
            else if (rocketPX == px1 - 1)
            {
                totalDamage = 75;
            }
            else if (rocketPY == py1 - 1 || rocketPY == py2 + 1)
            {
                totalDamage = 50;
            }
            else if (rocketPX > px2 || rocketPX < px1 || rocketPY > py2 || rocketPY < py1)
            {
                totalDamage = 0;
            }
            Console.WriteLine("{0}%", totalDamage);
        }
    }
}