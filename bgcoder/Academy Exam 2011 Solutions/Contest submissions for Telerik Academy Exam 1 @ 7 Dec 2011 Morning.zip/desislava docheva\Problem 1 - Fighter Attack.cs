using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace exam1
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int hitpointx;
            int hitpointy=fy;
            hitpointx = d - fx;
             if(hitpointx>px1 && hitpointx<px2 && hitpointy>py1 && hitpointy<py2)
            {
                Console.WriteLine("225%");
            }
        }
    }
}