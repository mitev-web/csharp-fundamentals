using System;
using System.Linq;


namespace Problem1_FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            int pX1 = int.Parse(Console.ReadLine());
            int pY1 = int.Parse(Console.ReadLine());
            int pX2 = int.Parse(Console.ReadLine());
            int pY2 = int.Parse(Console.ReadLine());
            if (pX1>pX2)
            {
                pX1 = pX1 + pX2;
                pX2 = pX1 - pX2;
                pX1 = pX1 - pX2;
            }
            if (pY1<pY2)
            {
                pY1 = pY1 + pY2;
                pY2 = pY1 - pY2;
                pY1 = pY1 - pY2;
            }
            int fX = int.Parse(Console.ReadLine()); 
            int fY = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int result = 0;
            if (fY>=pY2 && fY<= pY1)
            {
                if (fX+d >= pX1 && fX <= pX2)
                {
                    result = 100;
                    if (fX+d<=pX2-1)
                    {
                        result += 75;
                    }
                    if (fY+1<=pY1)
                    {
                        result += 50;
                    }
                    if (fY-1 >= pY2)
                    {
                        result += 50;
                    }
                }
                else if (fX+d == pX1-1)
                {
                    result = 75;
                }
                else
                {
                    result = 0;
                }
            }
            else if (fY==pY1+1 || fY == pY2-1)
	        {
                if (fX >= pX1 && fY <= pX2)
                {
                    result = 50;
                }
	        }
            else
            {
                result = 0;
            }
            Console.WriteLine("{0}%",result);

        }
    }
}
