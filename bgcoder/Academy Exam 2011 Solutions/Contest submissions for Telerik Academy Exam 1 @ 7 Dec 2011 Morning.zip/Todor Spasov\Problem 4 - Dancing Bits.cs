using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{

    class Program
    {
        static void Main()
        {
            int k = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());

            int dancer = 0;
            for (int i = 0; i < n; i++)
            {
                dancer |= Convert.ToInt32(Console.ReadLine());
            }

            int counter = 0;


            for ( int a = 0; a < 32; a ++)
            {

                int tempCounter1 = 0;
                int tempCounter0 = 0;


                for (int b = 0; b < k ; b++)
                {
                    if ((dancer >> (a + b) & 1) == 1) tempCounter1++;
                    else break;
                 
                }

                if (tempCounter1 == k)
                {
                    counter++;

                }

                for (int b = 0; b < k ; b++)
                {
                    if ((dancer >> (a + b) & 1) == 0) tempCounter0++;
                    else break;

                }

                if (tempCounter0 == k)
                {
                    counter++;

                }






            }

            Console.WriteLine(counter);
        }
    }
}
