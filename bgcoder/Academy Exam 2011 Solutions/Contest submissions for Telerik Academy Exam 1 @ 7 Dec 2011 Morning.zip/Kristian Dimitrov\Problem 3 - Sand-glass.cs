using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03SandGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n - (n / 2); i++)
            {
                int p = n;
                        for (int k = 0; k < i; k++)
                        {
                            Console.Write(".");
                        }
                        for (int l = 0; l < p-i*2; l++)
                        {
                            Console.Write("*");
                        }
                        for (int m = 0; m < i; m++)
                        {
                            Console.Write(".");
                        }
                    
                Console.WriteLine();
                
            }
            for (int i = n - (n / 2)-2; i >=0; i--)
            {
                int p = n;
                        for (int k = 0; k < i; k++)
                        {
                            Console.Write(".");
                        }
                        for (int l = 0; l < p-i*2; l++)
                        {
                            Console.Write("*");
                        }
                        for (int m = 0; m < i; m++)
                        {
                            Console.Write(".");
                        }
                    
                Console.WriteLine();
                
            }
            
        }
    }
}