using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
 
namespace _04.DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int K = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
 
            string input;
            
 
            int onecounter = 0;
            int zerocounter = 0;
 
 
            int result = 0;
             
            int numb;
 
            string number = "";
            for (int i = 0; i < N; i++)
            {
                input = Console.ReadLine();
                numb = int.Parse(input);
                number = number + Convert.ToString(numb, 2);
 
 
            }
            int length = number.Length;
            for (int i = 0; i < length; i++)
            {
                char num = number[i];
                if (num == '1')
                {
                    onecounter++;
                    zerocounter = 0;
                }
                else
                {
                    zerocounter++;
                    onecounter = 0;
 
                }
                if (onecounter == K)
                {
                    if (i + 1 > length - 1)
                    { goto Finish; }
                    if (num != number[i + 1])
                    { result++; }
 
                    onecounter = 0;
                }
                if (zerocounter == K)
                {
                    if (i + 1 > length - 1)
                    { goto Finish; }
                    if (num != number[i + 1])
                    { result++; }
                    zerocounter = 0;
                }
 
                if (onecounter > 0 && zerocounter > 0)
                {
                    zerocounter = 0;
                    onecounter = 0;
 
                }
            }
        Finish:
            Console.WriteLine(result);
        }
    }
}
