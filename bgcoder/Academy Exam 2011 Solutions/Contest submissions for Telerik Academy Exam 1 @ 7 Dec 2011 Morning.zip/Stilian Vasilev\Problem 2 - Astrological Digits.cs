using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            ushort answer = 0;

            foreach (char c in str)
            {
                if((((int) c) >= ((int) '1')) && (((int) c) <= ((int) '9')))
                {
                    answer += ushort.Parse(c.ToString());
                }
            }
            while (answer > 9)
            {
                byte digit = 0;
                ushort x = answer;
                ushort y = answer;
                while (x / 10 > 0)
                {
                    digit++;
                    x /= 10;
                }
                answer = 0;
                for (byte i = 0; i <= digit; i++)
                {
                    answer += (ushort)(y % 10);
                    y /= 10;
                }
            }
            Console.WriteLine(answer);
        }
    }
}
