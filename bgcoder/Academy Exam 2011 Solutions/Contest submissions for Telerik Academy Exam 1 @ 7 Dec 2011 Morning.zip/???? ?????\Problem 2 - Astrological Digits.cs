using System;
using System.Text.RegularExpressions;
using System.Numerics;

namespace AstrologicalDigits
{
    class AstrologicalDigits
    {
        static void Main(string[] args)
        {
            BigInteger n;
            BigInteger.TryParse(Console.ReadLine(), out n);
            n = BigInteger.Abs(n);
            string NumInString = n.ToString();
            string newString = Regex.Replace(NumInString, "[^.0-9]", "");
            BigInteger mynumber = BigInteger.Parse(newString);

            first:
            BigInteger sum = 0;
            while (mynumber != 0)
            {
                sum += mynumber % 10;
                mynumber /= 10;
            }
            mynumber = sum;
            if (sum > 9)
            {
                goto first;
            }
            Console.WriteLine(sum);
        }
    }
}