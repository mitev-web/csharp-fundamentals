using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5_Lines
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] n=new byte[8];
            n[0] = byte.Parse(Console.ReadLine());
            n[1] = byte.Parse(Console.ReadLine());
            n[2] = byte.Parse(Console.ReadLine());
            n[3] = byte.Parse(Console.ReadLine());
            n[4] = byte.Parse(Console.ReadLine());
            n[5] = byte.Parse(Console.ReadLine());
            n[6] = byte.Parse(Console.ReadLine());
            n[7] = byte.Parse(Console.ReadLine());

            byte[] lineOnCol = new byte[8];
            byte longestLineLength = 0, longestLineCount = 0;
            byte[] linesWithLength = new byte[9];
            for (int numberIndex = 0; numberIndex < 8; numberIndex++)
            {
               // Console.WriteLine(  );
                byte colIndex = 0;
                byte lineOnRowLength = 0;
                byte numberToShift = n[numberIndex];
                while (colIndex<8)
                {
                    int bit = numberToShift & 1;
                    numberToShift >>= 1;
             //       Console.Write(bit);
                    if (bit == 1)
                    {
                        lineOnRowLength++;
                        lineOnCol[colIndex]++;
                    }
                    else//bit is 0; reset counters and check length
                    {
                        if (lineOnCol[colIndex] > 1)
                        {
                            linesWithLength[lineOnCol[colIndex]]++;
                        }
                        linesWithLength[lineOnRowLength]++;
                        lineOnRowLength = 0;
                        lineOnCol[colIndex] = 0;
                    }
                    colIndex++;
                }
                linesWithLength[lineOnRowLength]++;
            }
            for (int colIndexToFinish = 0; colIndexToFinish < 8; colIndexToFinish++)
            {
                if (lineOnCol[colIndexToFinish] > 1)
                {
                    linesWithLength[lineOnCol[colIndexToFinish]]++;
                }
            }
            //Console.WriteLine(  );
            for (int findLongest = 8; findLongest > 0; findLongest--)
            {
                if (linesWithLength[findLongest] > 0)
                {
                    Console.WriteLine("{0}\n{1}", findLongest, linesWithLength[findLongest]);
                    break;
                }
            }
        }
    }
}
