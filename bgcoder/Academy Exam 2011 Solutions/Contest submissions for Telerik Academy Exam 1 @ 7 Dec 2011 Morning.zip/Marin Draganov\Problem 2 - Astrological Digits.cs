using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            BigInteger number = 0;
            BigInteger sum = 0;
            bool digits = true;


            while (digits)
            {
                char digit = Convert.ToChar(Console.Read());
                i = (int)digit;
                switch (i)
                {
                    case 48:
                    case 49:
                    case 50:
                    case 51:
                    case 52:
                    case 53:
                    case 54:
                    case 55:
                    case 56:
                    case 57: sum = sum + i - 48; break;
                    case 45: sum = sum; break;
                    case 46: sum = sum; break;
                    default: digits = false; break;

                }
                
            }

            number = sum;

            while (number > 9)
            {
                sum = 0;
                while (number > 0)
                {
                    sum = sum + (number % 10);
                    number = number / 10;
                }
                number = sum;
            }

            


            Console.WriteLine(sum);
        }
    }
}