using System;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal N = decimal.Parse(Console.ReadLine());
            if (N<0)
            {
                N = -N;
            }
            ulong result = 0;
            int counter = 0;
            ulong check = result;
            for (decimal i = 10; counter<28; i*=10)
            {
                result += (ulong)((N % i) / (i / 10));
                counter++;
                if (result==check)
                {
                    if (result <= 9)
                    {
                        Console.WriteLine(result);
                        break;
                    }
                    else
                    {
                        i = 1;
                        counter = 0;
                        N = result;
                        result = 0;
                    }
                }
                check = result;



            }
            
        }
    }
}
