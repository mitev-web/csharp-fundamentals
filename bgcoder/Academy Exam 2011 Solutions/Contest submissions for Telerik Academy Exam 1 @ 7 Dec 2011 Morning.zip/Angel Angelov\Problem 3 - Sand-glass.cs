using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int p1 = 0;
            int p2 = n + 1;

            for (int i = 0; i < n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    if (p1 >= j )
                    {
                        Console.Write(".");
                    }
                    else if (p2 <= j)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                    
                }
                Console.WriteLine();
                if (i < n/2)
                {
                    p1++;
                    p2--;

                }
                else
	            {
                    p1--;
                    p2++;
	            }
	
                
            }
        }
    }
}
