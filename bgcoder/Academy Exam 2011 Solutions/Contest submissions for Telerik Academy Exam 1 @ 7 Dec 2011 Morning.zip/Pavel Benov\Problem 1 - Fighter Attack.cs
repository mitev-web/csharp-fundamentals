using System;

namespace zad1Fighter
{
    class Program
    {
        static void Main(string[] args)
        {
            int pX = int.Parse(Console.ReadLine());
            int pY = int.Parse(Console.ReadLine());
            int pXX = int.Parse(Console.ReadLine());
            int pYY = int.Parse(Console.ReadLine());
            int fX = int.Parse(Console.ReadLine());
            int fY = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            double missileX = fX + d;
            double missileY = fY;
            short dmgSum = 0;       
            if ((pX < pXX) && (pY > pYY))
            {                
                if ((missileX >= pX) && (missileX <= pXX) && (missileY <= pY) && (missileY >= pYY))
                {
                    dmgSum += 100;
                }
                if ((missileX >= pX) && (missileX <= pXX) && ((missileY + 1) <= pY) && ((missileY + 1) >= pYY))
                {
                    dmgSum += 50;
                }
                if ((missileX >= pX) && (missileX <= pXX) && ((missileY - 1) <= pY) && ((missileY - 1) >= pYY))
                {
                    dmgSum += 50;
                }
                if (((missileX + 1) >= pX) && ((missileX + 1) <= pXX) && (missileY <= pY) && (missileY >= pYY))
                {
                    dmgSum += 75;
                }
            }
            else if ((pX > pXX) && (pY > pYY))
            {                
                if ((missileX <= pX) && (missileX >= pXX) && (missileY <= pY) && (missileY >= pYY))
                {
                    dmgSum += 100;
                }
                if ((missileX <= pX) && (missileX >= pXX) && ((missileY + 1) <= pY) && ((missileY + 1) >= pYY))
                {
                    dmgSum += 50;
                }
                if ((missileX <= pX) && (missileX >= pXX) && ((missileY - 1) <= pY) && ((missileY - 1) >= pYY))
                {
                    dmgSum += 50;
                }
                if (((missileX + 1) <= pX) && ((missileX + 1) >= pXX) && (missileY <= pY) && (missileY >= pYY))
                {
                    dmgSum += 75;
                }
            }
            else if ((pX < pXX) && (pY < pYY))
            {
                if ((missileX >= pX) && (missileX <= pXX) && (missileY >= pY) && (missileY <= pYY))
                {
                    dmgSum += 100;
                }
                if ((missileX >= pX) && (missileX <= pXX) && ((missileY + 1) >= pY) && ((missileY + 1) <= pYY))
                {
                    dmgSum += 50;
                }
                if ((missileX >= pX) && (missileX <= pXX) && ((missileY - 1) >= pY) && ((missileY - 1) <= pYY))
                {
                    dmgSum += 50;
                }
                if (((missileX + 1) >= pX) && ((missileX + 1) <= pXX) && (missileY >= pY) && (missileY <= pYY))
                {
                    dmgSum += 75;
                } 
            }            
            else if ((pX > pXX) && (pY < pYY))
            {
                if ((missileX <= pX) && (missileX >= pXX) && (missileY >= pY) && (missileY <= pYY))
                {
                    dmgSum += 100;
                }
                if ((missileX <= pX) && (missileX >= pXX) && ((missileY + 1) >= pY) && ((missileY + 1) <= pYY))
                {
                    dmgSum += 50;
                }
                if ((missileX <= pX) && (missileX >= pXX) && ((missileY - 1) >= pY) && ((missileY - 1) <= pYY))
                {
                    dmgSum += 50;
                }
                if (((missileX + 1) <= pX) && ((missileX + 1) >= pXX) && (missileY >= pY) && (missileY <= pYY))
                {
                    dmgSum += 75;
                }
            }
            Console.WriteLine(dmgSum + "%");
        }
    }
}
