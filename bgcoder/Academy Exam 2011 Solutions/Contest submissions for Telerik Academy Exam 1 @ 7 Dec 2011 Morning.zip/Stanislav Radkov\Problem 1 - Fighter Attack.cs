using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task01
{
    class Program
    {
        private static Int32 Px1, Py1, Px2, Py2, Fx, Fy, D;
        static void Main(string[] args)
        {
            int dmg = 0;

            Px1 = Int32.Parse(Console.ReadLine());
            Py1 = Int32.Parse(Console.ReadLine());
            Px2 = Int32.Parse(Console.ReadLine());
            Py2 = Int32.Parse(Console.ReadLine());
            Fx = Int32.Parse(Console.ReadLine());
            Fy = Int32.Parse(Console.ReadLine());
            D = Int32.Parse(Console.ReadLine());

            Int32 topLeftX, topLeftY, downRightX, downRightY;
            topLeftX = (Px1 < Px2) ? Px1 : Px2;
            topLeftY = (Py1 > Py2) ? Py1 : Py2;
            downRightX = (Px1 > Px2) ? Px1 : Px2;
            downRightY = (Py1 < Py2) ? Py1 : Py2;

            Px1 = topLeftX;
            Py1 = topLeftY;

            Px2 = downRightX;
            Py2 = downRightY;

            if (IsThere100pDamage())
                dmg += 100;
            if (IsThere75pDamage())
                dmg += 75;
            if (IsThere50pDamageOver())
                dmg += 50;
            if (IsThere50pDamageUnder())
                dmg += 50;

            Console.WriteLine("{0}%", dmg.ToString());

        }

        static bool IsThere100pDamage()
        {
            int strikeZoneX = Fx + D;
            int strikeZoneY = Fy;

            bool xCondition = strikeZoneX >= Px1 && strikeZoneX <= Px2;
            bool yCondition = strikeZoneY <= Py1 && strikeZoneY >= Py2;

            return xCondition && yCondition;
        }
        static bool IsThere75pDamage()
        {
            int strikeZoneX = Fx + D + 1;
            int strikeZoneY = Fy;

            bool xCondition = strikeZoneX >= Px1 && strikeZoneX <= Px2;
            bool yCondition = strikeZoneY <= Py1 && strikeZoneY >= Py2;

            return xCondition && yCondition;
        }
        static bool IsThere50pDamageOver()
        {
            int strikeZoneX = Fx + D;
            int strikeZoneY = Fy + 1;

            bool xCondition = strikeZoneX >= Px1 && strikeZoneX <= Px2;
            bool yCondition = strikeZoneY <= Py1 && strikeZoneY >= Py2;

            return xCondition && yCondition;
        }
        static bool IsThere50pDamageUnder()
        {
            int strikeZoneX = Fx + D;
            int strikeZoneY = Fy - 1;

            bool xCondition = strikeZoneX >= Px1 && strikeZoneX <= Px2;
            bool yCondition = strikeZoneY <= Py1 && strikeZoneY >= Py2;

            return xCondition && yCondition;
        }
    }
}
