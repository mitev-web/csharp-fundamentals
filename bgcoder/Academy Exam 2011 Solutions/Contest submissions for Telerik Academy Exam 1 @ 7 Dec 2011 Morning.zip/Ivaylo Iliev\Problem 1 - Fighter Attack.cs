using System;

namespace ModuleOne
{
    class Task1
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int hit1x, hit1y, hit2x, hit2y, hit3x, hit3y, hit4x, hit4y;
            hit1x = fx + d;
            hit1y = fy;
            if (d < 0)
            {
                hit2x = fx + d -1;
                hit2y = fy;
            }
            else
            {
                hit2x = fx + d + 1;
                hit2y = fy;
            }
            
            hit3x = fx + d;
            hit3y = fy + 1;
            hit4x = fx + d;
            hit4y = fy - 1;
            int res = 0;
            if (px1 <= px2)
            {
                if (py1 >= py2)
                {
                    if (px1 <= hit1x && hit1x <= px2 && py1 >= hit1y && hit1y >= py2)
                    {
                        res += 100;
                    }
                    if (px1 <= hit2x && hit2x <= px2 && py1 >= hit2y && hit2y >= py2)
                    {
                        res += 75;
                    }
                    if (px1 <= hit3x && hit3x <= px2 && py1 >= hit3y && hit3y >= py2)
                    {
                        res += 50;
                    }
                    if (px1 <= hit4x && hit4x <= px2 && py1 >= hit4y && hit4y >= py2)
                    {
                        res += 50;
                    }
                }
                else
                {
                    if (px1 <= hit1x && hit1x <= px2 && py1 <= hit1y && hit1y <= py2)
                    {
                        res += 100;
                    }
                    if (px1 <= hit2x && hit2x <= px2 && py1 <= hit2y && hit2y <= py2)
                    {
                        res += 75;
                    }
                    if (px1 <= hit3x && hit3x <= px2 && py1 <= hit3y && hit3y <= py2)
                    {
                        res += 50;
                    }
                    if (px1 <= hit4x && hit4x <= px2 && py1 <= hit4y && hit4y <= py2)
                    {
                        res += 50;
                    }
                }
            }
            else
            {
                if (py1 >= py2)
                {
                    if (px1 >= hit1x && hit1x >= px2 && py1 >= hit1y && hit1y >= py2)
                    {
                        res += 100;
                    }
                    if (px1 >= hit2x && hit2x >= px2 && py1 >= hit2y && hit2y >= py2)
                    {
                        res += 75;
                    }
                    if (px1 >= hit3x && hit3x >= px2 && py1 >= hit3y && hit3y >= py2)
                    {
                        res += 50;
                    }
                    if (px1 >= hit4x && hit4x >= px2 && py1 >= hit4y && hit4y >= py2)
                    {
                        res += 50;
                    }
                }
                else
                {
                    if (px1 >= hit1x && hit1x >= px2 && py1 <= hit1y && hit1y <= py2)
                    {
                        res += 100;
                    }
                    if (px1 >= hit2x && hit2x >= px2 && py1 <= hit2y && hit2y <= py2)
                    {
                        res += 75;
                    }
                    if (px1 >= hit3x && hit3x >= px2 && py1 <= hit3y && hit3y <= py2)
                    {
                        res += 50;
                    }
                    if (px1 >= hit4x && hit4x >= px2 && py1 <= hit4y && hit4y <= py2)
                    {
                        res += 50;
                    }
                }

            }
            Console.WriteLine(res + "%");

        }
    }
}
