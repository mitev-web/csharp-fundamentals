using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam
{
    class Program
    {
        static void Main(string[] args)
        {
                int px1, px2, py1, py2, fx, fy, d;
                //plant's coordinates
                px1 = Int32.Parse(Console.ReadLine());
                py1 = Int32.Parse(Console.ReadLine());
                px2 = Int32.Parse(Console.ReadLine());
                py2 = Int32.Parse(Console.ReadLine());
                //fighter's coordinates
                fx = Int32.Parse(Console.ReadLine());
                fy = Int32.Parse(Console.ReadLine());
                //distance
                d = Int32.Parse(Console.ReadLine());
                int targetx = fx + d;
                int targety = fy;
                short hitPercentage = 0;
                int maxx, minx, maxy, miny; // define the plant area
                if (px1 > px2)
                {
                    maxx = px1;
                    minx = px2;
                }
                else
                {
                    maxx = px2;
                    minx = px1;
                }
                if (py1 > py2)
                {
                    maxy = py1;
                    miny = py2;
                }
                else
                {
                    maxy = py2;
                    miny = py1;
                }
                if (targetx <= maxx && targetx >= minx && targety >= miny && targety <= maxy)
                    hitPercentage += 100;
                if (targetx + 1 <= maxx && targetx + 1 >= minx && targety >= miny && targety <= maxy)//the (tagetx+1,targety)
                    hitPercentage += 75;
                if (targetx <= maxx && targetx >= minx && targety + 1 >= miny && targety + 1 <= maxy)
                    hitPercentage += 50;
                if (targetx <= maxx && targetx >= minx && targety - 1 >= miny && targety - 1 <= maxy)
                    hitPercentage += 50;
                Console.WriteLine("{0}%", hitPercentage);
            }
    }
}
