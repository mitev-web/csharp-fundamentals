using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[8] {8, 72, 8, 8, 16, 28, 240, 0};

            int[,] grid = new int[8, 8];
            for (int row = 0; row <= 7; row++)
			{
                for (int col = 0; col <= 7; col++)
                {
                    grid[row, col] = getBitValue(numbers[row], col);
                }
            }

            int prevGridValue = -1; 
            int horLineCount = 0;
            int horCurrentValue = 0;
            int horLineValue = 0;
            for (int row = 0; row <= 7; row++)
            {
                horCurrentValue = 0;
                for (int col = 0; col <= 7; col++)
                {
                    if (grid[row, col] == prevGridValue && grid[row, col] == 1)
                    {
                        horCurrentValue++;
                        if (horCurrentValue > horLineValue)
                        {
                            horLineValue = horCurrentValue + 1;
                        }
                    }
                    else
                    {
                        if (horCurrentValue != 0)
                        {
                            horLineCount++;
                        }
                        horCurrentValue = 0;
                        prevGridValue = grid[row, col];
                    }
                }
            }
            Console.WriteLine(horLineValue);
            Console.WriteLine(horLineCount);

            //for (int row = 0; row <= 7; row++)
            //{
            //    for (int col = 0; col <= 7; col++)
            //    {
            //        Console.Write("{0} ",
            //            grid[row, col]);
            //    }
            //    Console.WriteLine();
            //}
        }

        private static int getBitValue(int number, int possition)
        {
            int mask = 1 << possition;
            int nAndMask = number & mask;
            int bit = nAndMask >> possition;
            return bit;
        }
    }
}