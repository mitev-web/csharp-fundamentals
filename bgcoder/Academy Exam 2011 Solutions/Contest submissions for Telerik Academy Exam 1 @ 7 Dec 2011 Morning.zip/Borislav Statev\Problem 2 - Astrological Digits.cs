using System;
using System.Collections.Generic;

namespace _2.AstrologicalDigits
{
    class AstrologicalDigits
    {
        static void Main(string[] args)
        {
            string n = Console.ReadLine();
            char[] digitsChar = n.ToCharArray();
            byte[] digitsNumber = new byte[digitsChar.Length];
            int astroSum = 0;
            for (int i = 0; i < digitsChar.Length; i++)
            {
                byte.TryParse(digitsChar[i].ToString(), out digitsNumber[i]);
                astroSum += digitsNumber[i];
            }
            while (astroSum >= 10)
            {
                int fallSum = astroSum;
                astroSum = 0;
                while (fallSum > 0)
                {
                    astroSum += fallSum % 10;
                    fallSum = fallSum / 10;
                }
            }
            Console.WriteLine(astroSum);
        }
    }
}
