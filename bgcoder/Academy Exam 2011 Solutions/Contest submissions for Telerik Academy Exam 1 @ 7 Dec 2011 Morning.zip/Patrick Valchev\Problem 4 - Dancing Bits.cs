using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int count=0;
            int res = 0;
            int [] arr = new int[n];
            for (int i = 0; i< n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            int bit = ((arr[n-1] >> 0) & 1);
            count++;
            for (int i = n-1; i >=0 ; i--)
			{
                
                for (int j = 0; j <= Math.Log(arr[i],2); j++)
                {
                    if (i != (n - 1) || j != 0)
                    {
                        if (((arr[i] >> j) & 1) == bit)
                        {
                            count++;
                        }
                        else
                        {
                            if (count == k)
                                res++;
                            count = 1;
                            bit = ((arr[i] >> j) & 1);
                        }
                    }
                    //else if ((int)Math.Log(arr[i], 2) == 1) 
                    //{
                    //    if (count == k)
                    //        res++;
                    //}
                }
               
            }
            if (count == k && ((arr[0] >> (int)Math.Log(arr[0], 2)) & 1) == bit || (count == 1 && count == k))
            {
                res++;
            }
            Console.WriteLine(res);
        }
    }
}
