using System;
using System.Linq;

namespace Problem2_AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            bool stop = false;
            string enterNumberStr = Console.ReadLine();
            long result = 0L;
            int digit = 0;
            do
            {
                result = 0L;
                foreach (var item in enterNumberStr)
                {
                    if (int.TryParse(item.ToString(),out digit))
                    {
                        result = result+digit;
                    }
                }
                if (result <= 9)
                {
                    stop = true;
                }
                else
                {
                    enterNumberStr = result.ToString();
                }
            } while (!stop);
            Console.WriteLine("{0}",result);

        }
    }
}
