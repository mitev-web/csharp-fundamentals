using System;

class Program
{
    static void Main()
    {
        string N = Console.ReadLine();
        int sum = 0;
        int sumofSum = 0;

        for (int i = 0; i < N.Length; i++)
        {
            char symbol = N[i];
            switch (symbol)
            {
                case '0': sum += 0; break;
                case '1': sum += 1; break;
                case '2': sum += 2; break;
                case '3': sum += 3; break;
                case '4': sum += 4; break;
                case '5': sum += 5; break;
                case '6': sum += 6; break;
                case '7': sum += 7; break;
                case '8': sum += 8; break;
                case '9': sum += 9; break;
                case '.': break;
                case '-': break;
                default: Console.WriteLine("Error !"); break;
            }
            if (sum >= 10)
                sum = (sum % 10) + 1;
        }
        Console.WriteLine(sum);
    }
}