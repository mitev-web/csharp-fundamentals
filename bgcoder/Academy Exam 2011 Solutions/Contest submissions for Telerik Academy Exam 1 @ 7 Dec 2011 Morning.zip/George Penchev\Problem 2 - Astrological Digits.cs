using System;


namespace problem2
{
    class Program
    {
        static void Main()
        {
            string n = Console.ReadLine();

            int sum = 0;

            do
            {
                sum = 0;
                if (n[0] == '-')
                {
                    for (int i = 1; i < n.Length; i++)
                    {
                        if (n[i] != '.')
                            sum += Convert.ToInt32(new string(n[i], 1));
                    }
                }
                else
                    for (int i = 0; i < n.Length; i++)
                    {
                        if (n[i] != '.')
                            sum += Convert.ToInt32(new string(n[i], 1));
                    }
                
                n = sum.ToString();

            }
            while (int.Parse(n) > 9);
            Console.WriteLine(sum);           
            
        }
    }
}
