using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstExam
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            int hitx = fx + d;
            int hity = fy;

            if ((hitx >= px1) && (hitx <= px2) && (hity >= py2) && (hity <= py1))
            {
                if ((px1 == px2) && (py1 == py2) && (hitx == px1) && (hity == py1))
                {
                    Console.WriteLine("100%");
                }
                else
                {
                    if ((hitx == px2) && (hity == py2) || ((hitx == px2) && (hity == py1)))
                    {
                        Console.WriteLine("150%");
                    }
                    else
                    {
                        if ((py1 == py2) && (hitx >= px1) && (hitx <= px2) && (hity == py1))
                        {
                            Console.WriteLine("175%");
                        }
                        else
                        {
                            if ((hitx == px2) && (hity < py1) && (hity > py2))
                            {
                                Console.WriteLine("200%");
                            }
                            else
                            {
                                if ((hitx < px2) && (hitx >= px1) && ((hity == py1) || (hity == py2)))
                                {
                                    Console.WriteLine("225%");
                                }
                                else
                                    Console.WriteLine("275%");
                            }
                        }
                    }
                }
            }
            else
            {
                if ((hitx == px1 - 1) && (hity <= py1) && (hity >= py2))
                    Console.WriteLine("75%");
                else
                {
                    if ((hitx <= px2) && (hitx >= px1) && ((hity == py2 - 1) || (hity == py1 + 1)))
                        Console.WriteLine("50%");
                    else
                        Console.WriteLine("0%");
                }
            }
        }
    }
}
