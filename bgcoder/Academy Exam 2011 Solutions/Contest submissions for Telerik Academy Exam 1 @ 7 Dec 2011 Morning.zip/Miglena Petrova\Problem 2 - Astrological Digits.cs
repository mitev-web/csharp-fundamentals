using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Zad2_izpit
{
    class Program
    {
        static void Main(string[] args)
        {
            double n = double.Parse(Console.ReadLine());
            n = Math.Abs(n);
            BigInteger sum = 0;
            BigInteger wholePart = (int)n;
            double decimalPart = n - (double) wholePart;
            for (int i = 1; i < 620; i++)
            {
                for (int j = 1; j < 620; j++)
                {
                    if (i == 1)
                    {
                        int digit = (int)(n % 10);
                        int digitDecimal = ((int)(decimalPart * 10)) % 10;
                        sum = sum + digit + digitDecimal;
                        n = n / 10;
                        decimalPart = (decimalPart * 10);
                    }
                    else
                    {
                        if (sum <= 9)
                        {
                            break;
                        }
                        else
                        {
                            n = (double) sum;
                            sum = 0;
                            while ((int)n > 0)
                            {
                                int digit = (int)(n % 10);
                                sum = sum + digit;
                                n = n / 10;
                            }
                        }
                    }
                }
                if (sum <= 9)
                {
                    break;
                }
            }
            Console.WriteLine(sum);
        }
    }
}
