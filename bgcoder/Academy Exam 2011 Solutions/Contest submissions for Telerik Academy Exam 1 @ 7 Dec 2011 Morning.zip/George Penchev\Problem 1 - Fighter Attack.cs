using System;


namespace Problem1
{
    class Program
    {
        static void Main()
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int damage = 0;

            if (px1 > px2)
            {
                px1 += px2;
                px2 = px1 - px2;
                px1 -= px2;
            }
            
            if (py1 < py2)
            {
                py1 += py2;
                py2 = py1 - py2;
                py1 -= py2;
            }

            if ((fx + d == px1 - 1) && (fy <= py1) && (fy >= py2)) damage += 75;
            if ((fx + d == px1) && (fy <= py1) && (fy >= py2) && (fx + d < px2)) damage += 175;
            if ((fx + d == px1) && (fy <= py1) && (fy >= py2) && (fx + d == px2)) damage += 100;
            if ((fx + d > px1) && (fy <= py1) && (fy >= py2) && (fx + d < px2)) damage += 175;
            if ((fx + d > px1) && (fy <= py1) && (fy >= py2) && (fx + d == px2)) damage += 100;

            if ((fx + d >= px1) && (fx + d <= px2) && (fy == py2 - 1)) damage += 50;
            if ((fx + d >= px1) && (fx + d <= px2) && (fy == py2)) damage += 50;
            if ((fx + d >= px1) && (fx + d <= px2) && (fy == py1 + 1)) damage += 50;
            if ((fx + d >= px1) && (fx + d <= px2) && (fy == py1)) damage += 50;
            if ((fx + d >= px1) && (fx + d <= px2) && (fy > py2) && (fy < py1)) damage += 100;

            Console.WriteLine("{0}%", damage);
        }
    }
}
