using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem3
{
    class Program
    {
        static void Main(string[] args)
        {


            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == 1 && j < n)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        if (n+1 == (n - j))
                        {
                            Console.Write(4);
                        }
                        else
                        {
                            if (i == 1 && j < n)
                            {
                                Console.Write(".");
                            }
                            else
                            {
                                if (i == n)
                                {
                                    Console.Write("*");
                                }
                                else
                                {
                                    if (i == n+1)
                                    {
                                        Console.Write("*");
                                    }
                                    else
                                    {
                                        if (n+1 - j-1 >= i)
                                        {
                                            Console.Write(".");
                                        }
                                        else
                                        {
                                            Console.Write("*");
                                        }
                                    }
                                }
                            }

                        }
                    }
                }
                Console.WriteLine();
            }
        }
    }

    
}

