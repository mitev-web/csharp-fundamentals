using System;

namespace TaskFive
{
    class Task5
    {
        static void Main(string[] args)
        {
            int[] arr = new int[8];
            for (int i = 0; i < 8; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            int br = 1;
            int[] arr1 = new int[8];
            arr.CopyTo(arr1, 0);
            int[] brv = new int[8];
            int[] ver = new int[8];
            int[] brh = new int[8];
            int[] hor = new int[8];
            int[] t = new int[8];
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (arr[i] % 2 == 1)
                    {
                        t[j]++;
                        if (i == 7)
                        {
                            if (t[j] == brv[j])
                            {
                                ver[j]++;
                            }
                            if (t[j] > brv[j])
                            {
                                brv[j] = t[j];
                            }
                        }
                    }
                    else
                    {
                        if (t[j] == brv[j])
                        {
                            ver[j]++;
                        }
                        if (t[j] > brv[j])
                        {
                            brv[j] = t[j];
                        }
                        t[j] = 0;
                    }
                    arr[i] = arr[i] >> 1;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                t[i] = 0;
            }
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (arr1[i] % 2 == 1)
                    {
                        t[i]++;
                        if (j == 7)
                        {
                            if (t[i] == brh[j])
                            {
                                hor[i]++;
                            }
                            if (t[i] > brh[j])
                            {
                                brh[j] = t[i];
                            }
                        }
                    }
                    else
                    {
                        if (t[i] == brh[i])
                        {
                            hor[j]++;
                        }
                        if (t[i] > brh[i])
                        {
                            brh[i] = t[i];
                        }
                        t[i] = 0;
                    }
                    arr1[i] = arr1[i] >> 1;
                }
            }

            Array.Sort(brv);
            Array.Sort(ver);
            Array.Sort(brh);
            Array.Sort(hor);

            if (brv[7] == brh[7])
            {
                for (int i = 6; i >= 0; i--)
                {
                    if (brv[i] == brv[7])
                    {
                        br++;
                    }
                    else
                        break;
                }
                br++;
                for (int i = 6; i >= 0; i--)
                {
                    if (brh[i] == brh[7])
                    {
                        br++;
                    }
                    else
                        break;
                }
                Console.WriteLine(brh[7]);
                Console.WriteLine(br + hor[0] + ver[0]);
            }
            else
            {
                if (brv[7] < brh[7])
                {
                    for (int i = 6; i >= 0; i--)
                    {
                        if (brh[i] == brh[7])
                        {
                            br++;
                        }
                        else
                            break;
                    }
                    Console.WriteLine(brh[7]);
                    Console.WriteLine(br + hor[0]);
                }
                else
                {
                    for (int i = 6; i >= 0; i--)
                    {
                        if (brv[i] == brv[7])
                        {
                            br++;
                        }
                        else

                            break;
                    }
                    Console.WriteLine(brv[7]);
                    Console.WriteLine(br + ver[0]);
                }
            }           
        }
    }
}
