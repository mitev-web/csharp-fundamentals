using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hourglass
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int a = 1;
            int b = 0;
            int c = 1;
            for (int i = 0; i < N; i++)
            {
                for (int k = 0; k < N; k++)
                {
                    if (a > b && a <= N-b)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                    a++;
                }
                a = 1;
                if (b+1 == N / 2 + 1)
                { c = -1; 
                  b = b + c; }
                else
                { b = b + c; }
                
                Console.WriteLine();

            }
        }
    }
}
