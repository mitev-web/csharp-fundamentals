using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            byte k = byte.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            string all = "";
            
           for (int i = 0; i < n; i++)
            {
                 uint[] array = new uint[n];
                array[i] = uint.Parse(Console.ReadLine());
                string[] binary = new string[n];
                binary[i]=Convert.ToString(array[i], 2);
                
                all = all + binary[i];
                 
            }

         


           


        }
    }
}
