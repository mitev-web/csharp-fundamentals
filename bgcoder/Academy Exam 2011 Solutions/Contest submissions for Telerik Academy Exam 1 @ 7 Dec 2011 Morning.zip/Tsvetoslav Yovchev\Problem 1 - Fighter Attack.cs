using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sandClock
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    if (i == 1 && j <= n)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        if (i == n)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            if (j == i - 1)
                            {
                                Console.Write("*");
                            }
                            else
                            {
                                if (n - j == i)
                                {
                                    Console.Write("*");
                                }
                                else
                                {
                                    if (j == n/2)
                                    {
                                        Console.Write("=");
                                    }
                                    else
                                    {
                                        Console.Write("."); 
                                    }
                                }
                            }
                        }
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
