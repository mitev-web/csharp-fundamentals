using System;

namespace TaskFour
{
    class Task4
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            string tmp = "";
            for (int i = 0; i < n; i++)
            {
                int t = int.Parse(Console.ReadLine());
                tmp += Convert.ToString(t, 2);
            }
            Console.WriteLine(find(tmp, k));
        }
        public static int find(string tmp, int k)
        {
            int br = 0;
            //Console.WriteLine(tmp); 101110111010001111
            string t0 = new string('0',k);
            string t1 = new string('1', k);
            string zero = tmp;
            string one = tmp;
            //Console.WriteLine(t0);
            //Console.WriteLine(t1);
            for (int i = 0; i < tmp.Length; i++)
            {
                if (one.IndexOf(t1) != one.IndexOf("1" + t1) && one.IndexOf(t1) != one.IndexOf(t1 + "1") && one.IndexOf(t1) != -1)
                {
                    br++;
                    one = one.Substring(one.IndexOf(t1) + 1, one.Length - one.IndexOf(t1) - 1);
                }
                else
                    break;
            }
            for (int i = 0; i < tmp.Length; i++)
            {
                if (zero.IndexOf(t0) != zero.IndexOf("0" + t0) && zero.IndexOf(t0) != zero.IndexOf(t0 + "0") && zero.IndexOf(t0) != -1)
                {
                    br++;
                    zero = zero.Substring(zero.IndexOf(t0) + 1, zero.Length - zero.IndexOf(t0) - 1);
                }
                else
                    break;
            }

            return br;
        }
    }
}
