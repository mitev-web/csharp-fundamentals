using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FighterAtack
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            int D = int.Parse(Console.ReadLine());
       
            /*  int Px1 =2;
            int Py1 =5;
            int Px2 = 6;
            int Py2 = 3;
            int Fx = -6;
            int Fy = 3;
            int D = 9;*/



            int damagecounter = 0;

            int damagedCellX = Fx + D;  //Cx   
            int damagedCellY = Fy;  //Cy   

            int A = (Px1 != Px2) ? Math.Min(Px1, Px2) : Px1;
            int B = (Px1 != Px2) ? Math.Max(Px1, Px2) : Px1;
            int C = (Py1 != Py2) ? Math.Max(Py1, Py2) : Py1;
            int E = (Py1 != Py2) ? Math.Min(Py1, Py2) : Py1;


            if((damagedCellX >=A)&&(damagedCellX<=B)&&(damagedCellY>=E)&&(damagedCellY<=C))

            {
                damagecounter = damagecounter + 100;
            }



            if (((damagedCellX + 1) >= A) && ((damagedCellX + 1) <= B) && (damagedCellY >= E) && (damagedCellY <=C))
            {
                damagecounter = damagecounter + 75;
            }

            if ((damagedCellX >= A) && (damagedCellX <= B) && ((damagedCellY+1) >= E) && ((damagedCellY+1) <= C))
            {
                damagecounter = damagecounter + 50;
            }

            if ((damagedCellX >= A) && (damagedCellX <= B) && ((damagedCellY - 1) > E) && ((damagedCellY - 1) <= C))
            {
                damagecounter = damagecounter + 50;
            }

            Console.WriteLine("{0}%",damagecounter);

        }
    }
}
