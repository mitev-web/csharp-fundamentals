using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.SandGlass
{
    class SandGlass
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            for (byte i = 0; i < n; i++)
            {
                byte afterMiddle = 0;
                byte isOdd = 0;
                if (i > (n / 2 - 1))
                {
                    afterMiddle = 1;
                    if (n % 2 == 1)
                    {
                        isOdd = 1;
                    }
                }
                string dotWidth = new string('.', Math.Abs(n / 2 - Math.Abs(n / 2 - i - afterMiddle + isOdd)));
                string asteriskWidth = new string('*',Math.Abs(n - 2 * (i + afterMiddle)));
                Console.WriteLine("{0}{1}{2}",dotWidth,asteriskWidth,dotWidth);
            }
        }
    }
}
