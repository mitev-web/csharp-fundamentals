using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;
 
namespace AstrologicalDigits
{
    class AstrologicalDigits
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            string userInput = Console.ReadLine();
            int n = int.Parse(userInput);
             
 
            string nString = n.ToString();
            int sum = 0;
            int numberOfDigitsWithoutDot = nString.Length;
            //Console.WriteLine("Numbers of digit : {0}",numberOfDigitsWithoutDot);
            int[] arrayWithoutDot = new int[numberOfDigitsWithoutDot];
 
            for (int i = 0; i < numberOfDigitsWithoutDot; i++)
            {
                arrayWithoutDot[i] = n % 10;
                n /= 10;
            }
 
            for (int i = 0; i < numberOfDigitsWithoutDot; i++)
            {
                 
                sum=sum+arrayWithoutDot[i];
            }
             
            Console.WriteLine(sum);
        }
    }
}