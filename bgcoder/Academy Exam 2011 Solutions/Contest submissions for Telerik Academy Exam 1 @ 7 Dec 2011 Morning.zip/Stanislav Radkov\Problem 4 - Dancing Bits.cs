using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04
{
    class Program
    {
        private static Int32 K;
        private static Int32 N;
        private static Int32 dancingBitsCount = 0;

        private static Int32[] numbers;

        static void Main(string[] args)
        {
            K = Int32.Parse(Console.ReadLine());
            N = Int32.Parse(Console.ReadLine());

            numbers = new Int32[N];

            ReadNumbers(numbers);
            CountDancingBits();

            Console.WriteLine(dancingBitsCount);
        }

        private static void ReadNumbers(Int32[] numbers)
        {
            Int32 mostleftPosition = numbers.Length - 1;

            for (int numberCnt = 0; numberCnt < numbers.Length; numberCnt++)
            {
                numbers[mostleftPosition - numberCnt] = Int32.Parse(Console.ReadLine());
            }
        }

        private static void CountDancingBits()
        {
            bool previousValue = GetBit(numbers[0], 0);
            bool currentValue = false; ;
            Int32 sameBitSequenceLength = 1;
            Int32 bitToCountUpTo;

            for (int numberCnt = 0; numberCnt < numbers.Length; numberCnt++)
            {
                bitToCountUpTo = FindMSBNotZero(numbers[numberCnt]);

                for (int bitCnt = (numberCnt==0 ? 1 : 0); bitCnt <= bitToCountUpTo; bitCnt++)
                {
                    currentValue = GetBit(numbers[numberCnt], bitCnt);
                    CompareToK(ref sameBitSequenceLength, currentValue, previousValue);

                    previousValue = currentValue;
                }
            }

            if (sameBitSequenceLength == K)
            {
                dancingBitsCount++;
            }
        }

        private static void CompareToK(ref Int32 sameBitSequenceLength, bool currentValue, bool previousValue)
        {
            if (currentValue == previousValue)
            {
                sameBitSequenceLength++;
            }
            else
            {
                if (sameBitSequenceLength == K)
                {
                    dancingBitsCount++;
                }

                sameBitSequenceLength = 1;
            }  
        }

        private static Int32 FindMSBNotZero(Int32 number)
        {
            Int32 mask;
            Int32 bitNumber = 0;

            for (int i = 31; i >= 0; i--)
            {
                mask = (Int32)(1 << i);

                if ((mask & number) != 0)
                {
                    bitNumber = i;
                    break;
                }
            }

            return bitNumber;
        }

        private static bool GetBit(Int32 number, Int32 bitPosition)
        {
            if ((number & (1 << bitPosition)) != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
