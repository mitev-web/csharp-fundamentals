using System;

class SandGlass
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
        for (int i = n-2; i > 0; i = i - 2)
        {
            for (int k = n-i-1; k > 0; k=k-2)
            {
                Console.Write(".");
            }
            for (int j = i; j > 0; j--)
            {
                Console.Write("*");
            }
            for (int k = n - i - 1; k > 0; k = k - 2)
            {
                Console.Write(".");
            }
            Console.WriteLine();
        }
        for (int i = 3; i <= n-2; i = i + 2)
        {
            for (int k = n - i - 1; k > 0; k = k - 2)
            {
                Console.Write(".");
            }
            for (int j = i; j > 0; j--)
            {
                Console.Write("*");
            }
            for (int k = n - i - 1; k > 0; k = k - 2)
            {
                Console.Write(".");
            }
            Console.WriteLine();
        }
        for (int i = 0; i < n; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
        
    }
}
