using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam1
{
    class Program
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N + 1; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (i == 0)
                    {
                        if (j < N)
                        {
                            Console.Write("*");
                        }
                        else
                          {
                               Console.Write(".");
                          }
                    }
                    else if (i == N)
                    {
                        Console.Write("*");
                    }

                    else
                    {
                        if (j >= N - i || i == 2 * N)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }


                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
