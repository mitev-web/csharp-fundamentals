using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace AstrologicalDigits
{
    class Program
    {
        static void Main(string[] args)
        {

           double orN = double.Parse(Console.ReadLine());

          /*
           do
           {

               orN = orN * 10;
           }
           while (orN<= 1.7e307);
           */


           BigInteger N = (BigInteger)orN;

           BigInteger a;
           BigInteger b = (N >= 0) ? N : (-N);
           BigInteger astroDigit = 11;


           




           while(astroDigit>=10)
           {
               BigInteger Sum = 0;

               do
               {
                   
                   a = b % 10;
                   Sum = a + Sum;
                   b = (BigInteger)b / 10;

               }
               while (b >= 1);

               b = Sum;
              
               astroDigit = Sum;

           }
           

            Console.WriteLine(astroDigit);
           
        }
    }
}
