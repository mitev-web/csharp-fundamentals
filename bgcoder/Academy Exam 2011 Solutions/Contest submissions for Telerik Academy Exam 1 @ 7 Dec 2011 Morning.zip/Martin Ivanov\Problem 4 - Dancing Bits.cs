using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int bitCount = int.Parse(Console.ReadLine());
            int numberCount = int.Parse(Console.ReadLine());
            int[] numbers = new int[numberCount];
            int currentCount = 0;
            int count = 0;

            for (int i = 0; i < numberCount; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }

            int currentBit = (numbers[numberCount - 1] & 1);

            for (int i = numberCount - 1; i >= 0; i--)
            {
                int currentNumber = numbers[i];
                while (currentNumber != 0)
                {
                    currentNumber >>= 1;
                    if ((currentNumber & 1) == currentBit)
                    {
                        currentCount++;
                    }
                    else
                    {
                        currentCount = 0;
                        currentBit = (currentNumber & 1);
                    }
                    if (currentCount == bitCount)
                    {
                        count++;
                    }
                }
            }
            Console.WriteLine(count);
        }
    }
}