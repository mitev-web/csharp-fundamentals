using System;

class Lines //problem 5
{
    static void Main()
    {
        string line;
        int [] n = new int [8];
        for (int i=0; i<8; i++)
        {
            line = Console.ReadLine();
            n[i] = Convert.ToByte(line);
        }
        int [] c = new int [8];
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                c[i] += ((n[j] & (1 << i)) >> i) << j;
            }
        }
        int consN = cons(n);
        int consC = cons(c);
        int con = 0;
        int cLines = 0;
        if (consN > consC)
        {
            con = consN;
            cLines = lines(n, con);
        }
        if (consN < consC)
        {
            con = consC;
            cLines = lines(c, con);
        }
        if (consN == consC)
        {
            con = consN;
            if (con == 1)
                cLines = lines(n, con);
            else
                cLines = lines(n, con)+lines(c, con);
        }
        Console.WriteLine(con);
        Console.WriteLine(cLines);
    }
    static int cons(int [] n)   //max number of consecutive 1-s in n
    {
        int cons = 0;
        for (int i = 0; i < 8; i++)
        {
            int t = n[i];
            int tmpcount = 0;
            for (int j = 0; j < 8; j++)
            {
                if (t % 2 == 1) tmpcount++;
                else tmpcount = 0;
                if (tmpcount > cons) cons = tmpcount;
                t >>= 1;
            }
        }
        return cons;
    }
    static int lines(int [] n, int cons)    //number of members of n with (cons) consecutive 1-s
    {
        int lines = 0;
        for (int i = 0; i < 8; i++)
        {
            int t = n[i];
            int tmpcount = 0;
            for (int j = 0; j < 8; j++)
            {
                if (t % 2 == 1) tmpcount++;
                else tmpcount = 0;
                if (tmpcount == cons) lines++;
                t >>= 1;
            }
        }
        return lines;
    }
}
