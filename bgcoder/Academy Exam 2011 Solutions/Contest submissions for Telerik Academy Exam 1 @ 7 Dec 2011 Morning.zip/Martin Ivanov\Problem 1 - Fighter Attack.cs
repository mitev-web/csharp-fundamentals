using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FighterAttack
{
    class Program
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            //Console.WriteLine();

            int left = px1 < px2 ? px1 : px2;
           // Console.WriteLine(left);
            int down = py1 < py2 ? py1 : py2;
           // Console.WriteLine(down);
            int length = Math.Abs(px1 - px2);
           // Console.WriteLine(length);
            int height = Math.Abs(py1 - py2);
           // Console.WriteLine(height);
            int missileX = fx + d;
            int missileY = fy;
            int totalDamage = 0;

            if (missileX >= left &&
                missileX <= left + length &&
                missileY >= down &&
                missileY <= down + height)
            {
                totalDamage += 100;
            }

            if ((missileX + 1) >= left &&
                (missileX + 1) <= left + length &&
                missileY >= down &&
                missileY <= down + height)
            {
                totalDamage += 75;
            }

            if (missileX >= left &&
                missileX <= left + length &&
                missileY + 1 >= down &&
                missileY + 1 <= down + height)
            {
                totalDamage += 50;
            }

            if (missileX >= left &&
                missileX <= left + length &&
                missileY - 1 >= down &&
                missileY - 1 <= down + height)
            {
                totalDamage += 50;
            }

            Console.WriteLine("{0}%", totalDamage);
        }
    }
}