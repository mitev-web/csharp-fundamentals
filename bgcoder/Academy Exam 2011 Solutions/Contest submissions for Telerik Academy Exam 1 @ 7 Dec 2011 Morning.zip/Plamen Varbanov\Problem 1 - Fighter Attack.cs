using System;

namespace Problem_1_Fighter_Attack
{
    class Problem_1_Fighter_Attack
    {
        static void Main(string[] args)
        {
            // Top Left Plant
            int Px1 = int.Parse(Console.ReadLine());
            int Py1 = int.Parse(Console.ReadLine());
            // Bottom Right Plant
            int Px2 = int.Parse(Console.ReadLine());
            int Py2 = int.Parse(Console.ReadLine());
            // Fighter
            int Fx = int.Parse(Console.ReadLine());
            int Fy = int.Parse(Console.ReadLine());
            // Distance
            int distance = int.Parse(Console.ReadLine());

            // Total damage
            int pointCenterX = Fx + distance;
            int pointCenterY = Fy;
            int pointLeftX = Fx + distance + 1;
            int pointLeftY = Fy;
            int pointTopX = Fx + distance;
            int pointTopY = Fy + 1;
            int pointBottomX = Fx + distance;
            int pointBottomY = Fy -1;

            if (Px1 < Px2 && Py1 > Py2)
            {
                float? counter = 0.00f;
                if ((pointCenterX >= Px1) && (pointCenterX <= Px2) && (pointCenterY <= Py1) & (pointCenterY >= Py2))
                {
                    float damage = 1.00f;
                    counter += damage;
                }
                if ((pointLeftX >= Px1) && (pointLeftX <= Px2) && (pointLeftY <= Py1) & (pointLeftY >= Py2))
                {
                    float damage = 0.75f;
                    counter += damage;
                }
                if ((pointTopX >= Px1) && (pointTopX <= Px2) && (pointTopY <= Py1) & (pointTopY >= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }
                if ((pointBottomX >= Px1) && (pointBottomX <= Px2) && (pointBottomY <= Py1) & (pointBottomY >= Py2))
	            {
                    float damage = 0.50f;
                    counter += damage; 
	            }

                Console.WriteLine("{0:##%}", counter + 0);
            }
            else if (Px1 < Px2 && Py1 < Py2)
            {
                float? counter = 0.00f;
                if ((pointCenterX >= Px1) && (pointCenterX <= Px2) && (pointCenterY >= Py1) & (pointCenterY <= Py2))
                {
                    float damage = 1.00f;
                    counter += damage;
                }
                if ((pointLeftX >= Px1) && (pointLeftX <= Px2) && (pointLeftY >= Py1) & (pointLeftY <= Py2))
                {
                    float damage = 0.75f;
                    counter += damage;
                }
                if ((pointTopX >= Px1) && (pointTopX <= Px2) && (pointTopY >= Py1) & (pointTopY <= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }
                if ((pointBottomX >= Px1) && (pointBottomX <= Px2) && (pointBottomY >= Py1) & (pointBottomY <= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }

                Console.WriteLine("{0:##%}", counter + 0);
            }
            else if (Px1 > Px2 && Py1 > Py2)
            {
                float? counter = 0.00f;
                if ((pointCenterX <= Px1) && (pointCenterX >= Px2) && (pointCenterY <= Py1) & (pointCenterY >= Py2))
                {
                    float damage = 1.00f;
                    counter += damage;
                }
                if ((pointLeftX <= Px1) && (pointLeftX >= Px2) && (pointLeftY <= Py1) & (pointLeftY >= Py2))
                {
                    float damage = 0.75f;
                    counter += damage;
                }
                if ((pointTopX <= Px1) && (pointTopX >= Px2) && (pointTopY <= Py1) & (pointTopY >= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }
                if ((pointBottomX <= Px1) && (pointBottomX >= Px2) && (pointBottomY <= Py1) & (pointBottomY >= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }

                Console.WriteLine("{0:##%}", counter + 0);
            }
            else if (Px1 > Px2 && Py1 < Py2)
            {
                float? counter = 0.00f;
                if ((pointCenterX <= Px1) && (pointCenterX >= Px2) && (pointCenterY >= Py1) & (pointCenterY <= Py2))
                {
                    float damage = 1.0f;
                    counter += damage;
                }
                if ((pointLeftX <= Px1) && (pointLeftX >= Px2) && (pointLeftY >= Py1) & (pointLeftY <= Py2))
                {
                    float damage = 0.75f;
                    counter += damage;
                }
                if ((pointTopX <= Px1) && (pointTopX >= Px2) && (pointTopY >= Py1) & (pointTopY <= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }
                if ((pointBottomX <= Px1) && (pointBottomX >= Px2) && (pointBottomY >= Py1) & (pointBottomY <= Py2))
                {
                    float damage = 0.50f;
                    counter += damage;
                }

                Console.WriteLine("{0:##%}", counter + 0);
            }
        }
    }
}