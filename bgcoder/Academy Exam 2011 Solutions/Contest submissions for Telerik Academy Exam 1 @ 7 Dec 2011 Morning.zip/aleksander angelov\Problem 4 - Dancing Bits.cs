using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DancingBits_task4_
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int[] nArray = new int[n];
            int numberOfDancingSeq = 0;            
            
            string reverseString = "";
            int index = 0;
            for (int i = 0; i < n; i++)
            {
                string concated = "";
                nArray[i] = int.Parse(Console.ReadLine());                
                if (nArray[i] == 0)
                {
                    concated += "0";
                }
                
                    while (nArray[i] != 0)
                    {
                        concated += (nArray[i] & 1);
                        nArray[i] = (nArray[i] >> 1);
                    }
                    for (int a = (concated.Length - 1); a >= 0; a--)
                    {
                        reverseString += concated[a];
                    }
            }
           
            Console.WriteLine(reverseString);
            for (int i = 1; i < reverseString.Length; i++)
            {
                if (reverseString[i - 1] == reverseString[i])
                {
                    index++;
                }
                else if (index == (k-1))
                {
                    numberOfDancingSeq++;
                    index = 0;
                }
                else
                {
                    index = 0;
                }


            }
            Console.WriteLine(numberOfDancingSeq);
        }
    }
}
