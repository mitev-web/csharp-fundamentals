using System;

namespace Problem_2_Astrological_Digits
{
    class Problem_2_Astrological_Digits
    {
        static void Main(string[] args)
        {
            decimal n = decimal.Parse(Console.ReadLine());
            decimal? sum = 0;
            do
            {
                sum += n % 10;
                n /= 10;
            } while (n != 0);
            
            Console.WriteLine((int)sum);
        }
    }
}