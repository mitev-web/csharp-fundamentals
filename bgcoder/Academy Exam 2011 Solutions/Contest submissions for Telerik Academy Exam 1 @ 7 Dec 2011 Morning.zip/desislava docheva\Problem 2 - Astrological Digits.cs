using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int s=int.Parse(Console.ReadLine());
            int n = s.ToString().Sum(c => Convert.ToInt32(c));
            Console.WriteLine(n);
        }
    }
}