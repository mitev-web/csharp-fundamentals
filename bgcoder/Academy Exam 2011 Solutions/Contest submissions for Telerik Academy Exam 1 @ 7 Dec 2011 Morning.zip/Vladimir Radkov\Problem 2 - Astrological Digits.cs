using System;
 
 
namespace Exam2real
{
    class Program
    {
 
        static void Main()
        {
 
 
 
            long num = long.Parse(Console.ReadLine());
            long sum = 0;
 
                for (long n = num; n > 0; sum += n % 10, n /= 10)
                {
 
                }
 
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
                if (sum > 9)
                {
                    num = sum;
                    sum = 0;
                    for (long n = num; n > 0; sum += n % 10, n /= 10)
                    {
 
                    }
                }
 
 
 
 
                Console.WriteLine(sum);
 
 
        }
 
 
    }
}