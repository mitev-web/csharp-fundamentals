using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class Task3
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                if (i < n / 2)
                {
                    for (int j = 0; j < n ; j++)
                    {
                        if (i == 0 || ( j >= i && j <= n - i - 1) )
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                else if (i > n / 2)
                {
                    for (int j = n - 1; j >= 0; j--)
                    {
                        if (i == n - 1 || (j <= i && j >= n - i - 1))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }   
                }
                else
                {
                    for (int j = n - 1; j >= 0; j--)
                    {
                        if (j == n / 2)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    } 
                }
                Console.WriteLine();
            }
        }
    }
}
