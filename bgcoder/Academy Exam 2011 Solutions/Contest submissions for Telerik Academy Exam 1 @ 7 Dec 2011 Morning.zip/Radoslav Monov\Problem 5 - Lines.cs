using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex5_Lines
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] numbers = new string[8];
            for (int i = 0; i < 8; i++)
            {
                string consoleInput = Console.ReadLine();
                numbers[i] = (Convert.ToString(int.Parse(consoleInput),2).PadLeft(8,'0'));
            }

            int[,] grid = new int[8, 8];
            
            for (int row = 0; row < 8; row++)
            {
                
                for (int col = 0; col < 8; col++)
                {
                    grid[row, col] = numbers[row][col]-48;
                    
                }
            }
          
            int[] lines = new int[9];
            int length = 0;
            int currentLength = 1;
            for (int row = 0; row < 7; row++)
            {
                
                for (int col = 0; col < 7; col++)
                {
                    if (grid[row, col] == 1)
                    {
                        
                        if (grid[row, col] == grid[row, col + 1])
                        {
                            currentLength++;
                            if (col==6)
                            {
                                lines[currentLength]++;
                                currentLength = 1;
                            }
                        }
                        else
                        {
                            lines[currentLength]++;
                            currentLength = 1;
                          
                        }
                    }                                        
                }
                
            }
            currentLength = 1;
            for (int col = 0; col < 7; col++)
            {
              
                for (int row = 0; row < 7; row++)
                {
                    if (grid[row, col] == 1)
                    {
                        
                        if (grid[row, col] == grid[row+1, col])
                        {
                            currentLength++;
                            if (row == 6)
                            {
                                lines[currentLength]++;
                                currentLength = 1;
                            }
                            
                        }
                        else
                        {
                            lines[currentLength]++;
                            currentLength = 1;
                          
                        }
                        
                    }            
                }
            }
            int numberOfLongest = 0;
            for (int i = 8; i >0 ; i--)
            {
                if (lines[i] != 0)
                {
                    numberOfLongest = lines[i];
                    length = i;
                    break;
                }
            }
            Console.WriteLine(length);
            Console.WriteLine(numberOfLongest);



        }
    }
}
