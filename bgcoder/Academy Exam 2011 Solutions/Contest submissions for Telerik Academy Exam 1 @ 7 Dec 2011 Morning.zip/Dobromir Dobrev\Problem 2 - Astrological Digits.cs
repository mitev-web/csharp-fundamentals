using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task31231
{
    class Program
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int acc;
            do
            {
                acc = 0;
                while (N > 0)
                {
                    acc += N % 10;
                    N /= 10;
                }
                N = acc;
            }
            while (acc >= 10);

 if (N < 9)
            {
                Console.WriteLine(N);
            }
            else
            {
                do
                {
                    acc = 0;
                    while (N > 0)
                    {
                        acc += N % 10;
                        N /= 10;
                    }
                    N = acc;
                }
                while (acc >= 10);
            }

        }

    }
}
