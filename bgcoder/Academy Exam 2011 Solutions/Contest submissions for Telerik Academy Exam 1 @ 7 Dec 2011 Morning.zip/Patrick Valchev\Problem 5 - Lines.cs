using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad4
{
    class Program
    {    
        static void Main(string[] args)
        {
            int maxRow = 0;
            int countRow = 0;
            int currentRow = 0;
            int maxCol = 0;
            int countCol = 0;
            int[] arr = new int[8];
            for (int i = 0; i < 8; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                     if (((arr[j] >> i) & 1) == 1 && j!=7)
                        {
                            currentRow++;
                        }
                     else
                     {
                         if (((arr[j] >> i) & 1) == 1)
                            currentRow++;
                         if (maxRow > currentRow)
                         {
                         }
                         else if (maxRow == currentRow && currentRow > 0)
                         {
                             countRow++;
                         }
                         else if (maxRow < currentRow)
                         {
                             maxRow = currentRow;
                             countRow = 1;
                         }
                             currentRow = 0;
                     }
                }

            }
            currentRow = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (((arr[i] >> j) & 1) == 1 && j != 7)
                    {
                        currentRow++;
                    }
                    else
                    {
                        if (((arr[i] >> j) & 1) == 1)
                            currentRow++;
                        if (maxCol > currentRow)
                        {
                        }
                        else if (maxCol == currentRow && currentRow > 0)
                        {
                            countCol++;
                        }
                        else if (maxCol < currentRow)
                        {
                            maxCol = currentRow;
                            countCol = 1;
                        }
                        currentRow = 0;
                    }
                }

            }
            if (maxRow == maxCol && maxRow!=1)
            {
                countRow += countCol;
            }
            else if (maxRow < maxCol)
            {
                maxRow = maxCol;
                countRow = countCol;
            }
            Console.WriteLine(maxRow);
            Console.WriteLine(countRow);
        }
    }
}
