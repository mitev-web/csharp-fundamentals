using System;

namespace Lines.cs
{
    class Program
    {
        static void Main()
        {
            byte[] n = new byte[8];
            byte[,] nn = new byte[8, 8];
            byte max = 0;
            byte[] lineLenghtVer = { 1, 1, 1, 1, 1, 1, 1, 1 };
            byte[] lineLenghtHor = { 1, 1, 1, 1, 1, 1, 1, 1 };


            byte count = 0;

            for (int i = 0; i < 8; i++)
            {
                n[i] = byte.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    int mask = 1 << j;
                    if ((mask & n[i]) != 0)
                        nn[i, j] = 1;
                    else
                        nn[i, j] = 0;
                }
            }


            for (int i = 1; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if ((nn[i, j] == 1) && (nn[i - 1, j] == 1))
                    {
                        lineLenghtVer[j]++;
                        if (lineLenghtVer[j] > max)
                            max = lineLenghtVer[j];


                    }

                }
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 1; j < 8; j++)
                {
                    if ((nn[i, j] == 1) && (nn[i, j - 1] == 1))
                    {
                        lineLenghtHor[i]++;
                        if (lineLenghtHor[i] > max)
                            max = lineLenghtHor[i];

                    }

                }
            }



            for (int i = 0; i < 8; i++)
            {

                if ((lineLenghtHor[i] == max) || (lineLenghtVer[i] == max))
                    count++;
            }

            Console.WriteLine(max);

            Console.WriteLine(count);
        }

    }
}