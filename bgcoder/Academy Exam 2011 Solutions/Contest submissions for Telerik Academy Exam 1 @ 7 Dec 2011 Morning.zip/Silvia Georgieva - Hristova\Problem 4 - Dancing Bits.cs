using System;

class DancingBits   //problem 4
{
    static void Main()
    {
        string line = Console.ReadLine();
        int K = Convert.ToInt32(line);
        line = Console.ReadLine();
        int N = Convert.ToInt32(line);
        int count = 0;
        string s = "";
        int t;
        string ts="";
        for (int i = 0; i < N; i++)
        {
            line = Console.ReadLine();
            t = Convert.ToInt32(line);
            ts = "";
            while (t>0)
            {
                ts = Convert.ToString(t%2) + ts;
                t >>= 1;
            }
            s += ts;
        }
        char c = s[0];
        int consecutive=1;
        int prevCons = 1;
        for (int i = 1; i < s.Length; i++)
        {
            prevCons = consecutive;
            if (s[i] == s[i - 1])
                consecutive++;
            else
                consecutive = 1;
            if (prevCons == K && consecutive == 1)
                count++;
        }
        if (consecutive == K)
            count++;
        Console.WriteLine(count);
    }
}