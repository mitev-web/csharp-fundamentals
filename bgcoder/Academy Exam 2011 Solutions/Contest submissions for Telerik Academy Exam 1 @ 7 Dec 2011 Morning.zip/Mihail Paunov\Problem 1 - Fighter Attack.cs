using System;

class Program
{
    static void Main()
    {
        int plantX1 = int.Parse(Console.ReadLine());
        int plantY1 = int.Parse(Console.ReadLine());
        int plantX2 = int.Parse(Console.ReadLine());
        int plantY2 = int.Parse(Console.ReadLine());
        int fighterX = int.Parse(Console.ReadLine());
        int fighterY = int.Parse(Console.ReadLine());
        int distance = int.Parse(Console.ReadLine());

        int damage = 0;

        if (((fighterX + distance) >= plantX1) && ((fighterX + distance) <= plantX2) &&
            (fighterY >= plantY2) && (fighterY <= plantY1))
        {
            damage += 100;
        }

        if (((fighterX + distance + 1) <= plantX2) && ((fighterX + distance + 1) >= plantX1) &&
            (fighterY >= plantY2) && (fighterY <= plantY1))
        {
            damage += 75;
        }

        if (((fighterX + distance) >= plantX1) && ((fighterX + distance) <= plantX2) &&
            ((fighterY - 1) >= plantY2) && ((fighterY - 1) <= plantY1))
        {
            damage += 50;
        }

        if (((fighterX + distance) >= plantX1) && ((fighterX + distance) <= plantX2) &&
            ((fighterY + 1) >= plantY2) && ((fighterY + 1) <= plantY1))
        {
            damage += 50;
        }

        Console.WriteLine(damage + "%");
    }
}