using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int var = n;
            char x = '*';
            char y = '.';
            int row1 = 1;
            int var1 = n;
            int var2 = n;
            int var3 = n;
            int n1 = n;
            int n2 = n;
            int row7 = new int();
            int n3 = 1;
            

            for ( row1 = 1; row1 <= (var + 1) / 2; row1++)
            {
                if (row1 > 1)
                {
                    for (int row2 = 2; row2 <= row1; row2++)
                    {
                        Console.Write("{0}", y);
                    }
                }
                if (row1 > 1)
                {
                    n2 = n2 - 2;
                    var1 = n2;
                }

                    for (int col2 = 1; var1 >= col2; var1--)
                    {
                        Console.Write("{0}", x);
                    }
                    if (row1 > 1)
                    {
                        for (int row2 = 2; row2 <= row1; row2++)
                        {
                            Console.Write("{0}", y);
                        }
                    }
                    Console.WriteLine();

            }
            int row5 = row1;
            int row6 = row1;

            for (int row4 = 1; row4 <= var2 / 2; row4++)
            {
                row7 = row4;
                if (row4 > 1)
                {
                    row1 = row1 - 1;
                    row5 = row1;
                    row6 = row1;
                }
               
                for (int row2 = 4; row5>= row2; row5--)
                {
                    Console.Write("{0}", y);
                    
                }


               
                    n3 = n3+2 ;
                    var3 = n3;
               

                for (int col2 = 1; var3 >= col2; var3--)
                {
                    Console.Write("{0}", x);
                }
               
               
                for (int row2 = 4; row6 >= row2; row6--)
                {
                    Console.Write("{0}", y);
                }

                Console.WriteLine();

            }






        }
    }

}