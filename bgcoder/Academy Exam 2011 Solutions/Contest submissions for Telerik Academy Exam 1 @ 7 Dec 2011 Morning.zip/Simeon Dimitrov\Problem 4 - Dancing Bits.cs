using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4
{
    class Program
    {
        static void Main(string[] args)
        {
            int mask;
            int bit;
            int k = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int[] lines = new int[n];
            int prv = 2;
            int counter = 0;
            int endcnt=0;

            for (int i = 0; i < n; i++)
            {
                lines[i] = int.Parse(Console.ReadLine());

                //Console.WriteLine("------");
            }


            for (int i = n-1; i >= 0; i--)
            {
                for (int j = 0; j <= Math.Log(lines[i], 2); j++)
                {
                    mask = 1 << j;
                    bit = (lines[i] & mask) >> j;
                    if (bit == prv)
                    {
                        counter++;
                    }
                    else
                    {
                        if (counter == k)
                        {
                            endcnt++;
                        }
                        counter = 0;
                        counter++;
                        prv = bit;
                        
                    }
                  
                   //Console.Write(bit);
                    // Console.WriteLine(bit);
                }
                if (i == 0)
                {
                    if (counter == k)
                    {
                        endcnt++;
                    }
                }
            }
            //Console.WriteLine();
            Console.WriteLine(endcnt);

        }
    }
}
