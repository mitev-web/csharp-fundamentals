using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class Task5
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[8, 8];
            int result = 0;
            int counter = 0;

            for (int i = 0; i < 8; i++)
            {
                int temp = int.Parse(Console.ReadLine());
                string tempStr = Convert.ToString(temp, 2).PadLeft(8, '0');

                for (int j = 7; j >= 0; j--)
                {
                    matrix[j, i] = Convert.ToInt32(tempStr.Substring(j, 1));                    
                }               
            }

            int tempResult = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 7; j >= 0; j--)
                {
                    if (matrix[j,i] == 1)
                    {
                        tempResult++;
                    }
                    else
                    {
                        if (tempResult > 0 && tempResult > result)
                        {
                            result = tempResult;
                            counter = 1;
                        }
                        else if (tempResult == result)
                        {
                            counter++;
                        }
                        tempResult = 0;
                    }
                    //Console.Write(matrix[j, i] + " ");
                }
                if (tempResult > 0 && tempResult > result)
                {
                    result = tempResult;
                    counter = 1;
                }
                else if (tempResult == result)
                {
                    counter++;
                }
                tempResult = 0;
                //Console.WriteLine();
            }

            tempResult = 0;
            for (int j = 7; j >= 0; j--)
            {
                for (int i = 0; i < 8; i++)
                {
                    if (matrix[j, i] == 1)
                    {
                        tempResult++;
                    }
                    else
                    {
                        if (tempResult > 0 && tempResult > result)
                        {
                            result = tempResult;
                            counter = 1;
                        }
                        else if (tempResult == result)
                        {
                            counter++;
                        }
                        tempResult = 0;
                    }                   
                }
                if (tempResult > 0 && tempResult > result)
                {
                    result = tempResult;
                    counter = 1;
                }
                else if (tempResult == result)
                {
                    counter++;
                }
                tempResult = 0;
            }
            Console.WriteLine(result);
            if (result == 1)
            {
                counter = counter / 2;
            }
            Console.WriteLine(counter);
        }
    }
}
