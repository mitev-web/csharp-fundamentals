using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.SandGlass
{
    class SandGlass
    {
        static void Main(string[] args)
        {
            byte n;

            byte temp = 0;

            n = byte.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i < (n/2+1))
                    {
                        if ((j >= i) && (j < (n - i)))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }

                    }
                    else
                    {
                        if ((j >= (n-(i+1))) && (j < (i+1)))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                Console.WriteLine();
            }
            
        }
    }
}