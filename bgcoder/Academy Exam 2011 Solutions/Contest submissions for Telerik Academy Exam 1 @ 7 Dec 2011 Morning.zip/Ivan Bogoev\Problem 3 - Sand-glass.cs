using System;


namespace ThirdTask.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberN = int.Parse(Console.ReadLine());
            string[] array = new string[numberN];

            for (int i = 0; i <= array.Length/2; i++)
            {
                
                    for (int d = 0; d < array.Length; d++)
                    {
                        if (i == 0)
                        {
                            array[i] += "*";
                        }
                        else
                        {
                            if (d >= i && d < array.Length - i)
                            {
                                array[i] += "*";
                            }
                            else
                            {
                                array[i] += ".";
                            }
                        }
                    }
                Console.WriteLine(array[i]);
            }
            for(int i = array.Length/2-1;i>=0;i--)
            {
                Console.WriteLine(array[i]);
            }
        
        }
    
    }
}
