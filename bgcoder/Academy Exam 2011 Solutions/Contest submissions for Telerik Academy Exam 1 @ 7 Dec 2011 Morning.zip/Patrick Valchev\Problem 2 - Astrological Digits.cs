using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Zad2
{
    class Program
    {
        static void Main(string[] args)
        {
            string k = Console.ReadLine();
            bool isTrue;
            int p = 0;
            
            int digits;
            do
            {
                digits = 0;
                for (int i = 0; i < k.Length; i++)
			    {
                    isTrue = int.TryParse(k[i].ToString(), out p);
                    if (isTrue)
                    {
                        digits = p + digits;
                    }
                            
			    }
                k = digits.ToString();
            }
            while (digits > 9);
            Console.WriteLine(digits);
        }
    }
}
