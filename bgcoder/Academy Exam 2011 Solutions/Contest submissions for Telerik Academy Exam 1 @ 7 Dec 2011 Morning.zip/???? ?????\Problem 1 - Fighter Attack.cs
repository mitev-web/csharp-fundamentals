using System;

namespace FighterAttack
{
    class FighterAttack
    {
        static void Main(string[] args)
        {
            int px1 = int.Parse(Console.ReadLine());
            int py1 = int.Parse(Console.ReadLine());
            int px2 = int.Parse(Console.ReadLine());
            int py2 = int.Parse(Console.ReadLine());
            int fx = int.Parse(Console.ReadLine());
            int fy = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());

            if (((px1 < -100000) || (px1 > 100000)))
            {
                goto Finish;
            }
            if (((py1 < -100000) || (py1 > 100000)))
            {
                goto Finish;
            }
            if (((px2 < -100000) || (px2 > 100000)))
            {
                goto Finish;
            }
            if (((py2 < -100000) || (py2 > 100000)))
            {
                goto Finish;
            }
            if (((fx < -100000) || (fx > 100000)))
            {
                goto Finish;
            }
            if (((fy < -100000) || (fy > 100000)))
            {
                goto Finish;
            }
            if (((d < -100000) || (d > 100000)))
            {
                goto Finish;
            }

            int percentage = 0;
            // 100 %
            if ((fx + d >= px1) && (fx + d <= px2))
            {
                if ((fy <= py1) && (fy >= py2))
                {
                    percentage += 100;
                }
            }
            // 75%
            if ((fx + d + 1 >= px1) && (fx + d + 1 <= px2))
            {
                if ((fy <= py1) && (fy >= py2))
                {
                    percentage += 75;
                }
            }
            // 50% up
            if ((fx + d >= px1) && (fx + d <= px2))
            {
                if ((fy + 1 <= py1) && (fy + 1 >= py2))
                {
                    percentage += 50;
                }
            }
            // 50% down
            if ((fx + d >= px1) && (fx + d <= px2))
            {
                if ((fy - 1 <= py1) && (fy - 1 >= py2))
                {
                    percentage += 50;
                }
            }
            Console.WriteLine("{0}%", percentage);
            Finish:;
        }
    }
}