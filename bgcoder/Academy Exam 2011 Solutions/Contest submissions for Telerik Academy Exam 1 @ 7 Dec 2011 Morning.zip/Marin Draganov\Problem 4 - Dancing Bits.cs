using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem4
{
    class Program
    {
        static void Main()
        {
            int k = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            BigInteger sumNumber = 0;
            int bitsCount = 0;
            BigInteger sumBitsCount = 0;
            int temp;
            int counter = 0;
            int dansingBits = 0;

            for (int i = 0; i < N; i++)
            {
                temp = int.Parse(Console.ReadLine());
                bitsCount = 0;


                for (int j = 0; j < 32; j++)
                {
                    if (temp >> j == 1) bitsCount = j;
                    sumBitsCount = sumBitsCount + bitsCount + 1;
                }

                for (int j = 0; j <= bitsCount; j++)
                {
                    sumNumber <<= 1;
                    sumNumber = sumNumber | (temp >> (bitsCount - j) & 1);
                }
            }


            int currentBit;//1 or 0
            currentBit = (int)sumNumber & 1;

            for (int i = 0; i < sumBitsCount; i++)
            {
                sumNumber = sumNumber >> 1;
                if ((sumNumber & 1) == currentBit)
                {
                    counter++;
                }
                else
                {
                    currentBit = (int)(sumNumber & 1);
                        if (counter == (k-1) ) dansingBits++;
                    counter = 0;
                }

            }

            Console.WriteLine(dansingBits);


        }
    }
}