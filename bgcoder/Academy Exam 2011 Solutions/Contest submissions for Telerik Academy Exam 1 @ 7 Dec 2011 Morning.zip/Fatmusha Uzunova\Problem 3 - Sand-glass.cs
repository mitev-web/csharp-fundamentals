using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3_Lastone
{
    class Program
    {
        static void Main(string[] args)
        {
            // Read input
            int N = int.Parse(Console.ReadLine());




            for (int i = 0; i < N; i++)
            {
                for (int j = 1; j < N+1; j++)
                {
                  
                        if (i != j)

                        {
                            if (j > i)
                            {
                                Console.Write("*");
                            }
                            else
                            {
                                Console.Write(".");

                            }

                        }
                        else
                        {
                            Console.Write(".");
                        }
                        
                    
                        
                    


                    

                    
                }
                Console.WriteLine();
            }
 
        }
    }
}
