using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstroDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            double sum = 0;
            string number = Console.ReadLine();
            do
            {
                sum = 0;
                for (int i = 0; i < number.Length; i++)
                {
                    if (number[i]!='.' && number[i]!='-' && number[i]!='+')
                    {
                        double digit = char.GetNumericValue(number[i]);
                        sum += digit;
                    }
                }
                //Console.WriteLine(sum);
                if (sum / 10 > 1)
                {
                    number = sum.ToString();
                }
            }
            while (sum / 10 > 1);
            Console.WriteLine(sum);
        }
        
    }
}
