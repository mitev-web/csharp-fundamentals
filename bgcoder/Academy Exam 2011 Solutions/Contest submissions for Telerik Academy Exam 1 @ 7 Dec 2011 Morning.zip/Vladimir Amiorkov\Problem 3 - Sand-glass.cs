using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_3
{
    class SandGlass
    {
        static void Main(string[] args)
        {
            //int n = 37;
            int n = int.Parse(Console.ReadLine());
            char dot = '.';
            char star = '*';

            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    if (row == col || (n - (row + 1)) == col || col > row && col < (n - (row + 1)) || col < row && col > (n - (row + 1)))
                    {
                        Console.Write(star);
                    }
                    else
                    {
                        Console.Write(dot);
                    }
                }
                Console.WriteLine();
            }
        }
    }
}