using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace astrdig
{
    class Program
    {
        static void Main(string[] args)
        {
            double N = double.Parse(Console.ReadLine());
            int rem = 0;
            int sum = 0;
            int sum2 = 0;
            string str = N.ToString();
           // Console.WriteLine(str);

            int len = str.Length;
            for (int i = 0; i < len; i++)
                if (str[i] != '.'&&str[i]!='-')
                    sum += (int)str[i]-48;

            if (sum > 0 && sum <= 9)
                Console.WriteLine(sum);
         else
            {
                int n = sum;
                while (n > 9)
                {
                  while (n > 0)
                    {
                        rem = n % 10;
                        n /= 10;
                        sum2 += rem;
                    }
                  n = sum2;
                }
                Console.WriteLine(n);
            }

         
        }
    }
}
