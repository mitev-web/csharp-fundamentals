using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3FinalDamnIT
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;


            int n = int.Parse(Console.ReadLine());

            // loop for top pyramid of the diamond

            for (i = n / 2; i >= 0; i--)
            {
                for (j = i; j < n / 2; j++)
                {
                    Console.Write(".");
                }

                for (j = i; j > 0; j--)
                {
                    Console.Write("*");
                }

                for (j = i; j >= 0; j--)
                {
                    Console.Write("*");
                }

                for (j = i; j < n / 2; j++)
                {
                    Console.Write(".");
                }
                Console.Write("\n");

            }



            for (i = n / 2 - 1; i >= 0; i--)
            {

                for (j = i; j > 0; j--)
                {
                    Console.Write(".");

                }

                for (j = i; j < n / 2; j++)
                {
                    Console.Write("*");
                }

                for (j = i; j <= n / 2; j++)
                {
                    Console.Write("*");
                }

                for (j = i; j > 0; j--)
                {
                    Console.Write(".");
                }


                Console.Write("\n");
            }
        }
    }
}
