using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lines
{
    class Program
    {
        static void Main(string[] args)
        {


            int[] numbers = new int[8];
            int[,] matrix = new int[8, 8];

            for (int i = 0; i < 8; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 8; i++)
            {
                int temp = numbers[i];

                for (int j = 7; j >= 0; j--)
                {


                    matrix[i, j] = temp % 2;
                    temp = temp / 2;


                }

            }

            ////////////////////

            /*
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Console.Write(matrix[i, j]);
                }

                Console.WriteLine();
            }
            */
            ////////////////////


            int maxLenght = 0;
            int counter = 0;

            for (int i = 0; i < 8; i++)
            {


                for (int j = 0; j < 8; j++)
                {

                    int tempLenght = 0;

                    if (matrix[i, j] == 1)
                    {
                        int temp = j;
                        while ( (temp <= 7)&&(matrix[i, temp] == 1))
                        {

                            tempLenght = tempLenght + 1;
                            temp = temp + 1;
                        }


                        if (maxLenght == tempLenght)
                        {
                            counter = counter + 1;

                        }

                        if (maxLenght < tempLenght)
                        {
                            counter = 1;
                            maxLenght = tempLenght;
                        }




                    }

                }
            }



            for (int j = 0; j < 8; j++)
            {


                for (int i = 0; i < 8; i++)
                {

                    int tempLenght = 0;

                    if (matrix[i, j] == 1)
                    {
                        int temp = i;
                        while ( (temp <= 7)&&(matrix[temp, j] == 1) )
                        {

                            tempLenght = tempLenght + 1;
                            temp = temp + 1;
                        }


                        if (maxLenght == tempLenght)
                        {
                            counter = counter + 1;

                        }

                        if (maxLenght < tempLenght)
                        {
                            counter = 1;
                            maxLenght = tempLenght;
                        }




                    }
                }


            }










            Console.WriteLine(maxLenght);
            Console.WriteLine(counter);





        }
    }
}
