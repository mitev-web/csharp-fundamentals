using System;

namespace _5
{
    class Program
    {
        static void Main(string[] args)
        {
            const int size = 8;
            bool[,] masiv = new bool[size, size];
            int[] n = new int[size];
            string str;
            for (int i = 0; i < size; i++)
            {
                str = "";
                n[i] = int.Parse(Console.ReadLine());
                if (n[i] == 0)
                {
                    for (int k = 0; k < size; k++)
                    {
                        str += 0;
                    }
                }
                else
                {
                    int nFloor = (int)Math.Floor(Math.Log(n[i], 2)) + 1;
                    for (int k = 0; k < size - nFloor; k++)
                    {
                        str += 0;
                    }
                }
                str += Convert.ToString(n[i], 2);
                for (int k = 0; k < size; k++)
                {
                    if (str[k] == '1')
                    {
                        masiv[i, k] = true;
                    }
                }
            }
            int[] counter = new int[8];
            int counter2 = 0;
            int counter3 = 0;
            bool flag = false;
            bool lampa = false;
            for (int i = 0; i < size; i++)
            {
                for (int k = 0; k < size; k++)
                {
                    if (masiv[i, k] == true)
                    {
                        counter2++;
                        counter[k]++;
                    }
                }
            }
            if (counter2 == 64)
            {
                Console.WriteLine("No");
            }
            else
            {
                if (counter2 % 2 == 0)
                {
                    for (int k = 0; k < size; k++)
                    {
                        for (int i = 0; i < size; i++)
                        {
                            if (masiv[i, k] == true)
                            {
                                counter3++;
                            }
                            if (counter3 == counter2 / 2)
                            {
                                for (int l = 0; l <= 8; l += 2)
                                {
                                    if (counter[k] == l)
                                    {
                                        flag = true;
                                        lampa = true;
                                        Console.WriteLine(7 - k);
                                        Console.WriteLine(counter2 / 2 - counter[k] / 2);
                                        break;
                                    }
                                    else if (counter[k] == l + 1)
                                    {
                                        flag = true;
                                        lampa = true;
                                        Console.WriteLine("No");
                                        break;
                                    }
                                }
                                if (lampa == true)
                                {
                                    break;
                                }
                            }
                        }
                        if (flag == true)
                        {
                            break;
                        }
                    }
                }
                else if (counter2 % 2 == 1)
                {
                    for (int k = 0; k < size; k++)
                    {
                        for (int i = 0; i < size; i++)
                        {
                            if (masiv[i, k] == true)
                            {
                                counter3++;
                            }
                            if (counter3 == counter2 / 2 + 1)
                            {
                                for (int l = 1; l < 8; l += 2)
                                {
                                    if (counter[k] == l)
                                    {
                                        flag = true;
                                        lampa = true;
                                        Console.WriteLine(7 - k);
                                        Console.WriteLine(counter2 / 2 - counter[k] / 2);
                                        break;
                                    }
                                    else if (counter[k] == l + 1)
                                    {
                                        flag = true;
                                        lampa = true;
                                        Console.WriteLine("No");
                                        break;
                                    }
                                }
                                if (lampa == true)
                                {
                                    break;
                                }
                            }
                        }
                        if (flag == true)
                        {
                            break;
                        }
                    }
                }
            }
        }
    }
}