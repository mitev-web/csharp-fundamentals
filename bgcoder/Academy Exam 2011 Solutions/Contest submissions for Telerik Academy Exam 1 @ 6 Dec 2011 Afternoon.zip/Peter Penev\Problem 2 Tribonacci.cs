using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _9.FibonacciSequence
{
    class FibonacciSequence
    {
        static void Main(string[] args)
        {
            string line1 = Console.ReadLine();
            BigInteger fibonacciValue1 = BigInteger.Parse(line1);

            string line2 = Console.ReadLine();
            BigInteger fibonacciValue2 = BigInteger.Parse(line2);

            string line3 = Console.ReadLine();
            BigInteger fibonacciValue3 = BigInteger.Parse(line3);

            BigInteger fibonacciValue4 = 0;

            string number = Console.ReadLine();
            int n = int.Parse(number);

            for (int i = 4; i <= n; i++)
            {
                fibonacciValue4 = fibonacciValue1 + fibonacciValue2 + fibonacciValue3;

                fibonacciValue1 = fibonacciValue2;
                fibonacciValue2 = fibonacciValue3;
                fibonacciValue3 = fibonacciValue4;

            }
            Console.WriteLine(fibonacciValue4);
        }
    }
}