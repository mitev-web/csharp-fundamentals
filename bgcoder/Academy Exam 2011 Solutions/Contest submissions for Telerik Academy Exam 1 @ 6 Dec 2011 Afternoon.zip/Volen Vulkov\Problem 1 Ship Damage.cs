using System;
 
namespace _01.ShipDamage
{
    class Program
    {
        static string Percantage(int number)
        {
            return number.ToString() + "%";
        }
 
 
        static int isInside(int height, int cY, int cX, int sY1, int sY2, int sX1, int sX2)
        {
            bool isInside = false;
             
            if (height > cY)
            {
                if  ( ( (height-cY)*2 + cY > sY1 ) && ( (height-cY)*2 + cY < sY2 ) )
                {
                    isInside = true;                   
                }
                if (((height - cY) * 2 + cY < sY1) && ((height - cY) * 2 + cY > sY2))
                {
                    isInside = true;
                }
 
                 
            }
 
            if (height < cY)
            {
                if ((cY - (cY - height) * 2 > sY1) && (cY - (cY - height) * 2 < sY2))
                {
                    isInside = true;
                }
                if ((cY - (cY - height) * 2 < sY1) && (cY - (cY - height) * 2 > sY2))
                {
                    isInside = true;
                }
 
            }
 
            isInside = isInside && (((cX < sX1) && (cX > sX2)) || ((cX > sX1) && (cX < sX2)));
 
            if (isInside == true)
            {
                return 100;
            }
 
            return 0;
        }
 
        static int isInTheCorners(int height, int cY, int cX, int sY1, int sY2, int sX1, int sX2)
        {
            bool isInTheCorners = false;
 
            if (height > cY)
            {
                if (((height - cY) * 2 + cY == sY1) || ((height - cY) * 2 + cY == sY2))
                {
                    isInTheCorners = true;
                }
                 
            }
 
            if (height < cY)
            {
                if ((cY - (cY - height) * 2 == sY1) || (cY - (cY - height) * 2 == sY2))
                {
                    isInTheCorners = true;
                }
                 
            }
 
            isInTheCorners = isInTheCorners && (((cX == sX1) || (cX == sX2)));
 
            if (isInTheCorners == true)
            {
                return 25;
            }
 
            return 0;
        }
 
        static int isLeftOrRightSide(int height, int cY, int cX, int sY1, int sY2, int sX1, int sX2)
        {
            bool isSide = false;
 
            if (height > cY)
            {
                if (((height - cY) * 2 + cY > sY1) && ((height - cY) * 2 + cY < sY2))
                {
                    isSide = true;
                }
                if (((height - cY) * 2 + cY < sY1) && ((height - cY) * 2 + cY > sY2))
                {
                    isSide = true;
                }
                 
            }
 
 
 
            if (height < cY)
            {
                if ((cY - (cY - height) * 2 > sY1) && (cY - (cY - height) * 2 < sY2))
                {
                    isSide = true;
                }
                if ((cY - (cY - height) * 2 < sY1) && (cY - (cY - height) * 2 > sY2))
                {
                    isSide = true;
                }
 
            }
 
 
 
            isSide = isSide && (((cX == sX1) || (cX == sX2)));
 
            if (isSide == true)
            {
                return 50;
            }
 
            return 0;
        }
 
        static int isDownOrUpSide(int height, int cY, int cX, int sY1, int sY2, int sX1, int sX2)
        {
            bool isSide = false;
 
            if (height > cY)
            {
                if (((height - cY) * 2 + cY == sY1) || ((height - cY) * 2 + cY == sY2))
                {
                    isSide = true;
                }
                 
            }
 
 
 
            if (height < cY)
            {
                if ((cY - (cY - height) * 2 == sY1) || (cY - (cY - height) * 2 == sY2))
                {
                    isSide = true;
                }
                 
            }
 
 
 
            isSide = isSide && (((cX < sX1) && (cX > sX2)) || ((cX > sX1) && (cX < sX2)));
 
            if (isSide == true)
            {
                return 50;
            }
 
            return 0;
        }
 
        static int ShootResult(int height, int cY, int cX, int sY1, int sY2, int sX1, int sX2)
        {
            return isInside(height, cY, cX, sY1, sY2, sX1, sX2) + isInTheCorners(height, cY, cX, sY1, sY2, sX1, sX2) + isLeftOrRightSide(height, cY, cX, sY1, sY2, sX1, sX2) + isDownOrUpSide(height, cY, cX, sY1, sY2, sX1, sX2);
        }
 
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
 
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
 
            int h = int.Parse(Console.ReadLine());
 
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
 
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
 
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
 
            int result = ShootResult(h, cY1, cX1, sY1, sY2, sX1, sX2) + ShootResult(h, cY2, cX2, sY1, sY2, sX1, sX2) + ShootResult(h, cY3, cX3, sY1, sY2, sX1, sX2);
 
            Console.WriteLine(Percantage(result));
                       
 
         }
    }
}