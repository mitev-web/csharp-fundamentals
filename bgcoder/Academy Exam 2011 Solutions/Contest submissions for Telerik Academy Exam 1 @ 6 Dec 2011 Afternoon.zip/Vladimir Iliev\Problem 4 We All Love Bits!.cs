using System;
using System.Collections.Generic;

namespace WeLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort n = 0;
            n = ushort.Parse(Console.ReadLine());
            uint[] numbersArray = new uint[n];
            uint[] invertedArray = new uint[n];
            uint[] reversedArray = new uint[n];
            uint[] resultArray = new uint[n];
            for (int i = 0; i < n; i++)
            {
                // read next number
                numbersArray[i] = uint.Parse(Console.ReadLine());
                //numbersArray[0] =19;
                //numbersArray[1] = 224;
                //numbersArray[2] = 96;
                //numbersArray[3] = 7;
                //numbersArray[4] = 6;
                //numbersArray[5] = 0;
                //numbersArray[6] = 0;
                //numbersArray[7] = 0;
                reversedArray[i] =  Convert.ToUInt32(ReverseString(Convert.ToString(numbersArray[i], 2)),2);
                invertedArray[i] = ~numbersArray[i];
                resultArray[i] = (numbersArray[i] ^ invertedArray[i]) & reversedArray[i];

                ////test
                //Console.WriteLine(Convert.ToString(numbersArray[0], 2).PadLeft(32, '0'));
                //Console.WriteLine(Convert.ToString(reversedArray[0], 2).PadLeft(32, '0'));
                //Console.WriteLine(Convert.ToString(invertedArray[i], 2).PadLeft(32, '0'));
                //Console.WriteLine();
            }
            foreach (uint number in resultArray)
            {
                Console.WriteLine(number);
            }
        }

        static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
