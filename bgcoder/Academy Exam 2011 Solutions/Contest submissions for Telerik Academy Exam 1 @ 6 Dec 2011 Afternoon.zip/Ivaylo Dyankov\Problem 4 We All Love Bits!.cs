using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BitOperations
{
    class Program
    {
        static int ReverseOnesAndZeroes(int input)
        {
            int result = 0;
            int mask = 0;
            int counter = 0;

            result = ~input;

            while (0 != input)
            {
                mask |= (1 << counter);
                counter++;
                input >>= 1;
            }

            result &= mask;

            return result;
        }


        static int ReversedNumber(int input)
        {
            int result = 0;

            while (0 != input)
            {
                result <<= 1;
                result |= (input & 0x1);
                input >>= 1;
            }

            return result;
        }

        static void Main(string[] args)
        {
            UInt16 N = UInt16.Parse(Console.ReadLine());

            for (int i = 0; i < N; i++)
            {
                int input = int.Parse(Console.ReadLine());
                Console.WriteLine("{0}", ((input ^ ReverseOnesAndZeroes(input)) & ReversedNumber(input)));
            }
        }
    }
}
