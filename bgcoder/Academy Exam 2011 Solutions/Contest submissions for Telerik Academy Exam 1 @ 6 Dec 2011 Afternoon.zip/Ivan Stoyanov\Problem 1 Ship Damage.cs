using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H   = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());

            if (Sx1 > Sx2 && Sy1 < Sy2)
            {
                int tmp = Sx1;
                Sx1 = Sx2;
                Sx2 = tmp;
                tmp = Sy1;
                Sy1 = Sy2;
                Sy2 = tmp;
            }
            else if (Sx1 < Sx2 && Sy1 < Sy2)
            {
                //int tmp = Sx1;
                //Sx1 = Sx2;
                //Sx2 = tmp;
               int  tmp = Sy1;
                Sy1 = Sy2;
                Sy2 = tmp;
            }
            else if (Sx1 > Sx2 && Sy1 > Sy2)
            {
                int tmp = Sx1;
                Sx1 = Sx2;
                Sx2 = tmp;
            }

            int damage = 0;
            int impact1,impact2,impact3;
                impact1 = 2 * H - Cy1;
                impact2 = 2 * H - Cy2;
                impact3 = 2 * H - Cy3;                          

            if ((impact1 == Sy1 && Cx1 == Sx1) || (impact1 == Sy1 && Cx1 == Sx2) || (impact1 == Sy2 && Cx1 == Sx1) || (impact1 == Sy2 && Cx1 == Sx2)) damage += 25;
            else if (Cx1 == Sx1 && (impact1 > Sy2 && impact1 < Sy1)) damage += 50;
            else if (Cx1 == Sx2 && (impact1 > Sy2 && impact1 < Sy1)) damage += 50;
            else if (impact1 == Sy1 && (Cx1 > Sx1 && Cx1 < Sx2)) damage += 50;
            else if (impact1 == Sy2 && (Cx1 > Sx1 && Cx1 < Sx2)) damage += 50;
            else if ((impact1 > Sy2 && impact1 < Sy1) && (Cx1 > Sx1 && Cx1 < Sx2)) damage += 100;

            if ((impact2 == Sy1 && Cx2 == Sx1) || (impact2 == Sy1 && Cx2 == Sx2) || (impact2 == Sy2 && Cx2 == Sx1) || (impact2 == Sy2 && Cx2 == Sx2)) damage += 25;
            else if (Cx2 == Sx1 && (impact2 > Sy2 && impact2 < Sy1)) damage += 50;
            else if (Cx2 == Sx2 && (impact2 > Sy2 && impact2 < Sy1)) damage += 50;
            else if (impact2 == Sy1 && (Cx2 > Sx1 && Cx2 < Sx2)) damage += 50;
            else if (impact2 == Sy2 && (Cx2 > Sx1 && Cx2 < Sx2)) damage += 50;
            else if ((impact2 > Sy2 && impact2 < Sy1) && (Cx2 > Sx1 && Cx2 < Sx2)) damage += 100;

            if ((impact3 == Sy1 && Cx3 == Sx1) || (impact3 == Sy1 && Cx3 == Sx2) || (impact3 == Sy2 && Cx3 == Sx1) || (impact3 == Sy2 && Cx3 == Sx2)) damage += 25;
            else if (Cx3 == Sx1 && (impact3 > Sy2 && impact3 < Sy1)) damage += 50;
            else if (Cx3 == Sx2 && (impact3 > Sy2 && impact3 < Sy1)) damage += 50;
            else if (impact3 == Sy1 && (Cx3 > Sx1 && Cx3 < Sx2)) damage += 50;
            else if (impact3 == Sy2 && (Cx3 > Sx1 && Cx3 < Sx2)) damage += 50;
            else if ((impact3 > Sy2 && impact3 < Sy1) && (Cx3 > Sx1 && Cx3 < Sx2)) damage += 100;

            Console.WriteLine("{0}%", damage);
            
        }
    }
}
