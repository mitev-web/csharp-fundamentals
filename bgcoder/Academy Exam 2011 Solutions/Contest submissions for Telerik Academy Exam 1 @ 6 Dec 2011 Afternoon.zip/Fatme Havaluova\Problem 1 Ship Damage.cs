using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace problem1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
  
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
  
            int h = int.Parse(Console.ReadLine());
  
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
  
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
  
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
  
            int width  = Math.Abs(Sx1 - Sx2);
            int height = Math.Abs(Sy1 - Sy2);
  
            int count = 0;
  
           /*  int h = int.Parse(Console.ReadLine());
  
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine()); */
  
            //if( findShootPosition(Cx1,Cy1,h)) )
  
            int CnewY1 = findShootPosition(Cx1, Cy1, h);
            int CnewY2 = findShootPosition(Cx2, Cy2, h);
            int CnewY3 = findShootPosition(Cx3, Cy3, h);
  
         //   Console.WriteLine("newY1 is: " + CnewY1 + " newY2 is: " + CnewY2 + " newY3 is: " + CnewY3);
  
        //    Console.WriteLine("cx3 is: " + Cx3 + " cy3 is: " + CnewY3 + " sx2 is :" + Sx2 + " sy2 is: " + Sy2);
  
       //     Console.WriteLine(isTwoPointsEq(Cx3, CnewY3, Sx2, Sy2));
  
            /* if some ot poitns shoot corner */
  
            
            if (isTwoPointsEq(Cx3, CnewY3, Sx2, Sy2) == true) count += 25;
            if (isTwoPointsEq(Cx3, CnewY3, Sx1, Sy1) == true) count += 25;
            if (isTwoPointsEq(Cx2, CnewY2, Sx2, Sy2) == true) count += 25;
            if (isTwoPointsEq(Cx2, CnewY2, Sx1, Sy1) == true) count += 25;
            if (isTwoPointsEq(Cx1, CnewY1, Sx2, Sy2) == true) count += 25;
            if (isTwoPointsEq(Cx1, CnewY1, Sx1, Sy1) == true) count += 25;
  
  
          //  Console.WriteLine("count is: " + count);
  
            int result = count + solve(Cx1, CnewY1, Sx1, Sy1, Sx2, Sy2) + solve(Cx2, CnewY2, Sx1, Sy1, Sx2, Sy2) + solve(Cx3, CnewY3, Sx1, Sy1, Sx2, Sy2);
  
            Console.WriteLine(result +"%");
  
           // Console.WriteLine(solve(Cx2, CnewY2, Sx1, Sy1, Sx2, Sy2));
  
        }
        static int findShootPosition(int x, int y, int hLine)
        {
             int newY = y + 2 * Math.Abs(y - hLine);
            //int newY = Math.Abs(y) + Math.Abs(hLine);
            return newY;
        }
        static int solve(int x,int y,int sx1,int sy1, int sx2, int sy2)
        {
            int sum = 0;
            int minY = (sy1 < sy2) ? sy1 : sy2;
            int maxY = (sy1 > sy2) ? sy1 : sy2;
            int minX = (sx1 < sx2) ? sx1 : sx2;
            int maxX = (sx1 > sx2) ? sx1 : sx2;
  
            if ((y > minY) && (y < maxY) && (x > minX) && (x < maxX)) sum += 100;
            if ((x > minX) && (x < maxX) && y == sy1) sum += 50;
            if ((x > minX) && (x < maxX) && y == sy2) sum += 50;
            if ((y > minY) && (y < maxY) && x == sx1) sum += 50;
            if ((y > minY) && (y < maxY) && x == sx2) sum += 50;
               
            return sum;
  
        }
        /* static int border(int x, int y, int sx1, int sy1, int sx2, int sy2)
        {
  
        } */
        static bool isTwoPointsEq(int x1, int y1, int x2, int y2)
        {
            return ((x1 == x2) && (y1 == y2)) ? true : false;
        }
    }
}