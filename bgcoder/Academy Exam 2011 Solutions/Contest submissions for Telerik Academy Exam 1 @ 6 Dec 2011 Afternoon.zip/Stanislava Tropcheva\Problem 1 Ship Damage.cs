using System;


namespace _4
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
            int cX1 = cx1;
            int cY1 = (-(cy1)) + h+1;
            int cX2 = cx2;
            int cY2 = (-(cy2)) + h+1 ;
            int cX3 = cx3;
            int cY3 = (-(cy3)) + h+1 ;
            decimal p = 0;
            decimal sum=0;



            if (((cX1==sx1)&&(cY1==sy1)) ||((cX1==sx1)&&(cY1==sy2))||((cX1==sx2)&&(cY1==sy1))||((cX1==sx2)&&(cY1==sy2)))
            {
                p = 0.25m;
                sum += p;

            }
            else if (((cX2==sx1)&&(cY2==sy1)) ||((cX2==sx1)&&(cY2==sy2))||((cX2==sx2)&&(cY2==sy1))||((cX2==sx2)&&(cY2==sy2)))
            {
                p = 0.25m;
                sum += p;
            }
            else if (((cX3 == sx1) && (cY3 == sy1)) || ((cX3 == sx1) && (cY3 == sy2)) || ((cX3 == sx2) && (cY3 == sy1)) || ((cX3 == sx2) && (cY3 == sy2)))
            {
                p = 0.25m;
                sum += p;

            }
           

            //
                if (((cX1 == sx1) || (cX1 == sx2)) && (cY1 > sy2) && (cY1 < sy1))
                {
                    p = 0.5m;
                    sum += p;   
                }
                if (((cX2 == sx1) || (cX2 == sx2)) && (cY2 > sy2) && (cY2 < sy1))
                {
                    p = 0.5m;
                    sum += p;
                }
                if (((cX3 == sx1) || (cX3 == sx2)) && (cY3 > sy2) && (cY3 < sy1))
                {
                    p = 0.5m;
                    sum += p;
                }
                    //
                else if ((cY1 == sy1)  && (cX1 > sx1) && (cX1 < sx2))
                {
                    p = 0.5m;
                    sum += p; 
                }
            else if ((cY2 == sy1)  && (cX2 > sx1) && (cX2 < sx2))
                {
                    p = 0.5m;
                    sum += p; 
                }
                else if ((cY3 == sy1) && (cX3 > sx1) && (cX3 < sx2))
                {
                    p = 0.5m;
                    sum += p;
                }

            
                else if ((cY3 == sy2) && (cX3 < sx1) && (cX3 > sx2))
                {
                    p = 0.5m;
                    sum += p;   
                }
                else if ((cY2 == sy2) && (cX2 < sx1) && (cX2 > sx2))
                {
                    p = 0.5m;
                    sum += p;
                }
                else if ((cY1 == sy2) && (cX1 < sx1) && (cX1 > sx2))
                {
                    p = 0.5m;
                    sum += p;
                }
                //
                else if (((cX1 > sx2) && (cY1 <sy2))||((cX1<sx2)&&(cY1<sy1))||((cX1>sx1)&&(cY1>sy2))||((cX1<sx1)&&(cY1>sy1)) )
                {
                    p = 1.0m;
                    sum += p;

                }
                else if (((cX2 > sx2) && (cY2 < sy2)) || ((cX2 < sx2) && (cY2 < sy1)) || ((cX2 > sx1) && (cY2 > sy2)) || ((cX2 < sx1) && (cY2 > sy1)))
                {
                    p = 1.0m;
                    sum += p;

                }
                else if (((cX3 > sx2) && (cY3 < sy2)) || ((cX3 < sx2) && (cY3 < sy1)) || ((cX3 > sx1) && (cY3 > sy2)) || ((cX3 < sx1) && (cY3 > sy1)))
                {
                    p = 1.0m;
                    sum += p;

                }
                
            
            Console.WriteLine("{0:p0}", sum);
            }
             
          
            } 

        }
    

