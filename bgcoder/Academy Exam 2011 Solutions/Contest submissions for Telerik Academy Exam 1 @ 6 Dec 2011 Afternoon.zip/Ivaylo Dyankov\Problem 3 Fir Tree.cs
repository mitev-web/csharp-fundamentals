using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte inputN = byte.Parse(Console.ReadLine());
            
            for (int i = 0; i < inputN; i++)
            {
                if (i < inputN - 1)
                {
                    for (int j = 0; j < ((2 * (inputN - 1)) - 1); j++)
                    {
                        if ((j < (inputN - 2) - i) || (j > (inputN - 2) + i))
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                    Console.WriteLine();
                }
                else
                {
                    for (int j = 0; j < ((2 * (inputN - 1)) - 1); j++)
                    {
                        if ((j < inputN - 2) || (j > inputN - 2))
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                }
            }
        }
    }
}
