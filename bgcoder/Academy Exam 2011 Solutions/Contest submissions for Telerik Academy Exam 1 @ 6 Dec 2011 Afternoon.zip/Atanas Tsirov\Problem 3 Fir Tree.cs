using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());
            int i = 0; // incrementer par 2
            int nombreEtoiles = 1;
            uint hauteur = n;

            for (int j = 0; j < 200 *n; j++)
            {

                for (int k = 1; n - k > 0; )
                {
                    Console.Write(".");
                    k++;
                }

                for (int k = 0; k < nombreEtoiles; )
                {
                    Console.Write("*");
                    k++;
                }
                for (int k = 1; n - k > 0; )
                {
                    Console.Write(".");
                    k++;
                }

                nombreEtoiles += 2;
                i += 2;
                n--;
            

                Console.WriteLine("");
            }

            for (int m = 0; m < hauteur/2 - 1; m++)
            {
                for (int l = 0; l < hauteur - 1; l++)
                {
                    Console.Write(".");
                }
                Console.Write("*");
                for (int l = 0; l < hauteur - 1; l++)
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}