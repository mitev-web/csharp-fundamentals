using System;

class Pillars
{
    static void Main()
    {
        byte n0, n1, n2, n3, n4, n5, n6, n7;
        n0 = byte.Parse(Console.ReadLine());
        n1 = byte.Parse(Console.ReadLine());
        n2 = byte.Parse(Console.ReadLine());
        n3 = byte.Parse(Console.ReadLine());
        n4 = byte.Parse(Console.ReadLine());
        n5 = byte.Parse(Console.ReadLine());
        n6 = byte.Parse(Console.ReadLine());
        n7 = byte.Parse(Console.ReadLine());
        byte n0Count, n1Count, n2Count, n3Count, n4Count, n5Count, n6Count, n7Count;
        n0Count = n1Count = n2Count = n3Count = n4Count = n5Count = n6Count = n7Count = 0;
        int zeroRowCounter = 0;
        int firstRowCounter = 0;
        int secondRowCounter = 0;
        int thirthRowCounter = 0;
        int fourthRowCounter = 0;
        int fifthRowCounter = 0;
        int sixthRowCounter = 0;
        int seventhRowCounter = 0;
        int counter = 0;
        for (int i = 0; i < 8; i++)
        {
            byte number = GetBitValueAtPositon(n0, i);
            if (number == 1)
            {
                n0Count++;
            }
            number = GetBitValueAtPositon(n1, i);
            if (number == 1)
            {
                n1Count++;
            }
            number = GetBitValueAtPositon(n2, i);
            if (number == 1)
            {
                n2Count++;
            }
            number = GetBitValueAtPositon(n3, i);
            if (number == 1)
            {
                n3Count++;
            }
            number = GetBitValueAtPositon(n4, i);
            if (number == 1)
            {
                n4Count++;
            }
            number = GetBitValueAtPositon(n5, i);
            if (number == 1)
            {
                n5Count++;
            }
            number = GetBitValueAtPositon(n6, i);
            if (number == 1)
            {
                n6Count++;
            }
            number = GetBitValueAtPositon(n7, i);
            if (number == 1)
            {
                n7Count++;
            }

            counter = n0Count + n1Count + n3Count + n4Count + n2Count + n5Count + n6Count + n7Count;

            switch (i)
            {
                case 0:
                    zeroRowCounter = counter;
                    break;
                case 1:
                    firstRowCounter = counter;
                    break;
                case 2:
                    secondRowCounter = counter;
                    break;
                case 3:
                    thirthRowCounter = counter;
                    break;
                case 4:
                    fourthRowCounter = counter;
                    break;
                case 5:
                    fifthRowCounter = counter;
                    break;
                case 6:
                    sixthRowCounter = counter;
                    break;
                case 7:
                    seventhRowCounter = counter;
                    break;
                default:
                    break;
            }
            n0Count = n1Count = n2Count = n3Count = n4Count = n5Count = n6Count = n7Count = 0;
            counter = 0;
            
        }
        if (zeroRowCounter + firstRowCounter + secondRowCounter + thirthRowCounter + fourthRowCounter + fifthRowCounter + seventhRowCounter == 0)
        {
            Console.WriteLine("7");
            Console.WriteLine(0);
        }
        else
        {
            if (zeroRowCounter + firstRowCounter + secondRowCounter + thirthRowCounter + fourthRowCounter + fifthRowCounter == seventhRowCounter)
            {
                Console.WriteLine("6");
                Console.WriteLine(seventhRowCounter);
            }
            else
            {
                if (zeroRowCounter + firstRowCounter + secondRowCounter + thirthRowCounter + fourthRowCounter == sixthRowCounter + seventhRowCounter)
                {
                    Console.WriteLine("5");
                    Console.WriteLine(sixthRowCounter + seventhRowCounter);
                }

                else
                {
                    if (zeroRowCounter + firstRowCounter + secondRowCounter + thirthRowCounter == fifthRowCounter + sixthRowCounter + seventhRowCounter)
                    {
                        Console.WriteLine("4");
                        Console.WriteLine(zeroRowCounter + firstRowCounter + secondRowCounter + thirthRowCounter);
                    }
                    else
                    {
                        if (zeroRowCounter + firstRowCounter + secondRowCounter == fourthRowCounter + fifthRowCounter + sixthRowCounter + seventhRowCounter)
                        {
                            Console.WriteLine("3");
                            Console.WriteLine(zeroRowCounter + firstRowCounter + secondRowCounter);
                        }

                        else
                        {
                            if (zeroRowCounter + firstRowCounter == thirthRowCounter + fourthRowCounter + fifthRowCounter + sixthRowCounter + seventhRowCounter)
                            {
                                Console.WriteLine("2");
                                Console.WriteLine(zeroRowCounter + firstRowCounter);
                            }


                            else
                            {
                                if (zeroRowCounter == secondRowCounter + thirthRowCounter + fourthRowCounter + fifthRowCounter + sixthRowCounter + seventhRowCounter)
                                {
                                    Console.WriteLine("1");
                                    Console.WriteLine(zeroRowCounter);
                                }
                                else
                                {
                                    Console.WriteLine("No");
                                }
                            }
                        }
                    }
                }
            }
        }
        //int n = 8;
        //int[] array = new int[8];
        //array[0] = zeroRowCounter;
        //array[1] = firstRowCounter;
        //array[2] = secondRowCounter;
        //array[3] = thirthRowCounter;
        //array[4] = fourthRowCounter;
        //array[5] = fifthRowCounter;
        //array[6] = sixthRowCounter;
        //array[7] = seventhRowCounter;
        //int summ = 0;
        //int summ2 = 0;
        //for (int i = 0; i < n; i++)
        //{
        //    summ = array[0];
        //    for (int j = i + 1; j < n; j++)
        //    {
        //        summ2 = summ2 + array[j];

        //    }
        //}

    }

    static byte GetBitValueAtPositon(byte number, int index)
    {
        byte numberAtIndex = (byte)(number >> index);
        byte mask = (byte)(numberAtIndex & 1);
        if (mask == 1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}