using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03
{
    class Tree
    {
        static void Main(string[] args)
        {
            int height = int.Parse(Console.ReadLine());
            int width = 2 * height - 3;
            int simet= width/2 -1 ;
            int simet2 = simet;
            int width2 = width;
            int t= 3;
            int change =2;
            for (int i = 0; i < width -1; i++)
            {
                Console.Write(".");
                if (i == simet)
                {
                    Console.Write("*");
                }
            }
            Console.WriteLine();
            for (int i = 0; i < height - 3; i++)
            {
                for (int j = 0; j < width  -change ; j++)
                {
                    if (j == simet)
                    {
                        for (int k = j; k < simet + t; k++)
                        {
                            Console.Write("*");
                        }
                        simet--;
                        t = t + 2;                        
                    }
                    else
                    {
                        Console.Write(".");
                    }
                   
                        
			    }
                width = width - 2;
                Console.WriteLine();
                
            }
            for (int b = 0; b < width2; b++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            for (int i = 0; i < width2 - 1; i++)
            {
                Console.Write(".");
                if (i == simet2)
                {
                    Console.Write("*");
                }
            }   
        }
    }
}
