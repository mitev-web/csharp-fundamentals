using System;


namespace test3
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            char star = '.';
            int d = 0;
            int i = 1;
            for (int row = 1; row <= N; row++)
            {
                for (int col = 1; col <= (((N-1)*2)-1); col++)
                {
                    if ((row == 1) && (col == N-1) )
                    {
                        star = '*';
                    }
                    if ((row == 1) && (col == N))
	                {
                        star = '.';
	                }
	                
                    if ((row == i) && (col == N - i) )
                    {
                        star = '*'; 
                    }
                    if ((row == i) && (col == N + d))
                    {
                        star = '.';
                    }
                    if (row == N)
                    {
                        star = '.';
                    }
                    if ((row == N) && (col == N-1 ))
                    {
                        star = '*';
                    }
                    Console.Write(star);
                }
                Console.WriteLine();
                i++;
                d++;
                
            }
    

        }
    }
}
