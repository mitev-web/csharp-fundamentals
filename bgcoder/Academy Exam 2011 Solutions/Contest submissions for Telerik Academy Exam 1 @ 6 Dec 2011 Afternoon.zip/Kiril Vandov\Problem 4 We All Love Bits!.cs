using System;

class WeAllLoveBits
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        while (n > 0)
        {
            string str = Console.ReadLine();

            int p = int.Parse(str);
            str =(Convert.ToString(p, 2));
           
            int number = 0;
            //string str = Convert.ToString(p, 2);
            //Console.WriteLine(str);
            int index = str.Length;
            string test = string.Empty;
            int magicNumber = 0;
            int xorNum = 0;
            int opositeP = ~p;

            for (int i = 0; i < index; i++)
            {
                number = GetBitValueAtPositon(p, i);
                xorNum = magicNumber | number;
                magicNumber = xorNum << 1;
            }
            int pNew = xorNum;
            //Console.WriteLine(pNew);
            int formula = (p ^ opositeP) & pNew;
            Console.WriteLine(formula);
            n--;
        }
    }

    static int GetBitValueAtPositon(int number, int index)
    {
        int numberAtIndex = number >> index;
        int mask = (int)numberAtIndex & 1;
        if (mask == 1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
 