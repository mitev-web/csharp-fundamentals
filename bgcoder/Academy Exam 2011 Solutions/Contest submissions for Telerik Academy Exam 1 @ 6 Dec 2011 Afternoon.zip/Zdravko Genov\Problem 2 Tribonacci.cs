using System;
using System.Numerics;
namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            int position = int.Parse(Console.ReadLine());
            BigInteger next = 0;
            for (int iteration = 1; iteration < position; iteration++)
            {
                next = a + b + c;
                a = b;
                b = c;
                c = next;
            }
            Console.WriteLine(a);
        }
    }
}
