using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger number1 = BigInteger.Parse(Console.ReadLine());
            BigInteger number2 = BigInteger.Parse(Console.ReadLine());
            BigInteger number3 = BigInteger.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());
            BigInteger sum = number1 + number2 + number3;
            for (int i = 1; i <= n - 3; i++)
            {
                sum = number1 + number2 + number3;
                number1 = number2;
                number2 = number3;
                number3 = sum;
            }
            Console.WriteLine(sum);
        }
    }
}
