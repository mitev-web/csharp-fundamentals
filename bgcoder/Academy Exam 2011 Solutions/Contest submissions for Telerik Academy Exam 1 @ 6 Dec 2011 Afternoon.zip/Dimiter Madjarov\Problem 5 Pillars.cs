using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.Pillars
{
	class Pillars
	{
		static void Main(string[] args)
		{
			int[] numbers = new int[8];
			for (int i = 0; i < 8; i++)
			{
				numbers[i] = int.Parse(Console.ReadLine());
			}

			int pillarCollumn = 0;
			int leftRightCount = 0;
			int leftCellsCount = 0;
			int rightCellsCount = 0;
			int unsuccessfulTries = 0;

			if ((numbers[0] == 0) && (numbers[1] == 0) && (numbers[2] == 0) && (numbers[3] == 0) &&
				(numbers[4] == 0) && (numbers[5] == 0) && (numbers[6] == 0) && (numbers[7] == 0) )
			{
				Console.WriteLine("No");
				return;
			}

			for (int currentPillarColumn = 6; currentPillarColumn >= 0; currentPillarColumn--)
			{
				leftCellsCount = 0;
				rightCellsCount = 0;
				for (int currentNumber = 0; currentNumber < 8; currentNumber++)
				{
					int tempCurrentNumber = currentNumber;
					for (int currentBit = 0; currentBit < 8; currentBit++)
					{
						if (currentBit == currentPillarColumn)
						{
							continue;
						}

						if (currentBit < currentPillarColumn)
						{
							if (((numbers[tempCurrentNumber] >> currentBit) & 1) > 0)
							{
								rightCellsCount++;
							}
						}

						if (currentBit > currentPillarColumn)
						{
							if (((numbers[tempCurrentNumber] >> currentBit) & 1) > 0)
							{
								leftCellsCount++;
							}
						}
					}
				}
				//after the whole count for current pillar index
				if (leftCellsCount == rightCellsCount)
				{
					pillarCollumn = currentPillarColumn;
					leftRightCount = leftCellsCount;
					break;
				}
				else
				{
					unsuccessfulTries++;
				}
			}
			if (unsuccessfulTries == 7)
			{
				Console.WriteLine("No");
			}
			else
			{
				Console.WriteLine(pillarCollumn);
				Console.WriteLine(leftRightCount);
			}
		}
	}
}
