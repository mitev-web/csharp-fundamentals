using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class task4
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            ulong num;
            ulong num2;
            ulong num3;
            ulong P1=0;
            ulong P2=0;
            
            ulong[] m = new ulong[32];
            ulong[] m2 = new ulong[32];
            ulong[] m3 = new ulong[32];
            int k = 0;
            uint sq = 1;
            int flag = 0;
            int poss=0;
            for (int p = 0; p < N; p++)
            {
                num = ulong.Parse(Console.ReadLine());
                num2 = num;
                num3 = num;
                
                    while (num != 0)
                    {
                        if (num % 2 == 0)
                        {
                            m3[31 - k] = 0;
                            m[31 - k] = 1;
                        }
                        else
                        {
                            m3[31 - k] = 1;
                            m[31 - k] = 0;
                        }
                        num /= 2;
                        k++;
                    }

                    for (int i = 0; i < 32; i++)
                    {
                        P1 += m[31 - i] * (sq);
                        sq *= 2;
                        if (i == 0) sq = 2;
                    }

                  

                    for (int i = 0; i < 32; i++)
                    {

                        if (m3[i] == 1 && flag == 0)
                        {
                            m2[31] = 1;
                            flag = 1;
                            poss++;
                            continue;
                        }
                        if (m3[i] == 1 && flag == 1)
                        {
                            m2[31 - poss] = 1;
                            poss++;
                        }
                        if (m3[i] == 0 && flag == 1)
                        {
                            m2[31 - poss] = 0;
                            poss++;
                        }
                    }

                    sq = 1;
                    for (int i = 0; i < 32; i++)
                    {
                        P2 += m2[31 - i] * (sq);
                        sq *= 2;
                        if (i == 0) sq = 2;
                    }
                   
            Console.WriteLine((num3^P1)&P2);
            P1 = 0;
            P2 = 0;
            k = 0;
            sq = 1;
            poss = 0;
            flag = 0;
            num3 = 0;

            for (int i = 0; i < 32; i++) m[i] = 0;
            for (int i = 0; i < 32; i++) m2[i] = 0;
            for (int i = 0; i < 32; i++) m3[i] = 0;
            }
            
            

        }
    }
}
