using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Ex._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            double Sx1 = double.Parse(Console.ReadLine());
            double Sy1 = double.Parse(Console.ReadLine());
            double Sx2 = double.Parse(Console.ReadLine());
            double Sy2 = double.Parse(Console.ReadLine());

            double H = double.Parse(Console.ReadLine());

            double Cx1 = double.Parse(Console.ReadLine());
            double Cy1 = double.Parse(Console.ReadLine());
            double Cx2 = double.Parse(Console.ReadLine());
            double Cy2 = double.Parse(Console.ReadLine());
            double Cx3 = double.Parse(Console.ReadLine());
            double Cy3 = double.Parse(Console.ReadLine());

            double shot1y = ShotYCal(H, Cy1);
            double shot2y = ShotYCal(H, Cy2);
            double shot3y = ShotYCal(H, Cy3);

            int total = 0;
            total += dmgCalc(Sx1, Sy1, Sx2, Sy2, Cx1, shot1y);
            total += dmgCalc(Sx1, Sy1, Sx2, Sy2, Cx2, shot2y);
            total += dmgCalc(Sx1, Sy1, Sx2, Sy2, Cx3, shot3y);
            Console.WriteLine(total+"%");


        }
        static int dmgCalc(double Sx1, double Sy1, double Sx2, double Sy2, double ShotX, double ShotY)
        {
            double leftX;
            double rightX;
            double top;
            double down;

            if (Sx1 < Sx2)
            {
                leftX = Sx1;
                rightX = Sx2;
            }
            else
            {
                leftX = Sx2;
                rightX = Sx1;
            }

            if (Sy1 > Sy2)
            {
                top = Sy1;
                down = Sy2;
            }
            else
            {
                top = Sy2;
                down = Sy1;
            }

            if (ShotX == Sx1 && ShotY == Sy1) 
            {
                return 25;
            }
            if (ShotX == Sx2 && ShotY == Sy2)
            {
                return 25;
            }
            if (ShotX == Sx1 && ShotY == Sy2) 
            {
                return 25;
            }
            if (ShotX == Sx2 && ShotY == Sy1)
            {
                return 25;
            }

            if (ShotX < leftX || ShotX > rightX)
            {
                return 0;
            }
            else
            {
                if (ShotY > top || ShotY < down)
                {
                    return 0;
                }
                if ((ShotY < top && ShotY > down) && (ShotX != leftX && ShotX != rightX))
                {
                    return 100;
                }
                if (ShotY == top && (ShotX != leftX && ShotX != rightX))
                {
                    return 50;
                }

                if (ShotY == down && (ShotX != leftX && ShotX != rightX))
                {
                    return 50;
                }

                //////
                if (ShotX == leftX && (ShotY != top && ShotY != down))
                {
                    return 50;
                }
                if (ShotX == rightX && (ShotY != top && ShotY != down))
                {
                    return 50;
                }
                //return 25;
                return 0;

            }
        }

        //static double ShotYCal(double H, double CY) 
        //{
        //    if (H > 0 && CY > H) 
        //    {
        //        return H - (CY - H);
        //    }
        //    if (H > 0 && CY >= 0) 
        //    {
        //        return H + (H - CY);
        //    }
        //    if (H == 0) 
        //    {
        //        return -CY;
        //    }
        //    if(H>0 && CY<0)
        //    {
        //        return H + (Math.Abs(CY) + H);
        //    }
        //    if (H < 0 && CY > 0) 
        //    {
        //        return H - (CY + Math.Abs(H));
        //    }
        //    if (H < 0 && (CY < 0 && CY > H)) 
        //    {
        //        return H - (Math.Abs(H) - Math.Abs(CY));
        //    }
        //    if (H < 0 && CY < H) 
        //    {
        //        return H + (Math.Abs(CY) - Math.Abs(H));
        //    }
        //    return 0;

        //}

        static double ShotYCal(double H, double CY)
        {
            if (H == CY) 
            {
                return H;
            }
            if (H > 0 && CY > H)
            {
                return H - (CY - H);
            }
            if (H > 0 && CY >= 0)
            {
                return H + (H - CY);
            }
            if (H == 0)
            {
                return -CY;
            }
            if (H > 0 && CY <=0)
            {
                return H + (Math.Abs(CY) + H);
            }
            if (H < 0 && CY >= 0)
            {
                return H - (CY + Math.Abs(H));
            }
            if (H < 0 && (CY <= 0 && CY > H))
            {
                return H - (Math.Abs(H) - Math.Abs(CY));
            }
            if (H < 0 && CY < H)
            {
                return H + (Math.Abs(CY) - Math.Abs(H));
            }
            return 0;

        }
    }
}
