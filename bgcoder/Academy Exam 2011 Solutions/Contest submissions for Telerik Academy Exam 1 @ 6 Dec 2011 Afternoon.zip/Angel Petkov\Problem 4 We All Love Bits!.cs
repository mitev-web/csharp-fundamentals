using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _04.WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {

            ushort n = ushort.Parse(Console.ReadLine());
            uint[] p = new uint[n];

            for (int i = 0; i < n; i++)
            {
                p[i] = uint.Parse(Console.ReadLine());
            }

            uint[] pInv = new uint[n];
            uint[] pRev = new uint[n];

            for (int k = 0; k < n; k++)
            {                
                byte bitCnt = 0;
                uint div = p[k];
                do
                {
                    div >>= 1;
                    bitCnt++;
                } while (div != 0);

                uint mask = uint.MaxValue >> (32 - bitCnt);

                pInv[k] = p[k] ^ mask;


                uint bit1, bit2;
                pRev[k] = p[k];

                for (int i = bitCnt / 2 - 1; i >= 0; i--)
                {
                    mask = 1;
                    mask <<= i;
                    mask &= pRev[k];
                    mask >>= i;
                    bit1 = mask;

                    mask = 1;
                    mask <<= (bitCnt - i - 1);
                    mask &= pRev[k];
                    mask >>= (bitCnt - i - 1);
                    bit2 = mask;

                    if (bit1 == bit2)
                    {
                        continue;
                    }

                    if (bit1 == 0)
                    {
                        mask = 1;
                        mask <<= i;
                        pRev[k] |= mask;

                        mask = 1;
                        mask <<= (bitCnt - i - 1);
                        pRev[k] &= ~mask; //0   

                    }
                    else
                    {
                        mask = 1;
                        mask <<= i;
                        pRev[k] &= ~mask; //0 

                        mask = 1;
                        mask <<= (bitCnt - i - 1);
                        pRev[k] |= mask; //1     


                    }
                } 
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine( (p[i]^pInv[i]) & pRev[i]);
            }

        }
    }
}
