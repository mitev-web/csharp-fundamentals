using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _04.WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            int numberN = Int32.Parse(Console.ReadLine());
            
            for (int i = 0; i < numberN; i++)
            {
                int[] bits = new int[31];
                int[] invertedBits = new int[31];
                int[] reversedBits = new int[31];
                int lastBit = 0;

                int integerP = Int32.Parse(Console.ReadLine());

                for (int j = 0; j < bits.Length; j++)
                {
                    int mask = 1 << j;        
                    int nAndMask = integerP & mask; 
                    bits[j] = nAndMask >> j;

                    if (bits[j] == 1)
                    {
                        lastBit = j;
                    }                
                }

                for (int j = 0; j < 31; j++)
                {
                    if (j <= lastBit && bits[j] == 0)
                    {
                        invertedBits[j] = 1;
                    }
                    else
                    {
                        invertedBits[j] = 0;
                    }
                }

                int invertedP = 0;

                for (int j = 0; j < invertedBits.Length; j++)
                {
                    if (invertedBits[j] == 1)
                    {
                        invertedP += (int)Math.Pow(2, j);
                    }
                }
                
                for (int j = 0, k = lastBit; j <= lastBit; j++, k--)
                {
                    reversedBits[k] = bits[j];
                }

                int reversedP = 0;

                for (int j = 0; j < reversedBits.Length; j++)
                {
                    if (reversedBits[j] == 1)
                    {
                        reversedP += (int)Math.Pow(2, j);
                    }
                }

                Console.WriteLine( (integerP ^ invertedP) & reversedP);          

            }
        }
    }
}
