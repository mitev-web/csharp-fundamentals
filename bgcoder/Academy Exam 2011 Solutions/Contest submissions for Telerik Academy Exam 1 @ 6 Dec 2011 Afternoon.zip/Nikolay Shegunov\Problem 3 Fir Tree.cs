using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam06
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            
            int maxlen = 2*(N - 2) + 1;
            int stars = 1;

            for (int i = 0; i < N - 1; i++)
            {
                for (int j = 0; j <= maxlen; j++)
                {
                    if (j == (maxlen - stars) / 2)
                    {
                        for (int k = 0; k < stars; k++)
                        {
                            Console.Write("*");
                            j = j + 1;
                        }
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.Write("\n");
                stars = stars + 2;
            }

            stars = 1;

            for (int i = 0; i <= maxlen; i++)
            {
                if (i == (maxlen - stars) / 2)
                {
                    Console.Write("*");
                    i = i + 1;
                }

                else
                {
                    Console.Write(".");
                }
            }

            Console.Write("\n");
        }
    }
}
