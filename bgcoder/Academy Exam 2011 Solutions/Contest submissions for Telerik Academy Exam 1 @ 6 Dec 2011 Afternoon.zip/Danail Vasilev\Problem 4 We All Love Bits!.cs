using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
{
    static void Main()
    {
        byte N = byte.Parse(Console.ReadLine());

        for (int g = 1; g < N + 1; g++)
        {
            int theNum = int.Parse(Console.ReadLine());
            int myNum = theNum; // This is inverted number

            //Initializing variables

            //int myNum = 503;
            //Console.WriteLine(Convert.ToString(myNum, 2)); // My check

            //Finding number of digits
            int numDigits = 0;
            int tempNumDigits = myNum;
            while (tempNumDigits != 0)
            {
                tempNumDigits = tempNumDigits >> 1;
                numDigits = numDigits + 1;
            }

            //Console.WriteLine(numDigits);   //My check

            //Check number of digits if it is Odd or Even
            int numDigitsIsOdd = numDigits;
            if ((numDigits % 2) != 0)
            {
                numDigitsIsOdd = numDigits - 1;
            }
            //Console.WriteLine(numDigitsIsOdd);   //my check

            //Calculating second parameter !!

            // Creating masks and bit checkers
            int mask = 1;  //mask with 0001000
            int mask1 = ((int)Math.Pow(2, numDigits) - 1);
            int mask2 = mask1 ^ 1; // mask with 1110111

            int mask_last = 1 << numDigits;  //mask with 0001000
            int mask1_last = ((int)Math.Pow(2, numDigits) - 1);
            int mask2_last = mask1 ^ 1; // mask with 1110111


            int bitChecker = 1;
            int bitChecker2 = 1 << numDigits;

            // Inverting bits
            for (int i = 1; i < (numDigitsIsOdd / 2) + 1; i++)
            {
                int firstBit = myNum & bitChecker;
                int lastBit = myNum & bitChecker2;
                if (firstBit != lastBit)
                {
                    if ((firstBit) == 0)
                    {
                        myNum = myNum | mask; // first bit is 0  makes it 1
                        myNum = myNum & mask2_last; // last bit is 1 makes it 0
                    }
                    else
                    {
                        myNum = myNum & mask2;// first bit is 1 makes it 0
                        myNum = myNum | mask_last; // last bit is 0 makes it 1
                    }
                }


                //Console.WriteLine(Convert.ToString(myNum, 2));
                mask = mask << 1;
                mask2 = mask1 ^ mask;

                mask_last = mask_last >> 1;
                mask2_last = mask1_last ^ mask_last;

                bitChecker = bitChecker << 1;
                bitChecker2 = bitChecker2 >> 1;
                //Console.WriteLine(Convert.ToString(bitChecker2, 2));
                //Console.WriteLine(Convert.ToString(mask2, 2));
                //Console.WriteLine();

                //firstbit i
                //lastbit N - i + 1


                //Calculating 1st P - reversed P

                int myNum2 = myNum;
                mask = 1;  //mask with 0001000
                mask1 = ((int)Math.Pow(2, numDigits) - 1);
                mask2 = mask1 ^ 1; // mask with 1110111
                

                bitChecker = 1;
                bitChecker2 = 1 << numDigits;

                for (int c = 1; i < numDigits + 1; c++)
                {
                    if ((myNum2 & bitChecker) == 0)
                    {
                        myNum2 = myNum2 | mask;
                    }
                    else
                    {
                        myNum2 = myNum2 & mask2;
                    }
                   //Console.WriteLine(Convert.ToString(p, 2));
                    mask = mask << 1;
                    mask2 = mask1 ^ mask;


                    bitChecker = bitChecker << 1;
                    bitChecker2 = bitChecker2 >> 1;
                    //Console.WriteLine(Convert.ToString(mask_last, 2));
                    //Console.WriteLine(Convert.ToString(mask2_last, 2));
                    //Console.WriteLine();
                }
                Console.WriteLine((theNum ^ myNum2) & myNum);

            }
        }
    }
}

