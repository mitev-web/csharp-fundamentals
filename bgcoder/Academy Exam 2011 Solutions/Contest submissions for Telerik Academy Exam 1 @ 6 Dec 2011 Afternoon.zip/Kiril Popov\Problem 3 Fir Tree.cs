using System;

namespace Problem3.FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int asterisks = 1;
            int size = n + (n - 3);
            for (int i = 0; i < n - 1; i++,asterisks+=2)
            {
                drawLineOfTheTree(size, asterisks);
                Console.WriteLine();
            }
            drawLineOfTheTree(size,1);
        }

        private static void drawLineOfTheTree(int size,int asterisks)
        {
            for (int i = 0; i < size; i++)
            {
                if (i < (size / 2) - asterisks / 2 || i > size / 2 + asterisks / 2)
                {
                    Console.Write('.');
                }
                else
                {
                    Console.Write('*');
                }
            }
        }
    }
}