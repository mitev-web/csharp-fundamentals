using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class Program
    {

        static UInt16 DamgeShip(int pointX, int pointY, int shipSX1, int shipSY1, int shipSX2, int shipSY2, int offset)
        {
            UInt16 result = 0;
            int minX = Math.Min(shipSX1, shipSX2);
            int minY = Math.Min(shipSY1, shipSY2);
            int maxX = Math.Max(shipSX1, shipSX2);
            int maxY = Math.Max(shipSY1, shipSY2);

            int DamagePointX = pointX;
            int DamagePointY = offset + (offset - pointY);

            if ((DamagePointX < minX) || (DamagePointX > maxX) || (DamagePointY < minY) || (DamagePointY > maxY))
            {
                result = 0;
            }
            else if ((DamagePointX == minX && DamagePointY == minY) || (DamagePointX == minX && DamagePointY == maxY) ||
                (DamagePointX == maxX && DamagePointY == minY) || (DamagePointX == maxX && DamagePointY == maxY))
            {
                result = 25;
            }
            else if ((DamagePointX == minX) || (DamagePointX == maxX) || (DamagePointY == minY) || (DamagePointY == maxY))
            {
                result = 50;
            }
            else
            {
                result = 100;
            }

            return result;
        }
        static void Main(string[] args)
        {
            int inputSX1 = int.Parse(Console.ReadLine());
            int inputSY1 = int.Parse(Console.ReadLine());
            int inputSX2 = int.Parse(Console.ReadLine());
            int inputSY2 = int.Parse(Console.ReadLine());
            int offsetH = int.Parse(Console.ReadLine());
            int inputCX1 = int.Parse(Console.ReadLine());
            int inputCY1 = int.Parse(Console.ReadLine());
            int inputCX2 = int.Parse(Console.ReadLine());
            int inputCY2 = int.Parse(Console.ReadLine());
            int inputCX3 = int.Parse(Console.ReadLine());
            int inputCY3 = int.Parse(Console.ReadLine());

            UInt16 damageInPerecents = 0;

            damageInPerecents += DamgeShip(inputCX1, inputCY1, inputSX1, inputSY1, inputSX2, inputSY2, offsetH);
            damageInPerecents += DamgeShip(inputCX2, inputCY2, inputSX1, inputSY1, inputSX2, inputSY2, offsetH);
            damageInPerecents += DamgeShip(inputCX3, inputCY3, inputSX1, inputSY1, inputSX2, inputSY2, offsetH);

            Console.WriteLine("{0}%", damageInPerecents);
        }
    }
}
