using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonaccii
{
    class Tribonaccii
    {
        static void Main(string[] args)
        {
            BigInteger tribonacci1 = BigInteger.Parse(Console.ReadLine());
            BigInteger tribonacci2 = BigInteger.Parse(Console.ReadLine());
            BigInteger tribonacci3 = BigInteger.Parse(Console.ReadLine());
            ushort num = ushort.Parse(Console.ReadLine());
            BigInteger tribonacciN = 0;
            if (num < 4)
            {
                Console.WriteLine("Error");
            }
            else
            {
                for (int i = 3; i < num; i++)
                {
                    tribonacciN = tribonacci1 + tribonacci2 + tribonacci3;
                    tribonacci1 = tribonacci2;
                    tribonacci2 = tribonacci3;
                    tribonacci3 = tribonacciN;
                }
                Console.WriteLine(tribonacciN);
            }
        }
    }
}
