
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace exam06
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] cord = new int[11];
            for(int i = 0; i < 11; i++)
            {
                cord[i] = int.Parse(Console.ReadLine());
            }
 
            int wight = Math.Abs(cord[0] - cord[2]);
            int hight = Math.Abs(cord[1] - cord[3]);
 
 
            //cord[4] is H
            int[] hitPointX = new int[3] { 0, 0, 0 };
            int[] hitPointY = new int[3] { 0, 0, 0 };
 
            if (cord[6] < cord[4])
            {
                hitPointY[0] = cord[6] + 2 * Math.Abs(cord[6] - cord[4]);
                hitPointY[1] = cord[8] + 2 * Math.Abs(cord[8] - cord[4]);
                hitPointY[2] = cord[10] + 2 * Math.Abs(cord[10] - cord[4]);
            }
            else
            {
                hitPointY[0] = cord[6] - 2 * Math.Abs(cord[6] - cord[4]);
                hitPointY[1] = cord[8] - 2 * Math.Abs(cord[8] - cord[4]);
                hitPointY[2] = cord[10] - 2 * Math.Abs(cord[10] - cord[4]);
            }
 
            hitPointX[0] = cord[5];
            hitPointX[1] = cord[7];
            hitPointX[2] = cord[9];
 
 
            int demage = 0;
 
            int shipTopLeftX = 0;
            int shipTopLeftY = 0;
 
            if (cord[0] > cord[2] && cord[1] > cord[3])
            {
                shipTopLeftX = cord[0] - wight;
                shipTopLeftY = cord[1];
            }
            else if (cord[0] < cord[2] && cord[1] < cord[3])
            {
                shipTopLeftX = cord[0];
                shipTopLeftY = cord[1] + hight;
            }
            else if ((cord[0] < cord[2] && cord[1] > cord[3]))
            {
                shipTopLeftX = cord[0];
                shipTopLeftY = cord[1];
            }
            else if ((cord[0] > cord[2] && cord[1] < cord[3]))
            {
                shipTopLeftX = cord[2];
                shipTopLeftY = cord[3];
            }
 
            for (int i = 0; i < 3; i++)
            {
                if (((hitPointX[i] == shipTopLeftX) || (hitPointX[i] == shipTopLeftX + wight)) && (hitPointY[i] < shipTopLeftY && hitPointY[i] > (shipTopLeftY - hight)))
                {
                    demage += 50;
                }
 
                if (((hitPointY[i] == shipTopLeftY) || (hitPointY[i] == shipTopLeftY - hight)) && (hitPointX[i] > shipTopLeftX && hitPointX[i] < (shipTopLeftX + wight)))
                {
                    demage += 50;
                }
 
                else if (hitPointX[i] > shipTopLeftX && hitPointX[i] < shipTopLeftX + wight && hitPointY[i] > shipTopLeftY - hight && hitPointY[i] < shipTopLeftY)
                {
                    demage += 100;
                }
                else if ((hitPointX[i] == shipTopLeftX && hitPointY[i] == shipTopLeftY) || (hitPointX[i] == shipTopLeftX + wight && hitPointY[i] == shipTopLeftY) ||
                    (hitPointX[i] == shipTopLeftX && hitPointY[i] == shipTopLeftY - hight) || (hitPointX[i] == shipTopLeftX + wight && hitPointY[i] == shipTopLeftY - hight))
                {
                    demage += 25;
                }
            }
 
            Console.WriteLine("{0}%",demage);
            }
        }
    }