using System;
using System.Numerics;

class Problem2
{    
    static void Main()
    {
        BigInteger currentElementI=0, first, second, third;
        ushort n;

        third = long.Parse(Console.ReadLine());
        second = long.Parse(Console.ReadLine());
        first = long.Parse(Console.ReadLine());
        n = ushort.Parse(Console.ReadLine());

        if (n == 1)
        {
            Console.WriteLine(third);
            return;
        }

        if (n == 2)
        {
            Console.WriteLine(second);
            return;
        }

        if (n == 3)
        {
            Console.WriteLine(first);
            return;
        }

        for (int i = 4; i <= n; i++)
        {
            currentElementI = first + second + third;
            third = second;
            second = first;
            first = currentElementI;
        }

        Console.WriteLine(currentElementI);

    }
}

