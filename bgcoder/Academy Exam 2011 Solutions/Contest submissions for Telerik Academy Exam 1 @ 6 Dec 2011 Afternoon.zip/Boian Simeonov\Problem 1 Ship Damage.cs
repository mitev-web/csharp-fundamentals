using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
  
            int[] ship = new int[4];
            int[] bombs = new int[6];
            int h = 0;
            int hitPoints = 0;
  
            for (int i = 0; i < ship.Length; i++)
            {
                ship[i] = int.Parse(Console.ReadLine());
            }
  
            h = int.Parse(Console.ReadLine());
  
            for (int i = 0; i < bombs.Length; i++)
            {
                bombs[i] = int.Parse(Console.ReadLine());
                if (i % 2 != 0)
                {
                    bombs[i] = -bombs[i];
                    bombs[i] += h * 2;
                }
            }
  
            int counterBomb = 0;
  
            for (int i = 0; i < 3; i++)
            {
                if ((bombs[counterBomb] > ship[0]) && (bombs[counterBomb] < ship[3]) &&
                                                    (bombs[counterBomb + 1] < ship[1]) && (bombs[counterBomb + 1] > ship[3]))
                {
                    hitPoints += 100;
                }
                else if ((bombs[counterBomb] == ship[0]) && (bombs[counterBomb + 1] >= ship[0]) && (bombs[counterBomb + 1] <= ship[3]))
                {
                    if (bombs[counterBomb + 1] == ship[1])
                    {
                        hitPoints += 25;
                    }
                    else if (bombs[counterBomb + 1] == ship[3])
                    {
                        hitPoints += 25;
                    }
                    else
                    {
                        hitPoints += 50;
                    }
                }
  
                else if ((bombs[counterBomb] == ship[2]) && (bombs[counterBomb + 1] <= ship[3]) && (bombs[counterBomb + 1] >= ship[0]))
                {
                    if (bombs[counterBomb + 1] == ship[1])
                    {
                        hitPoints += 25;
                    }
                    else if (bombs[counterBomb + 1] == ship[3])
                    {
                        hitPoints += 25;
                    }
                    else
                    {
                        hitPoints += 50;
                    }
                }
  
                else if ((bombs[counterBomb + 1] == ship[1]) && (bombs[counterBomb] >= ship[0]) && (bombs[counterBomb] <= ship[3]))
                {
                    if (bombs[counterBomb] == ship[0])
                    {
                        hitPoints += 25;
                    }
                    else if (bombs[counterBomb] == ship[2])
                    {
                        hitPoints += 25;
                    }
                    else
                    {
                        hitPoints += 50;
                    }
                }
  
                else if ((bombs[counterBomb + 1] == ship[2]) && (bombs[counterBomb] >= ship[0]) && (bombs[counterBomb] <= ship[3]))
                {
                    if (bombs[counterBomb] == ship[0])
                    {
                        hitPoints += 25;
                    }
                    else if (bombs[counterBomb] == ship[2])
                    {
                        hitPoints += 25;
                    }
                    else
                    {
                        hitPoints += 50;
                    }
                }
                counterBomb += 2;
            }
            Console.WriteLine("{0}%", hitPoints);
        }
    }
}