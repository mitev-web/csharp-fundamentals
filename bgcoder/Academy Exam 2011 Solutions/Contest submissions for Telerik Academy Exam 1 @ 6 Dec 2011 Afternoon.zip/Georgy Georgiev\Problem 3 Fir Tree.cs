using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contest3
{
    class Program
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n - 1; i++)
            {
                Console.Write(new string('.', n - i-1));
                Console.Write(new string('*',   2*i-1));
                Console.Write(new string('.', n - i-1));
                Console.WriteLine();
            }
            Console.Write(new string('.', n-2 ));
            Console.Write(new string('*', 1));
            Console.Write(new string('.', n-2 ));
            Console.WriteLine();
           



        }
    }
}
