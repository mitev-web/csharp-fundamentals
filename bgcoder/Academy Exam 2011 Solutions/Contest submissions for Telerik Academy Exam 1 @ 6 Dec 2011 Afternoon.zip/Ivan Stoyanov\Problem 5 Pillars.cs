using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] a = new byte[8];
            for (byte i = 0; i < 8; i++)
            {
                a[i] = byte.Parse(Console.ReadLine());
            }

            byte leftCounter = 0;
            byte rightCounter = 0;
            bool isTrue = false;
            //kyde e chertata
            for (sbyte CHERTATA = 7; CHERTATA >= 0; CHERTATA--)
            {
                leftCounter = 0;
                rightCounter = 0;
                //za LQVATA kolonka
                if (CHERTATA != 7)
                {
                    for (sbyte i = 7, stepen = 0; i > CHERTATA; i--, stepen++)
                    {
                        //za red
                        for (sbyte j = 0; j < 8; j++)
                        {
                            if (((byte)(a[j] << stepen) >> 7) == 1) leftCounter++;
                        }
                    }
                }

                //za DQSNATA kolonka
                if (CHERTATA != 0)
                {
                    for (sbyte i = (sbyte)(CHERTATA - 1), stepen = (sbyte)(7 - CHERTATA + 1); i >= 0; i--, stepen++)
                    {
                        //za red
                        for (sbyte j = 0; j < 8; j++)
                        {
                            if (((byte)(a[j] << stepen) >> 7) == 1) rightCounter++;
                        }
                    }
                }
                //if (leftCounter != 0)
                //{
                    if (leftCounter == rightCounter)
                    {
                        Console.WriteLine(CHERTATA);
                        Console.WriteLine(leftCounter);
                        isTrue = true;
                        break;
                    }
                //}
            }

            if (!isTrue)
            {
                Console.WriteLine("No");
            }

        }
    }
}
