using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad3_FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            string str;

            str = Console.ReadLine();
            int.TryParse(str, out n);

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < (n-1)*2-1; j++)
                {
                    if (i == n-1)
                    {
                        if (j == n-2)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    else
                    {
                        if (j >= n-i-2 && j <= n+i-2)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
