using System;

class Pillars
{
    static void Main()
    {
        byte[] bit = { 0, 0, 0, 0, 0, 0, 0, 0 };
        byte[] number = new byte[8];
        short sum=0;
         //byte[] number = { 1, 1, 1, 16, 32 , 32, 64, 0 };
        //byte[] number = { 0, 64, 0, 8, 0, 12, 224, 0 };
        //byte[] number = { 32, 64, 0, 8, 0, 12, 224, 1 };
        //byte[] number = { 3, 0, 0, 0, 0, 0, 0, 0 };

        for (int i = 0; i < 8; i++)
        {
            number[i] = byte.Parse(Console.ReadLine());
        }


        for (int i = 0; i <= 7; i++)
        {
            for (int j = 0; j <= 7; j++)
            {
                if (GetBitValueAtPositon(number[i], j) == 1)
                {
                    bit[j]++;
                }
            }
        }


        for (int i = 0; i < 8; i++)
        {
            sum += bit[i];
        }


            if (bit[7] == bit[5] + bit[4] + bit[3] + bit[2] + bit[1] + bit[0])
            {
                Console.WriteLine(6);
                Console.WriteLine(sum / 2);
            }
            else if (bit[7] + bit[6] == bit[4] + bit[3] + bit[2] + bit[1] + bit[0])
            {
                Console.WriteLine(5);
                Console.WriteLine(sum / 2);
            }
            else if (bit[7] + bit[6] + bit[5] == bit[3] + bit[2] + bit[1] + bit[0])
            {
                Console.WriteLine(4);
                Console.WriteLine(sum / 2);
            }
            else if (bit[7] + bit[6] + bit[5] + bit[4] == bit[2] + bit[1] + bit[0])
            {
                Console.WriteLine(3);
                Console.WriteLine(sum / 2);
            }
            else if (bit[7] + bit[6] + bit[5] + bit[4] + bit[3] == bit[1] + bit[0])
            {
                Console.WriteLine(2);
                Console.WriteLine(sum / 2);
            }
            else if (bit[7] + bit[6] + bit[5] + bit[4] + bit[3] + bit[2] == bit[0])
            {
                Console.WriteLine(1);
                Console.WriteLine(sum / 2);
            }
            else
                Console.WriteLine("No");

    }

    static int GetBitValueAtPositon(byte number, int index)
    {
        int numberAtIndex = number >> index;
        int mask = numberAtIndex & 1;
        if (mask == 1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
