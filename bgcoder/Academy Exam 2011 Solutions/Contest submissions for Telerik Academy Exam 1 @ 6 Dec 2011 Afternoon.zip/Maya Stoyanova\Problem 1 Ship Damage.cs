using System;
using System.Numerics;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tribonacci
{
    class tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger num1 = BigInteger.Parse(Console.ReadLine());
            BigInteger num2 = BigInteger.Parse(Console.ReadLine());
            BigInteger num3 = BigInteger.Parse(Console.ReadLine());
            BigInteger s = 0;
            ushort n = 10;
            int i=0;
            while (i<n)
            {
                 
                num1 = num2;
                num2 = num3;
                num3 = s;
                s = num1 + num2 + num3;
                i++;
            }
            Console.WriteLine(s);
        }
    }
}
