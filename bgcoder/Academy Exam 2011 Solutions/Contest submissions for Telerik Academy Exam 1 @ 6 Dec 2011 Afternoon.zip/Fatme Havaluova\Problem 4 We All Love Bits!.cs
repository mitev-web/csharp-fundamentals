using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem4
{
    class Program
    {
        static void Main(string[] args)
        {
            int d = int.Parse(Console.ReadLine());
            int i = 1;
           
           
           //long p1 = n;
            for (int j = 0; j < d; j++)
            {
                long n = long.Parse(Console.ReadLine());
                int sum = 0;
                int c = countDivider(n) - 1;
                int k = 0;
                long p1 = n;
                for (int pos = 0; pos < countDivider(n); pos++)
                {
                    int mask = i << pos;
                    if ((n & mask) != 0) p1 = (p1 & (~(1 << pos))); else p1 = (p1 | (i << pos));

                    int mask1 = i << pos;
                    if ((n & mask1) != 0) k = 1; else k = 0;
                    sum += k * (int)Math.Pow(2, c);
                    c--;
                }
                Console.WriteLine((n ^ p1) & sum);
            }
           
           
        }
        static int countDivider(long n)
        {
            int count = 0;
            long remain = 0;
            do
            {
                remain = n % 2;
                n = n / 2;
                count++;
            } while (n > 0);
            return count;
        }
       
    }
}
