using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[,] matrix = new string[n, 2 * n - 3];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 2 * n - 3; j++)
                {
                    matrix[i, j] = ".";
                }
            }
            for (int i = 0; i < n; i++)
            {
                if (n - i >= 2)
                {
                    for (int j = n - 2 - i; j <= n - 2 + i; j++)
                    {
                        matrix[i, j] = "*";
                    }
                }
            }
            matrix[n - 1, n - 2] = "*";
            printMatrix(matrix,n);
        }
        private static void printMatrix(string[,] matrix, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 2*n-3; j++)
                {
                    Console.Write(matrix[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
