using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.FirTree
{
	class FirTree
	{
		static void Main(string[] args)
		{
			byte N = byte.Parse(Console.ReadLine());
			int rowLength = (int)(1 + (2 * (N - 2)));
			int asteriskCount = 1;
			int inputedAsterisks = 0;
			int asteriskStartIndex = (rowLength / 2);

			for (int currentRow = 0; currentRow < N - 1; currentRow++)
			{
				for (int rowPosition = 0; rowPosition < rowLength; rowPosition++)
				{
					if (rowPosition>= asteriskStartIndex && rowPosition < (asteriskStartIndex + asteriskCount))
					{
						Console.Write("*");
					}
					else
					{
						Console.Write(".");
					}
				}
				Console.WriteLine();
				asteriskStartIndex--;
				asteriskCount += 2;
			}

			for (int rowPosition = 0; rowPosition < rowLength; rowPosition++)
			{
				if (rowPosition == (rowLength /2))
				{
					Console.Write("*");
				}
				else
				{
					Console.Write(".");
				}
			}
		}
	}
}
