using System;
using System.Collections.Generic;
using System.Numerics;

namespace Zad2_Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.BufferHeight = 150;
            BigInteger[] num = new BigInteger[3];

            string str;
            for (int i = 0; i < num.Length; i++)
            {
                str = Console.ReadLine();
                BigInteger.TryParse(str, out num[i]);
            }
            int n=0;
            str = Console.ReadLine();
            int.TryParse(str, out n);

            //Console.WriteLine("======================================");
            LinkedList<BigInteger> myList = new LinkedList<BigInteger>(num);
            for (int i = 0; i < n-num.Length; i++)
            {
                //Console.WriteLine(myList.Last.Value);
                myList.AddLast(new LinkedListNode<BigInteger>( BigInteger.Add(BigInteger.Add(myList.First.Value, myList.First.Next.Value), myList.First.Next.Next.Value) ));
                myList.RemoveFirst();
            }
            Console.WriteLine(myList.Last.Value);
        }
    }
}