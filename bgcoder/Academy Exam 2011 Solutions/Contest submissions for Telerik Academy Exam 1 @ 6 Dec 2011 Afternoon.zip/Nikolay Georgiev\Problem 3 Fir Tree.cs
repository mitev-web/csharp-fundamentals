using System;

    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int row = n*2 - 3;
            int star = n;
            int starLeft = n;
            int starRight = n-2;

            for (int i = 1; i <= n; i++)
            {
                starLeft--;
                starRight++;
                for (int k = 1; k <= row; k++)
                {

                    if (k == n - 1||(!(k<starLeft||k>starRight) && !(i==n)))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }

        }
    }
