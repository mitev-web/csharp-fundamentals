using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1 = Convert.ToInt32(Console.ReadLine());
            int number2 = Convert.ToInt32(Console.ReadLine());
            int number3 = Convert.ToInt32(Console.ReadLine());
            ushort n = Convert.ToUInt16(Console.ReadLine());
            BigInteger[] arr = new BigInteger[n];
            arr[0] = number1;
            arr[1] = number2;
            arr[2] = number3;
            for (int i = 3; i < n; i++)
            {
                arr[i] = arr[i - 1] + arr[i - 2] + arr[i - 3];
            }
            Console.WriteLine(arr[n-1]);
        }
    }
}
