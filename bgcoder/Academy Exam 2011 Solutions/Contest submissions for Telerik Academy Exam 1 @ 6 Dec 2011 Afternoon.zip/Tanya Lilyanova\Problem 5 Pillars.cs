using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Solution5
{
    class Program
    {
        static void Main(string[] args)
        {
            int n,i;
            int sum = 0;
           int[] m = new int[10];
            for (i = 0; i < 8; i++)
            {
                n = int.Parse(Console.ReadLine());
                int j = 0;
                while (n != 0)
                {
                    if ((n & 1) == 1)
                    {
                        m[j]++;
                        sum++;
                    }
                    n = n / 2;
                    j++;
                }
           }
            
            int s=0;
            int fl=0;
            for (i = 7; i >= 0; i--) { if (s == sum - m[i]-s) { fl = 1; break; } s += m[i]; }
            if (fl == 1) { Console.WriteLine(i); Console.WriteLine(s); }
            else Console.WriteLine("No");
 
        }
    }
}
