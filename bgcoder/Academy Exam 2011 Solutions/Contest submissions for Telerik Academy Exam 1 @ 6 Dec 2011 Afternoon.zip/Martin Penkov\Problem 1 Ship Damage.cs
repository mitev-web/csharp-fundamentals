using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.Ship_Damage
{
    class Program
    {
        static void Main(string[] args)
        {
            int shipX1 = int.Parse(Console.ReadLine());
            int shipY1 = int.Parse(Console.ReadLine());
            int shipX2 = int.Parse(Console.ReadLine());
            int shipY2 = int.Parse(Console.ReadLine());
            if (shipX1 < shipX2)
            {
                int temp = shipX2;
                shipX2 = shipX1;
                shipX1 = temp;
            }
            if (shipY1 < shipY2)
            {
                int temp = shipY2;
                shipY2 = shipY1;
                shipY1 = temp;
            }
            int horizontY = int.Parse(Console.ReadLine());
            int[] cannonX = new int[8];
            int[] cannonY = new int[8];
            int answer=0;
            for (int i = 1; i <= 3; i++)
            {
                cannonX[i] = int.Parse(Console.ReadLine());
                cannonY[i] = int.Parse(Console.ReadLine());
                cannonY[i] = horizontY + (horizontY - cannonY[i]);
                if ((cannonX[i] == shipX1 || cannonX[i] == shipX2) && (cannonY[i] == shipY1 || cannonY[i] == shipY2))
                {
                    answer += 25;
                }
                else
                {
                    if (cannonX[i] == shipX1 || cannonX[i] == shipX2 || cannonY[i] == shipY1 || cannonY[i] == shipY2)
                    {
                        if ((shipX1 >= cannonX[i] && shipX2 <= cannonX[i]) && (shipY1 >= cannonY[i] && shipY2 <= cannonY[i]))
                        {
                            answer += 50;
                        }
                    }
                    else
                        if((shipX1>cannonX[i] && shipX2<cannonX[i]) && (shipY1>cannonY[i] && shipY2<cannonY[i]))
                        {
                            answer += 100;
                        }
                }
            }
            Console.WriteLine("{0}%",answer);
        }
    }
}
