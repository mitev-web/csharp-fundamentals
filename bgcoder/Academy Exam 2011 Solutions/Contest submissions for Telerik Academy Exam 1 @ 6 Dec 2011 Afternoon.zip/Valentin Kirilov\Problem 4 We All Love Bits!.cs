using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {

        // Invert number
        static int invertNumber(int inputNumber)
        {
            int returnNumber = inputNumber;
            int inputN = inputNumber;

            int currentBitPosition = 0;
            while (inputNumber > 0)
            {
                int mask = 1 << currentBitPosition;
                int result = inputN & mask;
                int resultBit = result >> currentBitPosition;

                if (resultBit == 1)
                {
                    // Set bit in 0
                    mask = ~(1 << currentBitPosition);
                    returnNumber = returnNumber & mask;
                }
                else if (resultBit == 0)
                {
                    // Set bit in 1
                    mask = 1 << currentBitPosition;
                    returnNumber = returnNumber | mask;
                }

                inputNumber /= 2;
                currentBitPosition++;
            }

            return returnNumber;
        }

        // Reverse number
        static int reverseNumber(int inputNumber)
        {
            int returnNumber = 0;
            int inputN = inputNumber;

            int currentBitPosition = 0;
            while (inputNumber > 0)
            {
                int mask = 1 << currentBitPosition;
                int result = inputN & mask;
                int resultBit = result >> currentBitPosition;

                if (resultBit == 1)
                {
                    // Set bit in 1
                    returnNumber <<= 1;
                    mask = 1 << 0;
                    returnNumber = returnNumber | mask;
                    
                }
                else if (resultBit == 0)
                {
                    // Set bit in 0
                    returnNumber <<= 1;
                    mask = ~(1 << 0);
                    returnNumber = returnNumber & mask;   
                }

                inputNumber /= 2;
                currentBitPosition++;
            }

            return returnNumber;
        }

        static void Main(string[] args)
        {
            // Read input
            short inputN;
            short.TryParse(Console.ReadLine(), out inputN);

            int currentInputNumber;
            int currentPNew;
            int currentPInverted;
            int currentPReversed;

            for (int currentInputN = 0; currentInputN < inputN; currentInputN++)
            {
                int.TryParse(Console.ReadLine(), out currentInputNumber);

                // Invert and reverse current number
                currentPInverted = WeAllLoveBits.invertNumber(currentInputNumber);
                currentPReversed = WeAllLoveBits.reverseNumber(currentInputNumber);

                currentPNew = (currentInputNumber ^ currentPInverted) & currentPReversed;
                Console.WriteLine("{0}", currentPNew);
            }
        }
    }
}
