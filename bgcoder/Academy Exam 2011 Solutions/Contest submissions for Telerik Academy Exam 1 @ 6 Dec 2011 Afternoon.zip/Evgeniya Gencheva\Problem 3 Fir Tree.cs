using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = Convert.ToByte(Console.ReadLine());
            byte[] arr = new byte[n];
            byte dots = (byte)(n - 2);
            for (int i = 0; i < n; i++)
            {
                if (i == 0 || i == n-1)
                {
                    dots = (byte)(n - 2);
                    byte tmp = dots;
                    while(tmp != 0)
                    {
                        Console.Write(".");
                        tmp--;
                    }
                    Console.Write("*");
                    tmp = dots;
                    while (tmp != 0)
                    {
                        Console.Write(".");
                        tmp--;
                    }
                    Console.WriteLine();
                }
                else
                {
                    dots--;
                    byte tmp = dots;
                    while (tmp != 0)
                    {
                        Console.Write(".");
                        tmp--;
                    }
                    int count = i*2 + 1;
                    while(count != 0)
                    {
                        Console.Write("*");
                        count--;
                    }
                    tmp = dots;
                    while (tmp != 0)
                    {
                        Console.Write(".");
                        tmp--;
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
