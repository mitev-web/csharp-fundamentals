using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static byte GetBit(byte number, byte bitPosition)
        {
            if ((number >> bitPosition) % 2 == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            byte[,] bitPosition = new byte[8, 8];
            string input = "";
            int bitCounter1 = 0;
            int bitCounter2 = 0;

            for (byte array = 0; array < 8; array++)
            {
                input = Console.ReadLine();
                numbers[array] = byte.Parse(input);
            }


            for (byte array = 0; array < 8; array++)
            {
                for (byte bit = 8; bit > 0; bit--)
                {
                    bitPosition[array, 8 - bit] = GetBit(numbers[array], (byte)(bit - 1));
                }
            }

            for (int pillar = 0; pillar < 8; pillar++)
            {
                bitCounter1 = 0;
                bitCounter2 = 0;

                for (int row = 0; row < 8; row++)
                {
                    for (int column = 0; column < pillar; column++)
                    {
                        if (bitPosition[row, column] == 1)
                        {
                            bitCounter1++;
                        }
                    }

                }

                for (int row = 0; row < 8; row++)
                {
                    for (int column = pillar + 1; column < 8; column++)
                    {
                        if (bitPosition[row, column] == 1)
                        {
                            bitCounter2++;
                        }
                    }

                }

                if (bitCounter1 == bitCounter2)
                {
                    Console.WriteLine(7 - pillar);
                    Console.WriteLine(bitCounter1);
                    break;
                }
                else if (pillar == 7)
                {
                    Console.WriteLine("No");
                }
            }
        }
    }
}
