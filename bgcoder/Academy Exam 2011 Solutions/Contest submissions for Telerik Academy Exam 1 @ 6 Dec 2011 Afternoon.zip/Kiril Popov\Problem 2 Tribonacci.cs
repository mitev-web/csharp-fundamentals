using System;
using System.Numerics;

namespace Problem2.Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger firstT = BigInteger.Parse(Console.ReadLine());
            BigInteger secondT = BigInteger.Parse(Console.ReadLine());
            BigInteger thirdT = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger curentT = 0;
            for (int i = 3; i < n; i++)
            {
                curentT = firstT + secondT + thirdT;
                firstT =  secondT;
                secondT = thirdT;
                thirdT = curentT;
            }
            Console.WriteLine(thirdT);
        }
    }
}
