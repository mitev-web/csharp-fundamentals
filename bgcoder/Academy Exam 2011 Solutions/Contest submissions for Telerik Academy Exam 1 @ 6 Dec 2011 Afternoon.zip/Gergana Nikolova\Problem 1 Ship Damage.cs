using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ship
{
    class Ship
    {
        static void Main(string[] args)
        {
            //Console.WriteLine(" S x1:");
            int Sx1 = int.Parse(Console.ReadLine());
           // Console.WriteLine("S y1:");
            int Sy1 = int.Parse(Console.ReadLine());
           // Console.WriteLine("S x2:");
            int Sx2 = int.Parse(Console.ReadLine());
           // Console.WriteLine("S y2:");
            int Sy2 = int.Parse(Console.ReadLine());
           // Console.WriteLine("H:");
            int H = int.Parse(Console.ReadLine());
           // Console.WriteLine("C x1:");
            int Cx1 = int.Parse(Console.ReadLine());
           // Console.WriteLine("C y1:");
            int Cy1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("C x2:");
            int Cx2 = int.Parse(Console.ReadLine());
           // Console.WriteLine("C y2:");
            int Cy2= int.Parse(Console.ReadLine());
           // Console.WriteLine("C x3:");
            int Cx3 = int.Parse(Console.ReadLine());
           // Console.WriteLine("C y3:");
            int Cy3 = int.Parse(Console.ReadLine());

            int symCy1=(2*H)-Cy1;
            int symCy2 = (2 * H) - Cy2;
            int symCy3 = (2 * H) - Cy3;

            int sumC1 = 0%100;
            int sumC2 = 0%100;
            int sumC3 = 0%100;

            sumC1 = damageCaused(Sx1, Sy1, Sx2, Sy2, Cx1, symCy1, sumC1);
           // Console.WriteLine(sumC1);
            sumC2 = damageCaused(Sx1, Sy1, Sx2, Sy2, Cx2, symCy2, sumC2);
            //Console.WriteLine(sumC2);
            sumC3 = damageCaused(Sx1, Sy1, Sx2, Sy2, Cx3, symCy3, sumC3);
            //Console.WriteLine(sumC3);

            int wholeDamage = sumC1 + sumC2 + sumC3;
            Console.WriteLine("{0}%",wholeDamage);
     
        }

        private static int damageCaused(int Sx1, int Sy1, int Sx2, int Sy2, int Cx1, int symCy1, int sum)
        {
            if ((Math.Abs(Cx1) > Math.Abs(Sx1)) && (Math.Abs(Cx1) < Math.Abs(Sx2))||(Math.Abs(Cx1) < Math.Abs(Sx1)) && (Math.Abs(Cx1) > Math.Abs(Sx2)))
              {
                if ((Math.Abs(symCy1) > Math.Abs(Sy2)) && (Math.Abs(symCy1) < Math.Abs(Sy1))||((Math.Abs(symCy1) < Math.Abs(Sy2)) && (Math.Abs(symCy1) > Math.Abs(Sy1))))
                {
                    sum = 100%100;
                }
                else
                {
                    sum = 0%100;
                }
                if ((symCy1 == Sy2) || (symCy1 == Sy1))
                {
                    sum = 50%100;
                }
            }
            else
            {
                sum = 0%100;
            }
            if (((Cx1 == Sx1) || (Cx1 == Sx2)) && ((Math.Abs(symCy1) < Math.Abs(Sy1)) && (Math.Abs(symCy1) > Math.Abs(Sy2))))
            {
                sum = 50%100;
            }
            if (((Cx1 == Sx1) && (symCy1 == Sy1)) || ((Cx1 == Sx1) && (symCy1 == Sy2)) || ((Cx1 == Sx2) && (symCy1 == Sy2)) || ((Cx1 == Sx2) && (symCy1 == Sy1)))
            {
                sum = 25%100;
            }
            return sum;
        }
    }
}
