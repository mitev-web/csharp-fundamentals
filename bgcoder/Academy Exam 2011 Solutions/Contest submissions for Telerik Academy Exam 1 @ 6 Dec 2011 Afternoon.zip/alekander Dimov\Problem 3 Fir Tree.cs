using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n+(n-3); j++)
                {
                    if (i > 0 && i < n - 1 && j >= n-(i+2) && j <= n + (i-2))
                    {
                        Console.Write("*");                       
                    }                    
                    else
                    {
                        if (j == n - 2)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    } 

                } 
                
                Console.WriteLine();
            }
        }
    }
}