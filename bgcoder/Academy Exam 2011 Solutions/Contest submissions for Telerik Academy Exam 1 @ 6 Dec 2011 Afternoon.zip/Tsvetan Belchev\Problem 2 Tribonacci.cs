using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _07.Fibonacci
{
    class Program
    {
        public static BigInteger Fibonacci(BigInteger a, BigInteger b, BigInteger c, BigInteger n)
        {

            BigInteger temp;
            BigInteger temp2;

            for (int i = 0; i < n; i++)
            {
                temp = a ;
                temp2 = b;
                a = b;
                b = c;
                c = temp + temp2 + c;
            }
            return a;
        }
        static void Main(string[] args)
        {

            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            BigInteger n = BigInteger.Parse(Console.ReadLine());

            BigInteger answer = Fibonacci(a, b, c, n - 1);
            Console.WriteLine(answer);
        }

        
    }
}
