using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int d = 1;
            int b = n-2;
            int c = n-2;
            for (int m = 1; m < n; m++)
            {


                for (int i = 0; i < b; i++)
                {
                    Console.Write(".");
                }
                b--;
                for (int s = 0; s < d; s++)
                {
                    Console.Write("*");
                }
                for (int k = 0; k < c; k++)
                {
                    Console.Write(".");
                }
                c--;
                d=d+2;
                Console.WriteLine();
            }
            for (int y = 0; y < n-2; y++)
            {
                Console.Write(".");
            }

            Console.Write("*");
            for (int z = 0; z < n-2; z++)
            {
                Console.Write(".");
            }
 
        }
    }
}
