using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] cells = new int[16];
            int totalCells = 0;
            for (int i = 0; i < 8; i++)
            {
                int curNumber = int.Parse(Console.ReadLine());
                int counter = 0;
                while (curNumber != 0)
                {
                    cells[counter] += (curNumber % 2);
                    counter++;
                    totalCells += (curNumber % 2);
                    curNumber /= 2;
                }
            }
            //for (int i = 1; i < 8; i++)
           // {
           //     Console.Write(cells[i]+" ");
         //   }
           // Console.WriteLine();
            int cellsSoFar = cells[0];
            bool isNo = true;
            for (int i = 7; i >= 0; i--)
            {
                int sumdown = 0;
                int sumup = 0;
                int counter=i-1;
                while (counter >= 0)
                {
                    sumdown += cells[counter];
                    counter--;
                }
                counter = i + 1;
                while (counter <= 7)
                {
                    sumup += cells[counter];
                    counter++;
                }
                if (sumup == sumdown)
                {
                    Console.WriteLine(i);
                    Console.WriteLine(sumdown);
                    isNo = false;
                    break;
                }
            }
           
            if (isNo==true) Console.WriteLine("No");
        }
    }
}
