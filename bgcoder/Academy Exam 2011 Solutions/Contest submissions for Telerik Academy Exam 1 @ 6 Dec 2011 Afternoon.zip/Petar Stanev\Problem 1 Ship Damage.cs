using System;


namespace test1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int sum = 0;
            int H = int.Parse(Console.ReadLine());

            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());

            int newCy1 = 0;
            int newCy2 = 0;
            int newCy3 = 0; 

            for (Cy1 = Cy1; Cy1 < H; Cy1++)
            {
                newCy1++;
            }
            for (Cy2 = Cy2; Cy2 < H; Cy2++)
            {
                newCy2++;
            }
            for (Cy3 = Cy3; Cy3 < H; Cy3++)
            {
                newCy3++;
            }
            newCy1 += H;
            newCy2 += H;
            newCy3 += H;

            if ((Cx1 > Sx1) && (Cx1 < Sx2) && (newCy1 > Sy2) && (newCy1 < Sy1))
            {
                sum = sum + 100;
               
            }
            if ((Cx1 < Sx1) && (Cx1 > Sx2) && (newCy1 < Sy2) && (newCy1 > Sy1))
            {
                sum = sum + 0;
                
            }
            if ((Cx1 == Sx1) && (newCy1 < Sy1) && (newCy1 > Sy2) || (Cx2 == Sx2) && (newCy1 < Sy1) && (newCy1 > Sy2) ||
                (newCy1 == Sy1) && (Cx1 > Sx1) && (Cx1 < Sx2) || (newCy2 == Sy2) && (Cx1 > Sx1) && (Cx1 < Sx2))               
            {
                sum = sum + 50;
            }
            if ( (Cx1 == Sx1) && (newCy1 == Sy1) || (Cx1 == Sx1) && (newCy1 == Sy2) || (Cx1 == Sx2) && (newCy1 == Sy2) ||
                (Cx1 == Sx2) && (newCy1 == Sy1) )
            {
                sum = sum + 25;
                         // Cx1 i Cy1
            }


            if ((Cx2 > Sx1) && (Cx2 < Sx2) && (newCy2 > Sy2) && (newCy2 < Sy1))
            {
                sum = sum + 100;
                
            }
            if ((Cx2 < Sx1) && (Cx2 > Sx2) && (newCy2 < Sy2) && (newCy2 > Sy1))
            {
                sum = sum + 0;
                
            }
            if ((Cx2 == Sx1) && (newCy2 == Sy1) || (Cx2 == Sx1) && (newCy2 == Sy2) || (Cx2 == Sx2) && (newCy2 == Sy2) ||
                (Cx2 == Sx2) && (newCy2 == Sy1))
            {
                sum = sum + 25;
                      // Cx2 i Cy2
            }

            if ((Cx3 > Sx1) && (Cx3 < Sx2) && (newCy3 > Sy2) && (newCy3 < Sy1))
            {
                sum = sum + 100;
                
            }
            if ((Cx3< Sx1) && (Cx3 > Sx2) && (newCy3 < Sy2) && (newCy3 > Sy1))
            {
                sum = sum + 0;
               
            }
            if ((Cx3 == Sx1) && (newCy3 == Sy1) || (Cx3 == Sx1) && (newCy3 == Sy2) || (Cx3 == Sx2) && (newCy3 == Sy2) ||
                (Cx3 == Sx2) && (newCy3 == Sy1))
            {
                sum = sum + 25;
                      // Cx3 i Cy3
            }

            Console.WriteLine("{0}%",sum);
        }
    }
}
