using System;

namespace Pillars
{
    class Program
    {
        static void Main()
        {
            byte[] numbers = new byte[8];

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }

            byte[] ones = new byte[numbers.Length];

            for (int col = 0; col < 8; col++)
            {
                byte bitCounter = 0;
                for (int numberIndex = 0; numberIndex < numbers.Length; numberIndex++)
                {
                    int bit = (1 << col) & numbers[numberIndex];
                    if (bit != 0)
                    {
                        bitCounter++;
                    }
                }
                ones[col] = bitCounter;
            }

            if (ones[6] + ones[5] + ones[4] + ones[3] + ones[2] + ones[1] + ones[0] == 0)
            {
                Console.WriteLine(7);
                Console.WriteLine(0);
            }
            else if (ones[7] == ones[5] + ones[4] + ones[3] + ones[2] + ones[1] + ones[0])
            {
                Console.WriteLine(6);
                Console.WriteLine(ones[7]);
            }
            else if (ones[7] + ones[6] == ones[4] + ones[3] + ones[2] + ones[1] + ones[0])
            {
                Console.WriteLine(5);
                Console.WriteLine(ones[6] + ones[7]);
            }
            else if (ones[7] + ones[6] + ones[5] == ones[3] + ones[2] + ones[1] + ones[0])
            {
                Console.WriteLine(4);
                Console.WriteLine(ones[7] + ones[6] + ones[5]);
            }
            else if (ones[7] + ones[6] + ones[5] + ones[4] == ones[2] + ones[1] + ones[0])
            {
                Console.WriteLine(3);
                Console.WriteLine(ones[2] + ones[1] + ones[0]);
            }
            else if (ones[7] + ones[6] + ones[5] + ones[4] + ones[3] == ones[1] + ones[0])
            {
                Console.WriteLine(2);
                Console.WriteLine(ones[1] + ones[0]);
            }
            else if (ones[7] + ones[6] + ones[5] + ones[4] + ones[3] + ones[2] == ones[0])
            {
                Console.WriteLine(1);
                Console.WriteLine(ones[0]);
            }
            else if (ones[7] + ones[6] + ones[5] + ones[4] + ones[3] + ones[2] + ones[1] == 0)
            {
                Console.WriteLine(0);
                Console.WriteLine(0);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
