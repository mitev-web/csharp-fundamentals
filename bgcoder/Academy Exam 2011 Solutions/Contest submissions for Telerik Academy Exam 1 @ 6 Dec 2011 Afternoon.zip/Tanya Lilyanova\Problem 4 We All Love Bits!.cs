using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Solution4
{
    class Program
    {
        static void Main(string[] args)
        {
            uint p;
            ushort n;
            n=ushort.Parse(Console.ReadLine());
            for (ushort i = 0; i < n; i++)
            {
                p = uint.Parse(Console.ReadLine());
                uint np = 0; 
                while (p!= 0) 
               { 
                np = (np << 1) | (p & 0x01); 
               p >>= 1; 
               } 
               
               
                Console.WriteLine(np);
            }
        }
    }
}