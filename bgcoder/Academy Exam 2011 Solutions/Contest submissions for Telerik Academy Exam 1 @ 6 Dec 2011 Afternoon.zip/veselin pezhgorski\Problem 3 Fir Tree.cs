using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int row = 0;
            int k = n;
            for (int i = n + 1; i < 2 * n; i++)
            {
                row++;
                k = 2 * row - 1;
                for (int j = 2 * n - 4; j >= 0; j--)
                {
                    if (i > j + 2 && k > 0)
                    {
                        Console.Write("*");
                        k--;
                    }
                    else
                    {
                        Console.Write(".");
                    }

                }
                Console.WriteLine();
            }
            for (int i = 0; i < n - 2; i++)
            {
                Console.Write(".");
            }
            Console.Write("*");
            for (int i = 0; i < n - 2; i++)
            {
                Console.Write(".");
            }

        }
    }
}
