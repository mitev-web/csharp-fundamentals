using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.ProblemFirTree
{
    class Program
    {
        static void Main(string[] args)
        {

            int N = int.Parse(Console.ReadLine());
            int toTheEnd = (N - 2) * 2 + 1;
            for (int i = 0 ; i < N-1; i++)
            {
                for (int j = 0; j < toTheEnd; j++)
                {
                    if (j >= (N - i) - 2 && j <= toTheEnd-(N-(i+1)))
                        Console.Write("*");
                    else
                        Console.Write(".");
                }
                Console.WriteLine();
            }
            for (int j = 0; j < toTheEnd; j++)
            {
                if(j == N-2)
                    Console.Write("*");
                else
                    Console.Write(".");
            }
            
            Console.WriteLine();
        }
    }
}
