using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void PrintDots(int number)
        {
            if (number < 0)
            {
                return;
            }
            if (number == 0)
            {
                return;
            }
            Console.Write(".");

            PrintDots(number - 1);
        }

        static void PrintStars(int number)
        {
            if (number<0)
            {
                return;   
            }

            if (number == 0)
            {
                return;
            }
            Console.Write('*');
            
            PrintStars(number - 1);
        }

        static int counter = 1;
        static void PrintTree(int number)
        {
            if (number == 1)
	        {
                return;          
	        }

            PrintDots(number - 2);
            PrintStars(counter);
            PrintDots(number - 2);
            counter += 2;
            Console.WriteLine();
            PrintTree(number - 1);
            
         }

        static void Main(string[] args)
        {
            byte number = byte.Parse(Console.ReadLine());

            PrintTree(number);
            PrintDots(number - 2);
            PrintStars(1);
            PrintDots(number - 2);
            Console.WriteLine();
            
        }
    }
}
