using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex4
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = short.Parse(Console.ReadLine());
            int[] numbersTmp = new int[number];
            for (int k = 0; k < number; k++)
            {
                int p = int.Parse(Console.ReadLine());

                //kyde e poslednata edinica !!!
                int counter = 0;
                for (int i = 0; i < 32; i++)
                {
                    int tmp = 1;
                    if (((tmp << i) & p) != 0) counter = i + 1;
                }

                //p2 ready
                int p2 = 0;
                for (int i = 0, j = counter - 1; i < counter; i++, j--)
                {
                    int tmp = 1;
                    tmp = p & (tmp << j);
                    if (tmp != 0) p2 += (1 << i);
                }

                int p1 = 0;
                for (int i = 0; i < counter; i++)
                {
                    int tmp = 1;
                    if ((p & (tmp << i)) == 0) p1 += (1 << i);
                }

                numbersTmp[k] = ((p ^ p1) & p2);
            }
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine(numbersTmp[i]);
            }
        }
    }
}
