using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task02
{
    class Tribunacci
    {
        static void Main(string[] args)
        {
            BigInteger t1 = 0;
            BigInteger t2 = 0;
            BigInteger t3 = 0;
            BigInteger sum = 0;
            int n =0;

            for (int i = 1; i <= 4; i++)
            {
                if (i == 1) t1 = int.Parse(Console.ReadLine());
                if (i == 2) t2 = int.Parse(Console.ReadLine());
                if (i == 3) t3 = int.Parse(Console.ReadLine());
                if (i == 4) n = int.Parse(Console.ReadLine());
            }
            if (n == 4)
            {
                Console.WriteLine(t1 + t2 + t3);
            }
            else
            {
                for (int i = 3; i < n; i++)
                {
                    sum = t1 + t2 + t3;
                    t1 = t2;
                    t2 = t3;
                    t3 = sum;
                }
                Console.WriteLine(sum);
            }
        }
    }
}
