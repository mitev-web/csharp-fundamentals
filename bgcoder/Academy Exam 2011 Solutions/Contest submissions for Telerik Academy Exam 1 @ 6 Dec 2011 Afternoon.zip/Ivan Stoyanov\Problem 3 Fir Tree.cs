using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex3_christmasTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int j = 1,k=2; j < (2*n-3)+1; j+=2, k++)
            {
                for (int i = 0; i < n - k; i++)
                {
                    Console.Write(".");
                }
                for (int i = 0; i < j; i++)
                {
                    Console.Write("*");
                }
                for (int i = 0; i < n - k; i++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
            for (int i = 0; i < 2*n-3; i++)
            {
                if (n - 2 == i) { Console.Write("*"); continue; }
                Console.Write(".");
            }
        }
    }
}
