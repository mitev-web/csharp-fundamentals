using System;
using System.Numerics;


namespace _02.Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            
            BigInteger firstNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger secondNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger thirdNumber = BigInteger.Parse(Console.ReadLine());
            int numberN = Int32.Parse(Console.ReadLine());

            BigInteger old;

            for (int i = 0; i < numberN-3; i++)
            {
                old = thirdNumber;
                thirdNumber += secondNumber + firstNumber;
                firstNumber = secondNumber;
                secondNumber = old;
            }

            Console.WriteLine(thirdNumber);

        }
    }
}
