using System;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger firstNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger secondNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger thirdNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger currentNumber = firstNumber + secondNumber + thirdNumber;

            uint n = uint.Parse(Console.ReadLine());  
            for (int i = 0; i < n - 3; i++)
            {
                currentNumber = firstNumber + secondNumber + thirdNumber;
                firstNumber = secondNumber;
                secondNumber = thirdNumber;
                thirdNumber = currentNumber;
            }
            Console.WriteLine(thirdNumber);
        }
    }
}
