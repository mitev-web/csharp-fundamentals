using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _2.ProblemTribonacci
{
    class Program
    {
        static BigInteger tribonacci(BigInteger a, BigInteger b, BigInteger c, int n)
        {
            if (n == 1)
                return a;
            if (n == 2)
                return b;
            if (n == 3)
                return c;
            if (n == 4)
                return (a + b + c);
            else
                return tribonacci(b, c, (a + b + c), n - 1);
            
            
        
        }
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine(tribonacci(a, b, c, n));

        }
    }
}
