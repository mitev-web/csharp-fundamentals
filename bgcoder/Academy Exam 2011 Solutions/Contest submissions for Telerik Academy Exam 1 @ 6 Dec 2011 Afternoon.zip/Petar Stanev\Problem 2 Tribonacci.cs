using System;
using System.Numerics;



namespace exam
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            if (n == 0)
            {
                Console.WriteLine(0);
            }
            
            BigInteger Tn = 0;
            for (int i = 3; i < n; i++)
            {

                Tn = a + b + c;
                a = b;
                b = c;
                c = Tn;
            }
            
            Console.WriteLine(Tn);
        }
    }
}