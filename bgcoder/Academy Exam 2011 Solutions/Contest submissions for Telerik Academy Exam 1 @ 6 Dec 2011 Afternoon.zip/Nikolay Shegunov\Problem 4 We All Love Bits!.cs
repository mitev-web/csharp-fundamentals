using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam06
{
    class Program
    {
        static void Main(string[] args)
        {
            uint numbers = uint.Parse(Console.ReadLine());
            uint p = 0;
            int temp = 0;
            int reverse = 0;
            int result = 0;
            int mask = 0;

            for (uint i = 0; i < numbers; i++)
            {
                p = uint.Parse(Console.ReadLine());
                temp = (int)p;

                while (temp != 0)
                {
                    result = (temp % 2);
                    reverse = (reverse << 1) + result;
                    mask = (mask << 1) + 1;
                    temp /= 2;

                }
                Console.WriteLine((p ^(mask & (~p))) & reverse);
                mask = 0;
                reverse = 0;
            }

        }
    }
}
