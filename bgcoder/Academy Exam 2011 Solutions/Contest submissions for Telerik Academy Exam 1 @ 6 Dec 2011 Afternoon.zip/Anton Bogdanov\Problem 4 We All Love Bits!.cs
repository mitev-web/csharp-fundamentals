using System;

namespace ex._4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] myArr = new int[n];

            for (int i = 0; i < n; i++)
            {
                myArr[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < myArr.Length; i++)
            {
                string strNumber = Convert.ToString(myArr[i], 2);
                int P = myArr[i];
                for (int index = 0; index < strNumber.Length; index++)
                {
                    P = ReversBitAtNPosition(P, index);
                }
                int Pdots = Convert.ToInt32(ReverseString(strNumber),2);

                Console.WriteLine((myArr[i]^P)&Pdots);
            }
            
        }
        static int ReversBitAtNPosition(int number, int position)        
        {
            return number ^ (1 << position);
        }
        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
