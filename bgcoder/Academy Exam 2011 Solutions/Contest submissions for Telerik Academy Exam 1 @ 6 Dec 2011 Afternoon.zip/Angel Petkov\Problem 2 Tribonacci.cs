using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _02.Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {

            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            BigInteger sum;
            ushort n = ushort.Parse(Console.ReadLine());

            switch (n)
            {
                case 1:
                    Console.WriteLine("0");
                    break;
                case 2:
                    Console.WriteLine(t1);
                    break;
                case 3:
                    Console.WriteLine(t1+t2);
                    break;
                case 4:
                    Console.WriteLine(t1 + t2 + t3);
                    break;
                default:
                    sum = t1 + t2 + t3;
                    for (int i = 0; i < n-4; i++)
                    {
                        t1 = t2;
                        t2 = t3;
                        t3 = sum;
                        sum = t1 + t2 + t3;
                    }
                    Console.WriteLine(sum);
                    break;
            }

            

        }
    }
}
