using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Solution2
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort n;
            BigInteger tn1=0L, tn2=0L, tn3=0L;
            
            tn1 = BigInteger.Parse(Console.ReadLine());
            tn2 = BigInteger.Parse(Console.ReadLine());
            tn3 = BigInteger.Parse(Console.ReadLine());
            n = ushort.Parse(Console.ReadLine());
            if (n == 1) Console.WriteLine(tn1);
            else if (n == 2) Console.WriteLine(tn2);
            else if (n == 3) Console.WriteLine(tn3);
            else
            {
               
                    BigInteger tn0=0L;
                    for (ushort i = 4; i <= n; i++)
                    {
                        tn0 = tn1 + tn2 + tn3;
                        tn1 = tn2;
                        tn2 = tn3;
                        tn3 = tn0;
                    }
                    Console.WriteLine(tn0);
                               }
        }
    }
}
