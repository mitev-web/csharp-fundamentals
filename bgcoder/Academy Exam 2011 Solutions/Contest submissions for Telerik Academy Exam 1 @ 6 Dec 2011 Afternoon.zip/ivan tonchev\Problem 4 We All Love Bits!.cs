using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.ProblemWeAllLoveBits
{
    class Program
    {
        static int convertZerosAndOnes(int a)
        {
            int a1 = a;
            int binary = 0;
            while (a1 > 2)
            {
                a1 /= 2;

                binary++;
            }
            if (a1 == 2)
                binary += 2;
            else
                binary++;

            for (int i = 0; i < binary; i++)
            {
                int mask = (1 << i);
                int nandMask = a & mask;
                int bit = nandMask >> i;
                if (bit == 1)
                {
                   
                    mask = ~(1 << i);
                    a = a & mask;

                }
                else
                {
                    a = a | mask;
                
                }
            }


            return a;
        }


        static int reverse(int a)
        {
            int a1 = a;
            int binary = 0;
            while (a1 > 2)
            {
                a1 /= 2;

                binary++;
            }
            if (a1 == 2)
                binary += 2;
            else
                binary++;

            int[] aBits = new int[binary];

            for (int i = 0; i < binary; i++)
            {
                int mask = (1 << i);
                int nandMask = a & mask;
                aBits[(binary-1)-i] = nandMask >> i;
            
            }
            a = 0;
            for (int i = 0; i < binary; i++)
            {
                a = a | aBits[i] << i;
            
            }
            return a;
        }
        
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int[] arr = new int[a];
            for (int i = 0; i < a; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < a; i++)
            {
                Console.WriteLine((arr[i] ^ convertZerosAndOnes(arr[i])) & reverse(arr[i]));
            }
           

        }
    }
}
