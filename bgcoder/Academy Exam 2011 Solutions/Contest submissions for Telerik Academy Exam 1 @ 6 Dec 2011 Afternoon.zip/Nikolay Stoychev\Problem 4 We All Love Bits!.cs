using System;

namespace WeAllLoveBits
{
    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int[] inputNumbers = new int[n];
            for (int i = 0; i < n; i++)
            {
                inputNumbers[i] = int.Parse(Console.ReadLine());
            }

            int[] invertedNumbers = new int[n];
            int[] result = new int[n];

            for (int i = 0; i < n; i++)
            {
                int currentNumber = inputNumbers[i];
                while (currentNumber > 0)
                {
                    int bit = 1 & currentNumber;
                    currentNumber = currentNumber >> 1;
                    invertedNumbers[i] = invertedNumbers[i] << 1;
                    if (bit != 0)
                    {
                        invertedNumbers[i] |= bit;
                    }
                }
            }

            for (int i = 0; i < inputNumbers.Length; i++)
            {
                result[i] = (inputNumbers[i] ^ ~(inputNumbers[i])) & invertedNumbers[i];
                Console.WriteLine(result[i]);
            }
        }
    }
}
