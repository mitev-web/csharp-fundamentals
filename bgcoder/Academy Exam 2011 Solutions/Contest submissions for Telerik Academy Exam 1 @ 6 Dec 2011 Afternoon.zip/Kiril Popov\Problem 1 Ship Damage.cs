using System;

namespace Problem1.ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int shipX1 = int.Parse(Console.ReadLine());
            int shipY1 = int.Parse(Console.ReadLine());
            int shipX2 = int.Parse(Console.ReadLine());
            int shipY2 = int.Parse(Console.ReadLine());
            int horizon = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());

            int damage = 0;

            int dY1 = CalculateDy(cY1, horizon);
            int dY2 = CalculateDy(cY2, horizon);
            int dY3 = CalculateDy(cY3, horizon);
            if (shipX1 < shipX2 && shipY1 > shipY2)
            {
                damage = damage + CalculateDamage(shipX1, shipX2, shipY2, shipY1, cX1, dY1);
                damage = damage + CalculateDamage(shipX1, shipX2, shipY2, shipY1, cX2, dY2);
                damage = damage + CalculateDamage(shipX1, shipX2, shipY2, shipY1, cX3, dY3);
            }
            else if(shipX1 > shipX2 && shipY1 > shipY2)
            {
                damage = damage + CalculateDamage(shipX2, shipX1, shipY2, shipY1, cX1, dY1);
                damage = damage + CalculateDamage(shipX2, shipX1, shipY2, shipY1, cX2, dY2);
                damage = damage + CalculateDamage(shipX2, shipX1, shipY2, shipY1, cX3, dY3);
            }
            else if (shipX1 < shipX2 && shipY1 < shipY2)
            {
                damage = damage + CalculateDamage(shipX1, shipX2, shipY1, shipY2, cX1, dY1);
                damage = damage + CalculateDamage(shipX1, shipX2, shipY1, shipY2, cX2, dY2);
                damage = damage + CalculateDamage(shipX1, shipX2, shipY1, shipY2, cX3, dY3);
            }
            else if (shipX1 > shipX2 && shipY1 < shipY2)
            {
                damage = damage + CalculateDamage(shipX2, shipX1, shipY1, shipY2, cX1, dY1);
                damage = damage + CalculateDamage(shipX2, shipX1, shipY1, shipY2, cX2, dY2);
                damage = damage + CalculateDamage(shipX2, shipX1, shipY1, shipY2, cX3, dY3);
            }
            Console.WriteLine(damage + "%");
        }

        private static int CalculateDy(int pY, int horizon)
        {
            int result = 0;
            if (pY <= horizon)
            {
                while (pY < horizon)
                {
                    result++;
                    pY++;
                }
                result = horizon + result;
            }
            else
            {
                while (pY > horizon)
                {
                    result++;
                    pY--;
                }
                result = horizon - result;
            }
            return result;
        }

        private static int CheckCollisions(int pPoint, int pShip1, int pShip2)
        {
            int result = -1;
            if (pPoint >= pShip1 && pPoint <= pShip2)
            {
                result = 1;
                if (pPoint == pShip1 || pPoint == pShip2)
                {
                    result = 0;
                }
            }
            return result;
        }

        private static int CalculateDamage(int pShipX1, int pShipX2, int pShipY1, int pShipY2, int pX, int pY)
        {
            int damage = 0;
            int horizontalCollision = CheckCollisions(pX, pShipX1, pShipX2);
            int verticalCollision = CheckCollisions(pY, pShipY1, pShipY2);
            if (horizontalCollision == 1 && verticalCollision == 1)
            {
                damage = 100;
            }
            else if (horizontalCollision == 0 && verticalCollision == 1)
            {
                damage = 50;
            }
            else if (horizontalCollision == 1 && verticalCollision == 0)
            {
                damage = 50;
            }
            else if (horizontalCollision == 0 && verticalCollision == 0)
            {
                damage = 25;
            }
            return damage;
        }
    }
}