using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Contest4
{
    class Program
    {
        static uint reverse(uint n)
        {
            uint r = 0;
            uint q = n;
            while (q != 0)
            {
                
                r = r * 2 + q % 2;
                q = q / 2;
            }
            return r;
        }
 
        static uint invert(uint n)
        {
            uint r = 0;
            uint q = n;
            while (q != 0)
            {
                if (q % 2 == 1)
                    r = r * 2 + 0;
                else
                    r = r * 2 + 1;
              //  Console.WriteLine(r);
                q = q / 2;
            }
            if (n % 2 == 1)
            {
                r=(r<<0);
                return r;
            }
            return reverse(r);
        }
 
        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());
            uint[] num = new uint[n];
            for (int i = 0; i <= n - 1; i++)
            {
                num[i] = uint.Parse(Console.ReadLine());
            }
            for (int i = 0; i <= n - 1; i++)
            {
                Console.WriteLine((num[i] ^ invert(num[i])) & reverse(num[i]));
            }
 
 
 
           
 
 
             
 
 
 
             
        }
    }
}