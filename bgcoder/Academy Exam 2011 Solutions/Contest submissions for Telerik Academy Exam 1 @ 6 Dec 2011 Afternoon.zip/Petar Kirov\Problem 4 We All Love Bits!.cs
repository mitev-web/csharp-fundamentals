using System;

class Problem4
{    
    static uint Invert(uint input)
    {
        int firstOneIndex;

        for (firstOneIndex = 31; firstOneIndex >= 0; firstOneIndex--)
        {
            if ((input >> firstOneIndex) == 1) break;
        }

        input <<= (31 - firstOneIndex);
        input = ~input;
        input >>= (31 - firstOneIndex);

        return input;
    }

    static uint SwapBits(int bit1, int bit2, uint inputNumber)
    {
        bool isbit1One = (inputNumber >> bit1) % 2 == 1;
        bool isbit2One = (inputNumber >> bit2) % 2 == 1;

        inputNumber = (isbit1One) ? (inputNumber | (1u << bit2)) : (inputNumber & ~(1u << bit2));
        inputNumber = (isbit2One) ? (inputNumber | (1u << bit1)) : (inputNumber & ~(1u << bit1));

        return inputNumber;
    }

    static uint Reverse(uint input)
    {
        int firstOneIndex;

        for (firstOneIndex = 31; firstOneIndex >= 0; firstOneIndex--)
        {
            if ((input >> firstOneIndex) == 1) break;
        }

        for (int i = firstOneIndex; i > firstOneIndex / 2; i--)
        {
            input = SwapBits(i, firstOneIndex - i, input);
        }

        return input;
    }

    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            uint p = uint.Parse(Console.ReadLine());
            uint result = (p ^ Invert(p)) & Reverse(p);
            Console.WriteLine(result);
        }
    }
}