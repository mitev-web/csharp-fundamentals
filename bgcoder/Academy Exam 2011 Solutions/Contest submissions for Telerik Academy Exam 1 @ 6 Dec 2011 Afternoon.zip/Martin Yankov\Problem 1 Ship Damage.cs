using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KorabI
{
    class Program
    {
        static int BooM(int shipX1, int shipX2, int shipY1, int shipY2, int canX, int canY)
        {
            int result = 0;

            if (canX < Math.Max(shipX1, shipX2) && canX > Math.Min(shipX1, shipX2))
                {
                    if (Math.Abs(canY) == Math.Abs(shipY1) || Math.Abs(canY) == Math.Abs(shipY2))
                    {
                        result = 50;
                    }
                    else if (Math.Abs(canY) < Math.Max(Math.Abs(shipY1), Math.Abs(shipY2)) &&
                        Math.Abs(canY) > Math.Min(Math.Abs(shipY1), Math.Abs(shipY2)))
                    {
                        result = 100;
                    }
                }
                else if (canX == shipX1 || canX == shipX2)
                {
                    if (Math.Abs(canY) == Math.Abs(shipY1) || Math.Abs(canY) == Math.Abs(shipY2))
                    {
                        result = 25;
                    }
                    else if (Math.Abs(canY) < Math.Max(Math.Abs(shipY1), Math.Abs(shipY2)) &&
                        Math.Abs(canY) > Math.Min(Math.Abs(shipY1), Math.Abs(shipY2)))
                    {
                        result = 50;
                    }                   
                }

            if (shipY1 <= 0 && shipY2 <= 0 && canY <= 0)
            {
                result = 0;
            }
            else if (shipY1 >= 0 && shipY2 >= 0 && canY >= 0)
            {
                result = 0;
            }
            else if (canX > Math.Max(shipX1, shipX2) || canX < Math.Min(shipX1, shipX2))
            {
                result = 0;
            }
            else if (Math.Abs(canY) > Math.Max(Math.Abs(shipY1), Math.Abs(shipY2)) ||
                        Math.Abs(canY) < Math.Min(Math.Abs(shipY1), Math.Abs(shipY2)))
            {
                result = 0;
            }
            else if (Math.Min(shipX1, shipX2) > 0 && canX < 0)
            {
                result = 0;
            }
            else if (Math.Max(shipX1, shipX2) < 0 && canX > 0)
            {
                result = 0;
            }


            return result;
        }

        static void Main(string[] args)
        {
            int sX1 = 0;
            int sY1 = 0;
            int sX2 = 0;
            int sY2 = 0;
            int h = 0;
            int cX1 = 0;
            int cY1 = 0;
            int cX2 = 0;
            int cY2 = 0;
            int cX3 = 0;
            int cY3 = 0;
            int result = 0;

            sX1 = int.Parse(Console.ReadLine());
            sY1 = int.Parse(Console.ReadLine());
            sX2 = int.Parse(Console.ReadLine());
            sY2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cX1 = int.Parse(Console.ReadLine());
            cY1 = int.Parse(Console.ReadLine());
            cX2 = int.Parse(Console.ReadLine());
            cY2 = int.Parse(Console.ReadLine());
            cX3 = int.Parse(Console.ReadLine());
            cY3 = int.Parse(Console.ReadLine());

            // Converting to new coordinate system
            sY1 -= h;
            sY2 -= h;
            cY1 -= h;
            cY2 -= h;
            cY3 -= h;

            result += BooM(sX1, sX2, sY1, sY2, cX1, cY1);
            result += BooM(sX1, sX2, sY1, sY2, cX2, cY2);
            result += BooM(sX1, sX2, sY1, sY2, cX3, cY3);


               Console.WriteLine("{0}%", result);
        }
    }
}
