using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zadacha_3
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n;
            string inputN = Console.ReadLine();
            n = byte.Parse(inputN);
            int wight = ((n - 2) * 2) + 1;
            int center = ((wight / 2) + 1);
            int left = center-1;
            int right = center+1;

            for (int i = 1; i <= n; i++)
            {
                for (int k = 1; k<=wight; k++)
                {
                    if ((i == 1) && (k == center))
                    {
                        Console.Write("*");
                    }
                    else if ((i == n) && (k == center))
                    {
                        Console.Write("*");
                    }
                    else if (((i !=1)&&(i!=n)) && (k > left) && (k < right))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
                left--;
                right++;
            }

        }
    }
}
