using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bitovete
{
    class Program
    {
        static byte GetBit(uint number, byte bitPosition)
        {
            if ((number >> bitPosition) % 2 == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        static uint SetBit(uint number, byte bitPosition, byte bitValue)
        {
            if (bitValue == 1)
            {
                number += (uint)Math.Pow(2, bitPosition);
                return number;
            }
            else if (bitValue == 0)
            {
                number -= (uint)Math.Pow(2, bitPosition);
                return number;
            }
            else
            {
                return number;
            }
        }

        static uint GetFirstBitPosition(uint number)
        {
            int counter = 0;

            for (int bytes = 31; bytes >= 0; bytes--) 
            {
                counter++;

                if ((number >> bytes) % 2 == 1)
                {
                    break;
                }
            }

            return (uint)(32 - counter);
        }
        
        static uint Invert32Bits(uint number)
        {
            uint bitLength = GetFirstBitPosition(number);

            for (byte bitPosition = 0; bitPosition <= bitLength; bitPosition++)
            {
                byte bit = GetBit(number, bitPosition);

                if (bit == 1)
                {
                    number = SetBit(number, bitPosition, 0);
                }
                else
                {
                    number = SetBit(number, bitPosition, 1);
                }
            }

            return number;
        }

        static uint Reverse32Bits(uint number)
        {
            uint newnumber = 0;

            uint bitLength = GetFirstBitPosition(number);

            for (byte bitPosition = 0; bitPosition <= bitLength; bitPosition++)
            {
                byte bit = GetBit(number, bitPosition);

                if (bit == 1)
                {
                    newnumber = SetBit(newnumber, (byte)(bitLength - bitPosition), bit);
                }
            }

            return newnumber;
        }

        static void Main(string[] args)
        {
            uint numberN = 0;
            uint p2 = 0;
            uint p3 = 0;

            numberN = uint.Parse(Console.ReadLine());

            uint[] numbers = new uint[numberN];

            for (int array = 0; array < numberN; array++)
            {
                numbers[array] = uint.Parse(Console.ReadLine());
            }

            for (int array = 0; array < numberN; array++)
            {
                p2 = Invert32Bits(numbers[array]);
                p3 = Reverse32Bits(numbers[array]);
                numbers[array] = (numbers[array] ^ p2) & p3;

                Console.WriteLine(numbers[array]);
            }
        }
    }
}
