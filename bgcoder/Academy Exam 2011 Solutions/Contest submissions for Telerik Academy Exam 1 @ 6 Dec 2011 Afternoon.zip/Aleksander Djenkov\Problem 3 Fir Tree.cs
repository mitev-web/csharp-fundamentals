using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class task3
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int k;
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < (2 * N) - 3; j++)
                {
                    if (i == 0)
                    {
                        if (j == N - 2) Console.Write("*");
                        else Console.Write(".");
                    }
                    else if (i > 0 && i < N-1)
                    {

                        if (j == (N - 2) - i)
                        {
                            for ( k = 0; k < (i * 2) + 1; k++)
                            {
                                Console.Write("*");
                                
                            }
                            j += k-1;
                        }
                        else Console.Write("."); 
                    }
                     if (i == N-1)
                    {
                        
                        if (j == N-2) Console.Write("*");
                        else Console.Write("."); 
                    }

                }
                Console.WriteLine();
            }
        }
    }
}
