using System;



class Program
{
    static void Main(string[] args)
    {
        short N;

        int T1, T2, T3;
        T1 = int.Parse(Console.ReadLine());
        T2 = int.Parse(Console.ReadLine());
        T3 = int.Parse(Console.ReadLine());
        N = short.Parse(Console.ReadLine());
        long[] sum = new long[N];        
        sum[0] = T1;
        sum[1] = T2;
        sum[2] = T3;
        for (short i = 3; i < N; i++)
        {

            sum[i] = (sum[i - 1] + sum[i - 2] + sum[i - 3]);
        }        
       Console.WriteLine(sum[N - 1]);        
    }
}
