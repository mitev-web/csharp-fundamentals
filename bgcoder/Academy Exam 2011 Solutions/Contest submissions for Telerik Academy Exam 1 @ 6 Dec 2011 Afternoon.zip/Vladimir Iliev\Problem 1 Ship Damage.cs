using System;
using System.Collections.Generic;

namespace ShipDamage
{
    class Program
    {

        struct Point
        {
            private int localPositionVert;

            public int Y
            {
                get
                {
                    return localPositionVert;
                }
                set
                {
                    localPositionVert = value;
                }
            }

            private int localPositionHor;

            public int X
            {
                get
                {
                    return localPositionHor;
                }
                set
                {
                    localPositionHor = value;
                }
            }
        }
        static void Main(string[] args)
        {
            ushort damageSum = 0;
            int exchangeHolder = 0;

            Point [] shipPoints = new Point[4];
            Point [] cannons = new Point[3];
            Point [] projectiles = new Point[3];

            shipPoints[0].X = int.Parse(Console.ReadLine());
            shipPoints[0].Y = int.Parse(Console.ReadLine());
            shipPoints[2].X = int.Parse(Console.ReadLine());
            shipPoints[2].Y = int.Parse(Console.ReadLine());
            // Calculate
            if ((shipPoints[0].X > shipPoints[2].X)||
                (shipPoints[0].Y < shipPoints[2].Y))
            {
                exchangeHolder = shipPoints[0].X;
                shipPoints[0].X = shipPoints[2].X;
                shipPoints[2].X = exchangeHolder;

                exchangeHolder = shipPoints[0].Y;
                shipPoints[0].Y = shipPoints[2].Y;
                shipPoints[2].Y = exchangeHolder;
            }
            shipPoints[1].X = shipPoints[2].X;
            shipPoints[1].Y = shipPoints[0].Y;
            shipPoints[3].X = shipPoints[0].X;
            shipPoints[3].Y = shipPoints[2].Y;
            
            shipPoints[1].X = shipPoints[2].X;
            shipPoints[1].Y = shipPoints[0].Y;
            shipPoints[3].X = shipPoints[0].X;
            shipPoints[3].Y = shipPoints[2].Y;
            int hLineOffsetY = int.Parse(Console.ReadLine());
            cannons[0].X = int.Parse(Console.ReadLine());
            cannons[0].Y = int.Parse(Console.ReadLine());
            cannons[1].X = int.Parse(Console.ReadLine());
            cannons[1].Y = int.Parse(Console.ReadLine());
            cannons[2].X = int.Parse(Console.ReadLine());
            cannons[2].Y = int.Parse(Console.ReadLine());
            //// program
            
            for (int currentProjectile = 0; currentProjectile <= 2; currentProjectile++)
            {
                if (projectiles[currentProjectile].Y <= 0)
                {
                    projectiles[currentProjectile].X = cannons[currentProjectile].X;
                    projectiles[currentProjectile].Y = (hLineOffsetY - cannons[currentProjectile].Y) + hLineOffsetY;
                }
                else 
                {
                    projectiles[currentProjectile].X = cannons[currentProjectile].X;
                    projectiles[currentProjectile].Y = (hLineOffsetY + cannons[currentProjectile].Y) + hLineOffsetY;
                }
                
            }
            //projectiles[0].X = cannons[0].X;
            //projectiles[0].Y = (hLineOffsetY - cannons[0].Y) + hLineOffsetY;
            //projectiles[1].X = cannons[1].X;
            //projectiles[1].Y = (hLineOffsetY - cannons[1].Y) + hLineOffsetY;
            //projectiles[2].X = cannons[2].X;
            //projectiles[2].Y = (hLineOffsetY - cannons[2].Y) + hLineOffsetY;

            // corners check
            for (int currentProjectile = 0; currentProjectile <= 2; currentProjectile++)
            {
                for (int currentCorner = 0; currentCorner <= 3; currentCorner++)
                { 
                    if (projectiles[currentProjectile].X == shipPoints[currentCorner].X && projectiles[currentProjectile].Y == shipPoints[currentCorner].Y)
                    {
                        damageSum += 25;
                    }
                }

                // Chech if projectile is on line X
                if ((projectiles[currentProjectile].X == shipPoints[0].X || projectiles[currentProjectile].X == shipPoints[2].X) &&
                    projectiles[currentProjectile].Y > shipPoints[2].Y && projectiles[currentProjectile].Y < shipPoints[0].Y)
                {
                    damageSum += 50;
                }
                // Chech if projectile is on line Y
                if ((projectiles[currentProjectile].Y == shipPoints[0].Y || projectiles[currentProjectile].Y == shipPoints[2].Y) &&
                    projectiles[currentProjectile].X > shipPoints[0].X && projectiles[currentProjectile].X < shipPoints[2].X)
                {
                    damageSum += 50;
                }
                // Check if is in ship
                if ((projectiles[currentProjectile].X > shipPoints[0].X && projectiles[currentProjectile].X < shipPoints[2].X) &&
                    projectiles[currentProjectile].Y > shipPoints[2].Y && projectiles[currentProjectile].Y < shipPoints[0].Y)
                {
                    damageSum += 100;
                }
            }
            Console.WriteLine(damageSum+"%");
        }
    }
}
