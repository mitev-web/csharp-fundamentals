using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberN = 0;

            numberN = int.Parse(Console.ReadLine());

            for (int row = 0; row < numberN - 1; row++)
            {

                for (int column = 0; column < (1 + 2 * (numberN - 2)); column++)
                {

                    if (column >= (1 + 2 * (numberN - 2)) / 2 - row && column <= (1 + 2 * (numberN - 2)) / 2 + row)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }

                Console.Write("\n");
            }


            for (int column = 0; column < (1 + 2 * (numberN - 2)); column++)
            {
                if (column == (1 + 2 * (numberN - 2)) / 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
        }
    }
}
