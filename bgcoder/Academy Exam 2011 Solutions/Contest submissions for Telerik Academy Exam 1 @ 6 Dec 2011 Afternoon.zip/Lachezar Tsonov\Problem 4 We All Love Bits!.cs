using System;

namespace _4.WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            int howManyNumbers = Convert.ToInt32(Console.ReadLine());
            for (int counterOfNumbers = 0; counterOfNumbers < howManyNumbers; counterOfNumbers++)
            {
                int currentNumber = Convert.ToInt32(Console.ReadLine());
                int currentNumberInverted = GetInvertedNumberInBinary(currentNumber);
                int currentNumberReversed = GetReversedNumberInBinary(currentNumber);

                int resultOfMagicOperation = (currentNumber ^ currentNumberInverted) & currentNumberReversed;
                Console.WriteLine(resultOfMagicOperation);
            }
        }

        private static int GetReversedNumberInBinary(int numberToReverse)
        {
            int result = 0;
            int counterOfBitsInNumber = GetNumbersOfBits(numberToReverse);
            for (int currentBit = 0; currentBit <= counterOfBitsInNumber; currentBit++)
            {
                byte bit = GetBitAtPosition(numberToReverse, currentBit);
                if (bit != 0)
                {
                    result = SetBitAtPosition(result, counterOfBitsInNumber - currentBit - 1, 1);
                }
            }

            return result;
        }
  
        private static int GetNumbersOfBits(int number)
        {
            int counterOfBitsInNumber = 0;
            while (number != 0)
            {
                number = number >> 1;
                counterOfBitsInNumber++;
            }
            return counterOfBitsInNumber;
        }
  
        private static int GetInvertedNumberInBinary(int numberToInvert)
        {
            int result = 0;
            int counterOfBitsInNumber = GetNumbersOfBits(numberToInvert);
            for (int currentBit = 0; currentBit < counterOfBitsInNumber; currentBit++)
            {
                if (GetBitAtPosition(numberToInvert, currentBit) == 0)
                {
                    result = SetBitAtPosition(result, currentBit, 1);
                }
            }
            return result;
        }

        private static byte GetBitAtPosition(int number, int position)
        {
            if (((number >> position) & 1) == 0)
            {
                return 0;
            }
            else return 1;
        }

        private static int SetBitAtPosition(int number, int position,
            byte valueOfBit)
        {
            int mask;
            if (valueOfBit == 1)
            {
                mask = (valueOfBit << position);
                number = (number | mask);
            }
            else
            {
                mask = (~(1 << position));
                number = (number & mask);
            }
            return number;
        }
    }
}
