using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine()); 
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            int k = n -3;
            BigInteger next = 0;
            if (n != 1 && n != 2 && n != 3)
            {
                while (k != 0)
                {
                    next = t1 + t2 + t3;
                    t1 = t2;
                    t2 = t3;
                    t3 = next;
                    k--;
                    //  Console.WriteLine("next is: " + next + " t1 is: " + t1 + " t2 is: " + t2 + " t3 is: " + t3);
                }
            }
            if (n == 1) next = t1;
            if (n == 2) next = t2;
            if (n == 3) next = t3;
            Console.WriteLine(next);
        }
    }
}
