using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Solution3
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort n = ushort.Parse(Console.ReadLine());
            int k = 1 + 2 *(n-2);
            int stars = 1;
            for (ushort i = 0; i < n-1; i++)
            {
                for (ushort j = 1; j <= k / 2; j++) Console.Write(".");
                for (ushort j = 1; j <= stars; j++) Console.Write("*");
                for (ushort j = 1; j <= k / 2; j++) Console.Write(".");
                Console.WriteLine();
                stars+=2;
                k -= 2;
            }
            k = 1 + 2 * (n - 2);
            stars = 1;
            for (ushort j = 1; j <= k / 2; j++) Console.Write(".");
            for (ushort j = 1; j <= stars; j++) Console.Write("*");
            for (ushort j = 1; j <= k / 2; j++) Console.Write(".");
            Console.WriteLine();
        }
    }
}
