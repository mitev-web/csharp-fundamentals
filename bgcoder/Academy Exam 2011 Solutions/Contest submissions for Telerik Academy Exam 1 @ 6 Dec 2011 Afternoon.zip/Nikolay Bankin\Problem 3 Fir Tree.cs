using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int treeHeight;
            treeHeight = int.Parse(Console.ReadLine());

            int treeWidth = -1;
            for (int i = 0; i < (treeHeight-1); i++)
            {
                treeWidth += 2;
            }

            for (int i = 0; i < (treeHeight-1); i++)
            {
                int index = 0;
                int endPoint = treeWidth-(2*i+1);
                while (index != (endPoint/2))
                {
                    Console.Write(".");
                    ++index;
                }
                while(index != (treeWidth - endPoint/2))
                {
                    Console.Write("*");
                    ++index;   
                }
                while (index != treeWidth)
                {
                    Console.Write(".");
                    ++index;
                }
                Console.WriteLine();
            }
            for (int i = 0; i < treeWidth; i++)
            {
                if (i == (treeWidth/2))
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
