using System;
using System.Collections.Generic;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte height = 0;
            byte width = 0;
            byte halfWidth = 0;
            height = byte.Parse(Console.ReadLine());
            width = (byte)((2 * (height -2)) +1);
            halfWidth = (byte)(width / 2);
            for (int rows = 0; rows < height; rows++)
            {
                for (int columns = 0; columns < width; columns++)
                {
                    if (rows < height - 1)
                    {
                        if (columns >= (halfWidth - rows) && (halfWidth + rows) >= columns)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    else
                    {
                        if (columns >= (halfWidth) && (halfWidth) >= columns)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    
                }
                Console.WriteLine();
            }
        }
    }
}
