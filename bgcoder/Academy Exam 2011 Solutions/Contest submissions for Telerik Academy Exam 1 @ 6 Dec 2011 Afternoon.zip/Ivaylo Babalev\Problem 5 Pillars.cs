using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] n=new byte[8];
            byte[,] matrix = new byte[8, 8];
            int exist = 0, leftCounter = 0, rightCounter = 0; 
            for (int i = 0; i < 8; i++)
            {
                n[i] = byte.Parse(Console.ReadLine());
                string binValue = Convert.ToString(n[i], 2);
                char[] arr = binValue.ToCharArray();
                Array.Reverse(arr);
                for (int j = 0; j < binValue.Length; j++)
                {
                    if (arr[j] == '1')
                    {
                        matrix[i, 7 - j] = 1;
                    }
                    else if (arr[j] == '0')
                    {
                        matrix[i, 7 - j] = 0;
                    }
                        
                    
                }
            }

            
            for (int pillar = 0; pillar < 8; pillar++)
            {
                leftCounter = 0; 
                rightCounter = 0;

                for (int left = 0; left < pillar; left++)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if (matrix[i,left] == 1)
                        {
                            leftCounter++;
                        }
                    }
                }
                for (int right = pillar + 1; right < 8; right++)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if (matrix[i, right] == 1)
                        {
                            rightCounter++;
                        }
                    }
                }
                if (rightCounter == leftCounter)
                {
                    Console.WriteLine(7 - pillar);
                    Console.WriteLine(rightCounter);
                    exist = 1;
                    break;
                }
            }

            if (exist==0)
            {
                Console.WriteLine("No");
            }

            
        }
    }
}
