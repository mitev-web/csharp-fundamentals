using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribanacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger first = 0;
            BigInteger second = 0;
            BigInteger third = 0;
            int numberN = 0;

            first = BigInteger.Parse(Console.ReadLine());
            second = BigInteger.Parse(Console.ReadLine());
            third = BigInteger.Parse(Console.ReadLine());
            numberN = int.Parse(Console.ReadLine());

            for (int element = 3; element < numberN; element++)
            {
                third = first + second + third;
                second = third - second - first;
                first = third - second - first;
            }

            Console.WriteLine(third);
        }
    }
}
