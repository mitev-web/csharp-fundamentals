using System;
using System.Numerics;

class Program
{
    static void Main()
    {
        int t1 = int.Parse(Console.ReadLine());
        int t2 = int.Parse(Console.ReadLine());
        int t3 = int.Parse(Console.ReadLine());
        ushort N = ushort.Parse(Console.ReadLine());

        BigInteger[] myArray = new BigInteger[N];
        myArray[0] = t1;
        myArray[1] = t2;
        myArray[2] = t3;

        for (int i = 3; i < N; i++)
        {
            myArray[i] = myArray[i - 1] + myArray[i - 2] + myArray[i - 3];
        }

        Console.WriteLine(myArray[N - 1]);


    }
}

