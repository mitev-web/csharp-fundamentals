using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1._2.FinnalExam
{
    class Program
    {
        static void Main(string[] args)
        {


            decimal t1 = decimal.Parse(Console.ReadLine());
            decimal t2 = decimal.Parse(Console.ReadLine());
            decimal t3 = decimal.Parse(Console.ReadLine());
            decimal t4 = 0;
            int n = int.Parse(Console.ReadLine());


            for (int i = 4; i <= n; i++)
            {
                t4 = t3 + t1 + t2;

                t1 = t2;
                t2 = t3;
                t3 = t4;


            }
            Console.WriteLine(t4);
        }
    }
}