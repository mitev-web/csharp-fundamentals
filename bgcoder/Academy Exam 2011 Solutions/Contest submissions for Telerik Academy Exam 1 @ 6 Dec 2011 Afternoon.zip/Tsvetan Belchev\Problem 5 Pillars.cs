using System; 
using System.Collections.Generic; 
using System.Linq; 
using System.Text; 
  
namespace _5.Pillars 
{ 
    class Program 
    { 
        static void Main(string[] args) 
        { 
            int n = 8; 
            byte[] arr = new byte[n]; 
            string line; 
  
            byte ones = 0; 
            byte twos = 0; 
            byte fours = 0; 
            byte eights = 0; 
            byte sixtn = 0; 
            byte thirtwos = 0; 
            byte sixtyfours = 0; 
            byte onehtweight = 0; 
  
            //int i = 0; 
            //arr[i] = 224; 
            for (int i = 0; i < n; i++) 
            { 
                line = Console.ReadLine(); 
                arr[i] = byte.Parse(line); 
            } 
  
            for (int i = 0; i < n; i++) 
            { 
                while (arr[i] > 0) 
                { 
                    if (arr[i] - 128 >= 0) 
                    { 
                        onehtweight++; 
                        arr[i] -= 128; 
                    } 
                    if (arr[i] - 64 >= 0) 
                    { 
                        sixtyfours++; 
                        arr[i] -= 64; 
                    } 
                    if (arr[i] - 32 >= 0) 
                    { 
                        thirtwos++; 
                        arr[i] -= 32; 
                    } 
                    if (arr[i] - 16 >= 0) 
                    { 
                        sixtn++; 
                        arr[i] -= 16; 
                    } 
                    if (arr[i] - 8 >= 0) 
                    { 
                        eights++; 
                        arr[i] -= 8; 
                    } 
                    if (arr[i] - 4 >= 0) 
                    { 
                        fours++; 
                        arr[i] -= 4; 
                    } 
                    if (arr[i] - 2 >= 0) 
                    { 
                        twos++; 
                        arr[i] -= 2; 
                    } 
                    if (arr[i] - 1 >= 0) 
                    { 
                        ones++; 
                        arr[i] -= 1; 
                    } 
  
                } 
            } 
            //Console.WriteLine(onehtweight); 
            //Console.WriteLine(thirtwos); 
  
            
            
                if (onehtweight == (thirtwos + sixtn + eights + fours + twos + ones)) 
                { 
                    Console.WriteLine(6); 
                    Console.WriteLine(onehtweight); 
                    return; 
                } 
                else if (onehtweight + sixtyfours == sixtn + eights + fours + twos + ones) 
                { 
                    Console.WriteLine(5); 
                    Console.WriteLine(onehtweight + sixtyfours); 
                    return; 
                } 
                else if (onehtweight + sixtyfours + thirtwos == eights + fours + twos + ones) 
                { 
                    Console.WriteLine(4); 
                    Console.WriteLine(onehtweight + sixtyfours + thirtwos); 
                    return; 
                } 
                else if (onehtweight + sixtyfours + thirtwos + sixtn == fours + twos + ones) 
                { 
                    Console.WriteLine(3); 
                    Console.WriteLine(fours + twos + ones); 
                    return; 
                } 
                else if (onehtweight + sixtyfours + thirtwos + sixtn + eights + fours == ones) 
                { 
                    Console.WriteLine(2); 
                    Console.WriteLine(ones); 
                    return; 
                } 
                else if ((sixtyfours + thirtwos + sixtn + eights + fours + twos + ones) == 0) 
                { 
                    Console.WriteLine(7); 
                    Console.WriteLine(0); 
                } 
                else if ((onehtweight + sixtyfours + thirtwos + sixtn + eights + fours + twos) == 0) 
                { 
                    Console.WriteLine(0); 
                    Console.WriteLine(0); 
                } 
                else
                { 
                    Console.WriteLine("No"); 
                }      
              
              
  
        } 
    } 
}