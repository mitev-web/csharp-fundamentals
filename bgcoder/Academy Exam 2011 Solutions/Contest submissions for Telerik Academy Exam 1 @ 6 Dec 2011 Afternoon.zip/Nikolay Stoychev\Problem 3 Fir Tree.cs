using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int height = n;
            int treeWidth = 1;

            for (int j = 0; j < n - 2; j++)
            {
                for (int i = 0; i < height - 2; i++)
                {
                    Console.Write(".");
                }
                for (int i = 0; i < treeWidth; i++)
                {
                    Console.Write("*");
                }
                treeWidth += 2;
                for (int i = 0; i < height - 2; i++)
                {
                    Console.Write(".");
                }
                height--;
                Console.WriteLine();
            }
            for (int i = 0; i < treeWidth; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();

            for (int i = 1; i <= treeWidth; i++)
            {
                if (i == (treeWidth + 1) / 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
