using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05_Problem05_FallDown
{
    class FallDown
    {
        static void Main(string[] args)
        {
            byte[] byteArray = new byte[8];
            for (byte i = 0; i < byteArray.Length; i++)
            {
                string inputLine = Console.ReadLine();
                byteArray[i] = byte.Parse(inputLine);
            }
            byte[] bitCount = new byte[8];
            for (int i = 0; i < byteArray.Length; i++)
            {
                for (int j = 7, k = 0; k < 8; j--, k++)
                {
                    int tempByte = byteArray[i] >> j;
                    tempByte = tempByte & 1;
                    if (tempByte == 1)
                    {
                        bitCount[k]++;
                    }
                }
            }
            byte[,] byteMatrix = new byte[8, 8];
            for (int i = byteMatrix.GetLength(0) - 1; i >= 0; i--)
            {
                for (int j = 0; j < byteMatrix.GetLength(0); j++)
                {
                    if (bitCount[j] != 0)
                    {
                        byteMatrix[i, j] = 1;
                        bitCount[j]--;
                    }
                }
            }
            int[] resultArray = new int[8];
            for (int i = 0; i < byteMatrix.GetLength(0); i++)
            {
                for (int j = 7, k = 0; k < 8; j--, k++)
                {
                    int tempByte = byteMatrix[i, k];
                    tempByte = tempByte << j;
                    resultArray[i] = resultArray[i] | tempByte;
                }
                Console.WriteLine(resultArray[i]);
            }
        }
    }
}