using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] mass = new int[n];
            int[] horMass = new int[n];
            int[] inverted = new int[n];
            
            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = int.Parse(Console.ReadLine());   
            }
            
       

            int mask = 0;
            for (int i = 0; i < n; i++)
            {

                string s = Convert.ToString(mass[i],2);
                
                for (int j = 0; j < s.Length; j++)
                {
                    if ((mass[i] & (1 << j)) != 0)
                    {
                        
                        horMass[i] = horMass[i] & (~(1 << j));
                    }
                    else
                    {
                        horMass[i] = horMass[i] | (1 << j);
                    }
                }

                int counter = s.Length - 1;
                for (int j = 0; j < s.Length; j++)
                {
                    if ((mass[i] & (1 << j)) != 0)
                    {
                        inverted[i] = inverted[i] | (1 << counter);
                    }
                    else
                    {
                        inverted[i] = inverted[i] & (~(1 << counter));
                    }
                    counter--;
                }
             
            }
            for (int i = 0; i < n; i++)
            {
                int num = (mass[i] ^ horMass[i]) & inverted[i];
                Console.WriteLine(num);
            }
           


        }
    }
}
