using System;
using System.Numerics;

namespace Ex._2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());

            BigInteger nextElement = 0;
            if (n <= 3)
            {
                switch (n)
                {

                    case 1: nextElement = a;
                        break;
                    case 2: nextElement = b;
                        break;
                    case 3: nextElement = c;
                        break;
                }

            }
            else
            {
                for (int i = 4; i <= n; i++)
                {
                    nextElement = a + b + c;

                    a = b;
                    b = c;
                    c = nextElement;
                }
            }
            Console.WriteLine(nextElement);

        }
    }
}
