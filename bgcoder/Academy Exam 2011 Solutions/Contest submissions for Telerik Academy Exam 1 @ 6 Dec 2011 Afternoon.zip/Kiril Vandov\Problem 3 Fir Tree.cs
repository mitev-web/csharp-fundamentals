using System;

class FirTree
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        int height = n;

        for (int i = 1, p =n; i < n; i++,p--)
        {
            for (int j = 1; j <= (n - 2); j++)
            {
                if (p == j || j >= (p - 1) && j < n)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }

            for (int j = 1; j <= (n - 2) + 1; j++)
            {
                if (i == n && j == i - 1 || j == i || j <= i - 1)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
        for (int i = 0; i < 1; i++)
        {
            for (int j = 0; j < (n - 2)*2+1; j++)
            {
                if (j == n - 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
