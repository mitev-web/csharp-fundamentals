using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.ProblemShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {

            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());

            if (Sx1 > Sx2)
            {
                int temp = Sx2;
                Sx2 = Sx1;
                Sx1 = temp;
            
            }
            if(Sy1 < Sy2)
            {
                int temp = Sy2;
                Sy2 = Sy1;
                Sy1 = temp;

            }   
            int H = int.Parse(Console.ReadLine());

            

            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            if(Cy1>H)
                Cy1 = H - Math.Abs(Cy1 - H);
            else
                Cy1 = H + Math.Abs(H - Cy1);
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            if (Cy2 > H)
                Cy2 = H - Math.Abs(Cy2 - H);
            else
                Cy2 = H + Math.Abs(H - Cy2);
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            if (Cy3 > H)
                Cy3 = H - Math.Abs(Cy3 - H);
            else
                Cy3 = H + Math.Abs(H - Cy3);
           
            int damageC1 = 0;
            int damageC2 = 0;
            int damageC3 = 0;


            if (Cx1 <= Sx2 && Cx1 >= Sx1 && Cy1 <= Sy1 && Cy1 >= Sy2)
            {
                if (Cx1 == Sx2 || Cx1 == Sx1)
                    if (Cy1 == Sy1 || Cy1 == Sy2)
                        damageC1 = 25;
                    else

                        damageC1 = 50;

                else
                {
                    if (Cy1 == Sy1 || Cy1 == Sy2)
                        damageC1 = 50;
                    else
                        damageC1 = 100;
                }
                
            }

            if (Cx2 <= Sx2 && Cx2 >= Sx1 && Cy2 <= Sy1 && Cy2 >= Sy2)
            {
                if (Cx2 == Sx2 || Cx2 == Sx1)
                    if (Cy2 == Sy1 || Cy2 == Sy2)
                        damageC2 = 25;
                    else

                        damageC2 = 50;

                else
                {
                    if (Cy2 == Sy1 || Cy2 == Sy2)
                        damageC2 = 50;
                    else
                        damageC2 = 100;
                }


            }


            if (Cx3 <= Sx2 && Cx3 >= Sx1 && Cy3 <= Sy1 && Cy3 >= Sy2)
            {
                if (Cx3 == Sx2 || Cx3 == Sx1)
                    if (Cy3 == Sy1 || Cy3 == Sy2)
                        damageC3 = 25;
                    else

                        damageC3 = 50;

                else
                {
                    if (Cy3 == Sy1 || Cy3 == Sy2)
                        damageC3 = 50;
                    else
                        damageC3 = 100;
                }


            }

            Console.WriteLine("{0}%",(damageC1+damageC2+damageC3));
          

        }
    }
}
