using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {

            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());

            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());

            int h = int.Parse(Console.ReadLine());

            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());

            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());

            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());


            //int sx1 = -6;
            //int sy1 = 6;

            //int sx2 = -11;
            //int sy2 = 3;

            //int h = 1;

            //int cx1 = -9;
            //int cy1 = -4;

            //int cx2 = -11;
            //int cy2 = -1;

            //int cx3 = 2;
            //int cy3 = 2;

           
            int sum = 0;

            sum += Check(sx1, sy1, sx2, sy2, cx1, cy1, h);
            sum += Check(sx1, sy1, sx2, sy2, cx2, cy2, h);
            sum += Check(sx1, sy1, sx2, sy2, cx3, cy3, h);
            
            
            Console.WriteLine(sum + "%");
        }

        static int Check(int sx1, int sy1, int sx2, int sy2, int cx, int cy, int h)
        {
            int sum = 0;
            if (Math.Abs(sx2) > Math.Abs(sx1))
            {
                int temp = sx1;
                sx1 = sx2;
                sx2 = temp;
            }
            if (Math.Abs(sy2) > Math.Abs(sy1))
            {
                int temp = sy1;
                sy1 = sy2;
                sy2 = temp;
            }
            cx = Math.Abs(cx);
            cy = Math.Abs(cy);

            sx2 = Math.Abs(sx2);
            sx1 = Math.Abs(sx1);

            sy1 = Math.Abs(sy1);
            sy2 = Math.Abs(sy2);

           // h = Math.Abs(h);
            
            if ((cx > sx2 && cx < sx1) && (((cy + h) <sy1 - h) && ((cy + h) > sy2 - h)))
            {
                sum += 100;
            }


            if ((cx == sx2) && ((cy + h  == sy2 - h) || (cy + h  == sy1 - h)))
            {
                sum += 25;
            }
            else if ((cx == sx1) && ((cy + h  == sy2 - h) || (cy + h  == sy1 - h)))
            {
                sum += 25;
            }
            if ((cx > sx2 && cx < sx1) && ((cy + h) == sy1 - h))
            {
                sum += 50;
            }
            else if ((cx > sx2 && cx < sx1) && ((cy + h) == sy2 - h))
            {
                sum += 50;
            }
            else if (((cy + h < sy1 - h) && (cy + h  > sy2 - h)) && (cx == sx2))
            {
                sum += 50;
            }
            else if (((cy + h  < sy1 - h) && (cy + h  > sy2 - h)) && (cx == sx1))
            {
                sum += 50;
            }

            

            return sum;
        }
    }
}
