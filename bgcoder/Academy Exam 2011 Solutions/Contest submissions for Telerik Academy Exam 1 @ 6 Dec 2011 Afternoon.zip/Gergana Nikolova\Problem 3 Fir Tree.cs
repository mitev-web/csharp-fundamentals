using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class FirTree
    {
        static void Main(string[] args)
        {
           // Console.WriteLine("Enter height :");
            byte N = byte.Parse(Console.ReadLine());

            int width = 1;
            for (int i = 1; i <= N - 2; i++)
            {
                width += 2;
            }
           // Console.WriteLine(width);
            char[,] firTree = new char[N, width];
            for (int i = 0; i < N; i++)
                for (int j = 0; j < width; j++)
                {
                    firTree[i, j] = '.';
                    if ((i == N - 1) && j == (width / 2))
                    {
                        firTree[N - 1, width / 2] = '*';
                    }
                  int l=0;
                    int m=width-1;
                    for (int k = N - 2; k >= 0; k--)
                    {
                        firTree[k, l] = '*';
                        l++;

                        firTree[k, m] = '*';
                        m--;

                        for (int p = l ; p <= m ; p++)
                        {
                            firTree[k, p] = '*';
                        }
                    }
                    

                    
                    Console.Write(firTree[i, j]);
                    if (j == width - 1)
                    {
                        Console.WriteLine();

                    }

                }
        }
    }
}
