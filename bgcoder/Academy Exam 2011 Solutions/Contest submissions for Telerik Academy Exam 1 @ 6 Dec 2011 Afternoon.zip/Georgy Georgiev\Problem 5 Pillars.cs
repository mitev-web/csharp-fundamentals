using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test5
{
    class Program
    {
       
        static void Main(string[] args)
        {
            int[] n = new int[8];
            for (int i = 0; i <= 7; i++)
            {
                n[i] = int.Parse(Console.ReadLine());
            }
            
            int[] counter = new int[8];
               
                    for (int j = 7; j >= 0; j--)
                    {
                        for (int k = 7; k >= 0; k--)
                        {
                            if (((1 << j) & n[k]) == 1 << j )
                                counter[j]++;
                    }
                }
                    int sum1 = 0;
                    int sum2 = 0;
                    
            for(int i = 6; i>=1; i--)
            {
                sum1 = 0;
                sum2 = 0;
                for (int j = 7; j > i; j--)
                {
                    sum1 += counter[j];
                }
                for (int k = 0; k < i; k++)
                {
                    sum2 += counter[k];
                }
                
                if(sum1 == sum2)
                {
                 Console.WriteLine(i);
                    break;
                }

            }
            if (sum1 == sum2)
            {

                Console.WriteLine(sum1);

            }
            else
            {
                Console.WriteLine("No");
            }

                      
        }
    }
}
