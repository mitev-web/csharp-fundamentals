using System;


namespace _01.ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            
            int sX1 = Int32.Parse(Console.ReadLine());
            int sY1 = Int32.Parse(Console.ReadLine());
            int sX2 = Int32.Parse(Console.ReadLine());
            int sY2 = Int32.Parse(Console.ReadLine());
            int lineH = Int32.Parse(Console.ReadLine());
            int cX1 = Int32.Parse(Console.ReadLine());
            int cY1 = Int32.Parse(Console.ReadLine());
            int cX2 = Int32.Parse(Console.ReadLine());
            int cY2 = Int32.Parse(Console.ReadLine());
            int cX3 = Int32.Parse(Console.ReadLine());
            int cY3 = Int32.Parse(Console.ReadLine());

            int damage = 0;

            int swap = 0;

            if (sX1 > sX2)
            {
                swap = sX1;
                sX1 = sX2;
                sX2 = swap;
            }

            if (sY1 < sY2)
            {
                swap = sY1;
                sY1 = sY2;
                sY2 = swap;
            }

            int distanceToLineY1 = sY1 - lineH;
            int distanceToLineY2 = sY2 - lineH;
            
            int distanceToLineCatapult1 = lineH - cY1;
            int distanceToLineCatapult2 = lineH - cY2;
            int distanceToLineCatapult3 = lineH - cY3;

            if (cX1 >= sX1 && cX1 <= sX2 
                && distanceToLineY1 >= distanceToLineCatapult1
                && distanceToLineY2 <= distanceToLineCatapult1)
            {
                if ( (cX1 == sX1 || cX1 == sX2) )
                {
                    if (distanceToLineY1 == distanceToLineCatapult1 
                        || distanceToLineY2 == distanceToLineCatapult1)
                    {
                        damage += 25;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
                else if (distanceToLineY1 == distanceToLineCatapult1
                        || distanceToLineY2 == distanceToLineCatapult1)
                {
                    damage += 50;
                }
                else
                {
                    damage += 100;
                }
            }

            if (cX2 >= sX1 && cX2 <= sX2 
                && distanceToLineY1 >= distanceToLineCatapult2
                && distanceToLineY2 <= distanceToLineCatapult2)
            {
                if ( (cX2 == sX1 || cX2 == sX2) )
                {
                    if (distanceToLineY1 == distanceToLineCatapult2 
                        || distanceToLineY2 == distanceToLineCatapult2)
                    {
                        damage += 25;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
                else if (distanceToLineY1 == distanceToLineCatapult2
                        || distanceToLineY2 == distanceToLineCatapult2)
                {
                    damage += 50;
                }
                else
                {
                    damage += 100;
                }
            }



            if (cX3 >= sX1 && cX3 <= sX2
                && distanceToLineY1 >= distanceToLineCatapult3
                && distanceToLineY2 <= distanceToLineCatapult3)
            {
                if ((cX3 == sX1 || cX3 == sX2))
                {
                    if (distanceToLineY1 == distanceToLineCatapult3
                        || distanceToLineY2 == distanceToLineCatapult3)
                    {
                        damage += 25;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
                else if (distanceToLineY1 == distanceToLineCatapult3
                        || distanceToLineY2 == distanceToLineCatapult3)
                {
                    damage += 50;
                }
                else
                {
                    damage += 100;
                }
            }

            Console.WriteLine("{0}%", damage);           

        }
    }
}
