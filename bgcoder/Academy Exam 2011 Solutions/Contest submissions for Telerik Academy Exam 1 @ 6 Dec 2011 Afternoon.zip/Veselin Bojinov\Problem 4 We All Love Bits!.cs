using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] result = new int[n];
            for (int j = 0; j < n; j++ )
            {

                int p = int.Parse(Console.ReadLine());
                int k = p;
                int invertBit = 0;
                int switchBit = 0;
                int invertP = 0;
                int newP = 0;
                int switchP = 0;
                int count = 0;
                while (k != 0)
                {
                    k = k >> 1;
                    count++;
                }
                int[] bit = new int[count];
                k = p;
                for (int i = 0; i < count; i++)
                {
                    bit[i] = k & 1;
                    k = k >> 1;
                }
                for (int i = 0; i < count; i++)
                {
                    invertBit = bit[i];
                    if (invertBit == 0)
                    {
                        int mask = 1 << i;
                        invertP = invertP | mask;
                    }
                    else
                    {
                        int mask = ~(1 << i);
                        invertP = invertP & mask;
                    }
                }
                for (int i = (count - 1), h = 0; i >= 0; i--, h++)
                {
                    switchBit = bit[i];
                    if (switchBit == 0)
                    {
                        int mask = ~(1 << h);
                        switchP = switchP & mask;
                    }
                    else
                    {
                        int mask = 1 << h;
                        switchP = switchP | mask;
                    }
                }

                newP = ((p ^ invertP) & switchP);
                result[j] = newP;
            }

            for (int i = 0; i < n; i++)
            {
                System.Console.WriteLine(result[i]);
            }
        }
    }
}