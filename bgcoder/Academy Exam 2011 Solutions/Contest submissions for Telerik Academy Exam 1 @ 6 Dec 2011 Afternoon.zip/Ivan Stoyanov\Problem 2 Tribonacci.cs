using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger tmp1 = BigInteger.Parse(Console.ReadLine());
            BigInteger tmp2 = BigInteger.Parse(Console.ReadLine());
            BigInteger tmp3 = BigInteger.Parse(Console.ReadLine());
            short num = short.Parse(Console.ReadLine());
            for (int i = 3; i < num; i++)
            {
                BigInteger temp1 = tmp1;
                BigInteger temp2 = tmp2;
                tmp1 = tmp2;
                tmp2 = tmp3;
                tmp3 += temp2 + temp1;
            }
            Console.WriteLine(tmp3);
        }
    }
}
