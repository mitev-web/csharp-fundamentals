using System;
using System.Numerics;

class Tribonacci
{
    static void Main()
    {

        BigInteger[] numbers = new BigInteger[16000];
        numbers[0] = BigInteger.Parse(Console.ReadLine());
        numbers[1] = BigInteger.Parse(Console.ReadLine());
        numbers[2] = BigInteger.Parse(Console.ReadLine());
        int n = int.Parse(Console.ReadLine());


        for (int i = 0; i <= n; i++)
        {
            numbers[i + 3] = numbers[i] + numbers[i + 1] + numbers[i + 2];
        }
        Console.WriteLine(numbers[n - 1]);
    }
}
