using System;
using System.Numerics;

namespace _02.Tribonacci2
{
    class Tribonacci2
    {
        static BigInteger TribonacciFunc(BigInteger start1, BigInteger start2, BigInteger start3, int number)
        {
            BigInteger[] array = new BigInteger[number];

            array[0] = start1;
            array[1] = start2;
            array[2] = start3;

            for (int i = 3; i < number; i++)
            {
                array[i] = array[i - 1] + array[i - 2] + array[i - 3];
            }

            return array[number - 1];
        }
        
        static void Main(string[] args)
        {
            BigInteger start1 = BigInteger.Parse(Console.ReadLine());
            BigInteger start2 = BigInteger.Parse(Console.ReadLine());
            BigInteger start3 = BigInteger.Parse(Console.ReadLine());

            int number = int.Parse(Console.ReadLine());

            Console.WriteLine(TribonacciFunc(start1, start2, start3, number));           
            
        }
    }
}
