using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            int T1 = int.Parse(Console.ReadLine());
            int T2 = int.Parse(Console.ReadLine());
            int T3 = int.Parse(Console.ReadLine());
            uint N = uint.Parse(Console.ReadLine());
            //int nextvalue = T1+T2+T3;
            int d = 0;



            for (int i = 4; i <= N;i++ )
            {

                d = T1 + T2 + T3;
               
                T1 = T2;
                T2 = T3;
                T3 = d;
                
                
                
            }
            Console.WriteLine("" + d);
            

        }
    }
}
