using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.WeAllLoveBits
{
	class WeAllLoveBits
	{
		static int findPInverted(int number)
		{
			int tempnumber = number;
			int positionCounter = 0;
			while (tempnumber > 0)
			{
				if ((tempnumber & 1) > 0)
				{
					number -= (int)Math.Pow(2, positionCounter);
				}
				else
				{
					number += (int)Math.Pow(2, positionCounter);
				}

				positionCounter++;
				tempnumber >>= 1;
			}

			return number;
		}

		static int findPReversed(int number)
		{

			int tempnumber = number;
			int pReversed = 0;
			do
			{
				if ((tempnumber & 1) > 0)
				{
					pReversed += 1;
					pReversed <<= 1;
				}
				else
				{
					pReversed <<= 1;
				}
				tempnumber >>= 1;
			} while (tempnumber > 0);

			pReversed >>= 1;
			return pReversed;
		}

		static void Main(string[] args)
		{
			int N = int.Parse(Console.ReadLine());
			int currentNum;
			int pInverted;
			int pReversed;
			int pNew;
			
			for (int i = 0; i < N; i++)
			{
				currentNum = int.Parse(Console.ReadLine());
				pInverted = findPInverted(currentNum);
				pReversed = findPReversed(currentNum);
				pNew = (currentNum ^ pInverted) & pReversed;
				Console.WriteLine(pNew);
			}
		}
	}
}
