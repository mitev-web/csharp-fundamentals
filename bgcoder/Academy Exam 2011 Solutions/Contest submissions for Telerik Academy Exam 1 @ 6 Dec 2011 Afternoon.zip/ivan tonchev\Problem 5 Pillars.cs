using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.ProblemPillars
{
    
    class Program
    {
        static int[,] c = new int[8, 8];

        static void toBit(int a,int j)
        {
            
            int a1 = a;
            int binary = 7;
            while (a1 > 2)
            {
                if(a1%2==1)
                    c[j,binary]=1;
                a1 /= 2;
                
                binary--;
            }
            if (a1 == 2)
            {
                c[j, binary] = 0;
                c[j, binary-1] = 1;
            }
            else if(a1==1)
                c[j, binary] = 1;
            

        }
        static void Main(string[] args)
        {

            int[] omgTheNumbers = new int[8];
            for (int i = 0; i < 8; i++)
            {
                omgTheNumbers[i] = int.Parse(Console.ReadLine());
                toBit(omgTheNumbers[i], i);
            }
            

            int numberOfOnesLeft = 0;
            int numberOfOnesRight = 0;
            int column = 0;
            int[,] tempArr = c;
            bool result = false;
            bool result1 = false;

            
            
            while (column<8 &&  !result)
            {
                
                numberOfOnesLeft = 0;
                numberOfOnesRight = 0;
               

                for (int j = 0; j < 8; j++)
			    {
			        for (int i = 0; i < column; i++)
                    {
                        numberOfOnesLeft += tempArr[j, i];
                    }
			    }
                for (int j = 0; j < 8; j++)
                {
                    for (int i = column + 1; i < 8; i++)
                    {
                        numberOfOnesRight += tempArr[j, i];
                    }
                }

                if (numberOfOnesLeft == numberOfOnesRight)
                {
                    result = true;

                    break;
                }
                column++;
               
            }

            if (result) 
            {
                if (result1)
                {

                }
                else
                {
                    Console.WriteLine(7 - column);
                    Console.WriteLine(numberOfOnesRight);
                }
            }
            else
                Console.WriteLine("No");

        }
    }
}
