using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            byte rows = byte.Parse(Console.ReadLine());
            if (rows >= 4 && rows <= 100)
            {
                for (int i = 0; i < rows - 1; i++)
                {
                    for (int k = i; k < rows - 2; k++)
                    {
                        Console.Write(".");
                    }

                    for (int j = 2 * i + 1; j > 0; j--)
                    {
                        Console.Write("*");
                    }
                    for (int p = i; p < rows - 2; p++)
                    {
                        Console.Write(".");
                    }
                    Console.WriteLine("");
                }
                for (int k = 0; k < rows - 2; k++)
                {
                    Console.Write(".");
                }
                for (int j = 1; j > 0; j--)
                {
                    Console.Write("*");
                }
                for (int p = 0; p < rows - 2; p++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
        }
    }
}