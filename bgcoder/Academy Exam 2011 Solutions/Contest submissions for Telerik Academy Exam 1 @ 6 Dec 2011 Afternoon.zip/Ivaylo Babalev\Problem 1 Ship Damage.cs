using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ship_Damage
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());

            int temp;

            if (Sx1>Sx2)
            {
                temp = Sx1;
                Sx1 = Sx2;
                Sx2 = temp;
            }

            if (Sy1 > Sy2)
            {
                temp = Sy1;
                Sy1 = Sy2;
                Sy2 = temp;
            }

            int damage = 0, corner = 25, border = 50, inside = 100, outside = 0;
            //C3
            if ((Cx3 > Sx1 && Cx3 < Sx2) && (H - Cy3 == Sy1 - H || H - Cy3 == Sy2 - H) || ((Cx3==Sx1 || Cx3==Sx2) && (H - Cy1 > Sy1 - H && H-Cy1 < Sy2 -H)))
            {
                damage += border;
            }
            if ((Cx3 == Sx2&& H - Cy3 == Sy2 - H) || (Cx3 == Sx1 && H - Cy3 == Sy1 - H) || (Cx3 == Sx2 && H - Cy3 == Sy1 - H) || (Cx3 == Sx1 && H - Cy3 == Sy2 - H))
	        {
                damage += corner;
	        }
            if ((H - Cy3 > Sy1 - H && H - Cy3 < Sy2 - H) && (Cx3 > Sx1 && Cx3 < Sx2))
            {
                damage += inside;
            }
            if ((H - Cy3 < Sy1 - H && H - Cy3 > Sy2 - H) && (Cx3 < Sx1 && Cx3 > Sx2))
            {
                damage += outside;
            }

            //C2
            if ((Cx2 > Sx1 && Cx2 < Sx2) && (H - Cy2 == Sy1 - H || H - Cy2 == Sy2 - H) || ((Cx2==Sx1 || Cx2==Sx2) && (H - Cy2 > Sy1 - H && H-Cy2 < Sy2 -H)))
            {
                damage += border;
            }
            if ((Cx2 == Sx2 && H - Cy2 == Sy2 - H) || (Cx2 == Sx1 && H - Cy2 == Sy1 - H) || (Cx2 == Sx2 && H - Cy2 == Sy1 - H) || (Cx2 == Sx1 && H - Cy2 == Sy2 - H))
            {
                damage += corner;
            }
            if ((H - Cy2 > Sy1 - H && H - Cy2 < Sy2 - H) && (Cx2 > Sx1 && Cx2 < Sx2))
            {
                damage += inside;
            }
            if ((H - Cy2 < Sy1 - H && H - Cy2 > Sy2 - H) && (Cx2 < Sx1 && Cx2 > Sx2))
            {
                damage += outside;
            }

            //C1
            if ((Cx1 > Sx1 && Cx1 < Sx2) && (H - Cy1 == Sy1 - H || H - Cy1 == Sy2 - H) || ((Cx1 == Sx1 || Cx1 == Sx2) && (H - Cy1 > Sy1 - H && H - Cy1 < Sy2 - H)))
            {
                damage += border;
            }
            if ((Cx1 == Sx2 && H - Cy1 == Sy2 - H) || (Cx1 == Sx1 && H - Cy1 == Sy1 - H) || (Cx1 == Sx2 && H - Cy1 == Sy1 - H) || (Cx1 == Sx1 && H - Cy1 == Sy2 - H))
            {
                damage += corner;
            }
            if ((H - Cy1 > Sy1 - H && H - Cy1 < Sy2 - H) && (Cx1 > Sx1 && Cx1 < Sx2))
            {
                damage += inside;
            }
            if ((H - Cy1 < Sy1 - H && H - Cy1 > Sy2 - H) && (Cx1 < Sx1 && Cx1 > Sx2))
            {
                damage += outside;
            }

            Console.WriteLine("{0}%",damage);

        }
    }
}
