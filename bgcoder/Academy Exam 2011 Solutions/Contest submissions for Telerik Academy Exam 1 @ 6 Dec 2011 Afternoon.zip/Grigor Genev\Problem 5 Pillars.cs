using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            int[] numbers = new int [8];
            int[,] bits = new int[8, 8];

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = Int32.Parse(Console.ReadLine());
            }

            for (byte i = 0; i < numbers.Length; i++)
            {
                for (byte j = 0; j < 8; j++)
                {
                    int mask = 1 << j;        
                    int nAndMask = numbers[i] & mask; 
                    bits[i, j] = nAndMask >> j;     
                }

            }

          /*  for (int j = 0; j < 8; j++)
            {
                for (int k = 7; k > -1; k--)
                {
                    Console.Write(bits[j,k]);
                }
                Console.WriteLine();
            }*/

            

            for (int i = 7; i > -1; i--)
            {
                int leftCounter = 0;
                int rightCounter = 0;

                for (int j = 0; j < 8; j++)
                {
                    for (int k = 0; k < 8; k++)
                    {
                        if (bits[j, k] == 1 && k < i )
                        {
                            rightCounter++;
                        }
                        else if (bits[j, k] == 1 && k > i)
                        {
                            leftCounter++;
                        }
                    }
                }
                
                if (leftCounter == rightCounter)
                {
                    Console.WriteLine(i);
                    Console.WriteLine(leftCounter);
                    return;
                }
                
            }

            Console.WriteLine("No");
            
        }
    }
}
