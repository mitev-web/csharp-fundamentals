using System;

namespace Ex._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string lastLine ="";
            for (int i = 1, star = 1; i <= n-1; i++, star += 2)
            {

                string strEmpty = new string('.', n - i -1);
                string strStar = new string('*', star);
                if (i == 1) 
                {
                    lastLine = strEmpty + strStar + strEmpty; ;
                }
                Console.WriteLine(strEmpty + strStar + strEmpty);
            }
            Console.WriteLine(lastLine);
        }
    }
}
