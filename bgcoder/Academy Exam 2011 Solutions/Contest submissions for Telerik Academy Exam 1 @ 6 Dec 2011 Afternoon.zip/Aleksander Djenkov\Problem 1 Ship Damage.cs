using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace taskOne
{
    class taskOne
    {
        static void Main(string[] args)
        {
            int Sx1=int.Parse(Console.ReadLine());
            int Sy1=int.Parse(Console.ReadLine());
            int Sx2=int.Parse(Console.ReadLine());
            int Sy2=int.Parse(Console.ReadLine());
            int H=int.Parse(Console.ReadLine());
            int Cx1=int.Parse(Console.ReadLine());
            int Cy1=int.Parse(Console.ReadLine());
            int Cx2=int.Parse(Console.ReadLine());
            int Cy2=int.Parse(Console.ReadLine());
            int Cx3=int.Parse(Console.ReadLine());
            int Cy3=int.Parse(Console.ReadLine());
            int points=0;
            int tempX1=Sx1;
            int tempY2 = Sy1;
             
            if (Sx1 > Sx2)
            {
                Sx1 = Sx2;
                Sy1 = Sy2;
                Sx2 = tempX1;
                Sy2 = tempY2;
            }
 
            H += H;
            if (Sx1 < Sx2)
            {
             
                if (Cy1 >= H - 1)
                {
                    Cy1 = -Cy1;
                    H =0;
                }
                 
                 
                    if (Cx1 > Sx1 && Cx1 < Sx2 && H + (-Cy1) < Sy1 && H + (-Cy1) > Sy2)
                    {
                        points += 100;
                    }
                    if ((Cx1 == Sx1 && H + (-Cy1) < Sy1 && H + (-Cy1) > Sy2) || (Cx1 == Sx2 && H + (-Cy1) > Sy2 && H + (-Cy1) < Sy1))
                    {
                        points += 50;
                    }
                    if ((H + (-Cy1) == Sy1 && Cx1 > Sx1 && Cx1 < Sx2) || (H + (-Cy1) == Sy2 && Cx1 > Sx1 && Cx1 < Sx2))
                    {
                        points += 50;
                    }
                    if ((Cx1 == Sx1 && H + (-Cy1) == Sy1) || (Cx1 == Sx1 && H + (-Cy1) == Sy2) || (Cx1 == Sx2 && H + (-Cy1) == Sy1) || (Cx1 == Sx2 && H + (-Cy1) == Sy2))
                    {
                        points += 25;
                    }
                 
          
                if (Cy2 >= H - 1)
                {
                    Cy2 = -Cy2;
                    H =0 ;
                }
                
                    if (Cx2 > Sx1 && Cx2 < Sx2 && H + (-Cy2) < Sy1 && H + (-Cy2) > Sy2)
                    {
                        points += 100;
                    }
                    if ((Cx2 == Sx1 && H + (-Cy2) < Sy1 && H + (-Cy2) > Sy2) || (Cx2 == Sx2 && H + (-Cy2) > Sy2 && H + (-Cy2) < Sy1))
                    {
                        points += 50;
                    }
                    if ((H + (-Cy2) == Sy1 && Cx2 > Sx1 && Cx2 < Sx2) || (H + (-Cy2) == Sy2 && Cx2 > Sx1 && Cx2 < Sx2))
                    {
                        points += 50;
                    }
                    if ((Cx2 == Sx1 && H + (-Cy2) == Sy1) || (Cx2 == Sx1 && H + (-Cy2) == Sy2) || (Cx2 == Sx2 && H + (-Cy1) == Sy1) || (Cx2 == Sx2 && H + (-Cy2) == Sy2))
                    {
                        points += 25;
                    }
            
                if (Cy3 >= H - 1)
                {
                    Cy3 = -Cy3;
                    H=0;
                }
                
                    if (Cx3 > Sx1 && Cx3 < Sx2 && H + (-Cy3) < Sy1 && H + (-Cy3) > Sy2)
                    {
                        points += 100;
                    }
                    if ((Cx3 == Sx1 && H + (-Cy3) < Sy1 && H + (-Cy3) > Sy2) || (Cx3 == Sx2 && H + (-Cy3) > Sy2 && H + (-Cy3) < Sy1))
                    {
                        points += 50;
                    }
                    if ((H + (-Cy3) == Sy1 && Cx3 > Sx1 && Cx3 < Sx2) || (H + (-Cy3) == Sy2 && Cx3 > Sx1 && Cx3 < Sx2))
                    {
                        points += 50;
                    }
                    if ((Cx3 == Sx1 && H + (-Cy3) == Sy1) || (Cx3 == Sx1 && H + (-Cy3) == Sy2) || (Cx3 == Sx2 && H + (-Cy3) == Sy1) || (Cx3 == Sx2 && H + (-Cy3) == Sy2))
                    {
                        points += 25;
                    }
                 
             
            }
     
            Console.WriteLine("{0}%",points);
        }
    }
}