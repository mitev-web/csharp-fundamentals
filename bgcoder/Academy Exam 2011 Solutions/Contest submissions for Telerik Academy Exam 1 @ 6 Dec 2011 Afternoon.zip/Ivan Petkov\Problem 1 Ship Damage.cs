using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zadacha1
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1, sy1, sx2, sy2, h, cx1, cy1, cx2, cy2, cx3, cy3;

            string inpSX1 = Console.ReadLine();
            string inpSY1 = Console.ReadLine();
            string inpSX2 = Console.ReadLine();
            string inpSY2 = Console.ReadLine();
            string inpH = Console.ReadLine();
            string inpCX1 = Console.ReadLine();
            string inpCY1 = Console.ReadLine();
            string inpCX2 = Console.ReadLine();
            string inpCY2 = Console.ReadLine();
            string inpCX3 = Console.ReadLine();
            string inpCY3 = Console.ReadLine();

            sx1 = int.Parse(inpSX1);
            sy1 = int.Parse(inpSY1);
            sx2 = int.Parse(inpSX2);
            sy2 = int.Parse(inpSY2);
            h = int.Parse(inpH);
            cx1 = int.Parse(inpCX1);
            cy1 = int.Parse(inpCY1);
            cx2 = int.Parse(inpCX2);
            cy2 = int.Parse(inpCY2);
            cx3 = int.Parse(inpCX3);
            cy3 = int.Parse(inpCY3);

            int sx3, sy3, sx4, sy4;
            if (sy1 < sy2) //s1 e nai-niskata tochka
            {
                sy3 = sy1;
                sy4 = sy2;
            }
            else
            {
                sy3 = sy2;
                sy4 = sy1;
            }
            if (sx1 < sx2) //s1 e nai-lqvata tochka
            {
                sx3 = sx2;
                sx4 = sx1;
            }
            else
            {
                sx3 = sx1;
                sx4 = sx2;
            }

            double distanceC1 = Math.Sqrt(((cx1 - cx1) * (cx1 * cx1)) + ((cy1 - h) * (cy1 - h)));
            double distanceC2 = Math.Sqrt(((cx2 - cx2) * (cx2 * cx2)) + ((cy2 - h) * (cy2 - h)));
            double distanceC3 = Math.Sqrt(((cx3 - cx3) * (cx3 * cx3)) + ((cy3 - h) * (cy3 - h)));
            
            int damage = 0;
            double[] hits = new double[3];

            hits[0] = h + distanceC1;
            hits[1] = h + distanceC2;
            hits[2] = h + distanceC3;

            for (int i = 0; i < 3; i++)
            {
                if (((hits[i] == sy1) && (cx1 == sx1)) || ((hits[i] == sy3) && (cx1 == sx3)) || ((hits[i] == sy2) && (cx1 == sx2)))
                {
                    damage = damage + 25;
                }
                if ((sy1 < sy2) && (sx1 < sx2)) //s1 e nai-niska i nai-lqva
                {
                    if (((hits[i] < sy2) && (hits[i] > sy1)) && ((cx1 < sx2) && (cx1 > sx1)))
                    {
                        damage = damage + 100;
                    }
                    else if((hits[i] ==sy1) && (cx1<=sx2) && (cx1=>sx1))
                    {
                        damage= damage+50;
                    }
                    else if ((hits[i] == sy2) && (cx1 <= sx2) && (cx1 => sx1))
                    {
                        damage = damage + 50;
                    }
                    else if((hits[i] ==sy1) && (cx1<=sx2) && (cx1=>sx1))
                    {
                        damage= damage+50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else if ((sy1 < sy2) && (sx1 > sx2)) //s1 e nai-niska i nai-dqsna
                {
                    if (((hits[i] < sy2) && (hits[i] > sy1)) && ((cx1 > sx2) && (cx1 < sx1)))
                    {
                        damage = damage + 100;
                    }
                    else if((hits[i] ==sy1) && (cx1=>sx2) && (cx1<=sx1))
                    {
                        damage= damage+50;
                    }
                    else if ((hits[i] == sy2) && (cx1 => sx2) && (cx1 <= sx1))
                    {
                        damage = damage + 50;
                    }
                    else if((hits[i] ==sy1) && (cx1=s>x2) && (cx1<=sx1))
                    {
                        damage= damage+50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else if ((sy1 > sy2) && (sx1 < sx2)) //s1 e nai-visoka i nai-lqva
                {
                    if (((hits[i] > sy2) && (hits[i] < sy1)) && ((cx1 > sx2) && (cx1 < sx1)))
                    {
                        damage = damage + 100;
                    }
                    else if((hits[i] ==sy1) && (cx1<=sx2) && (cx1=>sx1))
                    {
                        damage= damage+50;
                    }
                    else if ((hits[i] == sy2) && (cx1 <= sx2) && (cx1 => sx1))
                    {
                        damage = damage + 50;
                    }
                    else if((hits[i] ==sy1) && (cx1<=sx2) && (cx1=>sx1))
                    {
                        damage= damage+50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else //s1 e nai-visoka i nai- dqsna
                {
                    if (((hits[i] > sy2) && (hits[i] < sy1)) && ((cx1 < sx2) && (cx1 > sx1)))
                    {
                        damage = damage + 100;
                    }
                    else if((hits[i] ==sy1) && (cx1=>sx2) && (cx1<=sx1))
                    {
                        damage= damage+50;
                    }
                    else if ((hits[i] == sy2) && (cx1 => sx2) && (cx1 <= sx1))
                    {
                        damage = damage + 50;
                    }
                    else if((hits[i] ==sy1) && (cx1=s>x2) && (cx1<=sx1))
                    {
                        damage= damage+50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
            }
            Console.WriteLine("{0}%", damage);

        }
    }
}
