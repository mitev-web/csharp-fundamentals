using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contest1
{
    class Program
    {
        static int percent(int a, int b, int c, int d, int x, int y)
        {
            if ((b < d))
            {
                percent(c, d, a, b, x, y);
            }

            if ((x == a && y == b) || (x == a && y == d) || (x == c && y == b) || (x == c && y == d))
            {
                return 25;
            }
            else if ((x == a) || (y == d) || (x == c) || (y == b))
            {
                return 50;
            }
            else if ((x > a) && (y > d) && (x < c) && (y < b))
            {
                return 100;
            }

            return 0;
                        
        }

        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int hy = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = (hy-int.Parse(Console.ReadLine()))*(-1) + hy;
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = (hy - int.Parse(Console.ReadLine())) * (-1) + hy;
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = (hy - int.Parse(Console.ReadLine())) * (-1) + hy;

            int sum = percent(sx1, sy1, sx2, sy2, cx1, cy1) + percent(sx1, sy1, sx2, sy2, cx2, cy2) + percent(sx1, sy1, sx2, sy2, cx3, cy3);
           
           // Console.WriteLine(percent(sx1, sy1, sx2, sy2, cx1, cy1) );
           // Console.WriteLine(percent(sx1, sy1, sx2, sy2, cx2, cy2) );
           // Console.WriteLine(percent(sx1, sy1, sx2, sy2, cx3, cy3));
            
            Console.WriteLine(sum + "%");


        }
    }
}
