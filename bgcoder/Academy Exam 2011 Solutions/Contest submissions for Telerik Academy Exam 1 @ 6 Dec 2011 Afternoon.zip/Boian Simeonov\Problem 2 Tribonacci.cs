using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace TribonachiSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger tr1 = BigInteger.Parse(Console.ReadLine());
            BigInteger tr2 = BigInteger.Parse(Console.ReadLine());
            BigInteger tr3 = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger[] sumMass = new BigInteger[n];
            sumMass[0] = tr1;
            sumMass[1] = tr2;
            sumMass[2] = tr3;

            for (int i = 3; i < n; i++)
            {
                sumMass[i] = sumMass[i - 1] + sumMass[i - 2] + sumMass[i - 3];

            }
           
            Console.WriteLine(sumMass[n - 1]);
        }
    }
}
