using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex_2_tribonacci
{
    class ex_2_tribonacci
    {
        static void Main()
        {
            long t0 = long.Parse(Console.ReadLine());
            long t1 = long.Parse(Console.ReadLine());
            long t2 = long.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());
            if ((t0 > -2000000000) && (t0 < 2000000000) && (t1 > -2000000000) && (t1 < 2000000000) && (t2 > -2000000000) && (t2 < 2000000000) && (n >= 1) && (n <= 15000))
            {
                long[] array = new long[n];
                array[0] = t0;
                array[1] = t1;
                array[2] = t2;
                for (int i = 3; i < n; i++)
                {
                    array[i] = array[i - 1] + array[i - 2] + array[i - 3];
                }
                Console.WriteLine(array[n-1]);
            }
            else
            {
                Console.WriteLine("Thea values don't comply with constraints");
            }
        }
    }
}