using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.WeAllLoveBits
{
    class WeAllLoveBits
    {
        public static int NotNumber(int inputNumber)
        {
            int notNumber = inputNumber;
            string numberString = Convert.ToString(inputNumber,2);
            int stringLength = numberString.Length;

            int bitMask = (int)Math.Pow((double)2, (double)stringLength) - 1;            
            notNumber ^= bitMask;
            return notNumber;
        }

        public static int InvertNumber(int inputNumber)
        {
            int inverted;
            string inputNumberString = Convert.ToString(inputNumber,2);
            
            char[] inputNumberArray = inputNumberString.ToCharArray();
            Array.Reverse(inputNumberArray);
            inputNumberString = new string(inputNumberArray);
            inverted = Convert.ToInt32(inputNumberString,2);

            return inverted;
        }
        static void Main(string[] args)
        {
            int numberCount;
            numberCount = int.Parse(Console.ReadLine());

            int[] numbers = new int[numberCount];
            for (int i = 0; i < numberCount; i++)
            {
                int currentNumber = int.Parse(Console.ReadLine());
                int currentResult = currentNumber ^ NotNumber(currentNumber);
                int inverseNumber = InvertNumber(currentNumber);
                numbers[i] = currentResult & inverseNumber;
            }

            for (int i = 0; i < numberCount; i++)
            {
                Console.WriteLine(numbers[i]);
            }
        }
    }
}
