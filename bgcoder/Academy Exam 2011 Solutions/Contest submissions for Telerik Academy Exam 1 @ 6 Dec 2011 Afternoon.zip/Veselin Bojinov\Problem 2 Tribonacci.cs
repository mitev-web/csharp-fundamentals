using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            BigInteger n = BigInteger.Parse(Console.ReadLine());
            BigInteger tn = 0;
            if(n==1)
            {
                tn = t1;
            }
            else if (n == 2)
            {
                tn = t2;
            }
            else if (n == 3)
            {
                tn = t3;
            }
            else
            {
                for (int i = 3; i < n; i++)
                {
                    tn = t1 + t2 + t3;
                    t1 = t2;
                    t2 = t3;
                    t3 = tn;
                }
            }
            System.Console.WriteLine(tn);
        }
    }
}