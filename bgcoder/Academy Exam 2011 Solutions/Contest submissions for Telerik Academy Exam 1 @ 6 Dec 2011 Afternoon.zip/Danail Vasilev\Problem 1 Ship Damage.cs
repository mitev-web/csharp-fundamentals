using System;

class Program
{
    static void Main()
    {
        int Sx1 = int.Parse(Console.ReadLine());
        int Sy1 = int.Parse(Console.ReadLine());
        int Sx2 = int.Parse(Console.ReadLine());
        int Sy2 = int.Parse(Console.ReadLine());
        int H = int.Parse(Console.ReadLine());
        int Cx1 = int.Parse(Console.ReadLine());
        int Cy1 = int.Parse(Console.ReadLine());
        int Cx2 = int.Parse(Console.ReadLine());
        int Cy2 = int.Parse(Console.ReadLine());
        int Cx3 = int.Parse(Console.ReadLine());
        int Cy3 = int.Parse(Console.ReadLine());

        int Cy1S = H + (H - Cy1);
        int Cy2S = H + (H - Cy2);
        int Cy3S = H + (H - Cy3);

        double damage1 = 0;
        double damage2 = 0;
        double damage3 = 0;

        //First point C1
        if (Cx1 == Sx1)
        {
            if ((Cy1S == Sy1) || (Cy1S == Sy2))
            {
                damage1 = damage1 + 0.25;
            }
            else if ((Sy1 < Cy1S) && (Cy1S < Sy2) || (Sy2 < Cy1S) && (Cy1S < Sy1))
            {
                damage1 = damage1 + 0.50;
            }
            
        }
        else if (Cx1 == Sx2)
        {   //Same code as in the previous If
            if ((Cy1S == Sy1) || (Cy1S == Sy2))
            {
                damage1 = damage1 + 0.25;
            }
            else if ((Sy1 < Cy1S) && (Cy1S < Sy2) || (Sy2 < Cy1S) && (Cy1S < Sy1))
            {
                damage1 = damage1 + 0.50;
            }

        }
        else if (((Sx1 < Cx1) && (Cx1 < Sx2)) || ((Sx2 < Cx1) && (Cx1 < Sx1)))
        {
            if ((Cy1S == Sy1) || (Cy1S == Sy2))
            {
                damage1 = damage1 + 0.5;
            }
            else if ((Sy1 < Cy1S) && (Cy1S < Sy2) || (Sy2 < Cy1S) && (Cy1S < Sy1))
            {
                damage1 = damage1 + 1;
            }
        }


        //Second point C2
        if (Cx2 == Sx1)
        {
            if ((Cy2S == Sy1) || (Cy2S == Sy2))
            {
                damage2 = damage2 + 0.25;
            }
            else if ((Sy1 < Cy2S) && (Cy2S < Sy2) || (Sy2 < Cy2S) && (Cy2S < Sy1))
            {
                damage2 = damage2 + 0.50;
            }

        }
        else if (Cx2 == Sx2)
        {   //Same code as in the previous If
            if ((Cy2S == Sy1) || (Cy2S == Sy2))
            {
                damage2 = damage2 + 0.25;
            }
            else if ((Sy1 < Cy2S) && (Cy2S < Sy2) || (Sy2 < Cy2S) && (Cy2S < Sy1))
            {
                damage2 = damage2 + 0.50;
            }

        }
        else if (((Sx1 < Cx2) && (Cx2 < Sx2)) || ((Sx2 < Cx2) && (Cx2 < Sx1)))
        {
            if ((Cy2S == Sy1) || (Cy2S == Sy2))
            {
                damage2 = damage2 + 0.5;
            }
            else if ((Sy1 < Cy2S) && (Cy2S < Sy2) || (Sy2 < Cy2S) && (Cy2S < Sy1))
            {
                damage2 = damage2 + 1;
            }
        }


        //Third point C3
        if (Cx3 == Sx1)
        {
            if ((Cy3S == Sy1) || (Cy3S == Sy2))
            {
                damage3 = damage3 + 0.25;
            }
            else if ((Sy1 < Cy3S) && (Cy3S < Sy2) || (Sy2 < Cy3S) && (Cy3S < Sy1))
            {
                damage3 = damage3 + 0.50;
            }

        }
        else if (Cx3 == Sx2)
        {   //Same code as in the previous If
            if ((Cy3S == Sy1) || (Cy3S == Sy2))
            {
                damage3 = damage3 + 0.25;
            }
            else if ((Sy1 < Cy3S) && (Cy3S < Sy2) || (Sy2 < Cy3S) && (Cy3S < Sy1))
            {
                damage3 = damage3 + 0.50;
            }

        }
        else if (((Sx1 < Cx3) && (Cx3 < Sx2)) || ((Sx2 < Cx3) && (Cx3 < Sx1)))
        {
            if ((Cy3S == Sy1) || (Cy3S == Sy2))
            {
                damage3 = damage3 + 0.5;
            }
            else if ((Sy1 < Cy3S) && (Cy3S < Sy2) || (Sy2 < Cy3S) && (Cy3S < Sy1))
            {
                damage3 = damage3 + 1;
            }
        }

        Console.WriteLine("{0:0%}",damage1 + damage2 + damage3);


    
    }
}

