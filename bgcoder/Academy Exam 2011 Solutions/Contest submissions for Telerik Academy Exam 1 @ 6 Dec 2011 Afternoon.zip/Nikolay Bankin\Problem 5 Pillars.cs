using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            int[,] field = new int[8, 8];
            int inputDataCount = 8;
            for (int i = 0; i < inputDataCount; i++)
            {
                int currentNumber = int.Parse(Console.ReadLine());
                string binaryNumber = Convert.ToString(currentNumber,2);
                binaryNumber = binaryNumber.PadLeft(8, '0');

                for (int k = 0; k < 8; k++)
                {
                    switch (binaryNumber[k])
                    {
                        case '0': field[i, k] = 0; break;
                        case '1': field[i, k] = 1; break;
                        default: return;
                    }
                }
            }

            int pillarCol;
            
            for (int i = 0; i < 8; i++)
            {
                int leftCounter = 0;
                int rightCounter = 0;
                pillarCol = i;
                for (int k = 0; k < pillarCol; k++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (1 == field[j,k])
                        {
                            leftCounter++;
                        }
                    }
                }
                for (int k = pillarCol+1; k < 8; k++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (1 == field[j,k])
                        {
                            rightCounter++;
                        }
                    }
                }
                if (rightCounter == leftCounter)
                {
                    Console.WriteLine(7-pillarCol);
                    Console.WriteLine(leftCounter);
                    return;
                }
            }
            Console.WriteLine("No");
        }
    }
}
