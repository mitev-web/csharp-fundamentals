using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int X1 = int.Parse(Console.ReadLine());
            int Y1 = int.Parse(Console.ReadLine());
            int X2 = int.Parse(Console.ReadLine());
            int Y2 = int.Parse(Console.ReadLine());

            int Sx1 = Math.Min(X1, X2);
            int Sy1 = Math.Min(Y1, Y2);
            int Sx2 = Math.Max(X1, X2);
            int Sy2 = Math.Max(Y1, Y2);

            int H = int.Parse(Console.ReadLine());

            int[] Cx = new int[3];
            int[] Cy = new int[3];
            for (int i = 0; i < 3; i++)
            {
                Cx[i] = int.Parse(Console.ReadLine());
                Cy[i] = 2 * H - int.Parse(Console.ReadLine());
            }

            int dmg=0;

            for (int i = 0; i < 3; i++)
			{
			    if (Cx[i]==Sx1 || Cx[i]==Sx2)
                {
                    if (Cy[i]==Sy1 || Cy[i]==Sy2)
                    {
                        dmg += 25;
                    }
                    else if ( Cy[i] < Sy2 && Cy[i] > Sy1 )
                    {
                        dmg += 50;
                    }
                }
                else if (Cy[i] == Sy1 || Cy[i] == Sy2)
                {
                    if (Cx[i] < Sx2 && Cx[i] > Sx1)
                    {
                        dmg += 50;
                    }
                }
                else if ((Cx[i] > Sx1 && Cx[i] < Sx2) && (Cy[i] > Sy1 && Cy[i] < Sy2))
                {
                    dmg += 100;
                }
			}

            Console.WriteLine("{0}%",dmg);
        }
    }
}
