using System;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());

            for (int k = n-1; k > 0; k--)
            {
                for (int i = 0; i < k - 1; i++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < 1+(n-1-k)*2; j++)
                {
                    Console.Write("*");
                }
                for (int i = 0; i < k - 1; i++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }

            //Write the trunk of the tree
            for (int i = 0; i < n - 2; i++)
            {
                Console.Write(".");
            }

            Console.Write("*");

            for (int i = 0; i < n - 2; i++)
            {
                Console.Write(".");
            }
        }
    }
}