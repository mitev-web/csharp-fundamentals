using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New_ship
{
    class Program
    {
        static void Main(string[] args)
        {
           
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
           

            
            int counter = 0;
            if (h > 0)
            {
                if (Math.Abs(sx1) > Math.Abs(sx2))
                {
                    if (Math.Abs(sy1) > Math.Abs(sy2))
                    {
                        if ((Math.Abs(cy1) < (Math.Abs(sy2) - h)) || (Math.Abs(cy1) > (Math.Abs(sy1) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx1) == Math.Abs(sx1)) || (Math.Abs(cx1) == Math.Abs(sx2)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy1)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy2)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy1) < Math.Abs(sy1) && Math.Abs(cy1) > Math.Abs(sy2)) || (Math.Abs(cx1) < Math.Abs(sx1) && Math.Abs(cx1) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy2) < (Math.Abs(sy2) - h)) || (Math.Abs(cy2) > (Math.Abs(sy1) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx2) == Math.Abs(sx1)) || (Math.Abs(cx2) == Math.Abs(sx2)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy1)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy2)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy2) < Math.Abs(sy1) && Math.Abs(cy2) > Math.Abs(sy2)) || (Math.Abs(cx2) < Math.Abs(sx1) && Math.Abs(cx2) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy3) < (Math.Abs(sy2) - h)) || (Math.Abs(cy3) > (Math.Abs(sy1) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx3) == Math.Abs(sx1)) || (Math.Abs(cx3) == Math.Abs(sx2)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy1)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy2)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy3) < Math.Abs(sy1) && Math.Abs(cy3) > Math.Abs(sy2)) || (Math.Abs(cx3) < Math.Abs(sx1) && Math.Abs(cx3) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                    }
                    //y2>y1
                    else
                    {
                        if ((Math.Abs(cy1) < (Math.Abs(sy1) - h)) || (Math.Abs(cy1) > (Math.Abs(sy2) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx1) == Math.Abs(sx1)) || (Math.Abs(cx1) == Math.Abs(sx2)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy2)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy1)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy1) < Math.Abs(sy2) && Math.Abs(cy1) > Math.Abs(sy1)) || (Math.Abs(cx1) < Math.Abs(sx1) && Math.Abs(cx1) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy2) < (Math.Abs(sy1) - h)) || (Math.Abs(cy2) > (Math.Abs(sy2) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx2) == Math.Abs(sx1)) || (Math.Abs(cx2) == Math.Abs(sx2)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy2)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy1)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy2) < Math.Abs(sy2) && Math.Abs(cy2) > Math.Abs(sy1)) || (Math.Abs(cx2) < Math.Abs(sx1) && Math.Abs(cx2) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy3) < (Math.Abs(sy1) - h)) || (Math.Abs(cy3) > (Math.Abs(sy2) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx3) == Math.Abs(sx1)) || (Math.Abs(cx3) == Math.Abs(sx2)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy2)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy1)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy3) < Math.Abs(sy2) && Math.Abs(cy3) > Math.Abs(sy1)) || (Math.Abs(cx3) < Math.Abs(sx1) && Math.Abs(cx3) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }
                    }
                }
                //x2>x1
                else
                {
                    if (Math.Abs(sy1) > Math.Abs(sy2))
                    {
                        if ((Math.Abs(cy1) < (Math.Abs(sy2) - h)) || (Math.Abs(cy1) > (Math.Abs(sy1) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx1) == Math.Abs(sx2)) || (Math.Abs(cx1) == Math.Abs(sx1)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy1)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy2)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy1) < Math.Abs(sy1) && Math.Abs(cy1) > Math.Abs(sy2)) || (Math.Abs(cx2) < Math.Abs(sx1) && Math.Abs(cx1) > Math.Abs(sx1)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy2) < (Math.Abs(sy2) - h)) || (Math.Abs(cy2) > (Math.Abs(sy1) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx2) == Math.Abs(sx1)) || (Math.Abs(cx2) == Math.Abs(sx2)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy1)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy2)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy2) < Math.Abs(sy1) && Math.Abs(cy2) > Math.Abs(sy2)) || (Math.Abs(cx2) < Math.Abs(sx2) && Math.Abs(cx2) > Math.Abs(sx1)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy3) < (Math.Abs(sy2) - h)) || (Math.Abs(cy3) > (Math.Abs(sy1) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx3) == Math.Abs(sx1)) || (Math.Abs(cx3) == Math.Abs(sx2)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy1)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy2)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy3) < Math.Abs(sy1) && Math.Abs(cy3) > Math.Abs(sy2)) || (Math.Abs(cx3) < Math.Abs(sx2) && Math.Abs(cx3) > Math.Abs(sx1)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                    }
                    //y2>y1
                    else
                    {
                        if ((Math.Abs(cy1) < (Math.Abs(sy1) - h)) || (Math.Abs(cy1) > (Math.Abs(sy2) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx1) == Math.Abs(sx1)) || (Math.Abs(cx1) == Math.Abs(sx2)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy2)) || ((Math.Abs(cy1) + 2 * h) == Math.Abs(sy1)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy1) < Math.Abs(sy2) && Math.Abs(cy1) > Math.Abs(sy1)) || (Math.Abs(cx1) < Math.Abs(sx1) && Math.Abs(cx1) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy2) < (Math.Abs(sy1) - h)) || (Math.Abs(cy2) > (Math.Abs(sy2) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx2) == Math.Abs(sx1)) || (Math.Abs(cx2) == Math.Abs(sx2)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy2)) || ((Math.Abs(cy2) + 2 * h) == Math.Abs(sy1)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy2) < Math.Abs(sy2) && Math.Abs(cy2) > Math.Abs(sy1)) || (Math.Abs(cx2) < Math.Abs(sx1) && Math.Abs(cx2) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }

                        if ((Math.Abs(cy3) < (Math.Abs(sy1) - h)) || (Math.Abs(cy3) > (Math.Abs(sy2) + h)))
                        {
                            counter = 0;
                        }
                        else if ((Math.Abs(cx3) == Math.Abs(sx1)) || (Math.Abs(cx3) == Math.Abs(sx2)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy2)) || ((Math.Abs(cy3) + 2 * h) == Math.Abs(sy1)))
                        {
                            counter += 25;
                        }
                        else if ((Math.Abs(cy3) < Math.Abs(sy2) && Math.Abs(cy3) > Math.Abs(sy1)) || (Math.Abs(cx3) < Math.Abs(sx1) && Math.Abs(cx3) > Math.Abs(sx2)))
                        {
                            counter += 50;
                        }
                        else
                        {
                            counter += 100;
                        }
                    }
                }
            }
                       Console.WriteLine(counter);









        }
    }
}
