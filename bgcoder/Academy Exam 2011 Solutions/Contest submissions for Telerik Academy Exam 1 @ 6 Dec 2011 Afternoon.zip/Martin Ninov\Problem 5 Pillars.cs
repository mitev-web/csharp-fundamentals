using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad5_Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] bytes = new byte[8];
            string str;
            int pillarIndex = -1;
            int fullCellCount = 0;
            byte leftMask;
            byte rightMask;
            int k=7;
            leftMask = (byte)((1 << k) - 1);
            rightMask = (byte)(((1 << 7 - k) - k) << k + 1);
            int leftBits = 0;
            int rightBits = 0;

            //Console.WriteLine(Convert.ToString(leftMask, 2).PadLeft(8, '0'));
            //Console.WriteLine(Convert.ToString(rightMask, 2).PadLeft(8, '0'));
            //Console.WriteLine(Convert.ToString(13, 2).PadLeft(8, '0'));
            //Console.WriteLine(bitCounter(13));

            //Console.WriteLine("===========================================");
            
            for (int i = 0; i < bytes.Length; i++)
            {
                str = Console.ReadLine();
                byte.TryParse(str, out bytes[i]);
            }
            
            for (int i = 0; i < 8; i++)
            {
                leftMask = (byte)((1 << i) - 1);
                rightMask = (byte)(((1 << 7 - i) - 1) << i + 1);
                for (int j = 0; j < bytes.Length; j++)
                {
                    leftBits += bitCounter(bytes[j] & leftMask);
                    rightBits += bitCounter(bytes[j] & rightMask);
                }

                /*
                Console.WriteLine("For pillar index " + i);
                Console.WriteLine(leftBits);
                Console.WriteLine(rightBits);
                */
                if (leftBits == rightBits)
                {
                    pillarIndex = i;
                    fullCellCount = rightBits;
                }
                leftBits = 0;
                rightBits = 0;
            }
            if (pillarIndex > -1)
            {
                Console.WriteLine(pillarIndex);
                Console.WriteLine(fullCellCount);
            }
            else
            {
                Console.WriteLine("No");
            }

        }

        static int bitCounter(int num) //The K way
        {
            int v = num;
            int c=0;
            for (c = 0; v!=0; c++)
            {
                v &= v - 1; // clear the least significant bit set
            }
            return c;
        }
    }
}
