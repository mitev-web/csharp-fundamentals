using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] numbers=new byte[8];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }

            int[] arr = new int[8];
            for (int i = 0; i < numbers.Length; i++)
            {
                int count = 0;
                for (int j = 0; j < arr.Length; j++)
                {                    
                    int andM = numbers[j] & (1<<i);
                    if (((numbers[j] & andM) >> i) == 1) count++;
                }
                arr[i] = count;
            }

            int sumL = 0;
            int flag = 0;

            int s = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                s += arr[i];
            }
            if (s == 0)
            {
                Console.WriteLine("7\n0");
                flag = 1;
            }

            for (int i = 7; i > 0; i--)
            {
                int sumR = 0;
                sumL+=arr[i];
                for (int j = 0; j < i-1; j++)
                {
                    sumR += arr[j];
                }
                if ((sumL == sumR)&&(s!=0))
                {
                    Console.WriteLine("{0}\n{1}", i - 1, sumL);
                    flag = 1;
                    break;
                }
                 
            }
            
            if (flag != 1) Console.WriteLine("No");
        }
    }
}