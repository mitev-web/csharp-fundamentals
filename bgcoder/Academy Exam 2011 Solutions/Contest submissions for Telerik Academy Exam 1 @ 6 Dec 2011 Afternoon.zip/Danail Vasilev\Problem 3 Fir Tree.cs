using System;

class Program
{
    static void Main()
    {
        byte N = byte.Parse(Console.ReadLine());
        for (int i = 1; i < N; i++)
        {
            for (int g = (N - 1); 0 < g; g--)
            {
                if (g <= i)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }

            for (int g = 1; g < N - 1; g++)
            {
                if (g <= i - 1)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }

            Console.WriteLine();
        }

        for (int g = (N - 1); 0 < g; g--)
        {
            if (g <= 1)
            {
                Console.Write("*");
            }
            else
            {
                Console.Write(".");
            }
        }

        for (int g = 1; g < N - 1; g++)
        {
            if (g <= 1 - 1)
            {
                Console.Write("*");
            }
            else
            {
                Console.Write(".");
            }
        }
    }
}
