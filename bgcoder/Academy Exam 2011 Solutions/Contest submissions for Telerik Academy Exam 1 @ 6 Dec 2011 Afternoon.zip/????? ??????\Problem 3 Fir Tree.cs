using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex_3_fir_tree
{
    class ex3_fir_tree
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int width = 1 + ((n - 2) * 2);
            if (n >= 4 && n <= 100)
            {
                char[] array = new char[1 + (n - 2) * 2];
                for (int i = 0; i < width; i++)
                {
                    array[i] = '.';
                }
                int middle = (width / 2);
                for (int i = 0; i < n - 1; i++)
                {
                    array[middle + i] = '*';
                    array[middle - i] = '*';
                    for (int j = 0; j < width; j++)
                    {
                        Console.Write(array[j]);
                    }
                    Console.WriteLine();
                }
                for (int i = 0; i < width; i++)
                {
                    array[i] = '.';
                }
                array[middle] = '*';
                for (int j = 0; j < width; j++)
                {
                    Console.Write(array[j]);
                }
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Enter a number between 4 and 100");
            }
        }
    }
}