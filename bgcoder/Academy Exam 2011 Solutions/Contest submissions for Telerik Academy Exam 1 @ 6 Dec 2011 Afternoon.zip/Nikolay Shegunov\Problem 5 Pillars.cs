using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam06
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }

            int maskLeft = 0x00;
            int maskRight = 0xFF;

            int leftCount = 0;
            int rightCount = 0;
            int temp = 0;

            for (int j = 0; j < 7; j++)
            {
                maskLeft = maskLeft + (byte)(1 << (8 - j));
                maskRight = maskRight >> 1;

                for (int i = 0; i < 8; i++)
                {
                    temp = maskLeft & numbers[i];

                    if (temp != 0)
                    {
                        while (temp != 0)
                        {
                            leftCount = leftCount + temp % 2;
                            temp = temp / 2;
                        }
                    }

                    temp = maskRight & numbers[i];

                    if (temp != 0)
                    {
                        while (temp != 0)
                        {
                            rightCount = rightCount + temp % 2;
                            temp = temp / 2;
                        }
                    }
                }
                if (rightCount == leftCount)
                {
                    Console.WriteLine(8 - (j + 1));
                    Console.WriteLine(leftCount);
                    return;
                }
                leftCount = 0;
                rightCount = 0;
            }
            Console.WriteLine("No");
        }
    }
}