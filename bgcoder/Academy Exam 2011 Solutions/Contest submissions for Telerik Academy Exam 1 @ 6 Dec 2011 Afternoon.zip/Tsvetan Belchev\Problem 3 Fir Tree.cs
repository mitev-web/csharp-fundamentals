using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int q = (2*n)-3;

            int[] arr = new int[q];


            int i = 1;


            for (i = 0; i < q; i++)
            {
                arr[i] = 1;
            }

            arr[n - 2] = 2;

            int p = 1;
            do
            {
                for (i = 0; i < q; i++)
                {
                    if (arr[i] == 2)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }                  
                    
                }
                Console.WriteLine();
                if (p < n-2)
                {
                    arr[n - 2 + p] = 2;
                    arr[n - 2 - p] = 2;
                }
                              
                p++;
            } while (p < n-1);

            for (i = 0; i < q; i++)
            {
                Console.Write("*");
            }
            for (i = 0; i < q; i++)
            {
                arr[i] = 1;
            }

            arr[n - 2] = 2;

            Console.WriteLine();

            for (i = 0; i < q; i++)
            {
                if (arr[i] == 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }

            }

        


            Console.WriteLine();
        }
    }
}
