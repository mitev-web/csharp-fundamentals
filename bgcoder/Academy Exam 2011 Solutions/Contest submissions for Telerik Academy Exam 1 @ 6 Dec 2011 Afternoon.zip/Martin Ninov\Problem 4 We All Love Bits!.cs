using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad4_WeAllLoveBits_
{
    class Program
    {
        static void Main(string[] args)
        {
            int n=0;
            string str;
            int[] nums;
            str = Console.ReadLine();
            int.TryParse(str, out n);

            nums = new int[n];

            for (int i = 0; i < n; i++)
            {
                str = Console.ReadLine();
                int.TryParse(str, out nums[i]);
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine((nums[i] ^ mathematicalNOT(nums[i])) & mathematicalBitReverse(nums[i]));
            }
        }

        static int mathematicalNOT(int num)
        {
            int ret = (int)(Math.Log10(num) / Math.Log10(2) + 1);
            int pow = (int)Math.Pow(2, ret) - 1;
            int not = ~num&pow;
            return not;
        }

        static int mathematicalBitReverse(int num)
        {
            int v = num;
            int r = num;
            int s = 31;
            for (v >>= 1; v!=0; v >>= 1)
            {
                r <<= 1;
                r |= v & 1;
                s--;
            }
            r <<= s;
            return (int)((uint)r >> 32 - (int)(Math.Log10(num) / Math.Log10(2) + 1));
        }
    }
}
