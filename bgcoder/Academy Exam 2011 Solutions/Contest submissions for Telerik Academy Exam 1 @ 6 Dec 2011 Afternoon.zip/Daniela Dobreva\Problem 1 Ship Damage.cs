


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad1Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            int sum = 0;
            if (((cX1 == sX1) || (cY1 == sY1)) || ((sX2 == cX1) || (cY1 == sY2)))
            {
                sum += 25;
                //Console.WriteLine("T ({0}, {1}) is in the corner rectangle!", cX1, cY1);
            }
            else
            {
                if (((sX2 < cX1) && (cY1 < sY1)) ||
                    ((sX1 < cX1) && (cY1 > sY2)))
                {
                    sum += 50;
                   // Console.WriteLine("T ({0}, {1}) is in the contur rectangle!", cX1, cY1);
                }
                else
                {
                     if ((sX1 < cX1) && (cX1 < sY1) && (sX2 < cY1) && (cY1 < sY2))
            {
                sum += 100;
                //Console.WriteLine("T ({0}, {1}) is in the rectangle!", cX1,cY1);

            }
                  
                }

            }
            
            if (((cX2 == sX1) || (cY2 == sY1)) || ((sX2 == cX2) || (cY2 == sY2)))
            {
                sum += 25;
                //Console.WriteLine("T ({0}, {1}) is in the corner rectangle!", cX2, cY2);
            }
            else
            {
                if (((sX2 < cX2) && (cY2 < sY1)) ||
                    ((sX1 < cX2) && (cY2 > sY2)))
                {
                    //Console.WriteLine("T ({0}, {1}) is in the contur rectangle!", cX2, cY2);
                    sum += 50;
                }
                else
                {
                    if ((sX1 < cX2) && (cX2 < sX2) && (sY2 > cY2) && (cY3 > sY1))
                    {
                        //Console.WriteLine("T ({0}, {1}) is in the rectangle!", cX2, cY2);
                        sum += 100;
                    }

                }

            }
           
            if (((cX3 == sX1) ||(cY3 == sY1)) || ((sX2 == cX3) || (cY3 == sY2)))
            {
                sum += 25;
               // Console.WriteLine("T ({0}, {1}) is in the corner rectangle!", cX3, cY3);
            }
            else
            {
                if (((sX2 < cX3) && (cY3 < sY1)) ||
                    ((sX1 < cX3) && (cY3 > sY2)))
                {
                    //Console.WriteLine("T ({0}, {1}) is in the contur rectangle!", cX3, cY3);
                    sum += 50;
                }
                else
                {
                    if ((sX1 < cX3) && (cX3 < sX2) && (sY2 > cY3) && (cY3 > sY1))
                    {
                       // Console.WriteLine("T ({0}, {1}) is in the rectangle!", cX3, cY3);
                        sum += 100;
                    }

                }
            }
            Console.WriteLine(sum);
        }
    }
}
