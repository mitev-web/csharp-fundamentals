using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            byte n = byte.Parse(input);
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < (2 * n) - 3; i++)
            {
                sb.Append(".");
            }
            sb.Replace(".", "*", n - 2, 1);
            Console.WriteLine(sb.ToString());

            int up = 2;
            for (int j = n - 3; j >= 0; j--)
            {
                sb.Replace(".", "*", j, 1);
                sb.Replace(".", "*", j + up, 1);
                up += 2;
                Console.WriteLine(sb.ToString());

            }

            sb.Replace("*", ".");
            sb.Replace(".", "*", n - 2, 1);
            Console.WriteLine(sb.ToString());


        }
    }
}
