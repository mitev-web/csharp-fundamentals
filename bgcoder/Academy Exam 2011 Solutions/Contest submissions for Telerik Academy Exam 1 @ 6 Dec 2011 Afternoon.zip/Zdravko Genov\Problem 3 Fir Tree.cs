using System;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            sbyte height = sbyte.Parse(Console.ReadLine());
            string line = "*";
            for (sbyte i = height, j = (sbyte)(height-2); i > 1; i--, j--)
            {
                Console.WriteLine(line.PadLeft(j + line.Length, '.').PadRight(2*(height-2)+1, '.'));
                line = line + "**";
            }
            Console.WriteLine("*".PadLeft(height - 1, '.').PadRight(2 * (height - 2) + 1, '.'));
        }
    }
}
