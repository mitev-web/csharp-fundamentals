using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static byte OnesInNumber(byte input)
        {
            byte result = 0;

            while (0 != input)
            {
                if (1 == (input & 0x01))
                {
                    result++;
                }
                input >>= 1;
            }

            return result;
        }

        static void Main(string[] args)
        {
            byte[] input = new byte[8];

            for (int i = 0; i < input.Length; i++)
			{
                input[i] = byte.Parse(Console.ReadLine());
			 
			}

            byte[] local = new byte[8];

            byte mask = (byte)0x80;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    local[i] <<= 1;
                    if (0 != (input[7 - j] & mask))
                    {
                        local[i] |= (byte)0x01;
                    }
                    
                }
                mask >>= 1;
            }

            bool noPillars = true;
            byte columnIndex = 0;
            byte numberOfFullCells = 0;

            for (int i = 0; i < 8; i++)
            {
                byte LeftResult = 0;
                byte RightResult = 0;

                for (int j = 0; j < 8; j++)
                {
                    if (j < i)
                    {
                        LeftResult += OnesInNumber(local[j]);
                    }
                    if (j > i)
                    {
                        RightResult += OnesInNumber(local[j]);
                    }
                }

                if ((LeftResult == RightResult) && (LeftResult != 0))
                {
                    noPillars = false;
                    columnIndex = (byte)(7 - i);
                    numberOfFullCells = LeftResult;
                    break;
                }
                
            }
            if (true == noPillars)
            {
                Console.WriteLine("No");
            }
            else
            {
                Console.WriteLine(columnIndex);
                Console.WriteLine(numberOfFullCells);
            }
        }
    }
}
