using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirThree
{
    class Program
    {
        static void Main(string[] args)
        {
            // Read input
            int inputHeight;
            int.TryParse(Console.ReadLine(), out inputHeight);

            // Check input
            //Console.WriteLine(inputHeight);

            int allAsterix = 1;
            int lastRow = 1;
            for (int row = 2; row < inputHeight; row++)
            {
                allAsterix += (lastRow + 2);
                lastRow += 2;
            }
            //lastRow -= 2;

            int currentPosition = (int)Math.Ceiling(lastRow / 2.0);
            
            int lastRowAsterix = 1;
            for (int currentRow = 1; currentRow < inputHeight; currentRow++)
            {
                for (int currentCol = 1; currentCol <= lastRow; currentCol++)
                {
                    if (currentCol == currentPosition)
                    {
                        for (int currentAsterix = 0; currentAsterix < lastRowAsterix; currentAsterix++)
                        {
                            Console.Write("*");
                            currentCol++;
                        }
                        currentCol--;
                        lastRowAsterix += 2;
                        currentPosition--;
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine("");

                if (currentPosition == 0)
                {
                    currentPosition = (int)Math.Ceiling(lastRow / 2.0);

                    for (int currentCol = 1; currentCol <= lastRow; currentCol++)
                    {
                        if (currentCol == currentPosition)
                        {
                            Console.Write("*");
                            //currentCol++;
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    Console.WriteLine("");
                }
            }
        }
    }
}
