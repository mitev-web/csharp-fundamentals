using System;
using System.Numerics;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger first, second, third, fourth = 0;
            int n;
            first = BigInteger.Parse(Console.ReadLine());
            second = BigInteger.Parse(Console.ReadLine());
            third = BigInteger.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n-3; i++)
            {
                if (n == 1)
                {
                    fourth = first;
                    break;
                }
                if (n == 2)
                {
                    fourth = second;
                    break;
                }
                if (n == 3)
                {
                    fourth = third;
                    break;
                }
                fourth = first + second + third;
                first = second;
                second = third;
                third = fourth;
            }
            Console.WriteLine(fourth);
        }
    }
}