using System;

namespace Problem5.Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] input = new int[8];
            for (int i = 0; i < input.Length; i++)
            {
                input[i] = int.Parse(Console.ReadLine());
            }
            int rightOnes = 0;
            int leftOnes = 0;
            int searchedIndex = -1;
            int searchedCount = -1;
            for (int i = 0; i < 8; i++)
            {
                rightOnes = 0;
                leftOnes = 0;
                for (int j = 0; j < 8; j++)
                {
                    rightOnes = rightOnes + RightOnesCount(input[j],i);
                    leftOnes = leftOnes + LeftOnesCount(input[j], i);
                }
               if(leftOnes == rightOnes)
               {
                   searchedIndex = i;
                   searchedCount = leftOnes;
               }
            }
            if (searchedIndex != -1)
            {
                Console.WriteLine(searchedIndex);
                Console.WriteLine(searchedCount);
            }
            else
            {
                Console.WriteLine("No");
            }
        }

        private static int LeftOnesCount(int pNumber, int pos)
        {
            int result = 0;
            for (int i = pos + 1; i < 8; i++)
            {
                if (CheckBitValue(pNumber, i) == true)
                {
                    result++;
                }
            }
            return result;
        }

        private static int RightOnesCount(int pNumber, int pos)
        {
            int result = 0;
            for (int i = pos - 1; i >= 0; i--)
            {
                if (CheckBitValue(pNumber, i) == true)
                {
                    result++;
                }
            }
            return result;
        }

        private static bool CheckBitValue(int pNumber, int pos)
        {
            bool result = false;
            int mask = 1 << pos;
            if ((pNumber & mask) != 0)
            {
                result = true;
            }
            return result;
        }
    }
}
