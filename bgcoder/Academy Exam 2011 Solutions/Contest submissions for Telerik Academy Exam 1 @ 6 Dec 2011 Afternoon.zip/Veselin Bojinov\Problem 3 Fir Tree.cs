using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int left = n-1;
            int right = n-1;
            for (int i = 0; i < (n-1); i++ )
            {
                for (int j = 1; j < ((2*n)-2); j++ )
                {
                    if (j >= left && j <= right)
                    {
                        System.Console.Write("*");
                    }
                    else
                    {
                        System.Console.Write(".");
                    }
                }
                System.Console.WriteLine();
                left--;
                right++;
            }
            for (int i = 0; i < ((2 * n) - 3); i++ )
            {
                if (i == (n - 2))
                {
                    System.Console.Write("*");
                }
                else
                {
                    System.Console.Write(".");
                }
            }
        }
    }
}