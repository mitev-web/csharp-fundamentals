using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N;
            int width;
            N = byte.Parse(Console.ReadLine());
            width = (2*N) - 3;
            for (int i = 0; i <  N; i++)
            {
                if (i == (N-1) || i==0)
                {
                    for (int j = 0; j < (2*N)-3; j++)
                    {
                        if (j != N-2)
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                }
                else if (i == N - 2)
                {
                    for (int k = 0; k < width; k++)
                    {
                        Console.Write("*");
                    }
                }
                else
                {
                    for (int j = 0; j < width; j++)
                    {
                        if (j > ((width - (2 + 2 * i)) / 2) && j < ((width + (2 + 2 * i)) / 2))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                Console.WriteLine();
            }
            

        }
    }
}
