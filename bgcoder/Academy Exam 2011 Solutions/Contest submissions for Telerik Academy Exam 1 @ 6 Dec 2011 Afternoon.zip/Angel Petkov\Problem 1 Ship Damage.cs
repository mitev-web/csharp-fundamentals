using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1, Sy1, Sx2, Sy2, H, Cx1, Cy1, Cx2, Cy2, Cx3, Cy3;

            Sx1 = int.Parse(Console.ReadLine());
            Sy1 = int.Parse(Console.ReadLine());
            Sx2 = int.Parse(Console.ReadLine());
            Sy2 = int.Parse(Console.ReadLine());
            H = int.Parse(Console.ReadLine());
            Cx1 = int.Parse(Console.ReadLine());
            Cy1 = int.Parse(Console.ReadLine());
            Cx2 = int.Parse(Console.ReadLine());
            Cy2 = int.Parse(Console.ReadLine());
            Cx3 = int.Parse(Console.ReadLine());
            Cy3 = int.Parse(Console.ReadLine());

            ushort percents = 0;

            int top, left, right, bottom;
            if (Sx1 < Sx2)
            {
                left = Sx1;
                right = Sx2;
            }
            else
            {
                left = Sx2;
                right = Sx1;
            }

            if (Sy1 < Sy2)
            {
                bottom = Sy1;
                top = Sy2;
            }
            else
            {
                bottom = Sy2;
                top = Sy1;
            }

            int projYPos = Cy1 + (H - Cy1) * 2;
            if (Cx1 > left && Cx1 < right)
            {                
                if ((projYPos > bottom) && (projYPos < top))
                {
                    percents += 100;
                }
                else if ((projYPos == bottom) || (projYPos == top))
                {
                    percents += 50;
                }
            }
            else if (Cx1 == left || Cx1 == right)
            {
                if ((projYPos > bottom) && (projYPos < top))
                {
                    percents += 50;
                }
                else if ((projYPos == bottom) || (projYPos == top))
                {
                    percents += 25;
                }
            }

            projYPos = Cy2 + (H - Cy2) * 2;
            if (Cx2 > left && Cx2 < right)
            {
                if ((projYPos > bottom) && (projYPos < top))
                {
                    percents += 100;
                }
                else if ((projYPos == bottom) || (projYPos == top))
                {
                    percents += 50;
                }
            }
            else if (Cx2 == left || Cx2 == right)
            {
                if ((projYPos > bottom) && (projYPos < top))
                {
                    percents += 50;
                }
                else if ((projYPos == bottom) || (projYPos == top))
                {
                    percents += 25;
                }
            }

            projYPos = Cy3 + (H - Cy3) * 2;
            if (Cx3 > left && Cx3 < right)
            {
                if ((projYPos > bottom) && (projYPos < top))
                {
                    percents += 100;
                }
                else if ((projYPos == bottom) || (projYPos == top))
                {
                    percents += 50;
                }
            }
            else if (Cx3 == left || Cx3 == right)
            {
                if ((projYPos > bottom) && (projYPos < top))
                {
                    percents += 50;
                }
                else if ((projYPos == bottom) || (projYPos == top))
                {
                    percents += 25;
                }
            }

            Console.WriteLine("{0}%",percents);
        }
    }
}
