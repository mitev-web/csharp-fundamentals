using System;

class Tribonacci
{
    static void Main()
    {

        double[] numbers = new double[15000];
        numbers[0] = double.Parse(Console.ReadLine());
        numbers[1] = double.Parse(Console.ReadLine());
        numbers[2] = double.Parse(Console.ReadLine());
        int n = int.Parse(Console.ReadLine());


        for (int i = 0; i < n; i++)
        {
            numbers[i + 3] = numbers[i] + numbers[i + 1] + numbers[i + 2];
        }
        Console.WriteLine(numbers[n-1]);
    }
}
