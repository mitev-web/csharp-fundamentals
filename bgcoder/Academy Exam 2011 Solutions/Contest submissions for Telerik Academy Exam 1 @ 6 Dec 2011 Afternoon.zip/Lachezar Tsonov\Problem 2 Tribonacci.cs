using System;
using System.Numerics;

namespace _2.Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            int firstNumberOfTribonacci = Convert.ToInt32(Console.ReadLine());
            int secondNumberOfTribonacci = Convert.ToInt32(Console.ReadLine());
            int thirdNumberOfTribonacci = Convert.ToInt32(Console.ReadLine());

            short whichMemberOfSequenceToCalculate = Convert.ToInt16(Console.ReadLine());
            if (whichMemberOfSequenceToCalculate == 1)
            {
                Console.WriteLine(firstNumberOfTribonacci);
            }
            else if (whichMemberOfSequenceToCalculate == 2)
            {
                Console.WriteLine(secondNumberOfTribonacci);
            }
            else if (whichMemberOfSequenceToCalculate == 3)
            {
                Console.WriteLine(thirdNumberOfTribonacci);
            }
            else
            {
                BigInteger firstNumber = firstNumberOfTribonacci;
                BigInteger secondNumber = secondNumberOfTribonacci;
                BigInteger thirdNumber = thirdNumberOfTribonacci;
                BigInteger memberWeSeek = 0;
                for (int currentIndexOfMember = 4; currentIndexOfMember <= whichMemberOfSequenceToCalculate; currentIndexOfMember++)
                {
                    memberWeSeek = firstNumber + secondNumber + thirdNumber;
                    firstNumber = secondNumber;
                    secondNumber = thirdNumber;
                    thirdNumber = memberWeSeek;
                }
                Console.WriteLine(memberWeSeek);
            }
        }
    }
}
