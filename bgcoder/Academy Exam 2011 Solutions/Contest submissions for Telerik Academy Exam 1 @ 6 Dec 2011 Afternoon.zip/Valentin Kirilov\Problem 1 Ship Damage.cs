using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class ShipDamage
    {
        public static int getSmallestNumber(int number1, int number2, int number3, int number4, int number5)
        {
            int toReturn = number1;

            if (toReturn > number2)
            {
                toReturn = number2;
            }
            if (toReturn > number3)
            {
                toReturn = number3;
            }
            if (toReturn > number4)
            {
                toReturn = number4;
            }
            if (toReturn > number5)
            {
                toReturn = number5;
            }

            return toReturn;
        }

        public static int hitShipWithCatapult(int shipX1, int shipY1, int shipX2, int shipY2, int catapultX, int catapultY)
        {
            int damageToReturn = 0;

            if (shipX2 < shipX1)
            {
                int c = shipX2;
                shipX2 = shipX1;
                shipX1 = c;
            }
            /*
            if (shipY2 < shipY1)
            {
                int d = shipY2;
                shipY2 = shipY1;
                shipY1 = d;
            }
            */
            //Console.WriteLine("{0} {1} {2} {3}", shipX1, shipY1, shipX2, shipY2);
            //Console.WriteLine("{0} {1}", catapultX, catapultY);

            // Check catapult position and return current damage
            if ((catapultX < shipX1) || (catapultX > shipX2))
            {
                //Console.WriteLine("Catapult is outside the ship X");
            }
            else if ((catapultY > shipY1) || (catapultY < shipY2))
            {
                //Console.WriteLine("Catapult is outside the ship Y");
            }
            else
            {
                if ((catapultX == shipX1) && (catapultY == shipY1))
                {
                    //Console.WriteLine("Hit at the TOP LEFT corner");
                    damageToReturn += 25;
                }
                else if ((catapultX == shipX2) && (catapultY == shipY1))
                {
                    //Console.WriteLine("Hit at the TOP RIGHT corner");
                    damageToReturn += 25;
                }
                else if ((catapultX == shipX1) && (catapultY == shipY2))
                {
                    //Console.WriteLine("Hit at the BOTTOM LEFT corner");
                    damageToReturn += 25;
                }
                else if ((catapultX == shipX2) && (catapultY == shipY2))
                {
                    //Console.WriteLine("Hit at the BOTTOM RIGHT corner");
                    damageToReturn += 25;
                }
                else if ((catapultX == shipX1) || (catapultX == shipX2) || (catapultY == shipY1) || (catapultY == shipY2))
                {
                    //Console.WriteLine("Hit on the border");
                    damageToReturn += 50;
                }
                else
                {
                    //Console.WriteLine("Hit inside");
                    damageToReturn += 100;
                }
            }

            //Console.WriteLine(damageToReturn);
            return damageToReturn;
        }

        static void Main(string[] args)
        {
            // Read input
            int inputSX1, inputSY1, inputSX2, inputSY2, inputH, inputCX1, inputCY1, inputCX2, inputCY2, inputCX3, inputCY3;

            int.TryParse(Console.ReadLine(), out inputSX1);
            int.TryParse(Console.ReadLine(), out inputSY1);
            int.TryParse(Console.ReadLine(), out inputSX2);
            int.TryParse(Console.ReadLine(), out inputSY2);
            int.TryParse(Console.ReadLine(), out inputH);
            int.TryParse(Console.ReadLine(), out inputCX1);
            int.TryParse(Console.ReadLine(), out inputCY1);
            int.TryParse(Console.ReadLine(), out inputCX2);
            int.TryParse(Console.ReadLine(), out inputCY2);
            int.TryParse(Console.ReadLine(), out inputCX3);
            int.TryParse(Console.ReadLine(), out inputCY3);

            // Check input coords
            // Checked 

            // Get the smallest X
            int smallestX = ShipDamage.getSmallestNumber(inputSX1, inputSX2, inputCX1, inputCX2, inputCX3);

            // Get the smallest Y
            int smallestY = ShipDamage.getSmallestNumber(inputSY1, inputSY2, inputCY1, inputCY2, inputCY3);

            //Console.WriteLine("Smallest X = {0}; Smallest Y = {1}", smallestX, smallestY);
            
            /*
            if (smallestX < 0)
            {
                smallestX = Math.Abs(smallestX);
                inputSX1 += smallestX;
                inputSX2 += smallestX;
                inputCX1 += smallestX;
                inputCX2 += smallestX;
                inputCX3 += smallestX;
            }

            inputCY1 = inputH + (inputCY1 + inputH);
            inputCY2 = inputH + (inputCY2 + inputH);
            inputCY3 = inputH + (inputCY3 + inputH);

            if (smallestY < 0)
            {
                smallestY = Math.Abs(smallestY);
                Console.WriteLine("{0} + {1}", inputSY1, smallestY);
                Console.WriteLine("{0} + {1}", inputSY2, smallestY);
                Console.WriteLine("{0} + {1}", inputCY1, smallestY);
                Console.WriteLine("{0} + {1}", inputCY2, smallestY);
                Console.WriteLine("{0} + {1}", inputCY3, smallestY);
                inputSY1 += smallestY;
                inputSY2 += smallestY;
                inputCY1 += smallestY;
                inputCY2 += smallestY;
                inputCY3 += smallestY;
                inputH += smallestY;
            }

            // Make new coords
            //inputCY1 += (inputH - inputCY1);
            //inputCY2 += (inputH - inputCY2);
            //inputCY3 += (inputH - inputCY3);
            */

            inputSY1 -= inputH;
            inputSY2 -= inputH;

            inputCY1 = Math.Abs(inputH - inputCY1);
            inputCY2 = Math.Abs(inputH - inputCY2);
            inputCY3 = Math.Abs(inputH - inputCY3);

            
            int currentDamage = 0;

            // Hit the ship with catapult (C1)
            currentDamage += ShipDamage.hitShipWithCatapult(inputSX1, inputSY1, inputSX2, inputSY2, inputCX1, inputCY1);
            // Hit the ship with catapult (C2)
            currentDamage += ShipDamage.hitShipWithCatapult(inputSX1, inputSY1, inputSX2, inputSY2, inputCX2, inputCY2);
            // Hit the ship with catapult (C2)
            currentDamage += ShipDamage.hitShipWithCatapult(inputSX1, inputSY1, inputSX2, inputSY2, inputCX3, inputCY3);

            // Show result
            Console.WriteLine("{0}%", currentDamage);
        }
    }
}
