using System;

namespace _3.FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            byte heightOfTree = Convert.ToByte(Console.ReadLine());

            byte treeWidth = (byte)(3 + (heightOfTree - 3) * 2);

            int howManyTreePartsOnRow = 1;
            for (int currentRow = 1; currentRow < heightOfTree; currentRow++)
            {
                int howManyNonTreePartsOnBothSides = (treeWidth - howManyTreePartsOnRow) / 2;
                
                //Print left side
                for (int currentColumn = 1; currentColumn <= howManyNonTreePartsOnBothSides; currentColumn++)
                {
                    Console.Write('.');
                }

                //Print tree on row
                for (int counterTreeParts = 1; counterTreeParts <= howManyTreePartsOnRow; counterTreeParts++)
                {
                    Console.Write('*');
                }

                //Print right side
                for (int currentColumn = 1; currentColumn <= howManyNonTreePartsOnBothSides; currentColumn++)
                {
                    Console.Write('.');
                }
                Console.WriteLine();
                howManyTreePartsOnRow += 2;
            }

            //Print lowest part
            for (int currentColumn = 1; currentColumn <= treeWidth; currentColumn++)
            {
                if (currentColumn == (treeWidth + 1) / 2)
                {
                    Console.Write('*');
                }
                else
                {
                    Console.Write('.');
                }
            }
        }
    }
}
