using System;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main()
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());

            if (a + b + c == 0)
            {
                Console.WriteLine(0);
            }
            else if (n > 3)
            {
                BigInteger[] tribNumbers = new BigInteger[n];
                tribNumbers[0] = a;
                tribNumbers[1] = b;
                tribNumbers[2] = c;

                for (int i = 3; i < n; i++)
                {
                    tribNumbers[i] = tribNumbers[i - 1] + tribNumbers[i - 2] + tribNumbers[i - 3];
                }
                Console.WriteLine(tribNumbers[n - 1]);
            }
            else if (n == 3)
            { 
                Console.WriteLine(c); 
            }
            else if (n == 2)
            { 
                Console.WriteLine(b); 
            }
            else if (n == 1)
            { 
                Console.WriteLine(a); 
            }
        }
    }
}
