using System;

namespace ActualExam
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            int hit1=0,hit2=0,hit3=0;
            int damage = 0;
            if (H >= Cy1)
            {
                hit1 = Cy1 + 2 * (H - Cy1);
            }
            else
            {
                hit1 = Cy1 - 2 * (Cy1 - H);
            }
            if (H >= Cy2)
            {
                hit2 = Cy2 + 2 * (H - Cy2);
            }
            else
            {
                hit2 = Cy2 - 2 * (Cy2 - H);
            }
            if (H >= Cy1)
            {
                hit3 = Cy3 + 2 * (H - Cy3);
            }
            else
            {
                hit3 = Cy3 - 2 * (Cy3 - H);
            }
            if (hit1 == Sy1 && Cx1 == Sx1)
            {
                damage += 25;
            }
            else if (hit1 == Sy2 && Cx1 == Sx1)
            {
                damage += 25;
            }
            else if (hit1 == Sy1 && Cx1 == Sx2)
            {
                damage += 25;
            }
            else if (hit1 == Sy2 && Cx1 == Sx2)
            {
                damage += 25;
            }
            if (hit2 == Sy1 && Cx2 == Sx1)
            {
                damage += 25;
            }
            else if (hit2 == Sy2 && Cx2 == Sx1)
            {
                damage += 25;
            }
            else if (hit2 == Sy1 && Cx2 == Sx2)
            {
                damage += 25;
            }
            else if (hit2 == Sy2 && Cx2 == Sx2)
            {
                damage += 25;
            }
            if (hit3 == Sy1 && Cx3 == Sx1)
            {
                damage += 25;
            }
            else if (hit3 == Sy2 && Cx3 == Sx1)
            {
                damage += 25;
            }
            else if (hit3 == Sy1 && Cx3 == Sx2)
            {
                damage += 25;
            }
            else if (hit3 == Sy2 && Cx3 == Sx2)
            {
                damage += 25;
            }
            if ((hit1 == Sy1 || hit1 == Sy2) && Cx1 > Math.Min(Sx1,Sx2) && Cx1 < Math.Max(Sx1,Sx2))
            {
                damage += 50;
            }
            else if ((Cx1 == Sx1 || Cx1 == Sx2) && hit1 > Math.Min(Sy1, Sy2) && hit1 < Math.Max(Sy1, Sy2))
            {
                damage += 50;
            }
            if ((hit2 == Sy1 || hit2 == Sy2) && Cx2 > Math.Min(Sx1, Sx2) && Cx2 < Math.Max(Sx1, Sx2))
            {
                damage += 50;
            }
            else if ((Cx2 == Sx1 || Cx2 == Sx2) && hit2 > Math.Min(Sy1, Sy2) && hit2 < Math.Max(Sy1, Sy2))
            {
                damage += 50;
            }
            if ((hit3 == Sy1 || hit3 == Sy2) && Cx3 > Math.Min(Sx1, Sx2) && Cx3 < Math.Max(Sx1, Sx2))
            {
                damage += 50;
            }
            else if ((Cx3 == Sx1 || Cx3 == Sx2) && hit3 > Math.Min(Sy1, Sy2) && hit3 < Math.Max(Sy1, Sy2))
            {
                damage += 50;
            }
            if (hit1 < Math.Max(Sy1, Sy2) && Cx1 < Math.Max(Sx1, Sx2) &&
                hit1 > Math.Min(Sy1, Sy2) && Cx1 > Math.Min(Sx1, Sx2))
            {
                damage += 100;
            }
            if (hit2 < Math.Max(Sy1, Sy2) && Cx2 < Math.Max(Sx1, Sx2) &&
               hit2 > Math.Min(Sy1, Sy2) && Cx2 > Math.Min(Sx1, Sx2))
            {
                damage += 100;
            }
            if (hit3 < Math.Max(Sy1, Sy2) && Cx3 < Math.Max(Sx1, Sx2) &&
               hit3 > Math.Min(Sy1, Sy2) && Cx3 > Math.Min(Sx1, Sx2))
            {
                damage += 100;
            }
            Console.WriteLine("{0}%",damage);
        }
    }
}
