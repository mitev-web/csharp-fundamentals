using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 8;
            int tmp = 0;
            byte separatorPossition = 0;
            byte sumOnes = 0;
            byte[] arr = new byte[n];
            while (tmp < n)
            {
                arr[tmp] = Convert.ToByte(Console.ReadLine());
                tmp++;
            }
            int countZeros = 0;
            for (int i = 0; i < n; i++)
            {
                if (arr[i] == 0)
                {
                    countZeros++;
                }
            }
            if (countZeros == n)
            {
                Console.WriteLine(7);
                Console.WriteLine(0);
                return;
            }
            byte[] sum = new byte[n];
            for (int i = 0; i < n; i++)
            {
                byte sumation = 0;
                for (int j = 0; j < n; j++)
                {
                    if (arr[j] % 2 == 1)
                    {
                        sumation++;
                    }
                }
                sum[i] = sumation;
                for (int k = 0; k < n; k++)
                {
                    arr[k] = (byte)(arr[k] >> 1);
                }
            }
            if (sum[0] + sum[1] + sum[2] + sum[3] + sum[4] + sum[5] == sum[7])
            {
                separatorPossition = 6;
                sumOnes = sum[7];
                Console.WriteLine(separatorPossition);
                Console.WriteLine(sumOnes);
                return;
            }
            else if (sum[0] + sum[1] + sum[3] + sum[4] + sum[2] == sum[6] + sum[7])
            {
                separatorPossition = 5;
                sumOnes = (byte)(sum[6] + sum[7]);
                Console.WriteLine(separatorPossition);
                Console.WriteLine(sumOnes);
                return;
            }
            else if (sum[0] + sum[1] + sum[2] + sum[3] == sum[5] + sum[6] + sum[7])
            {
                separatorPossition = 4;
                sumOnes = (byte)(sum[5] + sum[6] + sum[7]);
                Console.WriteLine(separatorPossition);
                Console.WriteLine(sumOnes);
                return;
            }
            else if (sum[0] + sum[1] + sum[2] == sum[4] + sum[5] + sum[6] + sum[7])
            {
                separatorPossition = 3;
                sumOnes = (byte)(sum[0] + sum[1] + sum[2]);
                Console.WriteLine(separatorPossition);
                Console.WriteLine(sumOnes);
                return;
            }
            else if (sum[0] + sum[1] ==  sum[3] + sum[4] + sum[5] + sum[6] + sum[7])
            {
                separatorPossition = 2;
                sumOnes = (byte)(sum[0] + sum[1]);
                Console.WriteLine(separatorPossition);
                Console.WriteLine(sumOnes);
                return;
            }
            else if (sum[0] ==  sum[2] + sum[3] + sum[4] + sum[5] + sum[6] + sum[7])
            {
                separatorPossition = 1;
                sumOnes = (byte)(sum[0]);
                Console.WriteLine(separatorPossition);
                Console.WriteLine(sumOnes);
                return;
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
