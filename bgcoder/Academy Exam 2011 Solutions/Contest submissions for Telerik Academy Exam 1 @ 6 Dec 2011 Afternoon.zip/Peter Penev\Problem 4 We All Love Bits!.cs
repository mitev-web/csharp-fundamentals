using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.Problem_4_WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int numberOfNumbers = int.Parse(line);
            
            for (int i = 0; i < numberOfNumbers; i++)
            {
                string number = Console.ReadLine();
                int n = int.Parse(number);

                int counterN = n;
                int count = 0;
                int k = 1; //How many bits
                int p;
                int q;

                long resultFlipped = 1;
                long resultInverted = n;
                long mask;

                while (counterN != 0)
                {
                    if ((counterN & 1) == 1)
                    {
                        count++;
                    }
                    else if ((counterN & 1) == 0)
                    {
                        count++;
                    }
                    counterN >>= 1;
                }

                if (count % 2 == 0)
                {
                    p = (count / 2) - 1; //First bit
                    q = (count / 2); //LastBit

                    for (int f = 1; f <= (count / 2) - 1; f++)
                    {
                        mask = ((n >> p) ^ (n >> q)) & ((1 << k) - 1);
                        resultFlipped = n ^ ((mask << p) | (mask << q));
                        p--;
                        q++;
                    }
                }
                else
                {
                    p = (count / 2) - 1; //First bit
                    q = (count / 2) + 1; //LastBit

                    for (int f = 1; f <= (count / 2); f++)
                    {
                        mask = ((n >> p) ^ (n >> q)) & ((1 << k) - 1);
                        resultFlipped = n ^ ((mask << p) | (mask << q));
                        p--;
                        q++;
                    }
                }

                long nAndMask;
                long bit;

                for (int f = count - 1; f >= 0; f--)
                {
                    p = f;

                    mask = 1 << p;
                    nAndMask = n & mask;
                    bit = nAndMask >> p;
                    if (bit == 1)
                    {
                        mask = ~(1 << p);
                        resultInverted = resultInverted & mask;

                    }
                    if (bit == 0)
                    {
                        mask = 1 << p;
                        resultInverted = resultInverted | mask;
                    }

                }


                long pNew = (n ^ resultInverted) & resultFlipped;
                Console.WriteLine(pNew);
            }     

        }
    }
}
