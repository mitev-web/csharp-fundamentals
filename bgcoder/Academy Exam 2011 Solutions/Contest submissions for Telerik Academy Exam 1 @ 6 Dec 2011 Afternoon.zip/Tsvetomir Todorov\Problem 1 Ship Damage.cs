using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task02
{
    class Tribunacci
    {
        static void Main(string[] args)
        {
            long t1 = 0;
            long t2 = 0;
            long t3 = 0;
            long sum = 0;
            int n =0;

            for (int i = 1; i <= 4; i++)
            {
                if (i == 1) t1 = long.Parse(Console.ReadLine());
                if (i == 2) t2 = long.Parse(Console.ReadLine());
                if (i == 3) t3 = long.Parse(Console.ReadLine());
                if (i == 4) n = int.Parse(Console.ReadLine());
            }
            for (int i = 3; i < n; i++)
            {
                sum = t1 + t2 + t3;
                t1 = t2;
                t2 = t3;
                t3 = sum;
            }
            Console.WriteLine(sum);
        }
    }
}
