using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonaci
{
    class Tribonaci
    {
        static void Main(string[] args)
        {
            BigInteger firstNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger secondNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger thirdNumber = BigInteger.Parse(Console.ReadLine());
            BigInteger result = BigInteger.Parse(Console.ReadLine());
            BigInteger finalNumber = firstNumber;
            if (result >= 1 && result <= 15000)
            {
                for (int i = 3; i < result; i++)
                {
                    finalNumber = firstNumber + secondNumber + thirdNumber;
                    firstNumber = secondNumber;
                    secondNumber = thirdNumber;
                    thirdNumber = finalNumber;
                }
                Console.WriteLine(finalNumber);
            }
        }
    }
}