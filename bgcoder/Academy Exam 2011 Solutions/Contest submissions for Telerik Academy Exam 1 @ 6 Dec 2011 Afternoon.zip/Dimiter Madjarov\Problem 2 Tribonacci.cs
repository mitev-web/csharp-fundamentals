using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _2.Tribonacci
{
	class Tribonacci
	{
		static void Main(string[] args)
		{
			BigInteger first = BigInteger.Parse(Console.ReadLine());
			BigInteger second = BigInteger.Parse(Console.ReadLine());
			BigInteger third = BigInteger.Parse(Console.ReadLine());
			int N = int.Parse(Console.ReadLine());
			BigInteger next = 0;

			if (N == 1)
			{
				Console.WriteLine(first);
				return;
			}

			if (N == 2)
			{
				Console.WriteLine(second);
				return;
			}

			if (N == 3)
			{
				Console.WriteLine(third);
				return;
			}

			for (int i = 0; i < N-3; i++)
			{
				next = first + second + third;
				first = second;
				second = third;
				third = next;
			}
			Console.WriteLine(next);
		}
	}
}
