using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Tribonacci
{
    class Tribon
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CultureCulture = CultureInfo.GetCultureInfo("en-us");
            Console.Write("");
            long firstNum = long.Parse(Console.ReadLine());
            Console.Write("");
            long secondNum = long.Parse(Console.ReadLine());
            Console.Write("");
            long thirthNum = long.Parse(Console.ReadLine());

            Console.Write("");
            int n = int.Parse(Console.ReadLine());
            long tribon = 0;
          
            for (int i = 0; i < n - 3; i++)
            {
                tribon = firstNum + secondNum + thirthNum;
                firstNum = secondNum;
                secondNum = thirthNum;
                thirthNum = tribon;

            }

            Console.WriteLine(tribon);
        }
    }
}