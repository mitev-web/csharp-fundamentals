using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int sx1 = int.Parse(input);
            input = Console.ReadLine();
            int sy1 = int.Parse(input);

            input = Console.ReadLine();
            int sx2 = int.Parse(input);
            input = Console.ReadLine();
            int sy2 = int.Parse(input);

            input = Console.ReadLine();
            int h = int.Parse(input);

            input = Console.ReadLine();
            int cx1 = int.Parse(input);
            input = Console.ReadLine();
            int cy1 = int.Parse(input);

            input = Console.ReadLine();
            int cx2 = int.Parse(input);
            input = Console.ReadLine();
            int cy2 = int.Parse(input);

            input = Console.ReadLine();
            int cx3 = int.Parse(input);
            input = Console.ReadLine();
            int cy3 = int.Parse(input);

            int ax = 0, ay = 0, bx = 0, by = 0;
            if (sx1 < sx2)
            {
                if (sy1 < sy2)
                {
                    ax = sx1;
                    ay = sy1;
                    bx = sx2;
                    by = sy2;
                }
                else
                {
                    ax = sx1;
                    ay = sy2;
                    bx = sx2;
                    by = sy1;
                }
            }
            else
            {
                if (sy2 < sy1)
                {
                    ax = sx2;
                    ay = sy2;
                    bx = sx1;
                    by = sy1;
                }
                else
                {
                    ax = sx2;
                    ay = sy1;
                    bx = sx1;
                    by = sy2;
                }
            }

            int f;
            if(cy1<ay)f=1;
            else f=2;

            int sum=0;

            if (f == 1)
            {
                cy1 = cy1 + 2*(h - cy1);
                cy2 = cy2 + 2*(h - cy2);
                cy3 = cy3 + 2*(h - cy3);

                
            }
            else
            {
                
                cy1 = cy1 - 2 * (cy1 - h);
                cy2 = cy2 - 2 * (cy2 - h);
                cy3 = cy3 - 2 * (cy3 - h);
    
            }
            if (((ax == cx1) && (ay == cy1)) || ((ax == cx1) && (by == cy1)) || ((bx == cx1) && (ay == cy1)) || ((bx == cx1) && (by == cy1)))
                sum += 25;
            if (((ax == cx2) && (ay == cy2)) || ((ax == cx2) && (by == cy2)) || ((bx == cx2) && (ay == cy2)) || ((bx == cx2) && (by == cy2)))
                sum += 25;
            if (((ax == cx3) && (ay == cy3)) || ((ax == cx3) && (by == cy3)) || ((bx == cx3) && (ay == cy3)) || ((bx == cx3) && (by == cy3)))
                sum += 25;

            if (((cx1 == ax) && (cy1 > ay) && (cy1 < by)) || ((cx1 == bx) && (cy1 > ay) && (cy1 < by))) sum+=50;
             if (((cx2 == ax) && (cy2 > ay) && (cy2 < by)) || ((cx2 == bx) && (cy2 > ay) && (cy2 < by))) sum+=50;
              if(((cx3 == ax) && (cy3 > ay) && (cy3 < by)) || ((cx3 == bx) && (cy3 > ay) && (cy3 < by))) sum += 50;

            if (((cy1 == ay) && (cx1 > ax) && (cx1 < bx)) || ((cy1 == by) && (cx1 > ax) && (cx1 < bx))) sum+=50; 
             if(((cy2 == ay) && (cx2 > ax) && (cx2 < bx)) || ((cy2 == by) && (cx2 > ax) && (cx2 < bx))) sum+=50; 
             if(((cy3 == ay) && (cx3 > ax) && (cx3 < bx)) || ((cy3 == by) && (cx3 > ax) && (cx3 < bx))) sum += 50;

             if ((cx1 > ax) && (cx1 < bx) && (cy1 > ay) && (cy1 < by)) sum += 100;
             if ((cx2 > ax) && (cx2 < bx) && (cy2 > ay) && (cy2 < by)) sum += 100;
              if  ((cx3 > ax) && (cx3 < bx) && (cy3 > ay) && (cy3 < by)) sum += 100;

            Console.WriteLine("{0}%", sum);
        }
    }
}
