using System;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte size = byte.Parse(Console.ReadLine());

            for (int i = 0; i < size; i++)
            {
                for (int n = size - 2; n > i; n--)
                {
                    Console.Write(".");

                }
                for (int u = 0; u <= i*2; u++)
                {
                    Console.Write("*");
                }
                for (int j = size - 2; j > i; j--)
                {
                    Console.Write(".");

                }
                Console.Write("\n");
                
            }
        }
    }
}