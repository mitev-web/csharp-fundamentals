using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger sum = 0;
            BigInteger[] s = new BigInteger[n];
            if (n==1)
            {
                Console.WriteLine(a);
            }
            else if (n==2)
            {
                Console.WriteLine(b);
            }
            else if (n==3)
            {
                Console.WriteLine(c);
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    //Console.Write("{0} ", s[i]);
                    sum = sum + s[i];
                    s[i] = a + b + c;
                    a = b;
                    b = c;
                    c = s[i];
                }
                Console.WriteLine(s[n - 4]);
            }
        }
    }
}
