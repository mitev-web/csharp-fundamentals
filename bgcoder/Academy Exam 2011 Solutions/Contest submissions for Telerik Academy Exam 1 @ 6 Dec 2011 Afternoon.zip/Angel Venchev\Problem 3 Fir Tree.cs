using System;

namespace _3
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            for (int i = n; i > 1; i--)
            {
                for (int k = 0; k < (2*(i-1)-1)/2; k++)
                {
                    Console.Write('.');
                }
                for (int k = 0; k < 2*n - 2*i + 1; k++)
                {
                    Console.Write('*');
                }
                for (int k = 0; k < (2*(i-1)-1)/2; k++)
                {
                    Console.Write('.');
                }
                Console.WriteLine();
            }
            int p = n;
            for (int k = 0; k < (2 * (p - 1) - 1) / 2; k++)
            {
                Console.Write('.');
            }
            for (int k = 0; k < 2 * n - 2 * p + 1; k++)
            {
                Console.Write('*');
            }
            for (int k = 0; k < (2 * (p - 1) - 1) / 2; k++)
            {
                Console.Write('.');
            }
        }
    }
}
