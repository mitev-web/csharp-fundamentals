using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[,] bitsArray = new byte[8, 8];
            ushort mask = 1;
            byte sumLeft = 0;
            byte sumRight = 0;
            bool isProblemIsSolved = false;
            // numbers array
            byte[] numbersArray = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                // read next number
                numbersArray[i] = byte.Parse(Console.ReadLine());

                //test
                //numbersArray[0] = 0;
                //numbersArray[1] = 224;
                //numbersArray[2] = 96;
                //numbersArray[3] = 7;
                //numbersArray[4] = 6;
                //numbersArray[5] = 0;
                //numbersArray[6] = 0;
                //numbersArray[7] = 0;

                // read all bits of this number and write in array
                for (int y = 0; y < 8; y++)
                {
                    mask = 1;
                    mask <<= y;

                    if ((ushort)(numbersArray[i] & mask) > 0)
                    {
                        bitsArray[i, y] = 1;
                    }
                    else 
                    {
                        bitsArray[i, y] = 0;
                    }
                }
            }

            for (byte pillar = 6; pillar >= 1; pillar--)
            { 
                // sum left side
                sumLeft = 0;
                sumRight = 0;
                for (int leftColumns = pillar + 1; leftColumns <= 7; leftColumns++)
                {
                    sumLeft += (byte)(
                        bitsArray[0, leftColumns] +
                        bitsArray[1, leftColumns] +
                        bitsArray[2, leftColumns] +
                        bitsArray[3, leftColumns] +
                        bitsArray[4, leftColumns] +
                        bitsArray[5, leftColumns] +
                        bitsArray[6, leftColumns] +
                        bitsArray[7, leftColumns]);
                }
                // sum right side
                for (int rightColumns = 0; rightColumns < pillar; rightColumns++)
                {
                    sumRight += (byte)(
                        bitsArray[0, rightColumns] +
                        bitsArray[1, rightColumns] +
                        bitsArray[2, rightColumns] +
                        bitsArray[3, rightColumns] +
                        bitsArray[4, rightColumns] +
                        bitsArray[5, rightColumns] +
                        bitsArray[6, rightColumns] +
                        bitsArray[7, rightColumns]);
                }

                // if sums are equal, break
                if (sumLeft == sumRight && (sumRight + sumLeft)!= 0)
                {
                    Console.WriteLine(pillar);
                    Console.WriteLine(sumLeft);
                    isProblemIsSolved = true;
                    break;
                }
            }

            if (!isProblemIsSolved)
            {
                Console.WriteLine("No");
            }
        }
    }
}
