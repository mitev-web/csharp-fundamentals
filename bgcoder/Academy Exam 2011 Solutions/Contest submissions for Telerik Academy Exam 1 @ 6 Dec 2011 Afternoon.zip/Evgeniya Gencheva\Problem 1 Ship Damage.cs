using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1 = Convert.ToInt32(Console.ReadLine());
            int sy1 = Convert.ToInt32(Console.ReadLine());
            int sx2 = Convert.ToInt32(Console.ReadLine());
            int sy2 = Convert.ToInt32(Console.ReadLine());
            int h = Convert.ToInt32(Console.ReadLine());
            int cx1 = Convert.ToInt32(Console.ReadLine());
            int cy1 = Convert.ToInt32(Console.ReadLine());
            int cx2 = Convert.ToInt32(Console.ReadLine());
            int cy2 = Convert.ToInt32(Console.ReadLine());
            int cx3 = Convert.ToInt32(Console.ReadLine());
            int cy3 = Convert.ToInt32(Console.ReadLine());

            int damage = 0;

            int distanceToS = Math.Min(sy1, sy2) - h;
            int distanceToH;

            int minX = Math.Min(sx1, sx2);
            int maxX = Math.Max(sx1, sx2);
            int minY = Math.Min(sy1, sy2);
            int maxY = Math.Max(sy1, sy2);
            //c1
            int newCX1 = cx1;
            int newCY1 = 2 * (h - cy1) + cy1;
            if (newCX1 >= minX && newCX1 <= maxX && newCY1 >= minY && newCY1 <= maxY)
            {
                if (newCX1 == minX || newCX1 == maxX)
                {
                    if (newCY1 == minY || newCY1 == maxY)
                    {
                        damage += 25;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
                else
                {
                    if (newCY1 == minY || newCY1 == maxY)
                    {
                        damage += 50;
                    }
                    else
                    {
                        damage += 100;
                    }
                }

            }
            //c2
            int newCX2 = cx2;
            int newCY2 = 2 * (h - cy2) + cy2;
            if (newCX2 >= minX && newCX2 <= maxX && newCY2 >= minY && newCY2 <= maxY)
            {
                if (newCX2 == minX || newCX2 == maxX)
                {
                    if (newCY2 == minY || newCY2 == maxY)
                    {
                        damage += 25;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
                else
                {
                    if (newCY2 == minY || newCY2 == maxY)
                    {
                        damage += 50;
                    }
                    else
                    {
                        damage += 100;
                    }
                }

            }

            //c3
            int newCX3 = cx3;
            int newCY3 = 2 * (h - cy3) + cy3;
            if (newCX3 >= minX && newCX3 <= maxX && newCY3 >= minY && newCY3 <= maxY)
            {
                if (newCX3 == minX || newCX3 == maxX)
                {
                    if (newCY3 == minY || newCY3 == maxY)
                    {
                        damage += 25;
                    }
                    else
                    {
                        damage += 50;
                    }
                }
                else
                {
                    if (newCY3 == minY || newCY3 == maxY)
                    {
                        damage += 50;
                    }
                    else
                    {
                        damage += 100;
                    }
                }

            }
            Console.WriteLine("{0}%", damage);
        }
    }
}
