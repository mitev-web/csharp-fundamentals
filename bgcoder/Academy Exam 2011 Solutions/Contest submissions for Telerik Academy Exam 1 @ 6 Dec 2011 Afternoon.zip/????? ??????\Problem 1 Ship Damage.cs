using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex_1_ship_damage
{
    class ex1_ship_damage
    {
        static void Main()
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            int damage = 0;
            if ((sX1 >= -100000) && (sY1 >= -100000) && (sX2 >= -100000) && (sY2 >= -100000) && (h >= -100000) && (cX1 >= -100000) && (cY1 >= -100000) && (cX2 >= -100000) && (cY2 >= -100000) &&  (cX3 >= -100000) && (cY3 >= -100000) && (sX1 <= 100000) && (sY1 <= 100000) && (sX2 <= 100000) && (sY2 <= 100000) && (h <= 100000) && (cX1 <= 100000) && (cY1 <= 100000) && (cX2 <= 100000) && (cY2 <= 100000) &&  (cX3 <= 100000) && (cY3 <= 100000))
            {
                int topHorizontal = Math.Max(sY1, sY2);
                int bottomHorizontal = Math.Min(sY1, sY2);
                int rightVertical = Math.Max(sX1, sX2);
                int leftVertical = Math.Min(sX1, sX2);
                if (cX1 != cX2 && cX2 != cX3 && cX1 != cX3 && cY1 != cY2 && cY2 != cY3 && cY1 != cY3 && ((h < bottomHorizontal) || (h > topHorizontal) ) /*&& (cY1 < h && cY2 < h && cY3 < h)*/)
                {
                    int hitPoint1Y = h + Math.Abs(cY1);
                    int hitPoint2Y = h + Math.Abs(cY2);
                    int hitPoint3Y = h + Math.Abs(cY3);
                    if (hitPoint1Y == topHorizontal || hitPoint1Y == bottomHorizontal)
                    {
                        if (cX1 == leftVertical || cX1 == rightVertical)
                        {
                            damage = damage + 25;
                        }
                        else if (cX1 > rightVertical && cX1 < rightVertical)
                        {
                            damage = damage + 50;
                        }
                    }
                    if (hitPoint2Y == topHorizontal || hitPoint2Y == bottomHorizontal)
                    {
                        if (cX2 == leftVertical || cX2 == rightVertical)
                        {
                            damage = damage + 25;
                        }
                        else if (cX2 > rightVertical && cX2 < rightVertical)
                        {
                            damage = damage + 50;
                        }
                    }
                    if (hitPoint3Y == topHorizontal || hitPoint3Y == bottomHorizontal)
                    {
                        if (cX3 == leftVertical || cX3 == rightVertical)
                        {
                            damage = damage + 25;
                        }
                        else if (cX3 > rightVertical && cX3 < rightVertical)
                        {
                            damage = damage + 50;
                        }
                    }
                    if (cX1 == leftVertical || cX1 == rightVertical)
                    {
                        if (hitPoint1Y > leftVertical && hitPoint1Y < rightVertical)
                        {
                            damage = damage + 50;
                        }
                    }
                    if (cX2 == leftVertical || cX2 == rightVertical)
                    {
                        if (hitPoint2Y > leftVertical && hitPoint2Y < rightVertical)
                        {
                            damage = damage + 50;
                        }
                    }
                    if (cX3 == leftVertical || cX3 == rightVertical)
                    {
                        if (hitPoint3Y > leftVertical && hitPoint3Y < rightVertical)
                        {
                            damage = damage + 50;
                        }
                    }
                    if (cX1 > leftVertical && cX1 < rightVertical && hitPoint1Y > bottomHorizontal && hitPoint1Y < topHorizontal)
                    {
                        damage = damage + 100;
                    }
                    if (cX2 > leftVertical && cX2 < rightVertical && hitPoint2Y > bottomHorizontal && hitPoint2Y < topHorizontal)
                    {
                        damage = damage + 100;
                    }
                    if (cX3 > leftVertical && cX3 < rightVertical && hitPoint3Y > bottomHorizontal && hitPoint3Y < topHorizontal)
                    {
                        damage = damage + 100;
                    }
                    Console.WriteLine("{0}%", damage);
                }
                
                else
                {
                    Console.WriteLine("The coordinates overlap each other");
                }
            }
            else
            {
                Console.WriteLine("The values do not comply");
            }
        }
    }
}