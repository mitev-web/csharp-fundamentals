using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;


namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            int T1 = int.Parse(Console.ReadLine());
            int T2 = int.Parse(Console.ReadLine());
            int T3 = int.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            BigInteger[] tribonacci=new BigInteger[N+1];
            tribonacci[0]=T1;
            tribonacci[1]=T2;
            tribonacci[2]=T3;
            for (int i = 3; i <= N; i++)
            {
                tribonacci[i] = tribonacci[i - 1] + tribonacci[i - 2] + tribonacci[i - 3];
            }
            Console.WriteLine(tribonacci[N-1]);
        }
    }
}
