using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.Pillars
{
    class Program
    {
        static void Main(string[] args)
        {

            
            byte[] cntArr = new byte[8];
            byte[] numArr = new byte[8];

            for (int i = 0; i < 8; i++)
            {
                numArr[i] = byte.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {

                    if (numArr[i] == 1)
                    {
                        cntArr[j]++;
                        break;
                    }
                    
                    if (numArr[i] % 2 == 1)
                    {
                        cntArr[j]++;
                    }
                    numArr[i] >>= 1;
                } 
            }

            byte leftSum = 0;
            byte rightSum = 0;
            byte? index=null;
            byte sideSum = 0;
            for (int i = 0; i < 8; i++)
            {
                leftSum = rightSum = 0;
                
                for (int j = 0; j < i; j++)
                {
                    rightSum += cntArr[j];
                }
                for (int j = i+1; j < 8; j++)
                {
                    leftSum += cntArr[j];
                }
                if (leftSum==rightSum)
                {
                    index = (byte)i;
                    sideSum = leftSum;
                }
            }

            if (index!=null)
            {
                Console.WriteLine(index);
                Console.WriteLine(sideSum);
            }
            else
            {
                Console.WriteLine("No");
            }

            

        }
    }
}
