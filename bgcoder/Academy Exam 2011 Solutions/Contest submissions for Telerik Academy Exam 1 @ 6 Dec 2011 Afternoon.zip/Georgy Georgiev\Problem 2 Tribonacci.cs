using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Contest2
{
    class Program
    {
        static void Main(string[] args)
        {
            
           long a = long.Parse(Console.ReadLine());
           long b = long.Parse(Console.ReadLine());
           long c = long.Parse(Console.ReadLine());
           int n = int.Parse(Console.ReadLine());
          BigInteger[] fib = new BigInteger[n];
           fib[0] = a;
           fib[1] = b;
           fib[2] = c;
           for (int i = 3; i <= n-1; i++)
            {
                fib[i] = fib[i - 1] + fib[i - 2] +fib[i - 3];
               

            }
             Console.WriteLine( fib[n-1]);
        }
    }
}
