using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _2.Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger firstNumber;
            BigInteger secondNumber;
            BigInteger thirdNumber;
            BigInteger currentResult;
            int wantedNumber;

            firstNumber = BigInteger.Parse(Console.ReadLine());
            secondNumber = BigInteger.Parse(Console.ReadLine());
            thirdNumber = BigInteger.Parse(Console.ReadLine());
            wantedNumber = int.Parse(Console.ReadLine());
            switch (wantedNumber)
            {
                case 1: return;
                case 2: Console.WriteLine(firstNumber); return;
                case 3: currentResult = firstNumber + secondNumber; Console.WriteLine(currentResult);return ;
                case 4: currentResult = firstNumber + secondNumber + thirdNumber; Console.WriteLine(currentResult); return;
                default:break;
            }
            currentResult = firstNumber + secondNumber + thirdNumber;
            for (int i = 4; i < wantedNumber; i++)
            {
                firstNumber = secondNumber;
                secondNumber = thirdNumber;
                thirdNumber = currentResult;
                currentResult = firstNumber + secondNumber + thirdNumber;
            }

            Console.WriteLine(currentResult);
        }
    }
}
