using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lovebits
{
    class LoveBits
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter how many numbers:");
            ushort N=ushort.Parse(Console.ReadLine());
            uint[] numbers = new uint[N];  
            int[] opposite=new int[N];
            ReadNumbers(N, numbers);           
            for (int i = 0; i < N; i++)
            {
                opposite[i] = (int)~numbers[i];
               // Console.WriteLine(opposite[i]);
            }
            int[] inverse = new int[N];
            for (int i = 0; i < N; i++)
            {
                inverse[i]=InverseBytes((byte)numbers[i]);
            }

            int[] newNumbers = new int[N];
            for (int i = 0; i < N; i++)
            {
                newNumbers[i] = (int)((numbers[i] ^ opposite[i]) & inverse[i]);
                Console.WriteLine(newNumbers[i]);
            }
        }

        private static byte InverseBytes(byte inByte)
        {
            byte result = 0x00;
            byte mask = 0x00;

            for (mask = 0x80;
                                Convert.ToInt32(mask) > 0;
                                mask >>= 1)
            {
                result >>= 1;
                byte tempbyte = (byte)(inByte & mask);
                if (tempbyte != 0x00)
                    result |= 0x80;
            }
            return (result);
        }




        private static void ReadNumbers(ushort N, uint[] numbers)
        {
            for (int i = 0; i < N; i++)
            {
                numbers[i] = uint.Parse(Console.ReadLine());
              
               
            }
        }
    }
}
