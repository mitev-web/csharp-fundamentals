using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _04.WeAllLoveBitsFAst
{
    class Program
    {
        static void Main(string[] args)
        {
            int inputSize = int.Parse(Console.ReadLine());
            //long[] answer = new long[1024];
            for (int i = 1; i <= inputSize; i++)
            {
                long curNumber = long.Parse(Console.ReadLine());
                long[] bits=new long[64];
                int counter=0;
                while (curNumber != 0)
                {
                    bits[counter] = curNumber % 2;
                    curNumber /= 2;
                   // Console.Write(bits[counter]);
                    counter++;
                }
               // Console.WriteLine();
                long answer = 0;
                long numSize = counter;
                while (counter > 0)
                {
                    answer = answer*2 + bits[numSize-counter];
                    counter--;
                }

                
                Console.WriteLine(answer);
            }
        }
    }
}
