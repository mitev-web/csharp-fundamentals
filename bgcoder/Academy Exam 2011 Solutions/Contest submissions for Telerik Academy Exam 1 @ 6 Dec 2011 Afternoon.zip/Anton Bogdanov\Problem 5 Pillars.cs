using System;

namespace Ex._5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] n = new int[8];
            int[] myArr = new int[8];

            for (int i = 0; i < n.Length; i++)
            {
                n[i] = int.Parse(Console.ReadLine());
            }
            int position = 0;
            for (int i = 0; i < 8; i++)
            {
                int counter = 0;
                for (int number = 7; number >= 0; number--)
                {
                    if (IsBitOn(n[number], position))
                    {
                        counter++;
                    }
                }
                myArr[position] = counter;
                position++;

            }
            PrintResult(myArr);


        }


        static bool IsBitOn(int number, int position)
        {
            int mask = 1;
            if ((number & (mask << position)) == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        static void PrintResult(int[] myArr) 
        {
            if (myArr[0] + myArr[1] + myArr[2] + myArr[3] + myArr[4] + myArr[5] + myArr[6] == 0) 
            {
                Console.WriteLine(7);
                Console.WriteLine(0);
                return;
            }
            if (myArr[0] + myArr[1] + myArr[2] + myArr[3] + myArr[4] + myArr[5] == myArr[7])
            {
                Console.WriteLine(6);
                Console.WriteLine(myArr[7]);
                return;
            }

            if (myArr[0] + myArr[1] + myArr[2] + myArr[3] + myArr[4] == myArr[6] + myArr[7])
            {
                Console.WriteLine(5);
                Console.WriteLine(myArr[6] + myArr[7]);
                return;
            }
            if (myArr[0] + myArr[1] + myArr[2] + myArr[3] == myArr[5] + myArr[6] + myArr[7])
            {
                Console.WriteLine(4);
                Console.WriteLine(myArr[5] + myArr[6] + myArr[7]);
                return;

            }
            if (myArr[0] + myArr[1] + myArr[2] == myArr[4] + myArr[5] + myArr[6] + myArr[7])
            {
                Console.WriteLine(3);
                Console.WriteLine(myArr[0] + myArr[1] + myArr[2]);
                return;
            }
            if (myArr[0] + myArr[1] == myArr[3] + myArr[4] + myArr[5] + myArr[6] + myArr[7])
            {
                Console.WriteLine(2);
                Console.WriteLine(myArr[0] + myArr[1]);
                return;
            }


            if (myArr[0] == myArr[2] + myArr[3] + myArr[4] + myArr[5] + myArr[6] + myArr[7]) 
            {
                Console.WriteLine(1);
                Console.WriteLine(myArr[0]);
                return;
            }
            if (myArr[1] + myArr[2] + myArr[3] + myArr[4] + myArr[5] + myArr[6] + myArr[7] ==0)
            {
                Console.WriteLine(0);
                Console.WriteLine(0);
                return;
            }
  
            Console.WriteLine("No");
        }
    }
}
    

