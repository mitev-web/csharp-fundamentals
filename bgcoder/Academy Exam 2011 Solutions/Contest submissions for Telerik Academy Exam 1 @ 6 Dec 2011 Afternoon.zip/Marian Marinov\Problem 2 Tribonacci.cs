using System;
using System.Collections.Generic;
using System.Numerics;
using System.Linq;
using System.Text;

namespace Tribnacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger T1 = BigInteger.Parse(Console.ReadLine());
            BigInteger T2 = BigInteger.Parse(Console.ReadLine());
            BigInteger T3 = BigInteger.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());

            if (N == 1)
            {
                Console.WriteLine(T1);
            }
            else if (N == 2)
            {
                Console.WriteLine(T2);
            }
            else if (N == 3)
            {
                Console.WriteLine(T3);
            }
            else
            {
                int nMod3;
                checked
                {
                    for (int n = 4; n <= N; n++)
                    {
                        nMod3 = (n - 1) % 3;
                        if (nMod3 == 0)
                        {
                            T1 = T1 + T2 + T3;
                        }
                        else if (nMod3 == 1)
                        {
                            T2 = T1 + T2 + T3;
                        }
                        else
                        {
                            T3 = T1 + T2 + T3;
                        }
                        if (n == N)
                        {
                            if (nMod3 == 0)
                            {
                                Console.WriteLine(T1);
                            }
                            else if (nMod3 == 1)
                            {
                                Console.WriteLine(T2);
                            }
                            else
                            {
                                Console.WriteLine(T3);
                            }
                        }
                    }
                }
            }
        }
    }
}
