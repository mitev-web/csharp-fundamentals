using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = n - 1; i >= 1; i--)
            {

                for (int j = i-1; j >= 1; j--)
                {
                    Console.Write(".");
                }
                for (int g = i + 1; g <= n; g++)
                {
                    Console.Write("*");
                }
                for (int g = i+2; g <= n; g++)
                {
                    Console.Write("*");
                }
                for (int j = i - 1; j >= 1; j--)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }
            for (int t = 1; t <= n - 2; t++)
        
                Console.Write(".");
            Console.Write("*");
            for (int t = 1; t <= n - 2; t++)

                Console.Write(".");

            Console.WriteLine();
                
        }
    }
}
