using System;
using System.Numerics;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            BigInteger one = BigInteger.Parse(Console.ReadLine());
            BigInteger two = BigInteger.Parse(Console.ReadLine());
            BigInteger three = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger temp;
            for (int i = 4; i <= n; i++)
            {
                temp = three;
                three = three + two + one;
                one = two;
                two = temp;
            }
            Console.WriteLine(three);
        }
    }
}
