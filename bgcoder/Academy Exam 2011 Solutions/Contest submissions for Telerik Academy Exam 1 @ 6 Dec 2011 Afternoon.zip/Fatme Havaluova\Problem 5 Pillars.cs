using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem5
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[,] matrix = new byte[8, 8];
            int input;
            for (int i = 0; i < 8; i++)
            {
                input = Int32.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    if ((input & (1 << j)) != 0)
                        matrix[i, j] = 1;
                }
            }
            int result = 0;
            int eqNumber = 0;
            for (int i = 1; i < 8; i++)
            {
               // Console.WriteLine("sum of left part for col: " + i + " is: " +  getSumOfPart(0, i-1, matrix));
               // Console.WriteLine("sum of right part for col: " + i + " is : " +  getSumOfPart(i + 1, 7, matrix));
                if (getSumOfPart(0, i - 1, matrix) == getSumOfPart(i + 1, 7, matrix))
                {
                    result = i;
                    eqNumber = getSumOfPart(0, i - 1, matrix);
                }
            }
          //  printMatrix(matrix);
          //  Console.Write( getSumOfPart(4, 7, matrix));
            if (result != 0)
            {
                Console.WriteLine(result);
                Console.WriteLine(eqNumber);
            }
            else Console.WriteLine("No");

        }
        static void printMatrix(byte[,] matrix)
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine(" ");
            }
        }
        static int getSumOfPart(int colsBegin,int colsEnd,byte[,] matrix)
        {
            int sum = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = colsBegin; j <= colsEnd; j++)
                {
                    if(matrix[i,j] == 1) sum++;
                }
            }
            return sum;
        }
    }
}
