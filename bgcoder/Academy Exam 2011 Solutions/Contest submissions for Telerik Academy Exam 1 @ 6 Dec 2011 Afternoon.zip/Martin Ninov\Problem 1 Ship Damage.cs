using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace martixy_exam
{

    class Program
    {
        public struct Point
        {
            public int X, Y;

            public Point(int _x, int _y)
            {
                X = _x;
                Y = _y;
            }
        }

        static void Main(string[] args)
        {
            int hOffset = 1; //Y value
            Point[] shipCorner =  new Point[2] { new Point(-11, 6), new Point(-6, 3) };
            Point[] catapults = new Point[] { new Point(-11,-5), new Point(-9, -3), new Point(-6, -1), };
            string str;

            
            str = Console.ReadLine();
            int.TryParse(str, out shipCorner[0].X);

            str = Console.ReadLine();
            int.TryParse(str, out shipCorner[0].Y);

            str = Console.ReadLine();
            int.TryParse(str, out shipCorner[1].X);

            str = Console.ReadLine();
            int.TryParse(str, out shipCorner[1].Y);

            str = Console.ReadLine();
            int.TryParse(str, out hOffset);

            str = Console.ReadLine();
            int.TryParse(str, out catapults[0].X);

            str = Console.ReadLine();
            int.TryParse(str, out catapults[0].Y);

            str = Console.ReadLine();
            int.TryParse(str, out catapults[1].X);

            str = Console.ReadLine();
            int.TryParse(str, out catapults[1].Y);

            str = Console.ReadLine();
            int.TryParse(str, out catapults[2].X);

            str = Console.ReadLine();
            int.TryParse(str, out catapults[2].Y);
            

            int minX = int.MaxValue, minY = int.MaxValue, maxX = int.MinValue, maxY = int.MinValue;

            for (int i = 0; i < shipCorner.Length; i++)
            {
                minX = Math.Min(minX, shipCorner[i].X);
                minY = Math.Min(minY, shipCorner[i].Y);
                maxX = Math.Max(maxX, shipCorner[i].X);
                maxY = Math.Max(maxY, shipCorner[i].Y);
            }
            Point shipTopRight = new Point(maxX, maxY);
            Point shipBottomLeft = new Point(minX, minY);

            int damage = 0;

            for (int i = 0; i < catapults.Length; i++)
            {
                //Console.WriteLine(getDamage(new Point(catapults[i].X, getOppositeNum(catapults[i].Y - hOffset)), new Point(shipTopRight.X, shipTopRight.Y - hOffset), new Point(shipBottomLeft.X, shipBottomLeft.Y - hOffset)));
                damage += getDamage(new Point(catapults[i].X, getOppositeNum(catapults[i].Y - hOffset)), new Point(shipTopRight.X, shipTopRight.Y - hOffset), new Point(shipBottomLeft.X, shipBottomLeft.Y - hOffset));
            }
            Console.WriteLine(damage + "%");
        }



        static int getOppositeNum(int num)
        {
            return (-1 * Math.Sign(num)) * Math.Abs(num);
        }

        // Corners work; 
        static int getDamage(Point testPoint, Point topRight, Point bottomLeft)
        {
            
            if ((testPoint.X > topRight.X || testPoint.X < bottomLeft.X) || (testPoint.Y > topRight.Y || testPoint.Y < bottomLeft.Y))
            {
                return 0;
            }
            
            if ((testPoint.X < topRight.X && testPoint.X > bottomLeft.X) && (testPoint.Y < topRight.Y && testPoint.Y > bottomLeft.Y))
            {
                return 100;
            }

            if (testPoint.X == bottomLeft.X || testPoint.X == topRight.X || testPoint.Y == bottomLeft.Y || testPoint.Y == topRight.Y)
            {
                if ((testPoint.X == bottomLeft.X && testPoint.Y == bottomLeft.Y) || (testPoint.X == topRight.X && testPoint.Y == topRight.Y) || (testPoint.X == bottomLeft.X && testPoint.Y == topRight.Y) || (testPoint.X == topRight.X && testPoint.Y == bottomLeft.Y))
                {
                    return 25;
                }
                else return 50;
            }
            return 0;
        }
    }
}
