using System;

namespace FirTree
{
    class Problem3
    {
        static void Main()
        {
            int row = int.Parse(Console.ReadLine());
            int column = 1;
            int star = 1;

            for (int c = 0; c < row - 2; c++)
            {
                column = column + 2;
            }
            
            int point = (column - 1) / 2;
            

            for (int i = 0; i < row - 2; i++)
            {
                    
                for (int lp = point; lp > 0; lp--)//left points
                {
                    Console.Write(".");
                }
                
                if (star == 1)
                {
                    Console.Write("*");
                }
                else if (star > 1 && star <= column)
                {
                    for (int j = 0; j < star; j++)
                    {
                        Console.Write("*");
                    }
                }
                    
                for (int rp = point; rp > 0; rp--)//right points
                {
                    Console.Write(".");
                }

                point = point - 1;
                star = star + 2;

                Console.WriteLine();
                
            }

            //last row
            for (int s = 0; s < star; s++)//row only stars
            {
                Console.Write("*");
            }
            
            Console.WriteLine();
            for (point = 0; point < (column - 1) / 2; point++)//left points
                {
                    Console.Write(".");
                }
            Console.Write("*");
            for (point = 0; point < (column - 1) / 2; point++)//right points
            {
                Console.Write(".");
            }
            Console.WriteLine();
        }
    }
}