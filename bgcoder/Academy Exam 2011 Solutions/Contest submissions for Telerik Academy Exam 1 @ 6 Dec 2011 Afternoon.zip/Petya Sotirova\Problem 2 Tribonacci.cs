using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;


namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            BigInteger first = BigInteger.Parse(input);
            input = Console.ReadLine();
            BigInteger second = BigInteger.Parse(input);
            input = Console.ReadLine();
            BigInteger third = BigInteger.Parse(input);
            input = Console.ReadLine();
            ushort n = ushort.Parse(input);
            
            BigInteger element = 0;

            if (n == 1) Console.WriteLine(first);
            if (n == 2) Console.WriteLine(second);
            if (n == 3) Console.WriteLine(third);
          
            for (int i = 4; i <n+1; i++)
            {
                element = first + second + third;
                first = second;
                second = third;
                third = element;
            }

            if(n>3) Console.WriteLine(element);
        }
    }
}
