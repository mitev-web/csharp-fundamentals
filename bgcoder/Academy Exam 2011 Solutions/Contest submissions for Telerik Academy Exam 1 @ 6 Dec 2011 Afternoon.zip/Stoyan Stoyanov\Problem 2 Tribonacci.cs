using System;
using System.Numerics;


namespace firstProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            long firstNumber = long.Parse(Console.ReadLine());
            long secondNumber = long.Parse(Console.ReadLine());
            long thirdNumber = long.Parse(Console.ReadLine());

            long number = long.Parse(Console.ReadLine());

            if (number == 1)
            {
                Console.WriteLine("{0}", firstNumber);
                return;
            }
            if (number == 2)
            {
                Console.WriteLine("{0}", secondNumber);
                return;
            }
            if (number == 3)
            {
                Console.WriteLine("{0}", thirdNumber);
                return;
            }


            BigInteger[] arr = new BigInteger[number];

            arr[0] = firstNumber;
            arr[1] = secondNumber;
            arr[2] = thirdNumber;

            for (int i = 3; i < arr.Length; i++)
            {
                arr[i] = arr[i - 1] + arr[i - 2] + arr[i - 3];
            }

            Console.WriteLine("{0}", arr[number - 1]);
        }
    }
}