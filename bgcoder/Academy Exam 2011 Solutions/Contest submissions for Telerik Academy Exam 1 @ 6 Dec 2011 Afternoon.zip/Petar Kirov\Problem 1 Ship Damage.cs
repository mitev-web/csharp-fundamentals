using System;

class Problem1
{
    static int GetDistance(int x1, int x2)
    {
        int distance;
        if (x1 >= 0 && x2 >= 0) { distance = Math.Abs(x1 - x2); return distance; }

        if (x1 < 0 && x2 < 0) { distance = Math.Abs(Math.Abs(x1) - Math.Abs(x2)); return distance; }
        else { distance = Math.Abs(0 - x1) + Math.Abs(0 - x2); return distance; }
    }

    static int GetSymetry(int y, int hY)
    {
        if (y == hY) return hY;

        if (y < hY)
        {
            int k = GetDistance(y, hY);
            return hY + k;
        }

        if (y > hY)
        {
            int k = GetDistance(y, hY);
            return hY - k;
        }
        return 0;//Not needed
    }

    /// <summary>
    /// Gets the damage.
    /// </summary>
    /// <param name="sX1">The S X1.</param>
    /// <param name="sY1">The S y1.</param>
    /// <param name="sX2">The S x2.</param>
    /// <param name="sY2">The S Y2.</param>
    /// <param name="c1X">The c X.</param>
    /// <param name="c2X">The c Y.</param>
    /// <param name="hY">The H Y.</param>
    /// <returns></returns>
    static int GetDamage(int sX1, int sY1, int sX2, int sY2, int hY, int cX, int cY)
    {
        int damage = 0;
        int sWidth = GetDistance(sX1, sX2);
        int sHeight = GetDistance(sY1, sY2);
        //x
        if (true)
        {

        }
        //Y
        if (true)
        {

        }
        //Corners
        if (sX1 == cX && sY1 == GetSymetry(cY, hY))
        {
            return 25;
        }
        if (sX2 == cX && sY2 == GetSymetry(cY, hY))
        {
            return 25;
        }
        if (sX1 == cX && sY2 == GetSymetry(cY, hY))
        {
            return 25;
        }
        if (sX2 == cX && sY1 == GetSymetry(cY, hY))
        {
            return 25;
        }

        return damage;
    }

    static void Main()
    {
        int sX1 = int.Parse(Console.ReadLine()),
            sY1 = int.Parse(Console.ReadLine()),
            sX2 = int.Parse(Console.ReadLine()),
            sY2 = int.Parse(Console.ReadLine()),
            hY = int.Parse(Console.ReadLine()),
            c1X = int.Parse(Console.ReadLine()),
            c1Y = int.Parse(Console.ReadLine());
            //c2X = int.Parse(Console.ReadLine()),
            //c2Y = int.Parse(Console.ReadLine()),
            //c3X = int.Parse(Console.ReadLine()),
            //c3Y = int.Parse(Console.ReadLine());

        int TotalDamage = 0;

        TotalDamage = GetDamage(sX1, sY1, sX2, sY2, hY, c1X, c1Y);
            //+ GetDamage(sX1, sY1, sX2, sY2, c2X, c2Y, hY)
            //+ GetDamage(sX1, sY1, sX2, sY2, c3X, c3Y, hY);
        Console.WriteLine(TotalDamage + "%");
    }
}

