using System;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int bitLenght = 0;
            uint bitInput;
            uint bitInverted;
            uint bitReverse;
            uint mask =1;

            uint bitAndMask;
            uint bit;

            n = int.Parse(Console.ReadLine());

            uint[] bitArray = new uint[n];

            for (int i = 0; i < n; i++)
            {
                //Initialize values
                bitInput = uint.Parse(Console.ReadLine());
                bitInverted = bitInput;
                bitReverse = bitInput;

                //Determin number of bits
                for (int k = 0; k < 32; k++)
                {
                    mask = 1u << k;
                    bitAndMask = mask & bitInput;
                    bit = bitAndMask >> k;

                    if (bit == 1)
                    {
                        bitLenght = k+1;
                    }

                }
                bitInverted = ~bitInverted;
                mask = 4294967295u << bitLenght;

                bitInverted = bitInverted ^ mask;

                //Reverse number
                char[] chars = Convert.ToString(bitReverse, 2).ToCharArray();
                Array.Reverse(chars);
                bitReverse = Convert.ToUInt32(new string(chars), 2);

                bitArray[i] = (bitInput ^ bitInverted) & bitReverse;

            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(bitArray[i]);
            }

        }
    }
}