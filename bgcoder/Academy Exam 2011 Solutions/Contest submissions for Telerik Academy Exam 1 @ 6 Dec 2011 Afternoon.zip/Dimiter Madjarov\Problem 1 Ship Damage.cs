using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.ShipDamage
{
	class ShipDamage
	{
		static void Main(string[] args)
		{
			//ship coordinates
			int rectX1 = int.Parse(Console.ReadLine());
			int rectY1 = int.Parse(Console.ReadLine());
			int rectX2 = int.Parse(Console.ReadLine());
			int rectY2 = int.Parse(Console.ReadLine());
			//horizon
			int horizon = int.Parse(Console.ReadLine());
			//catapult coordinates
			int c1x = int.Parse(Console.ReadLine());
			int c1y = int.Parse(Console.ReadLine());
			int c2x = int.Parse(Console.ReadLine());
			int c2y = int.Parse(Console.ReadLine());
			int c3x = int.Parse(Console.ReadLine());
			int c3y = int.Parse(Console.ReadLine());

			int topLeftCornerX = 0;
			int topLeftCornerY = 0;
			int bottomRightCornerX = 0;
			int bottomRightCornerY = 0;

			//find exact ship position
			if (rectX1 > rectX2 && rectY1 > rectY2)
			{
				topLeftCornerX = rectX2;
				topLeftCornerY = rectY1;
				bottomRightCornerX = rectX1;
				bottomRightCornerY = rectY2;
			}
			if (rectX1 > rectX2 && rectY1 < rectY2)
			{
				topLeftCornerX = rectX2;
				topLeftCornerY = rectY2;
				bottomRightCornerX = rectX1;
				bottomRightCornerY = rectY1;
			}
			if (rectX1 < rectX2 && rectY1 > rectY2)
			{
				topLeftCornerX = rectX1;
				topLeftCornerY = rectY1;
				bottomRightCornerX = rectX2;
				bottomRightCornerY = rectY2;
			}
			if (rectX1 < rectX2 && rectY1 < rectY2)
			{
				topLeftCornerX = rectX1;
				topLeftCornerY = rectY2;
				bottomRightCornerX = rectX2;
				bottomRightCornerY = rectY1;
			}

			//calculate catapult1 hit position
			int distanceToHorizon;
			int c1hitPositionX = c1x;
			int c1hitPositionY;
			if (c1y < horizon)
			{
				distanceToHorizon = horizon - c1y;
				c1hitPositionY = c1y + (2 * distanceToHorizon);
			}
			else
			{
				distanceToHorizon = c1y - horizon;
				c1hitPositionY = c1y - (2 * distanceToHorizon);
			}

			//calculate catapult2 hit position
			int distanceToHorizon2;
			int c2hitPositionX = c2x;
			int c2hitPositionY;
			if (c2y < horizon)
			{
				distanceToHorizon2 = horizon - c2y;
				c2hitPositionY = c2y + (2 * distanceToHorizon2);
			}
			else
			{
				distanceToHorizon2 = c2y - horizon;
				c2hitPositionY = c2y - (2 * distanceToHorizon2);
			}

			//calculate catapult3 hit position
			int distanceToHorizon3;
			int c3hitPositionX = c3x;
			int c3hitPositionY;
			if (c3y < horizon)
			{
				distanceToHorizon3 = horizon - c3y;
				c3hitPositionY = c3y + (2 * distanceToHorizon3);
			}
			else
			{
				distanceToHorizon3 = c3y - horizon;
				c3hitPositionY = c3y - (2 * distanceToHorizon3);
			}

			int totalDamage = 0;
			//if it touches rectangle
			if (c1hitPositionX >= topLeftCornerX && c1hitPositionX <= bottomRightCornerX &&
				c1hitPositionY <= topLeftCornerY && c1hitPositionY >= bottomRightCornerY)
			{
				totalDamage += 25;
				//if its on border
				if ((c1hitPositionX > topLeftCornerX && c1hitPositionX < bottomRightCornerX && c1hitPositionY == bottomRightCornerY) ||
					(c1hitPositionX == bottomRightCornerX && c1hitPositionY > bottomRightCornerY && c1hitPositionY < topLeftCornerY) ||
					(c1hitPositionX > topLeftCornerX && c1hitPositionX < bottomRightCornerX && c1hitPositionY == topLeftCornerY) ||
					(c1hitPositionX == topLeftCornerX && c1hitPositionY > bottomRightCornerY && c1hitPositionY < topLeftCornerY))
				{
					totalDamage += 25;
				}
				//if its inside
				if (c1hitPositionX > topLeftCornerX && c1hitPositionX < bottomRightCornerX &&
					c1hitPositionY < topLeftCornerY && c1hitPositionY > bottomRightCornerY)
				{
					totalDamage += 75;
				}
			}

			if (c2hitPositionX >= topLeftCornerX && c2hitPositionX <= bottomRightCornerX &&
				c2hitPositionY <= topLeftCornerY && c2hitPositionY >= bottomRightCornerY)
			{
				totalDamage += 25;
				//if its on border
				if ((c2hitPositionX > topLeftCornerX && c2hitPositionX < bottomRightCornerX && c2hitPositionY == bottomRightCornerY) ||
					(c2hitPositionX == bottomRightCornerX && c2hitPositionY > bottomRightCornerY && c2hitPositionY < topLeftCornerY) ||
					(c2hitPositionX > topLeftCornerX && c2hitPositionX < bottomRightCornerX && c2hitPositionY == topLeftCornerY) ||
					(c2hitPositionX == topLeftCornerX && c2hitPositionY > bottomRightCornerY && c2hitPositionY < topLeftCornerY))
				{
					totalDamage += 25;
				}
				//if its inside
				if (c2hitPositionX > topLeftCornerX && c2hitPositionX < bottomRightCornerX &&
					c2hitPositionY < topLeftCornerY && c2hitPositionY > bottomRightCornerY)
				{
					totalDamage += 75;
				}
			}

			if (c3hitPositionX >= topLeftCornerX && c3hitPositionX <= bottomRightCornerX &&
				c3hitPositionY <= topLeftCornerY && c3hitPositionY >= bottomRightCornerY)
			{
				totalDamage += 25;
				//if its on border
				if ((c3hitPositionX > topLeftCornerX && c3hitPositionX < bottomRightCornerX && c3hitPositionY == bottomRightCornerY) ||
					(c3hitPositionX == bottomRightCornerX && c3hitPositionY > bottomRightCornerY && c3hitPositionY < topLeftCornerY) ||
					(c3hitPositionX > topLeftCornerX && c3hitPositionX < bottomRightCornerX && c3hitPositionY == topLeftCornerY) ||
					(c3hitPositionX == topLeftCornerX && c3hitPositionY > bottomRightCornerY && c3hitPositionY < topLeftCornerY))
				{
					totalDamage += 25;
				}
				//if its inside
				if (c3hitPositionX > topLeftCornerX && c3hitPositionX < bottomRightCornerX &&
					c3hitPositionY < topLeftCornerY && c3hitPositionY > bottomRightCornerY)
				{
					totalDamage += 75;
				}
			}

			Console.WriteLine(totalDamage + "%");
		}
	}
}
