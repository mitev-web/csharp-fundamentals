using System;

namespace FigTree
{
    class FigTree
    {
        static void Main()
        {

            byte n = byte.Parse(Console.ReadLine());
            while ((n >= 4) && (n <= 100))
            {


                for (int rows = 0; rows <= n - 1; rows--)
                    rows = rows % 2;

                {
                    for (int col = 0; col <= row; col++)
                    {
                        Console.Write("*");
                    }


                    for (int tree = 0; tree <= row; tree++)
                    {
                        Console.Write(".");

                    }


                    for (int row1 = row; row1 < n; row1++)
                    {
                        for (int col = 0; col <= row - 1; col++)
                        {

                            Console.Write("*");
                        }




                        for (int trees = 0; trees <= row - 2; trees++)
                        {
                            Console.Write(".");
                        }



                    }





                }



            }
        }
    }