using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            int dmg = 0;
            bool c1X = ((cX1 > sX1 && cX1 < sX2) || (cX1 < sX1 && cX1 > sX2));
            bool c1Y = (-(cY1 - h) > sY1 && -(cY1 - h) < sY2) || (-(cY1 - h) < sY1 && -(cY1 - h) > sY2);
            if (c1X && c1Y)
            {
                dmg += 100;
            }
            bool c2X = ((cX2 > sX1 && cX2 < sX2) || (cX2 < sX1 && cX2 > sX2));
            bool c2Y = (-(cY2 - h) > sY1 && -(cY2 - h) < sY2) || (-(cY2 - h) < sY1 && -(cY2 - h) > sY2);
            if (c2X && c2Y)
            {
                dmg += 100;
            }
            bool c3X = ((cX3 > sX1 && cX3 < sX2) || (cX3 < sX1 && cX3 > sX2));
            bool c3Y = (-(cY3 - h) > sY1 && -(cY3 - h) < sY2) || (-(cY3 - h) < sY1 && -(cY3 - h) > sY2);
            if (c3X && c3Y)
            {
                dmg += 100;
            }
            bool borderC1X = ((cX1 > sX1 && cX1 < sX2) && ((-(cY1 - h) == sY1) || -(cY1 - h) == sY2));
            if (borderC1X)
            {
                dmg += 50;
            }
 
            bool borderC2X = ((cX2 > sX1 && cX2 < sX2) && ((-(cY2 - h) == sY1) || -(cY2 - h) == sY2));
            if (borderC2X)
            {
                dmg += 50;
            }
            bool borderC3X = ((cX3 > sX1 && cX3 < sX2) && ((-(cY3 - h) == sY1) || -(cY3 - h) == sY2));
            if (borderC1X)
            {
                dmg += 50;
            }
            bool cornerCX1 = (cX1 == sX1 && -(cY1 - h) == sY1-h) || (cX1 == sX1 && -(cY1 - h) == sY2-h)
                || (cX1 == sX2 && -(cY1 - 2 ) == sY1-h) || (cX1 == sX2 && -(cY1 - h) == sY2-h);
            if (cornerCX1)
            {
                dmg += 25;
            }
            bool cornerCX2 = (cX2 == sX1 && -(cY2 - h) == sY1-h) || (cX2 == sX1 && -(cY2 -  h) == sY2-h)
                || (cX2 == sX2 && -(cY2 -  h) == sY1-h) || (cX2 == sX2 && -(cY2 -  h) == sY2-h);
            if (cornerCX2)
            {
                dmg += 25;
            }
            bool cornerCX3 = (cX3 == sX1 && -(cY3 -  h) == sY1-h) || (cX3 == sX1 && -(cY3 - h) == sY2-h)
                || (cX3 == sX2 && -(cY3 -  h) == sY1-h) || (cX3 == sX2 && -(cY3 -  h) == sY2-h);
            if (cornerCX3)
            {
                dmg += 25;
            }
            Console.WriteLine("{0}%", dmg);
        }
    }
}