using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            // Read input
            byte currentLine;

            Boolean[,] array = new Boolean[8, 8];
            int currentFillPosition;
            String currntLineString;
            int currentColPosition;

            for (int currentRow = 0; currentRow < 8; currentRow++)
            {
                byte.TryParse(Console.ReadLine(), out currentLine);
                currntLineString = Convert.ToString(currentLine, 2);
                currentColPosition = 7;

                for (int currentStringIndex = currntLineString.Length - 1; currentStringIndex >= 0; currentStringIndex--)
                {
                    if (currntLineString[currentStringIndex] == '1')
                    {
                        array[currentRow, currentColPosition] = true;
                    }
                    currentColPosition--;
                }
            }

            int leftSideFill = 0;
            int rightSideFill = 0;
            int[] colsFill = new int[8];

            int currentLeftCol = 0;
            int currentRightCol = 7;

            for (int currentCounter = 0; currentCounter < 4; currentCounter++)
            {
                currentRightCol = 7 - currentCounter;
                currentLeftCol = currentCounter;

                // Count left col
                for (int currentRow = 0; currentRow < 8; currentRow++)
                {
                    if (array[currentRow, currentLeftCol] == true)
                    {
                        leftSideFill++;
                    }
                }

                // Count right col
                for (int currentRow = 0; currentRow < 8; currentRow++)
                {
                    if (array[currentRow, currentRightCol] == true)
                    {
                        rightSideFill++;
                    }
                }

                
            }

            int pillarCol = 0;
            int currentColFill = 0;

            // Get all cols fill
            int currenColFill;
            for (int col = 0; col < 8; col++)
            {
                currentColFill = 0;
                for (int row = 0; row < 8; row++)
                {
                    if (array[row, col] == true)
                    {
                        currentColFill++;
                    }
                }
                colsFill[col] = currentColFill;
            }

            int allFill = leftSideFill + rightSideFill;
            int leftFill = 0;
            int rightFill = 0;
            int nextLeftFill = 0;
            for (int col = 7; col > 0; col--)
            {
                leftFill = 0;
                rightFill = 0;
                for (int currentCol = col; currentCol < 8; currentCol++)
                {
                    rightFill += colsFill[currentColFill];
                }
                for (int currentCol = col; currentCol > 0; currentCol--)
                {
                    leftFill += colsFill[currentColFill];
                }
                if (col == 0)
                {
                    Console.WriteLine("No");
                    return;
                }
                nextLeftFill = colsFill[col-1];

                //Console.WriteLine("Left fill {0} {1}", col-1, nextLeftFill);
                //Console.WriteLine("SUB = {0} ?= {1}", (leftFill - colsFill[col-1]), rightFill);
                if ((leftFill - colsFill[col-1]) == rightFill)
                {
                    if ((leftFill - colsFill[col - 1]) == 0)
                    {
                        Console.WriteLine("No");
                    }
                    else
                    {
                        Console.WriteLine(col);
                        Console.WriteLine((leftFill - colsFill[col - 1]));
                    }
                    break;
                }
                //Console.WriteLine("{0} {1}", leftFill, rightFill);
            }

            // Show array            
            /*
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    Console.Write("{0} ", (array[row, col] == true) ? "1 " : "0 ");
                }
                Console.WriteLine("");
            }
            */
            Console.WriteLine("");
        }
    }
}
