using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hfghf
{
    class Program
    {
        static void Main(string[] args)
        {
            int h = int.Parse(Console.ReadLine());

            for (int n = 1; n < h +2; n++)
            {
                if (n <= h)
                {
                    Console.WriteLine(new String('*', n * 2 - 1).PadLeft(h+n));
                }
                else
                    Console.WriteLine( "*".PadLeft(h+1));
                
            }
        }
    }
}
