using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
            int cy11 = (h + (h - cy1));
            int cy22 = (h + (h - cy2));
            int cy33 = (h + (h - cy3));
            int biggersx = 0;
            int biggersy = 0;
            int smallersx = 0;
            int smallersy = 0;
     

            if (sx1 > sx2)
            {
                biggersx = sx1;
                smallersx = sx2;
            }
            else
            {
                biggersx = sx2;
                smallersx = sx1;
            }
            if (sy1 > sy2)
            {
                biggersy = sy1;
                smallersy = sy2;
            }
            else
            {
                biggersy = sy2;
                smallersy = sy1;
            }
             
  ////damage - 25%          
            int damage = 0;
            if (((cx1 == sx1) && (cy11 == sy1)) || ((cx1 == sx1) && (cy11 == sy2)) ||
                ((cx1 == sx2) && (cy11 == sy2)) || ((cx1 == sx2) && (cy11 == sy1)))
            {
                damage = damage + 25;
            }
            if (((cx2 == sx1) && (cy22 == sy1)) || ((cx2 == sx1) && (cy22 == sy2)) ||
                ((cx2 == sx2) && (cy22 == sy2)) || ((cx2 == sx2) && (cy22 == sy1)))
            {
                damage = damage + 25;
            }

            if (((cx3 == sx1) && (cy33 == sy1)) || ((cx3 == sx1) && (cy33 == sy2)) ||
                ((cx3 == sx2) && (cy33 == sy2)) || ((cx3 == sx2) && (cy33 == sy1)))
            {
                damage = damage + 25;
            }

  

            //damage - 50 %

            if (((cx1 == sx1) || (cx1 == sx2)) && (cy11 > smallersy) && (cy11 < biggersy))
            {
                damage = damage + 50;
            }

            if (((cx2 == sx1) || (cx2 == sx2)) && (cy22 >smallersy) && (cy22 < biggersy))
            {
                damage = damage + 50;
            }

            if (((cx3 == sx1) || (cx3 == sx2)) && (cy33 > smallersy) && (cy33 < biggersy))
            {
                damage = damage + 50;
            }
      

            if (((cy11 == sy1) || (cy11 == sy1)) && (cx1 > smallersx) && (cx1 < biggersx))
            {
                damage = damage + 50;
            }
            if (((cy22 == sy1) || (cy22 == sy1)) && (cx2 > smallersx) && (cx2 < biggersx))
            {
                damage = damage + 50;
            }
            if (((cy22 == sy1) || (cy22 == sy1)) && (cx2 > smallersx) && (cx2 < biggersx))
            {
                damage = damage + 50;
            }
    
            //damage - 100%

            if ((cx1 > smallersx) && (cx1 < smallersy) && (cy11 > smallersy) && (cy11 < biggersy))
            {
                damage = damage + 100;
            }
    

            if ((cx2 > smallersx) && (cx2 < smallersy) && (cy22 > smallersy) && (cy22 < biggersy))
            {
                damage = damage + 100;
            }

            if ((cx3 > smallersx) && (cx3 < smallersy) && (cy33 > smallersy) && (cy33 < biggersy))
            {
                damage = damage + 100;
            }
            Console.WriteLine(damage + "%");
            

       


        }
    }
}
