using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.FirTree
{
    class Program
    {
        static void Main(string[] args)
        {

            byte n = byte.Parse(Console.ReadLine());

            int k = 1 + (n - 2) * 2;

            for (int i = 0; i < n-1; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    if (j>=k/2 -i && j<=k/2+i)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }

                Console.WriteLine();
            }

            for (int i = 0; i < k; i++)
            {
                if (i==k/2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
        }
    }
}
