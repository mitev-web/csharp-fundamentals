using System;

namespace ShipDamage2
{
    class Program
    {
        struct Point
        {
            public int x;
            public int y;
        }

        static int percents = 0;
        static Point S1;
        static Point S2;

        static void CheckDamage(Point point)
        {
            if (S1.x == point.x && S1.y == Math.Abs(point.y))
            {
                percents += 25;
            }

            if (S2.x == point.x && S2.y == Math.Abs(point.y))
            {
                percents += 25;
            }

            if (S2.x == point.x && S1.y == Math.Abs(point.y))
            {
                percents += 25;
            }

            if (S1.x == point.x && S2.y == Math.Abs(point.y))
            {
                percents += 25;
            }

            if (S1.y == Math.Abs(point.y) && point.x > S1.x && point.x < S2.x)
            {
                percents += 50;
            }

            if (S2.y == Math.Abs(point.y) && point.x > S1.x && point.x < S2.x)
            {
                percents += 50;
            }

            if (S1.x == point.x && Math.Abs(point.y) < S1.y && Math.Abs(point.y) > S2.y)
            {
                percents += 50;
            }

            if (S2.x == point.x && Math.Abs(point.y) < S1.y && Math.Abs(point.y) > S2.y)
            {
                percents += 50;
            }

            if (point.x > S1.x && point.x < S2.x && Math.Abs(point.y) < S1.y && Math.Abs(point.y) > S2.y)
            {
                percents += 100;
            }
        }

        static void Main()
        {
            S1.x = int.Parse(Console.ReadLine());
            S1.y = int.Parse(Console.ReadLine());
            S2.x = int.Parse(Console.ReadLine());
            S2.y = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            Point C1 = new Point();
            C1.x = int.Parse(Console.ReadLine());
            C1.y = int.Parse(Console.ReadLine());

            Point C2 = new Point();
            C2.x = int.Parse(Console.ReadLine());
            C2.y = int.Parse(Console.ReadLine());

            Point C3 = new Point();
            C3.x = int.Parse(Console.ReadLine());
            C3.y = int.Parse(Console.ReadLine());


            if (H > 0)
            {
                S1.y -= H;
                S2.y -= H;
                C1.y -= H;
                C2.y -= H;
                C3.y -= H;
            }
            else if (H < 0)
            {
                int h = Math.Abs(H);
                S1.y += h;
                S2.y += h;
                C1.y += h;
                C2.y += h;
                C3.y += h;
            }

            if (S1.x > S2.x && S1.y > S2.y)
            {
                int swap = S1.x;
                S1.x = S2.x;
                S2.x = swap;
            }

            if (S1.y < S2.y && S1.x < S2.x)
            {
                int swap = S1.y;
                S1.y = S2.y;
                S2.y = swap;
            }

            if (S1.x > S2.x && S1.y < S2.y)
            {
                int swap = S1.x;
                S1.x = S2.x;
                S2.x = swap;

                swap = S1.y;
                S1.y = S2.y;
                S2.y = swap;
            }


            CheckDamage(C1);
            CheckDamage(C2);
            CheckDamage(C3);
            Console.WriteLine(percents.ToString() + "%");
        }
    }
}
