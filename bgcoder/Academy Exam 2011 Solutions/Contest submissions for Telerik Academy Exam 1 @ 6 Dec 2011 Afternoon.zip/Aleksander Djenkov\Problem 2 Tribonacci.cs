using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace task2
{
    class task2
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            BigInteger  d=0;
            
         for(int i=3;i<N;i++) 
         {
               d = a + b + c;
               a = b; 
               b = c; 
               c = d;  
         }
         if (N ==1) Console.WriteLine(1);
         if (N == 2) Console.WriteLine(1);
         if (N == 3) Console.WriteLine(1);
         if(N>3) Console.Write(d);
        }
  
    }
}
