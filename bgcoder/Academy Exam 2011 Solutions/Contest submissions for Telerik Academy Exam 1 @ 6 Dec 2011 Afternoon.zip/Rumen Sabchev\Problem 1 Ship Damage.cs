using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            int dmg = 0;
            Cy1 =Cy1- 1;
            Cy2 = Cy2-1;
            Cy3 = Cy3-1;
            if (h != Sx2)
            {
                if (Cx1 != Cx2 && Cx1!= Cx3 && Cx2!= Cx3)
                {
                    bool withinShip = false;
                    if ((Cx1 > Sx1) && (-Cy1 + h < Sy1) && (Cx1 < Sx2) && (-Cy1 + h > Sy2))
                        withinShip = true;
                    if (withinShip == true)
                    {
                        dmg = dmg + 100;
                    }
                    withinShip = false;
                    if ((Cx2 > Sx1) && (-Cy2 + h < Sy1) && (Cx2 < Sx2) && (-Cy2 + h > Sy2))
                        withinShip = true;
                    if (withinShip == true)
                    {
                        dmg = dmg + 100;
                    }
                    if ((Cx3 > Sx1) && (-Cy3 + h < Sy1) && (Cx3 < Sx2) && (-Cy3 + h > Sy2))
                        withinShip = true;
                    if (withinShip == true)
                    {
                        dmg = dmg + 100;
                    }
                    if ((Cx1 == Sx1) && (-Cy1 + h == Sy1) || (Cx1 == Sx2) && (-Cy1 + h == Sy2) || (Cx1 == Sx2) && (-Cy1 + h == Sy1) || (Cx1 == Sx1) && (-Cy1 + h == Sy2))
                        withinShip = true;
                    if (withinShip == true)
                    {
                        dmg = dmg + 25;
                    }
                    if ((Cx2 == Sx1) && (-Cy2 + h == Sy1) || (Cx2 == Sx2) && (-Cy2 + h == Sy2) || (Cx2 == Sx2) && (-Cy2 + h == Sy1) || (Cx2 == Sx1) && (-Cy2 + h == Sy2))
                        withinShip = true;
                    if (withinShip == true)
                    {
                        dmg = dmg + 25;
                    }
                    if ((Cx3 == Sx1) && (-Cy3 + h == Sy1) || (Cx3 == Sx2) && (-Cy3 + h == Sy2) || (Cx3 == Sx2) && (-Cy3 + h == Sy1) || (Cx3 == Sx1) && (-Cy3 + h == Sy2))
                        withinShip = true;
                    if (withinShip == true)
                    {
                        dmg = dmg + 25;
                    }
                }
            }
            Console.WriteLine("{0}%", dmg); Console.WriteLine(Cy3);
        }
    }
}
