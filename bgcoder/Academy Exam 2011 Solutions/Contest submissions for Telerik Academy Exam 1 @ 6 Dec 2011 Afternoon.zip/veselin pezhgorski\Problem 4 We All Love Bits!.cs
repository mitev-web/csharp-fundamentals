using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
           uint n = uint.Parse(Console.ReadLine());
            uint[] p = new uint[n];
            uint[] reversedP = new uint[n];
            uint[] bitInvertedP = new uint[n];
            uint[] pNew = new uint[n];
            uint mask = 1;
            uint swap;
            for (int i = 0; i < n; i++)
            {
                p[i] = uint.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                reversedP[i] = Reverse(p[i]);
            }
            for (int i = 0; i < n; i++)
            {
                mask = 1;
                swap = p[i];
                while (mask <= swap)
                {
                    if ((mask & swap) == 0)
                    {
                        bitInvertedP[i] = bitInvertedP[i] | mask;
                    }
                    else
                    {
                        bitInvertedP[i] = bitInvertedP[i] & (~mask);
                    }
                    mask <<= 1;
                }
            }
            for (int i = 0; i < n; i++)
            {
                pNew[i] = (p[i] ^ bitInvertedP[i]) & reversedP[i];
                Console.WriteLine(pNew[i]);
            }
        }
        public static uint Reverse(uint x)
        {
            uint y = 0;
            string c = Convert.ToString(x, 2);
            for (int i = 0; i < 32; ++i)
            {
                y <<= 1;
                y |= (x & 1);
                x >>= 1;
            }
            y >>= 32-c.Length;
            return y;
        }
    }
}

