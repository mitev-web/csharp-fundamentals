using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int treeSize=int.Parse(Console.ReadLine());
            for (int i = treeSize; i > 1; i--)
            {
                string dots = new string('.', i - 2);
                string stars = new string('*',(treeSize-i)*2+1);
                Console.WriteLine(dots+stars+dots);
            }
            string lastlineDots = new string('.',treeSize-2);
            Console.WriteLine(lastlineDots + "*" + lastlineDots);
        }
    }
}
