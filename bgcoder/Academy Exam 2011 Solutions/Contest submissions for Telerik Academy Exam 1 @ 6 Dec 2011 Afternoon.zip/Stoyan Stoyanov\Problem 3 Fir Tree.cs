using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace thirdTask
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());

            int temp = 1;
            for (int i = 0; i < n - 2; i++)
            {
                temp += 2;
            }

            char[,] helpArray = new char[n,temp];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < temp; j++)
                {
                    helpArray[i, j] = '.';
                }
            }

            helpArray[0, temp / 2] = '*';
            helpArray[n - 1, temp / 2] = '*';
            
            int magic = 0;
            
            for (int i = 1; i < n - 1; i++)
            {
                for (int j = 0; j < temp; j++)
                {
                    for (int ii = temp/2 - i; ii <= temp/2 + i; ii++)
                    {
                        helpArray[i, ii] = '*';
                    }
                    
                   
                    
                }
               
            }


            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < temp; j++)
                {
                    Console.Write("{0}", helpArray[i, j]);
                }
                Console.WriteLine();
            }

        }
    }
}
