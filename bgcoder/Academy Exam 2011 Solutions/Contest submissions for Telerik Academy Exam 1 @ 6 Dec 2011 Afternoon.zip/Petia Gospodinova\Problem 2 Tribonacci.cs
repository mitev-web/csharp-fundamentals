using System;
using System.Numerics;


namespace RealExam
{
    class Tribonacci
    {
        static void Main()
    {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            BigInteger n = BigInteger.Parse(Console.ReadLine());
            BigInteger tN = 0;
            while (n < 0)
            {
                break;
            }
           
                for (BigInteger i = 0; i < n - 3; i++)
                {
                    t2 += t1;
                    t3 += t2;
                    tN = t3;
                    t1 = t2 - t1;
                    t2 = t3 - t2;

                }
            
              Console.WriteLine(tN);
                
            
        }
    }
}
