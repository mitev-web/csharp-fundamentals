using System;

class Problem3
{
    static void Main()
    {
        byte n = byte.Parse(Console.ReadLine());

        int numberOfColumns = 1 + (n - 2) * 2, leftPart, count = numberOfColumns / 2, firTreeIter, rightPart;
        
        for (int row = 1; row < n; row++)
        {
            for (leftPart = 1; leftPart <= count; leftPart++)
            {
                Console.Write(".");
            }

            for (firTreeIter = 1; firTreeIter <= 1 + (row - 1) * 2; firTreeIter++)
            {
                Console.Write("*");
            }

            for (rightPart = 1; rightPart <= count; rightPart++)
            {
                Console.Write(".");
            }

            count--;
            Console.WriteLine();
        }

        for (leftPart = 1; leftPart <= numberOfColumns / 2; leftPart++)
        {
            Console.Write(".");
        }

        for (firTreeIter = 1; firTreeIter <= 1; firTreeIter += 2)
        {
            Console.Write("*");
        }

        for (rightPart = 1; rightPart <= numberOfColumns / 2; rightPart++)
        {
            Console.Write(".");
        }

    }
}

