using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam06
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal[] trib = new decimal[3];
            for (int i = 0; i < 3; i++)
            {
                trib[i] = decimal.Parse(Console.ReadLine());
            }

            int N = int.Parse(Console.ReadLine());
            Decimal result = 0;
            for (int i = 0; i < N - 3; i++)
            {
                result = trib[0] + trib[1] + trib[2];
                trib[0] = trib[1];
                trib[1] = trib[2];
                trib[2] = result;
            }

            Console.WriteLine(trib[2]);
        }
    }
}