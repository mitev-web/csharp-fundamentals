using System;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal first = decimal.Parse(Console.ReadLine());
            decimal second = decimal.Parse(Console.ReadLine());
            decimal third = decimal.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());

            decimal u = third;
            for (int i = 3; i < n; i++)
            {
                u = first + second + third;
                first = second;
                second = third;
                third = u;
            }
            Console.WriteLine(u);
        }
    }
}