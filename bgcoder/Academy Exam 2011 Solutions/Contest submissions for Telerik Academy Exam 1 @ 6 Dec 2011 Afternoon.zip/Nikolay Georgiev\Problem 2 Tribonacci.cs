using System;

    class Program
    {
        static void Main()
        {
            double a = double.Parse(Console.ReadLine());
            double b = double.Parse(Console.ReadLine());
            double c = double.Parse(Console.ReadLine());
            double d = 0;
            double n = double.Parse(Console.ReadLine());

            for (int i = 4; i <= n; i++)
            {
                d = a + b + c;
                a = b;
                b = c;
                c = d;
            }
            Console.WriteLine(d);
        }
    }
