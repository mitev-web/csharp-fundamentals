using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            byte[] mass = new byte[8];
            
            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = byte.Parse(Console.ReadLine());
            }

            int pillar = 1;
            int counterLeft = 0;
            int counterRight = 0;
            bool flag = false;
            int pil = 0;
            int num = 0;
        

            while(pillar < 8){
                for (int i = 0; i < mass.Length; i++)
                {
                    for (int j = 0; j < pillar; j++)
                    {
                        if ((mass[i] & (1 << j)) != 0)
                        {
                            counterLeft++;
                        }
                    }

                   for (int j = pillar + 1; j < 8; j++)
                   {
                        if ((mass[i] & (1 << j)) != 0)
                        {
                            counterRight++;
                        }
                   }
                }
                if (  counterLeft == counterRight)
                {
                    flag = true;
                    pil = pillar;
                    num = counterLeft;
                }
                counterLeft = 0;
                counterRight = 0;
                pillar++;
            }
            if (flag)
            {
                Console.WriteLine(pil);
                Console.WriteLine(num);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
