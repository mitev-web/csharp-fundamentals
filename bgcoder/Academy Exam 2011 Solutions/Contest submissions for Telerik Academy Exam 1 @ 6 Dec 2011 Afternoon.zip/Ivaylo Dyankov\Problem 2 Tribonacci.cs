using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal inputT1 = decimal.Parse(Console.ReadLine());
            decimal inputT2 = decimal.Parse(Console.ReadLine());
            decimal inputT3 = decimal.Parse(Console.ReadLine());

            UInt16 seqN = UInt16.Parse(Console.ReadLine());

            decimal resultT = 0;
            if  (seqN < 4)
            {
                switch (seqN)
                {
                    case 1:
                        resultT = inputT1;
                        break;
                    case 2:
                        resultT = inputT2;
                        break;
                    default:
                        resultT = inputT3;
                        break;
                }
            }
            else
            {   
                for (int i = 0; i < (seqN - 3); i++)
                {
                    resultT = inputT1 + inputT2 + inputT3;
                    inputT1 = inputT2;
                    inputT2 = inputT3;
                    inputT3 = resultT;
                }
            }

            Console.WriteLine(resultT);
        }
    }
}
