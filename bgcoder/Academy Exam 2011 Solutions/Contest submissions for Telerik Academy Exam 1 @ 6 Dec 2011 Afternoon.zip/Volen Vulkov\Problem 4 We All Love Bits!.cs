using System;

namespace _04.WeLoveBits
{
    class WeLoveBits
    {
        static int BitCounter(int number)
        {
            int counter = 0;
            for (; number != 0; number >>= 1)
            {
                counter++;
            }
            return counter;
        }

        static int ReverseBits(int number)
        {
            int temp = 0;
            int length = BitCounter(number);

            while (length > 0)
            {
                temp = (temp << 1) | (number & 1);
                number >>= 1;
                length--;
            }

            return temp;
        }

        
        static int GetBit(int number, int position) //want to get bit from a number in some position
        {
            int mask = 1 << position; //move the bit 1 to be under the bit in the number, other bits from the mask are 0
            if ((mask & number) == 0) //the mask is only 0 except the bit in the position u want
                return 0;
            else
                return 1;
        }

        static int SetBit(int number, int bit, int position)
        {
            int mask = 1 << position;
            if (bit == 1)
            {
                number |= mask;
            }

            else
            {
                number &= (~mask);
            }

            return number;
        }
        
        static int SetOppositeBits(int number)
        {
            int lenght = BitCounter(number);
            int temp;
            for (int i = 0; i < lenght; i++)
            {
                temp = GetBit(number, i);
                if (temp == 0)
                {
                    number = SetBit(number, 1, i);

                }
                if (temp == 1)
                {
                    number = SetBit(number, 0, i);

                }
            }
            return number;

        }

        static int MitkoPnew(int number)
        {
            return ((number ^ SetOppositeBits(number)) & ReverseBits(number));
        }
        
        static void Main(string[] args)
        {
            short n = short.Parse(Console.ReadLine());

            int[] array = new int[n];

            for (int i = 0; i < n; i++)
            {
                array[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(MitkoPnew(array[i]));
            }
        }
    }
}
