using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDammage
{
    class ShipDammage
    {
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2= int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());

            int damage = 0;

            int hitxc1 = cx1;
            int hityc1 = ((h - cy1) + h);

            int hitxc2 = cx2;
            int hityc2 = ((h - cy2) + h);

            int hitxc3 = cx3;
            int hityc3 = ((h - cy3) + h);

            
            if ((hitxc1 == sx1 || hitxc1 == sx2) && (hityc1 == sy1 || hityc1 == sy2))
            {
                damage = damage + 25; 
            }

            if ((hitxc1 == sx1 || hitxc1 == sx2) && (hityc1 > sy1 && hityc1 < sy2))
            {
                damage = damage + 50;
            }
            if ((hitxc1 == sx1 || hitxc1 == sx2) && (hityc1 < sy1 && hityc1 > sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc1 > sx1 && hitxc1 < sx2) && (hityc1 == sy1 || hityc1 == sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc1 < sx1 && hitxc1 > sx2) && (hityc1 == sy1 || hityc1 == sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc1 < sx1 && hitxc1 > sx2) && (hityc1 < sy1 && hityc1 > sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc1 < sx1 && hitxc1 > sx2) && (hityc1 > sy1 && hityc1 < sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc1 > sx1 && hitxc1 < sx2) && (hityc1 < sy1 && hityc1 > sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc1 > sx1 && hitxc1 < sx2) && (hityc1 > sy1 && hityc1 < sy2))
            {
                damage = damage + 100;
            }
             //2
            
            
            if ((hitxc2 == sx1 || hitxc2 == sx2) && (hityc2 == sy1 || hityc2 == sy2))
            {
                damage = damage + 25;
            }

            if ((hitxc2 == sx1 || hitxc2 == sx2) && (hityc2 > sy1 && hityc2 < sy2))
            {
                damage = damage + 50;
            }
            if ((hitxc2 == sx1 || hitxc2 == sx2) && (hityc2 < sy1 && hityc2 > sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc2 > sx1 && hitxc2 < sx2) && (hityc2 == sy1 || hityc2 == sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc2 < sx1 && hitxc2 > sx2) && (hityc2 == sy1 || hityc2 == sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc2 < sx1 && hitxc2 > sx2) && (hityc2 < sy1 && hityc2 > sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc2 < sx1 && hitxc2 > sx2) && (hityc2 > sy1 && hityc2 < sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc2 > sx1 && hitxc2 < sx2) && (hityc2 < sy1 && hityc2 > sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc2 > sx1 && hitxc2 < sx2) && (hityc2 > sy1 && hityc2 < sy2))
            {
                damage = damage + 100;
            }
            //3
            
            if ((hitxc3 == sx1 || hitxc3 == sx2) && (hityc3 == sy1 || hityc3 == sy2))
            {
                damage = damage + 25;
            }

            if ((hitxc3 == sx1 || hitxc3 == sx2) && (hityc3 > sy1 && hityc3 < sy2))
            {
                damage = damage + 50;
            }
            if ((hitxc3 == sx1 || hitxc3 == sx2) && (hityc3 < sy1 && hityc3 > sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc3 > sx1 && hitxc3 < sx2) && (hityc3 == sy1 || hityc3 == sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc3 < sx1 && hitxc3 > sx2) && (hityc3 == sy1 || hityc3 == sy2))
            {
                damage = damage + 50;
            }

            if ((hitxc3 < sx1 && hitxc3 > sx2) && (hityc3 < sy1 && hityc3 > sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc3 < sx1 && hitxc3 > sx2) && (hityc3 > sy1 && hityc3 < sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc3 > sx1 && hitxc3 < sx2) && (hityc3 < sy1 && hityc3 > sy2))
            {
                damage = damage + 100;
            }

            if ((hitxc3 > sx1 && hitxc3 < sx2) && (hityc3 > sy1 && hityc3 < sy2))
            {
                damage = damage + 100;
            }
             
            System.Console.WriteLine("{0}%",damage);

        }
    }
}