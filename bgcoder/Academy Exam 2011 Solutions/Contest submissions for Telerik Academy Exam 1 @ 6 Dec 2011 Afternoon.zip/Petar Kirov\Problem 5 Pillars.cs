using System;

class Problem5
{
    static byte[][] SplitByteArray(byte[] inputArr, byte pillarIndex)
    {
        byte[] arrLeft = (byte[])inputArr.Clone();
        byte[] arrRight = (byte[])inputArr.Clone();

        for (int row = 0; row < 8; row++)
        {
            for (int i = 7; i >= pillarIndex; i--)
            {
                if ((arrRight[row] >> i) % 2 == 1) { arrRight[row] = (byte)(arrRight[row] & ~(1u << i)); }
            }
        }

        for (int row = 0; row < 8; row++)
        {
            for (int i = pillarIndex; i >= 0; i--)
            {
                if ((arrLeft[row] >> i) % 2 == 1) { arrLeft[row] = (byte)(arrLeft[row] & ~(1u << i)); }
            }
        }


        byte[][] result = { arrLeft, arrRight };
        return result;
    }

    static void Main()
    {
        byte[] arr = new byte[8];
        byte leftOnesCounter = 0, rightOnesCounter = 0, columnIndex;
        for (int i = 0; i < 8; i++)
        {
            arr[i] = byte.Parse(Console.ReadLine());
        }

        for (columnIndex = 6; columnIndex > 0; columnIndex--)
        {
            byte[] arrLeft = SplitByteArray(arr, columnIndex)[0];
            byte[] arrRight = SplitByteArray(arr, columnIndex)[1];

            for (int row = 0; row < 8; row++)
            {
                for (int bitIndex = 7; bitIndex >= 0; bitIndex--)
                {
                    if ((arrLeft[row] >> bitIndex) % 2 == 1) leftOnesCounter++;
                }
            }

            for (int row = 0; row < 8; row++)
            {
                for (int bitIndex = 0; bitIndex < 7; bitIndex++)
                {
                    if ((arrRight[row] >> bitIndex) % 2 == 1) rightOnesCounter++;
                }
            }

            if (leftOnesCounter == rightOnesCounter) break;
            leftOnesCounter = 0;
            rightOnesCounter = 0;
        }


        if (leftOnesCounter == rightOnesCounter && (leftOnesCounter!=0&&rightOnesCounter!=0))
        {
            Console.WriteLine(columnIndex);
            Console.WriteLine(rightOnesCounter);
        }
        else 
        {
            Console.WriteLine("No");
        }


    }
}

