using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int a = 0;
            int b = 1;
            int c = 0;
            int d = 0;
            int mask = 1;
            int mask1 = 1;

            for (int i = 1; i <= n; i++)
            {
                a= Int32.Parse(Console.ReadLine());
                
                for (int k = 0; k < Math.Log(a,2); k++)
                {
                    mask = 1 << i;
                    if ((mask & a) != 0) 
                    {
                        b = 1 >> mask;
                    }
                }

                for (int k = 0; k < Math.Log(a, 2); k++)
                {
                    mask1 = 1 << i;
                    if ((mask & a) != 0)
                    {
                        c = ~a;
                    }
                }
                
                b = 1<<a;
                c = ~a;                             
                d = ((a ^ c) & b);
                Console.WriteLine(d);
			}
           
        }
    }
}
