using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            ushort n = ushort.Parse(input);
            ulong[] nums;
            nums = new ulong[n];
            int i = 0;

            const ulong one = 1;
            
            while (i != n)
            {
                input = Console.ReadLine();
                ulong a = ulong.Parse(input);
                int from = 0;
                //find the first 1
                for (int j = 62; j >= 0; j--)
                {
                    ulong mask = one << j;
                    ulong andM = a & mask;
                    if (andM >> j == 1)
                    {
                        from = j;
                        break;
                    }
                }
                ulong rev = 0;
                for (int k = 0, p = from; k <= (from + 1) / 2; k++, p--)
                {
                    
                    ulong smallMask = one << k;
                    ulong andM1 = a & smallMask;
                    ulong bigMask = one<< p;
                    ulong andM2 = a & bigMask;
                    ulong mask = (andM1 << (p-k)) | (andM2 >> (p-k));
                    rev = rev | mask;

                }
                         
                nums[i]=(a^(~a))&(rev);
                i++;
            }

            for (int j = 0; j < nums.Length; j++)
            {
                Console.WriteLine(nums[j]);
            }
            
        }
    }
}
