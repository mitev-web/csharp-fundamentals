using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace zadacha_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int t1, t2, t3, n;
            string inpt1 = Console.ReadLine();
            string inpt2 = Console.ReadLine();
            string inpt3 = Console.ReadLine();
            string inpN = Console.ReadLine();
            n = int.Parse(inpN);
            t1 = int.Parse(inpt1);
            t2 = int.Parse(inpt2);
            t3 = int.Parse(inpt3);
 
            for (int i = 0; i < (n-3); i++)
            {
                int t4 = t1;
                t1 = t2;
                t2 = t3;
                t3 = t4 + t2 + t1;
            }
            Console.WriteLine(t3);
        }
    }
}