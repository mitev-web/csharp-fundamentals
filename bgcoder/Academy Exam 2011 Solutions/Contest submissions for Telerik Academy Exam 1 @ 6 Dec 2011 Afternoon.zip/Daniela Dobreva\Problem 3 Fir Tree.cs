using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1._3.FinalExam
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            string lineI = "";
            string lineL = "";

            for (int i = n - 1; i >= 1; i--)
            {

                lineI = "";

                for (int j = 0; j < i - 1; j++)
                {
                    lineI += ".";
                }
                lineI += "*";
                //Console.WriteLine(lineI);
                for (int j = 0; j < n - i - 1; j++)
                {
                    lineI += "*";
                }
                //Console.WriteLine(lineI);
                for (int k = n - i - 1; k < n - i - 1; k++)
                    lineI += ".";
                //Console.WriteLine(lineI);
                for (int j = 0; j < n - i - 1; j++)
                {
                    lineI += "*";
                }
                //Console.WriteLine(lineI);
                for (int j = 0; j < i - 1; j++)
                {
                    lineI += ".";
                }

                Console.WriteLine(lineI + lineL);
            }

            for (int j = 0; j < n - 2; j++)
            {
                lineL += ".";
            }
            lineL += "*";
            for (int j = 0; j < n - 2; j++)
            {
                lineL += ".";
            }
            Console.WriteLine(lineL);
        }
    }
}