using System;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int sX1, sY1, sX2, sY2, h, cY1, cX1, cX2, cY2, cX3, cY3;
            int sX3, sY3, sX4, sY4;
            int damage=0;
            sX1 = int.Parse(Console.ReadLine());
            sY1 = int.Parse(Console.ReadLine());
            sX2 = int.Parse(Console.ReadLine());
            sY2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cX1 = int.Parse(Console.ReadLine());
            cY1 = int.Parse(Console.ReadLine());
            cX2 = int.Parse(Console.ReadLine());
            cY2 = int.Parse(Console.ReadLine());
            cX3 = int.Parse(Console.ReadLine());
            cY3 = int.Parse(Console.ReadLine());

            // Calculate hit points
            if (cY1 < h)
            {
                            cY1 = cY1 + (int)(Math.Sqrt((cY1 - h)*(cY1 - h)));
            }
            if (cY1>h)
            {
                            cY1 = cY1 - (int)(Math.Sqrt((cY1 - h)*(cY1 - h)));
            }
             if (cY2< h)
            {
                                        cY2 = cY2 + (int)(Math.Sqrt((cY2 - h)*(cY2 - h)));
            }
            if (cY2>h)
            {
                                cY2 = cY2 - (int)(Math.Sqrt((cY2 - h)*(cY2 - h)));
            }
                        if (cY3 < h)
            {
                                        cY3 = cY3 + (int)(Math.Sqrt((cY3 - h)*(cY3 - h)));
            }
            if (cY3>h)
            {
                                        cY3 = cY3 - (int)(Math.Sqrt((cY3 - h)*(cY3 - h)));
            }

            //Get other edges
            sX3 = sX1;
            sY3 = sY2;
            sX4 = sX2;
            sY4 = sY1;

            //Shot 1
            if ((cX1 == sX1) && (cY1 == sY1))
            {
                damage += 25;
            }
            else if ((cX1 == sX2) && (cY1 == sY2))
            {
                damage += 25;
            }
            else if ((cX1 == sX3) && (cY1 == sY3))
            {
                damage += 25;
            }
            else if ((cX1 == sX4) && (cY1 == sY4))
            {
                damage += 25;
            }
            else if ((cX1>=sX1) && (cX1<=sX2) && (cY1>=sY2) && (cY1<=sY1))
            {
                damage += 100;
            }
            
            //Shot 2
            if ((cX2 == sX1) && (cY2 == sY1))
            {
                damage += 25;
            }
            else if ((cX2 == sX2) && (cY2 == sY2))
            {
                damage += 25;
            }
            else if ((cX2 == sX3) && (cY2 == sY3))
            {
                damage += 25;
            }
            else if ((cX2 == sX4) && (cY2 == sY4))
            {
                damage += 25;
            }
            else if ((cX2 >= sX1) && (cX2 <= sX2) && (cY2 >= sY2) && (cY2 <= sY1))
            {
                damage += 100;
            }

            //Shot 3
            if ((cX3 == sX1) && (cY3 == sY1))
            {
                damage += 25;
            }
            else if ((cX3 == sX2) && (cY3 == sY2))
            {
                damage += 25;
            }
            else if ((cX3 == sX3) && (cY3 == sY3))
            {
                damage += 25;
            }
            else if ((cX3 == sX4) && (cY3 == sY4))
            {
                damage += 25;
            }
            else if ((cX3 >= sX1) && (cX3 <= sX2) && (cY3 >= sY2) && (cY3 <= sY1))
            {
                damage += 100;
            }

            Console.WriteLine(damage +"%");
        }
    }
}