using System;

class FirTree
{
    static void Main()
    {

        byte N;
        N =byte.Parse(Console.ReadLine());
       // N = 5;


        for (int i = 1; i < N; i++)
        {
            for (int column = 1; column < (2 * (N - 1)); column++)
            {
                if (column > (N - i - 1) && column < (N + i - 1))
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
        for (int i = 1; i < (2 * (N - 1)); i++)
        {
            if (i == (N-1))
            {
                Console.Write("*");
            }
            else
            {
                Console.Write(".");
            }
        }
    }
}

