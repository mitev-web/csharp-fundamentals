using System;
using System.Numerics;

class Program
{
    static void Main()
    {
        ushort N;
        BigInteger Tn, Tn1, Tn2,Tn3;
        Tn = BigInteger.Parse(Console.ReadLine());
        Tn1 = BigInteger.Parse(Console.ReadLine());
        Tn2 = BigInteger.Parse(Console.ReadLine());
        N = ushort.Parse(Console.ReadLine());
        Tn3 = 0;
        //N = 4;
        //Tn = 1;
        //Tn1 = 1;
        //Tn2 = 1;
        //Tn3 = 0;

        if (N == 1)
        {
            Tn3 = Tn;
        }
        else if (N == 2)
        {
            Tn3 = Tn2;
        }
        else if (N == 3)
        {
            Tn3 = Tn2;
        }
        else
        {

            for (int i = 3; i < N; i++)
            {
                Tn3 = Tn + Tn1 + Tn2;
                Tn = Tn1;
                Tn1 = Tn2;
                Tn2 = Tn3;
            }
           
        }
        Console.WriteLine(Tn3);
    }
}

