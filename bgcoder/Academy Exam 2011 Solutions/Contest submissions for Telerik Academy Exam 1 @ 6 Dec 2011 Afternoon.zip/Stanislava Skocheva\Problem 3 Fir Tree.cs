using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FireTree
{
    class Program
    {
        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());
            uint row = 0;
            uint col = 0;

            for (row = 1; row <= n; row++)
            {
                for (col = 1; col <= (2 * (n - 1) - 1); col++)
                {
                    if (row + col < n)
                    {
                        Console.Write(".");
                    }
                    else if(col - row > n - 2)
                    {
                        Console.Write(".");
                    }
                    else if ((row == n) && (col == n - 1))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                    
                    
                }
                Console.WriteLine();
            }
        }
    }
}