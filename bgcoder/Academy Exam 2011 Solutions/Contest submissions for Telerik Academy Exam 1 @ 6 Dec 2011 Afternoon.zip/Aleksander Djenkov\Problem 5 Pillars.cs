using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class Task5
    {
        static void Main(string[] args)
        {
            byte[,] m = new byte[8, 8];
            byte N;
            
            byte one1 = 0;
            byte one2 = 0;
            byte pillar = 7;
            byte match = 0;
            for (int i = 0; i < 8; i++)
            {
                N = byte.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    
                        if (N % 2 == 0) m[i, 7 - j] = 0;
                        else m[i, 7 - j] = 1;
                        N /= 2;
                    
                }
            }
            for (int p = 0; p <8; p++)
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < p; j++)
                    {
                        if (m[i, j] == 1) one1++;

                    }
                    for (int j = p + 1; j < 8; j++)
                    {
                        if (m[i, j] == 1) one2++;
                    }

                }
                if ((one1 == one2) && one1 > 0)
                {

                    Console.WriteLine(pillar);
                    Console.WriteLine(one1);
                    match = 1;
                    break;

                }
                one1 = 0;
                one2 = 0;
                pillar--;
            }
           

            if (match == 0) Console.WriteLine("No");
        }
    }
}
