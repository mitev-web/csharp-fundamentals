using System;


namespace Pillars
{
    class Pillars
    {
        static int GetBit(int number, int position) //want to get bit from a number in some position
            {
                int mask = 1 << position; //move the bit 1 to be under the bit in the number, other bits from the mask are 0
                if ((mask & number) == 0) //the mask is only 0 except the bit in the position u want
                    return 0;
                else
                    return 1;
            }          

        static int CountBitsOf1(int number)
        {
            int bitCounter;
            for (bitCounter = 0; number != 0; number >>= 1)
            {
                bitCounter += number & 1;
            }
            return bitCounter;
        }

        static int CountBitsInGridLine(int[] array, int gridIndex)
        {
            int sum = 0;
            for (int i = 0; i < 8; i++)
            {
                sum += GetBit(array[i], gridIndex);
            }
            return sum;
        }

        static int CountBitsInArray(int[] array)
        {
            int sum = 0;
            for (int i = 0; i < 8; i++)
            {
                sum += CountBitsOf1(array[i]);
            }

            return sum;
        }

        static int GetLeftArrayBits(int[] array, int index)
        {
            int[] newArray = new int[8];

            for (int i = 0; i < 8; i++)
            {
                newArray[i] = array[i] >> index+1;
            }

            int sum = 0;

            for (int i = 0; i < 8; i++)
            {
                sum += CountBitsOf1(newArray[i]);
            }

            return sum;
        }

                
        static void Main(string[] args)
        {
            int[] myArray = new int[8];
            for (int i = 0; i < 8; i++)
            {
                myArray[i] = int.Parse(Console.ReadLine());
            }

            int bitCounter = CountBitsInArray(myArray);
            int bitsInLeftArray;
            bool hasResult = false;
            int gridBits;
            double exeption;

            for (int i = 7; i >= 0; i--)
            {
                bitsInLeftArray = GetLeftArrayBits(myArray, i);
                gridBits = CountBitsInGridLine(myArray, i);
                exeption = ((bitCounter - gridBits) / 2.0);
                if (  bitsInLeftArray == Math.Ceiling(exeption) )
                {
                    if (bitCounter == 2 && gridBits == 1)
                    {
                        continue;
                    }
                    Console.WriteLine(i);
                    Console.WriteLine(bitsInLeftArray);
                    hasResult = true;
                    break;
                }
            }

            if (hasResult == false)
            {
                Console.WriteLine("No");
            }

            
        }
    }
}
