using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Problem_3_FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            string height = Console.ReadLine();
            int n = int.Parse(height);

            Console.Write("*".PadLeft(n-1, '.'));
            Console.WriteLine(".".PadRight(n - 2, '.'));
            
            int temp = 0;

            for (int i = 1, j = n - 3, k = 3; i <= n - 3; i++, j--, k++, k++)
            {
                Console.Write(".".PadRight(j, '.'));
                Console.Write("*".PadLeft(k, '*'));
                Console.WriteLine(".".PadRight(j, '.'));
                temp = k;
            }
            Console.WriteLine("*".PadLeft(temp + 2, '*'));

            Console.Write("*".PadLeft(n - 1, '.'));
            Console.WriteLine(".".PadRight(n - 2, '.'));
        }
    }
}