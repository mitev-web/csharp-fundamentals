using System;
using System.Numerics;

namespace Tribonacci
{
    class Problem2
    {
        static void Main()
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());
            ushort num4 = ushort.Parse(Console.ReadLine());

            BigInteger firstNum = num1;
            BigInteger secondNum = num2;
            BigInteger thirdNum = num3;

            BigInteger sum = 0;

            if (num4 > 0 && num4 <= 3)
            {
                Console.WriteLine(firstNum + secondNum + thirdNum);
            }

            else
            {
                for (int i = 0; i < num4 - 3; i++)
                {
                    sum = firstNum + secondNum + thirdNum;
                    firstNum = secondNum;
                    secondNum = thirdNum;
                    thirdNum = sum;
                }

                Console.WriteLine(sum);
            }
        }
    }
}