using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bits
{
    class Program
    {

        public static uint Invert(uint value)
        {
            
            value ^= (uint)uint.MaxValue;
            return value;
        }

        public static uint RotateInt(uint B)
        {
            

            uint rev = B;
            uint res = rev;
            int s = sizeof(uint)*8 - 1;

            for (rev >>= 1; rev != 0; rev >>= 1)
            {
                res <<= 1;
                res |= rev & 1;
                s--;
            }

            return res;
        }

        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());

           uint[] helpArray = new uint [n];

            for (int i = 0; i < helpArray.Length; i++)
			{
                helpArray[i] = uint.Parse(Console.ReadLine());
                uint invert = Invert(helpArray[i]);
                uint reverse = RotateInt(helpArray[i]);
                helpArray[i] = (helpArray[i] ^ invert) & reverse;
			}


            for (int i = 0; i < helpArray.Length; i++)
            {
                Console.WriteLine("{0}",helpArray[i]);
            }
        }
    }
}
