using System;

namespace FallDown
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] column = new byte[8];
            byte n;

            for (int i = 0; i < 8; i++)
            {
                n = byte.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    if ( (n & (1 << j)) > 0)
                    {
                        column[j]++;
                    }
                }
            }

            int leftFilled,rightFilled;
            for (int i = 7; i >= 0; i--)
            {
                leftFilled=0;
                rightFilled=0;

                for (int j = 7; j > i; j--)
                {
                    leftFilled += column[j];
                }

                for (int j = i-1; j >= 0; j--)
                {
                    rightFilled += column[j];
                }

                if (leftFilled == rightFilled)
                {
                    Console.WriteLine(i+"\n"+rightFilled);
                    return;
                }
            }

            Console.WriteLine("No");
        }
    }
}
