using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars2
{
    class Program
    {
        static void Main(string[] args)
        {
            int colon0 = 0;
            int colon1 = 0;
            int colon2 = 0;
            int colon3 = 0;
            int colon4 = 0;
            int colon5 = 0;
            int colon6 = 0;
            int colon7 = 0;
            int counter = -1;



            int number0 = int.Parse(Console.ReadLine());
            int number1 = int.Parse(Console.ReadLine());
            int number2 = int.Parse(Console.ReadLine());
            int number3 = int.Parse(Console.ReadLine());
            int number4 = int.Parse(Console.ReadLine());
            int number5 = int.Parse(Console.ReadLine());
            int number6 = int.Parse(Console.ReadLine());
            int number7 = int.Parse(Console.ReadLine());



            int k = number0;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number1;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number2;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number3;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number4;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number5;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number6;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            counter = 0;
            k = number7;
            while (k != 0)
            {
                int bit = k & 1;

                if (bit == 1)
                {
                    if (counter == 0) colon0++;
                    if (counter == 1) colon1++;
                    if (counter == 2) colon2++;
                    if (counter == 3) colon3++;
                    if (counter == 4) colon4++;
                    if (counter == 5) colon5++;
                    if (counter == 6) colon6++;
                    if (counter == 7) colon7++;
                }
                counter++;
                k = k >> 1;
            }
            if (colon0 == (colon2 + colon3 + colon4 + colon5 + colon6 + colon7))
            {
                System.Console.WriteLine(1);
                System.Console.WriteLine(6);
            }
            else
                if (colon0 + colon1 == (colon3 + colon4 + colon5 + colon6 + colon7))
                {
                    System.Console.WriteLine(2);
                    System.Console.WriteLine(5);
                }
                else
                    if (colon0 + colon1 + colon2 == (colon4 + colon5 + colon6 + colon7))
                    {
                        System.Console.WriteLine(3);
                        System.Console.WriteLine(4);
                    }
                    else
                        if (colon0 + colon1 + colon2 + colon3 == (colon5 + colon6 + colon7))
                        {
                            System.Console.WriteLine(4);
                            System.Console.WriteLine(3);
                        }
                        else
                            if (colon0 + colon1 + colon2 + colon3 + colon4 == (colon6 + colon7))
                            {
                                System.Console.WriteLine(5);
                                System.Console.WriteLine(2);
                            }
                            else
                                if (colon0 + colon2 + colon3 + colon4 + colon5 == (colon7))
                                {
                                    System.Console.WriteLine(6);
                                    System.Console.WriteLine(1);
                                }
                                else
                                {
                                    System.Console.WriteLine("No");
                                }

        }
    }
}