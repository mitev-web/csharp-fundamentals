using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zadacha_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string inpN = Console.ReadLine();
            int n = int.Parse(inpN);
            uint[] reversed = new uint[n];
            uint[] inverted = new uint[n];
            uint[] inputs = new uint[n];
            uint[] bits = new uint[8];
            uint[] p = new uint[n];
            for (int i = 0; i < n; i++)
            {
                string inpArray = Console.ReadLine();
                inputs[i] = uint.Parse(inpArray);
                reversed[i] = uint.Parse(inpArray);
                inverted[i] = uint.Parse(inpArray);
            }

            for (int j = 0; j < n; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    bool zeroOrOne = (reversed[j] & (ulong)(1 << i)) != 0;
                    if (zeroOrOne == false) // ako "i" bitat na chisloto obedinen sas 1 ne e 0 znachi e 1
                    {
                        bits[i] = 0;
                    }
                    else
                    {
                        bits[i] = 1;
                    }
                }
                for (int k = 0; k < 3; k++)
                {
                    bool compare = bits[k] == bits[(bits.Length - 1) - k];
                    if (compare == false) // ako sa razlicni razmeni gi ako ne ne pravi nishto
                    {
                        uint chanheFirst = (uint)(1 << k);
                        uint changeLast = (uint)1 << ((bits.Length - 1) - k);
                        reversed[j] = (reversed[j] ^ chanheFirst) ^ changeLast;
                    }
                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    inverted[i] = inverted[i] ^ (uint)(1 << j);
                }
            }
            for (int loop = 0; loop < n; loop++)
            {
                p[loop] = (inputs[loop] ^ inverted[loop]) & reversed[loop];
                Console.WriteLine(p[loop]);
            }
        }
    }
}
