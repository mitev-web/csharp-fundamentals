using System;

class Program
{
    static void Main(string[] args)
    {
        byte n0, n1, n2, n3, n4, n5, n6, n7, pillar = 1;
        int[] leftSide = new int[8];
        int[] rightSide = new int[8];
        int[,] numbers = new int[8, 8];
        int[] result = new int[8];
        n0 = byte.Parse(Console.ReadLine());
        n1 = byte.Parse(Console.ReadLine());
        n2 = byte.Parse(Console.ReadLine());
        n3 = byte.Parse(Console.ReadLine());
        n4 = byte.Parse(Console.ReadLine());
        n5 = byte.Parse(Console.ReadLine());
        n6 = byte.Parse(Console.ReadLine());
        n7 = byte.Parse(Console.ReadLine());

        for (int i = 0; i < 8; i++)
        {
            switch (i)
            {
                case 0:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n0, j);
                    }
                    break;
                case 1:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n1, j);
                    }
                    break;
                case 2:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n2, j);
                    }
                    break;
                case 3:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n3, j);
                    }
                    break;
                case 4:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n4, j);
                    }
                    break;
                case 5:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n5, j);
                    }
                    break;
                case 6:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n6, j);
                    }
                    break;
                default:
                    for (int j = 0; j < 8; j++)
                    {
                        numbers[i, j] = (byte)CheckBitValueAtPosition(n7, j);
                    }
                    break;
            }
        }
        for (int k = 0; k <= 7; k++)
        {
            for (int m = 0; m <= 7; m++)
            {
                if (numbers[m, k] == 1)
                {
                    result[k] += numbers[m, k];
                }
            }
        }

        for (byte u = 1; u < 7; u++)
        {
            for (byte y = 0; y < result.Length; y++)
            {
                if (y < pillar)
                {
                    rightSide[u] += result[y];
                }
                else if (y > pillar)
                {
                    leftSide[u] += result[y];
                }
            }

            pillar++;

        }
        pillar = 1;
        for (int i = 1; i < (rightSide.Length) - 1; i++)
        {
            if (leftSide[i] == rightSide[i])
            {
                pillar = (byte)i;
            }
        }
        if (pillar != 1)
        {
            Console.WriteLine(pillar);
            Console.WriteLine(leftSide[pillar]);
        }
        else
        {
            Console.WriteLine("No");
        }
    }
    public static int CheckBitValueAtPosition(int numberToCheck, int bitPosition)
    {
        int mask = 1 << bitPosition;
        int numberToChekcAndMask = numberToCheck & mask;
        int bit = numberToChekcAndMask >> bitPosition;
        return bit;
    }

}
