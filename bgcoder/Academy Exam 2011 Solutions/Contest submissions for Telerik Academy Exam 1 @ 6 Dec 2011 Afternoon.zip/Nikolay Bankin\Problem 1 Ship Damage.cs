using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.ShipDamage
{
    class ShipDmagae
    {
        static void Main(string[] args)
        {
            int catapultNumber = 3;
            int cordinatesNumber = 2;

            int shipTopLeftX;
            int shipTopLeftY;
            int shipBottomRightX;
            int shipBottomRightY;
            int horizont;
            int[,] catapults = new int[catapultNumber,cordinatesNumber];
            int damageDone = 0;

            shipTopLeftX = int.Parse(Console.ReadLine());
            shipTopLeftY = int.Parse(Console.ReadLine());
            shipBottomRightX = int.Parse(Console.ReadLine());
            shipBottomRightY = int.Parse(Console.ReadLine());
            horizont = int.Parse(Console.ReadLine());

            if (shipTopLeftX > shipBottomRightX)
            {
                int changeVar = shipTopLeftX;
                shipTopLeftX = shipBottomRightX;
                shipBottomRightX = changeVar;
            }
            if (shipBottomRightY > shipTopLeftY)
            {
                int changeVar = shipTopLeftY;
                shipTopLeftY = shipBottomRightY;
                shipBottomRightY = changeVar;
            }

            for (int i = 0; i < catapultNumber; i++)
			{
			    for (int k = 0; k < cordinatesNumber; k++)
			    {
			        catapults[i,k] = int.Parse(Console.ReadLine());
			    }
			}

            for (int i = 0; i < catapultNumber; i++)
            {
                int currentCatapultX = catapults[i, 0];
                int currentCatapultY = catapults[i, 1];
                int currentStrikeX = currentCatapultX;
                int catapultDistanceToHorizont = Math.Abs(currentCatapultY-horizont);
                int currentStrikeY;

                if (currentCatapultY > horizont)
                {
                    currentStrikeY = horizont - catapultDistanceToHorizont;
                }
                else
                {
                    currentStrikeY = horizont + catapultDistanceToHorizont;
                }
                
                //Console.WriteLine("{0} : {1}",currentStrikeX,currentStrikeY);
                if ((currentStrikeX == shipBottomRightX) || (currentStrikeX == shipTopLeftX))
                {
                    if (currentStrikeY == shipBottomRightY)
                    {
                        damageDone += 25;
                    }
                    else if (currentStrikeY == shipTopLeftY)
                    {
                        damageDone += 25;
                    }
                    else if ((currentStrikeY > shipBottomRightX) && (currentStrikeY < shipTopLeftY))
                    {
                        damageDone += 50;
                    }
                }
                else if ((currentStrikeX < shipBottomRightX) && (currentStrikeX > shipTopLeftX))
                {
                    if (currentStrikeY == shipBottomRightY)
                    {
                        damageDone += 50;
                    }
                    else if (currentStrikeY == shipTopLeftY)
                    {
                        damageDone += 50;
                    }
                    else if ((currentStrikeY > shipBottomRightY) && (currentStrikeY < shipTopLeftY))
                    {
                        damageDone += 100;
                    }
                }
            }
            Console.WriteLine("{0}%", damageDone);
        }
    }
}
