using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace test2
{
    class Program
    {
        static void Main(string[] args)
        {

            
            decimal p1 = decimal.Parse(Console.ReadLine());
            decimal p2 = decimal.Parse(Console.ReadLine());
            decimal p3 = decimal.Parse(Console.ReadLine());
            BigInteger t1 = (BigInteger)p1;
            BigInteger t2 = (BigInteger)p2;
            BigInteger t3 = (BigInteger)p3;

            int n = int.Parse(Console.ReadLine());
            BigInteger tn = 0;
            if (n == 1)
            {
                Console.WriteLine(t1);
            }
            if (n == 2)
            {
                Console.WriteLine(t2);
                if (n == 3)
                {
                    Console.WriteLine(t3);
                }
            }
 
            for (int number = 1; number < n-2; number++)
            {
                tn = t1 + t2 + t3;
                t1 = t2;
                t2 = t3;
                t3 = tn;
            }
            Console.WriteLine(tn);
       
        }
    }
}
