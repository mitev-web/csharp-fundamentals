using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
   
namespace Solution1
{
   
    class Solution1
    {
        static void Main(string[] args)
        {
            int sx1, sx2, sy1, sy2, h, cx1, cx2, cx3, cy1, cy2, cy3;
            int nx1, nx2, nx3, ny1, ny2, ny3;
            int sum = 0;
            sx1 = int.Parse(Console.ReadLine());
            sy1 = int.Parse(Console.ReadLine());
            sx2 = int.Parse(Console.ReadLine());
            sy2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cx1 = int.Parse(Console.ReadLine());
            cy1 = int.Parse(Console.ReadLine());
            cx2 = int.Parse(Console.ReadLine());
            cy2 = int.Parse(Console.ReadLine());
            cx3 = int.Parse(Console.ReadLine());
            cy3 = int.Parse(Console.ReadLine());
            nx1 = cx1;
            nx2 = cx2;
            nx3 = cx3;
            if ((sy1 < 0 || sy2 < 0) && (cy1 <= 0 && h <= 0) || (cy1 >= 0 && h >= 0)) ny1 = h + Math.Abs(cy1 - h);
            else if ((sy1 < 0 || sy2 < 0) && (cy1 <= 0 && h <= 0) || (cy1 >= 0 && h >= 0)) ny1 = h +(-1)* Math.Abs(cy1 - h);
            else if ( sy1 < 0 || sy2 < 0) ny1 = h + (-1)*(Math.Abs(h) + Math.Abs(cy1));
            else  ny1 = h + Math.Abs(h) + Math.Abs(cy1);
   
            if ((cy2 <= 0 && h <= 0) || (cy2 >= 0 && h >= 0)) ny2 = h + Math.Abs(cy2 - h);
            else if ((sy1 < 0 || sy2 < 0) && (cy2 <= 0 && h <= 0) || (cy2 >= 0 && h >= 0)) ny2 = h + (-1) * Math.Abs(cy2 - h);
            else if (sy1 < 0 || sy2 < 0) ny2 = h + (-1) * (Math.Abs(h) + Math.Abs(cy2));
            else ny2 = h + Math.Abs(h) + Math.Abs(cy2);
   
            if ((cy3 <= 0 && h <= 0) || (cy3 >= 0 && h >= 0)) ny3 = h + Math.Abs(cy3 - h);
            else if ((sy1 < 0 || sy2 < 0) && (cy3 <= 0 && h <= 0) || (cy3 >= 0 && h >= 0)) ny3 = h + (-1) * Math.Abs(cy3 - h);
            else if (sy1 < 0 || sy2 < 0) ny3 = h + (-1) * (Math.Abs(h) + Math.Abs(cy3));
            else ny3 = h + Math.Abs(h) + Math.Abs(cy3);
   
                 if (sx1 < sx2 && nx1 > sx1 && nx1 < sx2 && sy1 < sy2 && ny1 > sy1 && ny1 < sy2) sum += 100;
            else if (sx1 < sx2 && nx1 > sx1 && nx1 < sx2 && sy1 > sy2 && ny1 < sy1 && ny1 > sy2) sum += 100;
            else if (sx1 > sx2 && nx1 < sx1 && nx1 > sx2 && sy1 < sy2 && ny1 > sy1 && ny1 < sy2) sum += 100;
            else if (sx1 > sx2 && nx1 < sx1 && nx1 > sx2 && sy1 > sy2 && ny1 < sy1 && ny1 > sy2) sum += 100;
               
            else if ((sx1 == nx1 && sy1 == ny1) || (sx2 == nx1 && sy2 == ny1) || (sx1 == nx1 && sy2 == ny1) || (sx2 == nx1 && sy1 == ny1)) sum += 25;
            else if ((sx1 == nx1 && ((sy1 < ny1 && sy2 > ny1) || (sy1 > ny1 && sy2 < ny1)))
                || (sx2 == nx1 && ((sy1 < ny1 && sy2 > ny1) || (sy1 > ny1 && sy2 < ny1)))
                || (sy1 == ny1 && ((sx1 < nx1 && sx2 > nx1) || (sx1 > nx1 && sx2 < nx1)))
                || (sy2 == ny1 && ((sx1 < nx1 && sx2 > nx1) || (sx1 > nx1 && sx2 < nx1)))) sum += 50;
   
            if (sx1 < sx2 && nx1 > sx1 && nx2 < sx2 && sy1 < sy2 && ny2 > sy1 && ny2 < sy2) sum += 100;
            else if (sx1 < sx2 && nx2 > sx1 && nx2 < sx2 && sy1 > sy2 && ny2 < sy1 && ny2 > sy2) sum += 100;
            else if (sx1 > sx2 && nx2 < sx1 && nx2 > sx2 && sy1 < sy2 && ny2 > sy1 && ny2 < sy2) sum += 100;
            else if (sx1 > sx2 && nx2 < sx1 && nx2 > sx2 && sy1 > sy2 && ny2 < sy1 && ny2 > sy2) sum += 100;
            else if ((sx1 == nx2 && sy1 == ny2) || (sx2 == nx2 && sy2 == ny2) || (sx1 == nx2 && sy2 == ny2) || (sx2 == nx2 && sy1 == ny2)) sum += 25;
            else if ((sx1 == nx2 && ((sy1 < ny2 && sy2 > ny2) || (sy1 > ny2 && sy2 < ny2)))
                    || (sx2 == nx2 && ((sy1 < ny2 && sy2 > ny2) || (sy1 > ny2 && sy2 < ny2)))
                    || (sy1 == ny2 && ((sx1 < nx2 && sx2 > nx2) || (sx1 > nx2 && sx2 < nx2)))
                    || (sy2 == ny2 && ((sx1 < nx2 && sx2 > nx2) || (sx1 > nx2 && sx2 < nx2)))) sum += 50;
   
            if (sx1 < sx2 && nx3 > sx1 && nx3 < sx2 && sy1 < sy2 && ny3 > sy1 && ny3 < sy2) sum += 100;
            else if (sx1 < sx2 && nx3 > sx1 && nx3 < sx2 && sy1 > sy2 && ny3 < sy1 && ny3 > sy2) sum += 100;
            else if (sx1 > sx2 && nx3 < sx1 && nx3 > sx2 && sy1 < sy2 && ny3 > sy1 && ny3 < sy2) sum += 100;
            else if (sx1 > sx2 && nx3 < sx1 && nx3 > sx2 && sy1 > sy2 && ny3 < sy1 && ny3 > sy2) sum += 100;
            else if ((sx1 == nx3 && sy1 == ny3) || (sx2 == nx3 && sy2 == ny3) || (sx1 == nx3 && sy2 == ny3) || (sx2 == nx3 && sy1 == ny3)) sum += 25;
            else if ((sx1 == nx3 && ((sy1 < ny3 && sy2 > ny3) || (sy1 > ny3 && sy2 < ny3)))
                    || (sx2 == nx3 && ((sy1 < ny3 && sy2 > ny3) || (sy1 > ny3 && sy2 < ny3)))
                    || (sy1 == ny3 && ((sx1 < nx3 && sx2 > nx3) || (sx1 > nx3 && sx2 < nx3)))
                    || (sy2 == ny3 && ((sx1 < nx3 && sx2 > nx3) || (sx1 > nx3 && sx2 < nx3)))) sum += 50;
            Console.WriteLine(sum + "%");
        }
    }
}