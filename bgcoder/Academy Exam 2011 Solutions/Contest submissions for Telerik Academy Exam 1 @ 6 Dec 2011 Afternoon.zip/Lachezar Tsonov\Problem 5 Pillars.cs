using System;

namespace _5.Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            const byte arraySize = 8;
            byte[] numbers = GetNumbers(arraySize);

            //check for last column
            bool isLastColumnWhatWeSeek = true;
            for (int currentNumber = 0; currentNumber < arraySize; currentNumber++)
            {
                byte saveNumber = (byte) (numbers[currentNumber] << 1);
                if (saveNumber != 0)
                {
                    isLastColumnWhatWeSeek = false;
                    break;
                }
            }
            if (isLastColumnWhatWeSeek == true)
            {
                Console.WriteLine(7);
                Console.WriteLine(0);
                return;
            }

            for (int startingColumn = 6; startingColumn > 0; startingColumn--)
            {
                int leftGridCount = 0;
                int rightGridCount = 0;
                for (int leftGridChecker = 7; leftGridChecker > startingColumn; leftGridChecker--)
                {
                    for (int currentNumber = 0; currentNumber < arraySize; currentNumber++)
                    {
                        if (GetBitAtPosition(numbers[currentNumber], leftGridChecker) == 1)
                        {
                            leftGridCount++;
                        }
                    }
                }
                for (int rightGridChecker = 0; rightGridChecker < startingColumn; rightGridChecker++)
                {
                    for (int currentNumber = 0; currentNumber < arraySize; currentNumber++)
                    {
                        if (GetBitAtPosition(numbers[currentNumber], rightGridChecker) == 1)
                        {
                            rightGridCount++;
                        }
                    }
                }
                if (leftGridCount == rightGridCount)
                {
                    Console.WriteLine(startingColumn);
                    Console.WriteLine(leftGridCount);
                    return;
                }
            }

            //check for first column
            bool isFirstColumnWhatWeSeek = true;
            for (int currentNumber = 0; currentNumber < arraySize; currentNumber++)
            {
                byte saveNumber = (byte)(numbers[currentNumber] >> 1);
                if (saveNumber != 0)
                {
                    isFirstColumnWhatWeSeek = false;
                    break;
                }
            }
            if (isFirstColumnWhatWeSeek == true)
            {
                Console.WriteLine(0);
                Console.WriteLine(0);
                return;
            }

            //No column found
            Console.WriteLine("No");
        }
  
        private static byte[] GetNumbers(byte arraySize)
        {
            byte[] numbers = new byte[arraySize];
            for (int currentNumber = 0; currentNumber < arraySize; currentNumber++)
            {
                numbers[currentNumber] = Convert.ToByte(Console.ReadLine());
            }
            return numbers;
        }

        private static byte GetBitAtPosition(byte number, int position)
        {
            if (((number >> position) & 1) == 0)
            {
                return 0;
            }
            else return 1;
        }
    }
}
