using System;


namespace test6
{
    class Program
    {
        static void Main(string[] args)
        {
            int mask = 1;
            int zeros = 0;
            int ones = 0;
            int twos = 0;
            int threes = 0;
            int fours = 0;
            int fives = 0;
            int sixes = 0;
            int sevens = 0;        
            for (int g = 0; g <= 7; g++)
            {
                long givenNumber = long.Parse(Console.ReadLine());// Next number
                for (int i = 0; i <= Math.Log(givenNumber, 2); i++)
                {
                    mask = 1 << i;
                    bool checker = (mask & givenNumber) != 0;
                    if (checker)
                    {
                        switch (i)
                        {
                            case 0: zeros++; break;
                            case 1: ones++; break;
                            case 2: twos++; break;
                            case 3: threes++; break;
                            case 4: fours++; break;
                            case 5: fives++; break;
                            case 6: sixes++; break;
                            case 7: sevens++; break;
                            default: break;
                        }
                    }
                }
            }
            if (zeros + ones == twos + threes + fours + fives +sixes +sevens )
            {
                Console.WriteLine(6);
            }
            if (zeros + ones + twos == threes + fours + fives +sixes +sevens)
            {
                Console.WriteLine(5);
            }
            if (zeros + ones + twos + threes == fours + fives + sixes + sevens)
            {
                Console.WriteLine(4);
            }
            if (zeros + ones + twos + threes + fours == fives + sixes + sevens)
            {
                Console.WriteLine(3);
            }
            if (zeros + ones + twos + threes + fours + fives == sixes + sevens)
            {
                Console.WriteLine(2);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
