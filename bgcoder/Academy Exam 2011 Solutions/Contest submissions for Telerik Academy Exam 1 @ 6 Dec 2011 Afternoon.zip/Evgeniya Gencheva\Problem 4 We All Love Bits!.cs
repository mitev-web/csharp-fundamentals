using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int tmp = 0;
            int[] arr = new int[n];
            List<string> strArr = new List<string>(); ;
            while(tmp != n)
            {
                arr[tmp] = Convert.ToInt32(Console.ReadLine());
                tmp++;
            }
            foreach (var item in arr)
            {
                string strTmp = Convert.ToString(item, 2);
                strArr.Add(strTmp);

            }
            foreach (var item in strArr)
            {
                string tildaItem = "";
                string dotsItem = ReverseString(item);
                foreach (var ch in item)
                {
                    if (ch == '1')
                    {
                        tildaItem += '0';
                    }
                    else
                    {
                        tildaItem += '1';
                    }
                }
                int number = Convert.ToInt32(item, 2);
                int numberTilda = Convert.ToInt32(tildaItem, 2);
                int numberDots = Convert.ToInt32(dotsItem, 2);
                int result = (number ^ numberTilda) & numberDots;
                Console.WriteLine(result);
            }
        }

        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
    }
}
