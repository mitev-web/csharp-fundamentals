using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            BigInteger n = BigInteger.Parse(Console.ReadLine());

            BigInteger t = t1 + t2 + t3;

           
            for (BigInteger i = 1; i <= n - 3 ; i++)
            {
                t1++;
                t1 = t2;
                t2++;
                t2 = t3;
                t3++;
                t3 = t;     

                Console.WriteLine(t);
            }
            
        }
    }
}
