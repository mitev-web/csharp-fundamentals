using System;
using System.Collections.Generic;
using System.Numerics;

namespace TribonacciSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            short n = 0;
            BigInteger firstNumber = 0;
            BigInteger secondNumber = 0;
            BigInteger thirdnumber = 0;
            BigInteger resultHolder = 0;

            firstNumber = long.Parse(Console.ReadLine());
            secondNumber = long.Parse(Console.ReadLine());
            thirdnumber = long.Parse(Console.ReadLine());
            n = short.Parse(Console.ReadLine());


            switch (n)
            { 
                case 1:
                    Console.WriteLine(firstNumber);
                    break;
                case 2:
                    Console.WriteLine(secondNumber);
                    break;
                case 3:
                    Console.WriteLine(thirdnumber);
                    break;
                default:
                    for (int i = 3; i < n; i++)
                    {
                        resultHolder = firstNumber + secondNumber + thirdnumber;
                        firstNumber = secondNumber;
                        secondNumber = thirdnumber;
                        thirdnumber = resultHolder;
                    }
                    Console.WriteLine(resultHolder);
                    break;
            }

            
        }
    }
}
