using System;

namespace _4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] arr1 = new int[800];
            int[] arr2 = new int[800];
            int[] arr3 = new int[800];
            int[] arr4 = new int[800];
            for (int i = 0; i < n; i++)
            {
                arr1[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                if (arr1[i] == 0)
                {
                    arr2[i] = 0;
                    arr3[i] = 1;
                }
                else
                {
                    int nFloor = (int)Math.Floor(Math.Log(arr1[i], 2)) + 1;
                    for (int k = 0; k < nFloor; k++)
                    {
                        int mask = 1 << nFloor - 1 - k;
                        arr2[i] += ((arr1[i] & mask) >> nFloor - 1 - k) * ((int)Math.Pow(2, k));
                    }
                    for (int k = 0; k < nFloor; k++)
                    {
                        int mask = 1 << nFloor - 1 - k;
                        arr3[i] += (((arr1[i] & mask) >> nFloor - 1 - k) ^ 1) * ((int)Math.Pow(2, nFloor - 1 - k));
                    }

                }
                arr4[i] = (arr1[i] ^ arr3[i]) & arr2[i];
            }
            for (int t = 0; t < n; t++)
            {
                Console.WriteLine(arr4[t]);
            }
        }
    }
}

