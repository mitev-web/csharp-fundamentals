using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            short N = short.Parse(Console.ReadLine());

            for (int j = 0; j < N; j++)
            {
                for (int i = 0; i < 2 * N - 3; i++)
                {
                    if (j != N - 1)
                    {
                        if (i - N + 2 >= -j && i - N + 2 <= j)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    else
                    {
                        if (i - N + 2 == 0)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }

                Console.WriteLine();
            }
        }
    }
}
