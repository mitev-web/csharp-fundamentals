using System;

namespace _1.ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sXFirst, sXSecond, sYFirst, sYSecond;
            int horizon;
            int firstCX, firstCY, secondCX, secondCY, thirdCX, thirdCY;

            sXFirst = Convert.ToInt32(Console.ReadLine());
            sYFirst = Convert.ToInt32(Console.ReadLine());
            sXSecond = Convert.ToInt32(Console.ReadLine());
            sYSecond = Convert.ToInt32(Console.ReadLine());
            horizon = Convert.ToInt32(Console.ReadLine());
            firstCX = Convert.ToInt32(Console.ReadLine());
            firstCY = Convert.ToInt32(Console.ReadLine());
            secondCX = Convert.ToInt32(Console.ReadLine());
            secondCY = Convert.ToInt32(Console.ReadLine());
            thirdCX = Convert.ToInt32(Console.ReadLine());
            thirdCY = Convert.ToInt32(Console.ReadLine());

            //calculate dimensions
            int rectangleXMax, rectangleXMin, rectangleYMax, rectangleYmin;
            if (sXFirst > sXSecond)
            {
                rectangleXMax = sXFirst;
                rectangleXMin = sXSecond;
            }
            else
            {
                rectangleXMax = sXSecond;
                rectangleXMin = sXFirst;
            }

            if (sYFirst > sYSecond)
            {
                rectangleYMax = sYFirst;
                rectangleYmin = sYSecond;
            }
            else
            {
                rectangleYMax = sYSecond;
                rectangleYmin = sYFirst;
            }
            //find symmetric point of each
            if (firstCY < horizon)
            {
                firstCY = horizon + Math.Abs(horizon - firstCY);
            }
            else
            {
                firstCY = horizon - Math.Abs(horizon - firstCY);
            }

            if (secondCY < horizon)
            {
                secondCY = horizon + Math.Abs(horizon - secondCY);
            }
            else
            {
                secondCY = horizon - Math.Abs(horizon - secondCY);
            }

            if (thirdCY < horizon)
            {
                thirdCY = horizon + Math.Abs(horizon - thirdCY);
            }
            else
            {
                thirdCY = horizon - Math.Abs(horizon - thirdCY);
            }
            //check damage
            int damage = 0;

            //First point
            if (firstCX > rectangleXMin &&
                firstCX < rectangleXMax &&
                firstCY > rectangleYmin &&
                firstCY < rectangleYMax) //point is within rectangle
            {
                damage += 100;
            }
            else if ( ( (firstCX == rectangleXMin || firstCX == rectangleXMax) && (firstCY > rectangleYmin && firstCY < rectangleYMax) ) ^
                      ( (firstCY == rectangleYmin || firstCY == rectangleYMax) && (firstCX > rectangleXMin && firstCX < rectangleXMax) ) ) // point is on one of the sides
            {
                damage += 50;
            }
            else if ((firstCX == rectangleXMin && firstCY == rectangleYmin) ||
                      (firstCX == rectangleXMin && firstCY == rectangleYMax) ||
                      (firstCX == rectangleXMax && firstCY == rectangleYmin) ||
                      (firstCX == rectangleXMax && firstCY == rectangleYMax)) //Point is on the corners
            {
                damage += 25;
            }
            else
            {
                //Point is outside rectangle, skip adding damage
            }

            //Second point
            if (secondCX > rectangleXMin &&
                secondCX < rectangleXMax &&
                secondCY > rectangleYmin &&
                secondCY < rectangleYMax) //point is within rectangle
            {
                damage += 100;
            }
            else if (((secondCX == rectangleXMin || secondCX == rectangleXMax) && (secondCY > rectangleYmin && secondCY < rectangleYMax)) ^
                      ((secondCY == rectangleYmin || secondCY == rectangleYMax) && (secondCX > rectangleXMin && secondCX < rectangleXMax))
                     ) // point is on one of the sides
            {
                damage += 50;
            }
            else if ((secondCX == rectangleXMin && secondCY == rectangleYmin) ||
                      (secondCX == rectangleXMin && secondCY == rectangleYMax) ||
                      (secondCX == rectangleXMax && secondCY == rectangleYmin) ||
                      (secondCX == rectangleXMax && secondCY == rectangleYMax)) //Point is on the corners
            {
                damage += 25;
            }
            else
            {
                //Point is outside rectangle, skip adding damage
            }

            //Third point
            if (thirdCX > rectangleXMin &&
                thirdCX < rectangleXMax &&
                thirdCY > rectangleYmin &&
                thirdCY < rectangleYMax) //point is within rectangle
            {
                damage += 100;
            }
            else if (((thirdCX == rectangleXMin || thirdCX == rectangleXMax) && (thirdCY > rectangleYmin && thirdCY < rectangleYMax)) ^
                      ((thirdCY == rectangleYmin || thirdCY == rectangleYMax) && (thirdCX > rectangleXMin && thirdCX < rectangleXMax))
                     ) // point is on one of the sides
            {
                damage += 50;
            }
            else if ((thirdCX == rectangleXMin && thirdCY == rectangleYmin) ||
                      (thirdCX == rectangleXMin && thirdCY == rectangleYMax) ||
                      (thirdCX == rectangleXMax && thirdCY == rectangleYmin) ||
                      (thirdCX == rectangleXMax && thirdCY == rectangleYMax)) //Point is on the corners
            {
                damage += 25;
            }
            else
            {
                //Point is outside rectangle, skip adding damage
            }

            Console.WriteLine("{0}%",damage);
        }
    }
}
