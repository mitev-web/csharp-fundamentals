using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4.Bits
{
    class Program
    {
        static int getBitCount(uint number)
        {
            int bits = 0;
            while (number > 2)
            {
                number /= 2;

                bits++;
            }
            if (number == 2)
                bits += 2;
            else
                bits++;

            return bits;
        }

        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());

            string line;
            uint p;
            uint pInv;
            uint pRev;
            uint answer;

            uint[] arr = new uint[n];

            for (int i = 0; i < n; i++)
            {
                line = Console.ReadLine();
                p = uint.Parse(line);

                pInv = PInverse(p);
                pRev = PReverse(p);

                answer = (p ^ pInv);
                answer &= pRev;
                arr[i] = answer;
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(arr[i]);
            }

        }

        static uint PReverse(uint p)
        {
            uint mask = 1;
            uint numberAndMask;
            int end = getBitCount(p);
            int q = 0;
            uint pRev = p;
            uint pRevTemp = p;

            for (int i = end - 1; i >= 0; i--)
            {
                mask = (uint)(1 << i);
                numberAndMask = (pRev & mask);
                numberAndMask = numberAndMask >> i;

                if (numberAndMask == 0)
                {
                    mask = (uint)~(1 << q);
                    pRevTemp = (pRevTemp & mask);
                }
                else if (numberAndMask == 1)
                {
                    mask = (uint)(1 << q);
                    pRevTemp = (pRevTemp | mask);
                }
                q++;
            }

            return pRevTemp;
        }

        static uint PInverse(uint p)
        {
            uint mask = 1;
            uint numberAndMask;
            int end = getBitCount(p);
            uint pInv = p;

            for (int i = 0; i < end; i++)
            {
                mask = (uint)(1 << i);
                numberAndMask = (pInv & mask);
                numberAndMask = numberAndMask >> i;
                if (numberAndMask == 0)
                {
                    mask = (uint)(1 << i);
                    pInv = (pInv | mask);
                }
                else if (numberAndMask == 1)
                {
                    mask = (uint)~(1 << i);
                    pInv = (pInv & mask);
                }
            }

            return pInv;
        }
    }
}
