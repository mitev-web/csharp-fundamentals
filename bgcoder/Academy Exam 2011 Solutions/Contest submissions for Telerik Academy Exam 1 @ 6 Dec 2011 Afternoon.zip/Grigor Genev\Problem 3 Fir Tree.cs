using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int numberN = Int32.Parse(Console.ReadLine());

            int width = (numberN - 1) * 2 - 1;
            int height = numberN - 2;

            for (int i = 0; i < width; i++)
            {
                if (i == width / 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();

            for (int i = 0, k = 1; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (j >= width / 2  - k && j <= width / 2 + k)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                k++;
                Console.WriteLine();
            }

            for (int i = 0; i < width; i++)
            {
                if (i == width / 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
