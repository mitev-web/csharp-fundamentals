using System;

namespace Problem4.WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            int[] numbersP = new int[numberOfLines];
            for (int i = 0; i < numberOfLines; i++)
            {
                numbersP[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < numbersP.Length; i++)
            {
                Console.WriteLine((numbersP[i]^FindFirstInvertedP(numbersP[i])) & FindSecondInvertedP(numbersP[i]));
            }
        }

        private static int FindSecondInvertedP(int pNumber)
        {
            int result = 0;
            bool[] bits = new bool[32];
            int i = 0;
            while (pNumber > 0)
            {
                bits[i] = CheckBitValue(pNumber, 0);
                i++;
                pNumber = pNumber >> 1;
            }         
            for (int j = 0; i > 0; i--,j++)
            {
                result = SetBitValue(result, j, bits[i-1]);
            }

            return result;
        }

        private static int FindFirstInvertedP(int pNumber)
        {
            int result = 0;
            int i = 0;
            while (pNumber > 0)
            {  
                result = SetBitValue(result, i, !CheckBitValue(pNumber, 0));
                pNumber = pNumber >> 1;
                i++;
            }       
            return result;
        }

        private static bool CheckBitValue(int pNumber, int pos)
        {
            bool result = false;
            int mask = 1 << pos;
            if ((pNumber & mask) != 0)
            {
                result = true;
            }
            return result;
        }

        private static int SetBitValue(int pNumber,int pos, bool value)
        {
            int result;
            if (value == false)
            {
                result = pNumber & (~(1 << pos));
            }
            else
            {
                result = pNumber | (1 << pos);
            }
            return result;
        }
    }
}
