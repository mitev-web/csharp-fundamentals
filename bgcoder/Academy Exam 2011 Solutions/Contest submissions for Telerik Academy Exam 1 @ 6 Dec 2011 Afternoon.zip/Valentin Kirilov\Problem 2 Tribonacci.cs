using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            // Read input
            long inputFirstNumber;
            long inputSecondNumber;
            long inputThirdNumber;
            int inputN;

            long.TryParse(Console.ReadLine(), out inputFirstNumber);
            long.TryParse(Console.ReadLine(), out inputSecondNumber);
            long.TryParse(Console.ReadLine(), out inputThirdNumber);
            int.TryParse(Console.ReadLine(), out inputN);

            BigInteger firstNumber = new BigInteger(inputFirstNumber);
            BigInteger secondNumber = new BigInteger(inputSecondNumber);
            BigInteger thirdNumber = new BigInteger(inputThirdNumber);

            // Check input
            //Console.WriteLine("{0} {1} {2} {3}", firstNumber, secondNumber, thirdNumber, inputN);
            
            BigInteger result = new BigInteger();
            result = 0;
            for (BigInteger currentNumber = 3; currentNumber < inputN; currentNumber++)
            {
                result = firstNumber + secondNumber + thirdNumber;
                firstNumber = secondNumber;
                secondNumber = thirdNumber;
                thirdNumber = result;
            }

            Console.WriteLine("{0}", result);
        }
    }
}
