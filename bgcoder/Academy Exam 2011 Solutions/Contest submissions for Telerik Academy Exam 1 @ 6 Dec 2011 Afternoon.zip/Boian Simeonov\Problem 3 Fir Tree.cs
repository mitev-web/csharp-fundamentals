using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirThree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int elements = ((n - 1) * 2) - 1;
            int counter = 1;
            int flag = elements/2;

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j <= elements; j++)
                {
                    if (j == flag)
                    {
                        for (int k = 0; k < counter; k++)
                        {
                            Console.Write("*");
                            j++;
                        }
                        counter += 2;
                        flag--;
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
            for (int i = 0; i < elements; i++)
            {
                if (i == elements / 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
