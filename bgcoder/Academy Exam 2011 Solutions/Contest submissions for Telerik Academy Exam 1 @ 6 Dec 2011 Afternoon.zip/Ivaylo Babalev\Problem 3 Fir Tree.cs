using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fir_Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int half =(n*2 - 3)/2;
            int dots = 0, stars =1;
            for (int rows = 0; rows < n  ; rows++)
            {
                if (rows == n - 1)
                {
                    half = (n * 2 - 3) / 2;
                    dots = 0;
                    stars = 1;
                }
                for (; dots < half ; dots++)
                {
                    Console.Write(".");
                }
                for (int k = 0; k < stars; k++)
                {
                    Console.Write("*");    
                }
                
                for (; dots > 0; dots--)
                {
                    Console.Write(".");
                }
                half--;
                stars += 2;
                Console.WriteLine();
            }
        }
    }
}
