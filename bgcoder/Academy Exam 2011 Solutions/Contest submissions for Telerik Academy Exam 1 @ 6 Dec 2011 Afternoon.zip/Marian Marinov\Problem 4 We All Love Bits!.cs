using System;

namespace ProbablyLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            
            short N = short.Parse(Console.ReadLine());
            long[] P = new long[N];
            long[] Prev = new long[N];
            string PnewString="";
            
            for (int i = 0; i < N; i++)
            {
                P[i] = int.Parse(Console.ReadLine());
            }

            for (long i = 0; i < N; i++)
            {
                long mask=1;
                for ( mask = 1; mask <= P[i] ; mask <<= 1)
                {
                }

                mask >>= 1;

                for (int j = 0; (mask >> j) > 0; j++)
                {
                    if ((P[i] & (mask >> j)) > 0)
                    {
                        Prev[i] |= 1 << j;
                    }
                }
                               
                PnewString += Prev[i] + "\n";// <= shortening program execution time 


            }

            Console.Write(PnewString);
        }
    }
}


/*

//////  I just want to add that this code uses int to do the SAME algorithm, but fails your test. Why?? For greater numbers, I'm having the mask 
//////  moved to the byte before the last(because the last is the sign). I assume your testing program is with uint/long and is using
//////  a value greater than Int32.MaxValue, which you give in Constraints..

using System;

namespace ProbablyLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            
            short N = short.Parse(Console.ReadLine());
            int[] P = new int[N];
            int[] Prev = new int[N];
            string PnewString="";
            
            for (int i = 0; i < N; i++)
            {
                P[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < N; i++)
            {
                int mask=1;
                for ( mask = 1;mask!= 1<<30 && mask <= P[i] ; mask <<= 1)
                {
                }

                if (mask != 1 << 30)
                {
                    mask >>= 1;
                }

                for (int j = 0; (mask >> j) > 0; j++)
                {
                    if ((P[i] & (mask >> j)) > 0)
                    {
                        Prev[i] |= 1 << j;
                    }
                }
                               
                PnewString += Prev[i] + "\n";// <= shortening program execution time 

            }

            Console.Write(PnewString);
        }
    }
}

*/