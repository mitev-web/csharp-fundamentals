using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


class Academy
{
    static int[] pleasantness;
    static int variety;
    static bool solved;
    static List<int> results;

    static void Main(string[] args)
    {
        //StreamReader reader = new StreamReader("t3.txt");
        //using (reader)
        //{
            string[] input = Console.ReadLine().Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            variety = int.Parse(Console.ReadLine());

            int length = input.Length;
            pleasantness = new int[length];
            for (int i = 0; i < length; i++)
            {
                pleasantness[i] = int.Parse(input[i]);
            }
       // }
        results = new List<int>();
        SolveAcademyProblem(0, 1, int.MaxValue, pleasantness[0]);
        if (solved)
        {
            Console.WriteLine(2);
            return;
        }
        Console.WriteLine(results.Min());

    }

    static void SolveAcademyProblem(int index,int count,int min, int max)
    {
        if (solved)
        {
            return;
        }

        if (max-min>=variety)
        {
            results.Add(count);
            if (count==2)
            {
                solved = true;
            }
            return;
        }

        if (index==pleasantness.Length-1)
        {
            return;
        }

        for (int i = 0; i <=1; i++)
        {
            if (i==0)
            {
                index ++;
                count++;
                int temp;
                if (pleasantness[index] > max)
                {
                    temp = max;
                    max = pleasantness[index];
                    if (temp < min)
                    {
                        min = temp;
                    }
                }
                else
                {
                    temp = pleasantness[index];
                    if (temp<min)
                    {
                        min = temp;
                    }
                }
                
                SolveAcademyProblem(index, count,min, max);
                count--;
            }
            if (i==1)
            {
                
                index = index +1;
                if (index>pleasantness.Length-1)
                {
                    return;
                }
                count++;
                int temp;
                if (pleasantness[index] > max)
                {
                    temp = max;
                    max = pleasantness[index];
                    if (temp < min)
                    {
                        min = temp;
                    }
                }
                else
                {
                    temp = pleasantness[index];
                    if (temp < min)
                    {
                        min = temp;
                    }
                }
                SolveAcademyProblem(index, count,min,max);
                count--;
            }
        }
    }
}
