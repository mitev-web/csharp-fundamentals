using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam
{
    class Program
    {
        public static int[] myArray;
        public static bool[] visitedNumbers;
        public static List<int> nonCycleNumbers = new List<int>();
        public static StringBuilder result = new StringBuilder();


        public static void SequenceGenerator(int index)
        {
            if (OutsideTheBounds(index))
            {
                if (index + 1 < myArray.Length)
                {
                    SequenceGenerator(index + 1);
                }
                else
                {
                    return;
                }
            }
            if (visitedNumbers[index] == true)
            {
                nonCycleNumbers.Remove(index);
                if (index + 1 < myArray.Length)
                {
                    SequenceGenerator(index + 1);
                }
                else
                {
                    return;
                }
            }

            if (index == myArray[index] || nonCycleNumbers.Contains(index))
            {
                visitedNumbers[index] = true;
            }
            if (visitedNumbers[index] == false)
            {
                nonCycleNumbers.Add(index);
            }
            SequenceGenerator(myArray[index]);
        }

        public static bool OutsideTheBounds(int index)
        {
            if (index >= myArray.Length || index < 0)
            {
                return true;
            }
            return false;
        }


        static void Main(string[] args)
        {
            int arraySize = 6;//int.Parse(Console.ReadLine());
            myArray = new int[arraySize];
            visitedNumbers = new bool[arraySize];
            StringBuilder sequence = new StringBuilder();
            for (int i = 0; i < myArray.Length; i++)
            {
                sequence.Append(Console.ReadLine());
            }
            string[] numbers = Convert.ToString(sequence).Split(' ');
            for (int i = 0; i < arraySize; i++)
            {
                myArray[i] = int.Parse(numbers[i]);
            }
            SequenceGenerator(0);
            result.Append(0);

            foreach (int i in nonCycleNumbers)
            {
                if (nonCycleNumbers.Count == 1)
                {
                    break;
                }
                result.Append(i);
                if (i + 1 <= nonCycleNumbers.Count)
                {
                    result.Append(" ");
                }
            }
            int counter = 0;
            for (int i = 0; i < visitedNumbers.Length; i++)
            {
                if (visitedNumbers[i] == true)
                {
                    if (!OutsideTheBounds(myArray[i]))
                    {
                        counter++;
                        break;
                    }
                }
            }

            List<int> someNumbers = new List<int>();

            if (counter != 0)
            {
                for (int i = 0; i < visitedNumbers.Length; i++)
                {
                    if (visitedNumbers[i] == true)
                    {
                        int tempIndexer = myArray[i];
                        if (!OutsideTheBounds(tempIndexer))
                            someNumbers.Add(myArray[i]);
                    }
                }
                someNumbers.Sort();
                result.Append("(");
                foreach (int number in someNumbers)
                {
                    result.Append(number);
                    if (number != someNumbers.Last())
                    {
                        result.Append(" ");
                    }
                }
                result.Append(")");
            }

            Console.WriteLine(final);

        }
    }
}