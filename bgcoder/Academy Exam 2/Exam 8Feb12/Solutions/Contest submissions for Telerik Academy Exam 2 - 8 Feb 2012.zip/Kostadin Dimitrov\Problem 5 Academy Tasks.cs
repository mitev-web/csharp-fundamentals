using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task05.AcademyTasks
{
    class AcademyTasks
    {
        static void Main(string[] args)
        {
            string pleasant = Console.ReadLine();
            char[] separator = { ' ', ',' };
            string[] pleasantArray = pleasant.Split(separator,StringSplitOptions.RemoveEmptyEntries);
            int[] pleasantness = new int[pleasantArray.Length];
            int[] sortPleasantness = new int[pleasantArray.Length];

            int variety = int.Parse(Console.ReadLine());

            for (int i = 0; i < pleasantArray.Length; i++)
            {
                pleasantness[i] = int.Parse(pleasantArray[i]);
                sortPleasantness[i] = int.Parse(pleasantArray[i]);
            }

            Array.Sort(sortPleasantness);
            int sum = 0;
            int k = 0;
            string allTask = null;

            while (variety >= sum)
            {
                sum += sortPleasantness[k];
                k++;
                if (k == sortPleasantness.Length)
                {
                    allTask = " ";
                    break;
                }
            }
            int counter = 1;
            int firstSum = pleasantness[0];
            int secondSum = pleasantness[0];
            sum = 0;

            for (int i = 0; i < pleasantness.Length - 2; i++)
            {
                firstSum += pleasantness[i+1];
                secondSum += pleasantness[i + 2];
                if (firstSum > secondSum)
                {
                    sum += firstSum;
                    counter++;
                }
                else
                {
                    sum += secondSum;
                    counter++;
                    i++;
                }
                if (sum / counter >= variety )
                {
                    break;
                }
            }
            if (allTask == " ")
            {
                counter = pleasantness.Length;
            }
            Console.WriteLine(counter);
            
        }
    }
}
