using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem_5
{
    class Program
    {
        static ushort minPleasantnes = ushort.MaxValue;
        static ushort maxPleasantnes = ushort.MinValue;
        static int counter = 0;
        static List<int> solves = new List<int>();

        static void Solve(ushort[] numbers, ushort variety,int index)
        {            
            if (maxPleasantnes - minPleasantnes >= variety)
            {
                solves.Add(counter);
                return;
            }
            for (int i = index; i < numbers.Length; i++)
            {
                counter++;
                if (numbers[i] < minPleasantnes)
                {
                    minPleasantnes = numbers[i];
                }
                if (numbers[i] > maxPleasantnes)
                {
                    maxPleasantnes = numbers[i];
                }                
                Solve(numbers, variety, index + 2);            
                Solve(numbers, variety, index + 1);                
            }            
        }
        static void Main(string[] args)
        {
            string pleasantness = Console.ReadLine();
            ushort variety = ushort.Parse(Console.ReadLine());
            char[] separator = {' ', ','};
            string[] numbers = pleasantness.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            ushort[] nums = new ushort[numbers.Length];
            for (int i = 0; i < numbers.Length; i++)
            {
                nums[i] = ushort.Parse(numbers[i]);
            }
            Solve(nums, variety,0);
            int result = solves.Min();
            Console.WriteLine(result);
        }
    }
}
