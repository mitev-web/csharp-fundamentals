using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3_Indices
{
    class Indices
    {
        static void Main()
        {
            int N = Int32.Parse(Console.ReadLine());
            string inputLine = Console.ReadLine();
            int[] arr = new int[N];
            string[] numbers = inputLine.Split(' ');

            for (int i = 0; i < N; i++ )
            {
                arr[i] = Convert.ToInt32(numbers[i]);
            }

            if (arr[0] >= N) Console.WriteLine("0 1");
          

        }   
    }
}