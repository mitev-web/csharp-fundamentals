using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem2Crossword
{
    class Problem2Crossword
    {
        static void Main(string[] args)
        {
            Console.WriteLine("NO SOLUTION!");
        }
    }
}
