using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task5
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            char[] separator = { ' ', ',', '\n' };
            string[] stringPleasant = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] pleasantness = new int[stringPleasant.Length];

            int min = int.MaxValue;
            int max = int.MinValue;

            /* parse the input */
            for (int i = 0; i < stringPleasant.Length; i++)
            {
                pleasantness[i] = int.Parse(stringPleasant[i]);

                /* get min and max value */
                if (min > pleasantness[i])
                {
                    min = pleasantness[i];
                }
                else
                {
                    if (max < pleasantness[i])
                    {
                        max = pleasantness[i];
                    }
                }
            }

            
            int variety = int.Parse(Console.ReadLine());
            if (max - min < variety)
            {
                Console.WriteLine(pleasantness.Length);
            }
            else
            {
                Console.WriteLine(Solve(pleasantness, variety, min, max));
            }
        }

        private static int Solve(int[] pleasantness, int variety, int minPl, int maxPl)
        {
            int columns = maxPl - minPl + 1;
            int[,] optimize = new int[pleasantness.Length, columns];
            const int empty = 10000;
           

            for (int rows = 0; rows < pleasantness.Length; rows++)
            {
                for (int cols = 0; cols < columns; cols++)
                {
                    optimize[rows, cols] = empty;
                }
            }

            int min, max;
            min = max = pleasantness[0];
            optimize[0, 0] = 1;
            int answer = 10001;
            bool done = false;

            for (int rows = 0; rows < pleasantness.Length; rows++)
            {
                if (done)
                    break;

                for (int cols = 0; cols < columns; cols++)
                {
                    //min = max = pleasantness[rows];
                    if (optimize[rows, cols] != empty)
                    {
                        /* i+1 move */
                        if (rows + 1 < pleasantness.Length)
                        {
                            if (min > pleasantness[rows + 1])
                            {
                                min = pleasantness[rows + 1];
                            }
                            else
                            {
                                if (max < pleasantness[rows + 1])
                                    max = pleasantness[rows + 1];
                            }

                            optimize[rows + 1, max - min] = Math.Min(optimize[rows, cols] + 1, optimize[rows + 1, max - min]);

                            for (int i = variety; i < columns; i++)
                            {
                                if (optimize[rows + 1, i] != empty)
                                {
                                    if (answer > optimize[rows + 1, i])
                                    {
                                        answer = optimize[rows + 1, i];
                                    }
                                    done = true;
                                }
                            }
                        }

                        //min = max = pleasantness[rows];
                        /* i+2 move */
                        if (rows + 2 < pleasantness.Length)
                        {
                            if (min > pleasantness[rows + 2])
                            {
                                min = pleasantness[rows + 2];
                            }
                            else
                            {
                                if (max < pleasantness[rows + 2])
                                    max = pleasantness[rows + 2];
                            }

                            optimize[rows + 2, max - min] = Math.Min(optimize[rows, cols] + 1, optimize[rows + 2, max - min]);

                            for (int i = variety; i < columns; i++)
                            {
                                if (optimize[rows + 2, i] != empty)
                                {
                                    if (answer > optimize[rows + 1, i])
                                    {
                                        answer = optimize[rows + 2, i];
                                    }
                                    done = true;
                                }
                            }
                        }
                    }
                }
            }

            return answer;
        }
    }
}
