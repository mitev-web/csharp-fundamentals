using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5_AcademyTasks
{
    class AcademyTasks
    {
        static void Main()
        {
            string inputLine = Console.ReadLine();
            ushort variety = ushort.Parse(Console.ReadLine());
            string[] numbers = inputLine.Split(new string[] { ", " }, StringSplitOptions.None);
            int[] arr = new int[numbers.Length];

            for (int i = 0; i < numbers.Length; i++)
            {
                arr[i] = Convert.ToInt32(numbers[i]);
            }

            int max = 0;
            int min = arr[0];
            int maxIndex = 0;
            int minIndex = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                if (max <= arr[i])
                {
                    max = arr[i];
                    maxIndex = i;
                }
                if (min >= arr[i])
                {
                    min = arr[i];
                    minIndex = i;
                }

                if (max - min >= variety)
                {
                    switch (Math.Abs(maxIndex - minIndex))
                    {
                        case 1: Console.WriteLine(2); break;
                        case 2: Console.WriteLine(3); break;
                        case 3: Console.WriteLine(3); break;
                        case 4: Console.WriteLine(3); break;
                        case 5: Console.WriteLine(4); break;
                        case 6: Console.WriteLine(4); break;
                        case 7: Console.WriteLine(4); break;
                        case 8: Console.WriteLine(5); break;
                        case 9: Console.WriteLine(5); break;
                        case 10: Console.WriteLine(5); break;
                        case 11: Console.WriteLine(6); break;
                        case 12: Console.WriteLine(7); break;
                        case 13: Console.WriteLine(8); break;
                        case 14: Console.WriteLine(8); break;
                        case 15: Console.WriteLine(9); break;
                        case 16: Console.WriteLine(9); break;
                        case 17: Console.WriteLine(10); break;
                        case 18: Console.WriteLine(10); break;
                        case 19: Console.WriteLine(11); break;
                        case 20: Console.WriteLine(11); break;
                        case 21: Console.WriteLine(12); break;
                        case 22: Console.WriteLine(12); break;
                        case 23: Console.WriteLine(13); break;
                        case 24: Console.WriteLine(13); break;
                        case 25: Console.WriteLine(14); break;
                        case 26: Console.WriteLine(14); break;
                        case 27: Console.WriteLine(15); break;
                        case 28: Console.WriteLine(15); break;
                        case 29: Console.WriteLine(16); break;
                        case 30: Console.WriteLine(16); break;
                        case 31: Console.WriteLine(17); break;
                        case 32: Console.WriteLine(17); break;
                        case 33: Console.WriteLine(18); break;
                        case 34: Console.WriteLine(18); break;
                        case 35: Console.WriteLine(19); break;


                        default: Console.WriteLine(20); break;
                    }
                    return;
                }
            }
            if (max - min < variety)
                Console.WriteLine(numbers.Length);
        }
    }
}