using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indeces
{
    class Program
    {
        static List<string> list = new List<string>();
        
        static void Main(string[] args)
        {
            int[] array = new int[] {1,2,3,5,7,8 };
            Index(array);
            Print(list);
        }

        public static void Index (int[] array)
        {
            for (int index = 0; index < array.Length; index++)
            {
                list.Add(index.ToString());
                index =array[index];
                index--;
            }

        }

        static void Print(List<string> list)
        {
            foreach (string elem in list)
            {
                Console.Write(elem);
                if (elem != list.Last())
                {
                    Console.Write(" ");
                }
            }
        }
    }
}
