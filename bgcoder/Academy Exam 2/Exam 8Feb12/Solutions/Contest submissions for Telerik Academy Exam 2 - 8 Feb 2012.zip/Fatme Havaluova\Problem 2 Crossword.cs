using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace crossword
{
    class Program
    {
        static bool isFindRes = false;
        static void Main(string[] args)
        {
           // using (StreamReader reader = new StreamReader("test.txt"))
           // {
                int n = int.Parse(Console.ReadLine());
                char[,] crossword = new char[n, n];
                string[] words = new string[2*n];
                for (int i = 0; i < 2 * n; i++)
                {
                    words[i] = Console.ReadLine();
                }
               // string[] arr = new string[n];
                //combinations(arr, 0, words, 1);
                //if (isFindRes == false) Console.WriteLine("NO SOLUTION!");
                createSubsets(words,n);
           // }

                
        }
        static void combinations(string[] arr, int index,string[] words,int begin)
        {
            if (index >= arr.Length)
            {
                 print(arr);
                return;
            }
            for(int i=begin-1;i<words.Length;i++)
            {
                arr[index] = words[i];
                combinations(arr, index + 1,words,begin+1);
            }

        }
        private static void createSubsets(string[] originalArray,int n)
        {
            List<string[]> subsets = new List<string[]>();

            for (int i = 0; i < originalArray.Length; i++)
            {
                int subsetCount = subsets.Count;
                subsets.Add(new string[] { originalArray[i] });

                for (int j = 0; j < subsetCount; j++)
                {
                    string[] newSubset = new string[subsets[j].Length + 1];
                    subsets[j].CopyTo(newSubset, 0);
                    newSubset[newSubset.Length - 1] = originalArray[i];
                    subsets.Add(newSubset);
                    int length = newSubset.Length;
                    if (length == n)
                    {
                        if(isValidCross(newSubset,originalArray)) print(newSubset);
                        break;
                    }
                }
            }

            //return subsets;
        }


        static void print(string[] arr)
        {
            if (isFindRes == false)
            {
                foreach (string element in arr)
                {
                    Console.WriteLine(" {0} ", element);
                }
                Console.WriteLine();
                isFindRes = true;
            }
            
        }
        static bool isValidCross(string[] arr,string[] words)
        {
            char[,] chars = new char[arr.Length, arr.Length];
            int k=0;
            StringBuilder res = new StringBuilder();
            while (k < arr.Length)
            {
                res.Clear();
                for (int i = 0; i < arr.Length; i++)
                {
                    res.Append(arr[i].ElementAt(k).ToString());
                }
                if (!words.Contains(res.ToString())) return false;
                k++;
            }
            return true;
        }

       
       
    }
}
