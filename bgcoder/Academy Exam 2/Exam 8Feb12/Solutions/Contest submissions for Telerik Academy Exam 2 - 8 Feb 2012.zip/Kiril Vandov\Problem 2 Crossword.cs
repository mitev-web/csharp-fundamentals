using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

class Crossword
{
    static int n;
    static bool solved;
    static string[] words;
    static char[,] crossword;
    static void Main(string[] args)
    {
        //StreamReader reader = new StreamReader("t1.txt");
        //using (reader)
        //{
            n = int.Parse(Console.ReadLine());
            words = new string[n * 2];
            for (int i = 0; i < n * 2; i++)
            {
                words[i] = Console.ReadLine();
            }
       // }
        Array.Sort(words);
        crossword = new char[n, n];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                crossword[i, j] = '-';
            }
        }
        SolveCrossword(0);
        if (!solved)
        {
            Console.WriteLine("NO SOLUTION!");
        }
    }

    static void SolveCrossword(int word)
    {
        if (solved)
        {
            return;
        }
        if (word==1)
        {
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                char start = crossword[0,i];
                for (int j = 0; j < n; j++)
                {
                    string woow = words[j];
                    if (start==woow[0])
                    {
                        count++;
                        break;
                    }
                }
            }
            if (count!=n)
            {
                return;
            }
        }
        if (word == 2)
        {
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                char start = crossword[1, i];
                for (int j = 0; j < n; j++)
                {
                    string woow = words[j];
                    if (start == woow[1])
                    {
                        count++;
                        break;
                    }
                }
            }
            if (count != n)
            {
                return;
            }
        }
        if (word == 3)
        {
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                char start = crossword[2, i];
                for (int j = 0; j < n; j++)
                {
                    string woow = words[j];
                    if (start == woow[2])
                    {
                        count++;
                        break;
                    }
                }
            }
            if (count != n)
            {
                return;
            }
        }
        if (word == n)
        {
            //StringBuilder checkWord = new StringBuilder();
            int count = 0;
            for (int i = 0; i < n; i++)
            {
                string checkWord = string.Empty;
                for (int j = 0; j < n; j++)
			    {
                    checkWord+=crossword[j, i];
			    }
                for (int j = 0; j < n*2; j++)
                {
                    if (checkWord== words[j])
                    {
                        count++;
                        break;
                    }
                }
                if (count==n)
                {
                    solved = true;
                    Print();
                    break;
                }
            }

            if (count==4)
            {
                solved = true;
            }
            return;
        }

        for (int i = 0; i < n*2; i++)
        {
            string currentWord = words[i];
            for (int j = 0; j < n; j++)
            {
                crossword[word, j] = currentWord[j];
            }
            SolveCrossword(word + 1);
            for (int j = 0; j < n; j++)
            {
                crossword[word, j] = '-';
            }
        }

    }

    static void Print()
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write(crossword[i,j]);
            }
            Console.WriteLine();
        }
    }
}