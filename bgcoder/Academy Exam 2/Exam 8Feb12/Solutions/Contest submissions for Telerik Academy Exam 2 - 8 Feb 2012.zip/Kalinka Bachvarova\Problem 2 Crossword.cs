using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreateCrossword
{
    class Problem2
    {
        static string[] words = { "FIRE", "ACID", "CENG", "EDGE", "FACE", "ICED", "RING", "CERN" };//new string [2*size];
        static List<string> combinations = new List<string>();
        static int size = 4;
        static string[] result = new string[size];
        static char[,] crossword = new char [size, size];
        static string chars = "";
        static int counter = 0;
        static string check = "";
        static int equal = 0;
        static bool ifEqual = false; 

        static void GenNWords(int index, string[] result, int start)
        {
            if (index == -1)
            {
                AddCombination(combinations);
            }
            else
            {
                for (int i = start; i < words.Length; i++)
                {
                    result[index] = words[i];
                    GenNWords(index - 1, result, i + 1);
                }
            }
        }

        static void AddCombination(List<string> combinations)
        {
            for (int i = 0; i < size; i++)
            {
                combinations.Add(result[i]);
            }
        }

        static void Main()
        {
            GenNWords(size - 1, result, 0);

            //while (equal != size)
            //{
            //    for (int row = 0; row < size; row++)
            //    {
            //        for (int col = 0; col < size; col++)
            //        {
            //            crossword[row, col] = '\0';
            //        }
            //    }
                for (int row = 0; row < size; row++)
                {
                    for (int col = 0; col < size; col++)
                    {
                        chars = combinations[row + counter];
                        crossword[row, col] = chars[col];
                        Console.Write(crossword[row, col]);
                    }
                    counter += 4;
                    Console.WriteLine();
                }
                counter = 0;

                for (int col = 0; col < size; col++)
                {
                    for (int row = 0; row < size; row++)
                    {
                        check = check + crossword[row, col];
                    }
                    for (int i = 0; i < words.Length; i++)
                    {
                        ifEqual = (check == words[i]);
                        if (!ifEqual)
                        {
                            break;
                        }
                        else
                        {
                            equal++;
                        }
                    }

                }
                if (equal == size)
                {
                    for (int m = 0; m < size; m++)
                    {
                        for (int n = 0; n < size; n++)
                        {
                            Console.Write(crossword[m, n]);
                        }

                    }
                    Console.WriteLine();
                }
            
        }        
    }
}
