using System;

namespace Problem05
{
    class Problem05
    {
        static int[] pleasantness;
        static int variety;

        static int minNumOfProb; //starts at pleasantness.Length
        
        static void ReadInput()
        {
            string pleasantnessStr = Console.ReadLine();

            string[] tokens = pleasantnessStr.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            pleasantness = new int[tokens.Length];


            for (int i = 0; i < tokens.Length; i++)
            {
                pleasantness[i] = int.Parse(tokens[i]);
            }

            variety = int.Parse(Console.ReadLine());

            minNumOfProb = pleasantness.Length;

        }


        static void GetMinProblemSolved(/*int currentVar, */ int currentMaxP, int currentMinP, int currentTask, int tasksSolved)
        {

            

            currentMaxP = Math.Max(currentMaxP, pleasantness[currentTask]);
            currentMinP = Math.Min(currentMinP, pleasantness[currentTask]);

            int currentVariety = currentMaxP - currentMinP;            

            if (currentVariety >= variety)
            {
                minNumOfProb = Math.Min(minNumOfProb, tasksSolved);
                return;
            }

            for (int i = 0; i < 2; i++)
            {
                if (i == 0)
                {
                    if (tasksSolved + 1 > minNumOfProb || currentTask +1 >= pleasantness.Length)
                       continue;

                    GetMinProblemSolved(currentMaxP, currentMinP ,currentTask + 1, tasksSolved + 1);
                }
                else
                {
                    if (tasksSolved + 1 > minNumOfProb || currentTask + 2 >= pleasantness.Length)
                        continue;

                    GetMinProblemSolved(currentMaxP, currentMinP, currentTask + 2, tasksSolved + 1);
                }
            }
        }

        static void Main()
        {
            ReadInput();

            GetMinProblemSolved(0, 1000, 0, 1);

            Console.WriteLine(minNumOfProb);
        }
    }
}
