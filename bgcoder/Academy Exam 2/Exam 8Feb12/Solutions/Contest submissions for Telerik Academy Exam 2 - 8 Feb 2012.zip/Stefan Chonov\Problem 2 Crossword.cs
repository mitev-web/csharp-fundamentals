using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword
{
    class Crossword
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            byte numberOfWords = (byte)(n * 2);
            string[] allWords = new string[numberOfWords];

            for (byte i = 0; i < numberOfWords; i++)
            {
                allWords[i] = Console.ReadLine();
            }

            List<List<string>> allPassableCrosswords = new List<List<string>>();

            List<string> bestCrossword = new List<string>();

            //foreach (string[] words in allPassableCrosswords)
            //{
            //    List<string> newOp = CheckHorizontals(words, allWords);

            //    if (newOp.Count > bestCrossword.Count)
            //    {
            //        List<string> newOp0 = CheckVerticals(allWords, allWords);
            //        bestCrossword = newOp;
            //    }
            //}

            for (byte i = 0; i < allWords.Length; i++)
            {
                string word = allWords[i];
                List<string> matchingWord = FindMatchingOfLetter(word, allWords);

                allPassableCrosswords.Add(matchingWord);
            }

            foreach (List<string> words in allPassableCrosswords)
            {
                List<string> newOp = CheckHorizontals(words, allWords);
                //List<string> newOp2 = CheckVerticals(words, allWords);
                                
                //if (newOp.Count > bestCrossword.Count)
                //{
                //    bestCrossword = newOp;
                //}
                
                if (newOp.Count >= bestCrossword.Count) 
                {
                    string firstCrossword = ConcatenateLines(bestCrossword);
                    string secondCrossword = ConcatenateLines(newOp);

                    if (firstCrossword != String.Empty)
                    {
                        bool isLexicographicallyLowest = CompareLexicographically(firstCrossword, secondCrossword);
                        if (!isLexicographicallyLowest)
                        {                            
                            bestCrossword = newOp;
                        }
                    }
                    else
                    {
                        newOp = CheckHorizontals(newOp, allWords);
                        bestCrossword = newOp;
                    }
                }
            }

            if (bestCrossword.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (string word in bestCrossword)
                {
                    sb.AppendLine(word);
                }

                Console.Write(sb);
            }
            else
            {
                Console.WriteLine("NO SOLUTION!");
            }
        }

        private static List<string> FindMatchingOfLetter(string word, string[] words)
        {
            List<string> matchingWords = new List<string>();

            for (int i = 0; i < word.Length; i++)
            {
                char letter = word[i];

                for (int j = 0; j < words.Length; j++)
                {
                    if (word != words[j])
                    {
                        if (letter == words[j][0])
                        {
                            if (!matchingWords.Contains(words[j]))
                            {
                                matchingWords.Add(words[j]);
                            }
                        }
                    }
                }
            }

            return matchingWords;
        }
        
        private static List<string> CheckHorizontals(List<string> words, string[] allWords)
        {
            List<string> mostMatchingWords = new List<string>();
            int lengthOfWords = words.Count;
            string tempWord = null;
            byte countPassableWords = 0;
            byte lastCountOfPassableWords = 0;

            for (int i = 0; i < lengthOfWords; i++)
            {
                string w = words[i];
                int missRow = i;
                byte startRow = 0;

                for (int j = 0; j < w.Length; j++)
                {
                    for (int x = 0; x < lengthOfWords; x++)
                    {
                        if (x == startRow)
                        {
                            x = startRow + missRow;
                        }

                        if (x < lengthOfWords)
                        {
                            tempWord += words[x][j];
                        }
                    }

                    foreach (string word in allWords)
                    {
                        if (tempWord == word)
                        {
                            countPassableWords++;
                            break;
                        }
                    }

                    if (countPassableWords > lastCountOfPassableWords)
                    {
                        lastCountOfPassableWords = countPassableWords;

                        foreach (string word in allWords)
                        {
                            if (tempWord == word)
                            {
                                mostMatchingWords.Add(tempWord);
                                break;
                            }
                        }
                    }

                    tempWord = null;
                    startRow++;
                }
            }

            return mostMatchingWords;
        }

        private static List<string> CheckVerticals(string[] words, string[] allWords)
        {
            List<string> mostMatchingWords = new List<string>();
            int lengthOfWords = words.Length;
            string tempWord = null;
            byte countPassableWords = 0;
            byte lastCountOfPassableWords = 0;

            for (int i = 0; i < words[0].Length; i++)
            {
                string w = words[i];
                int missRow = i;
                byte startRow = 0;

                for (int j = 0; j < lengthOfWords; j++)
                {
                    for (int x = 0; x < w.Length; x++)
                    {
                        if (x == startRow)
                        {
                            x = startRow + missRow;
                        }

                        if (x < lengthOfWords)
                        {
                            tempWord += words[x][j];
                        }
                    }

                    foreach (string word in allWords)
                    {
                        if (tempWord == word)
                        {
                            countPassableWords++;
                            break;
                        }
                    }

                    if (countPassableWords > lastCountOfPassableWords)
                    {
                        lastCountOfPassableWords = countPassableWords;

                        foreach (string word in allWords)
                        {
                            if ((tempWord == word) && (!mostMatchingWords.Contains(tempWord)))
                            {
                                mostMatchingWords.Add(tempWord);
                                break;
                            }
                        }
                    }

                    tempWord = null;
                    startRow++;
                }
            }

            return mostMatchingWords;
        }

        private static string ConcatenateLines(List<string> words)
        {
            StringBuilder sb = new StringBuilder();

            foreach (string word in words)
            {
                sb.Append(word);
            }

            return sb.ToString();
        }

        private static bool CompareLexicographically(string text, string secondText)
        {
            bool result = false;

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] < secondText[i])
                {
                    result = true;
                    break;
                }
                else if (text[i] > secondText[i])
                {                    
                    break;
                }
            }

            return result;
        }
    }
}