using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P02_Crossword
{
    class Crossword
    {
        static string[] givenWords;        
        static int n;
        static bool found;
        static string result;
        static bool CheckCrossword(int[] vector, List<string> words)
        {
            bool[] isCrossword = new bool[n];
            string[] result = new string[n];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = words[vector[i]];
                words[vector[i]] = String.Empty;                
            }
            List<string> restOftheWords = new List<string>();
            for (int i = 0; i < words.Count; i++)
            {
                if (words[i] != string.Empty)
                {
                    restOftheWords.Add(words[i]);
                }
            }
            for (int i = 0; i < result.Length; i++)
            {
                StringBuilder word = new StringBuilder();
                for (int j = 0; j < result.Length; j++)
                {
                    word.Append(result[j][i % n]);
                }
                for (int j = 0; j < restOftheWords.Count; j++)
                {
                    if (word.ToString() == restOftheWords[j])
                    {
                        isCrossword[i] = true;
                        restOftheWords[j] = string.Empty;
                        break;
                    }                                        
                }                
            }
            bool ifTrue = true;
            for (int i = 0; i < isCrossword.Length; i++)
            {
                ifTrue = ifTrue && isCrossword[i];
            }
            if (ifTrue)
            {
                found = true;
            }
            return ifTrue;
        }
        static void GenPermutations(int[] vector, int index)
        {            
            if (index >= vector.Length)
            {
                List<string> words = new List<string>();                
                foreach (string str in givenWords)
                {
                    words.Add(str);
                }
                if (CheckCrossword(vector, words))
                {
                    result = string.Empty;
                    for (int i = 0; i < n; i++)
                    {
                        result = result + string.Format("{givenWords[vector[i]]}");
                    }
                }
            }
            else
            {                
                for (int i = index; i < vector.Length; i++)
                {
                    int temp = vector[i];
                    vector[i] = vector[index];
                    vector[index] = temp;
                    GenPermutations(vector, index + 1);
                    temp = vector[i];
                    vector[i] = vector[index];
                    vector[index] = temp;
                }
            }
        }
        static void Main(string[] args)
        {
            string inputLine = Console.ReadLine();
            n = int.Parse(inputLine);
            givenWords = new string[n * 2];
            for (int i = 0; i < n * 2; i++)
            {
                givenWords[i] = Console.ReadLine();
            }
            int[] vector = new int[n * 2];
            for (int i = 0; i < vector.Length; i++)
            {
                vector[i] = i;
            }
            GenPermutations(vector, 0);
            if (found == false)
            {

                Console.WriteLine("NO SOLUTION!");
            }
        }
    }
}
