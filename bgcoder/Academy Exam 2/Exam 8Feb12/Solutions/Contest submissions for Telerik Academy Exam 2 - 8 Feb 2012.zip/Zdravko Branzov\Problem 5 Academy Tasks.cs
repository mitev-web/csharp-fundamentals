using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Academy
{
    class Program
    {
        static int min = 0;
        static int max = 0;
        static bool skipUsed = false;
        static int skipped = 0;

        static int counter = 1;
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
           string[] array = str.Split(new string[] { ", " },StringSplitOptions.None);
           List<int> input = new List<int>();
           for (int j = 0; j < array.Length; j++)
           {
               input.Add(int.Parse(array[j]));
           }

           int variety = int.Parse(Console.ReadLine());
            int first =0;
            int next = 0;
            /////////////////////////////////////////////////////////////////////////
            for (int i = 1; i < input.Count; i++)
            {


                if (i == 1)
                {

                    first = input[i - 1];      //kato po4va s nuleviq
                    next = input[i];

                    max = Math.Max(first, next);
                    min = Math.Min(first, next);
                }
                else
                {
                    next = input[i];
                    if (next > max)
                    {
                        max = next;
                    }
                    if (next < min)
                    {
                        min = next;
                    }
                }

                int diff = Math.Abs(min - max);

                if (skipUsed == true && diff<variety && skipped==1)
                {
                    
                    //counter++;
                    skipped--;
                }

                if (diff >= variety)
                {
                    counter++;
                    Console.WriteLine(counter);
                    break;
                }

                if (skipped == 0)
                {
                    skipUsed = false;
                }
                //////////////////////////////////////////////////////////////////////////////////////

                if (diff < variety && skipUsed==false) /////////SKIP
                {
                    skipUsed = true;
                    skipped++;
                    next = input[i + 1];  //ako razlikata e po malka prvim skip i vzimame sledva6toto

                    if (next > max)
                    {
                        max = next;
                    }
                    if (next < min)
                    {
                        min = next;
                    }

                    i++;

                    diff = Math.Abs(min - max);
                    counter++; //ka4vame s edno za6toto nqmame skip i sme obrabotili next

                    if (diff >= variety)
                    {
                       
                        Console.WriteLine(counter);
                        break;
                    }

                }


            }
        }
    }
}
