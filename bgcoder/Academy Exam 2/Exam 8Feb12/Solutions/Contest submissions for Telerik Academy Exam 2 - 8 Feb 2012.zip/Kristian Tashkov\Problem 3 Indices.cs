using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Indices
    {
        static void Main(string[] args)
        {
            int n=int.Parse(Console.ReadLine());
            int[] array = new int[n];
            bool[] found = new bool[n];
            string[] input = (Console.ReadLine()).Split(' ');
            for (int i = 0; i < n; i++)
            {
                array[i]=int.Parse(input[i]);
            }
            int current=0;
            List<int> output = new List<int>();
            output.Add(0);
            found[0]=true;
            int cycle = -1;
            while (array[current] >= 0 && array[current] < n)
            {
                current=array[current];
                if (found[current] == false)
                {
                    output.Add(current);
                    found[current] = true;
                }
                else
                {
                    cycle = current;
                    break;
                }
            }
            for (int i = 0; i < output.Count; i++)
            {
                if (cycle == 0 && i == 0) Console.Write("(" + output[i]);
                else Console.Write(output[i]);
                if(i+1==output.Count)
                {
                    if (cycle != -1) Console.Write(')'+Environment.NewLine);
                    else Console.WriteLine();
                }
                else
                {
                    if (output[i + 1] == cycle)
                    {
                        Console.Write('(');
                    }
                    else Console.Write(' ');
                }
            }
        }
    }
}
