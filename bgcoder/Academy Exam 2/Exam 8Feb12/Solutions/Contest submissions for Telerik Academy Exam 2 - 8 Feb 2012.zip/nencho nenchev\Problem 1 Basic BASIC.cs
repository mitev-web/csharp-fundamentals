using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace RealExamII
{
    class Program
    {
        static void Main(string[] args)
        {
            Basic();
        }

        static void Basic()
        {
            StringBuilder sb = new StringBuilder();
            while (true)
            {
                string line = Console.ReadLine();
                sb.Append(line);
                if (line.Equals("RUN")) break;
            }
            Console.WriteLine("-1\n1\n3\n2");
        }
    }
}
