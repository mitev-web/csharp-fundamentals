using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Basic_BASIC
{
    class Basic_BASIC
    {
        static string[] keywords = new string[]{
            "V", "W", "X", "Y", "Z",
            "GOTO", "IF", "THEN", "STOP",
            "CLS", "PRINT", 
            "<", ">", "=",
            "+", "-", " "
        };

        static string variables = "V W X Y Z";
        static string conditional = "IF THEN";
        static string arithmetic = "< > = + -";
        static string output = "CLS PRINT";
        static string other = "GOTO STOP";

        static List<string> codeLines = new List<string>();

        static Dictionary<int, int> lineNumToIndex = new Dictionary<int, int>();
        static Dictionary<string, int> vars = new Dictionary<string, int>();

        static void EnumerateLines()
        {
            for (int ind = 0; ind < codeLines.Count; ind++ )
            {
                string line = codeLines[ind];
                int lineNum = int.Parse(line.Substring(0, line.IndexOf(" ")));
                lineNumToIndex.Add(lineNum, ind);
            }
        }

        static void ParseExpression(string[] expression, int lookAt)
        {
            if (expression[lookAt + 2] == "+")
            {
                 vars[expression[lookAt]] = int.Parse(expression[lookAt + 3]);
            }
            else if (expression[lookAt + 2] == "-")
            {
                vars[expression[lookAt]] = -int.Parse(expression[lookAt + 3]);
            }
            else
            {
                if (lookAt + 3 >= expression.Length)
                {
                    vars[expression[lookAt]] = vars[expression[lookAt + 2]];
                }
                else
                {
                    if (expression[lookAt + 3] == "+")
                    {
                        vars[expression[lookAt]] = vars[expression[lookAt + 2]] + vars[expression[lookAt + 4]];
                    }
                    else
                    {
                        vars[expression[lookAt]] = vars[expression[lookAt + 2]] + vars[expression[lookAt + 4]];
                    }
                }
            }
        }

        static int GetValue(string varOrNum)
        {
            if (variables.Contains(varOrNum))
            {
                return vars[varOrNum];
            }
            else
            {
                return int.Parse(varOrNum);
            }
        }

        static void ParseConditional(string[] expression, int lookAt)
        {
            bool conditionValue=false;
            if (expression[lookAt + 1] == "=")
            {
                conditionValue = (GetValue(expression[lookAt]) == GetValue(expression[lookAt + 2]));
            }
            if (expression[lookAt + 1] == "<")
            {
                conditionValue = (GetValue(expression[lookAt]) < GetValue(expression[lookAt + 2]));
            }
            if (expression[lookAt + 1] == ">")
            {
                conditionValue = (GetValue(expression[lookAt]) > GetValue(expression[lookAt + 2]));
            }
            if (conditionValue)
            {
                string line = "";
                for (int i = lookAt; i < expression.Length; i++)
                {
                    if (expression[i] == "THEN")
                    {
                        lookAt = i+1;
                        break;
                    }
                }
                for (int i = lookAt; i < expression.Length; i++)
                {
                    line += expression[i];
                }
                ParseLine(line, 0, lookAt-1, 0);
            }
        }

        static void ParseOutput(string[] expression, int lookAt)
        {
            if (expression[1] == "CLS")
            {
                Console.Clear();
            }
            else
            {
                if (variables.Contains(expression[lookAt]))
                {
                    Console.WriteLine(vars[expression[lookAt]]);
                }
                else
                {
                    Console.WriteLine(expression[lookAt]);
                }
            }
        }

        static int ParseLine(string line, int index, int lookAt=0, int skipSpeak=2)
        {
            string[] lineElements = line.Split(new string[]{" "}, StringSplitOptions.RemoveEmptyEntries);
            if (variables.Contains(lineElements[lookAt + 1]))
            {
                ParseExpression(lineElements, lookAt + skipSpeak);
            }
            if (conditional.Contains(lineElements[lookAt + 1]))
            {
                ParseConditional(lineElements, lookAt + skipSpeak);
            }
            if (output.Contains(lineElements[lookAt + 1]))
            {
                ParseOutput(lineElements, lookAt + skipSpeak);
            }
            else
            {
                if (lineElements[lookAt + 1] == "GOTO")
                {
                    return int.Parse(lineElements[lookAt + skipSpeak]);
                }
                if (lineElements[lookAt + 1] == "STOP")
                {
                    return -1;
                }
            }
            return index + 1;
        }

        static void Main(string[] args)
        {
            vars.Add("X", 0);
            vars.Add("Y", 0);
            vars.Add("Z", 0);
            vars.Add("V", 0);
            vars.Add("W", 0);
            Input();
            EnumerateLines();
            Console.WriteLine(lineNumToIndex[50]);
            int lineToParseInd = 0;
            while (lineToParseInd < codeLines.Count && lineToParseInd!=-1)
            {
                lineToParseInd = ParseLine(codeLines[lineToParseInd], lineToParseInd);
            }
        }

        private static void Input()
        {
            string codeLine = "";
            while (codeLines.Count==0 || codeLines[codeLines.Count - 1] != "RUN")
            {
                codeLines.Add(Console.ReadLine());
            }
            codeLines.RemoveAt(codeLines.Count - 1);
        }
    }
}
