using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static int v = 0;
        static int w = 0;
        static int x = 0;
        static int y = 0;
        static int z = 0;
        static int lines = 10001;
        static string[] code = new string[lines];

        static int index = 0;
        static bool flag = true;

        static StringBuilder result = new StringBuilder();

        static int GetVarValue(string expression)
        {
            int result = 0;
            switch (expression)
            {
                case "V":
                    result = v;
                    break;
                case "W":
                    result = w;
                    break;
                case "X":
                    result = x;
                    break;
                case "Y":
                    result = y;
                    break;
                case "Z":
                    result = z;
                    break;
                default:
                    break;
            }
            return result;
        }
        static bool Check(string rule)
        {
            bool result = false;
            if (rule.Contains(">"))
            {
                string[] ops = rule.Split('>');
                result = GetValue(ops[0]) > GetValue(ops[1]);
            }
            else if (rule.Contains("<"))
            {
                string[] ops = rule.Split('<');
                result = GetValue(ops[0]) < GetValue(ops[1]);
            }
            else if (rule.Contains("="))
            {
                string[] ops = rule.Split('=');
                result = GetValue(ops[0]) == GetValue(ops[1]);
            }
            return result;
        }
        static int GetValue(string expression)
        {
            int result = 0;
            if (expression.Contains("+"))
            {
                string[] ops = expression.Split('+');
                result = GetValue(ops[0]) + GetValue(ops[1]);
            }
            else if (expression.Contains("-"))
            {
                string[] ops = expression.Split('-'); 
                if (ops[0] != "")
                {
                    result = GetValue(ops[0]) - GetValue(ops[1]);  
                }
                else
                {
                    result = -1 * GetValue(ops[1]);
                }                                              
            }
            else if (!int.TryParse(expression, out result))
            {
                result = GetVarValue(expression);
            }
            else
            {
                result = int.Parse(expression);
            }
            return result;
        }
        static void Assign(string operand1, string operand2)
        {
            switch (operand1)
            {   
                case "V":
                    v = GetValue(operand2);
                    break;
                case "W":
                    w = GetValue(operand2);
                    break;
                case "X":
                    x = GetValue(operand2);
                    break;
                case "Y":
                    y = GetValue(operand2);
                    break;
                case "Z":
                    z = GetValue(operand2);
                    break;
                default:
                    break;
            }
        }
        static void IF(string line)
        {
            if (line.Contains("THEN"))
            {
                string[] ops = line.Split(new string[] {"IF", "THEN"}, StringSplitOptions.RemoveEmptyEntries);
                if (Check(ops[0]))
                {
                    Evaluate(ops[1]);
                }                
            }
        }
        static void Evaluate(string expression)
        {
            if (expression.Contains("PRINT"))
            {
                string[] ops = expression.Split(new string[] { "PRINT" }, StringSplitOptions.RemoveEmptyEntries);
                result.Append(GetVarValue(ops[0]));
                result.Append(" ");
            }
            else if (expression.Contains("GOTO"))
            {
                string[] ops = expression.Split(new string[] { "GOTO" }, StringSplitOptions.RemoveEmptyEntries);
                index = int.Parse(ops[0]) - 1;
            }
            else if (expression.Contains("="))
            {
                 string[] ops = expression.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries);
                 Assign(ops[0], ops[1]);
            }
            else if (expression.Contains("CLS"))
            {
                result.Clear();   
            }
            else if (expression.Contains("STOP"))
            {
                flag = false;
            }
        }
        static void ExecuteLine()
        {
            if (code[index] != null)
            {
                if (code[index].Contains("IF"))
                {
                    IF(code[index]);
                }
                else
                {
                    Evaluate(code[index]);
                }
            }
            index++;
            if (flag == true && index < code.Length)
            {
                ExecuteLine();
            }         
        }
        static void ReadBBLine(string line)
        {
            if (line != "RUN")
            {
                string[] separators = { " " };
                string[] array = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                string temp = line.Replace(" ", "");

                code[int.Parse(array[0])] = temp.Remove(0, array[0].Length);                
            }
            
        }
        static void Main(string[] args)
        {
            string line = "START";

            while (line != "RUN")
	        {
                line = Console.ReadLine();
                ReadBBLine(line);
	        }

            ExecuteLine();
            string[] separators = { " " };
            string[] forPrinting = result.ToString().Split(separators, StringSplitOptions.RemoveEmptyEntries);
             
            for (int i = 0; i < forPrinting.Length; i++)
            {
                Console.WriteLine(forPrinting[i]);
            }
        }
    }
}
