using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Indices
{
    class Indeces
    {
        static int n;
        static int[] arr;
        static int cycleStart = -1;

        static List<int> sequence;

        static void Main(string[] args)
        {
            //n = 6;

            n = int.Parse(Console.ReadLine());
            arr = new int[n];
            string line = Console.ReadLine();

            //string line = "1 2 3 5 7 1";
            string[] lineParts = line.Split(' ');
            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(lineParts[i]);
            }



            sequence = new List<int>();

            ProceedArr(0);

            StringBuilder output = new StringBuilder();
            if (cycleStart!=-1)
            {
                for (int i = 0; i < sequence.Count; i++)
                {
                    if (sequence[i]!=cycleStart)
                    {
                        output.Append(sequence[i].ToString() + ' ');
                    }
                    else
                    {
                        if (i != 0)
                        {
                            output.Remove(output.Length - 1, 1);
                            output.Append('(' + sequence[i].ToString() + ' ');
                        }
                        else
                        {
                            output.Append('('+sequence[i].ToString() + ' ');
                        }
                    }

                    if (i==sequence.Count-1)
                    {
                        output.Remove(output.Length - 1, 1);
                        output.Append(")");
                    }
                }
                
            }
            else
            {
                for (int i = 0; i < sequence.Count; i++)
                {
                    if (i==sequence.Count-1)
                    {
                        output.Append(sequence[i].ToString());
                    }
                    else
                    {
                        output.Append(sequence[i].ToString() + ' ');
                    }
                }
            }

            Console.WriteLine(output.ToString());


        }

        private static void ProceedArr(int index)
        {
            sequence.Add(index);
            if (arr[index]<0 || arr[index]>n-1)
            {
                return;
            }
            if (sequence.Contains(arr[index]))
            {
                cycleStart = arr[index];
                return;
            }
            ProceedArr(arr[index]);
        }        
        
    }
}
