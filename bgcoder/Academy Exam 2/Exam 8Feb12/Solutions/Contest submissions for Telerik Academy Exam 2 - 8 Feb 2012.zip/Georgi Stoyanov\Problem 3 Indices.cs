using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());

            string input = Console.ReadLine();
            string[] strInput = input.Split(' ');

            int[] array = new int[size];

            for (int i = 0; i < size; i++)
            {
                array[i] = int.Parse(strInput[i]);
            }

            Console.WriteLine(Solve(array));
        }

        private static string Solve(int[] array)
        {
            List<int> answer = new List<int>();
            int index = 0;
            bool cycle = false;
            int cycleStart = -2;
            int cycleEnd = -1;
            
            while (index < array.Length && !cycle && index >= 0)
            {
                answer.Add(index);

                if (array[index] == index)
                {
                    cycle = true;
                    cycleStart = index;
                    cycleEnd = index;
                    continue;
                }
                if (array[index] < index)
                {
                    for (int i = 0; i < answer.Count; i++)
                    {
                        if (array[index] == answer[i])
                        {
                            cycle = true;
                            cycleStart = array[index];
                            cycleEnd = index;
                            break;
                        }
                    }

                    if (cycle)
                        break;
                }                

                index = array[index];
            }

            StringBuilder strAnswer = new StringBuilder();

            //1 2 3 5 7 8 
            //1 2 3 5 7 1
            index = 0;
            if (cycleStart == 0)
            {
                strAnswer.Append("(" + answer[index]);
                if (cycleStart == cycleEnd)
                    strAnswer.Append(")");
                else
                {
                    strAnswer.Append(" ");
                }
                index++;
            }
            while(index < answer.Count)
            {
                if (cycle)
                {
                    if (index + 1 < answer.Count && answer[index + 1] == cycleStart)
                    {
                        strAnswer.Append(answer[index] + "(");
                        index++;
                        continue;
                    }
                    if (index + 1 < answer.Count && answer[index + 1] == cycleEnd)
                    {
                        strAnswer.Append(answer[index] + " ");
                        index++;
                        strAnswer.Append(answer[index] + ")");
                        index++;
                        continue;
                    }
                    
                }
                if (index != answer.Count - 1)
                {
                    strAnswer.Append(answer[index] + " ");
                }
                else
                {
                    strAnswer.Append(answer[index]);
                }
                index++;
            }
            if (cycleStart == cycleEnd && cycleEnd != 0)
            {
                if (strAnswer[strAnswer.Length - 1] == ' ')
                    strAnswer[strAnswer.Length - 1] = ')';
                else
                    strAnswer.Append(")");
            }
            if (cycle)
            {
                if (char.IsDigit(strAnswer[strAnswer.Length - 1]))
                    strAnswer.Append(")");
            }
            return strAnswer.ToString();
        }
    }
}
