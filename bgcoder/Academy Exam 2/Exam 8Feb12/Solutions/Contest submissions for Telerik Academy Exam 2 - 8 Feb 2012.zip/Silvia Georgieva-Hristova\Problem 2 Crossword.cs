using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Crossword
{
    static int n;
    static string[] words = new string[1];
    static char[,] letters = new char[2, 1];
    static char[,] crossword = new char[1, 1];
    static bool found = false;
    static bool exists = true;
    static char[] firstCh = new char[1];
    static List<string> firstWords = new List<string>();
    static void findCrossword()
    {
        findPossibleFirstWord();
        if (firstWords.Count == 0)
        {
            exists = false;
            Console.WriteLine("NO SOLUTION!");
            return;
        }
        tryFirstWord();
    }
    static void findPossibleFirstWord()
    {
        for (int i = 0; i < 2 * n; i++)
        {
            bool first = true;
            for (int j = 0; j < n; j++)
            {
                if (!firstCh.Contains(Convert.ToChar(words[i].Substring(j, 1))))
                {
                    first = false;
                    break;
                }
            }
            if (first)
                firstWords.Add(words[i]);
        }
    }
    static void tryFirstWord()
    {
        foreach (string word in firstWords)
        {
            for (int i = 0; i < n; i++)
            {
                crossword[0, i] = word[i];
            }
            foreach (string word2 in firstWords)
            {
                if (word2[0] == crossword[0, 0])
                {
                    for (int j = 1; j < n; j++)
                    {
                        crossword[j, 0] = word2[j];
                            
                    }
                    tryRow(1);
                    return;
                }
            }
            return;
        }
    }
    static void tryRow(int rowIndex)
    {
        if (found == true)
            return;
        if (rowIndex == n)
        {
            found = true;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                    Console.Write(crossword[i, j]);
                Console.WriteLine();
            }
            return;
        }
        for (int w = 0; w<2*n;w++)
        {
            string word = words[w];
            for (int i=0; i<rowIndex;i++)
            {
                if (crossword[rowIndex,i]!=word[i])
                    return;
            }
            for (int i=rowIndex; i<n;i++)
            {
                crossword[rowIndex,i]=word[i];
            }
            tryColumn(rowIndex);
            return;
        }
    }
    static void tryColumn(int columnIndex)
    {
        if (found == true)
            return;
        for (int w = 0; w<2*n;w++)
        {
            string word = words[w];
            for (int i=0; i<columnIndex;i++)
            {
                if (crossword[i,columnIndex]!=word[i])
                    return;
            }
            for (int i=columnIndex; i<n;i++)
            {
                crossword[i,columnIndex]=word[i];
            }
            tryRow(columnIndex+1);
            return;
        }
    }
    public static void Main()
    {
        string input = Console.ReadLine();
        n = Convert.ToInt32(input);
        words = new string[2*n];
        for (int i = 0; i < 2*n; i++)
        {
            words[i] = Console.ReadLine();
        }
        Array.Sort(words);
        crossword = new char[n, n];
        firstCh = new char[2 * n];
        for (int i = 0; i < 2 * n; i++)
        {
            firstCh[i] = Convert.ToChar(words[i].Substring(0,1));
        }
        firstCh = firstCh.Distinct().ToArray();
        Array.Sort(firstCh);
        letters = new char[2 * n, n];
        for (int i = 0; i < 2 * n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                letters[i,j] = Convert.ToChar(words[i].Substring(j, 1));
            }
        }
        findCrossword();
    }
}
