using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Task1
{
    public enum States { IF, AssigningValue, GOTO, PRINT, IDLE, STOP }
    public enum Variables { V, W, X, Y, Z }

    class Line
    {
        public int LineNumber { get; private set; }
        public string LineContent { get; private set; }

        public Line(string line)
        {
            int i = 0;
            StringBuilder number = new StringBuilder();
            StringBuilder content = new StringBuilder();
            if (!string.IsNullOrEmpty(line))
            {
                while (i < line.Length && line[i] != ' ')
                {
                    number.Append(line[i]);
                    i++;
                }

                while (i < line.Length && line[i] == ' ')
                {
                    i++;
                }

                for (; i < line.Length; i++)
                {
                    content.Append(line[i]);
                }

                LineNumber = int.Parse(number.ToString());
                content.Replace(" ", string.Empty);
                LineContent = content.ToString();
            }
        }
    }

    class Code
    {
        SortedList<int, Line> sortedCodeLines = new SortedList<int, Line>();
        StringBuilder result = new StringBuilder();
        int currentLineNumber = 0;
        int V = 0, W = 0, X = 0, Y = 0, Z = 0;
        Line currentLine = null;

        public Code()
        {
        }

        public int AddLine(string line)
        {
            Line newLine = new Line(line);
            sortedCodeLines.Add(newLine.LineNumber, newLine);

            currentLineNumber = newLine.LineNumber;

            return currentLineNumber;
        }

        public bool ExecuteLine(int lineNumber)
        {
            bool isFirstCommand = true;
            States currentState = States.IDLE;
            Variables currentVariable = Variables.V;

            if (sortedCodeLines.ContainsKey(lineNumber))
            {
                sortedCodeLines.TryGetValue(lineNumber, out currentLine);
            }

            if (currentLine == null)
            {
                return false;
            }

            bool isFirstTime = false;

            for (int i = 0; i < currentLine.LineContent.Length; i++)
            {
                isFirstTime = false;
                switch (currentState)
                {
                    #region IDLE

                    case States.IDLE:
                        {
                            isFirstTime = true;
                            if (i + 1 < currentLine.LineContent.Length && currentLine.LineContent[i] == 'I' && currentLine.LineContent[i + 1] == 'F')
                            {
                                currentState = States.IF;
                                i += 1;
                                break;
                            }

                            if (currentLine.LineContent[i] == 'V' || currentLine.LineContent[i] == 'W' || currentLine.LineContent[i] == 'X' || currentLine.LineContent[i] == 'Y' || currentLine.LineContent[i] == 'Z')
                            {
                                currentState = States.AssigningValue;
                                switch (currentLine.LineContent[i])
                                {
                                    case 'V':
                                        {
                                            currentVariable = Variables.V;
                                        }
                                        break;
                                    case 'W':
                                        {
                                            currentVariable = Variables.W;
                                        }
                                        break;
                                    case 'X':
                                        {
                                            currentVariable = Variables.X;
                                        }
                                        break;
                                    case 'Y':
                                        {
                                            currentVariable = Variables.Y;
                                        }
                                        break;
                                    case 'Z':
                                        {
                                            currentVariable = Variables.Z;
                                        }
                                        break;
                                }

                                i++;

                                break;
                            }

                            if (i + 3 < currentLine.LineContent.Length && currentLine.LineContent[i] == 'G' && currentLine.LineContent[i + 1] == 'O' && currentLine.LineContent[i + 2] == 'T' && currentLine.LineContent[i + 3] == 'O')
                            {
                                currentState = States.GOTO;
                                i += 3;
                                break;
                            }

                            if (i + 2 < currentLine.LineContent.Length && currentLine.LineContent[i] == 'C' && currentLine.LineContent[i + 1] == 'L' && currentLine.LineContent[i + 2] == 'S')
                            {
                                currentState = States.IDLE;
                                result.Clear();
                                isFirstTime = false;
                                break;
                            }

                            if (i + 4 < currentLine.LineContent.Length && currentLine.LineContent[i] == 'P' && currentLine.LineContent[i + 1] == 'R' && currentLine.LineContent[i + 2] == 'I' && currentLine.LineContent[i + 3] == 'N' && currentLine.LineContent[i + 4] == 'T')
                            {
                                currentState = States.PRINT;
                                i += 4;
                                break;
                            }


                            if (i + 3 < currentLine.LineContent.Length && currentLine.LineContent[i] == 'S' && currentLine.LineContent[i + 1] == 'T' && currentLine.LineContent[i + 2] == 'O' && currentLine.LineContent[i + 3] == 'P')
                            {
                                currentState = States.STOP;
                                return true;
                            }
                        }
                        break;

                    #endregion

                    #region AssigningValue

                    case States.AssigningValue:
                        {
                            StringBuilder firstVariableValue = new StringBuilder();
                            StringBuilder secondVariableValue = new StringBuilder();
                            char operand = 'N';
                            bool IsFirstVaribleIsNumber = false;
                            bool IsSecondVariableIsNumber = false;

                            AssingFirstVariableForAssigning(currentLine, ref i, firstVariableValue, ref IsFirstVaribleIsNumber);

                            operand = AssingSecondVariableForAssingning(currentLine, ref i, secondVariableValue, ref IsSecondVariableIsNumber);

                            FindResultForAssing(currentVariable, firstVariableValue, secondVariableValue, operand);
                        }
                        break;

                    #endregion

                    #region GOTO

                    case States.GOTO:
                        {
                            StringBuilder number = new StringBuilder();
                            while (i < currentLine.LineContent.Length && currentLine.LineContent[i] >= '0' && currentLine.LineContent[i] <= '9')
                            {
                                number.Append(currentLine.LineContent[i]);
                                i++;
                            }
                            lineNumber = int.Parse(number.ToString());
                            currentLine = sortedCodeLines.Values[sortedCodeLines.IndexOfKey(lineNumber)];
                            isFirstTime = true;
                            i = -1;
                            currentState = States.IDLE;
                        }
                        break;

                    #endregion

                    #region IF

                    case States.IF:
                        {
                            isFirstTime = true;
                            StringBuilder firstVariableValue = new StringBuilder();
                            StringBuilder secondVariableValue = new StringBuilder();
                            char operand = 'N';
                            bool IsFirstVaribleIsNumber = false;
                            bool IsSecondVariableIsNumber = false;

                            AssingFirstVariableForAssigning(currentLine, ref i, firstVariableValue, ref IsFirstVaribleIsNumber);

                            operand = AssingSecondVariableForAssingning(currentLine, ref i, secondVariableValue, ref IsSecondVariableIsNumber);

                            bool IfResult = FindResultForIf(firstVariableValue, secondVariableValue, operand);
                            if (IfResult)
                            {
                                currentState = States.IDLE;
                                continue;
                            }
                            else
                            {
                                currentLine = sortedCodeLines.Values[sortedCodeLines.IndexOfKey(currentLine.LineNumber) + 1];
                                i = -1;
                                currentState = States.IDLE;
                            }
                        }
                        break;

                    #endregion

                    #region PRINT

                    case States.PRINT:
                        {
                            switch (currentLine.LineContent[i])
                            {
                                case 'V':
                                    {
                                        result.AppendLine(V.ToString());
                                    }
                                    break;
                                case 'W':
                                    {
                                        result.AppendLine(W.ToString());
                                    }
                                    break;
                                case 'X':
                                    {
                                        result.AppendLine(X.ToString());
                                    }
                                    break;
                                case 'Y':
                                    {
                                        result.AppendLine(Y.ToString());
                                    }
                                    break;
                                case 'Z':
                                    {
                                        result.AppendLine(Z.ToString());
                                    }
                                    break;
                            }
                        }
                        break;

                    #endregion
                }

                if (currentLine.LineNumber < sortedCodeLines.Keys.Max() && !isFirstTime)
                {
                    currentLine = sortedCodeLines.Values[sortedCodeLines.IndexOfKey(currentLine.LineNumber) + 1];
                    i = -1;
                    currentState = States.IDLE;
                }
            }

            return false;
        }

        public void PrintResult()
        {
            Console.WriteLine(result.ToString());
        }

        private static bool FindResultForIf(StringBuilder firstVariableValue, StringBuilder secondVariableValue, char operand)
        {
            switch (operand)
            {
                case '<':
                    {
                        return int.Parse(firstVariableValue.ToString()) < int.Parse(secondVariableValue.ToString());
                    }
                case '>':
                    {
                        return int.Parse(firstVariableValue.ToString()) > int.Parse(secondVariableValue.ToString());
                    }
                case '=':
                    {
                        return int.Parse(firstVariableValue.ToString()) == int.Parse(secondVariableValue.ToString());
                    }
                default:
                    {
                        throw new Exception();
                    }
            }
        }

        private void FindResultForAssing(Variables currentVariable, StringBuilder firstVariableValue, StringBuilder secondVariableValue, char operand)
        {
            switch (currentVariable)
            {
                case Variables.V:
                    {
                        Assing(ref V, firstVariableValue, secondVariableValue, operand);
                    }
                    break;
                case Variables.W:
                    {
                        Assing(ref W, firstVariableValue, secondVariableValue, operand);
                    }
                    break;
                case Variables.X:
                    {
                        Assing(ref X, firstVariableValue, secondVariableValue, operand);
                    }
                    break;
                case Variables.Y:
                    {
                        Assing(ref Y, firstVariableValue, secondVariableValue, operand);
                    }
                    break;
                case Variables.Z:
                    {
                        Assing(ref Z, firstVariableValue, secondVariableValue, operand);
                    }
                    break;
            }
        }

        private void Assing(ref int Variable, StringBuilder firstVariableValue, StringBuilder secondVariableValue, char operand)
        {
            if (secondVariableValue.Length == 0)
            {
                Variable = int.Parse(firstVariableValue.ToString());
            }

            if (operand == 'N')
            {
                return;
            }

            if (operand == '-')
            {
                Variable = int.Parse(firstVariableValue.ToString()) - int.Parse(secondVariableValue.ToString());
            }
            if (operand == '+')
            {
                Variable = int.Parse(firstVariableValue.ToString()) + int.Parse(secondVariableValue.ToString());
            }
        }

        private void AssingFirstVariableForAssigning(Line currentLine, ref int i, StringBuilder firstVariableValue, ref bool IsFirstVaribleIsNumber)
        {
            if (currentLine.LineContent[i] == '-' || currentLine.LineContent[i] == '+')
            {
                firstVariableValue.Append(currentLine.LineContent[i]);
                i++;
            }

            while (i < currentLine.LineContent.Length && currentLine.LineContent[i] >= '0' && currentLine.LineContent[i] <= '9')
            {
                IsFirstVaribleIsNumber = true;
                firstVariableValue.Append(currentLine.LineContent[i]);
                i++;
            }

            if (!IsFirstVaribleIsNumber)
            {
                switch (currentLine.LineContent[i])
                {
                    case 'V':
                        {
                            firstVariableValue.Append(V);
                            i++;
                        }
                        break;
                    case 'W':
                        {
                            firstVariableValue.Append(W);
                            i++;
                        }
                        break;
                    case 'X':
                        {
                            firstVariableValue.Append(X);
                            i++;
                        }
                        break;
                    case 'Y':
                        {
                            firstVariableValue.Append(Y);
                            i++;
                        }
                        break;
                    case 'Z':
                        {
                            firstVariableValue.Append(Z);
                            i++;
                        }
                        break;
                }
            }
        }

        private char AssingSecondVariableForAssingning(Line currentLine, ref int i, StringBuilder secondVariableValue, ref bool IsSecondVariableIsNumber)
        {
            char operand = 'N';

            if (i < currentLine.LineContent.Length)
            {
                if (currentLine.LineContent[i] == '-' || currentLine.LineContent[i] == '+' || currentLine.LineContent[i] == '>' || currentLine.LineContent[i] == '<' || currentLine.LineContent[i] == '=')
                {
                    operand = currentLine.LineContent[i];
                    i++;
                }

                if (currentLine.LineContent[i] == '-' || currentLine.LineContent[i] == '+')
                {
                    secondVariableValue.Append(currentLine.LineContent[i]);
                    i++;
                }

                while (i < currentLine.LineContent.Length && currentLine.LineContent[i] >= '0' && currentLine.LineContent[i] <= '9')
                {
                    IsSecondVariableIsNumber = true;
                    secondVariableValue.Append(currentLine.LineContent[i]);
                    i++;
                }

                if (!IsSecondVariableIsNumber)
                {
                    switch (currentLine.LineContent[i])
                    {
                        case 'V':
                            {
                                secondVariableValue.Append(V);
                                i++;
                            }
                            break;
                        case 'W':
                            {
                                secondVariableValue.Append(W);
                                i++;
                            }
                            break;
                        case 'X':
                            {
                                secondVariableValue.Append(X);
                                i++;
                            }
                            break;
                        case 'Y':
                            {
                                secondVariableValue.Append(Y);
                                i++;
                            }
                            break;
                        case 'Z':
                            {
                                secondVariableValue.Append(Z);
                                i++;
                            }
                            break;
                    }
                }
            }
            return operand;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string line;
            Code code = new Code();
            int lineNumber = -1;

            do
            {
                line = Console.ReadLine();
                if (line[0] == 'R' && line[1] == 'U' && line[2] == 'N')
                {
                    break;
                }
                if (lineNumber == -1)
                {
                    lineNumber = code.AddLine(line);
                }
                else
                {
                    code.AddLine(line);
                }
            } while (true);

            code.ExecuteLine(lineNumber);

            code.PrintResult();
        }
    }
}