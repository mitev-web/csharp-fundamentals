using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2
{
    class Program
    {
        static string[] word;
        static string[] result;
        static string output = "";
        static int range;
        static bool flag = true;
        
        static void SaveResult(string[] tempResult)
        {
            StringBuilder temp = new StringBuilder();
            for (int i = 0; i < tempResult.Length; i++)
            {
                temp.Append(tempResult[i]);
            }
            if (temp.ToString().CompareTo(output) < 0 || output == "")
            {
                output = temp.ToString();
            }
        }
        static bool CheckWord(string wordToCheck)
        {
            bool result = false;
            for (int i = 0; i < word.Length; i++)
            {
                if (wordToCheck == word[i])
                {
                    result = true;
                }
            }
            return result;
        }

        static string BuildWord(int column, string[] array)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < array.Length; i++)
            {
                result.Append(array[i].Substring(column, 1));
            }
            return result.ToString();
        }

        static bool CheckCrossWord(string[] array)
        {
            bool result = true;
            for (int i = 0; i < array.Length; i++)
            {
                string wordToCheck = BuildWord(i, array);
                result = result & CheckWord(wordToCheck);
            }
            return result;
        }

        static void BuildCrossWord(int level)
        {
            if (flag == false)
            {
                return;
            }
            if (level > range - 1 && CheckCrossWord(result))
            {
                SaveResult(result);
                flag = false;
                return;                
            }
            else if (level > range - 1)
            {
                return;
            }
            
            for (int i = 0; i < 2 * range; i++)
            {
                result[level] = word[i];
                BuildCrossWord(level + 1);
                result[level] = null;
            }
        }

        static void Print()
        {
            if (output == "")
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                for (int i = 0; i < range * range; i++)
                {
                    if (i % range == 0 && i !=0)
                    {
                        Console.WriteLine();
                    }
                    Console.Write(output[i]);
                }
            }
        }
        static void Main(string[] args)
        {
            range = int.Parse(Console.ReadLine());

            word = new string[2 * range];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = Console.ReadLine();
            }

            Array.Sort(word);
            result = new string[range];

            BuildCrossWord(0);
            Print();

            Console.WriteLine();
        }
    }
}
