using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;


namespace AcademyTasks
{
    class Program
    {
        static void Main(string[] args)
        {

            string example = Console.ReadLine();
            char[] NumberSeperators = new char[] { ' ', ',' };
            string[] numbers = example.Split(NumberSeperators, StringSplitOptions.RemoveEmptyEntries);
            float[] num = new float[numbers.Length];
            for (int x = 0; x < numbers.Length; x++)
            {
                num[x] = Convert.ToSingle(numbers[x], CultureInfo.InvariantCulture);

            }

            float variety = float.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            int minsolved = num.Length;
            
            int i = 0;
            int k = 0;
            int solve = 2;
            int sumSolve = 0;
            int t = 3;
            int defaultSolve = 0;
            for (; i < numbers.Length; i++)
            {
                k = i + 1;
                for (; k < numbers.Length; k++)
                {
                    if (num[i] > num[k] || num[i] == num[k])
                    {
                        if (variety == num[i] - num[k])
                        {
                            sumSolve = solve / 2 + 1;
                            if (sumSolve < minsolved)
                            {
                                minsolved = sumSolve;
                            }
                        }
                        else
                        {
                            solve++;
                        }
                    }
                    if (num[i] < num[k])
                    {
                        if (variety == num[k] - num[i])
                        {
                            sumSolve = solve / 2 + 1;
                            if (sumSolve < minsolved)
                            {
                                minsolved = sumSolve;
                            }
                        }
                        else
                        {
                            solve++;
                        }
                    }

                }
                if ((i + 1) % 2 != 0)
                {
                    solve = i + t;
                    defaultSolve = solve;
                    t--;
                }
                else
                {
                    solve = defaultSolve;
                }
            }
            Console.WriteLine(minsolved);
        }
    }
}
