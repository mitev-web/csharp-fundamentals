using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
   
namespace ex2
{
    class Program
    {
        static int BigMin = 0;
        static int variety = 0;
        static bool varEnded = false;
   
        static void Start(int[] num, int x, int cnt, int max, int min)
        {
            cnt++;
            if (x >= num.Length-1)
            {
                if (BigMin == 0) BigMin = cnt;
                else if (cnt < BigMin) { BigMin = cnt; return; }
                return;
            }
            else
            {           
                max += num[x];
                min -= num[x];
                if (!(min == max))
                {
                    if (min >= variety && max >= variety)
                    {
                        Console.WriteLine(cnt);
                        varEnded = true;
                        return;
                        //game over bla bla = false;
                    }
                }
            }
               
            if (!(x + 2 >= num.Length))
            {
                if (num[x]+2 >= num[x + 2])
                {
                    Start(num, x + 2, cnt, max, min);
                }
            }
            if (!(x + 1 >= num.Length))
            {
                if (num[x]+2>=num[x+1])
                {
                    Start(num, x + 1, cnt, max, min);
                }
            }
            return;
        }
   
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            char[] separator = { ' ', ',' };
            string[] tmpNums = line.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] numbers = new int[tmpNums.Length];
            for (int i = 0; i < tmpNums.Length; i++)
            {
                numbers[i] = int.Parse(tmpNums[i]);
            }
            variety = int.Parse(Console.ReadLine());
   
            int max = 0;
            int min = numbers[0] * 2;
               
            //Start(numbers, 0, 0, max, min);
   
            //if (!varEnded) Console.WriteLine(BigMin);
   
            Console.WriteLine(tmpNums.Length);
        }
    }
}