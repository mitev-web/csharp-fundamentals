using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
 
 
 
class AcademyTask
{
    static List<int> pleasantness = new List<int>();
    static int variety;
    static int finalResult = 0;
 
    static void Main(string[] args)
    {
        string line;
        string[] lineSplited;
        char[] spliters = { ' ', ',', '\n' };
 
        int difMaxMin;
 
        int count;
 
        //StreamReader reader = new StreamReader("test3.txt");
 
        line = Console.ReadLine();
 
        lineSplited = line.Split(spliters, StringSplitOptions.RemoveEmptyEntries);
 
        for (int i = 0; i < lineSplited.Length; i++)
        {
            pleasantness.Add(int.Parse(lineSplited[i]));
        }
 
        int currentMaxPles = pleasantness[0];
        int currentMinPles = pleasantness[0];
        finalResult = pleasantness.Count;
 
        line = Console.ReadLine();
 
        variety = int.Parse(line);
 
 
 
        FindPleasantness(currentMaxPles, currentMinPles, 1, 0);
 
        Console.WriteLine(finalResult);
 
     
    }
 
    static void FindPleasantness(int currentMaxPles, int currentMinPles,int count, int indx)
    {
        if (indx >= pleasantness.Count)
        {
            return;
        }
         
        if (pleasantness[indx] > currentMaxPles)
        {
            currentMaxPles = pleasantness[indx];
        }
 
        if (pleasantness[indx] < currentMinPles)
        {
            currentMinPles = pleasantness[indx];
        }
 
        if ((currentMaxPles - currentMinPles) >= variety)
        {
            if (count < finalResult)
            {
                finalResult = count;
            }
        }
 
        FindPleasantness(currentMaxPles, currentMinPles, count + 1, indx + 1);
        FindPleasantness(currentMaxPles, currentMinPles, count + 1, indx + 2);
    }
}