using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword
{
    class Crossword
    {
        public char[,] crossword;

        public Crossword(int size)
        {
            crossword = new char[size, size + 1];
        }

        public Crossword(Crossword c)
        {
            crossword = new char[c.crossword.GetLength(0),c.crossword.GetLength(1)];

            for (int i = 0; i < crossword.GetLength(0); i++)
            {
                for (int j = 0; j < crossword.GetLength(1); j++)
                {
                    crossword[i, j] = c.crossword[i, j];
                }
            }
        }

        public void FillRow(string word, int row)
        {
            for (int i = 0; i < word.Length; i++)
            {
                crossword[row, i] = word[i];
            }
            crossword[row, word.Length] = '\n';
        }

        public void FillColumn(string word, int column)
        {
            for (int i = 0; i < word.Length; i++)
            {
                crossword[i, column] = word[i];
            }
        }

        public bool checkColumn(string word, int column)
        {
            for (int i = 0; i < crossword.GetLength(0); i++)
            {
                if (word[i] != crossword[i,column])
                {
                    return false;
                }
            }
            return true;
        }

        public int CompareTO(Crossword compareTo)
        {
            for (int i = 0; i < crossword.GetLength(0); i++)
            {
                for (int j = 0; j < crossword.GetLength(1); j++)
                {
                    if (this.crossword[i, j] != compareTo.crossword[i, j])
                    {
                        return this.crossword[i, j] - compareTo.crossword[i, j];
                    }
                }
            }

            return 0;
        }
    }

    class Program
    {        
        static string[] words;
        static List<Crossword> solutions = new List<Crossword>();

        static void printLowestSolution()
        {
            Crossword lowest = solutions[0];

            foreach (Crossword c in solutions)
            {
                if (lowest.CompareTO(c) > 0)
                {
                    lowest = c;
                }
            }

            foreach (char ch in lowest.crossword)
            {
                Console.Write(ch);
            }
        }

        static void CheckCrossword(Crossword c)
        {
            bool valid;

            for (int column = 0; column < words.Length / 2; column++)
            {
                valid = false;

                for (int i = 0; i < words.Length; i++)
                {
                    if (c.checkColumn(words[i],column))
                    {
                        valid = true;
                        break;
                    }
                }

                if (!valid)
                {
                    break;
                }
                else
                {
                    if (column == words.Length/2 - 1)
                    {
                        solutions.Add(new Crossword(c));
                    }
                }
            }
        }

        static void FindWords(Crossword cross, int matchingIndex)
        {
            if (matchingIndex == words.Length / 2)
            {
                CheckCrossword(cross);
                return;
            }           
            for (int i = 0; i < words.Length; i++)
            {
                if (cross.crossword[matchingIndex, 0] == words[i][0])
                {
                    cross.FillRow(words[i], matchingIndex);
                    FindWords(cross, matchingIndex + 1);
                }
            }
        }

        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            words = new string[2 * size];
            for (int i = 0; i < 2 * size; i++)
            {
                words[i] = Console.ReadLine();
            }

            Crossword c = new Crossword(size);

            for (int i = 0; i < words.Length; i++)
            {
                c.FillColumn(words[i], 0);
                FindWords(c, 0);
            }

            if (solutions.Count == 0)
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                printLowestSolution();
            }
        }
    }
}
