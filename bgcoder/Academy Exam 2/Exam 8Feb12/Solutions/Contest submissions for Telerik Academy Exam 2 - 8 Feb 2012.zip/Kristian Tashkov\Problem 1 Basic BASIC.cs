using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Basic_BASIC
{
    class Line
    {
        public static int[] indexes=new int[100000];
        public int id, next;
        public string operators;
        public Line(string line="",int next=0)
        {
            int i = 0;
            while (line[i] == ' ') i++;
            StringBuilder sb = new StringBuilder();
            while (i < line.Length && line[i] >= '0' && line[i] <= '9')
            {
                sb.Append(line[i]);
                i++;
            }
            this.id = int.Parse(sb.ToString());
            this.operators = line.Substring(i);
            this.next = next;
        }
        public char this[int index]
        {
            get
            {
                return operators[index];
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Line> lines=new List<Line>();
            int[] variables = new int[100];
            //StreamReader sr = new StreamReader("input.txt");
            string line=Console.ReadLine();
            //string line = sr.ReadLine();
            while(line!="RUN")
            {
                lines.Add(new Line(line,lines.Count+1));
                Line.indexes[lines.Last().id] = lines.Count - 1;
                line=Console.ReadLine();
                //line = sr.ReadLine();
            }
            int current = 0;
            StringBuilder output= new StringBuilder();
            bool shouldStop = false;
            while (current < lines.Count)
            {
                //Console.WriteLine(lines[current].operators+"   " + lines[current].next);
                //for (int i = 0; i < 5; i++)
                //    Console.Write(variables[i] + " ");
                //Console.WriteLine();
                //Console.ReadKey();
                bool wasInGOTO = false;
                for (int i = 0; i < lines[current].operators.Length; i++)
                {
                    if (lines[current][i] == ' ') continue;
                    if (lines[current][i] >= 'V' && lines[current][i] <= 'Z')
                    {
                        int which = lines[current][i] - 'V';
                        i++;
                        while (lines[current][i] == ' ' || lines[current][i] == '=') i++;
                        int first = 0, second = 0, operation = 0;
                        if (lines[current][i] >= 'V' && lines[current][i] <= 'Z')
                        {
                            first = variables[lines[current][i] - 'V'];
                            i++;
                        }
                        else
                        {
                            bool isPositive = true;
                            StringBuilder sb = new StringBuilder();
                            if (lines[current][i] == '-')
                            {
                                isPositive = false;
                                i++;
                            }
                            while (i < lines[current].operators.Length && lines[current][i] >= '0' && lines[current][i] <= '9')
                            {
                                sb.Append(lines[current][i]);
                                i++;
                            }
                            //Console.WriteLine(sb.ToString());
                            first = int.Parse(sb.ToString());
                            if (!isPositive) first *= -1;
                        }
                        while (i < lines[current].operators.Length && lines[current][i] == ' ') i++;
                        if (i >= lines[current].operators.Length)
                        {
                            variables[which] = first;
                            break;
                        }
                        if (lines[current][i] == '-') operation = -1;
                        else operation = 1;
                        i++;
                        while (lines[current][i] == ' ') i++;
                        if (lines[current][i] >= 'V' && lines[current][i] <= 'Z')
                        {
                            second = variables[lines[current][i] - 'V'];
                        }
                        else
                        {
                            StringBuilder sb = new StringBuilder();
                            while (i < lines[current].operators.Length && ((lines[current][i] >= '0' && lines[current][i] <= '9') || lines[current][i] == '-'))
                            {
                                sb.Append(lines[current][i]);
                                i++;
                            }
                            second = int.Parse(sb.ToString());
                        }
                        if (operation == -1) variables[which] = first - second;
                        else variables[which] = first + second;
                        break;
                    }
                    if (lines[current][i] == 'I')
                    {
                        int first = 0, second = 0;
                        int operation = -2;
                        i+=2;
                        while (lines[current][i] == ' ') i++;
                        if (lines[current][i] >= 'V' && lines[current][i] <= 'Z')
                        {
                            first = variables[lines[current][i] - 'V'];
                            i++;
                        }
                        else
                        {
                            StringBuilder sb = new StringBuilder();
                            while (i < lines[current].operators.Length && ((lines[current][i] >= '0' && lines[current][i] <= '9') || lines[current][i]=='-'))
                            {
                                sb.Append(lines[current][i]);
                                i++;
                            }
                            first = int.Parse(sb.ToString());
                        }
                        while (lines[current][i] == ' ') i++;
                        if (lines[current][i] == '>') operation = 1;
                        if (lines[current][i] == '<') operation = -1;
                        if (lines[current][i] == '=') operation = 0;
                        i++;
                        while (lines[current][i] == ' ') i++;
                        if (lines[current][i] >= 'V' && lines[current][i] <= 'Z')
                        {
                            second = variables[lines[current][i] - 'V'];
                        }
                        else
                        {
                            StringBuilder sb = new StringBuilder();
                            while (i < lines[current].operators.Length && ((lines[current][i] >= '0' && lines[current][i] <= '9') || lines[current][i] == '-'))
                            {
                                sb.Append(lines[current][i]);
                                i++;
                            }
                            second = int.Parse(sb.ToString());
                        }
                        if (operation == 0)
                        {
                            if (first != second) break;
                        }
                        if (operation == 1)
                        {
                            if (first <= second) break;
                        }
                        if (operation == -1)
                        {
                            if (first >= second) break;
                        }
                        continue;
                    }
                    if (lines[current][i] == 'G')
                    {
                        while (lines[current][i] < '0' || lines[current][i] > '9') i++;
                        StringBuilder sb = new StringBuilder();
                        while (i < lines[current].operators.Length && lines[current][i] >= '0' && lines[current][i] <= '9')
                        {
                            sb.Append(lines[current][i]);
                            i++;
                        }
                        current = Line.indexes[int.Parse(sb.ToString())];
                        wasInGOTO = true;
                        break;
                    }
                    if (lines[current][i] == 'P')
                    {
                        int number;
                        i+=5;
                        while (lines[current][i] == ' ') i++;
                        if (lines[current][i] >= 'V' && lines[current][i] <= 'Z')
                        {
                            number = variables[lines[current][i] - 'V'];
                            i++;
                        }
                        else
                        {
                            StringBuilder sb = new StringBuilder();
                            while (i < lines[current].operators.Length && ((lines[current][i] >= '0' && lines[current][i] <= '9') || lines[current][i]=='-'))
                            {
                                sb.Append(lines[current][i]);
                                i++;
                            }
                            number = int.Parse(sb.ToString());
                        }
                        output.Append(number+Environment.NewLine);
                        break;
                    }
                    if (lines[current][i] == 'C')
                    {
                        output.Clear();
                        break;
                    }
                    if (lines[current][i] == 'S')
                    {
                        shouldStop = true;
                        break;
                    }
                }
                if (shouldStop) break;
                if(!wasInGOTO) current = lines[current].next;
            }
            Console.Write(output.ToString());
        }
    }
}
