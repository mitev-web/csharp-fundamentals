using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _04_Cuboid
{
    class Program
    {
        static int width;
        static int height;
        static int depth;
        static char[, ,] cube;

        static int bombCount;
        static int[][] bombs;

        static int[] colors = new int[26];

        private static void Read(StreamReader reader)
        {
            string line = reader.ReadLine();
            string[] dimensions = line.Split(' ');

            width = int.Parse(dimensions[0]);
            height = int.Parse(dimensions[1]);
            depth = int.Parse(dimensions[2]);
            cube = new char[width, height, depth];

            for(int h = 0; h < height; h++)
            {
                line = reader.ReadLine();
                string[] letters = line.Split();

                for(int d = 0; d < depth; d++)
                    for(int w = 0; w < width; w++)
                        cube[w, h, d] = letters[d][w];
            }

            bombCount = int.Parse(reader.ReadLine());
            bombs = new int[bombCount][];

            for(int i = 0; i < bombCount; i++)
            {
                line = reader.ReadLine();
                string[] bombCoord = line.Split(' ');

                bombs[i] = new int[4];

                bombs[i][0] = int.Parse(bombCoord[0]); // w
                bombs[i][1] = int.Parse(bombCoord[1]); // h
                bombs[i][2] = int.Parse(bombCoord[2]); // d
                bombs[i][3] = int.Parse(bombCoord[3]); // p

            }
        }

        static double CalcDistance(int w, int h, int d, int bombW, int bombH, int bombD)
        {
            double result = Math.Sqrt(Math.Pow(w - bombW, 2) + Math.Pow(h - bombH, 2) + Math.Pow(d - bombD, 2));

            return result;
        }

        static void NormalizeCube()
        {
            for(int h = height-2; h >= 0; h--)
                for(int w = 0; w < width; w++)
                    for(int d = 0; d < depth; d++)
                        if(cube[w, h, d] == ' ' && cube[w, h+1, d] != ' ')
                        {
                            cube[w, h, d] = cube[w, h + 1, d];
                            cube[w, h + 1, d] = ' ';
                        }
        }

        static int BombAt(int bombW, int bombH, int bombD, int bombPower)
        {
            int count = 0;

            if(bombPower <= 0)
                return 0;

            for(int w = 0; w < width; w++)
                for(int h = 0; h < height; h++)
                    for(int d = 0; d < depth; d++)
                        if(cube[w, h, d] != ' ' && CalcDistance(w, h, d, bombW, bombH, bombD) <= (double)bombPower)
                        {
                            char color = cube[w, h, d];
                            colors[(int)color - 'A']++;
                            
                            cube[w, h, d] = ' ';
                            count++;
                        }

            return count;
        }


        static void Main(string[] args)
        {
            Read(new StreamReader(Console.OpenStandardInput()));
            //Read(new StreamReader("c:/4.txt"));

            int count = 0;

            for(int i = 0; i < bombCount; i++)
            {
                count += BombAt(bombs[i][0], bombs[i][1], bombs[i][2], bombs[i][3]);
                for(int j = 0; j < height; j++) 
                NormalizeCube();
            }

            Console.WriteLine(count);

            for(int i = 0; i < 26; i++)
                if(colors[i] != 0)
                    Console.WriteLine("{0} {1}", (char)(i + 'A'), colors[i]);
        }
    }
}
