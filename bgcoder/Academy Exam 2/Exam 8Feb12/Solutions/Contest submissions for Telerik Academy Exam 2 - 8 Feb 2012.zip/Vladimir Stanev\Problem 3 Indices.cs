using System;
using System.Linq;
using System.Text;

namespace _02._03_Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            // int N = 6;
            int[] Arr = new int[N];
            bool[] repeated = new bool[200001];
            bool okRepeated = false;

            string line = Console.ReadLine();
            // string line="1 2 3 5 7 1";

            int beginDigit = 0;
            int positionNextSpace = line.IndexOf(" ", 0);
            int index=0;
            int firstRepeatedPosition = 0;

            while (positionNextSpace >= 0)
            {
                Arr[index] = int.Parse(line.Substring(beginDigit,positionNextSpace-beginDigit));
                if (repeated[Arr[index]] && !okRepeated) { okRepeated = true; firstRepeatedPosition = index; }
                repeated[Arr[index]] = true;
                index++;
                beginDigit = positionNextSpace + 1;
                positionNextSpace = line.IndexOf(" ", positionNextSpace + 1);
                if (positionNextSpace==-1)
                {
                    Arr[index] = int.Parse(line.Substring(beginDigit));
                    if (repeated[Arr[index]] && !okRepeated) { okRepeated = true; firstRepeatedPosition = index; }
                    repeated[Arr[index]] = true;

                }
            }

            // Console.WriteLine("f {0}", firstRepeatedPosition);
            // Console.WriteLine(okRepeated);
           
            index = 0;
            Console.Write("{0}", index);

            if (okRepeated)
            {
                index=Arr[index];
                Console.Write("({0}",index);

                while (index!=firstRepeatedPosition)
	            {   
                    
                    index = Arr[index];
                    Console.Write(" {0}", index);    
	            }
                Console.WriteLine(")\n");
            }

            index = Arr[0];
            if (!okRepeated)
            {
                while (index<N)
                {
                    Console.Write(" {0}", index);
                    index = Arr[index];
                }
                Console.WriteLine("\n");
            }


            
        }
    }
}
