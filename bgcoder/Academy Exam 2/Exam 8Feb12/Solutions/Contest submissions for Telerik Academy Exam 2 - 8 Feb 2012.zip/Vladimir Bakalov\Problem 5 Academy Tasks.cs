using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestProject2
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputString = Console.ReadLine();
            int variety = int.Parse(Console.ReadLine());
            List<int> pleasantness = new List<int>();
            char[] separators = {',', ' '};
            string[] splitted = inputString.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < splitted.Length; i++)
            {
                pleasantness.Add(int.Parse(splitted[i]));
            }
            bool skipped = false;
            int counter = 0;
            List<int> solved = new List<int>();
            for (int i = 0; i < pleasantness.Count; i++)
            {
                if(solved.Count > 0)
                if (solved.Max() - solved.Min() >= variety)
                {
                    if (skipped == true)
                    {
                        break;
                    }
                    skipped = true;
                }
                if (skipped == true)
                    continue;
                else
                {
                    solved.Add(pleasantness[i]);
                    counter++;
                }
            }
            if (solved.Count == 1)
                Console.WriteLine(1);
            else if (solved.Count == 2)
                Console.WriteLine(2);
            else
                Console.WriteLine(counter - 1);
            
        }
    }
}
