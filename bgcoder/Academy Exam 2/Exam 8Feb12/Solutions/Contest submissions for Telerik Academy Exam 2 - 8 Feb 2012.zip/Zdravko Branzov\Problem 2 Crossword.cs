using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword
{
    class Program
    {
        static List<string> matrix = new List<string>();
        static void Main(string[] args)
        {
           // List<string> input = new List<string> { "FIRE", "ACID", "CENG", "EDGE", "FACE", "ICED", "RING", "CERN" };
            int n = int.Parse(Console.ReadLine());
            List<string> input = new List<string>();
            for (int g = 0; g < n * 2; g++)
            { 
                input.Add(Console.ReadLine());
            }
           // List<string> da = input.FindAll(p => p.StartsWith("F"));
            input.Sort();

            for (int i = 0; i < input.Count; i++)
            {
               
                matrix.Clear();
                matrix.Add(input[i]); //dobavqm parviq elem glavanata duma


                for (int j =0; j < n; j++)        //za vsqka bukva dobawqm duma
                {
                    string glavnaDuma = matrix[0];                  //vzimam glavnata duma
                    string bukva = glavnaDuma[j].ToString();        // vzimam po edna bukva ot glavnata duma

                    List<string> startWith = input.FindAll(p => p.StartsWith(bukva));  //otsqvam lista s dumi po4va6ti s bukvata
                    if (startWith.Count != 0)
                    {
                        startWith.Sort();
                        for (int word = 0; word < startWith.Count; word++)  // za vsqka opciq dobawqm duma
                        {

                            
                                matrix.Add(startWith[word]);         //dobavqm duma za neq
                                // continue;        //////?????????????????
                          
                            
                            if (matrix.Count == j+2)
                            {
                                break;
                            }
                        }
                        
                    }
                    else
                    {
                        break;
                    }
                             

                    
                }
                if (matrix.Count == n + 1)
                {
                    StringBuilder checkWord = new StringBuilder();
                    for (int h = 1; h < matrix.Count; h++)
                    {
                        string duma = matrix[h];
                        checkWord.Append(duma[1]);
                    }

                    if (input.Contains(checkWord.ToString()))
                    {
                        for (int d = 1; d < matrix.Count; d++)
                        {
                            Console.WriteLine(matrix[d]);
                        }
                        break;

                    }
                   
                    

                }
                if (i == input.Count - 1)
                {
                    Console.WriteLine("NO SOLUTION!");
                }
                

               
            }
            
        }
    }
}
