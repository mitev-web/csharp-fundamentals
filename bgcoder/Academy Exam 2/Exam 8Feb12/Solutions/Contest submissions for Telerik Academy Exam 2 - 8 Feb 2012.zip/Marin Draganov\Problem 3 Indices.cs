using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.Indices
{
    class Indices
    {
        static void Main()
        {
            int n;
            n = int.Parse(Console.ReadLine());
            string line = Console.ReadLine();
            string[] numbers = line.Split();
            int[] arr = new int[n];
            int[] visited = new int[n];

            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(numbers[i]);
            }

            StringBuilder result = new StringBuilder();
            int index = 0;
            bool cycle = false;
            while (index >= 0 && index < n)
            {
                if (visited[index] == 1)
                {
                    cycle = true;
                    break;
                }
                visited[index] = 1;
                result.Append(index.ToString()+" ");
                index = arr[index];
            }

            if (!cycle)
            {
                result.Remove(result.Length - 1,1);
            }
            if (cycle)
            {
                string old = " "+index;
                if (index == 0) old = "0";
                string newStr = "("+index;
                result.Replace(old, newStr);
                result[result.Length - 1] = ')';
            }
            Console.Write(result);
        }
    }
}