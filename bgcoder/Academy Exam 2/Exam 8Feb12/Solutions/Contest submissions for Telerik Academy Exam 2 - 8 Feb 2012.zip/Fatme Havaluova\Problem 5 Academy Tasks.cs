using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace AcademyTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] elems = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.None);
            int n = elems.Length;
            int[] arr = new int[n];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(elems[i]);
            }
            int variety = int.Parse(Console.ReadLine());
            generareSubSets(arr, variety);
            /*  List<int[]> lists = createSubsets(arr);
            for (int i = 0; i < lists.Count; i++)
            {
                int[] array = lists[i];
                for (int j = 0; j < array.Length; j++)
                {
                    Console.Write(array[j] + " ");
                }
                Console.WriteLine();
            }
            */
        }
        private static List<T[]> createSubsets<T>(T[] originalArray)
        {
            List<T[]> subsets = new List<T[]>();
 
            for (int i = 0; i < originalArray.Length; i++)
            {
                int subsetCount = subsets.Count;
                subsets.Add(new T[] { originalArray[i] });
 
                for (int j = 0; j < subsetCount; j++)
                {
                    T[] newSubset = new T[subsets[j].Length + 1];
                    subsets[j].CopyTo(newSubset, 0);
                    if (i - j <= 1) newSubset[newSubset.Length - 1] = originalArray[i];
                    Console.WriteLine("i is: " + i + " j is: " + j);
                    subsets.Add(newSubset);
                }
            }
 
            return subsets;
        }
        private static void generareSubSets(int[] originalArray, int variety)
        {
            List<int[]> subsets = new List<int[]>();
 
            for (int i = 0; i < originalArray.Length; i++)
            {
                int subsetCount = subsets.Count;
                subsets.Add(new int[] { originalArray[i] });
 
                for (int j = 0; j < subsetCount; j++)
                {
                    int[] newSubset = new int[subsets[j].Length + 1];
                    subsets[j].CopyTo(newSubset, 0);
                    newSubset[newSubset.Length - 1] = originalArray[i];
                    subsets.Add(newSubset);
                    int length = newSubset.Length;
                    if (isValidSubset(newSubset, originalArray, length))
                    {
                        Array.Sort(newSubset);
 
                        int difference = newSubset[length - 1] - newSubset[0];
 
                        if (difference >= variety)
                        {
                            Console.WriteLine(length);
                            return;
                        }
                    }
 
                }
            }
        }
        private static bool isValidSubset(int[] subset, int[] originalArray, int subsetLength)
        {
            if (subset.Length == 2)
            {
                if ((Array.IndexOf(originalArray, subset[1]) - Array.IndexOf(originalArray, subset[0])) > 1) return false;
                return true;
            }
            for (int i = 0; i < subsetLength - 1; i++)
            {
                int fIndex = Array.IndexOf(originalArray, subset[i]);
                int sIndex = Array.IndexOf(originalArray, subset[i + 1]);
                if ((fIndex - sIndex) > 2) return false;
            }
            return true;
        }
        private static void printArr(int[] arr, int n)
        {
 
            for (int i = 0; i < n; i++)
            {
                //int fIndex = Array.IndexOf(originalArray, arr[i]);
                //int sIndex = Array.IndexOf(originalArray, arr[i + 1]);
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
        }
    }
}