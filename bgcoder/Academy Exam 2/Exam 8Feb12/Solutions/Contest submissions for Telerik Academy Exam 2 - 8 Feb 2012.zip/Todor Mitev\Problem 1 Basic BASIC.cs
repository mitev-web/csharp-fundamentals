using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam2
{
    class Task01
    {
        static int v;
        static int w;
        static int x;
        static int y;
        static int z;
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            string input = "";
            int count = 0;
            while (input != "RUN")
            {
                input = Console.ReadLine();
                sb.Append(input + "\n");
                count++;
            }

            string[,] code = new string[count, 2];
            int indexOfNewLine = 0;
            int indexOfLastKnowNL = 0;
            int indexOfSpace = 0;
            string line = sb.ToString();
            for (int i = 0; i < count - 1; i++)
            {
                indexOfNewLine = line.IndexOf("\n", indexOfLastKnowNL + 1);
                indexOfSpace = line.IndexOf(" ", indexOfLastKnowNL + 1);
                if (indexOfNewLine >= 0)
                {
                    if (indexOfSpace >= 0)
                    {
                        code[i, 0] = line.Substring(indexOfLastKnowNL, indexOfSpace - indexOfLastKnowNL);
                        code[i, 1] = line.Substring(indexOfSpace, indexOfNewLine - indexOfLastKnowNL - 1).Trim().Replace(" ", "");
                    }
                    else
                    {
                        code[i, 0] = "-1";
                        code[i, 1] = line.Substring(indexOfLastKnowNL, indexOfNewLine - indexOfLastKnowNL).Trim().Replace(" ", "");
                    }
                    indexOfLastKnowNL = indexOfNewLine + 1;
                }
            }
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < count - 1; i++)
            {
                if (code[i, 1].IndexOf("GOTO") >= 0)
                {
                    int gotoIndex = code[i, 1].IndexOf("GOTO");
                    string lineToGo = (code[i, 1].Substring((gotoIndex + 4), code[i, 1].Length - gotoIndex - 4));
                    for (int j = 0; j < count - 1; j++)
                    {
                        if ((code[j, 0]) == lineToGo)
                            i = j;
                    }
                }
                if (code[i, 1].IndexOf("CLS") >= 0)
                {
                    result = new StringBuilder();
                }
                if (code[i, 1].IndexOf("STOP") >= 0)
                {
                    break;
                }
                int indexOfV = code[i, 1].IndexOf('V');
                int indexOfW = code[i, 1].IndexOf('W');
                int indexOfX = code[i, 1].IndexOf('X');
                int indexOfY = code[i, 1].IndexOf('Y');
                int indexOfZ = code[i, 1].IndexOf('Z');

                if (code[i, 1].IndexOf("PRINT") < 0)
                {
                    
                    if (code[i, 1].IndexOf("IF") < 0)
                    {
                        if (indexOfX >= 0 && indexOfY < 0 && indexOfZ < 0 && indexOfV < 0 && indexOfW < 0)
                        {
                            if (code[i, 1].IndexOf('X', indexOfX + 1) < 0) // getting x
                            {
                                x = int.Parse(code[i, 1].Substring(indexOfX + 2, code[i, 1].Length - 2 - indexOfX));
                            }
                            int secondX = code[i, 1].IndexOf('X', indexOfX + 1);
                            if (secondX > indexOfX)
                            {
                                if (code[i, 1][secondX + 1] == '-') x -= int.Parse(code[i, 1].Substring(secondX + 2, code[i, 1].Length - 2 - secondX));
                                if (code[i, 1][secondX + 1] == '+') x += int.Parse(code[i, 1].Substring(secondX + 2, code[i, 1].Length - 2 - secondX));
                            }
                            if (indexOfY > indexOfX)
                            {
                                if (code[i, 1][indexOfY + 1] == '-') x -= int.Parse(code[i, 1].Substring(indexOfY + 2, code[i, 1].Length - indexOfY - 2));
                                if (code[i, 1][indexOfY + 1] == '+') x += int.Parse(code[i, 1].Substring(indexOfY + 2, code[i, 1].Length - indexOfY - 2));
                            }
                        }
                        if (indexOfX < 0 && indexOfY >= 0 && indexOfZ < 0 && indexOfV < 0 && indexOfW < 0)
                        {
                            if (code[i, 1].IndexOf('Y', indexOfY + 1) < 0) // getting y
                            {
                                y = int.Parse(code[i, 1].Substring(indexOfY + 2, code[i, 1].Length - 2 - indexOfY));
                            }
                            int secondY = code[i, 1].IndexOf('Y', indexOfY + 1);
                            if (secondY > indexOfY)
                            {
                                if (code[i, 1][secondY + 1] == '-') y -= int.Parse(code[i, 1].Substring(secondY + 2, code[i, 1].Length - 2 - secondY));
                                if (code[i, 1][secondY + 1] == '+') y += int.Parse(code[i, 1].Substring(secondY + 2, code[i, 1].Length - 2 - secondY));
                            }
                        }
                        if (indexOfX < 0 && indexOfY < 0 && indexOfZ >= 0 && indexOfV < 0 && indexOfW < 0)
                        {
                            if (code[i, 1].IndexOf('Z', indexOfZ + 1) < 0) // getting z
                            {
                                z = int.Parse(code[i, 1].Substring(indexOfZ + 2, code[i, 1].Length - 2 - indexOfZ));
                            }
                            int secondZ = code[i, 1].IndexOf('Z', indexOfZ + 1);
                            if (secondZ > indexOfZ)
                            {
                                if (code[i, 1][secondZ + 1] == '-') z -= int.Parse(code[i, 1].Substring(secondZ + 2, code[i, 1].Length - 2 - secondZ));
                                if (code[i, 1][secondZ + 1] == '+') z += int.Parse(code[i, 1].Substring(secondZ + 2, code[i, 1].Length - 2 - secondZ));
                            }
                        }
                        if (indexOfX < 0 && indexOfY < 0 && indexOfZ < 0 && indexOfV >= 0 && indexOfW < 0)
                        {
                            if (code[i, 1].IndexOf('V', indexOfV + 1) < 0) // getting v
                            {
                                v = int.Parse(code[i, 1].Substring(indexOfV + 2, code[i, 1].Length - 2 - indexOfV));
                            }
                            int secondV = code[i, 1].IndexOf('V', indexOfV + 1);
                            if (secondV > indexOfY)
                            {
                                if (code[i, 1][secondV + 1] == '-') v -= int.Parse(code[i, 1].Substring(secondV + 2, code[i, 1].Length - 2 - secondV));
                                if (code[i, 1][secondV + 1] == '+') v += int.Parse(code[i, 1].Substring(secondV + 2, code[i, 1].Length - 2 - secondV));
                            }
                        }
                        if (indexOfX < 0 && indexOfY < 0 && indexOfZ < 0 && indexOfV < 0 && indexOfW >= 0)
                        {
                            if (code[i, 1].IndexOf('W', indexOfW + 1) < 0) // getting w
                            {
                                w = int.Parse(code[i, 1].Substring(indexOfW + 2, code[i, 1].Length - 2 - indexOfW));
                            }
                            int secondW = code[i, 1].IndexOf('W', indexOfW + 1);
                            if (secondW > indexOfW)
                            {
                                if (code[i, 1][secondW + 1] == '-') w -= int.Parse(code[i, 1].Substring(secondW + 2, code[i, 1].Length - 2 - secondW));
                                if (code[i, 1][secondW + 1] == '+') w += int.Parse(code[i, 1].Substring(secondW + 2, code[i, 1].Length - 2 - secondW));
                            }
                        }
                    }
                }
                else if (code[i, 1].IndexOf("PRINT") >= 0 && code[i,1].IndexOf("IF")<0)
                {
                    if (indexOfX >= 0) result.AppendLine(x.ToString());
                    if (indexOfY >= 0) result.AppendLine(y.ToString());
                    if (indexOfZ >= 0) result.AppendLine(z.ToString());
                    if (indexOfV >= 0) result.AppendLine(v.ToString());
                    if (indexOfW >= 0) result.AppendLine(w.ToString());
                }
               
            }
            Console.WriteLine(result.ToString().Trim());
        }
    }
}
