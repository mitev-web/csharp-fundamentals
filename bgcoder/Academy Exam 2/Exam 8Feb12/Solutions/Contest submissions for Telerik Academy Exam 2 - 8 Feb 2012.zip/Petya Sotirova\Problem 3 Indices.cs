using System;
using System.Collections.Generic;

namespace Indices
{
    class Program
    {
        static void Index(int[] arr,List<int> actArr)
        {
            actArr.Add(0);
            actArr.Add(arr[0]);
            
            int next = actArr[1];

            int i = 2;
            while(actArr[i-1]<arr.Length-1)
            {
                actArr.Add( arr[next]);
                next = actArr[i];
                i++;
            }
        }

        static void Main(string[] args)
        {
            ushort n = ushort.Parse(Console.ReadLine());
            int[] arr = new int[n];
            string[] nums = Console.ReadLine().Split(' ');
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(nums[i]);
            }

            List<int> actArr = new List<int>();
            Index(arr,actArr);

            for (int i = 0; i < actArr.Count-1; i++)
            {
                Console.Write(actArr[i] + " ");
            }
            Console.WriteLine(actArr[actArr.Count-1]);
        }
    }
}
