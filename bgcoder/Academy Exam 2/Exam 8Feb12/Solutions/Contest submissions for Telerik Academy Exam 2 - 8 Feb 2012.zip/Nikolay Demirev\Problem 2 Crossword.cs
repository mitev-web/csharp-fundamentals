using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2
{
    class Crossword
    {
        SortedList<string, string> words = new SortedList<string, string>();
        SortedList<string, string> crosswords = new SortedList<string, string>();
        string[] currentCrossword;
        int n;

        public Crossword(int n)
        {
            this.n = n;
            currentCrossword = new string[n];
        }

        public void AddWord(string word)
        {
            words.Add(word, word);
        }

        private string GetCol(int col)
        {
            StringBuilder result = new StringBuilder();

            for (int row = 0; row < n; row++)
            {
                if (string.IsNullOrEmpty(currentCrossword[row]))
                {
                    return null;
                }

                result.Append(currentCrossword[row][col]);
            }

            return result.ToString();
        }

        private bool IsValid()
        {
            for (int col = 0; col < n; col++)
            {
                string result = GetCol(col);
                if (string.IsNullOrEmpty(result))
                {
                    return false;
                }

                if (!words.ContainsKey(result))
                {
                    return false;
                }
            }

            return true;
        }

        public void CreateCrossWord(int newIndex)
        {
            if (IsValid())
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < n; i++)
                {
                    sb.Append(currentCrossword[i]);
                }
                string c = sb.ToString();
                crosswords.Add(c, c);
            }

            for (int i = newIndex; i < n; i++)
            {
                if (string.IsNullOrEmpty(currentCrossword[i]))
                {
                    for (int wordCounter = 0; wordCounter < words.Count; wordCounter++)
                    {
                        currentCrossword[i] = words.Values[wordCounter];
                        CreateCrossWord(i + 1);
                        currentCrossword[i] = string.Empty;
                    }
                }
            }
        }

        public void PrintResult()
        {
            int i = 0;
            if (crosswords.Count == 0)
            {
                Console.WriteLine("NO SOLUTION!");
                return;
            }
            string result = crosswords.Values[0];

            while (i < result.Length)
            {
                Console.Write(result[i]);
                i++;
                if (i % n == 0)
                {
                    Console.WriteLine();
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            
            int doubleN = 2 * n;

            Crossword crossword = new Crossword(n);

            for (int i = 0; i < doubleN; i++)
            {
                string word = Console.ReadLine();
                crossword.AddWord(word);
            }

            crossword.CreateCrossWord(0);
            crossword.PrintResult();
        }
    }
}
