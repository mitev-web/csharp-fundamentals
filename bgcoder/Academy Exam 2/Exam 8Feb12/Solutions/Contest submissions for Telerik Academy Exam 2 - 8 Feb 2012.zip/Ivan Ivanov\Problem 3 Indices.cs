using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
 
 
class IndicesNonRecurse
{
    static StringBuilder result = new StringBuilder();
    static int indxBracket = -10;
 
    static void Main(string[] args)
    {
        checked
        {
            string finalResut;
            string line;
            string[] lineSplited;
            char[] spliters = { ' ', ',', '\n' };
            int numbersRead;
 
            //StreamReader reader = new StreamReader("test1.txt");
 
            line = Console.ReadLine();
            numbersRead = int.Parse(line);
 
            int[] arr = new int[numbersRead];
            bool[] isVisited = new bool[numbersRead];
 
            line = Console.ReadLine();
            lineSplited = line.Split(spliters, StringSplitOptions.RemoveEmptyEntries);
 
            for (int i = 0; i < numbersRead; i++)
            {
                arr[i] = int.Parse(lineSplited[i]);
            }
 
 
            int position = 0;
 
            while (position >= 0 && position < arr.Length)
            {
 
                result.Append(String.Format("{0}", position));
                isVisited[position] = true;
 
                position = arr[position];
 
                if (position < arr.Length && position >= 0)
                    if (isVisited[position] == true)
                    {
                        result.Append(")");
                        indxBracket = position;
                        break;
                    }
                    else
                    {
                        result.Append(String.Format(" ", position));
                    }
 
 
            }
 
            if (indxBracket != -10)
            {
                indxBracket = indxBracket * 2 - 1;
 
                if (indxBracket == -1)
                {
                    finalResut = String.Concat("(", result.ToString());
                }
                else
                {
                    result[indxBracket] = '(';
                    finalResut = result.ToString();
                }
 
            }
            else
            {
                finalResut = result.ToString();
            }
 
 
            Console.WriteLine(finalResut);
        }
 
    }
}