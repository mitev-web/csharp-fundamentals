using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.crossword
{
    class Program
    {
        public static List<string> lstr = new List<string>();
        static int count=0;
        static void Crossword(int n, string[] str)
        {
            for (int k = 0; k < n; k++)
            {
                StringBuilder sb = new StringBuilder();
                string temp;
                int i;
                for (i = 0; i < n; i++)
                {
                    temp = str[i].ToString();
                    sb.Append(temp[k]);
                }

                for (int j = 0; j < str.Length; j++)
                {
                    if (sb.ToString() == str[j])
                    {
                        count++;
                        //Console.WriteLine(sb.ToString());
                        lstr.Add(sb.ToString());
                    }
                }
                temp = "";
            }    
        }


        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] str = new string[2*n];
            for (int j = 0; j < 2 * n; j++)
            {
                str[j] = Console.ReadLine();
            }
            string[] str2 = str;
            for (int i = 0; i < n; i++)
            {
                Crossword(n, str);
                var lst = str.ToList();
                lst.Remove(lst[0]);
                str = lst.ToArray();
            }
            
            if (count != 0)
            {
                if (true)
                {
                    string[] str1 = lstr.ToArray();
                    for (int k = 0; k < n; k++)
                    {
                        StringBuilder sb1 = new StringBuilder();
                        string temp;
                        int i;
                        for (i = 0; i < n; i++)
                        {
                            temp = str1[i].ToString();
                            sb1.Append(temp[k]);
                        }

                        for (int j = 0; j < str.Length; j++)
                        {
                            if (sb1.ToString() == str2[j])
                            {
                                count++;
                                //Console.WriteLine(sb1.ToString());
                            }
                        }
                        temp = "";
                    }
                    foreach (var item in lstr)
                    {
                        Console.WriteLine(item);
                    }
                }
            }      
            if (count == 0)
                Console.WriteLine("NO SOLUTION!");
        }
    }
}

