using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BombingCuboids
{
    class Program
    {
        static int width;
        static int height;
        static int depth;
        static int[, ,] cuboid;

        static void Main(string[] args)
        {
            ReadCuboid();
            int bombNumber = int.Parse(Console.ReadLine());

        }
        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            // Read the cuboid content
            cuboid = new int[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        int cubeValue = int.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
        }
    }
}
