using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Indices
    {
        static void Main(string[] args)
        {
            int arrSize = int.Parse(Console.ReadLine());
            string [] numbersAsStr = Console.ReadLine().Split(' ');
            int [] arr = new int[arrSize];

            for (int i = 0; i < arrSize; i++)
			{
                arr[i] = int.Parse(numbersAsStr[i]);
			}
            List<int> sequence = new List<int>();
            sequence.Add(0);

            int currentIndex = 0;
            int xorredLast = 0;
            int lastIndex = 0;

            while (currentIndex < arrSize && currentIndex >= 0)
            {
                sequence.Add(arr[currentIndex]);
                currentIndex = arr[lastIndex];
                lastIndex = currentIndex;
            }

            for (int i = 0; i < sequence.Count-1; i++ )
            {
                if (i == sequence.Count - 2)
                {
                    Console.Write(sequence[i]);
                }
                else
                {
                    Console.Write(sequence[i] + " ");
                }
            }
            Console.WriteLine();
        }
    }
}
