using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Problem
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string k = Console.ReadLine();
            string []kk = k.Split(' ');
            long[] arr = new long[n];
            short[] arr2 = new short[n];

            int i = 0;
            while (true)
            {
                if (i==n)
                {
                    break;
                }
                if (String.IsNullOrEmpty(kk[i]) == false && String.IsNullOrWhiteSpace(kk[i]) == false)
                {
                    arr[i] = long.Parse(kk[i].Trim());
                    i++;
                }
                
            }
            StringBuilder output = new StringBuilder();
            output.Append(0);
            arr2[0] = 1;
            long startLoop = 0;
            long current = 0;
            bool isLoop = false;
            StringBuilder output2 = new StringBuilder();
            while (true)
            {
                
                current = arr[current];
                
                if (current >= arr.Length)
                {
                    break;
                }
                if (arr2[current]==1)
                {
                    startLoop = current;
                    isLoop = true;
                    break;
                    
                }
                arr2[current] = 1;
                output.Append(" " + current);
            }
            if (isLoop == true)
            {


                string[] p = output.ToString().Split(' ');
                int[] z = new int[p.Length];
                for (int om = 0; om < p.Length; om++)
                {
                    z[om] = int.Parse(p[om]);
                }
                for (int op = 0; op < z.Length; op++)
                {
                    if (z[op] != startLoop)
                    {
                        if (op == 0)
                        {
                            output2.Append(z[op]);
                        }
                        else
                        {
                            output2.Append(" " + z[op]);
                        }
                    }
                    else
                    {
                        output2.Append("(" + z[op]);
                    }

                }
                output2.Append(")");
                Console.WriteLine(output2);
            }
            else
            {
                Console.WriteLine(output);
            }
        }
    }
}
