using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.Crossword
{
	class Crossword
	{
		static string[] words;
		static char[,] crossword;
		static bool printed = false;

		static bool CheckState()
		{
			for (int col = 0; col < crossword.GetLength(0); col++)
			{
				StringBuilder currentWord = new StringBuilder();
				for (int row = 0; row < crossword.GetLength(1); row++)
				{
					currentWord.Append(crossword[row, col]);
				}
				if (words.Contains(currentWord.ToString()) == false)
				{
					return false;
				}
			}
			return true;
		}

		static void PrintCrossword()
		{
			for (int row = 0; row < crossword.GetLength(0); row++)
			{
				for (int col = 0; col < crossword.GetLength(1); col++)
				{
					Console.Write(crossword[row, col]);
				}
				if (row < crossword.GetLength(0) - 1)
				{
					Console.WriteLine();
				}
			}
			printed = true;
			return;
		}

		static void SolveCrossword(int row)
		{
			if (printed == true)
			{
				return;
			}
			if (row == crossword.GetLength(0))
			{
				if (CheckState() == true)
				{
					PrintCrossword();
					return;
				}
				return;
			}
			foreach (string word in words)
			{
				for (int i = 0; i < word.Length; i++)
				{
					crossword[row, i] = word[i];
				}
				SolveCrossword(row + 1);
			}
		}

		static void Main(string[] args)
		{

			int n = int.Parse(Console.ReadLine());
			words = new string[2 * n];
			crossword = new char[n, n];
			for (int i = 0; i < 2 * n; i++)
			{
				words[i] = Console.ReadLine();
			}

			Array.Sort(words);
			SolveCrossword(0);
			if (printed == false)
			{
				Console.WriteLine("NO SOLUTION!");
			}
		}
	}
}
