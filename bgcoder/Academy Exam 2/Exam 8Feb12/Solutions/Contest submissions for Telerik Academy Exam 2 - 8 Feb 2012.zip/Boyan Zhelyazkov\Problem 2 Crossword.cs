using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace CrossWord1
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            char[,] letters = new char[2 * N, N];
            List<string> verticalWords = new List<string>();
            List<string> horizontalWords = new List<string>();
            List<string> findedWords = new List<string>();
            List<string> answer = new List<string>();
            int[] position = new int[N];
            string word;
            int k = 0;
            int m=0;
            bool isFiniesh = false;
            for (int i = 0; i < 2 * N; i++)
            {
                word = Console.ReadLine();
                horizontalWords.Add(word);
                for (int j = 0; j < N; j++)
                {
                    letters[i, j] = word[j];  
                }
            }
            StringBuilder verticalWord = new StringBuilder();
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 2 * N; j++)
                {
                    verticalWord.Append(letters[j, i]);
                }
                verticalWords.Add(verticalWord.ToString());
                verticalWord.Clear();
            }
 
           horizontalWords.Sort();
            for (int i = 0; i < 2 * N; i++)
            {
               recursive(horizontalWords,  k, N, answer, i, position);
               m--;
                
            }
            Console.WriteLine("NO SOLUTION!");
        }
        static void recursive(List<string> horizontalWords,  int k, int N, List<string> answer, int m, int[] position)
        {
 
            
            if (k == N && m<2*N)
            {
                StringBuilder word = new StringBuilder();
                int c = 0;
                for (int n = 0; n < N; n++)
                {
                     
                    if (position[k-1]  <2*N)
                    {
 
                       
                        for (int r = 0; r < N; r++)
                        {
                            word.Append(answer[r][n]);
                        }
                        if (horizontalWords.Contains(word.ToString()))
                        {
                            word.Clear();
                            c++;
                        }
                        else
                        {
                            answer.RemoveAt(k - 1);
                            k--;
                            if (m==2*N)
                            {
                                k++;
                                m++;
                                position[k-1] = m;
                            }
                            recursive(horizontalWords, k, N, answer, m, position);
                           
 
                        }
                    }
                }
                if (c==3)
                {
                    Console.WriteLine("a");
                }
                
            }
            else if (k < N && m < 2 * N)
            {
                if (position[k] == 2 * N && m > 0)
                {
                    return;
                }
                if (position[k] == 2 * N && m == 0)
                {
                    k--;
                    answer.RemoveAt(answer.Count - 1);
                    return;
                }
 
                if (position[k] <= 2 * N - 1)
                {
 
 
                    answer.Add(horizontalWords[m]);
                    k++;
                    m++;
                    position[k - 1] = m;
 
                    recursive(horizontalWords, k, N, answer, m, position);
                    
 
 
                }
 
            }
            else if(k == N && m == 2 * N)
            {
                if (position[k-1] == 2 * N && m > 0)
                {
                    return;
                }
                if (position[k-1] == 2 * N && m == 0)
                {
                    k--;
                    m = position[k];
                    answer.RemoveAt(answer.Count - 1);
                    return;
                }
            }
             
        }
 
    }
}