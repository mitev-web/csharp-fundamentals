using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.ProblemSolving
{
    class Program
    {
        static int numCount;
        static int satisfaction;
        static int bestCount = 1001;
        static int bestVal = 0;

        static void ChooseNext(int[] pleas, int index,int count,int maxVal,int minVal)
        {
            if (index >= numCount)
            {
                return;
            }
            count++;
            if (pleas[index] > maxVal)
            {
                maxVal = pleas[index];
            }
            if (pleas[index] < minVal)
            {
                minVal = pleas[index];
            }
            if (maxVal - minVal >= satisfaction)
            {
                if (count < bestCount)
                {
                    bestCount = count;
                    return;
                }
            }
            ChooseNext(pleas, index + 1, count, maxVal, minVal);
            ChooseNext(pleas, index + 2, count, maxVal, minVal);

        }
        static void Main()
        {
            string line = Console.ReadLine();
            satisfaction = int.Parse(Console.ReadLine());
            char[] separators = {' ',','};
            string[] numbers = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            numCount = numbers.Length;
            int[] pleas = new int[numCount];

            for (int i = 0; i < numCount; i++)
            {
                pleas[i] = int.Parse(numbers[i]);
            }


            ChooseNext(pleas, 0, 0, -1, 1001);
            Console.WriteLine(bestCount);


        }
    }
}