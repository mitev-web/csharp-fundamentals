using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_Crossword
{
    class Program
    {
        static void Main()
        {
            byte N = byte.Parse(Console.ReadLine());
            string[] crossword = new string[N * 2];
            for (byte i = 0; i < N * 2; i++)
            {
                crossword[i] = Console.ReadLine();
            }

            Console.WriteLine("NO SOLUTION!");
        }
    }
}