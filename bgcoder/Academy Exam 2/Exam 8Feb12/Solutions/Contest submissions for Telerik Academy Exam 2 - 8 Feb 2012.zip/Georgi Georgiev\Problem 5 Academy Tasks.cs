using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Academy_Tasks
{
    class Academy_Tasks
    {
        static void Main(string[] args)
        {
            string [] tasksAsStrings = Console.ReadLine().Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            int variety = int.Parse(Console.ReadLine());
            int[] tasks = new int[tasksAsStrings.Length];

            for (int i = 0; i < tasksAsStrings.Length; i++)
            {
                tasks[i] = int.Parse(tasksAsStrings[i]);
            }

            int currentInd = 0;
            int minimum = tasks[currentInd];
            int minimumNumSolved = tasks.Length;
            int numSolved = 1;
            while (Math.Abs(minimum - tasks[currentInd]) < variety)
            {
                numSolved++;
                if (tasks[currentInd] < minimum)
                {
                    minimum = tasks[currentInd];
                }

                if (currentInd + 1 >= tasks.Length)
                {
                    break;
                }

                if (Math.Abs(minimum - tasks[currentInd + 1]) >= variety)
                {
                    currentInd++;
                }
                else
                {
                    currentInd += 2;
                }
            }

            Console.WriteLine(numSolved);
        }
    }
}
