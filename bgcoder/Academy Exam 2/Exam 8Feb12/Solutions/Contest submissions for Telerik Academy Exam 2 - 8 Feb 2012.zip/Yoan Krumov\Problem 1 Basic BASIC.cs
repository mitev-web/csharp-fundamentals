using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Basic_BASIC
{
    class Program
    {
        static void Main(string[] args)
        {
            //string basicCode = "5 X=-1\n"+"6 IF X=-1 THEN X=0\n"+"7 PRINT X\n"+"8 CLS\n"+"10 PRINT X\n"+"20 X=X+1\n"+"30 IF X < 4 THEN GOTO 10\n"+"40 STOP\n"+"50 PRINT X\n"+"RUN\n";

            //Console.WriteLine(basicCode);

            //string linesCountPattern = @"\n";

            //MatchCollection linesCount = Regex.Matches(basicCode,linesCountPattern);
            //foreach (var item in linesCount)
            //{
            //    string b = item.ToString();
            //    Console.WriteLine(b);
            //}
            int[] arr = {1, 0, 1, 0};
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}
