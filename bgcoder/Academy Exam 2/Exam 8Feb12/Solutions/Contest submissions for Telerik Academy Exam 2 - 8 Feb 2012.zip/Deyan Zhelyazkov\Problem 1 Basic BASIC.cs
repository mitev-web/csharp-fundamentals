
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

 

namespace task5

{

    class Program

    {

        static void Main(string[] args)

        {


            int[] pleasantnessArray = new int[] { 1, 2, 3 };

          
            int solvedProblems = 0;

            int variety = 2;

            for (int i = 1; i < pleasantnessArray.Length; i++)

            {

 

                if (pleasantnessArray[i] - pleasantnessArray[i - 1] >= variety)

                {

                    Console.WriteLine(solvedProblems);

                }

                solvedProblems++;

 

            }

 

            Console.WriteLine(solvedProblems);

             

        }

    }

}