using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.CSharp;
using System.CodeDom.Compiler;

namespace wtf
{

     
    class Program
    { 
        static bool rek = false;
        static StringBuilder sb = new StringBuilder();
         static List<int> intList = new List<int>();
         
         static  void rekursiq(int index, int[] masiv,StringBuilder sb)
        {
          
            rek = intList.Contains(index);
            
            if (rek == true)
            {
                if (index == 0)
                {
                    Console.WriteLine(index);
                }
               
                else 
                {

                int indexOFsign = intList.IndexOf(index);
                sb.Remove(indexOFsign, 1);
                sb.Insert(indexOFsign, "(");
                sb.Append(")");
                sb.Remove(sb.Length-2,1);
                Console.WriteLine(sb);
            }

                //for (int i = 0; i < intList.Count; i++)
                //{
                //    if (i < intList.Count - 2)
                //    {

                //        sb.Append(intList[i] + " ");
                //        //Console.Write(sb[i] + " ");
                //    }
                //    else if (i == intList.Count - 2)
                //    {
                //        sb.Append(intList[i]);
                //    }
                //    else
                //    {

                //        sb.Append(intList[i] + ")");
                //        //Console.WriteLine(sb[i] + ")");
                //    }
                //}

                return;
    
             }
            
            if (index < masiv.Length)
            {   
                    sb.Append(index + " ");
                    intList.Add(index);
                    index = masiv[index];
                    rekursiq(index, masiv,sb);   
            }

                else if (index >= masiv.Length)
                {
                    for (int i = 0; i < intList.Count; i++)
                    {
                        if (i != intList.Count - 1)  
                        {
                            Console.Write(intList[i] + " ");
                        }
                        else 
                        {
                            Console.WriteLine(intList[i]);
                        }
                    }
                  
                }
            
        }
         
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string inputNumbers = Console.ReadLine();
            string[] stringNumbers = inputNumbers.Split(' ');
            int[] intNumbers = new int[stringNumbers.Length];
            for (int i = 0; i < stringNumbers.Length; i++)
            {
                intNumbers[i] = int.Parse(stringNumbers[i]);
            }
            int x = 0;
            StringBuilder result = new StringBuilder();
            rekursiq(x,intNumbers,result);
          }
          
          

  
    }
}
