using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NoSolutionCrossword
{
    class Program
    {
        static void Main(string[] args)
        {
            string userInput = Console.ReadLine();
            byte n = byte.Parse(userInput);

            string[] words = new string[n * 2];
            //char[,] crossword=new char[n,n];
            string[] crossword = new string[n];
            for (int i = 0; i < n * 2; i++)
            {
                words[i] = Console.ReadLine();
            }
            Console.WriteLine("NO SOLUTION!");
        }
    }
}
