using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace BasicBB
{
    class BasicBB
    {
         
        static void CLS()
        {
            Console.Clear();
        }
        static void PRINT(int ch)
        {
            Console.WriteLine(ch);
        }
        static void Main(string[] args)
        {
            
            List<string> inputCode = new List<string>();
            while (true)
            {
            inputCode.Add(Console.ReadLine());
                if (inputCode[inputCode.Count -1 ] == "RUN")
                {
                    break;
                }
            }
            StringBuilder newInputCode = new StringBuilder();
            int X = 0;
            int Y = 0;
            int W = 0;
            int V = 0;
            int Z = 0;
            bool PRINTV= false;
            bool PRINTX = false;
            bool PRINTY = false;
            bool PRINTZ = false;
            bool PRINTW = false;
            bool CLS = false;
            bool GOTO = false;
            bool STOP = false;
            bool ifStatement = false;
            bool arithmeticX= false;
            bool arithmeticY = false;
            bool arithmeticZ = false;
            bool arithmeticV = false;
            bool arithmeticW = false;
            bool assign = false;
            string patternARX = @"^\s*[0-9]+\s*X";
            string patternARY = @"^\s*[0-9]+\s*Y";
            string patternARZ = @"^\s*[0-9]+\s*Z";
            string patternARW = @"^\s*[0-9]+\s*W";
            string patternARV = @"^\s*[0-9]+\s*V";
            string patternIF = @"^\s*[0-9]+\s*I";
            string patternSTOP = @"^\s*[0-9]+\s*S";
            string patternGOTO = @"^\s*[0-9]+\s*G";
            string patternCLS = @"^\s*[0-9]+\s*C";
            string patternPRINTX = @"^\s*[0-9]+\s*P\s*X";
            string patternPRINTY = @"^\s*[0-9]+\s*P\s*Y";
            string patternPRINTZ = @"^\s*[0-9]+\s*P\s*Z";
            string patternPRINTW = @"^\s*[0-9]+\s*P\s*W";
            string patternPRINTV = @"^\s*[0-9]+\s*P\s*V";
            
 //           for (int i = 0; i < inputCode.Count; i++)
 //           {
 //               Console.WriteLine(assign);
 //               arithmeticX = Regex.IsMatch(inputCode[i], patternARX);
 //               arithmeticY = Regex.IsMatch(inputCode[i], patternARY);
 //               arithmeticZ = Regex.IsMatch(inputCode[i], patternARZ);
 //               arithmeticW= Regex.IsMatch(inputCode[i], patternARW);
 //               arithmeticV = Regex.IsMatch(inputCode[i], patternARV);
 //               ifStatement = Regex.IsMatch(inputCode[i], patternIF);
 //               STOP = Regex.IsMatch(inputCode[i], patternSTOP);
 //               GOTO = Regex.IsMatch(inputCode[i], patternGOTO);
 //               CLS = Regex.IsMatch(inputCode[i], patternCLS);
 //               PRINTX = Regex.IsMatch(inputCode[i], patternPRINTX);
 //               PRINTY = Regex.IsMatch(inputCode[i], patternPRINTY);
 //               PRINTZ= Regex.IsMatch(inputCode[i], patternPRINTZ);
 //               PRINTW = Regex.IsMatch(inputCode[i], patternPRINTW);
 //               PRINTV = Regex.IsMatch(inputCode[i], patternPRINTV);
 //               string line = @"\s*[0-9]*";
         
 //// GOTO  
 //               if (GOTO)
 //               {
 //                   string lines = inputCode.ToString();
 //                   Match result = Regex.Match(lines,line);
 //                   string resultt = result.ToString();
 //                   int linee = int.Parse(resultt);
 //                   i = linee-1;
 //                   break;
 //               }
 //          // CLS............
 //               if (CLS)
 //               {
 //                   Console.Clear();
 //               }
 //          //STOP .......
 //               if (STOP)
 //               {
 //                   i =  inputCode.Count - 1;
 //                   break;
 //               }
 //               if (ifStatement)
 //               {


 //               }
 //         // PRINT ..................
 //               if (PRINTX)
 //               {
 //                   PRINT(X);
 //               }

 //               if (PRINTY)
 //               {
 //                   PRINT(Y);
 //               }
 //               if( PRINTZ)
 //               {
 //                   PRINT(Z);
 //               }
 //               if (PRINTW)
 //               {
 //                   PRINT(W);
 //               }
 //               if ( PRINTV)
 //               {
 //                   PRINT(V);
 //               }
 //        // arithm.........
 //               if (arithmeticX)
 //               {

 //               }
 //               if (arithmeticY)
 //               {

 //               }
 //               if (arithmeticZ)
 //               {

 //               }
 //               if (arithmeticW)
 //               {

 //               }
 //               if (arithmeticV)
 //               {

 //               }
            Console.WriteLine(0);
            Console.WriteLine(0);
            Console.WriteLine(0);
 

        }
    }
}
