using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _1.Problem
{
    class Program
    {
        static void Main(string[] args)
        {
           // StreamReader reader = new StreamReader(@"..\..\..\in.txt");
            //string input = reader.ReadToEnd();
            //string[] lines = input.Split('\n');
            StringBuilder input = new StringBuilder();
            while (true)
            {
                string k = Console.ReadLine();
                if (k.IndexOf("RUN")>=0)
                {
                    input.Append(k);
                    break;
                }
                input.Append(k + "\n");
                
            }
            string[] lines = input.ToString().Split('\n');
            
            int[] lineNumbers = new int[lines.Length];
            int index = -1;
            int i = 0;
            int X = 0;
            int Y = 0;
            int Z = 0;
            int V = 0;
            int start = 0;
            int W = 0;
            int num1 = 0;
            int num2= 0;
            bool isNumber = false;
            StringBuilder str = new StringBuilder();
            StringBuilder output = new StringBuilder();
            for (i = 0; i < lines.Length -1; i++)
            {
                index = lines[i].IndexOf(' ');
                str.Clear();
                for (int j = 0; j < index; j++)
                {
                    str.Append(lines[i][j]);
                }

                lineNumbers[i] = int.Parse(str.ToString());
            }
            i = 0;
            while (true)
            {
                start = 0;
                if (lines[i].IndexOf(" I") > 0)
                {
                    int unk = 0;
                    int indexSign = -1;
                    char sign = ' ';
                    int thenN = -1;
                    int unk2 = 0;
                    bool isValid = false;
                    thenN = lines[i].IndexOf(" T");
                    start = thenN+5;
                    index = lines[i].IndexOf(" I");
                    if (lines[i].IndexOf("=", index, lines[i].Length - index ) > 0)
                    {
                        indexSign = lines[i].IndexOf("=", index, lines[i].Length - index +0);
                        sign = '=';
                    }
                    else if (lines[i].IndexOf("<", index, lines[i].Length - index +0) > 0)
                    {
                        indexSign = lines[i].IndexOf("<", index, lines[i].Length - index +0);
                        sign = '<';
                    }
                    else if (lines[i].IndexOf(">", index, lines[i].Length - index +0) > 0)
                    {
                        indexSign = lines[i].IndexOf(">", index, lines[i].Length - index +0);
                        sign = '>';
                    }
                    if (lines[i].IndexOf("X",index,indexSign-index)>0)
	                {
                        unk = X;
	                }
                    else if (lines[i].IndexOf("Y", index, indexSign - index ) > 0)
	                {
                        unk = Y;
	                }
                    else if (lines[i].IndexOf("Z", index, indexSign - index ) > 0)
	                {
                        unk = Z;
	                }
                    else if (lines[i].IndexOf("V", index, indexSign - index ) > 0)
	                {
                        unk = V;
	                }
                    else if (lines[i].IndexOf("W", index, indexSign - index ) > 0)
	                {
                        unk = W;
	                }
                    for (int y = indexSign+1; y < thenN; y++)
                    {
                        isNumber = char.IsNumber(lines[i][y]);
                        if (lines[i].IndexOf("X", indexSign) > 0)
                        {
                            unk2 = X;
                        }
                        else if (lines[i].IndexOf("Y", indexSign) > 0)
                        {
                            unk2 = Y;
                        }
                        else if (lines[i].IndexOf("Z", indexSign) > 0)
                        {
                            unk2 = Z;
                        }
                        else if (lines[i].IndexOf("V", indexSign) > 0)
                        {
                            unk2 = V;
                        }
                        else if (lines[i].IndexOf("W", indexSign) > 0)
                        {
                            unk2 = W;
                        }
                        else if (isNumber == true)
                        {
                            int count = 1;
                            for (int k = y + 1; k < index; k++)
                            {
                                if (char.IsNumber(lines[i][k]) == false)
                                {
                                    break;

                                }
                                count++;
                            }
                            unk2 = int.Parse(lines[i].Substring(y, count));
                            if (lines[i][y -1] == '-')
                            {
                                unk2 = -unk2;
                            }
                            break;
                        }
                    }
                    if (sign=='=')
                    {
                        if (unk == unk2)
                        {
                            isValid = true;
                        }
                    }
                    else if (sign == '<')
                    {
                        if (unk<unk2)
                        {
                            isValid = true;
                        }
                    }
                    else if (sign == '>')
                    {
                        if (unk > unk2)
                        {
                            isValid = true;
                        }
                    }
                    if (isValid == false)
                    {
                        i++;
                        continue;
                    }

                }
                if ((lines[i].IndexOf(" X") > 0 || lines[i].IndexOf(" Y") > 0
                    || lines[i].IndexOf(" Z")>0 || lines[i].IndexOf(" V")>0 || lines[i].IndexOf(" W")>0 ))
                {
                    bool isCur = true;
                    for (int z = start; z < lines[i].Length; z++)
                    {
                        char now = lines[i][z];
                        if (char.IsLetter(now)==true)
                        {
                           if (now !='X' && now !='Y' && now !='Z' && now !='V' && now !='W' )
                             isCur = false;
                           break;
                        }
                    }
                    if (isCur == true)
                    {


                        int index2 = 0;

                        for (int y = lines[i].IndexOf("=",start,lines[i].Length-start+0) + 1; y < lines[i].Length; y++)
                        {
                            isNumber = char.IsNumber(lines[i][y]);
                            index = lines[i].IndexOf("=", start, lines[i].Length - start);
                            if (lines[i].IndexOf("X", index) > 0)
                            {
                                index2 = lines[i].IndexOf("X", index) + 1;
                                num1 = X;
                                if (lines[i].IndexOf("X", index) -1 == '-')
                                {
                                    num1 = -num1;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("Y", index) > 0)
                            {
                                index2 = lines[i].IndexOf("Y", index) + 1;
                                num1 = Y;
                                if (lines[i].IndexOf("Y", index) -1 == '-')
                                {
                                    num1 = -num1;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("Z", index) > 0)
                            {
                                index2 = lines[i].IndexOf("Z", index) + 1;
                                num1 = Z;
                                if (lines[i].IndexOf("Z", index) -1 == '-')
                                {
                                    num1 = -num1;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("V", index) > 0)
                            {
                                num1 = V;
                                index2 = lines[i].IndexOf("V", index) + 1;
                                if (lines[i].IndexOf("V", index) -1 == '-')
                                {
                                    num1 = -num1;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("W", index) > 0)
                            {
                                index2 = lines[i].IndexOf("W", index) + 1;
                                num1 = W;
                                if (lines[i].IndexOf("W", index) -1 == '-')
                                {
                                    num1 = -num1;
                                }
                                break;

                            }
                            else if (isNumber == true)
                            {
                                int count = 1;
                                for (int k = y + 1; k < index; k++)
                                {
                                    if (char.IsNumber(lines[i][k]) == false)
                                    {
                                        break;

                                    }
                                    count++;
                                }
                                num1 = int.Parse(lines[i].Substring(y, count));
                                index2 = lines[i][y] + count + 1;
                                for (int lo = y-1; lo >= 0; lo--)
                                {
                                    if (char.IsWhiteSpace(lines[i][lo]))
                                    {
                                        
                                    }
                                    else
                                    {
                                        if (lines[i][y - 1] == '-')
                                        {
                                            num1 = -num1;
                                        }
                                        break;
                                    }
                                }
                                
                                break;
                            }
                        }

                        for (int y = index2; y < lines[i].Length; y++)
                        {
                            isNumber = char.IsNumber(lines[i][y]);
                            index = index2;
                            bool isM = false;
                            for (int lp = index; lp < lines[i].Length; lp++)
                            {
                                if (char.IsSymbol(lines[i][lp]) == true)
                                {
                                    if (lines[i][lp]=='-')
                                    {
                                        isM = true;
                                    }
                                }
                            }
                            if (lines[i].IndexOf("X", index) > 0)
                            {
                                num2 = X;
                                if (isM == true)
                                {
                                    num2 = -num2;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("Y", index) > 0)
                            {
                                num2 = Y;
                                if (isM == true)
                                {
                                    num2 = -num2;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("Z", index) > 0)
                            {
                                num2 = Z;
                                if (isM == true)
                                {
                                    num2 = -num2;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("V", index) > 0)
                            {
                                num2 = V;
                                if (isM == true)
                                {
                                    num2 = -num2;
                                }
                                break;
                            }
                            else if (lines[i].IndexOf("W", index) > 0)
                            {
                                num2 = W;
                                if (isM == true)
                                {
                                    num2 = -num2;
                                }
                                break;

                            }
                            else if (isNumber == true)
                            {
                                int count = 1;
                                for (int k = y + 1; k < index; k++)
                                {
                                    if (char.IsNumber(lines[i][k]) == false)
                                    {
                                        break;

                                    }
                                    count++;
                                }
                                num2 = int.Parse(lines[i].Substring(y, count));
                                if (isM == true)
                                {
                                    num2 = -num2;
                                }
                                break;
                            }
                        }


                        if (lines[i].IndexOf("X", 0, lines[i].IndexOf("=")) > 0)
                        {
                            X = num1 + num2;
                        }
                        else if (lines[i].IndexOf("Y", 0, lines[i].IndexOf("=")) > 0)
                        {
                            Y = num1 + num2;
                        }
                        else if (lines[i].IndexOf("Z", 0, lines[i].IndexOf("=")) > 0)
                        {
                            Z = num1 + num2;
                        }
                        else if (lines[i].IndexOf("V", 0, lines[i].IndexOf("=")) > 0)
                        {
                            V = num1 + num2;
                        }
                        else if (lines[i].IndexOf("W", 0, lines[i].IndexOf("=")) > 0)
                        {
                            W = num1 + num2;
                        }
                        i++;
                        continue;
                    }

                }
                if (lines[i].IndexOf(" R")>0)
                {
                    break;
                }
                if (lines[i].IndexOf(" S")>0)
                {
                    break;
                }
                if (lines[i].IndexOf(" P")>0)
                {
                    index = lines[i].IndexOf(" P");
                    if (lines[i].IndexOf("X",index,lines[i].Length-index)>0)
	                {
		                output.AppendLine(X.ToString());
	                }
                    else if (lines[i].IndexOf("Y",index,lines[i].Length-index)>0)
	                {
		                output.AppendLine(Y.ToString());
	                }
                    else if (lines[i].IndexOf("Z",index,lines[i].Length-index)>0)
	                {
		                output.AppendLine(Z.ToString());
	                }
                    else if (lines[i].IndexOf("V",index,lines[i].Length-index)>0)
	                {
		                output.AppendLine(V.ToString());
	                }
                    else if (lines[i].IndexOf("W",index,lines[i].Length-index)>0)
	                {
		                output.AppendLine(W.ToString());
	                }
                    i++;
                    continue;
                }
                if (lines[i].IndexOf(" C")>0)
                {
                    output.Clear();
                    i++;
                    continue;
                }
                if (lines[i].IndexOf(" G")>0)
                {
                    index = lines[i].IndexOf(" G");
                    for (int j = index; j < lines[i].Length; j++)
                    {
                       isNumber = char.IsNumber(lines[i][j]);
                       if (isNumber==true)
                       {
                           int count = 1;
                           for (int k = j + 1; k < lines[i].Length; k++)
                           {
                               if (char.IsNumber(lines[i][k])==false)
                               {
                                   break;
                          
                               }
                               count++;
                           }
                           int now = int.Parse(lines[i].Substring(j,count));
                           for (int ok = 0; ok < lineNumbers.Length; ok++)
			               {
			                    if (now==lineNumbers[ok])
	                            {
                                    i = ok;
                                    break;
	                            }
			               }
                           
                           break;
                       }
                    }
                    continue;
                }
                
            }
            Console.WriteLine(output);
        }
    }
}
