using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword2
{
    class Program
    {
        static string[] words;

        static bool showVariations(int[] array, int[] var, int depth, int pos, int maxDepth)
        {
            long length = array.Length;
            var[depth] = array[pos];
            if (depth == maxDepth - 1)
            {
                if (checkCrossword(var))
                {
                    for (int i = 0; i < var.Length; i++)
                    {
                        Console.WriteLine(words[var[i]]);
                    }
                    return true;
                }


                return false;
            }

            for (int i = 0; i < length; i++)
            {
                if (showVariations(array, var, depth + 1, i, maxDepth))
                {
                    return true;
                }
            }

            return false;
        }

        static bool checkCrossword(int[] variations)
        {
            string[] crossword = new string[variations.Length];

            for (int i = 0; i < crossword.Length; i++)
            {
                crossword[i] = words[variations[i]];
            }


            if (returnWordsInColumn(crossword))
            {
                return true;
            }

            return false;
        }


        static bool returnWordsInColumn(string[] crossword)
        {
            StringBuilder wordsInColumn = new StringBuilder();

            for (int i = 0; i < crossword.Length; i++)
            {
                for (int j = 0; j < crossword.Length; j++)
                {
                    wordsInColumn.Append(crossword[j][i]);
                }
                if (!checkWord(wordsInColumn.ToString()))
                    return false;
                wordsInColumn.Clear();
            }

            return true;
        }

        static bool checkWord(string word)
        {
            for (int i = 0; i < words.Length; i++)
            {
                if (word == words[i])
                    return true;
            }

            return false;
        }

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            
            
            
            
            
            words = new string[n*2];
            /*string word = @"ABC
DEF
GHI
JKL
MNO
PQR";*/
            /*string word = @"FIRE
ACID
CENG
EDGE
FACE
ICED
RING
CERN";*/
            //words = word.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            //DateTime start = DateTime.Now;
            for (int i = 0; i < words.Length; i++)
            {
                words[i] = Console.ReadLine();
            }
            Array.Sort(words);


            int[] array = new int[words.Length];
            for (int i = 0; 
                i < array.Length; i++)
            {
                array[i] = i;
            }
            int[] var = new int[n];
            int depth = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (showVariations(array, var, depth, i, n))
                {
                    return;
                }
            }

            Console.WriteLine("NO SOLUTION!");
            //TimeSpan dif = DateTime.Now - start;
            //Console.WriteLine(dif);
        }
    }
}
