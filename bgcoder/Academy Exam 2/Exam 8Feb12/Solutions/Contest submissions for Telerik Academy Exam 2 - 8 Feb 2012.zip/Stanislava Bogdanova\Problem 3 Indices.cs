using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Problem3Indices
{
    class Problem3Indices
    {
        static Dictionary<long, long> arr = new Dictionary<long, long>();

        
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            ReadArr();
           
        }

        public static void ReadArr()
        {
            int N = int.Parse(Console.ReadLine());
            //int N = 6;


            string expectedValues = Console.ReadLine();
            //string expectedValues = Tekst();
            //string expectedValues = " 1 2 3 5 7 8";
            //string expectedValues = " 1 2 3 5 7 1";
            string[] value = expectedValues.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (N != value.Length)
            {
                throw new InvalidCastException();
            }
            for (int i = 0; i < N; i++)
            {
                arr.Add(i, int.Parse(value[i]));
            }

            Console.WriteLine(GenerateSequence(N));
        }


        public static string GenerateSequence(int N)
        {
            StringBuilder sb = new StringBuilder();
            long k = 0;
           
            bool[] isVisited = new bool[N];
            for (int i = 0; i < N; i++)
            {
                isVisited[i] = false;
            }
            bool isRepeat = false;
            if (N == 1 && arr[0] == 0)
            {
                return "(0)";
            }
            while (!isRepeat)
            {
                    
                        sb.Append(k);
                        sb.Append(" ");
                        isVisited[k] = true;
                        k = arr[k];

                        if (arr.ContainsKey(k))
                        {
                            if (isVisited[k] == true)
                            {
                                
                               string str = sb.ToString();
                               if (str.IndexOf(k.ToString()) == 0)
                               {
                                   sb.Insert(0, '(');
                               }
                               else
                               {
                                   sb.Replace(" " + k.ToString(), "(" + k);
                               }
                               string ddd = (sb.ToString().Trim() + ")").Trim();
                                //return sb.ToString().Trim()+")";
                               return ddd;
                            }
                        }
                        else
                        {
                            return sb.ToString().Trim();
                        }
                 
            }


            return sb.ToString();
        }

        
    }
}
