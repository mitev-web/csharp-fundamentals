using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] array=new string[2*n];
            for (int a = 0; a < 2 * n; a++)
            {
                Console.ReadLine();
            }
            Console.Write("NO SOLUTION!");
        }
    }
}
