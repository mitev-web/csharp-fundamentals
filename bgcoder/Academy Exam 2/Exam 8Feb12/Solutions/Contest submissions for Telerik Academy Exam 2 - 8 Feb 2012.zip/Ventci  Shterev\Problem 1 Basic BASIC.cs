using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P01_BasicBASIC
{
    class BASIC
    {
        static int numV = 0;
        static int numW = 0;
        static int numX = 0;
        static int numY = 0;
        static int numZ = 0;
        static string output = String.Empty;
        static bool CheckCondition(string condition)
        {
            StringBuilder allMeaningfulChars = new StringBuilder();
            foreach (char symbol in condition)
            {
                if (symbol == ' ')
                {
                    continue;
                }
                allMeaningfulChars.Append(symbol);
            }
            string left;
            string right;
            for (int i = 0; i < allMeaningfulChars.Length; i++)
            {
                if (allMeaningfulChars[i] == '<')
                {
                    left = allMeaningfulChars.ToString().Substring(0, i);
                    right = allMeaningfulChars.ToString().Substring(i + 1);
                    int leftNum = 0;
                    if (left == "V")
                    {
                        leftNum = numV;
                    }
                    else if (left == "W")
                    {
                        leftNum = numW;
                    }
                    else if (left == "X")
                    {
                        leftNum = numX;
                    }
                    else if (left == "Y")
                    {
                        leftNum = numY;
                    }
                    else if (left == "Z")
                    {
                        leftNum = numZ;
                    }
                    else
                    {
                        leftNum = int.Parse(left);
                    }
                    int rightNum = 0;
                    if (right == "V")
                    {
                        rightNum = numV;
                    }
                    else if (right == "W")
                    {
                        rightNum = numW;
                    }
                    else if (right == "X")
                    {
                        rightNum = numX;
                    }
                    else if (right == "Y")
                    {
                        rightNum = numY;
                    }
                    else if (right == "Z")
                    {
                        rightNum = numZ;
                    }
                    else
                    {
                        rightNum = int.Parse(right);
                    }
                    if (leftNum < rightNum)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (allMeaningfulChars[i] == '<')
                {
                    left = allMeaningfulChars.ToString().Substring(0, i);
                    right = allMeaningfulChars.ToString().Substring(i + 1);
                    int leftNum = 0;
                    if (left == "V")
                    {
                        leftNum = numV;
                    }
                    else if (left == "W")
                    {
                        leftNum = numW;
                    }
                    else if (left == "X")
                    {
                        leftNum = numX;
                    }
                    else if (left == "Y")
                    {
                        leftNum = numY;
                    }
                    else if (left == "Z")
                    {
                        leftNum = numZ;
                    }
                    else
                    {
                        leftNum = int.Parse(left);
                    }
                    int rightNum = 0;
                    if (right == "V")
                    {
                        rightNum = numV;
                    }
                    else if (right == "W")
                    {
                        rightNum = numW;
                    }
                    else if (right == "X")
                    {
                        rightNum = numX;
                    }
                    else if (right == "Y")
                    {
                        rightNum = numY;
                    }
                    else if (right == "Z")
                    {
                        rightNum = numZ;
                    }
                    else
                    {
                        rightNum = int.Parse(right);
                    }
                    if (leftNum > rightNum)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (allMeaningfulChars[i] == '=')
                {
                    left = allMeaningfulChars.ToString().Substring(0, i);
                    right = allMeaningfulChars.ToString().Substring(i + 1);
                    int leftNum = 0;
                    if (left == "V")
                    {
                        leftNum = numV;
                    }
                    else if (left == "W")
                    {
                        leftNum = numW;
                    }
                    else if (left == "X")
                    {
                        leftNum = numX;
                    }
                    else if (left == "Y")
                    {
                        leftNum = numY;
                    }
                    else if (left == "Z")
                    {
                        leftNum = numZ;
                    }
                    else
                    {
                        leftNum = int.Parse(left);
                    }
                    int rightNum = 0;
                    if (right == "V")
                    {
                        rightNum = numV;
                    }
                    else if (right == "W")
                    {
                        rightNum = numW;
                    }
                    else if (right == "X")
                    {
                        rightNum = numX;
                    }
                    else if (right == "Y")
                    {
                        rightNum = numY;
                    }
                    else if (right == "Z")
                    {
                        rightNum = numZ;
                    }
                    else
                    {
                        rightNum = int.Parse(right);
                    }
                    if (leftNum == rightNum)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return false;
        }
        static void CheckCommand(string command)
        {
            StringBuilder allMeaningfulChars = new StringBuilder();
            foreach (char symbol in command)
            {
                if (symbol == ' ')
                {
                    continue;
                }
                allMeaningfulChars.Append(symbol);
            }
            int indexOfEqual = allMeaningfulChars.ToString().IndexOf('=');
            if (indexOfEqual > 0)
            {
                string left = allMeaningfulChars.ToString().Substring(0, indexOfEqual);
                int leftNum = 0;
                if (left == "V")
                {
                    leftNum = numV;
                }
                else if (left == "W")
                {
                    leftNum = numW;
                }
                else if (left == "X")
                {
                    leftNum = numX;
                }
                else if (left == "Y")
                {
                    leftNum = numY;
                }
                else if (left == "Z")
                {
                    leftNum = numZ;
                }
                else
                {
                    leftNum = int.Parse(left);
                }
                string right = allMeaningfulChars.ToString().Substring(indexOfEqual + 1);
                int rightNum = 0;
                int indexOfPlus = allMeaningfulChars.ToString().IndexOf('+');
                int indexOfMinus = allMeaningfulChars.ToString().IndexOf('-');
                if (indexOfPlus > 0)
                {
                    string leftOfPlus = allMeaningfulChars.ToString().Substring(indexOfEqual + 1, indexOfPlus - indexOfEqual - 1);
                    string rightOfPlus = allMeaningfulChars.ToString().Substring(indexOfPlus + 1);
                    int leftplus = 0;
                    if (leftOfPlus == "V")
                    {
                        leftplus = numV;
                    }
                    else if (leftOfPlus == "W")
                    {
                        leftplus = numW;
                    }
                    else if (leftOfPlus == "X")
                    {
                        leftplus = numX;
                    }
                    else if (leftOfPlus == "Y")
                    {
                        leftplus = numY;
                    }
                    else if (leftOfPlus == "Z")
                    {
                        leftplus = numZ;
                    }
                    else
                    {
                        leftplus = int.Parse(leftOfPlus);
                    }
                    int rightplus = 0;
                    if (rightOfPlus == "V")
                    {
                        rightplus = numV;
                    }
                    else if (rightOfPlus == "W")
                    {
                        rightplus = numW;
                    }
                    else if (rightOfPlus == "X")
                    {
                        rightplus = numX;
                    }
                    else if (rightOfPlus == "Y")
                    {
                        rightplus = numY;
                    }
                    else if (rightOfPlus == "Z")
                    {
                        rightplus = numZ;
                    }
                    else
                    {
                        rightplus = int.Parse(rightOfPlus);
                    }
                    rightNum = leftplus + rightplus;
                }
                else if (indexOfMinus > 0)
                {
                    string leftOfMinus = allMeaningfulChars.ToString().Substring(indexOfEqual + 1, indexOfMinus - indexOfEqual - 1);
                    string rightOfMinus = allMeaningfulChars.ToString().Substring(indexOfMinus + 1);
                    int leftminus = 0;
                    if (leftOfMinus == "V")
                    {
                        leftminus = numV;
                    }
                    else if (leftOfMinus == "W")
                    {
                        leftminus = numW;
                    }
                    else if (leftOfMinus == "X")
                    {
                        leftminus = numX;
                    }
                    else if (leftOfMinus == "Y")
                    {
                        leftminus = numY;
                    }
                    else if (leftOfMinus == "Z")
                    {
                        leftminus = numZ;
                    }
                    else
                    {
                        leftminus = int.Parse(leftOfMinus);
                    }
                    int rightminus = 0;
                    if (rightOfMinus == "V")
                    {
                        rightminus = numV;
                    }
                    else if (rightOfMinus == "W")
                    {
                        rightminus = numW;
                    }
                    else if (rightOfMinus == "X")
                    {
                        rightminus = numX;
                    }
                    else if (rightOfMinus == "Y")
                    {
                        rightminus = numY;
                    }
                    else if (rightOfMinus == "Z")
                    {
                        rightminus = numZ;
                    }
                    else
                    {
                        rightminus = int.Parse(rightOfMinus);
                    }
                    rightNum = leftminus - rightminus; 
                }
                else
                {
                    if (right == "V")
                    {
                        rightNum = numV;
                    }
                    else if (right == "W")
                    {
                        rightNum = numW;
                    }
                    else if (right == "X")
                    {
                        rightNum = numX;
                    }
                    else if (right == "Y")
                    {
                        rightNum = numY;
                    }
                    else if (right == "Z")
                    {
                        rightNum = numZ;
                    }
                    else
                    {
                        rightNum = int.Parse(right);
                    }
                }
                if (left == "V")
                {
                    numV = rightNum;
                }
                if (left == "W")
                {
                    numW = rightNum;
                }
                if (left == "X")
                {
                    numX = rightNum;
                }
                if (left == "Y")
                {
                    numY = rightNum;
                }
                if (left == "Z")
                {
                    numZ = rightNum;
                }
            }
            int indexOfPRINT = allMeaningfulChars.ToString().IndexOf("PRINT");
            if (indexOfPRINT >= 0)
            {
                string left = allMeaningfulChars.ToString().Substring(indexOfPRINT + 5);
                if (left == "V")
                {
                    output = output + String.Format("{0}",numV);
                }
                if (left == "W")
                {
                    output = output + String.Format("{0}", numV);
                }
                if (left == "X")
                {
                    output = output + String.Format("{0}", numV);
                }
                if (left == "Y")
                {
                    output = output + String.Format("{0}", numV);   
                }
                if (left == "Z")
                {
                    output = output + String.Format("{0}", numV);
                }
                output = output + "\r\n";
            }
            int indexOfCLS = allMeaningfulChars.ToString().IndexOf("CLS");
            if (indexOfCLS >= 0)
            {
                output = String.Empty;
            }
        }
        static void Main(string[] args)
        {
            List<string> inputLines = new List<string>();
            do
            {
                string inputLine = Console.ReadLine();
                inputLines.Add(inputLine);
            }
            while (inputLines[inputLines.Count - 1] != "RUN");
            string[] codeLines = new string[10000];
            for (int i = 0; i < inputLines.Count - 1; i++)
            {
                int tempIndex = inputLines[i].IndexOf(' ');
                string tempStr = inputLines[i].Substring(0, tempIndex);
                int codeIndex = int.Parse(tempStr);
                codeLines[codeIndex] = inputLines[i].Substring(tempIndex + 1);
            }            
            for (int i = 0; i < codeLines.Length; i++)
            {
                
                if (codeLines[i] == null)
                {
                    continue;
                }
                else
                {
                    int indexofIF = codeLines[i].IndexOf("IF");
                    if (indexofIF >= 0)
                    {
                        int indexOfTHEN = codeLines[i].IndexOf("THEN");
                        string condition = codeLines[i].Substring(indexofIF + 2, indexOfTHEN - 2);
                        string command = codeLines[i].Substring(indexOfTHEN + 4);
                        int indexOFGOTO = command.IndexOf("GOTO");
                        int indexOfSTOP = command.IndexOf("STOP");
                        if (indexOFGOTO >= 0)
                        {
                            string address = command.Substring(indexOFGOTO + 4);
                            address.Trim();
                            i = int.Parse(address) - 1;
                        }
                        else if (indexOfSTOP >= 0)
                        {
                            Console.WriteLine(output);
                            break;
                        }
                        else
                        {
                            if (CheckCondition(condition))
                            {
                                CheckCommand(command);
                            }
                        }
                    }
                    else
                    {
                        int indexOFGOTO = codeLines[i].IndexOf("GOTO");
                        int indexOfSTOP = codeLines[i].IndexOf("STOP");
                        if (indexOFGOTO >= 0)
                        {
                            string address = codeLines[i].Substring(indexOFGOTO + 4);
                            address.Trim();
                            i = int.Parse(address) - 1;
                        }
                        else if (indexOfSTOP >= 0)
                        {
                            Console.WriteLine(output);
                            break;
                        }
                        else
                        {
                            CheckCommand(codeLines[i]);
                        }
                        Console.WriteLine(output);
                    }               
                }
            }
        }
    }
}
