using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem03
{
    class Problem03
    {
        static int[] numbers;
        static int num;
        static int last = 0;

        static void Read()
        {
            num = int.Parse(Console.ReadLine());

            string line = Console.ReadLine();

            string[] tokens = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            numbers = new int[num];


            for (int i = 0; i < tokens.Length; i++)
            {
                numbers[i] = int.Parse(tokens[i]);
            }

        }

        static void Rec(int n)
        {
            int[] a = new int[200003];

            a[0] = 0;
            a[1] = numbers[0];

            for (int i = 2; i < num; i++)
            {
                a[i] = numbers[a[i - 1]];


                for (int t = 0; t < i; t++)
                {
                    if (a[i] == a[t])
                    {
                        int k;
                        for (k = 0; k < t-1; k++)
                        {
                            Console.Write("{0} ", a[k]);
                        }
                        Console.Write(a[k]);

                        Console.Write("(");
                        
                        for (k = t; k < i -1 ; k++)
                        {
                            Console.Write("{0} ", a[k]);
                        }
                        Console.WriteLine("{0})", a[k]);

                        break;

                    }
                }


                if (a[i] > num - 1 || a[i] < 0)
                {
                    int j;
                    for (j = 0; j < i - 1; j++)
                    {
                        Console.Write("{0} ", a[j]);
                    }
                    Console.WriteLine(a[j]);
                    break;
                }


            }

        }


        static void Main()
        {
            Read();
            //Console.Write("0");
            Rec(0);
        }
    }
}
