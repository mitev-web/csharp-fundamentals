using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BombingCuboids
{
    class Program
    {
        static int width, height, depth;
        static char[, ,] cuboid;
        static int[,] heights;
        static int[] colors;
        static int numberDestroyedCubes = 0;

        static double findDistance(int bombW, int bombH, int bombD, int cubeW, int cubeH, int cubeD)
        {
            return Math.Sqrt((bombW - cubeW) * (bombW - cubeW) + (bombH - cubeH) * (bombH - cubeH) + (bombD - cubeD) * (bombD - cubeD));
        }

        static void destroyCube(int bombW, int bombH, int bombD, double p)
        {
            for (int w = 0; w < width; w++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int h = 0; h < heights[w,d]; h++)
                    {
                        if (cuboid[w, h, d] != '-')
                        {
                            if (findDistance(bombW, bombH, bombD, w, h, d) <= p)
                            {
                                colors[(int)cuboid[w, h, d] - 65]++;
                                numberDestroyedCubes++;
                                cuboid[w, h, d] = '-';
                            }
                        }
                    }
                }
            }
        }

        static void gravitation()
        {

            for (int w = 0; w < width; w++)
            {
                for (int d = 0; d < depth; d++)
                {
                    int destroyed = 0;
                    Queue<char> colours = new Queue<char>();

                    for (int h = 0; h < heights[w,d]; h++)
                    {
                        if (cuboid[w, h, d] == '-')
                        {
                            destroyed++;
                        }
                        else
                        {
                            colours.Enqueue(cuboid[w, h, d]);
                        }
                    }
                    if (destroyed > 0)
                    {
                        heights[w, d] -= destroyed;
                        for (int h = 0; h < heights[w,d]; h++)
                        {
                            cuboid[w, h, d] = colours.Dequeue();
                        }
                        /*for (int h = height - destroyed; h < height; h++)
                        {
                            cuboid[w, h, d] = '-';
                        }
                        */
                    }
                }
            }
        }





        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);
            cuboid = new char[width, height, depth];
            colors = new int[26];

            heights = new int[width, depth];
            for (int w = 0; w < width; w++)
            {
                for (int d = 0; d < depth; d++)
                {
                    heights[w, d] = height;
                }
            }
            // Read the cuboid data

            /*string lines = @"BRYYYYY RYYYYGY YRYYYYY
YYYGBGY YYYYGGG YYYGGGY
RYBYGYY RYYYYGY RYBYGBB
RYBYGYY RBYYGYY RYBYGBB";
            string[] newLines = lines.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            */
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                //string line = newLines[h];
                string[] letters = line.Split();
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        cuboid[w, h, d] = letters[d][w];
                    }
                }
            }
        }

        static void detonateBombs()
        {
            int n = int.Parse(Console.ReadLine());
            int[,] coords = new int[n, 3];
            double[] power = new double[n];
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                string[] coordsAndpower = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                int W = int.Parse(coordsAndpower[0]);
                int H = int.Parse(coordsAndpower[1]);
                int D = int.Parse(coordsAndpower[2]);
                double P = double.Parse(coordsAndpower[3]);
                destroyCube(W, H, D, P);
                gravitation();
            }


            Console.WriteLine(numberDestroyedCubes);
            for (int i = 0; i < 26; i++)
            {
                if (colors[i] != 0)
                {
                    Console.WriteLine("{0} {1}", (char)(i + 65), colors[i]);
                }
            }

        }

        static void Main(string[] args)
        {
            //Read the cuboid
            ReadCuboid();

            //Detonate
            detonateBombs();

        }
    }
}
