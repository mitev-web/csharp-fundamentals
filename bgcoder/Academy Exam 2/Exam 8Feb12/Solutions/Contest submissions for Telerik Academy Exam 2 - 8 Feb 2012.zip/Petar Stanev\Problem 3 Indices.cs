using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam2
{
    class Program
    {        
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            int n = int.Parse(Console.ReadLine());
            string text = Console.ReadLine();
            //int n = 6;
            //string text = "1 2 3 5 7 1";
            string[] splittedText = text.Split(' ');
            int[] arr = new int[splittedText.Length];
            for (int i = 0; i < splittedText.Length; i++)
            {
                arr[i] = int.Parse(splittedText[i]);           
            }
            int num = arr[0];
            sb.Append("0 " + num + " ");                     
            int[] visited = new int[n];           
            int nextNum = 0;
            if (num <= n)
            {
                while (true)
                {
                    if (num >= n)
                    {
                        break;
                    }
                    visited[num] = 1;
                    nextNum = arr[num];
                    if (nextNum >= n)
                    {
                        break;
                    }
                    sb.Append(nextNum + " ");
                    visited[nextNum] = 1;
                    num = arr[nextNum];
                    if (num >= n)
                    {
                        break;
                    }
                    if (visited[num] == 1)
                    {
                        sb.Insert(num, '(');
                        sb.Append(')');
                        break;
                    }
                    sb.Append(num + " ");
                }
                string oldScope1 = "( ";
                string oldScope3 = " (";
                string oldScope2 = " )";
                string newScope1 = "(";
                string newScope2 = ")";
                string result = sb.ToString();
                string finalResult = result.Replace(oldScope1, newScope1);
                finalResult = finalResult.Replace(oldScope2, newScope2);
                finalResult = finalResult.Replace(oldScope3, newScope1);
                finalResult = finalResult.TrimEnd(' ');
                Console.WriteLine(finalResult);
            }
            else
            {
                Console.WriteLine(0 + " " + num);
            }                    
        }
    }
}
