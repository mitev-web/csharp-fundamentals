using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword
{
    class Program
    {


        static void Main()
        {

            int number = int.Parse(Console.ReadLine());

            string[] words = new string[number * 2];

            for (int i = 0; i < 2 * number; i++)
            {
                words[i] = Console.ReadLine();

            }
            
            StringBuilder builder = new StringBuilder(2*number*number);

            foreach (string value in words)
            {
                builder.Append(value);

            }

            StringBuilder allNewWords = new StringBuilder(2*number);
           
            for (int j = 0; j < number; j++)
            {
                for (int i = 0; i < builder.Length / 2; i = i + number)
                {
                    allNewWords.Append(builder[j + i]);
                }
                allNewWords.Append(".");

            }


            for (int j = 0; j < number; j++)
            {
                for (int i = builder.Length / 2; i < builder.Length; i = i + number)
                {
                    allNewWords.Append(builder[j + i]);
                }
                allNewWords.Append(".");
            }
            builder.Clear();

            List<string> crossword = new List<string>();
            string result = allNewWords.ToString();
            string[] cr = result.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
            
            foreach (var item in cr)
            {
                crossword.Add(item);

            }
            
            List<string> worsInCrossword = new List<string>();

            foreach (var item in crossword)
            {
                foreach (var word in words)
                {
                    if (word == item)
                    {
                        worsInCrossword.Add(item);                        
                    }
                }                         
            }
          
            int count = worsInCrossword.Count;           
                 
            if (count == 0)
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                foreach (var item in worsInCrossword)
                {
                    Console.WriteLine(item);
                }       
            }

        }
    }
}
