using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _5.Tasks
{
	class Tasks
	{
		static int[] pleasantness;
		static int variaty;
		static List<int> counters = new List<int>();

		static void Solve(int currentElem, int currentMin, int currentMax, int currentlySkiped, int currentlySolved)
		{
			if (currentElem >= pleasantness.Length || currentlySkiped > (currentElem / 2))
			{
				return;
			}

			currentlySolved++;
			if (pleasantness[currentElem] < currentMin)
			{
				currentMin = pleasantness[currentElem];
			}
			if (pleasantness[currentElem] > currentMax)
			{
				currentMax = pleasantness[currentElem];
			}
			if (currentMax - currentMin >= variaty)
			{
				counters.Add(currentlySolved);
				return;
			}
			Solve(currentElem + 1, currentMin, currentMax, currentlySkiped, currentlySolved);
			currentlySkiped++;
			Solve(currentElem + 2, currentMin, currentMax, currentlySkiped, currentlySolved);
			currentlySkiped--;
			return;
		}

		static void Main(string[] args)
		{
			string[] temp = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
			variaty = int.Parse(Console.ReadLine());
			pleasantness = new int[temp.Length];
			for (int i = 0; i < pleasantness.Length; i++)
			{
				pleasantness[i] = int.Parse(temp[i]);
			}

			Solve(0, pleasantness[0], pleasantness[0], 0, 0);
			if (counters.Count > 0)
			{
				Console.WriteLine(counters.Min());
			}
			else
			{
				Console.WriteLine(pleasantness.Length);
			}
		}
	}
}
