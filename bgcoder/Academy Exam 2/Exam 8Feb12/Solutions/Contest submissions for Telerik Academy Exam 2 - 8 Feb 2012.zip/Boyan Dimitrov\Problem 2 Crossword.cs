using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CrossWord_Ex2ver2
{
    class Program
    {
        static string[] givenWordsArr;
        static StringBuilder tempWord;
        static int count = 0;
        static void Print(string[] currentCrossBoard) 
        {
            foreach (var item in currentCrossBoard)
            {
                Console.WriteLine(item);
            }
        }

        static void CheckWords(string[] currentCrossBoard)
        {
            char[,] currentCharArr = new char[currentCrossBoard.Length, currentCrossBoard.Length];
            for (int i = 0; i < currentCrossBoard.Length; i++)
            {
                for (int j = 0; j < currentCrossBoard[i].Length; j++)
                {
                    currentCharArr[i, j] = currentCrossBoard[i][j];
                }
            }

            for (int i = 0; i < currentCharArr.GetLength(1); i++)
            {
                tempWord = new StringBuilder();
                for (int j = 0; j < currentCharArr.GetLength(0); j++)
                {
                    tempWord.Append(currentCharArr[j, i]);
                }
                for (int j = 0; j < givenWordsArr.Length; j++)
                {
                    if (tempWord.ToString() == givenWordsArr[j])
                    {
                        count++;
                    }
                }
            }
            if (count >= currentCharArr.GetLength(1))
            {
                Print(currentCrossBoard);
            }
        }
        static void PermWord(int index, string[] currentCrossBoard) 
        {
            if (index >= currentCrossBoard.Length)
            {
                CheckWords(currentCrossBoard);
            }
            else
            {
                for (int i = 0; i < givenWordsArr.Length; i++)
                {
                    currentCrossBoard[index] = givenWordsArr[i];
                    PermWord(index + 1, currentCrossBoard);
                }
            }
        }

        static void Main(string[] args)
        {
            int iterations;
            int givenWords;
            string[] currentCrossBoard;
            string consoleLine = Console.ReadLine();
            iterations = int.Parse(consoleLine);
            givenWords = iterations * 2;
            givenWordsArr = new string[givenWords];
            currentCrossBoard = new string[iterations];
            
 
            for (int i = 0; i < givenWords; i++)
            {
                consoleLine = Console.ReadLine();
                givenWordsArr[i] = consoleLine;
            }
            PermWord(0, currentCrossBoard);

        }
    }
}
