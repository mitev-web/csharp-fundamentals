using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02.CrosswordNew
{
    class CrosswordNew
    {
        static string[] HorizontWord(string[] arr, int n, string[] originalArr)
        {
            List<string> words = new List<string>();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    string word = "";
                    for (int f = j; f < n + j; f++)
                    {
                        word += arr[f][i];
                    }
                    for (int k = 0; k < originalArr.Length; k++)
                    {
                        if (word == originalArr[k])
                        {
                            words.Add(word);
                        }
                    }
                }
            }
            
            string[] wordsArray = new string[words.Count];
            for (int i = 0; i < wordsArray.Length; i++)
            {
                wordsArray[i] = words[i];
            }
            return wordsArray;
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] array = new string[n * 2];

            for (int i = 0; i < array.Length; i++)
            {
                array[i] = Console.ReadLine();
            }

            string[] firstWords = HorizontWord(array, n, array);

            if (firstWords.Length != 0)
            {
                foreach (var item in firstWords)
                {
                    Console.WriteLine(item);
                }
            }
            else
            {
                Console.WriteLine("NO SOLUTION!");
            }


        }
    }
}
