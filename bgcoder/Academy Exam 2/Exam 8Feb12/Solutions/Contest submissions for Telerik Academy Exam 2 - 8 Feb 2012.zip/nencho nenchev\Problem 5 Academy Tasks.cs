using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace RealExamII
{
    class Program
    {
        static void Main(string[] args)
        {
            AcademyTasks();
        }

        static void AcademyTasks()
        {
            string input = Console.ReadLine();
            string[] numbers = Regex.Split(input, ", ");
            int zeroProblem = int.Parse(numbers[0]);
            int variety = int.Parse(Console.ReadLine());
            int result = 1;
            int currentProblem = 0;
            int nextProblem = 0;

            int length = numbers.Length - 1;
            for (int i = 0; i < length; i++)
            {
                currentProblem = int.Parse(numbers[i]);
                nextProblem = int.Parse(numbers[i + 1]);
                if (Math.Abs(currentProblem - nextProblem) >= variety)
                {
                    result++;
                    break;
                }
                else
                {
                    i++;
                    result++;
                    
                    if (Math.Abs((currentProblem - zeroProblem)) >= variety) break;
                }
            }

            Console.WriteLine(result);
        }
    }
}
