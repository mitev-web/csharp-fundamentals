using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class Program
    {
        static int[] check;
        static bool flag = true;

        static void GoThrough(int index, int prevIndex, int[] array)
        {
            if (index < 0 || index > array.Length - 1)
            {
                return;
            }

            if (check[index] == 1)
            {
                check[index] = -1;
                check[prevIndex] = -1;
                return;
            }
            else 
            {
                check[index] = 1;
            }

            GoThrough(array[index], index, array);
        }

        static void Print (int index, int prevIndex, int[] array)
        {
            if (index < 0 || index > array.Length - 1)
            {
                return;
            }

            if (check[index] == -1 && flag && index == array[index])
            {
                Console.Write("(" + index + ")");
                flag = false;
                check[index] = 0;
                return;
            }
            if (check[index] == - 1 && flag)
            {
                Console.Write("(" + index);
                flag = false;
            }
            else if (check[index] == -1)
            {
                Console.Write(" " + index + ")");
                return;
            }
            else if (index == 0)
            {
                Console.Write(index);
            }
            else if (check[index] == 1)
            {
                Console.Write(" " + index);
            }

            Print(array[index], index, array);
        }

        static void Main(string[] args)
        {
            int length = int.Parse(Console.ReadLine());

            string[] separators = { " " };
            string[] input = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int[] array = new int[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                array[i] = int.Parse(input[i]);
            }  

            check = new int[array.Length];
           
            GoThrough(0, 0, array);
            Print(0, 0, array);
            Console.WriteLine();
        }
    }
}
