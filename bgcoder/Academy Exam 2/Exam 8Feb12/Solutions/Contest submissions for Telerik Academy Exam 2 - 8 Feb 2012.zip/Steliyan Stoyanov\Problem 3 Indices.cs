using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _03_Indices
{
    class Program
    {
        static int n;
        static int[] arr;
        static bool[] visited;

        static int circularIndex = -1;
        static StringBuilder result = new StringBuilder();

        static void Read(StreamReader reader)
        {
            n = int.Parse(reader.ReadLine());

            arr = new int[n];
            visited = new bool[n];

            string line = reader.ReadLine();
            string[] parsed = line.Split(new char[] { ' '}, StringSplitOptions.RemoveEmptyEntries);

            for(int i = 0; i < parsed.Length; i++)
                arr[i] = int.Parse(parsed[i]);
        }

        static void Print(int index)
        {
            if(index >= n )
                return;

            if(visited[index] == true)
            {
                circularIndex = index;
                //result.Append(index);

                return;
            }

            visited[index] = true;
            result.Append(index + " ");

            Print(arr[index]);
        }

        static void Print2(int i)
        {
            if(i >= n)
                return;
            Console.WriteLine(arr[i]);
            Print2(arr[i]);
        }

        static void Main(string[] args)
        {
            Read(new StreamReader(Console.OpenStandardInput()));

            Print(0);
            
            
            if(circularIndex != -1)
            {
                string toMatch = " " + circularIndex;
                string toReplace = "(" + circularIndex;

                int match = result.ToString().IndexOf(toMatch);

                if(match == -1)
                    result.Insert(0, '(');

                result = result.Replace(toMatch, toReplace);

                result[result.Length - 1] = ')';
            }
            

            string output = result.ToString().Trim();

            Console.WriteLine(output);
        }
    }
}
