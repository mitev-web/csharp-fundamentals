using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _04.TheCube
{
    class TheCube
    {
        public struct Bomb
        {
            public int col;
            public int row;
            public int layer;
            public int dist;
        }
        static int counterstrice = 0;
        static int cols;
        static int rows;
        static int layers;
        static char[, ,] cube;


        static void Explosion(Bomb bomb)
        {
            char bombChar = cube[bomb.row, bomb.col, bomb.layer];
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    for (int layer = 0; layer <layers; layer++)
                    {
                        double dist = Math.Sqrt((row - bomb.row) * (row - bomb.row) + (col - bomb.col) * (col - bomb.col) + (layer - bomb.layer) * (layer - bomb.layer));
                        if (dist <= bomb.dist)
                        {
                            cube[row, col, layer] = '0';
                        }
                    }
                }
            }
        }

        static void FallDown()
        {
            for (int col = 0; col < cols; col++)
            {
                for (int layer = 0; layer < layers; layer++)
                {
                    int emptyRow = 0;
                    while(emptyRow < rows && cube[emptyRow,col,layer] =='0')
                    {
                        emptyRow++;
                    }
                    if (emptyRow > 0)
                    {
                        for (int i = emptyRow; i < rows; i++)
                        {
                            cube[i - emptyRow, col, layer] = cube[i, col, layer];
                            cube[i, col, layer] = '0';
                        }
                    }

                }
            }
        }

        static void Main()
        {
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            int[] startlLettCount = new int[26];
            int[] endlLettCount = new int[26];



            string[] dimensions = Console.ReadLine().Split();
            cols = int.Parse(dimensions[0]);
            rows = int.Parse(dimensions[1]);
            layers = int.Parse(dimensions[2]);
            cube = new char[rows, cols, layers];
            
            for (int row = 0; row < rows; row++)
			{
                string[] line = Console.ReadLine().Split();
                for (int layer = 0; layer <layers; layer++)
                {
                    for (int col = 0; col < cols; col++)
                    {
                        cube[row, col, layer] = line[layer][col];
                    }
                }

			}


            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    for (int layer = 0; layer < layers; layer++)
                    {

                        for (int i = 0; i < 26; i++)
                        {
                            if (letters[i] == cube[row, col, layer])
                                startlLettCount[i]++;
                        }
                    }
                }
            }
            int bombCount = int.Parse(Console.ReadLine());
            List<Bomb> bombs = new List<Bomb>();
            for (int i = 0; i < bombCount; i++)
			{
                Bomb bomb = new Bomb();
                string[] line = Console.ReadLine().Split();
                bomb.col = int.Parse(line[0]);
                bomb.row = int.Parse(line[1]);
                bomb.layer = int.Parse(line[2]);
                bomb.dist = int.Parse(line[3]);
                bombs.Add(bomb);
			}


            for (int i = 0; i < bombCount; i++)
            {
                
                Explosion(bombs[i]);
                FallDown();
            }


            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    for (int layer = 0; layer < layers; layer++)
                    {

                        for (int i = 0; i < 26; i++)
                        {
                            if (letters[i] == cube[row, col, layer])
                                endlLettCount[i]++;
                        }
                    }
                }
            }

            int startSum = 0;
            int endSum = 0;
            for (int i = 0; i < 26; i++)
            {
                startSum += startlLettCount[i];
                endSum += endlLettCount[i];
            }
            Console.Write(startSum-endSum);
            for (int i = 0; i < 26; i++)
            {
                if (startlLettCount[i] > endlLettCount[i])
                {
                    Console.WriteLine();
                    Console.Write(letters[i] + " " + (startlLettCount[i] - endlLettCount[i]));
                }
            }


            
        }
    }
}