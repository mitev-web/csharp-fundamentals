using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Task02
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            
                string[] ko = new string[2*n];
                for (int i = 0; i < ko.Length; i++)
                {
                    ko[i] = Console.ReadLine();
                }
                Console.WriteLine(ko[1]);
                
            
              
            
        }
    }
}
