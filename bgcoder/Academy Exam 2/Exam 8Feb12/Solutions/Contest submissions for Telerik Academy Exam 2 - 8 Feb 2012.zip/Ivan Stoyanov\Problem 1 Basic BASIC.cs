using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex1
{
    class Program
    {
        //static bool enteredInGOTO = false;

        static int elCounter = 0;
        static void Main(string[] args)
        {
            StringBuilder[] lines = new StringBuilder[10001];
            int[] indexes = new int[10001];
            //bool isEnd = false;
            //int elCounter = 0;
            int i = 0;
            while (true)
            {                
                string tmp = Console.ReadLine();
                if (tmp == "RUN") { elCounter = i; break; }
                lines[i] = new StringBuilder();
                lines[i].Append(tmp);
                StringBuilder tmpNum = new StringBuilder();
                int j = 0;
                while (lines[i][j] != ' ' && lines[i][j] != '\t' && lines[i][j] != '\n')
                {
                    tmpNum.Append(lines[i][j]);
                    j++;
                }
                indexes[i] = int.Parse(tmpNum.ToString());
                i++;
            }

            int x = 0;
            int y = 0;
            int z = 0;
            int w = 0;
            int v = 0;

            StringBuilder[] finalOutput = new StringBuilder[10000];
            bool foundS = false;
            int CountWritedLines = 0;
            for (i = 0; i < elCounter; i++)
            {
                if(!foundS)
                {
                    for (int j = 0; j < lines[i].Length; j++)
                    {
                        if (!(lines[i][j] == ' ' || lines[i][j] == '\t'))
                        {
                            if (lines[i][j] == 'X')
                            {
                                x = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                break;
                            }
                            else if (lines[i][j] == 'Y')
                            {
                                y = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                break;
                            }
                            if (lines[i][j] == 'Z')
                            {
                                z = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                break;
                            }
                            else if (lines[i][j] == 'V')
                            {
                                v = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                break;
                            }
                            else if (lines[i][j] == 'W')
                            {
                                w = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                break;
                            }
                            else if (lines[i][j] == 'S')
                            {
                                foundS = true;
                                break;
                            }                            
                            else if (lines[i][j] == 'P')
                            {
                                StringBuilder bla = new StringBuilder();
                                j += 5;                                
                                while (true)
                                {
                                    if(lines[i][j]!=' ' && lines[i][j]!='\t') bla.Append(lines[i][j]);
                                    j++;
                                    if (j >= lines[i].Length) break;
                                }
                                finalOutput[CountWritedLines] = new StringBuilder();
                                if (bla[0] == 'X') finalOutput[CountWritedLines].Append((int)x);
                                else if (bla[0] == 'Y') finalOutput[CountWritedLines].Append((int)y);
                                else if (bla[0] == 'Z') finalOutput[CountWritedLines].Append((int)z);
                                else if (bla[0] == 'V') finalOutput[CountWritedLines].Append((int)v);
                                else if (bla[0] == 'W') finalOutput[CountWritedLines].Append((int)w);
                                else finalOutput[CountWritedLines].Append((int)int.Parse(bla.ToString()));
                                CountWritedLines++;
                                break;
                            }
                            else if (lines[i][j] == 'C')
                            {
                                for (int s = 0; s < CountWritedLines; s++)
                                {
                                    finalOutput[s].Clear();
                                }
                                CountWritedLines = 0;
                                break;
                            }
                            else if (lines[i][j] == 'I')
                            {
                                j += 2;
                                bool theIf = FoundLettarLittleChange(lines, i, ref x, y, z, w, v, ref j);
                                if (theIf == false) break;
                                else
                                {
                                    for( ; j < lines[i].Length; j++)
                                    {
                                        if (lines[i][j] == 'N') break;
                                    }
                                    j++;

                                        for (; j < lines[i].Length; j++)
                                        {
                                            if (lines[i][j] != ' ' || lines[i][j] != '\t')
                                            {
                                                if (lines[i][j] == 'X')
                                                {
                                                    x = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                                    break;
                                                }
                                                else if (lines[i][j] == 'Y')
                                                {
                                                    y = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                                    break;
                                                }
                                                if (lines[i][j] == 'Z')
                                                {
                                                    z = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                                    break;
                                                }
                                                else if (lines[i][j] == 'V')
                                                {
                                                    v = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                                    break;
                                                }
                                                else if (lines[i][j] == 'W')
                                                {
                                                    w = FoundLettar(lines, i, ref x, y, z, w, v, ref j);
                                                    break;
                                                }
                                                else if (lines[i][j] == 'G')
                                                {
                                                    GOTO(lines, indexes, ref i, ref j);
                                                }
                                            }
                                        }
                                }
                                break;
                            }
                            else if (lines[i][j] == 'G')
                            {
                                j += 4;
                                //StringBuilder tmpRow = new StringBuilder();
                                GOTO(lines, indexes, ref i, ref j);
                            }
                        }
                    }
                }
            }

            //print
            for (int k = 0; k < CountWritedLines; k++)
            {
                Console.WriteLine(finalOutput[k]);
            }
            
        }

        private static void GOTO(StringBuilder[] lines, int[] indexes, ref int i, ref int j)
        {
            int tmpRow = 0;
            for (; j < lines[i].Length; j++)
            {
                if (lines[i][j] != ' ' && lines[i][j] != '\t')
                {
                    if (lines[i][j] >= '0' && lines[i][j] <= '9')
                    {
                        StringBuilder tmpx = new StringBuilder();
                        while (lines[i][j] != ' ' && lines[i][j] != '\t' && lines[i][j] != '\n')
                        {
                            tmpx.Append(lines[i][j]);
                            j++;
                            if (j >= lines[i].Length) break;
                        }
                        tmpRow = int.Parse(tmpx.ToString());
                        break;
                    }
                }
            }
            for (int k = 0; k < indexes.Length; k++)
            {
                if (indexes[k] == tmpRow)
                {
                    i = k - 1;
                    break;
                }
            }
        }

        private static int FoundLettar(StringBuilder[] lines, int i, ref int x, int y, int z, int w, int v, ref int j)
        {
            for (j = j + 1; j < lines[i].Length; j++)
            {
                if (lines[i][j] == '=')
                {
                    int? a = null;
                    int? b = null;
                    char op = ' ';
                    for (j = j + 1; j < lines[i].Length; j++)
                    {
                        if (lines[i][j] != ' ' && lines[i][j] != '\t')
                        {
                            if (lines[i][j] == 'X') { if (a == null) a = x; else b = x; }
                            else if (lines[i][j] == 'Y') { if (a == null) a = y; else b = y; }
                            else if (lines[i][j] == 'Z') { if (a == null) a = z; else b = z; }
                            else if (lines[i][j] == 'W') { if (a == null) a = w; else b = w; }
                            else if (lines[i][j] == 'V') { if (a == null) a = v; else b = v; }
                            if (lines[i][j] == '-') op = '-';
                            if (lines[i][j] == '+') op = '+';                   
                            if (lines[i][j] >= '0' && lines[i][j] <= '9')
                            {
                                StringBuilder tmpx = new StringBuilder();
                                while (lines[i][j] != ' ' && lines[i][j] != '\t' && lines[i][j] != '\n')
                                {
                                    tmpx.Append(lines[i][j]);
                                    j++;
                                    if (j >= lines[i].Length) break;
                                }
                                { if (a == null) a = int.Parse(tmpx.ToString()); else b = int.Parse(tmpx.ToString()); }
                            }
                        }
                    }
                    if (a != null && b != null)
                    {
                        if (op == '-') return (int)a - (int)b;
                        else return (int)a + (int)b;
                    }
                    else if (a != null)
                    {
                        if (op == '-') return -(int)a;
                        else return (int)a;
                    }
                    break;
                }
            }
            return 0;
        }

        private static bool FoundLettarLittleChange(StringBuilder[] lines, int i, ref int x, int y, int z, int w, int v, ref int j)
        {
            
                int? a = null;
                int? b = null;
                char op = ' ';
                for (j = j + 1; j < lines[i].Length; j++)
                {
                    if (lines[i][j] != ' ' && lines[i][j] != '\t')
                    {
                        if (lines[i][j] == 'X') { if (a == null) a = x; else b = x; }
                        else if (lines[i][j] == 'Y') { if (a == null) a = y; else b = y; }
                        else if (lines[i][j] == 'Z') { if (a == null) a = z; else b = z; }
                        else if (lines[i][j] == 'W') { if (a == null) a = w; else b = w; }
                        else if (lines[i][j] == 'V') { if (a == null) a = v; else b = v; }
                        //if (lines[i][j] == '-') op = '-';
                        //if (lines[i][j] == '+') op = '+';
                        if (lines[i][j] == '<') op = '<';
                        if (lines[i][j] == '>') op = '>';
                        if (lines[i][j] == '=') op = '=';
                        if (lines[i][j] >= '0' && lines[i][j] <= '9')
                        {
                            StringBuilder tmpx = new StringBuilder();
                            while (lines[i][j] != ' ' && lines[i][j] != '\t' && lines[i][j] != '\n')
                            {
                                tmpx.Append(lines[i][j]);
                                j++;
                                if (j >= lines[i].Length) break;
                            }
                            { if (a == null) a = int.Parse(tmpx.ToString()); else b = int.Parse(tmpx.ToString()); }
                        }
                    }
                }
                    
                if (a != null && b != null)
                {
                    if (op == '>') { if (a > b) return true; else return false; }
                    else if (op == '<') { if (a < b) return true; else return false; }
                    else if (op == '=') { if (a == b) return true; else return false; }
                }    
                
            return false;
        }


        private static int FoundLettarLittleMoreChange(StringBuilder[] lines,ref int i, ref int x, int y, int z, int w, int v, ref int j, int[] indexes)
        {
            for (j = j + 1; j < lines[i].Length; j++)
            {
                if (lines[i][j] == '=')
                {
                    int? a = null;
                    int? b = null;
                    char op = ' ';
                    for (j = j + 1; j < lines[i].Length; j++)
                    {
                        if (lines[i][j] != ' ' && lines[i][j] != '\t')
                        {
                            if (lines[i][j] == 'X') { if (a == null) a = x; else b = x; }
                            else if (lines[i][j] == 'Y') { if (a == null) a = y; else b = y; }
                            else if (lines[i][j] == 'Z') { if (a == null) a = z; else b = z; }
                            else if (lines[i][j] == 'W') { if (a == null) a = w; else b = w; }
                            else if (lines[i][j] == 'V') { if (a == null) a = v; else b = v; }
                            else if (lines[i][j] == 'G')
                            {
                                GOTO(lines, indexes, ref i, ref j);
                            }
                            if (lines[i][j] == '-') op = '-';
                            if (lines[i][j] == '+') op = '+';
                            if (lines[i][j] >= '0' && lines[i][j] <= '9')
                            {
                                StringBuilder tmpx = new StringBuilder();
                                while (lines[i][j] != ' ' && lines[i][j] != '\t' && lines[i][j] != '\n')
                                {
                                    tmpx.Append(lines[i][j]);
                                    j++;
                                    if (j >= lines[i].Length) break;
                                }
                                { if (a == null) a = int.Parse(tmpx.ToString()); else b = int.Parse(tmpx.ToString()); }
                            }
                        }
                    }
                    if (a != null && b != null)
                    {
                        if (op == '-') return (int)a - (int)b;
                        else return (int)a + (int)b;
                    }
                    else if (a != null)
                    {
                        if (op == '-') return -(int)a;
                        else return (int)a;
                    }
                    break;
                }
            }
            return 0;
        }

       
    }
}