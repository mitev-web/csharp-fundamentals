using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _05_AcadaemyTask
{
    class Program
    {
        static int variety;
        static int[] pleasentness;

        static void Read(StreamReader reader)
        {
            string line = reader.ReadLine();
            string[] parsed = line.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

            pleasentness = new int[parsed.Length];

            for(int i = 0; i < parsed.Length; i++)
                pleasentness[i] = int.Parse(parsed[i]);
                
            variety = int.Parse(reader.ReadLine());
        }

        static void Main(string[] args)
        {
            Read(new StreamReader(Console.OpenStandardInput()));
            //Read(new StreamReader("c:/52.txt"));

            int min = pleasentness[0];
            int max = pleasentness[0];

            bool check = false;
            bool skipped = false;
            int count = 1;

            for(int i = 1; i < pleasentness.Length ; i++)
            {
                if(max - min >= variety)
                {
                    check = true;
                    break;
                }

                if(max < pleasentness[i])
                    max = pleasentness[i];

                if(min > pleasentness[i])
                    min = pleasentness[i];

                if(max - pleasentness[i] >= variety)
                {
                    count++;
                    check = true;
                    break;
                }

                if(pleasentness[i] - min >= variety)
                {
                    count++;
                    check = true;
                    break;
                }

                if(skipped)
                {
                    count++;
                    skipped = false;
                    continue;
                }
                else
                {
                    skipped = true;
                }
            }

            if(max - min < variety)
                count = pleasentness.Length;

            Console.WriteLine(count);
        }
    }
}
