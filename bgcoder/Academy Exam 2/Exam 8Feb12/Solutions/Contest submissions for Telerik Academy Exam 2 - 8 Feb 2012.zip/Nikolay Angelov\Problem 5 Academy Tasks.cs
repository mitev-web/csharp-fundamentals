using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex5
{
    class Program
    {
        public static int min(List<int> list)
        {
            int min = int.MaxValue;
	        foreach (int number in list)
	        {
	            if (number < min)
                {
                    min = number;
	            }
	        }
            return min;
        }
        public static int max(List<int> list)
        {
            int max = int.MinValue;
            foreach (int number in list)
            {
                if (number > max)
                {
                    max = number;
                }
            }
            return max;
        }
        static void Main(string[] args)
        {
            char[] delimiterChars = { ',', ' '};

            string pleasant = Console.ReadLine();
            int variety = int.Parse(Console.ReadLine());
            string[] pleasantness = pleasant.Split(delimiterChars, StringSplitOptions.RemoveEmptyEntries);

            int length = pleasantness.Length;
            int[] tasks = new int[length];

            // Convert it to int[]
            for (int i = 0; i < length; i++)
            {
                tasks[i] =  int.Parse(pleasantness[i]);
            }

            List<int> solution = new List<int>();

            int current = 0;
            int next = 0;
            int nextNext = 0;

            for (int i = 2; i < length; i++)
            {
                current = tasks[i - 2];
                next = tasks[i - 1];
                nextNext = tasks[i];
                solution.Add(current);
                if (i == length - 1)
                {
                    solution.Add(nextNext);
                }
                else if (i == length - 2)
                {
                    solution.Add(nextNext);
                }

                if (max(solution) - min(solution) >= variety)
                {
                    Console.WriteLine(solution.Count);
                    break;
                }

                bool result1 = (current - next) >= variety;
                bool result2 = (next - current) >= variety;
                bool result3 = (current - nextNext) >= variety;
                bool result4 = (nextNext - current) >= variety;
                if ((result1 || result2))
                {
                    solution.Add(next);
                    Console.WriteLine(solution.Count);
                    break;
                }
                else if (result3 || result4)
                {
                    solution.Add(nextNext);
                    Console.WriteLine(solution.Count);
                    break;
                }
                else
                {
                    i++;
                }
            }
        }
    }
}