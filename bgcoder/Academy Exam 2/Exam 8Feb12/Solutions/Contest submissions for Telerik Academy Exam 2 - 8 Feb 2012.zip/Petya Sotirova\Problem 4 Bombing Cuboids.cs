using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BombingCuboids
{
    class Program
    {
        static char[, ,] cube;
        static SortedDictionary<char,int> destroy=new SortedDictionary<char,int>();

        private static void ReadCube()
        {
            for (int j = 0; j < cube.GetLength(1); j++)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(Console.ReadLine());
                int index = 0;


                for (int k = 0; k < cube.GetLength(2); k++)
                {
                    for (int i = 0; i < cube.GetLength(0); i++)
                    {
                        cube[i, j, k] = sb[index];
                        index++;
                    }
                    index++;
                }
            }
            
        }

        static void Explode(byte w, byte h, byte d, byte power)
        {
            for (int i = 0; i < cube.GetLength(0); i++)
            {
                for (int j = 0; j < cube.GetLength(1); j++)
                {
                    for (int k = 0; k < cube.GetLength(2); k++)
                    {
                        if(Math.Sqrt((w - i) * (w - i) + (h - j) * (h - j) + (d - k) * (d - k))<=power)
                        {
                            if(destroy.ContainsKey(cube[i,j,k]))
                            {
                                destroy[cube[i, j, k]]++;
                            }
                            else
                            {
                                if(cube[i,j,k]>='A'&&cube[i,j,k]<='Z')
                                destroy.Add(cube[i, j, k], 1);
                            }
                            cube[i, j, k] = ' ';
                        }
                    }
                }   
            }

            Gravity();
        }

        static void Gravity()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < cube.GetLength(0); i++)
            {
                for (int j = 0; j < cube.GetLength(1); j++)
                {
                    for (int k = 0; k < cube.GetLength(2); k++)
                    {
                        if (cube[i, j, k] != ' ')
                        {
                            sb.Append(cube[i, j, k]);
                        }
                    }
                    int sbIndex=0;
                    for (int h = 0; h <cube.GetLength(2); h++)
                    {
                        if (sbIndex < sb.Length)
                        {
                            cube[i, j, h] = sb[sbIndex];
                            sbIndex++;
                        }
                        else
                            break;
                    }
                    sb.Clear();
                    }
                }
            }

        
        static void Main(string[] args)
        {
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            byte w = byte.Parse(sizes[0]);
            byte h = byte.Parse(sizes[1]);
            byte d = byte.Parse(sizes[2]);
            cube = new char[w, h, d];
            ReadCube();

            byte n = byte.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string bomb = Console.ReadLine();
                string[] b = bomb.Split(' ');
                byte wBomb = byte.Parse(b[0]);
                byte hBomb = byte.Parse(b[1]);
                byte dBomb = byte.Parse(b[2]);
                byte power = byte.Parse(b[3]);

                Explode(wBomb, hBomb, dBomb, power);
            }

            int sum = 0;
            foreach (var item in destroy)
            {
                sum += item.Value;
            }

            Console.WriteLine(sum);

            foreach (var item in destroy)
            {
                Console.WriteLine("{0} {1}",item.Key,item.Value);
            }
            
        }
    }
}
