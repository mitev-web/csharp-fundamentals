using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task5
{
    class Program
    {


        static void Main(string[] args)
        {
           int n = int.Parse(Console.ReadLine());
           string text = Console.ReadLine();
           string[] strings = text.Split(' ');
            int[] numArray = strings.Select(x => int.Parse(x)).ToArray();
          
            Console.Write("{0}", 0);
            int index = 0;
            findMin(numArray, index + 1);
           





        }

        public static int findMin(int[] array, int index)
        {


            if (index + 1 >= array.Length)
            {


                return array[index];


            }

            else
            {


                Console.Write(" " + "{0}",array[(index - 1)]);
            
                return Math.Min(array[index], findMin(array, index + 1));



            }





        }
    }
}