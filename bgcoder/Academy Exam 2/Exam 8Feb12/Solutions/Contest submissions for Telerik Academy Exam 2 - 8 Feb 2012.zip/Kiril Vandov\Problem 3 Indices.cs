using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

class Indices
{
    static void Main(string[] args)
    {
        
        int numbersCount;
        //StreamReader reader = new StreamReader("t1.txt");
        //using (reader)
        //{
            numbersCount = int.Parse(Console.ReadLine());
            numbers = Console.ReadLine().Split(' ');
            foreach (var item in numbers)
            {
                numz.Add(item);
            }
        //}
        vizitedNumbers = new bool[numbersCount];
        //int index = Array.IndexOf(numbers, "5");
        Solve(0);
    }
    static StringBuilder rezult = new StringBuilder();
    static List<string> numz = new List<string>();
    static List<int> list = new List<int>();
    static string[] numbers;
    static bool[] vizitedNumbers;
    static bool solved;
    static bool cicle;
    static void Solve(int index)
    {
        if (solved)
        {
            return;
        }

        if (cicle)
        {
            StringBuilder build = new StringBuilder();
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].ToString() == numbers[index])
                {
                    string newBuild = build.ToString().Trim() + "(" + list[i]+ " ";
                    build.Clear();
                    build.Append(newBuild);
                    continue;
                }
                build.Append(list[i] + " ");
            }
            Console.WriteLine(build.ToString().Trim() + ")");
            solved = true;
            return;
        }

        if (index==-1|| index>numz.Count-1)
        {
            StringBuilder build = new StringBuilder();
            for (int i = 0; i < list.Count; i++)
            {
                build.Append(list[i] + " ");
            }
            Console.WriteLine(build.ToString().Trim());
            solved = true;
            return;
        }
        vizitedNumbers[index] = true;
        //string value = numbers[index];
        string value = numz[index];
        list.Add(index);
        //index = Array.IndexOf(numbers, value);
        index = numz.IndexOf(value);
        int newIndex = int.Parse(value);
        if (newIndex < numbers.Length && vizitedNumbers[newIndex])
        {
            cicle = true;
            Solve(index);
        }
        Solve(newIndex);
    }
}
