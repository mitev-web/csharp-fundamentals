using System;
using System.Collections.Generic;
using System.Text;

namespace Problem3_Indices
{
    class Indices
    {
        static int seqCounter = 0;
        static void Main(string[] args)
        {
            string consoleInputLine = Console.ReadLine();
            int n = int.Parse(consoleInputLine);
            int[] arr = new int[n];
            consoleInputLine = Console.ReadLine();
            char[] separators = { ' ' };
            string[] numbers = consoleInputLine.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < numbers.Length; i++)
            {
                arr[i] = int.Parse(numbers[i]);
            }

            //Random randNum = new Random();

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    arr[i] = randNum.Next(0, 2001);
            //}
            //int[] arr = { 3, 2, 1, 4, 5, 1 };
            bool[,] arrBool = new bool[arr.Length, 3];
            List<int> sequence = new List<int>();
            int index = 0;
            int indexOpenBracket = - 1;

            while (index >= 0 && index < arr.Length)
            {
                if (arrBool[index, 0] == false)
                {
                    sequence.Add(index);
                    seqCounter++;
                    arrBool[index, 0] = true;
                    index = arr[index];
                }
                else
                {
                    if (arrBool[index, 1] == false)
                    {
                        arrBool[index, 1] = true;
                        index = arr[index];
                    }
                    else
                    {
                        for (int i = 0; i < arr.GetLength(0); i++)
                        {
                            if (arrBool[i, 1] == true)
                            {
                                indexOpenBracket = - 2;
                                break;
                            }
                        }
                        if (indexOpenBracket != -1)
                        {
                            break;
                        }
                    }
                }
            }
            int counter = 0;
            for (int i = 0; i < arrBool.GetLength(0); i++)
            {
                if (arrBool[i, 1] == true)
                {
                    counter++;
                }
            }
            if (counter > 0)
            {
                indexOpenBracket = sequence.Count - counter;
            }
            //end of while  
            StringBuilder result = new StringBuilder();
            int cc = 0;
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                
                if (arrBool[i, 0] == true)
                {
                    if (i != indexOpenBracket)
                    {
                        result.Append(string.Format("{0} ", sequence[cc]));
                        cc++;
                    }
                    else
                    {
                        result.Append('(');
                        result.Append(string.Format("{0} ", sequence[cc]));
                        cc++;
                    }
                }
            }
            if (indexOpenBracket != -1)
            {
                result.Append(')');
                result = result.Replace(" )", ")");
                result = result.Replace(" (", "(");
                Console.Write(result);
            }
            else
            {
                Console.Write(result.ToString().Trim());
            }
        }
    }
}