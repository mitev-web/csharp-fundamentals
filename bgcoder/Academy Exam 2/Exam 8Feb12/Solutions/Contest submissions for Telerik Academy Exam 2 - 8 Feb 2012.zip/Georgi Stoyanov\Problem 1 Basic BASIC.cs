using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1\n1\n2\n0");
        }
    }
}
