using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cube
{
    class Point
    {
        public int w,h,d;
        public Point(int w=0,int h=0,int d=0)
        {
            this.w = w;
            this.h = h;
            this.d = d;
        }
    }
    class Bomb
    {
        public Point pos;
        public int power;
        public Bomb(Point pos,int p=0)
        {
            this.pos = new Point(pos.w, pos.h, pos.d);
            this.power = p;
        }
    }
    class Cube
    {
        static int CubesDestroyed;
        static int[] colors= new int[30];
        static int w, h, d, n;
        static char[,,] cube = new char[105,105,105];
        static Bomb[] bombs= new Bomb[25];
        static double Distance(Point a, Point b)
        {
            double result = Math.Sqrt((a.w-b.w)*(a.w-b.w)+(a.d-b.d)*(a.d-b.d)+(a.h-b.h)*(a.h-b.h));
            return result;
        }
        static void Gravity()
        {
            for (int i = 0; i < h; i++)
            {
                for (int j = 0; j < d; j++)
                {
                    for (int k = 0; k < w; k++)
                    {
                        if (cube[k, i, j] == '*')
                        {
                            int hole = i + 1;
                            while (hole < h && cube[k, hole, j] == '*') hole++;
                            int m = hole;
                            while (m < h && cube[k, m, j] != '*')
                            {
                                cube[k, m - (hole-i), j] = cube[k, m, j];
                                cube[k, m, j] = '*';
                                m++;
                            }
                        }
                    }
                }
            }
        }
        static void DetonateBomb(Bomb bomb)
        {
            for(int i=0;i<h;i++)
            {
                for (int j = 0; j < d; j++)
                {
                    for (int k = 0; k < w; k++)
                    {
                        if (cube[k,i,j]!='*' && Distance(bomb.pos, new Point(k, i, j)) <= bomb.power)
                        {
                            CubesDestroyed++;
                            colors[cube[k, i, j] - 'A']++;
                            cube[k, i, j] = '*';
                        }
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            string[] items = (Console.ReadLine()).Split(' ');
            w=int.Parse(items[0]);
            h=int.Parse(items[1]);
            d=int.Parse(items[2]);
            cube = new char[w, h, d];
            for (int i = 0; i < h; i++)
            {
                items = (Console.ReadLine()).Split(' ');
                for (int j = 0; j < d; j++)
                {
                    for (int k = 0; k < w; k++)
                    {
                        cube[k, i, j]=items[j][k];
                    }
                }
            }
            n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                items = (Console.ReadLine()).Split(' ');
                bombs[i] = new Bomb(new Point(int.Parse(items[0]),int.Parse(items[1]),int.Parse(items[2])),int.Parse(items[3]));
            }
            for (int i = 0; i < n; i++)
            {
                DetonateBomb(bombs[i]);
                Gravity();
            }
            Console.WriteLine(CubesDestroyed);
            for (int i = 0; i < 26; i++)
            {
                if (colors[i] != 0) Console.WriteLine((char)('A' + i) + " "+ colors[i]);
            }
        }
        
    }
}
