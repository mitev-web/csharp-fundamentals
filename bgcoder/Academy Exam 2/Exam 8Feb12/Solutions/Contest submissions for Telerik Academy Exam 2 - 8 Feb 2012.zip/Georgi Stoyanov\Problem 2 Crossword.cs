using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace task2
{
    class Program
    {
        private const int maxSize = 6;
        private static char[,] field = new char[maxSize, maxSize];
        public static bool foundSolution = false;
        public static string solution = "";

        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            string[] words = new string[size * 2];
            int[] backTrack = new int[size * 2];

            for (int i = 0; i < size * 2; i++)
            {
                words[i] = Console.ReadLine();
            }
            //Console.WriteLine();
            Array.Sort(words, string.Compare);

            Variations(backTrack, size, size, words);

            if (solution == "")
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                Console.WriteLine(solution);
            }
        }

        static private void Variations(int[] backTrack, int length, int k, string[] words)
        {
            if (!foundSolution)
            {
                if (k == 0)
                {
                    GenerateMatrix(backTrack, words);
                    foundSolution = IsSolution(words, length);
                    if (foundSolution)
                    {
                        solution = PrintField(length);
                    }
                    return;
                }

                int size = length * 2;
                for (int i = 0; i < size; i++)
                {
                    
                    bool canUse = false;
                    for (int checkWords = 0; checkWords < size; checkWords++)
                    {
                        if (words[i][0] == words[checkWords][length - k])
                            canUse = true;
                    }
                    if (canUse)
                    {
                        backTrack[length - k] = i;
                        Variations(backTrack, length, k - 1, words);
                    }
                }
            }
        }

        private static void GenerateMatrix(int[] positions, string[] words)
        {
            int size = words.Length / 2;
                for (int rows = 0; rows < size; rows++)
                {
                    for (int cols = 0; cols < size; cols++)
                    {
                        field[rows, cols] = words[positions[rows]][cols];
                    }
                }            
        }

        private static string[] GenerateWords(int length)
        {
            StringBuilder newWord = new StringBuilder();

            string[] words = new string[length];
            for (int cols = 0; cols < length; cols++)
            {
                for (int rows = 0; rows < length; rows++)
                {
                    newWord.Append(field[rows, cols]);
                }
                words[cols] = newWord.ToString();
                newWord.Clear();
            }

            return words;
        }

        private static bool IsSolution(string[] allWords, int length)
        {
            /* generate all words */
            StringBuilder newWord = new StringBuilder();

            string[] words = new string[length];
            for (int cols = 0; cols < length; cols++)
            {
                for (int rows = 0; rows < length; rows++)
                {
                    newWord.Append(field[rows, cols]);
                }
                words[cols] = newWord.ToString();
                newWord.Clear();
            }

            bool noMatch = false;
            for (int wordsInWords = 0; wordsInWords < words.Length; wordsInWords++)
            {
                if (noMatch)
                    break;

                noMatch = true;
                for (int wordsInAllWords = 0; wordsInAllWords < allWords.Length; wordsInAllWords++)
                {
                    bool match = true;
                    for (int letters = 0; letters < length; letters++)
                    {
                        if (words[wordsInWords][letters] != allWords[wordsInAllWords][letters])
                        {
                            match = false;
                        }
                        
                    }
                    if (match)
                    {
                            noMatch = false;
                    }/*
                    if (Regex.Match(words[wordsInWords], allWords[wordsInAllWords]).Success)
                    {
                        noMatch = false;
                        break;
                    }
                      * */
                }                
            }

            return !noMatch;
        }

        private static string PrintField(int length)
        {
            StringBuilder output = new StringBuilder();
            for (int rows = 0; rows < length; rows++)
            {
                for (int cols = 0; cols < length; cols++)
                {
                    output.Append(field[rows, cols]);
                }
                output.Append('\n');
            }

            return output.ToString();
        }
    }
}
