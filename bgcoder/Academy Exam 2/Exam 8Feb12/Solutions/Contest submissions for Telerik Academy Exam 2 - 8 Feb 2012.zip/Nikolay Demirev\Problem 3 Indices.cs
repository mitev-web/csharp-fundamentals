using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];
            bool[] visited = new bool[n];

            string[] numbers = Console.ReadLine().Split(' ');

            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(numbers[i]);
            }

            List<int> sequence = new List<int>();

            int index = 0;

            while (index >= 0 && index < n && !visited[index])
            {
                visited[index] = true;
                sequence.Add(index);
                index = arr[index];
            }

            if (index >= 0 && index < n && visited[index])
            {
                int printed = 0;
                bool isClosed = false;
                for (int i = 0; i < sequence.Count; i++)
                {
                    if (index == i)
                    {
                        printed++;
                        Console.Write("({0}", sequence[i]);
                    }
                    else if (i < sequence.Count - 1)
                    {
                        if (printed == 0)
                        {
                            printed++;
                            Console.Write("{0}", sequence[i]);
                        }
                        else
                        {
                            printed++;
                            Console.Write(" {0}", sequence[i]);
                        }
                    }
                    else
                    {
                        printed++;
                        isClosed = true;
                        Console.Write(" {0})", sequence[i]);
                    }
                }
                if (!isClosed)
                {
                    Console.Write(')');
                }
            }

            if (index < 0 || index >= n)
            {
                Console.Write("{0}", 0);
                for (int i = 1; i < sequence.Count; i++)
                {
                    Console.Write(" {0}", sequence[i]);
                }
            }
        }
    }
}
