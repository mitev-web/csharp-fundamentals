using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Academy_Task
{
    class Program
    {
        static int counter;
        static double oneHop;
        static double twoHops;

        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] del = new char[] { ' ', ',' };
            string[] nums = input.Split(del,StringSplitOptions.RemoveEmptyEntries);

            int[] pleasantness = new int[nums.Length];

            for (int i = 0; i < nums.Length;i++ )
            {
                pleasantness[i] = int.Parse(nums[i]);
            }
            /*pleasantness[0] = 6;
            pleasantness[1] = 2;
            pleasantness[2] = 6;
            pleasantness[3] = 2;
            pleasantness[4] = 6;
            pleasantness[5] = 3;
            pleasantness[6] = 3;
            pleasantness[7] = 3;
            pleasantness[8] = 7;*/

            List<int> solved = new List<int>();
            solved.Add(pleasantness[0]);
            counter = 1;
            int variety = int.Parse(Console.ReadLine());
            
            
                FindNextTask(pleasantness,variety,solved);
           

            Console.WriteLine(counter);
            foreach (var task in solved)
            {
               // Console.WriteLine(task);
            }
            
        }

        static void FindNextTask(int[] pl, int var,List<int> solved)
        {
            for (int i = 1; i < pl.Length-1; i++)
            {
                oneHop =  Math.Abs((pl[i] - solved.Min()));
                //Console.WriteLine(oneHop);
                twoHops = Math.Abs(pl[i + 1] - solved.Min());
                //Console.WriteLine(twoHops);

                if (oneHop >= var)
                {
                    solved.Add(pl[i]);
                    counter++;
                    break;
                }
                else if (twoHops >= var)
                {
                    solved.Add(pl[i+1]);
                    counter++;
                    break;
                     
                }
                else if (oneHop == twoHops)
                {
                    counter++;
                    solved.Add(pl[i + 1]);
                    i++;
                }
                else if (oneHop < twoHops)
                {
                    solved.Add(pl[i + 1]);
                    counter++;
                    i++;
                }
                else if (oneHop > twoHops)
                {
                    solved.Add(pl[i]);
                    counter++;
                }


            }
            
        }
    }
}
