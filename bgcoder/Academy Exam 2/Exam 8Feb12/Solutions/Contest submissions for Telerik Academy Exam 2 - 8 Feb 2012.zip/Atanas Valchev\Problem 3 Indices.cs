using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int N = int.Parse(input);
            input = Console.ReadLine();
            char[] separator = {' '};
            string[] split = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int[] ARR = new int[N];
            for (int i = 0; i < ARR.Length; i++)
            {
                ARR[i] = int.Parse(split[i]);
            }
            StringBuilder sb = new StringBuilder();

            try
            {
                Indice(ARR, 0, sb);
            }
            catch (IndexOutOfRangeException)
            {
                string result = sb.ToString().TrimEnd(' ');
                Console.WriteLine(result);
                
            }
            
            
        }
        static void Indice(int[] nums, int start, StringBuilder sb)
        {

            if (start<=nums.Length)
            {
                sb.Append(Convert.ToString(start));
                sb.Append(' ');
            }
           //if (nums[start] < start)
           // {
           //     return;
           // }

            
            Indice(nums, nums[start], sb);
        }
    }
}
