using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices_Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            long[] array;
            long firstEl;
            bool firstBracket = false;
            bool repeatedEl = false;
            int repeatedElStartIndex = 0;
            int repeatElEndIndex = 0;
            string[] stringEl;
            string consoleLine = Console.ReadLine();
            int iterations = int.Parse(consoleLine);
            array = new long[iterations];
            consoleLine = Console.ReadLine();
            stringEl = consoleLine.Split(' ');
            for (int i = 0; i < stringEl.Length; i++)
            {
                array[i] = long.Parse(stringEl[i]);
            }
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[i] == array[j])
                    {
                        repeatedEl = true;
                        firstBracket = true;
                        repeatElEndIndex = j;
                        repeatedElStartIndex = i;
                    }
                }
            }
            Console.Write("0");
            firstEl = array[0];
            if (array[repeatedElStartIndex] == firstEl && repeatedEl)
            {
                Console.Write("(" + firstEl);
                firstBracket = false;
            }
            else
            {
                Console.Write(" " + firstEl);
            }
            while (array[firstEl] < array.Length)
            {
                if (repeatedEl)
                {
                    firstEl = array[firstEl];
                    if (array[repeatedElStartIndex] == firstEl && firstBracket)
                    {
                        Console.Write("(" + firstEl);
                        firstBracket = false;
                        
                    }
                    if (array[repeatElEndIndex] == firstEl && firstBracket == false)
                    {
                        Console.Write(")");
                        return;
                    }
                    else
                    {
                        Console.Write(" " + firstEl);
                    }
                    
                    
                }
                else
                {
                    firstEl = array[firstEl];
                    Console.Write(" " + firstEl);
                }
                
            }
            
            
        }
    }
}
