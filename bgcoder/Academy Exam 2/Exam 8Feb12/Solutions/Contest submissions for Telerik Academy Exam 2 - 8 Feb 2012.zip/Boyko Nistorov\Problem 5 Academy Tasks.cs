using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class Program
    {
        static int FindMaxIndex(int[] arr, int variety)
        {
            int maxIndex = -1;

            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (Math.Abs(arr[i] - arr[j]) >= variety)
                    {
                        return Math.Max(i, j);
                    }
                }
            }
            return maxIndex;
        }
        static void Main(string[] args)
        {
            string[] separators = {", "};
            string[] input = Console.ReadLine().Split(separators, StringSplitOptions.RemoveEmptyEntries);

            int[] pleasantness = new int [input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                pleasantness[i] = int.Parse(input[i]);
            }          

            int variety = int.Parse(Console.ReadLine());

            int result = pleasantness.Length;
            int maxIndex = FindMaxIndex(pleasantness, variety);

            if (maxIndex != -1)
            {
                if (pleasantness.Length == 1)
                {
                    result = 1;
                }
                else
                {
                    result = (maxIndex + 1) / 2 + 1;
                }               
            }

            Console.WriteLine(result);
        }
    }
}
