using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace AcademyTask
{
    class Program
    {
        static int variety;
        static int[] pleasant;
        static int shortest = int.MaxValue;
        static int?[] problemsSolved;
        static int PSCount;

        static void FindShortest(int problem)
        {
            int? min = problemsSolved.Min();
            int? max = problemsSolved.Max();

            if (PSCount >= shortest)
            {
                return;
            }

            if (max - min >= variety)
            {
                if (shortest > PSCount)
                {
                    shortest = PSCount;
                }
                return;
            }

            if (problem >= pleasant.Length)
            {
                if (shortest > pleasant.Length)
                {
                    shortest = pleasant.Length;
                }
                return;
            }

            problemsSolved[PSCount++] = pleasant[problem];

            FindShortest(problem + 1);
            
            FindShortest(problem + 2);
            PSCount--;
            problemsSolved[PSCount] = null;
        }

        static int[] ReadPleasant()
        {
            List<int> nums = new List<int>();
            StringBuilder num = new StringBuilder();

            string line = Console.ReadLine();
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == ',')
                {
                    nums.Add(int.Parse(num.ToString()));
                    i++;
                    num.Clear(); 
                }
                else
                {
                    num.Append(line[i]);
                }
            }

            nums.Add(int.Parse(num.ToString()));
            return nums.ToArray();
        }

        static void Main(string[] args)
        {
            pleasant = ReadPleasant();

            variety = int.Parse(Console.ReadLine());

            problemsSolved = new int?[50];
            problemsSolved[0] = pleasant[0];
            PSCount = 1;

            if (variety > pleasant.Max() - pleasant.Min())
            {
                Console.WriteLine(pleasant.Length);
            }
            else
            {
                FindShortest(1);
                FindShortest(2);

                Console.WriteLine(shortest);
            }

        }
    }
}
