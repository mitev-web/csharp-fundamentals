using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace basicBASIC
{
    class Program
    {
        static void Main(string[] args)
        {
            int V = 0, W = 0, X = 0, Y = 0, Z = 0;
            int value = 0, eValue = 0;
            StringBuilder print = new StringBuilder();
            bool ifValue = false;
            bool printValue = false;
            bool CLS = false;
            bool STOP = false;
            bool RUN = false;
            bool then = false;
            bool Vis = false;
            bool Wis = false;
            bool Xis = false;
            bool Yis = false;
            bool Zis = false;
            bool firstSpace = false;
            bool GOTO = false;
            bool equal = false;
            bool smaller = false;
            bool greater = false;
            bool haveVal2 = false;
            bool firstTimeHere = true;
            int goLine=0;
            bool minus = false;
            bool plus = false;
            bool operators = false;
            int numLine;
            int momentIndex=0;
            string somethng;
            List<string> lines = new List<string>();
            List<int> activeLines = new List<int>();
            for (int i = 0; i < 10001; i++)
            {
                lines.Add("");
            }
            StringBuilder whatIs = new StringBuilder();
            StringBuilder num = new StringBuilder();
            string line = Console.ReadLine();
            
            while (line != "RUN")
            {
                if (STOP == true)
                {
                    break;
                }
                for (int i = 0; i < line.Length; i++)
                {
                    
                    if (line[i] == ' ' && firstSpace == false)
                    {
                        firstSpace = true;
                        if (GOTO==false)
                        {
                            numLine = int.Parse(whatIs.ToString());
                            lines.Insert(numLine, line);
                            activeLines.Add(numLine);
                        }
                        
                        whatIs.Clear();
                    }
                    if (whatIs.ToString() == "PRINT")
                    {
                        string prints = line.Substring(i).Trim();
                        if (prints == "V")
                        {
                            Print(V, print); 
                        }
                        if (prints == "W")
                        {
                            Print(W, print); 
                        }
                        if (prints == "X")
                        {
                            Print(X, print); 
                        }
                        if (prints == "Y")
                        {
                            Print(Y, print); 
                        }
                        if (prints == "Z")
                        {
                            Print(Z, print); 
                        }
                        whatIs.Clear();
                        i = line.Length;
                    }
                    if (whatIs.ToString() == "STOP")
                    {
                        STOP = true;
                        break;
                    }
                    if (whatIs.ToString() == "CLS")
                    {
                        Clear(print);
                    }
                    if (whatIs.ToString() == "V=")
                    {
                        int val = V;
                        CalculatePrase(line, num, V, W, X, Y, Z, ref minus, ref plus, ref val, i);
                        i = line.Length - 1;
                        V = val;
                    }
                    if (whatIs.ToString() == "W=")
                    {
                        int val = W;
                        CalculatePrase(line, num, V, W, X, Y, Z, ref minus, ref plus, ref val, i);
                        i = line.Length - 1;
                        W = val;
                    }
                    if (whatIs.ToString() == "X=")
                    {
                        int val = X;
                        CalculatePrase(line, num, V, W, X, Y, Z, ref minus, ref plus, ref val, i);
                        i = line.Length - 1;
                        X = val;
                    }
                    if (whatIs.ToString() == "Y=")
                    {
                        int val = Y;
                        CalculatePrase(line, num, V, W, X, Y, Z, ref minus, ref plus, ref val, i);
                        i = line.Length - 1;
                        Y = val;
                    }
                    if (whatIs.ToString() == "Z=")
                    {
                        int val = Z;
                        CalculatePrase(line, num, V, W, X, Y, Z, ref minus, ref plus, ref val, i);
                        i = line.Length - 1;
                        Z = val;
                    }
                    if (whatIs.ToString() == "IF")
                    {
                        int val1 = 0,val2 = 0;
                        operators = false;
                        smaller = false;
                        equal = false;
                        greater = false;
                        StringBuilder sbNum = new StringBuilder();
                        for (int j = i; j < line.Length ; j++)
                        {
                            if (line[j] != ' ')
                            {
                                if (operators == false)
                                {
                                    if (line[j] == 'V')
                                    {
                                        val1 = V;
                                    }
                                    else if (line[j] == 'W')
                                    {
                                        val1 = W;
                                    }
                                    else if (line[j] == 'X')
                                    {
                                        val1 = X;
                                    }
                                    else if (line[j] == 'Y')
                                    {
                                        val1 = Y;
                                    }
                                    else if (line[j] == 'Z')
                                    {
                                        val1 = Z;
                                    }
                                    else
                                    {
                                        sbNum.Append(line[j]);
                                    }
                                    operators = true;
                                }
                                else if (operators == true && line[j]!=' ')
                                {
                                    if (line[j] == '<')
                                    {
                                        smaller = true;
                                    }
                                    else if (line[j] == '>')
                                    {
                                        greater = true;
                                    }
                                    else if (line[j] == '=')
                                    {
                                        equal = true;
                                    }
                                    else if (line[j] == 'V')
                                    {
                                        val2 = V;
                                        haveVal2 = true;
                                    }
                                    else if (line[j] == 'W')
                                    {
                                        val2 = W;
                                        haveVal2 = true;
                                    }
                                    else if (line[j] == 'X')
                                    {
                                        val2 = X;
                                        haveVal2 = true;
                                    }
                                    else if (line[j] == 'Y')
                                    {
                                        val2 = Y;
                                        haveVal2 = true;
                                    }
                                    else if (line[j] == 'Z')
                                    {
                                        val2 = Z;
                                        haveVal2 = true;
                                    }
                                    else
                                    {
                                        sbNum.Append(line[j]);
                                    }
                                }
                            }
                            else if (line[j] == ' ' && operators == false && sbNum.Length != 0)
                            {
                                val1 = int.Parse(sbNum.ToString());
                                sbNum.Clear();
                            }
                            else if (line[j] == ' ' && (equal == true || smaller == true || greater == true) && sbNum.Length != 0)
                            {
                                val2=int.Parse(sbNum.ToString());
                                sbNum.Clear();
                                haveVal2 = true;
                            }

                            if (line[j] == ' ' && haveVal2)
                            {
                                haveVal2 = false;
                                if (equal == true)
                                {
                                    if (ifEqual(val1, val2))
                                    {
                                        i = j;
                                        j = line.Length;
                                        whatIs.Clear();
                                        continue;
                                    }
                                    else
                                    {
                                        i = line.Length - 1;
                                        break;
                                    }
                                }
                                else if (smaller)
                                {
                                   if( ifSmaller(val1,val2))
                                    {
                                        i = j;
                                        j = line.Length;
                                        whatIs.Clear();
                                        continue;
                                    }
                                   else
                                   {
                                       i = line.Length - 1;
                                       break;
                                   }
                                }
                                else if (greater)
                                {
                                    if (ifGreater(val1, val2))
                                    {
                                        i = j;
                                        j = line.Length;
                                        whatIs.Clear();
                                        continue;
                                    }
                                    else
                                    {
                                        i = line.Length - 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (whatIs.ToString()=="THEN")
                    {
                        then = true;
                        whatIs.Clear();
                    } 
                    if (whatIs.ToString() == "GOTO")
                    {
                        GOTO = true;
                        string whatLineNum=line.Substring(i).Trim();
                        goLine =  int.Parse(whatLineNum);

                        numLine = goLine;
                        i = line.Length-1;
                        whatIs.Clear();
                    }
                    if (i==line.Length)
                    {
                        i = line.Length - 1;
                    }
                    if (line[i] != ' ')
                    {
                        whatIs.Append(line[i]);
                    }
                }
                if (whatIs.ToString() == "CLS")
                {
                    Clear(print);
                    whatIs.Clear();
                }
                if (whatIs.ToString() == "STOP")
                {
                    STOP = true;
                }
                whatIs.Clear();
                firstSpace = false;
                then = false;
                
                if (GOTO==true)
                {
                    
                    line = lines[goLine];
                    
                    if (firstTimeHere == true)
                    {
                        momentIndex = activeLines.IndexOf(goLine);
                        firstTimeHere = false;
                        
                    }
                    else
                    {
                        if (momentIndex == activeLines.Count-1)
                        {
                            GOTO = false;
                            firstTimeHere = true;
                            momentIndex = 0;
                            whatIs.Clear();
                        }
                        else
                        {
                            whatIs.Clear();
                            momentIndex++;
                            goLine = activeLines[momentIndex];
                            line = lines[goLine];
                          
                        
                            numLine = goLine;
                             
                        }
                        if (momentIndex == activeLines.Count - 1)
                        {
                            firstTimeHere = true;
                        }
                    }
                }
                if (GOTO == false)
                {
                    line = Console.ReadLine();
                }
                
            }
            Console.WriteLine(print.ToString());
        }
  
        private static void CalculatePrase(string line, StringBuilder num, int V, int W, int X, int Y, int Z, ref bool minus, ref bool plus, ref int val, int i)
        {
            for (int j = i ; j < line.Length; j++)
            {
                if (line[j] == '-')
                {
                    minus = true;
                    j++;
                }
                if (line[j] == '+')
                {
                    plus = true;
                    j++;
                }
                              
                if (line[j] != ' ' && (minus == false && plus == false))
                {
                    if (char.IsDigit(line[i]))
                    {
                        num.Append(line[j]);
                        continue;
                    }
                    else if (line[j] == 'V')
                    {
                        val = V;
                    }
                    else if (line[j] == 'W')
                    {
                        val = W;
                    }
                    else if (line[j] == 'X')
                    {
                        val = X;
                    }
                    else if (line[j] == 'Y')
                    {
                        val = Y;
                    }
                    else if (line[j] == 'Z')
                    {
                        val = Z;
                    }
                }

                if (line[j] != ' ' && num.Length != 0 && (minus == false && plus == false))
                {
                    val = int.Parse(num.ToString());
                    num.Clear();
                    continue;
                }
                if (line[j] != ' ' && minus == true)
                {
                    if (char.IsDigit(line[j]))
                    {
                        num.Append(line[j]);
                        continue;
                    }
                    else if (line[j] == 'V')
                    {
                        val = Minus(X, V);
                        minus = false;
                    }
                    else if (line[j] == 'W')
                    {
                        val = Minus(X, W);
                        minus = false;
                    }
                    else if (line[j] == 'X')
                    {
                        val = Minus(X, X);
                        minus = false;
                    }
                    else if (line[j] == 'Y')
                    {
                        val = Minus(X, Y);
                        minus = false;
                    }
                    else if (line[j] == 'Z')
                    {
                        val = Minus(X, Z);
                        minus = false;
                    }
                }
                if (line[j] != ' ' && minus == true && num.Length != 0)
                {
                    val = X - int.Parse(num.ToString());
                    num.Clear();
                    minus = false;
                }

                if (line[j] != ' ' && plus == true)
                {
                    if (char.IsDigit(line[j]))
                    {
                        num.Append(line[j]);
                        continue;
                    }
                    else if (line[j] == 'V')
                    {
                        val = Plus(X, V);
                        plus = false;
                    }
                    else if (line[j] == 'W')
                    {
                        val = Plus(X, W);
                        plus = false;
                    }
                    else if (line[j] == 'X')
                    {
                        val = Plus(X, X);
                        plus = false;
                    }
                    else if (line[j] == 'Y')
                    {
                        val = Plus(X, Y);
                        plus = false;
                    }
                    else if (line[j] == 'Z')
                    {
                        val = Plus(X, Z);
                        plus = false;
                    }
                }
                if (line[j] != ' ' && plus == true && num.Length != 0)
                {
                    val = X + int.Parse(num.ToString());
                    num.Clear();
                    plus = false;
                }
            }
            if (num.Length != 0)
            {
                if (minus == true)
                {
                    int num1 = int.Parse(num.ToString());
                    val = Minus(X, num1);
                    minus = false;
                    num.Clear();
                }
                if (plus == true)
                {
                    int num1 = int.Parse(num.ToString());
                    val = Plus(X, num1);
                    plus = false;
                    num.Clear();
                }
                if (num.Length != 0)
                {
                    val = int.Parse(num.ToString());
                }
            }
            i = line.Length - 1;
            num.Clear();
        }

        static bool ifEqual(int value, int eValue)
        {
            if (value == eValue)
            {
                return true;
            }
            return false;
        }

        static bool ifSmaller(int value, int eValue)
        {
            if (value < eValue)
            {
                return true;
            }
            return false;
        }

        static bool ifGreater(int value, int eValue)
        {
            if (value < eValue)
            {
                return true;
            }
            return false;
        }

        static int Plus(int value, int eValue)
        {
            return value + eValue;
        }
        
        static int Minus(int value, int eValue)
        {
            return value - eValue;
        }
      
        static void Print(int value, StringBuilder print)
        {
            print.Append(value);
            print.Append(Environment.NewLine);
        }

        static void Clear(StringBuilder print)
        {
            print.Clear();
        }
    }
}