using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.academy
{
    class Program
    {
        static void Main(string[] args)
        {
            string nums = Console.ReadLine();
            nums.Trim(' ');
            string[] numbers = nums.Split(',');
            int[] ARR = new int[numbers.Length];
            for (int j = 0; j < ARR.Length; j++)
            {
                ARR[j] = int.Parse(numbers[j]);
            }
            int[] arr = ARR.Distinct().ToArray();
            int variety = int.Parse(Console.ReadLine());
            Array.Sort(arr);
            int count = 0;
            bool checkLast = false;
            for (int i = 0; i < arr.Length-1; i++)
            {
                if (count < variety)
                {


                    if (arr[i] + 1 == arr[i + 1])
                    {
                        i++;
                        count++;
                        checkLast = true;
                    }
                    else
                    {
                        checkLast = false;
                        count++;
                    }
                }
                else
                {
                    Console.WriteLine(variety); break;
                }
            }
            if (checkLast) { }
            else
            {
                count++;
            }

            //int x = arr.Sum();
            //int result = x / ARR.Length;
            Console.WriteLine(variety);
        }
    }
}
