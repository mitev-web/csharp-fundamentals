using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Program
    {
        static List<int> result = new List<int>();
        static StringBuilder res = new StringBuilder();
        static int cycleBegin = 0;
        static int cycleEnd = 0;
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
           
                string line = Console.ReadLine();
                string[] elems = line.Split(new string[]{ " " }, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < elems.Length; j++)
                {
                    arr[j] = int.Parse(elems[j]);
                }
                solve(arr, n, 0);
        }
        static void solve(int[] arr, int n,int elem)
        {
           
                if(elem > n - 1)
                {
                    print();
                    return;
                }
                if(result.Contains(elem))
                {
                    //Console.WriteLine(result.IndexOf(elem));
                    cycleBegin = result.IndexOf(elem);
                    printCycle();
                    return;
                }
                result.Add(elem);
                res.Append(elem);
                solve(arr, n, arr[elem]);
        }
        static void print()
        {
                for (int i = 0; i < result.Count; i++)
                {
                    //if (cycleIndex != 0 && cycleIndex == result[i] && i != result.Count-1 ) Console.Write("("+result[i] + " ");
                    if (i == result.Count - 1) Console.Write(result[i]);
                    else  Console.Write(result[i] + " ");
                }
                Console.WriteLine();
        }
        static void printCycle()
        {
            /* res.Insert(cycleBegin, "(");
            res.Insert(res.Length, ")"); */
            StringBuilder help = new StringBuilder();
            for (int i = 0; i < result.Count; i++)
            {
                if (i == cycleBegin)
                {
                    help.Append("(");
                    help.Append(result[i]);
                }
                else
                {
                    if (i == cycleBegin - 1 || i == result.Count - 1)
                    {
                        help.Append(result[i]);
                    }
                    else
                    {
                        if (i == cycleBegin + 1) help.Append(" "+result[i]+" ");
                        else help.Append(result[i] + " ");
                    }
                }
            }
            help.Append(")");
            Console.WriteLine(help);
        }
        static void replace(StringBuilder res, int index)
        {

        }
    }
}
