using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04
{
    class BombingCuboids
    {
        static int dMax, hMax, wMax;
        static char[,,,] cube;

        static int bNumber;
        static int[,] bombs;

        static Dictionary<char, int> detonated = new Dictionary<char, int>();
        static int detonatedCubes = 0;

        static void Main(string[] args)
        {
            ReadInput();
            DetonateBomb();
            Console.WriteLine(detonatedCubes);
            List<char> keys = detonated.Keys.ToList();
            keys.Sort();

            StringBuilder sb = new StringBuilder();
            foreach (char key in keys)
            {
                sb.Append(key);
                sb.Append(' ');
                sb.Append(detonated[key]);
                sb.Append('\n');
            }
            Console.WriteLine(sb.ToString());
            //PrintInput();
        }

        static void DetonateBomb()
        {
            for (int i = 0; i < bNumber; i++)
            {
                for (int d = 0; d < dMax; d++)
                {
                    for (int h = 0; h < hMax; h++)
                    {
                        for (int w = 0; w < wMax; w++)
                        {
                            double distCubeBomb = Math.Sqrt(Math.Pow((d - bombs[i, 2]), 2) + Math.Pow((h - bombs[i, 1]), 2) + Math.Pow((w - bombs[i, 0]), 2));
                            if (distCubeBomb <= bombs[i, 3])
                            {
                                if (cube[1, d, h, w] == 'x')
                                {
                                    detonatedCubes++;
                                    cube[1, d, h, w] = '-';
                                    if (detonated.ContainsKey(cube[0, d, h, w]))
                                    {
                                        detonated[cube[0, d, h, w]] += 1;
                                    }
                                    else
                                    {
                                        detonated.Add(cube[0, d, h, w], 1);
                                    }
                                    
                                }                                                                
                            }                            
                        }                        
                    }
                }
                FallDownCubes();
            }
        }

        static void Swap(int h1, int h2, int d, int w)
        {
            char temp = cube[0, d, h1, w];
            cube[0, d, h1, w] = cube[0, d, h2, w];
            cube[0, d, h2, w] = temp;
            temp = cube[1, d, h1, w];
            cube[1, d, h1, w] = cube[1, d, h2, w];
            cube[1, d, h2, w] = temp;
        }

        static void FallDownCubes()
        {
            for (int d = 0; d < dMax; d++)
            {
                for (int w = 0; w < wMax; w++)
                {
                    for (int h = 0; h < hMax; h++)
                    {
                        if (cube[1, d, h, w] == '-')
                        {
                            for (int h2 = h + 1; h2 < hMax; h2++)
                            {
                                if (cube[1, d, h2, w] == 'x')
                                {
                                    Swap(h2, h, d, w);
                                    break;
                                }                                
                            }
                        }
                    }
                }
            }
        }

        static void PrintInput()
        {
            Console.WriteLine("Cube:");
            for (int d = 0; d < dMax; d++)
            {
                for (int h = 0; h < hMax; h++)
                {
                    for (int w = 0; w < wMax; w++)
                    {
                        Console.Write(cube[d, h, w, 0]);
                    }
                    Console.WriteLine();
                }
                Console.WriteLine(new string('-', wMax));
            }

            Console.WriteLine("Bombs:");
            for (int i = 0; i < bNumber; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(bombs[i, j]);                    
                }
                Console.WriteLine();
            }
        }

        static void ReadInput()
        {
            string sizes = Console.ReadLine();
            string[] size = sizes.Split(' ');
            wMax = int.Parse(size[0]);
            hMax = int.Parse(size[1]);
            dMax = int.Parse(size[2]);

            cube = new char[2, dMax, hMax, wMax];
            for (int h = 0; h < hMax; h++)
            {
                string row = Console.ReadLine();
                string[] dd = row.Split(' ');
                for (int d = 0; d < dMax; d++)
                {
                    string ww = dd[d];
                    for (int w = 0; w < wMax; w++)
                    {
                        cube[0, d, h, w] = ww[w];
                        cube[1, d, h, w] = 'x';
                    }
                }
            }

            bNumber = int.Parse(Console.ReadLine());
            bombs = new int[bNumber, 4];
            for (int i = 0; i < bNumber; i++)
            {
                string bomb = Console.ReadLine();
                string[] bombData = bomb.Split(' ');
                for (int j = 0; j < 4; j++)
                {
                    bombs[i, j] = int.Parse(bombData[j]);
                }                
            }            
        }
    }
}
