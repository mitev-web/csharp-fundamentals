using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace crossword
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int n = int.Parse(line);

            for (int i = 0; i < 2*n; i++)
            {
               string words = Console.ReadLine();
            }
            Console.WriteLine("NO SOLUTION!");
        }
    }
}
