using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Program
    {
        static StringBuilder sb = new StringBuilder();
        static int index = 0;

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] array = new int[n];
            string str = Console.ReadLine();
            string[] inputNums = str.Split(' ');

            for (int i = 0; i < n; i++)
            {
                array[i] = int.Parse(inputNums[i]);
            }
            FindNextElement(array, index);
            
            //Console.WriteLine("0 1 2 3 5");
            Console.WriteLine(sb);

        }

        static int FindNextElement(int[] arr, int position)
        {
            int current = arr[position];
            sb.Append(position.ToString());
            sb.Append(" ");
            for (int i = 0; i < index; i = i + 2)
            {
                if (sb[i] == sb[index])
                {
                    if (i - 1 != -1)
                    {
                        sb[i - 1] = '(';
                    }
                    else
                    {
                        sb[1] = sb[0];
                        sb[0] = '(';
                    }
                    if (index - 1 > 1)
                    {
                        sb.Remove(index-1, 2);
                        sb[index - 1] = ')';
                    }
                    else
                    {
                        sb[index] = ')';
                    }
                    return -1;
                }
            }
            if (current < arr.Length)
            {
                index = index + 2;
                FindNextElement(arr, current);
                return current;
            }
            else
            {
                sb.Remove(sb.Length - 1, 1);
                return -1;
            }
        }


    }
}