using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class Crossword
    {
        static int n;
        static string[] words;
        static List<string> crossword = new List<string>();
        static string[] newOne;

        static void Main(string[] args)
        {
            ReadInput();
            newOne = new string[n];
            CreateCrossword(0);
            if (crossword.Count == 0)
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else if (crossword.Count == 1)
            {
                Console.Write(crossword[0]);
            }
            else
            {
                crossword.Sort();
                Console.Write(crossword[0]);
            }
            
        }
        
        static void CreateCrossword(int x)
        {
            if (x == n)
            {
                if (CheckCrossword())
                {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < n; i++)
                    {
                        sb.Append(newOne[i]);
                        sb.Append('\n');
                    }
                    crossword.Add(sb.ToString());
                }
            }
            else
            {
                for (int i = 0; i < 2*n; i++)
                {
                    newOne[x] = words[i];
                    CreateCrossword(x + 1);
                }
            }
        }

        static bool CheckCrossword()
        {
            bool valid = true;
            for (int i = 0; i < n; i++)
            {
                bool validWord = false;
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < n; j++)
                {                    
                    string conceptWord = newOne[j];
                    sb.Append(conceptWord[i]);
                }
                for (int j = 0; j < 2*n; j++)
                {
                    if (sb.ToString() == words[j])
                    {
                        validWord = true;
                        break;
                    }
                }
                if (!validWord)
                {
                    valid = false;
                    break;
                }
            }
            return valid;
        }

        static void ReadInput()
        {
            n = int.Parse(Console.ReadLine());
            words = new string[2 * n];

            for (int i = 0; i < 2*n; i++)
            {
                words[i] = Console.ReadLine();
            }

        }

    }
}
