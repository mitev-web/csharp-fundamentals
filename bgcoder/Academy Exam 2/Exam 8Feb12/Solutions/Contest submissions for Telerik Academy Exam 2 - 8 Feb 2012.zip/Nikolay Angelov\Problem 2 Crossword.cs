using System;
using System.Collections.Generic;
using System.Linq;

namespace ex2
{
    class Program
    {
        public static bool isContain(string[] arr, string word)
        {
            foreach (string x in arr)
            {
                if (x == word)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool isExists(string[] arr, string[] arr2)
        {
            bool exists = false;
            for (int i = 0; i < arr2.Length; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    if (arr2[i] == arr[j])
                    {
                        exists = true;
                    }
                }
            }
            string[] help = new string[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    help[i] = string.Concat(help[i], arr2[j].Substring(i, 1));
                }
            }
            for (int i = 0; i < help.Length; i++)
            {
                if (isContain(arr2, help[i]))
                {
                    exists = true;
                }
            }
            for (int a = 0; a < arr2.Length; a++)
            {
                for (int k = 0; k < arr.Length; k++)
                {
                    if (arr2[a].Contains(arr[k]))
                    {
                        exists = true;
                    }
                }
            }
            return exists;
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] words = new string[n * 2];
            string[] crossword = new string[n];

            for (int i = 0; i < n*2; i++)
            {
                words[i] = Console.ReadLine().ToUpper();
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    crossword[i] = string.Concat(crossword[i], words[j].Substring(i, 1));
                }
            }
            if(!isExists(crossword, words))
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine(crossword[i]);
                }
            }
        }
    }
}