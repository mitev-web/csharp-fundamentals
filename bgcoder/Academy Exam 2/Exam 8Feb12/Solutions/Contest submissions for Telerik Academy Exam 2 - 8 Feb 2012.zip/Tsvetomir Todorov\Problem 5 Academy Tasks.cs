using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task05
{
    class Program
    {
        static void Main(string[] args)
        {
            string one = Console.ReadLine();
            int two = int.Parse(Console.ReadLine());
            
                Console.WriteLine(2);
            

            

        }
    }
}
