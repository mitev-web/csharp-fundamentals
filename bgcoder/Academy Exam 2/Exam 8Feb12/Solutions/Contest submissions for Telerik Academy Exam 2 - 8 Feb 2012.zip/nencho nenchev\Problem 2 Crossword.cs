using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
 
namespace RealExamII
{
    class Program
    {
        static void Main(string[] args)
        {
            Crossword();
        }
 
        static void Crossword()
        {
            int input = int.Parse(Console.ReadLine());
            int length = 2 * input;
            string[] words = new string[length];
            char[] startLetters = new char[length];
            string result = "NO SOLUTION!";
 
            for (int i = 0; i < length; i++)
            {
                string word = Console.ReadLine();
                words[i] = word;
                startLetters[i] = word[0];
            }
 
            List<string> selectedWords = new List<string>();
            bool isCrossword = false;
 
            for (int i = 0; i < length; i++)
            {
                string word = words[i];
                for (int k = 0; k < input; k++)
                {
                    for (int j = 0; j < length; j++)
                    {
                        if (word[k] == words[j][0])
                        {
                            isCrossword = true;
                            break;
                        }
                        else isCrossword = false;
                    }
                    if (!isCrossword) break;
                }
                if (isCrossword) selectedWords.Add(word);
            }
            int count = selectedWords.Count;
            StringBuilder sb = new StringBuilder();
            if (count > 0)
            {
                string crossWord = selectedWords[0];
                for (int i = 0; i < crossWord.Length; i++)
                {
                    for (int k = 0; k < length; k++)
                    {
                        if (crossWord[i] == words[k][0])
                        {
                            sb.AppendLine(words[k]);
                            break;
                        }
                    }
                }
                Console.WriteLine(sb);
            }
            else
            {
                Console.WriteLine(result);
            }
 
        }
    }
}