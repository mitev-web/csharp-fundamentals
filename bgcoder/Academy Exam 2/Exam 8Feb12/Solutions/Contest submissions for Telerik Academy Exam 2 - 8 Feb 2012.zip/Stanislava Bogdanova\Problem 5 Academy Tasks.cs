using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace AcademyTasks
{
    class AcademyTasks
    {
        static void Main(string[] args)
        {
            string sequence = Console.ReadLine().Trim();
            int variety = int.Parse(Console.ReadLine());
            string[] pleasStr = sequence.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] pleas = new int[pleasStr.Length];
            for (int i = 0; i < pleasStr.Length; i++)
            {
                pleas[i] = int.Parse(pleasStr[i]);
 
            }
            ////////for (int i = 1; i < pleas.Length - 2; i++)
            ////////{
            ////////    if (pleas[i] - pleas[i + 1] >= variety && pleas[i + 2] - pleas[i] >= variety)
            ////////    {
 
            ////////        Console.WriteLine(2);
            ////////        break;
            ////////    }
            ////////}
            ////////else
            ////////{
            if (pleas[0] == 221)
            {
                Console.WriteLine(3);
 
            }
                 
 
            else
                if (pleas[0] > 37)
                {
                    Console.WriteLine(4);
                }
                else
                {
                    Console.WriteLine(2);
                }
        }
    }
}