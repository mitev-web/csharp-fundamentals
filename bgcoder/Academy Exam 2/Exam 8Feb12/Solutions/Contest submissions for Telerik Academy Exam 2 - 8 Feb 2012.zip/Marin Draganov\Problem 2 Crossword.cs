using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crssword
{
    class Program
    {
        static char[,] table;
        static StringBuilder currString = new StringBuilder();
        static StringBuilder bestString = new StringBuilder();

        static void Print(int n)
        {
            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    currString.Append(table[row,col]);
                }

                if (bestString.ToString() == "magic")
                {
                    bestString = currString;
                }
                else if (currString.ToString().CompareTo(bestString.ToString())<0)
                {
                    bestString = currString;
                }
            }
        }

        static bool Check(string[] words,int n)
        {

            bool magic = false;
            StringBuilder tableWord = new StringBuilder();
            int[] checker = new int[2*n];
            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    tableWord.Append(table[row,col]);
                }
                for (int i = 0; i < 2*n; i++)
                {
                    if (tableWord.ToString() == words[i])
                    {
                        magic = true;
                    }
                }
                if (!magic)
                {
                    return false;
                }
                magic = false;
                tableWord.Clear();
            }

            magic = false;
            for (int col = 0; col < n; col++)
            {
                for (int row = 0; row < n; row++)
                {
                    tableWord.Append(table[row, col]);
                }
                for (int i = 0; i < 2 * n; i++)
                {
                    if (tableWord.ToString() == words[i])
                    {
                        magic = true;
                    }
                }
                if (!magic)
                {
                    return false;
                }
                magic = false;
                tableWord.Clear();
            }
            Print(n);
            return true;

        }
        static bool BruteForce(string[] words,int n,int row)
        {
            if (row == n)
            {
                if (Check(words, n))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            for (int word = 0; word < 2*n; word++)
            {
                for (int i = 0; i < n; i++)
                {
                    table[row, i] = words[word][i];
                }
                if (BruteForce(words, n, row + 1))
                {
                    return true;
                }

            }
            return false;
        }


        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string[] words = new string[2*n];
            table = new char[n, n];
            bestString.Append("magic");

            for (int i = 0; i < 2*n; i++)
            {
                words[i] = Console.ReadLine();
            }
            var sortedWords =
            from word in words
            orderby word 
            select word;
            string[] sorted = new string[2*n];
            int count = 0;
            foreach (var item in sortedWords)
            {
                sorted[count] = item;
                count++;
            }

            if (BruteForce(sorted, n, 0))
            {
                int counter = 0;
                for (int row = 0; row < n; row++)
                {
                    for (int col = 0; col < n; col++)
                    {
                        Console.Write(bestString[counter]);
                        counter++;
                    }
                    if (row < n - 1)
                    {
                        Console.WriteLine();
                    }
                }
            }
            else
            {
                Console.Write("NO SOLUTION!");
            }
        }
    }
}