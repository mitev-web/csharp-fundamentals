using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace crossword
{
    class Crossword
    {
        static int n;
        static string firstWord = "";
        static List<string> verticalWords = new List<string>();
        static string solution="";
        static string[] words;
        static bool WordExists(string word)
        {
            for (int i = 0; i < 2 * n; i++)
                if (words[i].Substring(0, word.Length) == word) return true;
            return false;
        }
        static bool CheckWord(string word)
        {
            int position=verticalWords.Count;
            if (firstWord[position] != word[0]) return false;
            for (int i = 1; i < n; i++)
            {
                StringBuilder sb=new StringBuilder();
                for(int j=0;j<position;j++)
                {
                   sb.Append(verticalWords[j][i]);
                }
                sb.Append(word[i]);
                if(!WordExists(sb.ToString())) return false;
            }
            return true;
        }
        static string isBetter()
        {
            string curr = "";
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    curr += verticalWords[j][i];
                }
            }
            if (solution == "") return curr;
            if (String.Compare(curr, solution) == -1) return curr;
            else return "";
        }
        static void Generate()
        {
            if (verticalWords.Count == n)
            {
                string result = isBetter();
                if(result!="") solution=result;
                return;
            }
            for (int k = 0; k < 2 * n; k++)
            {
                if (CheckWord(words[k]))
                {
                    verticalWords.Add(words[k]);
                    Generate();
                    verticalWords.RemoveAt(verticalWords.Count - 1);
                }
            }

        }
        static void Main(string[] args)
        {
            n = int.Parse(Console.ReadLine());
            words = new string[2 * n];
            for (int i = 0; i < 2 * n; i++)
            {
                words[i] = Console.ReadLine();
            }
            for (int i = 0; i < 2 * n; i++)
            {
                firstWord = words[i];
                Generate();
            }
            if (solution=="")
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                //Console.WriteLine(solution);
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                        Console.Write(solution[i*n+j]);
                    Console.WriteLine();
                }
            }
        }
    }
}
