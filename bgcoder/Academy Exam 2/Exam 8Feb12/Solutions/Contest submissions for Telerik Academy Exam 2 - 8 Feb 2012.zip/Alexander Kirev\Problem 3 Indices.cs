using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Program
    {


        static void Indi(long num, long old, long[] arr)
        {
            final.Add(old);
            if ((num >= arr.Length) || (num < 0))
            {
                Print(1);

            }

            foreach (var item in final)
            {
                if (num == item)
                {
                    //final.Remove(final.Count -1);
                    Print(-1);
                }
            }
            old = num;
            num = arr[num];
            Indi(num, old, arr);


        }
        static void Print(int n)
        {
            if (n == 1)
            {
                for (int i = 0; i < final.Count; i++)
                {
                    if (i == final.Count - 1)
                    {
                        Console.WriteLine("{0}", final[i]);
                        Environment.Exit(0);
                    }
                    Console.Write("{0} ", final[i]);
                }
            }
            else
            {
                for (int i = 0; i < final.Count; i++)
                {
                    if (i == 0)
                    {
                        Console.Write("{0}(", final[i]);
                        continue;
                    }
                    if (i == final.Count - 1)
                    {
                        Console.WriteLine("{0})", final[i]);
                        Environment.Exit(0);
                    }
                    Console.Write("{0} ", final[i]);
                }
            }


        }
        static List<long> final = new List<long>();
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string str = Console.ReadLine();
            string[] numbers = str.Split(' ');
            long[] arr = new long[n];
            int counter = 0;

            for (int i = 0; i < n; i++)
            {
                if (i == ' ')
                {
                    continue;
                }
                else
                {
                    arr[counter] = long.Parse(numbers[i]);
                    counter++;
                }
            }


            long number = arr[0];
            long old = 0;
            if ((number <= n - 1) && (number >= 0))
            {
                Indi(number, old, arr);
            }
        }
    }
}
