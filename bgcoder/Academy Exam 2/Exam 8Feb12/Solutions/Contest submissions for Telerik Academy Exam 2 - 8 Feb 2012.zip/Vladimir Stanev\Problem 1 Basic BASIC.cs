using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02._01_Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> codeBB = new Dictionary<int, string>();

            string line = Console.ReadLine();
            int i=1;

            while (line != "RUN")
            {
                int positionSpace = line.IndexOf(" ");
                int number = int.Parse(line.Substring(0,positionSpace));
                string commandBB = line.Substring(positionSpace+1);
                commandBB = commandBB.Trim();
                commandBB = commandBB.Replace(" ", "");
                codeBB.Add(number, commandBB);
                line = Console.ReadLine();
                i++;
            }

            int[] lines = new int[i-1];
            i = 0;
            foreach (KeyValuePair<int, string> code in codeBB)
            {
                lines[i] = code.Key;
                i++;
                //Console.WriteLine("Key = {0}, Value = {1}", code.Key, code.Value);
            }

            int X = 0;
            int Y = 0;
            int Z = 0;
            int V = 0;
            int W = 0;

            int runLineNumber = 0;
            string currentCommand="";
            string outputString = "";

            bool end=false;
            while (!end)
            {
                // Console.WriteLine("Line {0}" , runLineNumber);
                currentCommand = codeBB[lines[runLineNumber]];
                // Console.WriteLine(currentCommand);

                string twoLetters = currentCommand.Substring(0,2);
                char thirdSymbol = currentCommand[2];
                char fourthSymbol= 'a';
                char fifthSymbol = 'a';
                char sixtySymbol = 'a';
                if (currentCommand.Length>3)    { fourthSymbol = currentCommand[3];  }
                if (currentCommand.Length > 4)  { fifthSymbol = currentCommand[4];  }
                if (currentCommand.Length > 5)  { sixtySymbol = currentCommand[5]; }

                // 
                if (twoLetters == "X=")
                {
                    Console.WriteLine(currentCommand);
                    // X=5 ?? 5+X ??
                    if (Char.IsNumber(thirdSymbol))
	                { X = int.Parse(currentCommand.Substring(3)); }
                    // X=-5
                    if (thirdSymbol == '-' && Char.IsNumber(thirdSymbol))
                    { X = -(int.Parse(currentCommand.Substring(3))); }
                    // X=-Z...
                    if (thirdSymbol == '-' && Char.IsLetter(thirdSymbol))
                    {
                        if (fourthSymbol == 'X')  { X = -X;  }
                        if (fourthSymbol == 'Y')  { X = -Y;  }
                        if (fourthSymbol == 'Z')  { X = -Z;  }
                        if (fourthSymbol == 'V')  { X = -V;  }
                        if (fourthSymbol == 'W')  {  X = -W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol != '-' || fourthSymbol != '+')
                    {
                        if (thirdSymbol == 'Y') { X = Y; }
                        if (thirdSymbol == 'Z') { X = Z; }
                        if (thirdSymbol == 'V') { X = V; }
                        if (thirdSymbol == 'W') { X = W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '-' )
                    {
                        if (fifthSymbol == 'X')  { X =  X-X; }
                        if (fifthSymbol == 'Y')  { X =  X-Y; }
                        if (fifthSymbol == 'Z')  { X =  X-Z; }
                        if (fifthSymbol == 'V')  { X =  X-V; }
                        if (fifthSymbol == 'W')  { X =  X-W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '+')
                    {
                        if (fifthSymbol == 'X') { X = X + X; }
                        if (fifthSymbol == 'Y') { X = X + Y; }
                        if (fifthSymbol == 'Z') { X = X + Z; }
                        if (fifthSymbol == 'V') { X = X + V; }
                        if (fifthSymbol == 'W') { X = X + W; }
                    }
                }
                
                if (twoLetters == "Y=")
                {
                    Console.WriteLine(currentCommand);
                    // Y=5 ?? 5+X ??
                    if (Char.IsNumber(thirdSymbol))
	                { Y = int.Parse(currentCommand.Substring(3)); }
                    // X=-5
                    if (thirdSymbol == '-' && Char.IsNumber(thirdSymbol))
                    { Y = -(int.Parse(currentCommand.Substring(3))); }
                    // X=-Z...
                    if (thirdSymbol == '-' && Char.IsLetter(thirdSymbol))
                    {
                        if (fourthSymbol == 'X')  { Y = -X;  }
                        if (fourthSymbol == 'Y')  { Y = -Y;  }
                        if (fourthSymbol == 'Z')  { Y = -Z;  }
                        if (fourthSymbol == 'V')  { Y = -V;  }
                        if (fourthSymbol == 'W')  { Y = -W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol != '-' || fourthSymbol != '+')
                    {
                        if (thirdSymbol == 'X') { Y = X; }
                        if (thirdSymbol == 'Z') { Y = Z; }
                        if (thirdSymbol == 'V') { Y = V; }
                        if (thirdSymbol == 'W') { Y = W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '-' )
                    {
                        if (fifthSymbol == 'X')  { Y =  Y-X; }
                        if (fifthSymbol == 'Y')  { Y =  Y-Y; }
                        if (fifthSymbol == 'Z')  { Y =  Y-Z; }
                        if (fifthSymbol == 'V')  { Y =  Y-V; }
                        if (fifthSymbol == 'W')  { Y =  Y-W; } ///
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '+')
                    {
                        if (fifthSymbol == 'X') { Y = Y + X; }
                        if (fifthSymbol == 'Y') { Y = Y + Y; }
                        if (fifthSymbol == 'Z') { Y = Y + Z; }
                        if (fifthSymbol == 'V') { Y = Y + V; }
                        if (fifthSymbol == 'W') { Y = Y + W; }
                    }
                }
                
                if (twoLetters == "Z=")
                {
                    Console.WriteLine(currentCommand);
                    // Y=5 ?? 5+X ??
                    if (Char.IsNumber(thirdSymbol))
                    { Z = int.Parse(currentCommand.Substring(3)); }
                    // X=-5
                    if (thirdSymbol == '-' && Char.IsNumber(thirdSymbol))
                    { Z = -(int.Parse(currentCommand.Substring(3))); }
                    // X=-Z...
                    if (thirdSymbol == '-' && Char.IsLetter(thirdSymbol))
                    {
                        if (fourthSymbol == 'X') { Z = -X; }
                        if (fourthSymbol == 'Y') { Z = -Y; }
                        if (fourthSymbol == 'Z') { Z = -Z; }
                        if (fourthSymbol == 'V') { Z = -V; }
                        if (fourthSymbol == 'W') { Z = -W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol != '-' || fourthSymbol != '+')
                    {
                        if (thirdSymbol == 'X') { Z = X; }
                        if (thirdSymbol == 'Y') { Z = Y; }
                        if (thirdSymbol == 'V') { Z = V; }
                        if (thirdSymbol == 'W') { Z = W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '-')
                    {
                        if (fifthSymbol == 'X') { Z = Z - X; }
                        if (fifthSymbol == 'Y') { Z = Z - Y; }
                        if (fifthSymbol == 'Z') { Z = Z - Z; }
                        if (fifthSymbol == 'V') { Z = Z - V; }
                        if (fifthSymbol == 'W') { Z = Z - W; } ///
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '+')
                    {
                        if (fifthSymbol == 'X') { Z = Z + X; }
                        if (fifthSymbol == 'Y') { Z = Z + Y; }
                        if (fifthSymbol == 'Z') { Z = Z + Z; }
                        if (fifthSymbol == 'V') { Z = Z + V; }
                        if (fifthSymbol == 'W') { Z = Z + W; }
                    }
                }
                
                if (twoLetters == "V=")
                {
                    Console.WriteLine(currentCommand);
                    // Y=5 ?? 5+X ??
                    if (Char.IsNumber(thirdSymbol))
                    { V = int.Parse(currentCommand.Substring(3)); }
                    // X=-5
                    if (thirdSymbol == '-' && Char.IsNumber(thirdSymbol))
                    { V = -(int.Parse(currentCommand.Substring(3))); }
                    // X=-Z...
                    if (thirdSymbol == '-' && Char.IsLetter(thirdSymbol))
                    {
                        if (fourthSymbol == 'X') { V = -X; }
                        if (fourthSymbol == 'Y') { V = -Y; }
                        if (fourthSymbol == 'Z') { V = -Z; }
                        if (fourthSymbol == 'V') { V = -V; }
                        if (fourthSymbol == 'W') { V = -W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol != '-' || fourthSymbol != '+')
                    {
                        if (thirdSymbol == 'X') { V = X; }
                        if (thirdSymbol == 'Y') { V = Y; }
                        if (thirdSymbol == 'Z') { V = Z; }
                        if (thirdSymbol == 'W') { V = W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '-')
                    {
                        if (fifthSymbol == 'X') { V = V - X; }
                        if (fifthSymbol == 'Y') { V = V - Y; }
                        if (fifthSymbol == 'Z') { V = V - Z; }
                        if (fifthSymbol == 'V') { V = V - V; }
                        if (fifthSymbol == 'W') { V = V - W; } ///
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '+')
                    {
                        if (fifthSymbol == 'X') { V = V + X; }
                        if (fifthSymbol == 'Y') { V = V + Y; }
                        if (fifthSymbol == 'Z') { V = V + Z; }
                        if (fifthSymbol == 'V') { V = V + V; }
                        if (fifthSymbol == 'W') { V = V + W; }
                    }
                }
               
                if (twoLetters == "W=")
                {
                    Console.WriteLine(currentCommand);
                    // Y=5 ?? 5+X ??
                    if (Char.IsNumber(thirdSymbol))
                    { W = int.Parse(currentCommand.Substring(3)); }
                    // X=-5
                    if (thirdSymbol == '-' && Char.IsNumber(thirdSymbol))
                    { W = -(int.Parse(currentCommand.Substring(3))); }
                    // X=-Z...
                    if (thirdSymbol == '-' && Char.IsLetter(thirdSymbol))
                    {
                        if (fourthSymbol == 'X') { W = -X; }
                        if (fourthSymbol == 'Y') { W = -Y; }
                        if (fourthSymbol == 'Z') { W = -Z; }
                        if (fourthSymbol == 'V') { W = -V; }
                        if (fourthSymbol == 'W') { W = -W; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol != '-' || fourthSymbol != '+')
                    {
                        if (fourthSymbol == 'X') { W = X; }
                        if (fourthSymbol == 'Y') { W = Y; }
                        if (fourthSymbol == 'Z') { W = Z; }
                        if (fourthSymbol == 'V') { W = V; }
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '-')
                    {
                        if (fifthSymbol == 'X') { W = W - X; }
                        if (fifthSymbol == 'Y') { W = W - Y; }
                        if (fifthSymbol == 'Z') { W = W - Z; }
                        if (fifthSymbol == 'V') { W = W - V; }
                        if (fifthSymbol == 'W') { W = W - W; } ///
                    }
                    if (Char.IsLetter(thirdSymbol) || fourthSymbol == '+')
                    {
                        if (fifthSymbol == 'X') { W = W + X; }
                        if (fifthSymbol == 'Y') { W = W + Y; }
                        if (fifthSymbol == 'Z') { W = W + Z; }
                        if (fifthSymbol == 'V') { W = W + V; }
                        if (fifthSymbol == 'W') { W = W + W; }
                    }
                }
                // if
                
                if (twoLetters == "IF")
                {
                    Console.WriteLine(currentCommand);
                    bool isOK = false;
                    int positionT=currentCommand.IndexOf("T");
                    string condition = currentCommand.Substring(2, positionT - 2);
                    int positionOp = condition.IndexOf("<");
                    char oper = '<';
                    if (positionOp == -1)
                    {
                        positionOp = condition.IndexOf("=");
                        oper = '=';
                    }
                    if (positionOp == -1)
                    {
                        positionOp = condition.IndexOf(">");
                        oper = '>';
                    }

                    int leftOp = 0;
                    int rightOp = 0;

                    if (Char.IsLetter(thirdSymbol))
                    {
                        if (thirdSymbol == 'X') { leftOp = X; }
                        if (thirdSymbol == 'Y') { leftOp = Y; }
                        if (thirdSymbol == 'Z') { leftOp = Z; }
                        if (thirdSymbol == 'V') { leftOp = V; }
                        if (thirdSymbol == 'W') { leftOp = W; }
                    }
                    else
                    {
                        leftOp = int.Parse(condition.Substring(0, positionOp));
                    }

                    char symbolAfterOp=condition[positionOp+1];
                    if (symbolAfterOp == '-')
                    {
                        symbolAfterOp=condition[positionOp+2];
                        if (Char.IsLetter(symbolAfterOp))
                        {
                            if (symbolAfterOp == 'X') { rightOp = -X; }
                            if (symbolAfterOp == 'Y') { rightOp = -Y; }
                            if (symbolAfterOp == 'Z') { rightOp = -Z; }
                            if (symbolAfterOp == 'V') { rightOp = -V; }
                            if (symbolAfterOp == 'W') { rightOp = -W; }
                        }
                        else
                        {
                            rightOp = int.Parse(condition.Substring(positionOp+1));
                        }
                    }
                    else
                    {
                        if (Char.IsLetter(symbolAfterOp))
                        {
                            if (symbolAfterOp == 'X') { rightOp = X; }
                            if (symbolAfterOp == 'Y') { rightOp = Y; }
                            if (symbolAfterOp == 'Z') { rightOp = Z; }
                            if (symbolAfterOp == 'V') { rightOp = V; }
                            if (symbolAfterOp == 'W') { rightOp = W; }
                        }
                        else
                        {
                            rightOp = int.Parse(condition.Substring(positionOp + 1));
                        }
                    }


                    if (oper == '<')
                    {
                        if (leftOp<rightOp) {isOK = true; }
                    }
                    else if (oper == '=')
                    {
                        if (leftOp == rightOp) { isOK = true; }
                    }
                    if (oper == '>')
                    {
                        if (leftOp > rightOp) { isOK = true; }
                    }


                    // 
                    if (isOK)
                    {
                        int newLine = positionT + 7; // 8-1
                        runLineNumber=newLine;
                    }



                }
                
                if (twoLetters == "PR")
                {
                    Console.WriteLine(currentCommand);
                    if (sixtySymbol == 'X') { outputString = X +"\n";  }
                    if (sixtySymbol == 'Y') {  outputString = Y + "\n";  }
                    if (sixtySymbol == 'Z') { outputString = Z + "\n"; }
                    if (sixtySymbol == 'V') { outputString = V + "\n"; }
                    if (sixtySymbol == 'W') { outputString = W + "\n";  }
                    Console.WriteLine(outputString);
                }
                
                if (twoLetters == "CL")
                {
                    Console.WriteLine(currentCommand);
                    outputString ="";
                }

                if (twoLetters == "ST")
                {
                    Console.WriteLine(currentCommand);
                    end = true;
                }

                runLineNumber++;
                if (runLineNumber>lines.Length)
                {
                    end=true;
                }
            }

            Console.WriteLine( outputString );
        }
    }
}
