using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_3
{
    class Program
    {
        static void Method(int number, int[] array, int N, StringBuilder stringBuild, int pos1, int elem)
        {
            if (number > array[number])
            {
                pos1 = array[number];
                elem = number;
                stringBuild = stringBuild.Insert(pos1 * 2, "(");
                stringBuild.Append(")");
                return;
            }
            stringBuild.Append(" ");
            stringBuild.Append(array[number]);
            number = array[number];
            if (array[number] > N - 1)
            {
                return;
            }
            else
            {
                Method(number, array, N, stringBuild, pos1, elem);
            }
        }

        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());

            int index = 0;
            string text = Console.ReadLine();
            string[] arrString = text.Split(' ');
            int[] arr = new int[n];
            for (int i = 0; i < arrString.Length; i++)
            {
                arr[i] = int.Parse(arrString[i]);
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("0");
            int position2 = 0;
            int element = 0;
            Method(index, arr, n, sb, position2, element);
            Console.WriteLine(sb);
        }
    }
}

