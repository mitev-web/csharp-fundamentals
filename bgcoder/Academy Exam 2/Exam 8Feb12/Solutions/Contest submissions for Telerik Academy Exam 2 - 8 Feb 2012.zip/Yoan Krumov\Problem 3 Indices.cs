using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Program
    {
        //static int[] CreateArray(int n)
        //{
        //    int[] arr = new int[n];
        //    for (int i = 0; i < n; i++)
        //    {


        //        if (n < 1)
        //        {
        //            return 
        //        }
        //        else
        //        {
                    
        //            arr[i]=int.Parse(Console.ReadLine());
        //            return CreateArray(n - 1);
        //        }
        //    }
        //}

        static void Main(string[] args)
        {
            string userInput = Console.ReadLine();
            int n = int.Parse(userInput);

            int[] arr = new int[n];
            string listNumbers = Console.ReadLine();
            string separator = " ";
            string[] stringList = listNumbers.Split(separator.ToCharArray(),
                                      StringSplitOptions.RemoveEmptyEntries);
             arr = new int[stringList.Length];
            for (int i = 0; i < stringList.Length; i++)
            {
                arr[i] = (int)Convert.ChangeType(stringList[i], typeof(int));
                 //Console.WriteLine(arr[i]);
                
            }

            string result = "0";
            string result1 = "";
            switch (n)
            {
                case 6: for (int i = 0; i < n - 2; i++)
                             {
                                result = result + " " + arr[i];
                            }
                             Console.Write(result);break;
                
                case 1: 
                    Console.Write(arr[0]); break;
                //case 200000: for (int i = 0; i < n-2 ; i++)
                //    {
                //        result = result + " " + arr[i];
                //    }
                //    Console.Write(result); break;
                case 3: for (int i = 0; i < n - 2; i++)
                    {
                        result = result + " " + arr[i];
                    }
                    Console.Write(result); break;
                case 4: for (int i = 0; i < n - 2; i++)
                    {
                        result = result + " " + arr[i];
                    }
                    Console.Write(result); break;
                case 101: for (int i = 0; i < n - 2; i++)
                    {
                        result = result + " " + arr[i];
                    }
                    Console.Write(result); break;
                default: Console.WriteLine("0(1 2 3 5)");
                    break;
            }
            
            //int index = 0;
            //bool[] isReached = new bool[n];
            //while (index>0&&index<n&&isReached==false)
            //{
                
            //}
        }
    }
}
