using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _3.Indices
{
	class Indices
	{
		static int[] arr;
		static StringBuilder output = new StringBuilder();
		static Dictionary<int, int> visited = new Dictionary<int, int>();

		static void GetIndices(int index)
		{
			while (index >= 0 && index < arr.Length)
			{
				int nextIndex = arr[index];
				if (nextIndex >= arr.Length)
				{
					break;
				}
				else
				{
					if (visited.ContainsKey(nextIndex) == false)
					{
						output.Append(" ");
						output.Append(arr[index]);
						visited.Add(index, arr[index]);
					}
					else
					{
						output.Append(')');
						int startLoopIndex = output.ToString().LastIndexOf(" " + nextIndex.ToString() + " ");
						if (startLoopIndex >= 0)
						{
							output.Insert(startLoopIndex, "(");
						}
						else
						{
							output.Insert(0, "(");
							break;
						}

						if (output.Length > 3)
						{
							output.Remove(startLoopIndex + 1, 1);
						}
						break;
					}
				}
				index = nextIndex;
			}
		}

		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			arr = new int[n];
			string[] temp = Console.ReadLine().Split(' ');
			for (int i = 0; i < n; i++)
			{
				arr[i] = int.Parse(temp[i]);
			}

			if (arr.Length == 1)
			{
				if (arr[0] == 0)
				{
					Console.WriteLine("(0)");
					return;
				}
				else
				{
					Console.WriteLine(arr[0]);
					return;
				}
			}
			output.Append(0);
			GetIndices(0);
			Console.WriteLine(output.ToString().Trim());
		}
	}
}
