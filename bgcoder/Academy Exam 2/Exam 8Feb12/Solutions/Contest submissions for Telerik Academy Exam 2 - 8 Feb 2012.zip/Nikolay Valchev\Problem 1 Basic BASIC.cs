using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Basic
{

    class Program
    {
        static int[] values;

        static char[] variables;
        static string[] commands;
        static string[] lines;
        static List<string> printThis;
        struct bbLine
        {
            public int num;
            public string line;
        }
        
        static void Main(string[] args)
        {   
            printThis = new List<string>();
            char[] vars = { 'X', 'Y', 'V', 'W', 'Z' };
            int[] vals = {0,0,0,0,0};
            values = vals;
            variables = vars;
            string[] coms = { "IF", "=", "CLS", "PRINT", "GOTO", "STOP" };
            commands = coms;
            StringBuilder code = new StringBuilder();
            do
            {
                string line;
                if ((line = Console.ReadLine()) .Trim().IndexOf("RUN") != -1)
                {
                    break;
                }
                if (line.Trim() !="")
                    code.Append(line + '\n');
            }
            while (true);
            
            string[] newLines = code.ToString().Split(new char[] { '\n','\r' }, StringSplitOptions.RemoveEmptyEntries);
            bbLine[] bbLines = new bbLine[newLines.Length];

            int maxLine = int.MinValue;
            int minLine = int.MaxValue;
            for (int i = 0; i < newLines.Length; i++)
	        {
                int index = newLines[i].Trim().IndexOf(' ');
                bbLines[i].num = int.Parse(newLines[i].Trim().Substring(0, index));
                bbLines[i].line = newLines[i].Trim().Substring(index).Trim();
                if (maxLine < bbLines[i].num)
                {
                    maxLine = bbLines[i].num;
                }
                if (minLine > bbLines[i].num)
                {
                    minLine = bbLines[i].num;
                }
	        }

            lines = new string[maxLine +1];
            for (int i = 0; i < bbLines.Length; i++)
            {
                lines[bbLines[i].num] = bbLines[i].line;
            }

            runProgram(minLine);

            foreach (var item in printThis)
            {
                Console.WriteLine(item);
            }
        }

        //IF FUNCTION
        static int ifFunc(string line)
        {
            char[] comparers = {'>','<','='};
            int comparer = -1;
            int indexOfComparer = 0;
            for (int i = 0; i < comparers.Length; i++)
			{
                if ((indexOfComparer=line.IndexOf(comparers[i])) != -1)
                {
                    comparer = i;
                    break;
                }
			}
            string left = line.Trim().Substring(0, indexOfComparer);
            string toRight = line.Trim().Substring(indexOfComparer+1).Trim();
            string right = toRight.Substring(0, toRight.IndexOf(' '));

            int leftValue = 0;
            int rightValue = 0;

            leftValue = returnValue(left);
            rightValue = returnValue(right);
            int nextLine = -1;
            if (isTrue(leftValue,rightValue,comparer))
            {
                nextLine = doFunc(line.Substring(line.IndexOf("THEN") + "THEN".Length).Trim());
            }

            return nextLine;
        }


        //Do some function
        static int doFunc(string line)
        {
            int index = -1;
            int commandInd = 0;
            for (int i = 0; i < commands.Length; i++)
            {
                if ((commandInd = line.IndexOf(commands[i]))!= -1)
                {
                    index = i;
                    break;
                }
            }

            switch (index)
            { 
                case 0:
                    return ifFunc(line.Substring(commandInd + commands[index].Length).Trim());
                case 1:
                    int ind = 0;
                    changeValueOfVar(line.Substring(0, (ind = line.IndexOf("="))).Trim(), line.Substring(ind + 1).Trim());
                    break;
                case 2:
                    cls();
                    break;
                case 3:
                    printFuc(line.Substring(commandInd + commands[index].Length).Trim());
                    break;
                case 4:
                    return gotoFunc(line.Substring(commandInd + commands[index].Length).Trim());
                case 5:
                    return -2;
                default:
                    return -1;
            }
            return -1;
        }



        //Is true 
        static bool isTrue(int left, int right, int comparer)
        {
            switch (comparer)
            { 
                case 0:
                    if (left > right)
                        return true;
                    else
                        return false;
                case 1:
                    if (left < right)
                        return true;
                    else return false;
                case 2:
                    if (left == right)
                        return true;
                    else
                        return false;
                default:
                    return false;
            } 
        }

        //Return a value
        static int returnValue(string var)
        {
            int value = 0;
            if (!int.TryParse(var, out value))
            {
                for (int i = 0; i < variables.Length; i++)
                {
                    if (var.IndexOf(variables[i]) != -1)
                    {
                        return values[i];
                    }
                }
            }
            return value;
        }

        //Run Program
        static void runProgram(int begin)
        {
            
            for (int i = begin; i < lines.Length; i++)
            {
                int nextLine = -1;

                if (lines[i] != null)
                {
                    nextLine = doFunc(lines[i]);
                }

                if (nextLine == -2)
                {
                    return;
                }
                if (nextLine >= 0)
                {
                    i = nextLine - 1;
                }
            }
        }

        //print function
        static void printFuc(string line)
        { 
            int value;
            bool isValue = int.TryParse(line, out value);
            if (isValue)
            {
                printThis.Add(value.ToString());
                return;
            }

            for (int i = 0; i < values.Length; i++)
            {
                if (line.IndexOf(variables[i]) != -1)
                {
                    printThis.Add(values[i].ToString());
                    break;
                }
            }
        }

        //clear screan
        static void cls()
        {
            printThis.Clear();
        }

        //go to function
        static int gotoFunc(string line)
        {
            int value = 0;
            bool isValue = int.TryParse(line, out value);

            if (isValue)
            {
                return value;
            }

            for (int i = 0; i < values.Length; i++)
            {
                if (line.IndexOf(variables[i]) != -1)
                {
                    return values[i];

                }
            }

            return -1;
        }


        //changing value of variable
        static void changeValueOfVar(string variable, string newValue)
        {
            string[] vals = newValue.Split(new char[] { '-', '+' }, StringSplitOptions.RemoveEmptyEntries);
            int sign = 1;
            if (newValue.IndexOf('+') != -1)
            {
                sign = 1;
            }
            if (newValue.IndexOf('-') != -1)
            {
                sign = -1;
            }
            int left = 0;
            int right = 0;

            left = returnValue(vals[0]);
            if (vals.Length > 1)
            {
                right = returnValue(vals[1]);
            }
            
            int index = 0;

            for (int j = 0; j < variables.Length; j++)
            {
                if (variable.IndexOf(variables[j]) != -1)
                {
                    index = j;
                    break;
                }
            }

            if (vals.Length > 1)
            {
                values[index] = left + sign * right;
            }
            else
            {
                values[index] = sign * left;
            }
        }

    }
}
