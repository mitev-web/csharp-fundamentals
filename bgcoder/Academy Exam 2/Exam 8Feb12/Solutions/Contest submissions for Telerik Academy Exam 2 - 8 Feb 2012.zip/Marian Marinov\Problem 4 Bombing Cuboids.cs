using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BombingCuboids
{
    class Cube
    {
        public bool destroyed = false;
        public char colour;

        public Cube(char ch)
        {
            colour = ch;
        }
    }

    class Destroyed
    {
        public char colour;
        public int count;

        public Destroyed(char c, int count)
        {
            this.colour = c;
            this.count = count;
        }
    }

    class Bomb
    {
        public int w, h, d;
        public int p;

        public Bomb(int w, int h, int d, int p)
        {
            this.w = w;
            this.h = h;
            this.d = d;
            this.p = p;
        }
    }
    class Program
    {
        static Cube[, ,] cuboid;
        static Bomb[] bombs;
        
        static void CreateCuboid(int w, int h, int d)
        {
            cuboid = new Cube[w, h, d];

            for (int j = 0; j < h; j++)
            {
                string[] colours = Console.ReadLine().Split(' ');

                for (int k = 0; k < d; k++)
                {
                    for (int i = 0; i < w; i++)
                    {
                        cuboid[i, j, k] = new Cube(colours[k][i]);
                    }
                }
            }
        }

        static void CreateBombs(int N)
        {
            int w, h, d, p;

            for (int i = 0; i < N; i++)
            {
                string[] parameters = Console.ReadLine().Split(' ');
                w= int.Parse(parameters[0]);
                h= int.Parse(parameters[1]);
                d= int.Parse(parameters[2]);
                p= int.Parse(parameters[3]);
                bombs[i] = new Bomb(w, h, d, p);
            }
        }

        static void Switch(Cube a, Cube b)
        {
            Cube tmp = new Cube(a.colour);
            tmp.destroyed = a.destroyed;
            a.colour = b.colour;
            a.destroyed = b.destroyed;
            b.colour = tmp.colour;
            b.destroyed = tmp.destroyed;
        }

        static void RelocateCubes()
        {
            int destroyedBegin;
            int destroyedEnd;
            for (int i = 0; i < cuboid.GetLength(0); i++)
            {
                for (int k = 0; k < cuboid.GetLength(2); k++)
                {
                    destroyedBegin = -1;
                    destroyedEnd = -1;

                    for (int j1 = 0; j1 < cuboid.GetLength(1); j1++)
                    {
                        if (cuboid[i,j1,k].destroyed)
                        {
                            destroyedBegin = j1;
                            for (int j2 = j1 + 1; j2 < cuboid.GetLength(1); j2++)
                            {
                                if (!cuboid[i,j2,k].destroyed)
                                {
                                    destroyedEnd = j2;
                                    for (int tmp = 0; destroyedEnd + tmp < cuboid.GetLength(1); tmp++)
                                    {
                                        Switch(cuboid[i, destroyedBegin + tmp, k], cuboid[i, destroyedEnd + tmp, k]);
                                    }
                                    break;
                                }                                
                            }
                        }
                    }                    
                }
            }
        }

        static void BOOM(Bomb b)
        {
            double distance;
            int wDistance;
            int hDistance;
            int dDistance;

            for (int i = 0; i < cuboid.GetLength(0); i++)
            {
                for (int j = 0; j < cuboid.GetLength(1); j++)
                {
                    for (int k = 0; k < cuboid.GetLength(2); k++)
                    {
                        wDistance = (i - b.w) * (i - b.w);
                        hDistance = (j - b.h) * (j - b.h);
                        dDistance = (k - b.d) * (k - b.d);

                        distance = Math.Sqrt(wDistance + hDistance + dDistance);

                        if (distance <= b.p)
                        {
                            cuboid[i, j, k].destroyed = true;
                        }
                    }
                }
            }

            RelocateCubes();
        }

        static void ShowStatistics()
        {
            int cubesDestroyed = 0;
            List<Destroyed> destr = new List<Destroyed>();
            Destroyed find;

            foreach (Cube cube in cuboid)
            {
                if (cube.destroyed)
                {
                    cubesDestroyed++;
                    find = destr.Find(
                        delegate(Destroyed d)
                        {
                            return d.colour == cube.colour;
                        }
                        );
                    if (find != null)
                    {
                        find.count++;
                    }
                    else
                    {
                        destr.Add(new Destroyed(cube.colour, 1));
                    }
                }
            }

            Console.WriteLine(cubesDestroyed);

            destr.Sort(
                delegate(Destroyed d1, Destroyed d2)
                {
                    return d1.colour - d2.colour;
                }
                );

            foreach (Destroyed d in destr)
            {
                Console.WriteLine(d.colour + " " + d.count);
            }
        }

        static void Main(string[] args)
        {
            string[] dimensions = Console.ReadLine().Split(' ');
            CreateCuboid(int.Parse(dimensions[0]), int.Parse(dimensions[1]), int.Parse(dimensions[2]));
                        
            int N = int.Parse(Console.ReadLine());
            bombs = new Bomb[N];
            CreateBombs(N);

            foreach (Bomb b in bombs)
            {
                BOOM(b);
            }

            ShowStatistics();
        }
    }
}
