using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bombing_Cuboids
{
    class Bombing_Cuboids
    {
        static List<char> colorNames;
        static Dictionary<char, int> destroyed;
        static char[, ,] hypercube;
        static bool[, ,] hypercubeCurrentlyHit;
        static char emptyCell = ' ';
        static List<Point> affectedPillars;
        static int totalDestroyed = 0;

        struct Point
        {
            public int h, d, w;
            public Point (int h=0, int d=0, int w=0)
            {
                this.h = h;
                this.d = d;
                this.w = w;
            }

            public static Point operator + (Point a, Point b)
            {
                return new Point (a.h + b.h, a.d + b.d, a.w + b.w);
            }

            public static Point operator - (Point a, Point b)
            {
                return new Point (a.h - b.h, a.d - b.d, a.w - b.w);
            }

            public void Print()
            {
                Console.WriteLine(this.h + " " + this.d + " " + this.w);
            }
        }

        static double GetDistance (Point A, Point B)
        {
            double result = 0;
            Point AB = B-A;
            result = Math.Sqrt(AB.h * AB.h + AB.d * AB.d + AB.w * AB.w);
            return result;
        }

        static int GetSqDistance(Point A, Point B)
        {
            int result = 0;
            Point AB = B - A;
            result = AB.h * AB.h + AB.d * AB.d + AB.w * AB.w;
            return result;
        }

        static bool IsValid(Point cellLocation)
        {
            /*
            if (cellLocation.h < 0 || cellLocation.h >= hypercube.GetLength(0)) return false;
            if (cellLocation.d < 0 || cellLocation.d >= hypercube.GetLength(1)) return false;
            if (cellLocation.w < 0 || cellLocation.w >= hypercube.GetLength(2)) return false;
            return true;*/
            if (cellLocation.h < 0 || cellLocation.h >= globH) return false;
            if (cellLocation.d < 0 || cellLocation.d >= globD) return false;
            if (cellLocation.w < 0 || cellLocation.w >= globW) return false;
            return true;
        }

        static void Destroy(Point bombLocation, double bombPower)
        {
            if (!IsValid(bombLocation))
            {
                //System.Threading.Thread.Sleep(2000);
                throw new Exception();
            }
            
            TryDestroy(bombLocation, bombLocation, bombPower);

            hypercubeCurrentlyHit = new bool[globH, globD, globW];
            /*
            for (int height = 0; height < hypercube.GetLength(0); height++)
            {
                for (int depth = 0; depth < hypercube.GetLength(1); depth++)
                {
                    for (int width = 0; width < hypercube.GetLength(2); width++)
                    {
                        hypercubeCurrentlyHit[height, depth, width] = false;
                    }
                }
            }*/
            FallAllPillars();
            affectedPillars.Clear();
        }

        static void TryDestroy(Point cellLocation, Point bombLocation, double bombPower)
        {
            //debug Console.WriteLine();
            Queue<Point> cellLocationsDestroy = new Queue<Point>();
            cellLocationsDestroy.Enqueue(cellLocation);
            double sqPower = bombPower * bombPower;
            while (cellLocationsDestroy.Count > 0)
            {
                cellLocation = cellLocationsDestroy.Dequeue();
                if (GetSqDistance(bombLocation, cellLocation) <= sqPower)
                {

                    char cellColor = hypercube[cellLocation.h, cellLocation.d, cellLocation.w];
                    //destruction
                    if (hypercube[cellLocation.h, cellLocation.d, cellLocation.w] != emptyCell)
                    {
                        totalDestroyed++;
                        affectedPillars.Add(new Point(0, cellLocation.d, cellLocation.w));
                    }
                    hypercube[cellLocation.h, cellLocation.d, cellLocation.w] = emptyCell;
                    if (destroyed.ContainsKey(cellColor))
                    {
                        destroyed[cellColor] += 1;
                    }

                    //-----------
                    for (int h = cellLocation.h - 1; h <= cellLocation.h + 1; h++)
                    {
                        for (int d = cellLocation.d - 1; d <= cellLocation.d + 1; d++)
                        {
                            for (int w = cellLocation.w - 1; w <= cellLocation.w + 1; w++)
                            {
                                Point newCellLocation = new Point(h, d, w);
                                if (IsValid(newCellLocation) && ((h != cellLocation.h) || (d != cellLocation.d) || (w != cellLocation.w)))
                                {
                                    //debug newCellLocation.Print();
                                    if (!hypercubeCurrentlyHit[h, d, w])
                                    {
                                        hypercubeCurrentlyHit[h, d, w] = true;
                                        //TryDestroy(newCellLocation, bombLocation, bombPower);
                                        cellLocationsDestroy.Enqueue(newCellLocation);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        static void Swap (ref char a, ref char b)
        {
            a ^= b;
            b ^= a;
            a ^= b;
        }

        static void FallPillar(int depth, int width)
        {
            int ground = globH-1;
            for (int h = 0; h < globH; h++)
            {
                if (hypercube[h, depth, width] == emptyCell)
                {
                    ground = h;
                    break;
                }
            }
            int falling = globH-1;
            for (int h = ground + 1; h < globH; h++)
            {
                if (hypercube[h, depth, width] != emptyCell)
                {
                    falling = h;
                    break;
                }
            }
            while (falling < globH && hypercube[falling, depth, width] != emptyCell)
            {
                Swap(ref hypercube[falling, depth, width], ref hypercube[ground, depth, width]);
                falling++;
                ground++;
            }
        }

        static void FallAllPillars()
        {
            foreach (Point pillar in affectedPillars)
            {
                FallPillar(pillar.d, pillar.w);
            }
        }

        static void PrintHypercube()
        {

            for (int height = 0; height < hypercube.GetLength(0); height++)
            {
                for (int depth = 0; depth < hypercube.GetLength(1); depth++)
                {
                    for (int width = 0; width < hypercube.GetLength(2); width++)
                    {
                        Console.Write(hypercube[height, depth, width]);
                    }
                    Console.WriteLine();
                }
                Console.WriteLine(new string ('-', hypercube.GetLength(1)));
            }
        }

        private static void InputHypercube()
        {
            for (int height = 0; height < hypercube.GetLength(0); height++)
            {
                string plate = Console.ReadLine();
                string[] rows = plate.Split(' ');
                for (int depth = 0; depth < rows.Length; depth++)
                {
                    string row = rows[depth];
                    for (int width = 0; width < row.Length; width++)
                    {
                        char cell = row[width];
                        hypercube[height, depth, width] = cell;
                        if (!destroyed.ContainsKey(cell))
                        {
                            colorNames.Add(cell);
                            destroyed.Add(cell, 0);
                        }
                    }
                }
            }
        }

        static int globW, globH, globD;

        static void Main(string[] args)
        {
            int w, h, d;
            string [] dimensions = Console.ReadLine().Split(' ');
            w = int.Parse(dimensions[0]);
            h = int.Parse(dimensions[1]);
            d = int.Parse(dimensions[2]);

            globW = w;
            globH = h;
            globD = d;

            hypercube = new char[h, d, w];
            hypercubeCurrentlyHit = new bool[h, d, w];
            destroyed = new Dictionary<char, int>();
            colorNames = new List<char>();
            affectedPillars = new List<Point>();

            InputHypercube();

            int bombsNum = int.Parse(Console.ReadLine());
            for (int i = 0; i < bombsNum; i++)
            {
                string[] bombAsStr = Console.ReadLine().Split(' ');
                int.Parse(bombAsStr[1]); int.Parse(bombAsStr[2]); int.Parse(bombAsStr[0]); int.Parse(bombAsStr[3]);
                Destroy(new Point(int.Parse(bombAsStr[1]), int.Parse(bombAsStr[2]), int.Parse(bombAsStr[0])), int.Parse(bombAsStr[3]));
                //Console.WriteLine();
                //PrintHypercube();
                //Console.WriteLine();
            }

            Console.WriteLine(totalDestroyed);
            colorNames.Sort();
            foreach (char key in colorNames)
            {
                int destroyedForCurrentKey = destroyed[key];
                if (destroyedForCurrentKey > 0)
                {
                    Console.WriteLine(key + " " + destroyed[key]);
                }
            }
        }
    }
}
