using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    class Program
    {
        static StringBuilder result = new StringBuilder();
        static int index = 0;
        static bool onespace = false;
        static int spaceCount = 0;
 
        static void OutputElements(int[] arr, int element)
        {
            
            if (element >= arr.Length)
            {
                return;
            }
            
            for (int i = index; i >= 0; i--)
            {
                if (element == arr[i] && i != index)
                {
                    result.Replace(' ', '(', result.ToString().IndexOf(arr[i].ToString())-1, 2);
                    spaceCount++;
                    result.Remove(result.Length - 1, 1);
                    result.Append(')');
                    onespace = true;                    
                    return;
                }
            }
            result.Append(element);
            if (onespace == false)
            {
                result.Append(' ');
                spaceCount++;
            }
            index = element;
            OutputElements(arr,arr[element]);            
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string sequence = Console.ReadLine();
            string[] numbers = sequence.Split(' ');
            int[] arr = new int[n];
            for (int i = 0; i < numbers.Length; i++)
            {
                arr[i] = int.Parse(numbers[i]);
            }
            OutputElements(arr, 0);
            Console.WriteLine(result.ToString().TrimEnd(' '));            
        }
    }
}
