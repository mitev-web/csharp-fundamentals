using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.AcademyTasks
{
    class AcademyTasks
    {
        static int[] pleasantness;
        static int variety;
        static List<int> solvedProblems;
        static int minSolved;

        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            string[] lineParts = line.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            pleasantness = new int[lineParts.Length];
            for (int i = 0; i < lineParts.Length; i++)
            {
                pleasantness[i] = int.Parse(lineParts[i]);
            }
            variety = int.Parse(Console.ReadLine());

            //variety = 2;
            //pleasantness = new int[] {1,2,3};

            solvedProblems = new List<int>();

            minSolved = pleasantness.Length;

            CalculatePl(0, pleasantness[0], pleasantness[0]);

            Console.WriteLine(minSolved);

        }

        private static void CalculatePl(int i, int min, int max)
        {
            if (i>=pleasantness.Length)
            {
                return;
            }

            if (pleasantness[i]>max)
            {
                max = pleasantness[i];
            }
            if (pleasantness[i]<min)
            {
                min = pleasantness[i];
            }
            solvedProblems.Add(pleasantness[i]);
            int difference = max - min;
            if (difference>=variety)
            {
                if (solvedProblems.Count<minSolved)
                {
                    minSolved = solvedProblems.Count;
                    solvedProblems.RemoveAt(solvedProblems.Count - 1);
                    return;
                }
                else
                {
                    solvedProblems.RemoveAt(solvedProblems.Count - 1);
                    return;
                }
            }

            CalculatePl(i + 2, min, max);
            CalculatePl(i + 1, min, max);

            solvedProblems.RemoveAt(solvedProblems.Count - 1);
        }
    }
}
