using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace RealExamII
{
    class Program
    {
        static void Main(string[] args)
        {
            Indices();
        }

        static void Indices()
        {
            int count = int.Parse(Console.ReadLine());
            string[] indices = Console.ReadLine().Split(' ');
            long[] numbers = new long[count];

            for (int i = 0; i < count; i++)
                numbers[i] = long.Parse(indices[i]);

            StringBuilder sb = new StringBuilder();
            long index = 0;
            sb.Append(index + " ");
            int replaceIndex = 0;

            while(true) {
                index = numbers[index];
                replaceIndex = sb.ToString().IndexOf(index.ToString());
                if (replaceIndex != -1)
                {
                    if (index == 0) sb.Insert(0, '(');
                    else sb.Replace(' ', '(', replaceIndex - 1, 1);
                    sb.Replace(' ', ')', sb.ToString().Length - 1, 1);
                    break;
                }
                if (index >= count || index < 0) break;
                sb.Append(index + " ");
            }

            Console.WriteLine(sb.ToString().Trim());
        }
    }
}
