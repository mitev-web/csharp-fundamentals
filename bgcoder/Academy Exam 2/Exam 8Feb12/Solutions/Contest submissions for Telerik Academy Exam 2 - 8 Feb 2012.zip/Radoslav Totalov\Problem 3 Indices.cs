using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Program
    {      

        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int numbersInArr = int.Parse(input);
            string numbers = Console.ReadLine();
            string[] arr = numbers.Split();          
            
            List<int> result = new List<int>();       

            result.Add(0);
            
            int last = Convert.ToInt32(result[result.Count-1]);           

            while (last < numbersInArr)  
            {
                int next = Convert.ToInt32(arr[last]);
                result.Add(next);                    
                last = Convert.ToInt32(result[result.Count - 1]);
                
            }
            for (int i = 0; i <= result.Count-2; i++)
            {
                
                if (i == result.Count - 2)
                {
                    Console.Write("{0}", result[i]);
                }
                else
                {
                    Console.Write("{0} ", result[i]);
                }
            }
            

        }

    }

}
