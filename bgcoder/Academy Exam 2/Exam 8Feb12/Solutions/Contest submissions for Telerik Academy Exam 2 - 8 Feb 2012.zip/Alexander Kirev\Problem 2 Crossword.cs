
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crossword
{
    class Cross
    {
        static void Check1(int n, string[] str)
        {
            string[] result = new string[n];
            char[] temp = new char[n];
            int counterTemp = 0;
            int counterRes = 0;
            for (int rows = 0; rows < n; rows++)
            {
                for (int col = 0; col < n ; col++)
                {
                    for (int row = rows; row < n+rows; row++)
                    {
                        temp[counterTemp] = str[row][col];
                        counterTemp++;
                    }
                    string tempStr = new string(temp);
                    counterTemp = 0;
                    for (int i = 0; i < str.Length ; i++)
                    {
                        if (str[i] == tempStr)
                        {
                            result[counterRes] = str[i];
                            counterRes++;
                            break;
                        }
                    }
                    if (counterRes == n)
                    {
                        List<string> sublist = new List<string>();
                        foreach (var item in result)
                        {
                            sublist.Add(item);
                            counterRes = 0;
                        }
                        listRes.Add(sublist);

                    }
                }
            }
        }
        static List<List<string>> listRes = new List<List<string>>();
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] words = new string[n * 2];
            for (int i = 0; i < words.Length; i++)
            {
                words[i] = Console.ReadLine();
            }

//            int n = 3;
//            string[] words = {
                              
//"ABC",
//"DEF",
//"GHI",
//"JKL",
//"MNO",
//"PQR",
                             //};
            string[] result = new string[n];
            Check1(n, words);

            listRes.Sort();
            if (listRes.Count == 0)
            {
                Console.WriteLine("NO SOLUTION!");
            }
            else
            {
                result = listRes[0].ToArray();

                if (result[n - 1] == null)
                {
                    Console.WriteLine("NO SOLUTION!");
                }
                else
                {
                    foreach (var item in result)
                    {
                        Console.WriteLine(item);
                    }
                }
            }


        }

        public static int rows { get; set; }
    }
}
