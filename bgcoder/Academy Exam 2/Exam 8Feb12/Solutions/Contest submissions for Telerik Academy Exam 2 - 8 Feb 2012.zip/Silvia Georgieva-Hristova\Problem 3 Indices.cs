using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Indices
{
    static int n=1;
    static int[] arr = new int[n];
    static bool[] passed = new bool[n];
    static List<int> res = new List<int>();
    static string[] splittedInput = new string[1];
    static void loop(int index)
    {
        if (index >= n || index < 0)
        {
            Print(res);
            return;
        }
        if (!passed[index])
        {
            passed[index] = true;
            res.Add(index);
            loop(arr[index]);
            return;
        }
        Print(res, index);
        return;
    }
    static void Print(List<int> res)
    {
        int len = res.Count-1;
        for(int i = 0; i< len; i++) //all except the last element
        {
            Console.Write("{0} ",res.ElementAt(i));
        }
        Console.WriteLine(res.ElementAt(len));
    }
    static void Print(List<int> res, int index)
    {
        bool bracket = false;
        int len = res.Count-1;
        if (res.ElementAt(0)==index)
        {
            Console.Write('(');
            bracket=true;
        }
        for(int i = 0; i< len; i++) //all except the last element
        {
            Console.Write(res.ElementAt(i));
            if (bracket==false)
            {
                if (res.ElementAt(i+1)==index)
                {
                    Console.Write('(');
                    bracket=true;
                }
                else
                    Console.Write(' ');
            }
            else
                Console.Write(' ');
        }
        Console.WriteLine("{0})",res.ElementAt(len));
    }
    public static void Main()
    {
        string input = Console.ReadLine();
        n = Convert.ToInt32(input);
        arr = new int[n];
        passed = new bool[n];
        input = Console.ReadLine();
        char[] delimiters = new char[] { ' ' };
        splittedInput = input.Split(delimiters, n);
        for (int i = 0; i < n; i++)
        {
            arr[i] = Convert.ToInt32(splittedInput[i]);
        }
        loop(0);
    }
}