using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class AcademyTask
    {
        List<int> lstPleasantness;
        List<int> lstSolvedTasks = new List<int>();
        int variety;
        int minimum;

        public AcademyTask(List<int> lstPleasantness, int variety)
        {
            this.lstPleasantness = lstPleasantness;
            this.variety = variety;
            minimum = lstPleasantness.Count;
        }

        public bool Solve(int previousTaskIndex)
        {
            if (lstSolvedTasks.Count > minimum)
            {
                return false;
            }

            if (lstSolvedTasks.Count > 0 && lstSolvedTasks.Max() - lstSolvedTasks.Min() >= variety)
            {
                if (minimum > lstSolvedTasks.Count)
                {
                    minimum = lstSolvedTasks.Count;
                }
                if (minimum == 2)
                {
                    return true;
                }
                return false;
            }

            for (int i = previousTaskIndex + 1; i <= previousTaskIndex + 2 && i < lstPleasantness.Count; i++)
            {
                lstSolvedTasks.Add(lstPleasantness[i]);

                if (Solve(i))
                {
                    return true;
                }

                lstSolvedTasks.RemoveAt(lstSolvedTasks.Count - 1);
            }

            return false;
        }

        public void Print()
        {
            Console.Write(minimum);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<int> lstPleasantness = new List<int>();
            int variety;

            string line = Console.ReadLine();

            string[] pleasantness = line.Split(new char[] { ' ', ','});

            for (int i = 0; i < pleasantness.GetLength(0); i++)
            {
                if (!string.IsNullOrEmpty(pleasantness[i].Trim()))
                {
                    lstPleasantness.Add(int.Parse(pleasantness[i]));
                }
            }

            line = Console.ReadLine();
            variety = int.Parse(line);

            AcademyTask at = new AcademyTask(lstPleasantness, variety);
            at.Solve(-1);
            at.Print();
        }
    }
}
