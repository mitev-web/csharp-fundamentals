using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task05
{
    class Task05
    {
        //static string input = "1, 2, 3, 4, 5";
        //static int variety = 3;
        static char[] separators = { ',', ' ' };
        const int MAX_PROBLEMS = 50;
        const int MAX_RATING = 1000;
        static int[,] temp = new int[MAX_PROBLEMS+1, MAX_RATING+1];
        static int[] Result = new int[MAX_RATING];

        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int variety = int.Parse(Console.ReadLine());
            string[] inputSplitted = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] pleasantness = new int[inputSplitted.Length];
            int[] problems = new int[pleasantness.Length];
            for (int i = 0; i < pleasantness.Length; i++)
            {
                pleasantness[i] = int.Parse(inputSplitted[i]);
                problems[i] = i;
            }
            int max = int.MinValue;
            int min = int.MaxValue;
            for (int i = 0; i < pleasantness.Length; i++)
            {
                if (pleasantness[i] > max)
                {
                    max = pleasantness[i];
                }
                if (pleasantness[i] < min)
                {
                    min = pleasantness[i];
                }
            }
            int resMin=0;
            int resEq=0;
            int res=0;
            int numberOfProblems = problems.Length;
            for (int i = 0; i < numberOfProblems; i++)
            {
                if ((max - min)-1 == pleasantness[i])
                    resMin = variety;
                if ((max - min) == pleasantness[i])
                    resEq = variety;
            }
            if(resMin!=0 && resEq!=0)
                 Console.WriteLine(Math.Min(resEq,resMin));
            else
                Console.WriteLine(min);
        }
    }
}
