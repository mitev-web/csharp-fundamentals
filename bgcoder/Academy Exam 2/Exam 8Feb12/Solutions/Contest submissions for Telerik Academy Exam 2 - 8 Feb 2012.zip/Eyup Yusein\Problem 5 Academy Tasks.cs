using System;
using System.Collections.Generic;

class AcademyTask
{
    static void Main()
    {
        short minPl = 1000;
        short maxPl = 0;

        string entered = Console.ReadLine();
        short var = short.Parse(Console.ReadLine());

        List<short> numbers = new List<short>();

        for (int i = 0; i < entered.Length; i++)
        {
            if (entered[i] != ' ' && entered[i] != ',')
            {
                numbers.Add(short.Parse(entered[i].ToString()));
            }
        }
        byte count = 1;

        for (byte i = 0; i < numbers.Count; count++)
        {
            if (numbers[i] < minPl)
            {
                minPl = numbers[i];
            }
            if (numbers[i] > maxPl)
            {
                maxPl = numbers[i];
            }
            if (var <= (maxPl - minPl))
            {
                break;
            }
            if (i == numbers.Count - 1)
            {
                break;
            }
            if (i == numbers.Count - 2)
            {
                i++;
            }
            else if (Math.Abs(numbers[i] - numbers[i + 1]) >= var || Math.Abs(numbers[i] - numbers[i + 2]) >= var)
            {
                count++;
                break;
            }
            else if (numbers[i + 2] > numbers[i + 1])
            {
                i += 2;
            }
            else
            {
                i++;
            }
        }
        Console.WriteLine(count);
    }
}
