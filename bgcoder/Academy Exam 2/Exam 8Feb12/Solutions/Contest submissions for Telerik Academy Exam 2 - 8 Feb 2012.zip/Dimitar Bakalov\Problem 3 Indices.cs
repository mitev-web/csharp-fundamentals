using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static int size;
        static int[] indexArray;
        static int[] stepVisited;
        static string output;

        static void Main(string[] args)
        {
            size = int.Parse(Console.ReadLine());

            indexArray = new int[size];
            stepVisited = new int[size];

            string text = Console.ReadLine();
            string[] bits = text.Split(' ');

            for (int i = 0; i < size; i++)
            {
                indexArray[i] = int.Parse(bits[i]);
                stepVisited[i] = -1;
            }

            int step = 1;
            int currIndex = 0;

           while ((indexArray[currIndex] < size) && (indexArray[currIndex] >= 0) && (stepVisited[indexArray[currIndex]] == -1))
            {
                output += currIndex.ToString() + ' ';
                currIndex = indexArray[currIndex];
                stepVisited[currIndex] = step;
                step++;
            }

            if ((indexArray[currIndex] >= size) || (indexArray[currIndex] < 0))
            {
                output += currIndex.ToString();
                Console.WriteLine(output);
            }
            else if (stepVisited[indexArray[currIndex]] != -1)
            {
                output += currIndex.ToString() + ")";
                //int spaceIndex = output.IndexOf(' ', stepVisited[indexArray[currIndex]]);
                int spaceIndex = 0;
                for (int i = 0; i < stepVisited[indexArray[currIndex]] ; i++)
                {
                    spaceIndex = output.IndexOf(' ', spaceIndex + 1);
                }
                char[] charOutput = output.ToCharArray();
                charOutput[spaceIndex] = '(';
                Console.WriteLine(charOutput);
            }
        }
    }
}