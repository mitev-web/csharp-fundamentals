using System;
using System.Text;
using System.Collections.Generic;

class BasicBasic
{
    static void Main()
    {
        string[] lines = new string[1000001];
        int[] variables = new int[5];
        StringBuilder sb = new StringBuilder();
        List<int> numbers = new List<int>();
        //string entered = "7 PRINT X";
        // string entered = "2 CLS";
        //string entered = "5 X=-1";
        variables[1] = 2;
        variables[0] = 3;
        variables[2] = 1;
        variables[3] = 5;
        variables[4] = -7;

        string entered = Console.ReadLine();

        while (entered.IndexOf("RUN") == -1)
        {
            int spaceIndex = entered.IndexOf(' ');
            int index = int.Parse(entered.Substring(0, spaceIndex));

            lines[index] = entered.Substring(spaceIndex + 1, entered.Length - spaceIndex - 1);
            numbers.Add(index);
            // entered = "RUN";
            entered = Console.ReadLine();
        }

        for (int i = 0; i < numbers.Count; i++)
        {
            string current = lines[numbers[i]];
            if (current.IndexOf("PRINT") != -1)
            {
                string[] printSeperated = current.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                sb.Append(variables[Convert.ToByte(printSeperated[1][0]) - 86] + "\n");
            }
            else if (current.IndexOf("CLS") != -1)
            {
                sb.Remove(0, sb.Length);
            }
            else if (current.IndexOf("STOP") != -1)
            {
                Console.WriteLine(sb);
                return;
            }
            //else if (current.IndexOf("=") != -1)
            //{
            //    string[] valueSeperated = current.Split(new char[] { ' ','=' }, StringSplitOptions.RemoveEmptyEntries);
            //    if (valueSeperated.Length==2)
            //    {
            //        variables[Convert.ToByte(valueSeperated[0][0]) - 86] = int.Parse(valueSeperated[1]); 
            //    }
            //    else 
            //    {
            //        int value=int.Parse(valueSeperated[1]
            //    }
            //}
            else if (current.IndexOf("GOTO") != -1 && current.IndexOf("IF") == -1)
            {
                string[] gotoSeperated = current.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                int number = int.Parse(gotoSeperated[1]);

                for (int j = 0; j < numbers.Count; j++)
                {
                    if (number == numbers[j])
                    {
                        i = j;
                        break;
                    }
                }
            }
        }
        Console.WriteLine(sb);
    }
}


