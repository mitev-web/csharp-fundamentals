using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("FACE");
            Console.WriteLine("ICED");
            Console.WriteLine("RING");
            Console.WriteLine("EDGE");
        }
    }
}
