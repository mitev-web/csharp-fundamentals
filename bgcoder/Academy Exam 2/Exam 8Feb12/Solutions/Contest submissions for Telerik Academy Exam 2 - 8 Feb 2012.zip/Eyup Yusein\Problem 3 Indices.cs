using System;
using System.Collections.Generic;
using System.Text;

class Indices
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        StringBuilder sb = new StringBuilder();

        int[] numbers = new int[n];
        List<int> result = new List<int>();

        string entered = Console.ReadLine();
        string[] seperated = entered.Split(' ');

        for (int i = 0; i < seperated.Length; i++)
        {
            numbers[i] = int.Parse(seperated[i]);
        }

        int index = 0;
        sb.Append(index + " ");
        result.Add(index);
        bool checker = false;
        int demo = 0;

        while (true)
        {
            result.Add(numbers[index]);
            sb.Append(numbers[index]);
            sb.Append(" ");
            index = numbers[index];
            if (index < 0 || index >= numbers.Length)
            {
                break;
            }
            demo = sb.Length;
            for (int i = 0; i < result.Count; i++)
            {
                if (numbers[index] == result[i])
                {
                    sb[sb.Length - 1] = ')';
                    checker = true;
                    if (i > 0)
                    {
                        sb[i] = '(';
                    }
                    else
                    {
                        string reserve = sb.ToString();
                        sb.Remove(0, sb.Length);
                        sb.Append("(");
                        sb.Append(reserve);
                    }
                    break;
                }
            }
            if (checker)
            {
                break;
            }
        }
        if (!checker && n != 1)
        {
            sb.Remove(demo, sb.Length - demo);
        }
        Console.WriteLine(sb);
    }
}
