using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ArrayTask
{
    class Program
    {
        static int N;
        static int[] fromTo;
        static bool[] used;
        static void Main(string[] args)
        {
            ReadInput();
            Solve();
        }

        static void ReadInput()
        {
            string line = Console.ReadLine();
            N = int.Parse(line);
            string numbers = Console.ReadLine();
            string[] differentNumber = numbers.Split(' ');
            fromTo = new int[differentNumber.Length];
            used = new bool[differentNumber.Length];
            for (int i = 0; i < differentNumber.Length; i++)
            {
                fromTo[i] = int.Parse(differentNumber[i]);
            }
        }

        static void Solve()
        {
            int currentIndex = 0;
            used[currentIndex] = true;
            List<BigInteger> answer = new List<BigInteger>();
            answer.Add(currentIndex);
            while (true)
            {
                if (currentIndex >= used.Length)
                {
                    for (int i = 0; i < answer.Count - 2; i++)
                    {
                        Console.Write(answer[i] + " ");
                    }
                    Console.WriteLine(answer[answer.Count - 2]);
                    return;

                }
                else
                {
                    currentIndex = fromTo[currentIndex];
                    answer.Add(currentIndex);
                    if (currentIndex < used.Length)
                    {
                        if (used[currentIndex] == true)
                        {
                            if (currentIndex == answer[0])
                            {
                                Console.Write("(");
                            }
                            Console.Write(answer[0]);
                            for (int i = 1; i < answer.Count - 1; i++)
                            {
                                if (currentIndex == answer[i])
                                {
                                    Console.Write("(" + +answer[i]);
                                }
                                else
                                {
                                    Console.Write(" " + answer[i]);
                                }
                            }
                            Console.WriteLine(")");
                            return;
                        }
                        else
                        {
                            used[currentIndex] = true;
                        }
                    }
                }
            }
        }
    }
}