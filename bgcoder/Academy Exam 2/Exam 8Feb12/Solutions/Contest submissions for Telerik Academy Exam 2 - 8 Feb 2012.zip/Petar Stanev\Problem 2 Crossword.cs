using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam
{
    class Program
    {
        static string isCrosswordVert(string[,] allWords,string tempWord)
        {
            string vertWord = "";
            int index = 0;
            string result = "";
            for (int row = 0; row < allWords.GetLength(0); row++)
            {
                for (int col = 0; col < allWords.GetLength(1); col++)
                {
                    vertWord += allWords[row, col];
                }
                index = vertWord.IndexOf(tempWord);
                if (index != -1)
                {
                    result = vertWord.Substring(index, 4);
                }
                vertWord = "";
                
            }
            return result;
        }

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] words = new string[n * 2];
            for (int i = 0; i < n * 2; i++)
            {
                words[i] = Console.ReadLine();
            }
            //int n = 4;
            //string[] words = { "FIRE", "ACID", "CENG", "EDGE", "FACE", "ICED", "RING", "CERN" };
            
            string[,] allWords = new string[n, n * 2];
            for (int col = 0; col < words.Length; col++)
            {
                for (int row = 0; row < n ; row++)
                {
                    allWords[row,col] = words[col].Substring(row,1);
                   // Console.Write(allWords[row,col]);
                }
                //Console.WriteLine();
            }

            string tempWord = "";
            string result = "";
            bool hasResult = false;
            List<string> finalResult = new List<string>();
            for (int row = 0; row < words.Length; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    tempWord += allWords[col, row];
                    if (col == 3)
                    {
                        result = isCrosswordVert(allWords, tempWord);
                        if (result.Length > 1)
                        {
                            //Console.WriteLine(result);
                            hasResult = true;
                            finalResult.Add(result);
                        }                        
                        tempWord = "";
                    }
                }
            }
            if (hasResult == true)
            {
                finalResult.Add(finalResult[0]);
                finalResult.Remove(finalResult[0]);
                foreach (var ch in finalResult)
                {
                    Console.WriteLine(ch);
                } 
            }
            
            if (hasResult == false)
            {
                Console.WriteLine("NO SOLUTION!");
            }

            
        }
    }
}
