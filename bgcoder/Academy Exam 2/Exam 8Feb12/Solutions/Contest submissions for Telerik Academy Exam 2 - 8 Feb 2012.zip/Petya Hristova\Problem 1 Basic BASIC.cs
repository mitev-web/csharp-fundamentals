using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
//            string BB = @"5 X=-1
//6 IF X=-1 THEN X = 0
//7 PRINT X
//8 CLS
//10 PRINT X
//20 X=X+1
//30 IF X < 4 THEN GOTO 10
//40 STOP
//50 PRINT X
//RUN";
            string BB = Console.ReadLine();
            int V = 0;
            int W = 0;
            int X = 0;
            int Y = 0;
            int Z = 0;
            string lineNum = "";
            string code = "";
            int index = 0;

            //Print finding
            for (int i = 0; i < BB.Length / 5; i++)
            {
                if (index != -1)
                {
                    int indexParam = 0;
                    index = BB.IndexOf("PRINT", index + 1);
                    for (int j = index + 5; j < BB.Length; j++)
                    {
                        if (char.IsLetterOrDigit(BB[j]))
                        {
                            indexParam = j;
                            break;
                        }
                    }
                    int spaceIndex = BB.IndexOf('\r', indexParam);
                    if ((index != -1))
                    {
                        BB = BB.Substring(0, index - 1) + " Console.WriteLine(" + BB.Substring(indexParam, (spaceIndex - indexParam)) + ")" + BB.Substring(indexParam + 1);
                    }
                }
                else
                {
                    break;
                }
            }

            //CLS finding
            for (int i = 0; i < BB.Length / 3; i++)
            {
                index = BB.IndexOf("CLS", index + 1);
                if (index != -1)
                {
                    BB = BB.Substring(0, index - 1) + " Console.Clear()" + BB.Substring(index + 4);
                }
                else
                {
                    break;
                }
            }

            //STOP finding
            for (int i = 0; i < BB.Length / 4; i++)
            {
                index = BB.IndexOf("STOP", index + 1);
                if (index != -1)
                {
                    BB = BB.Substring(0, index - 1) + " Break" + BB.Substring(index + 5);
                }
                else
                {
                    break;
                }
            }

            //IF finding
            for (int i = 0; i < BB.Length / 5; i++)
            {
                index = BB.IndexOf("IF", index + 1);
                if ((index != -1))
                {
                    int thenIndex = BB.IndexOf("THEN", index);
                    int endIndex = BB.IndexOf('\r', index);
                    BB = BB.Substring(0, index + 2) + "(" + BB.Substring(index + 2, (thenIndex - (index + 2))) + ")" + BB.Substring(thenIndex + 4);
                    //BB = BB.Substring(0, index + 2) + "(" + BB.Substring(index + 2, (thenIndex - (index + 2))) + ")" + "(" + BB.Substring(thenIndex + 4, endIndex - (thenIndex + 4)) + ")" + BB.Substring(endIndex + 1);
                }
                else
                {
                    break;
                }
            }

            //GOTO finding

            for (int i = 0; i < BB.Length / 3; i++)
            {
                string number = "";
                index = BB.IndexOf("GOTO", index + 1);

                if (index != -1)
                {
                    int endIndex = BB.IndexOf("\n", index);
                    int numIndex = 0;
                    int counter = 0;
                    for (int j = index + 4; j < endIndex; j++)
                    {
                        if (char.IsDigit(BB[j]))
                        {
                            number += BB[j];
                            numIndex = j;
                            counter++;
                        }
                    }
                    number = "\n" + number;
                    int newLineIndex = BB.IndexOf(number);
                    BB = BB.Substring(0, index - 1) + " " + " Breakout" + BB.Substring((numIndex + 1));
                    BB = BB.Substring(0, newLineIndex + number.Length) + " Breakout:" + BB.Substring(newLineIndex + number.Length);
                }
                else
                {
                    break;
                }
            }

            string[] splited = BB.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < splited.Length - 1; i++)
            {
                int spaceIndex = splited[i].IndexOf(" ");
                if (spaceIndex != -1)
                {
                    splited[i] = splited[i].Substring(spaceIndex + 1) + ";";
                }
            }
        

            //IDictionary<string, string> dict = new Dictionary<string, string>();
            //string[] splited = BB.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            //for (int i = 0; i < splited.Length - 1; i++)
            //{
            //    int firstSpaceIndex = 0;
            //    firstSpaceIndex = splited[i].IndexOf(' ');
            //    if (firstSpaceIndex != 0)
            //    {
            //        lineNum = splited[i].Substring(0, firstSpaceIndex);
            //        code = splited[i].Substring(firstSpaceIndex + 1);
            //        dict.Add(lineNum, code);
            //    }
            //    else
            //    {
            //        break;
            //    }
            //}

            //for (int i = 0; i < dict.Count; i++)
            //{
            //    dict[ 
            //}
        }
    }
}
