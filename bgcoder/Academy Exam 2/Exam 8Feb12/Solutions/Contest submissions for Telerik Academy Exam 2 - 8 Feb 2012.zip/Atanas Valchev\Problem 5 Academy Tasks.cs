using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_5
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] separators = { ',', ' ' };
            string[] stringpleasant = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int[] pleasant = new int[stringpleasant.Length];
            for (int i = 0; i < stringpleasant.Length; i++)
            {
                pleasant[i] = int.Parse(stringpleasant[i]);
            }

            input = Console.ReadLine();
            int variety = int.Parse(input);
            int solved = 0;
            int min = int.MaxValue;
            int max = int.MinValue;
            int minindex = 0;
            int maxindex = 0;
            for (int i = 0; i < pleasant.Length; i++)
            {
                if (pleasant[i] < min)
                {
                    min = pleasant[i];
                    minindex = i;
                }
                else if (pleasant[i] > max)
                {
                    max = pleasant[i];
                    maxindex = i;
                }
                if ((max - min >= variety) && (min > 0 && max > 0))
                {
                    break;
                }
            }
            if (max - min < variety)
            {
                Console.WriteLine(pleasant.Length);
                return;
            }
            int endindex = int.MinValue;
            if (maxindex > minindex)
            {
                endindex = maxindex;

            }
            else
            {
                endindex = minindex;
            }
            for (int i = 0; i < endindex; )
            {
                if (((i + 1) == maxindex) || ((i + 1) == minindex))
                {
                    i = i + 1;
                    solved++;
                }
                if (((i + 2) == maxindex) || ((i + 2) == minindex))
                {
                    i = i + 2;
                    solved++;
                }
                else
                {
                    i = i + 2;
                }
                solved++;

            }

            Console.WriteLine(solved);

        
        
        
        
        }
       


    }
}
