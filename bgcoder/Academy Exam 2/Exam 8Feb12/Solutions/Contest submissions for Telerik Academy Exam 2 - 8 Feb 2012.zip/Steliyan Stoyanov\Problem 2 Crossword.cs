using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _02_Crossword
{
    class Program
    {
        static int count;
        static int totalCount;
        static bool found = false;
        static string[] words;
        static string[] crossword;

        static void Read(StreamReader reader)
        {
            count = int.Parse(reader.ReadLine());
            totalCount = 2 * count;

            words = new string[totalCount];
            crossword = new string[count];

            for(int i = 0; i < totalCount; i++)
                words[i] = reader.ReadLine();

            Array.Sort(words);
        }

        static string GetVertical(int index)
        {
            StringBuilder result = new StringBuilder();

            for(int i = 0; i < count; i++)
                result.Append(crossword[i][index]);

            return result.ToString();
        }

        static void Print(string[] words)
        {
            for(int i = 0; i < words.Length; i++)
                Console.WriteLine(words[i]);
        }

        static bool IsInWords(string word)
        {
            int index = Array.BinarySearch(words, word);

            if(index < 0)
                return false;

            return true;
        }

        static bool IsValidCrossword()
        {
            for(int i = 0; i < count; i++)
            {
                string word = GetVertical(i);

                if(IsInWords(word) == false)
                    return false;
            }

            found = true;

            return true;
        }

        static void CheckCrossword()
        {
            if(IsValidCrossword() == true)
                Print(crossword);
        }

        static void Variations(string[] tmp, int i, int n, int k)
        {
            if(found)
                return;

            if(i >= k)
            {
                CheckCrossword();
                return;
            }

            for(int j = 0; j < n; j++)
            {
                crossword[i] = tmp[j];
                Variations(tmp, i + 1, n, k);
            }
        }

        static void Main(string[] args)
        {
            //Read(new StreamReader("c:/words.txt"));
            Read(new StreamReader(Console.OpenStandardInput()));

            int k = count;
            int n = totalCount;
            
            Variations(words, 0, n, k);

            if(!found)
                Console.WriteLine("NO SOLUTION!");
        }
    }
}
