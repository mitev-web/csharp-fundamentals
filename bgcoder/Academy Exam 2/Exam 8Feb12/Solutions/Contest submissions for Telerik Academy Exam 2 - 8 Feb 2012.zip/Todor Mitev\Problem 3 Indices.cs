using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03
{
    class Task03
    {
        static bool isInCycle = false;
        // static string input = "1 2 3 5 7 8";
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string input = Console.ReadLine();
            string[] inputSplited = input.Split();
            int[] arr = new int[n];
            //arr[0] = 0;
            for (int i = 0; i < inputSplited.Length; i++)
            {
                arr[i] = int.Parse(inputSplited[i]);
            }
            StringBuilder result = new StringBuilder();

            int index = 0;
            result.Append(0);
            int lengthOfTheCycle = 0;
            int indexStartCycle = -1;
            if (arr[index] == 0 && n != 1)
            {
                Console.WriteLine("0(0)");
            }
            else if (arr[index] == 0 && n == 1)
            {
                Console.WriteLine("0 1");
            }
            else
            {
                while (arr[index] < n && arr[index] >= 0)
                {
                    if (result.ToString().IndexOf(arr[index].ToString()) >= 0)
                    {
                        isInCycle = true;
                        indexStartCycle = index;
                        // Console.WriteLine(arr[index]);
                        // Console.WriteLine(lengthOfTheCycle);
                    }
                    if (isInCycle)
                    {
                        InCycle(arr, arr[indexStartCycle], lengthOfTheCycle);
                        //isInCycle = false;
                        //Console.WriteLine(indexStartCycle);
                        break;
                    }
                    else if (!isInCycle)
                    {
                        result.Append(" " + arr[index]);
                        index = arr[index];
                        lengthOfTheCycle++;
                    }
                }
                if (!isInCycle)
                {
                    Console.WriteLine(result.ToString().TrimEnd());
                }
            }
        }
        static void InCycle(int[] arr, int indexStartCycle, int indexEndCycle)
        {
            StringBuilder result = new StringBuilder();
            if (indexStartCycle - 1 != 0)
            {
                result.Append(0 + " ");
                for (int i = 0; i < indexStartCycle - 1; i++)
                {
                    result.Append(arr[i]);
                    if (i != indexStartCycle - 2)
                    {
                        result.Append(" ");
                    }
                }
                result.Append("(");

                for (int i = indexStartCycle - 1; i < indexEndCycle; i++)
                {
                    result.Append(arr[i]);
                    if (i != indexEndCycle - 1)
                    {
                        result.Append(" ");
                    }
                }
                result.Append(")");
                Console.WriteLine(result.ToString());
            }
            else
            {
                result.Append("0(");
                for (int i = indexStartCycle - 1; i < indexEndCycle; i++)
                {
                    result.Append(arr[i]);
                    if (i != indexEndCycle - 1)
                    {
                        result.Append(" ");
                    }
                }
                result.Append(")");
                Console.WriteLine(result.ToString());
            }
        }
    }
}