using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class Task02
    {
       //const int LINES = 4;
    // static string[] STRING = {
    //                            "ABC",
    //                            "DEF",
    //                            "GHI",
    //                            "JKL",
    //                            "MNO",
    //                            "PQR"};
    //                            
    // static string[] STRING2 = {
    //                            "FIRE",
    //                            "ACID",
    //                            "CENG",
    //                            "EDGE",
    //                            "FACE",
    //                            "ICED",
    //                            "RING",
    //                            "CERN"};
        static bool CheckIsThere(string toCheck, string[] crossword)
        {
            bool isThere = false;
            for (int i = 0; i < crossword.Length; i++)
            {
                if (toCheck == crossword[i])
                {
                    isThere = true;
                    break;
                }
            }
            return isThere;
        }
        static void Solve(string[] crossword)
        {
            List<string> solved = new List<string>();
            StringBuilder sb = new StringBuilder();
            int len = crossword.Length;
            for (int i = 0; i < crossword[0].Length; i++)
            {
                for (int j = 0; j < len-crossword[0].Length; j++)
                {
                    sb = new StringBuilder();
                    int p = j;
                    int count = 0;
                    while (count < 4)
                    {
                        sb.Append(crossword[p][i]);
                        p++;
                        count++;
                    }
                    if (CheckIsThere(sb.ToString(), crossword))
                    {
                        solved.Add(sb.ToString());
                    }
                }
            }
            solved.Sort();
            if (solved.Count == len / 2)
            {
                int count = 0;
                foreach (string s in solved)
                {
                    if (count < len / 2)
                    {
                        Console.WriteLine(s);
                    }
                    count++;
                }
            }
            else
            {
                Console.WriteLine("NO SOLUTION!");
            }
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] givenWords = new string[n * 2];
            for (int i = 0; i < n*2; i++)
            {
                givenWords[i] = Console.ReadLine();
            }
            Solve(givenWords);
        }
    }
}
