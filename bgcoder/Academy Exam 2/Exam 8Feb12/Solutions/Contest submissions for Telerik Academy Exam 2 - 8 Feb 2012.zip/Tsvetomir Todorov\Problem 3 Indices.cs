using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03Indices
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string inputSeq = Console.ReadLine();
            //int n = 6;
            //string inputSeq = "1 2 3 5 7 8";
            string[] sequence = inputSeq.Split(' ');
            int[] arr = new int[n];
            StringBuilder sb = new StringBuilder();
            sb.Append((int)0);
            
            arr[0] = int.Parse(sequence[0]);
            if (n > 1)
            {
                if (arr[0] < n)
                {
                    sb.Append(' ' + sequence[0]);
                }
                for (int i = arr[0]; i < arr.Length; i++)
                {
                    arr[i] = int.Parse(sequence[i]);
                    if ((arr[i] < n) && (arr[i] > 0))
                    {
                        sb.Append(' ' + sequence[i]);
                    }
                    else if (arr[i] == 0)
                    {
                        sb.Insert(0, '(');
                        break;
                    }
                    else { break; }
                }
                for (int i = 0; i < sb.Length - 2; i++)
                {
                    if (sb[0] == '(')
                    {
                        sb.Append(')');
                        break;
                    }
                    if (sb[sb.Length - 1] == sb[i])
                    {
                        sb.Remove(sb.Length - 2, 2);
                        sb.Append(')');
                        //sb.Insert(1, '(');
                        sb.Replace(' ', '(', 1, 1);
                    }
                }
            }
            else 
            {
                sb.Append(' ' + sequence[0]);
            }
            
            string output = sb.ToString();
            Console.WriteLine(output);
        }
    }
}