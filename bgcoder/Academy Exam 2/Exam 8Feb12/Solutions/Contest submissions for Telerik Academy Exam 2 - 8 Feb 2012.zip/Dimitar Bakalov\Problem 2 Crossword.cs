using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class ImmutableStack<T>
    {
        public readonly T Head;
        public readonly ImmutableStack<T> Tail;

        public ImmutableStack(T head, ImmutableStack<T> tail)
        {
            this.Head = head;
            this.Tail = tail;
        }

        public static ImmutableStack<T> Cons(T head, ImmutableStack<T> tail)
        {
            return new ImmutableStack<T>(head, tail);
        }

        public static ImmutableStack<T> Reverse(ImmutableStack<T> s)
        {
            ImmutableStack<T> res = null;
            while (s != null)
            {
                res = Cons(s.Head, res);
                s = s.Tail;
            }
            return res;
        }
    }

    class Program
    {
        static int n;
        static string[] inputStrings;
        static char[,] crossWord;

        static bool TestCrossword()
        {
            for (int p = 0; p < n; p++)
            {
                char[] charArray = new char[n]; 
                for (int q = 0; q < n; q++)
                {
                    charArray[q] = crossWord[q,p];
                }   
                string testWord = new string(charArray);

                if (Array.IndexOf(inputStrings, testWord) < 0)
                    return false;
            }
            
            return true;
        }

        static bool AwesomeRecursion(int toDepth, int start, int max, ImmutableStack<int> indices)
        {
            if (toDepth < 0)
            {
                throw new ArgumentException("toDepth should be >= 0");
            }
            else if (toDepth == 0)
            {
                indices = ImmutableStack<int>.Reverse(indices);

                int i = 0;
                while (indices != null)
                {
                    for (int j = 0; j < n; j++)
                        crossWord[i,j] = inputStrings[indices.Head][j];
                    indices = indices.Tail;
                    i++;
                }

                if (TestCrossword())
                    return true; 
            }
            else
            {
                for (int i = start; i < max; i++)
                {
                    if (AwesomeRecursion(toDepth - 1, 0, max, ImmutableStack<int>.Cons(i, indices)))
                        return true;
                }
            }

            return false;
        }


        static void Main(string[] args)
        {

            n = int.Parse(Console.ReadLine());
            inputStrings = new string[2 * n];
            crossWord = new char[n, n];

            for (int i = 0; i < 2 * n; i++)
            {
                inputStrings[i] = Console.ReadLine();
            }

            Array.Sort(inputStrings);

            if (AwesomeRecursion(n, 0, n * 2, null))
            {
                for (int p = 0; p < n; p++)
                {
                    for (int q = 0; q < n; q++)
                    {
                        Console.Write(crossWord[p,q]);
                    }
                    Console.WriteLine();
                } 
            }
            else
                Console.WriteLine("NO SOLUTION!");
        }
    }
}