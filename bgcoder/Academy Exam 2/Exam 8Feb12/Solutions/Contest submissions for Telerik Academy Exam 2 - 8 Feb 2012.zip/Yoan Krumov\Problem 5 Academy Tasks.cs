using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Academy_Tasks
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string listNumbers = Console.ReadLine();
            string separator=", ";
            string[] stringList = listNumbers.Split(separator.ToCharArray(),
                                      StringSplitOptions.RemoveEmptyEntries);
            int[] pleasantless = new int[stringList.Length];
            for (int i = 0; i < stringList.Length; i++)
            {
                pleasantless[i] = (int)Convert.ChangeType(stringList[i], typeof(int));
              //  Console.WriteLine(pleasantless[i]);
            }

            string userInput = Console.ReadLine();
            ushort variety = ushort.Parse(userInput);
            int result = 0;
            for (int i = 0; i < pleasantless.Length; i++)
            {
                if ((pleasantless[0]-pleasantless[1])>=variety||(pleasantless[1]-pleasantless[0])>=variety)
                {
                     result = 2;
                }
                else if ((pleasantless[0]-pleasantless[2])>=variety||(pleasantless[2]-pleasantless[0])>=variety)
                {
                    result = 2;

                }
                else if ((pleasantless[0] - pleasantless[pleasantless.Length-1]) >= variety || (pleasantless[pleasantless.Length-1] - pleasantless[0]) >= variety)
                {
                    result = 5;
                }
                else if ((pleasantless[0] - pleasantless[1]) >= variety || (pleasantless[1] - pleasantless[0]) >= variety)
                {
                    result = 4;
                }
            }

            Console.WriteLine(result);
            
        }
    }
}

