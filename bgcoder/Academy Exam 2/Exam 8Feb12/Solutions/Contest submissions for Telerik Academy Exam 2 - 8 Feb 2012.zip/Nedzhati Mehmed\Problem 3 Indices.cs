using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    class Program
    {
        public static int Tok (int n,int max,int[] Array,int br,int[] Arr)
        {
            
            
            Arr[br] = n;
            br++;
            int k = Array[n];
            for (int i = 0; i < br; i++)
            {
                if (Arr[i] == k)
                {
                    Console.Write("0(");
                    for (int b=1; b < br; b++)
                    {
                        if (b == 1)
                        {
                            Console.Write(Arr[b]);
                        }
                        else
                        {
                            Console.Write(" " + Arr[b]);
                        }
                       
                    }
                    Console.Write(")");
                    return 0;
                }
            }
            if (k > max || k<0)
            {
                for (int b = 0; b < br; b++)
                {
                    if (b == 0)
                    {
                        Console.Write(Arr[b]);
                    }
                    else
                    {
                        Console.Write(" "+Arr[b]);
                    }
                }
                return 0;
            }

            return Tok(k, max, Array,br,Arr);
            
            
        }
        static void Main(string[] args)
        {
            int variety = int.Parse(Console.ReadLine());
            string example = Console.ReadLine();
            char[] NumberSeperators = new char[] {' '};
            string[] numbers = example.Split(NumberSeperators, StringSplitOptions.RemoveEmptyEntries);
            int[] num = new int[numbers.Length];
            for (int x = 0; x < variety; x++)
            {
                num[x] = Convert.ToInt32(numbers[x]);

            }
            
            
           // int[] array = { 5, 2, 3, 4, 6, 1 };
            int broqch = 0;
            int max = num.Length - 1;
            int[] arr = new int[200001];
          
            Tok(0, max, num,broqch,arr);
            

        }
    }
}
