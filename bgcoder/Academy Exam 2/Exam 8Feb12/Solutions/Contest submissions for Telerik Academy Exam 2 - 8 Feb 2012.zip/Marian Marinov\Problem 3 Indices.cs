using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indices
{
    
    class Program
    {
        static int[] ARR;
        static List<int> output = new List<int>();


        static void Print()
        {
            StringBuilder sb = new StringBuilder();
            foreach (int i in output)
            {
                sb.Append(i + " ");
            }
            try
            {
                sb.Remove(sb.Length - 1, 1);
            }
            catch { }
            sb.Append("\n");

            Console.Write(sb);
        }

        static void Print(int beginCycle, int endCycle)
        {
            StringBuilder sb = new StringBuilder();

            foreach (int i in output)
            {
                if ( i == beginCycle)
                {
                    try
                    {
                        sb.Remove(sb.Length - 1, 1);
                    }
                    catch { }
                    sb.Append("(");
                }

                if (i == endCycle)
                {
                    sb.Append(i + ") ");
                }
                else
                {
                    sb.Append(i + " ");
                }
            }

            sb.Remove(sb.Length - 1, 1);
            sb.Append("\n");

            Console.Write(sb);
        }

        static void NextValue(int index)
        {
            if (index < 0 || index >= ARR.Length)
            {
                Print();
                return;
            }
            
            foreach (int i in output)
            {
                if (i == ARR[index])
                {
                    if (i != index)
                    {
                        output.Add(index);
                    }
                    Print(i, index);
                    return;
                }
            }
            
            output.Add(index);

            NextValue(ARR[index]);
        }

        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            ARR = new int[N];
            string[] numbers = Console.ReadLine().Split(' ');

            for (int i = 0; i < numbers.Length; i++)
            {
                ARR[i] = int.Parse(numbers[i]);
            }

            NextValue(0);
        }
    }
}
