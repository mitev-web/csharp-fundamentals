using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Academy_Tasks
{
    class Program
    {
        static void Main(string[] args)
        {
            string tokens = Console.ReadLine();
            string[] newTokens = Regex.Split(tokens, ", ");
            uint[] pl = new uint[newTokens.Length];
            for (int i = 0; i < newTokens.Length; i++)
            {
                pl[i] = uint.Parse(newTokens[i]);
            }
            //uint[] pl = {6, 2, 6, 2, 6, 3, 3, 3, 7};
            //uint[] pl = { 1, 2, 3 };
            //uint [] pl = {1, 2, 3, 4, 5};
            uint maxPl = 0;
            uint minPl = 0;
            //uint variety = 2;
            uint curMinPl = 0;
            uint variety = uint.Parse(Console.ReadLine());
           for (int i = 0; i < pl.Length; i++)
           {

               if (maxPl - curMinPl >= variety)
               {
                   uint result = maxPl - variety;
                   Console.Write(result);
                   break;
               }
               if (pl[i] > minPl)
               {
                   minPl = pl[i];
                   curMinPl = minPl;
                   if (curMinPl > minPl)
                   {
                       curMinPl = minPl;
                   }
               }
               if (minPl > maxPl)
               {
                   maxPl = minPl;
               }

           }
        }
    }
}
