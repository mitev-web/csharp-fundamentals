using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CROSSWORD
{
    class Program
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            string[] str = new string[n];
            for (int i = 0; i < str.Length; i++)
            {
                str[i] = Console.ReadLine();
            }
            
            Console.WriteLine("NO SOLUTION !");
             

        }
    }
}