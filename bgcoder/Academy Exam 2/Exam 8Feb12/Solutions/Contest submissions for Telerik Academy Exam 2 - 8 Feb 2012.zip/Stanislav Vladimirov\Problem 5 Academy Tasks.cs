using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task05
{
    class AcademyTasks
    {
        static byte n;
        static short[] pList;
        static int minSolvedProblems = short.MaxValue;
        static short v;

        static void Main(string[] args)
        {
            ReadInput();

            short solvedCounter = 0;
            SolveProblems(0, pList[0], pList[0], solvedCounter);

            Console.WriteLine(minSolvedProblems);

        }

        static void SolveProblems(int i, int minPles, int maxPles, int solvedCounter)
        {            
            if (i < n)
            {
                if (pList[i] < minPles)
                {
                    minPles = pList[i];
                }
                if (pList[i] > maxPles)
                {
                    maxPles = pList[i];
                }
                solvedCounter++;
                if (maxPles - minPles >= v)
                {
                    if (solvedCounter < minSolvedProblems)
                    {
                        minSolvedProblems = solvedCounter;
                    }
                    return;
                }
                else if (solvedCounter >= minSolvedProblems)
                {
                    return;
                }
                else
                {
                    SolveProblems(i + 1, minPles, maxPles, solvedCounter);
                    SolveProblems(i + 2, minPles, maxPles, solvedCounter);
                }
            }                    	
        }

        static void ReadInput()
        {
            string p = Console.ReadLine();
            string[] list = p.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            n = (byte)list.Length;
            pList = new short[n];
            for (short i = 0; i < n; i++)
            {
                pList[i] = short.Parse(list[i]);
            }
            v = short.Parse(Console.ReadLine());
        }
    }
}
