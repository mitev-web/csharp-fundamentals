using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task4
{
    struct Point
    {
        public int x ;
        public int y ;
        public int z ;

        public Point(int x_ = 0, int y_ = 0, int z_ = 0)
        {
            x = x_;
            y = y_;
            z = z_;
        }
    }

    struct Bomb
    {
        public int x ;
        public int y ;
        public int z;
        public double p ;

        Bomb(int x_ = 0, int y_ = 0, int z_ = 0, double p_ = 0 )
        {
            x = x_;
            y = y_;
            z = z_;
            p = p_;
        }
    }
    class Program
    {
        public const int maxSize = 101;
        public static char[,,] field = new char[maxSize, maxSize, maxSize];
        public static int detonatedBombs = 0;
        public static int[] countLetters = new int[26];

        static void Main(string[] args)
        {
            string inputWHD = Console.ReadLine();
            string[] WHD = inputWHD.Split(' ');

            int W = int.Parse(WHD[0]);
            int H = int.Parse(WHD[1]);
            int D = int.Parse(WHD[2]);
            bool[] usedLetters = new bool[26];

            string oneLevel = "";
            for (int height = 0; height < H; height++)
            {
                oneLevel = Console.ReadLine();
                string [] width = oneLevel.Split(' ');
                for (int depth = 0; depth < D; depth++)
                {
                    for (int wide = 0; wide < W; wide++)
                    {
                        field[wide, height, depth] = width[depth][wide];
                        if(!usedLetters[field[wide, height, depth] - 65])
                        {
                            usedLetters[field[wide, height, depth] - 65] = true;
                        }
                    }
                }
            }

            int N = int.Parse(Console.ReadLine());

            Bomb[] bombs = new Bomb[N];
            string oneBomb = "";
            for (int numBomb = 0; numBomb < N; numBomb++)
            {
                oneBomb = Console.ReadLine();
                string[] getMeasure = oneBomb.Split(' ');
                bombs[numBomb].x = int.Parse(getMeasure[0]);
                bombs[numBomb].y = int.Parse(getMeasure[1]);
                bombs[numBomb].z = int.Parse(getMeasure[2]);
                bombs[numBomb].p = double.Parse(getMeasure[3]);
            }

            DetonateAllBombs(bombs, W, H, D);

            Console.WriteLine(detonatedBombs);
            for (int i = 0; i < 26; i++)
            {
                if (usedLetters[i])
                {
                    if (countLetters[i] != 0)
                    {
                        Console.WriteLine("{0} {1}", (char)(i + 65), countLetters[i]);
                    }
                }
            }

        }

        private static void MoveBlocks(int W, int H, int D)
        {
            int countDestr = 0;
            int startHeight = 0;
            for (int width = 0; width < W; width++)
            {
                for (int depth = 0; depth < D; depth++)
                {
                    countDestr = 0;
                    for (int height = 0; height < H; height++)
                    {
                        if (!char.IsLetter(field[width, height, depth]))
                        {
                            if (field[width, height, depth] == '.')
                                break;
                            
                            if (countDestr == 0)
                            {
                                startHeight = height;
                            }

                            countDestr++;
                        }
                    }

                    int toContinue = startHeight;
                    for (int height = startHeight; height < startHeight + countDestr + 1; height++)
                    {
                        if (height + countDestr < H)
                            field[width, height, depth] = field[width, height + countDestr, depth];
                        else
                        {
                            toContinue = height;
                            break;
                        }
                    }

                    if (toContinue != startHeight)
                    {
                        for (int height = toContinue; height < H; height++)
                        {
                            field[width, height, depth] = '.';
                        }
                    }
                }
            }
        }
        private static double GetDistance(Point one, Point two)
        {
            return Math.Sqrt((one.x - two.x) * (one.x - two.x) + (one.y - two.y) * (one.y - two.y) + (one.z - two.z) * (one.z - two.z));
        }
        private static void DetonateBomb(Bomb bomb, int W, int H, int D)
        {
            for (int firstVect = -1; firstVect <= 1; firstVect++)
            {
                if (firstVect == 0)
                    continue;
                for (int secondVect = -1; secondVect <= 1; secondVect++)
                {
                    if (secondVect == 0)
                        continue;
                    for (int thirdVect = -1; thirdVect <= 1; thirdVect++)
                    {
                        if (thirdVect == 0)
                            continue;
                        for (int width = bomb.x; width < W && width >= 0; width += firstVect)
                        {
                            for (int height = bomb.y; height < H && height >= 0; height += secondVect)
                            {
                                for (int depth = bomb.z; depth < D && depth >= 0; depth += thirdVect)
                                {
                                    if (GetDistance(new Point(bomb.x, bomb.y, bomb.z), new Point(width, height, depth)) <= bomb.p)
                                    {
                                        if (char.IsLetter(field[width, height, depth]))
                                        {
                                            detonatedBombs++;
                                            countLetters[field[width, height, depth] - 65]++;
                                        }

                                        if (field[width, height, depth] == '.')
                                            continue;

                                        field[width, height, depth] = '#';
                                    }
                                    else
                                        break;
                                }
                            }
                        }
                    }
                }
            }
        }
        private static void DetonateAllBombs(Bomb[] bombs, int W, int H, int D)
        {
            for (int i = 0; i < bombs.Length; i++)
            {
                DetonateBomb(bombs[i], W, H, D);
                MoveBlocks(W, H, D);
            }
        }
    }
}
