
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

 

namespace task5

{

    class Program

    {

        static void Main(string[] args)

        {

 

 

            int[] pleasantnessArray = new int[] { 1, 2, 3 };

            //for (int i = 0; i < pleasantnessArray.Length ; i++)

            //{

            //    pleasantnessArray[i] = int.Parse(Console.ReadLine());

            //}

            int solvedProblems = 0;

            int variety = 2;  //int.Parse(Console.ReadLine());

            for (int i = 1; i < pleasantnessArray.Length; i++)

            {

 

                if (pleasantnessArray[i] - pleasantnessArray[i - 1] >= variety)

                {

                    Console.WriteLine(solvedProblems);

                }

                solvedProblems++;

 

            }

 

            Console.WriteLine(solvedProblems);

             

        }

    }

}