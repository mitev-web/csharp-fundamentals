using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
  
  
class Crossword
{
    static string[] allWords;
    static string bestCross = "";
    static bool first = true;
    static string[] variat;
  
    static void Main(string[] args)
    {
        string finalResut;
        string line;
        string[] lineSplited;
        int N;
  
        //StreamReader reader = new StreamReader("test2.txt");
  
        line = Console.ReadLine();
        N = int.Parse(line);
  
        allWords = new string[2 * N];
        string[] subset = new string[N];
  
        for (int i = 0; i < 2 * N; i++)
        {
            line = Console.ReadLine();
            allWords[i] = line;
        }
  
  
        List<string> strList = new List<string>(allWords);
  
        variat = new string[allWords.Length / 2];
        Variations(allWords.Length, allWords.Length / 2, 0);
          
        if (bestCross.Length > 2)
        {
            Console.WriteLine(bestCross);
        }
        else
        {
            Console.WriteLine("NO SOLUTION!");
        }
  
    }
  
    static void Variations(int n, int k, int current)
    {
  
        if (current >= k)
        {
            PrintSub();
            return;
        }
  
        for (int i = 0; i < n; i++)
        {
            variat[current] = allWords[i];
  
            Variations(n, k, current + 1);
        }
  
    }
  
    static void PrintSub()
    {
        string word;
        StringBuilder currentCrossword = new StringBuilder();
        StringBuilder verticalWord = new StringBuilder();
        string verWord;
        string curCros;
  
        int matches = 0;
  
         
            bool isMatch = false;
  
            for (int j = 0; j < variat.Length; j++)
            {
                verticalWord.Clear();
                for (int k = 0; k < variat.Length; k++)
                {
                    verticalWord.Append(variat[k][j]);
                }
  
                isMatch = false;
                verWord = verticalWord.ToString();
  
                foreach (var item in allWords)
                {
                    if (item == verWord)
                    {
                        isMatch = true;
                        break;
                    } 
                }
                  
                if (isMatch == false)
                {
                    break;  
                }
                else
                {
                    matches++;
                }
  
            }
              
  
        if (matches == 4)
        {
              
            for (int i = 0; i < variat.Length; i++)
            {
                currentCrossword.Append(variat[i]);
  
                if (i != variat.Length - 1)
                {
                    currentCrossword.Append("\n");
                } 
  
            }
              
            curCros = currentCrossword.ToString();
  
            if (first == true)
            {
                bestCross = curCros;
                first = false;
  
            }else if (String.Compare(bestCross ,curCros) >= 0)
            {
                bestCross = curCros;
            }
        }
  
    }
  
}