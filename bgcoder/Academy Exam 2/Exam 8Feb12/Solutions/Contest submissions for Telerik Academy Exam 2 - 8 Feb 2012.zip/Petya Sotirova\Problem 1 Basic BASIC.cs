using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace BasicBASIC
{
    class Program
    {
        static SortedDictionary<char, int> values = new SortedDictionary<char, int>();

        static void Calc(string expr)
        {
            StringBuilder sb=new StringBuilder();
            for (int i = 0; i < expr.Length; i++)
            {
                if (expr[i] != ' ')
                    sb.Append(expr[i]);
            }
            expr = sb.ToString();
            sb.Clear();

            if(values.ContainsKey(expr[2]))
            {
                if (expr.Length == 3)
                    values[expr[0]] = values[expr[2]];
                else
                {
                    StringBuilder s = new StringBuilder();
                    if (expr[4] >= '0' && expr[4] <= '9')
                    {
                        int i = 4;
                        while (i < expr.Length)
                        {
                            s.Append(expr[i]);
                        }
                        switch (expr[3])
                        {
                            case '-':
                                values[expr[0]] = values[expr[2]] - int.Parse(s.ToString());
                                break;
                            case '+':
                                values[expr[0]] = values[expr[2]] + int.Parse(s.ToString());
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        switch (expr[3])
                        {
                            case '-':
                                values[expr[0]] = values[expr[2]] - values[expr[4]];
                                break;
                            case '+':
                                values[expr[0]] = values[expr[2]] + values[expr[4]];
                                break;
                            default:
                                break;
                        }   
                    }
                }
            }
            
            else if (expr[2] == '-')
            {
                if (expr[expr.Length - 1] >= '0' && expr[expr.Length - 1] <= '9')
                {
                    for (int i = 3; i < expr.Length; i++)
                    {
                        sb.Append(expr[i]);
                    }
                    values[expr[0]] = -1*int.Parse(sb.ToString());
                }
                else
                {
                    int i;
                    for (i = 3; i < expr.Length; i++)
                    {
                        if (expr[i] >= '0' && expr[i] <= '9')
                            sb.Append(expr[i]);
                        else
                            break;
                    }
                    switch (expr[i])
                    {
                        case'-':
                            values[expr[0]] = -1 * int.Parse(sb.ToString()) - values[expr[i + 1]];
                            break;
                        case'+':
                            values[expr[0]] = -1 * int.Parse(sb.ToString()) + values[expr[i + 1]];
                            break;
                        default:
                            break;
                    }
                }

            }
            else if (expr[2] >= '0' && expr[2] <= '9')
            {
                StringBuilder num = new StringBuilder();
                int i=2;
                while (i<expr.Length)
                {
                    if (expr[i] >= '0' && expr[i] <= '9')
                    {
                        num.Append(expr[i]);
                        i++;
                    }
                    else
                        break;
                   
                }

                        if (i == expr.Length )
                        {
                            values[expr[0]] = int.Parse(num.ToString());
                        }
                        else
                        {
                            switch (expr[i])
                            {
                                case'-':
                                    values[expr[0]] = int.Parse(num.ToString()) - values[expr[i + 1]];
                                    break;
                                case'+':
                                    values[expr[0]] = int.Parse(num.ToString()) - values[expr[i + 1]];
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }

        static bool Eval(string expr)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < expr.Length; i++)
            {
                sb.Append(expr[i]);
            }
            expr=sb.ToString();

            switch (expr[1])
            {
                case '=':
                    {
                        if (values.ContainsKey(expr[0]))
                        {
                            if (values.ContainsKey(expr[2]))
                            {
                                if (values[expr[0]] == values[expr[2]])
                                    return true;
                                else
                                    return false;
                            }
                            else
                            {
                                StringBuilder num = new StringBuilder();
                                for (int i = 2; i < expr.Length; i++)
                                {
                                    num.Append(expr[i]);
                                }
                                if (values[expr[0]] == int.Parse(num.ToString()))
                                    return true;
                                else return false;
                            }
                        }
                        else
                        {
                            StringBuilder s=new StringBuilder();
                            int i = 0;
                            while (true)
                            {
                                if (expr[i] >= '0' && expr[i] <= '9')
                                {
                                    s.Append(expr[i]);
                                }
                                else break;

                            }
                            if (values.ContainsKey(expr[i]))
                            {
                                if (values[expr[0]] == values[expr[i]])
                                    return true;
                                else
                                    return false;
                            }
                            else
                            {
                                StringBuilder num = new StringBuilder();
                                for (int j = i; j < expr.Length; j++)
                                {
                                    num.Append(expr[i]);
                                }
                                if (values[expr[0]] == int.Parse(num.ToString()))
                                    return true;
                                else return false;
                            }
                        }
                    }
                case '<':
                    {
                        if (values.ContainsKey(expr[0]))
                        {
                            if (values.ContainsKey(expr[2]))
                            {
                                if (values[expr[0]] < values[expr[2]])
                                    return true;
                                else
                                    return false;
                            }
                            else
                            {
                                StringBuilder num = new StringBuilder();
                                for (int i = 2; i < expr.Length; i++)
                                {
                                    num.Append(expr[i]);
                                }
                                if (values[expr[0]] < int.Parse(num.ToString()))
                                    return true;
                                else return false;
                            }
                        }
                        else
                        {
                            StringBuilder s = new StringBuilder();
                            int i = 0;
                            while (true)
                            {
                                if (expr[i] >= '0' && expr[i] <= '9')
                                {
                                    s.Append(expr[i]);
                                }
                                else break;

                            }
                            if (values.ContainsKey(expr[i]))
                            {
                                if (values[expr[0]] < values[expr[i]])
                                    return true;
                                else
                                    return false;
                            }
                            else
                            {
                                StringBuilder num = new StringBuilder();
                                for (int j = i; j < expr.Length; j++)
                                {
                                    num.Append(expr[i]);
                                }
                                if (values[expr[0]] < int.Parse(num.ToString()))
                                    return true;
                                else return false;
                            }
                        }
                    }
                case'>':
                    if (values.ContainsKey(expr[0]))
                    {
                        if (values.ContainsKey(expr[2]))
                        {
                            if (values[expr[0]] > values[expr[2]])
                                return true;
                            else
                                return false;
                        }
                        else
                        {
                            StringBuilder num = new StringBuilder();
                            for (int i = 2; i < expr.Length; i++)
                            {
                                num.Append(expr[i]);
                            }
                            if (values[expr[0]] > int.Parse(num.ToString()))
                                return true;
                            else return false;
                        }
                    }
                    else
                    {
                        StringBuilder s = new StringBuilder();
                        int i = 0;
                        while (true)
                        {
                            if (expr[i] >= '0' && expr[i] <= '9')
                            {
                                s.Append(expr[i]);
                            }
                            else break;

                        }
                        if (values.ContainsKey(expr[i]))
                        {
                            if (values[expr[0]] > values[expr[i]])
                                return true;
                            else
                                return false;
                        }
                        else
                        {
                            StringBuilder num = new StringBuilder();
                            for (int j = i; j < expr.Length; j++)
                            {
                                num.Append(expr[i]);
                            }
                            if (values[expr[0]] > int.Parse(num.ToString()))
                                return true;
                            else return false;
                        }
                    }
                default:
                    return false;
            }
        }

        static void Main(string[] args)
        {
            List<string> inp=new List<string>();
            bool inpENd = false;
            while (inpENd == false)
            {
                string str = Console.ReadLine();
                if (str == "RUN")
                    inpENd = true;
                else
                    inp.Add(str);
            }

            int[] line = new int[inp.Count];
            string[] command = new string[line.Length];

            for(int j=0;j<inp.Count;j++)
            {
                StringBuilder sb = new StringBuilder();
                int sign = 1;
                for (int i = 0; i < inp[j].Length; i++)
                {
                    if (inp[j][i] == '-')
                        sign = -1;
                    else if(inp[j][i]>='0'&&inp[j][i]<='9')
                        sb.Append(inp[j][i]);
                    else
                    {
                        line[j] = int.Parse(sb.ToString());
                        if (sign == -1) line[j] *= -1;
                        sb.Clear();
                        sb.Append(inp[j], i, inp[j].Length - i);
                        command[j]=sb.ToString().Trim();
                        break;
                    }
                }
            }
            
            values.Add('V',0);
            values.Add('W',0);
            values.Add('X',0);
            values.Add('Y',0);
            values.Add('Z',0);

            int k;
            for (k = 0; k < command.Length; k++)
            {
                if (values.ContainsKey(command[k][0]))
                {
                    Calc(command[k]);
                }
                else if (command[k][0] == 'I')
                {
                    if (Eval(command[k]))
                    {
                        if (command[k].Contains("GOTO"))
                        {
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < command[k].Length; i++)
                            {
                                if (command[k][i] >= '0' && command[k][i] <= '9')
                                {
                                    sb.Append(command[k][i]);
                                }
                            }
                            int l = int.Parse(sb.ToString());
                            for (int i = 0; i < line.Length; i++)
                            {
                                if (l == line[i])
                                {
                                    l = i;
                                    break;
                                }
                            }
                            continue;
                        }
                        else   
                        Calc(command[k].Substring(command[k].IndexOf("THEN"), command[k].Length - command[k].IndexOf("THEN")));

                    }
                    else
                        continue;
                }
                else if (command[k][0] == 'P')
                {
                    for (int i = 5; i < command[k].Length; i++)
                    {
                        if(values.ContainsKey(command[k][i]))
                        {
                            int tmp;
                            values.TryGetValue(command[k][i], out tmp);
                            Console.WriteLine(tmp);
                            break;
                        }
                    }
                }
                else if (command[k][0] == 'C')
                {
                    Console.Clear();
                }
                else if (command[k][0] == 'S')
                {
                    break;
                }
                else if (command[k][0] == 'G')
                {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < command[k].Length; i++)
                    {
                        if (command[k][i] >= '0' && command[k][i] <= '9')
                        {
                            sb.Append(command[k][i]);
                        }
                    }
                    int l = int.Parse(sb.ToString());
                    for (int i = 0; i < line.Length; i++)
                    {
                        if (l == line[i])
                        {
                            l = i;
                            break;
                        }
                    }

                    continue;
                }
            }

        }
    }
}
