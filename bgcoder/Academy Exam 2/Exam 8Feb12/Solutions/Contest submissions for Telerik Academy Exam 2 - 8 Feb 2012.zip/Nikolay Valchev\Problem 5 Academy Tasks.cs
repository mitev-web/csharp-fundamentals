using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AcademyTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            //string str = "1, 2, 3, 4, 5";
            //string str = "1, 2, 3";
            //string str = "1, 2, 3, 0, 4, 7";
            //string str = "6, 2, 6, 2, 6, 3";
            //string[] pleasantnessStr = str.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            string[] pleasantnessStr = Console.ReadLine().Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            int variety = int.Parse(Console.ReadLine());
            int[] pleasentness = new int[pleasantnessStr.Length];
            for (int i = 0; i < pleasantnessStr.Length; i++)
            {
                pleasentness[i] = int.Parse(pleasantnessStr[i]);
            }

            Console.WriteLine(returnTasks(pleasentness,variety));
        }

        static int returnTasks(int[] tasks, int variety)
        {
            int max = tasks[0];
            if (tasks.Length < 2)
            {
                return 1;
            }
            int min = tasks[1];
            int indexMax = 0;
            int indexMin = 1;
            if (min > max)
            {
                max = min + max;
                min = max - min;
                max = max - min;
                indexMax = 1;
                indexMin = 0;
            }


            int indexLast = 0;
            bool shouldSolveAlltasks = true;
            for (int i = 1; i < tasks.Length; i++)
            {
                if (Math.Abs(max - tasks[i]) >= variety) 
                {
                    shouldSolveAlltasks = false;
                    indexMin = -1;
                    indexLast = i;
                    break;
                }

                if (Math.Abs(min - tasks[i]) >= variety)
                {
                    shouldSolveAlltasks = false;
                    indexMax = -1;
                    indexLast = i;
                    break;
                }

                if (max < tasks[i])
                {
                    max = tasks[i];
                    indexMax = i;
                }
                if (min > tasks[i])
                {
                    min = tasks[i];
                    indexMin = i;
                }

            }

            if (shouldSolveAlltasks)
            {
                return tasks.Length;
            }

            return (indexLast + 1) / 2 + 1;
        }
    }  
}
