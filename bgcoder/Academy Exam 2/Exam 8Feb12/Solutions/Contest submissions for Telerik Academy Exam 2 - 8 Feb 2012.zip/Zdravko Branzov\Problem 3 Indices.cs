using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indeces
{
    class Program
    {
        static List<string> list = new List<string>();
        
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] array = new string[n];
            string input = Console.ReadLine();
            array = input.Split(new char[] {' '});
            //int[] intArray = new int[n];


            //for (int i = 0; i < array.Length; i++)
            //{
            //    intArray[i] = int.Parse(array[i]);
            //}

            Index(array);
            Print(list);
        }

        public static void Index (string[] array)
        {
            for (int index = 0; index < array.Length; index++)
            {
                list.Add(index.ToString());
                index =int.Parse( array[index]);//parse
                index--;
                int next = index+1;
                if(list.Contains(next.ToString()))
                {
                    int insertion = list.IndexOf(next.ToString());
                    list.Insert(insertion, "(");
                    list.Add(")");
                    break;
                }
                

            }

        }

        static void Print(List<string> list)
        {
            for(int i = 0 ; i< list.Count; i++)
            {
                Console.Write(list[i]);
                if (list[i] != list.Last() && list[i+1]!="(" && list[i]!="(" && list[i+1]!=")")
                {
                    Console.Write(" ");
                }
            }
        }
    }
}
