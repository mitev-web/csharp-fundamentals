using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class BasicBASIC
{
    public static class line
    {
        public int index;
        public List<string> commands;
        //public string commandLine;
        public line(List<string> words)
        {
            index = (int)words.ElementAt(0);
            words.RemoveAt(0);
            commands = words;
            /*StringBuilder temp = new StringBuilder();
            foreach (string word in commands)
                temp.Append(word+" ");
            temp.Remove(temp.Length-1,1);
            commandLine = temp.ToString();*/
        }
    }
    public static List<line> lines = new List<line>();
    public static string processInputLine (string inputLine)
    {
        char[] delimiters = new char[] { ' ', '\t' };
        List<string> words = new List<string>(inputLine.Split(delimiters, StringSplitOptions.RemoveEmptyEntries));
        if (words.ElementAt(0) == "run")
            return "run";
        lines.Add(new line(words));
        return "ok";
    }
    public static int v, w, x, y, z = 0;
    public static StringBuilder result = new StringBuilder();
    public static bool reachedStop = false;
    public static bool reachedGoto = false;
    public static int gotoIndex = -1; //there isn't GOTO
    public static int startIndex = lines.ElementAt(0).index;
    public static void loopLines(int startIndex)
    {
        if (reachedStop)
            return;
        if (reachedGoto)
            loopLines(gotoIndex);
        line current = lines.Find(line => line.index == startIndex);
        int currIndex = lines.IndexOf(current);
        for (int i = currIndex; i < lines.Count; i++)
        {
            executeLine(lines.ElementAt(i));
        }
    }
    public static void executeLine(line current)
    {
        char c = current.commands.ElementAt(0)[0];
        switch (c)
        {
            case 'v':
            case 'w':
            case 'x':
            case 'y':
            case 'z':
                executeChangeValue(current);
                break;
            case 'i':
                executeIf(current);
                break;
            case 'g':
                executeGoto(current);
                break;
            case 'c':
                executeCls(current);
                break;
            case 'p':
                executePrint(current);
                break;
            case 's':
                executeStop(current);
                break;
        }
    }
    public static void executeChangeValue(line current)
    {
        string temp = current.commands[0];
        if (temp[2] == '+' || temp[2] == '-')
            temp = temp[0] + temp[1] + '0' + temp.Substring(2);

    }
    public static void executeIf(line current)
    {
    }
    public static void executeGoto(line current)
    {
        reachedGoto = true;
        gotoIndex = (int)(current.commands[1]);
    }
    public static void executeCls(line current)
    {
        result.Clear();
    }
    public static void executePrint(line current)
    {
        int value = 0;
        char variable = current.commands[1][0];
        switch (variable)
        {
            case 'v':
                value = v; break;
            case 'w':
                value = w; break;
            case 'x':
                value = x; break;
            case 'y':
                value = y; break;
            case 'z':
                value = z; break;
        }
        result.Append(value + "\n");
    }
    public static void executeStop(line current)
    {
        reachedStop = true;
        return;
    }
    public static void Main()
    {
        string input = Console.ReadLine();
        string check = String.Empty;
        do
        {
            check = processInputLine(input.ToLower());
            input = Console.ReadLine();
        }
        while (check!="run");
        
        loopLines(startIndex);  //execute program
        Console.WriteLine(result);
    }
}
