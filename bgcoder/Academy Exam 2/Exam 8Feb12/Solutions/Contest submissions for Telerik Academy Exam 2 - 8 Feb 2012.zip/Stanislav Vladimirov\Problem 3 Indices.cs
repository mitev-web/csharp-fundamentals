using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03
{
    class Indices
    {
        static int max;
        static int[,] arr;
        static StringBuilder sb = new StringBuilder();
        static bool loop = false;
        static int loopStart = 0;

        static void Main(string[] args)
        {
            ReadInput();
            //while(i < max && !loop)
            //{
            //    if (arr[1, i] != 0)
            //    {
            //        loop = true;
            //        loopStart = i;
            //        break;
            //    }
            //    int number = arr[0,i];
            //    arr[1, i] = 0;
            //    sb.Append(i);
            //    sb.Append(' ');
            //    i = number;
            //}
            Racursion(0);

            string result = sb.ToString();
            sb.Clear();
            sb.Append(result.Trim());

            //sb.Remove(sb.Length - 1, 1);

            if (loop)
            {
                string old = " " + loopStart.ToString() + " ";
                string newStr = "(" + loopStart + " ";
                sb.Replace(old, newStr);
                if (sb[sb.Length - 1] == ' ')
                {
                    sb.Remove(sb.Length - 1, 1);
                }
                sb.Append(')');
            }
            Console.WriteLine(sb.ToString());
        }

        static void Racursion(int i)
        {
            if (i >= max || i < 0)
            {
                return;
            }
            else if (arr[1, i] != 0)
            {
                loop = true;
                loopStart = i;
                return;
            }
            else
            {
                int number = arr[0, i];
                sb.Append(i);
                sb.Append(' ');
                arr[1, i] = 1;
                Racursion(number);
            }
        }

        static void ReadInput()
        {
            max = int.Parse(Console.ReadLine());
            string array = Console.ReadLine();
            array = array.Trim();
            string[] arrayNumbers = array.Split(' ');
            arr = new int[2, max];
            for (int i = 0; i < max; i++)
            {
                arr[0, i] = int.Parse(arrayNumbers[i]);
            }
        }
    }
}