using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indicec
{
    class Program
    {

        static void findSequence(int[] array)
        {
            bool[] isChecked = new bool[array.Length];
            List<int> indexes = new List<int>();
            int length = array.Length;
            int index = 0;
            bool hasCycle = false;
            int indexOfTheCycle = -1;
            do
            {
                if (!isInRange(length, index))
                {
                    break;
                }

                if (isChecked[index] == true)
                {
                    hasCycle = true;
                    indexOfTheCycle = index;
                    break;
                }

                indexes.Add(index);
                isChecked[index] = true;
                index = array[index];
            } while (true);


            if (hasCycle)
            {
                printSequenceWithCycle(indexes, indexOfTheCycle);

            }
            else
            {
                printSequence(indexes);
            }

        }

        static void printSequenceWithCycle(List<int> seq, int startIndex)
        {
            int[] array = seq.ToArray();
            int index = 0;
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == startIndex)
                {
                    index = i;
                    break;
                }
                str.Append(array[i] + " ");
            }

            string sequence = str.ToString().Trim();

            str.Clear();

            str.Append("(");

            for (int i = index; i < array.Length; i++)
            {
                str.Append(array[i] + " ");
            }
            string cycle = str.ToString().Trim();
            Console.WriteLine(sequence+cycle+")");


        
        }

        static void printSequence(List<int> seq)
        {
            StringBuilder sequence = new StringBuilder();
            foreach (var index in seq)
            {
                sequence.Append(index + " ");
            }

            Console.WriteLine(sequence.ToString().Trim());
        
        }




        static bool isInRange(int length, int index)
        {
            if (index < 0 || index >= length)
            {
                return false;
            }

            return true;
        }

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            string[] arr = Console.ReadLine().Split(new char[] { ' ', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            int[] ARR = new int[n];

            for (int i = 0; i < n; i++)
            {
                ARR[i] = int.Parse(arr[i]);
            }
            findSequence(ARR);
        }
    }
}
