using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Indeces_IntermediateExam_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 6;
            int[] numbers = { 0, 2, 3, 5, 7, 1 };
            bool[] visited = new bool[numbers.Length];

            int index = 0;
            Queue<int> queue = new Queue<int>();
            bool hasLoop = false;
            int startLoop = 0;
            while (IndexIsInRange(index, numbers.Length))
            {
                if (visited[index])
                {
                    hasLoop = true;
                    startLoop = index;
                    break;
                }
                visited[index] = true;
                queue.Enqueue(index);
                index = numbers[index];
            }

            StringBuilder builder = new StringBuilder();
            if (queue.Count == 1)
            {
                Console.WriteLine("(0)");
                return;
            }
            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                if (hasLoop && current == startLoop)
                {
                    builder.Remove(builder.Length - 1, 1);
                    builder.Append("(");
                }
                builder.Append(current);
                builder.Append(" ");
            }
            var result = builder.ToString().Trim();
            if (hasLoop)
            {
                result += ")";
            }
            Console.WriteLine(result);

        }

        private static bool IndexIsInRange(int index, int length)
        {
            return index >= 0 && index < length;
        }
    }
}
