using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.Crossword
{
    class CrossWord
    {
        static int n;
        static string[] orderedWords;
        static bool isFound = false;

        static List<string> crossword;

        static void Main(string[] args)
        {
            n = int.Parse(Console.ReadLine());
            string[] words = new string[2 * n];
            for (int i = 0; i < 2 * n; i++)
            {
                words[i] = Console.ReadLine();
            }
            //n = 4;
            //string[] words = new string[] 
            //{ "FIRE","ACID","CENG","EDGE","FACE","ICED","RING","CERN" };
            orderedWords = words.OrderBy(x => x).ToArray();
            crossword = new List<string>();

            PlaceWords(0);

            if (isFound)
            {
                foreach (var item in crossword)
                {
                    Console.WriteLine(item);
                }
            }
            else
            {
                Console.WriteLine("NO SOLUTION!");
            }

            
        }

        private static void PlaceWords(int row)
        {
            if (row==n)
            {
                isFound = CheckCrossword(row-1);
                return;
            }
            for (int i = 0; i < orderedWords.Length; i++)
            {
                crossword.Add(orderedWords[i]);
                if (row>0)
                {
                    bool isValid = CheckCrossword(row);
                    if (!isValid)
                    {
                        crossword.RemoveAt(row);
                        continue;
                    }
                }
                PlaceWords(row + 1);
                if (isFound)
                {
                    return;
                }
                crossword.RemoveAt(row);
            }
        }

        private static bool CheckCrossword(int row)
        {            
            for (int i = 0; i < n; i++)
            {
                StringBuilder word = new StringBuilder();
                for (int j = 0; j <= row; j++)
                {
                    word.Append(crossword[j][i]);
                }
                bool isCorrect = false;
                foreach (var item in orderedWords)
                {
                    if (item.Contains(word.ToString()))
                    {
                        isCorrect = true; break;
                    }
                }
                if (!isCorrect)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
