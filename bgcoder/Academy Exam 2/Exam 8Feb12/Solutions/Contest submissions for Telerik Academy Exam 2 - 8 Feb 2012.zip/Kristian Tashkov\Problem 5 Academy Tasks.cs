using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Academy_Tasks
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = (Console.ReadLine()).Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            int variety=int.Parse(Console.ReadLine());
            int[] please = new int[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                please[i] = int.Parse(input[i]);
            }
            int min = 100,jumps=-1;
            for (int i = 0; i < please.Length; i++)
            {
                for (int j = i+1; j < please.Length; j++)
                {
                    jumps = 1 + (i+1) / 2+(j-i+1)/2;
                    //Console.WriteLine(i+":"+j+" j:"+jumps+" p:"+Math.Abs(please[j] - please[i]));
                    //Console.ReadKey();
                    if (jumps > min) break;
                    if ((Math.Abs(please[j] - please[i]) >= variety) && (jumps<min))
                    {
                        min = jumps;
                    }
                }
            }
            if (min == 100) Console.WriteLine(please.Length);
            else Console.WriteLine(min);
        }
    }
}
