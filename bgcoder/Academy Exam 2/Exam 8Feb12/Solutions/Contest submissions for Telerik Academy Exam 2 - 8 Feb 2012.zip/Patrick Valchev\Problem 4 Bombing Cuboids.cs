using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace _4.Problem
{
    public class Bomb
    {
        public short h;
        public short w;
        public short d;
        public short p;
        public Bomb(short w, short h, short d, short p)
        {
            this.h = h;
            this.w = w;
            this.d = d;
            this.p = p;
        }
    }
    class Program
    {
        static int countA = 0;
        static int countB = 0;
        static int countG = 0;
        static int countR = 0;
        static int countY = 0;
        static int count = 0;
        static short bombN;
        static short width, height, depth;
        static char[, ,] cuboid;
        static short[, ,] has;
        static Bomb[] bombs;
        //static StreamReader reader = new StreamReader(@"..\..\..\in.txt");
        static void Main()
        {
            // Read the cuboid size
            
            StringBuilder output = new StringBuilder();
            ReadCuboid();
            ReadBombs();
            for (int i = 0; i < bombN; i++)
            {
                Bomb(bombs[i].w, bombs[i].h, bombs[i].d, bombs[i].p);
                FallDown();
                
            }
                Console.WriteLine(count);
            if (countA>0)
            {
                Console.WriteLine("A " + countA);
            }
            if (countB > 0)
            {
                Console.WriteLine("B " + countB);
            }
            if (countG > 0)
            {
                Console.WriteLine("G " + countG);
            }
            if (countR > 0)
            {
                Console.WriteLine("R " + countR);
            }
            if (countY > 0)
            {
                Console.WriteLine("Y " + countY);
            }
        }
        private static void FallDown()
        {
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < depth; j++)
                {
                    for (int k = 0; k < width; k++)
                    {
                        if (has[k,i,j]==1)
                        {
                            for (int p = i+1; p <cuboid.GetLength(1) ; p++)
                            {
                                if (has[k,p,j]==0)
                                {
                                    has[k, p, j] = 1;
                                    has[k, i, j] = 0;
                                    cuboid[k, i, j] = cuboid[k, p, j];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        private static void Bomb(int w, int h, int d,int p)
        {
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < depth; j++)
                {
                    for (int k = 0; k < width; k++)
                    {
                        if (Math.Sqrt((k-w)*(k-w) +(j-d)*(j-d) + (i-h)*(i-h))<=p && has[k,i,j]==0)
                        {
                            has[k, i, j] = 1;
                            count++;
                            if (cuboid[k,i,j]=='A')
                            {
                                countA++;
                            }
                            else if (cuboid[k, i, j] == 'B')
                            {
                                countB++;
                            }
                            else if (cuboid[k, i, j] == 'G')
                            {
                                countG++;
                            }
                            else if (cuboid[k, i, j] == 'R')
                            {
                                countR++;
                            }
                            else if (cuboid[k, i, j] == 'Y')
                            {
                                countY++;
                            }
                        }
                    }
                }
            }
        }
        private static void ReadBombs()
        {
            bombN = short.Parse(Console.ReadLine());
            bombs = new Bomb[bombN];
            for (int i = 0; i < bombN; i++)
            {
                string k = Console.ReadLine();
                string[] kk = k.Split(' ');
                bombs[i] = new Bomb(short.Parse(kk[0]), short.Parse(kk[1]), short.Parse(kk[2]), short.Parse(kk[3]));
            }
        }
        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = short.Parse(sizes[0]);
            height = short.Parse(sizes[1]);
            depth = short.Parse(sizes[2]);
            cuboid = new char[width, height, depth];
            has = new short[width, height, depth];

            // Read the cuboid data
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] letters = line.Split();
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        cuboid[w, h, d] = letters[d][w];
                    }
                }
            }
        }

        

        private static bool IsInsideTheCuboid(int w, int h, int d)
        {
            bool inside =
                w >= 0 && w < width &&
                h >= 0 && h < height &&
                d >= 0 && d < depth;
            return inside;
        }
        
    }
}
