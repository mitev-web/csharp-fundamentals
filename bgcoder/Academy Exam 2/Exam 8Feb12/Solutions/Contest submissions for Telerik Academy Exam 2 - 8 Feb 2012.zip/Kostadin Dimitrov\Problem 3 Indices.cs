using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task03.Indices
{
    class Indices
    {
        static int[] arr;
        static int count = 0;
        static int number = 0;
        static int[] array;

        static void NestedLoops(int num)
        {
            count++;
                array = new int[count];
                try
                {
                    num = arr[num];
                }
                catch (IndexOutOfRangeException)
                {
                    return;
                }
            NestedLoops(num);
            FillArray(num);
        }

        static void FillArray(int num)
        {
            count--;
            array[count] = num;
        }
        static void Main(string[] args)
        {
            number = int.Parse(Console.ReadLine());
            arr = new int[number];

            string numbers = Console.ReadLine();
            string[] numberString = numbers.Split(); 

            for (int i = 0; i < numberString.Length; i++)
            {
                arr[i] = int.Parse(numberString[i]);
            }
            NestedLoops(0);
            int k = 0;
            for (k = 0; k < array.Length - 2; k++)
            {
                Console.Write("{0} ", array[k]);
            }
            Console.Write(array[k]);
            
        }
    }
}
