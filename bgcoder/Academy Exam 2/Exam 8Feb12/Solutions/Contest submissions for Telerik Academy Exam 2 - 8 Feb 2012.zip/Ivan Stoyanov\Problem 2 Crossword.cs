using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheExam
{
    class Program
    {
        static bool saveCall = false;
        static void Save(StringBuilder[] a, int end)
        {
            if (!saveCall)
            {
                for (int i = 0; i < end; i++)
                {
                    LASTRESULT[i] = new StringBuilder();
                    LASTRESULT[i].Append(a[i]);
                }
                saveCall = true;
                return;
            }
            else
            {
                //check if lowwer
                for (int i = 0; i < end; i++)
                {
                    if (String.Compare(LASTRESULT[i].ToString(), a[i].ToString()) > 0) break;
                    else if (LASTRESULT[i].ToString() == a[i].ToString()) continue;
                    else return;
                }
                //prisvoqva
                for (int i = 0; i < end; i++)
                {
                    LASTRESULT[i].Clear();
                    LASTRESULT[i].Append(a[i]);
                }
                return;
            }
        }

        static bool CheckColInRow(int[] nums, int index, int stop, int end, StringBuilder[] sb, StringBuilder[] tmpSB)
        {
            bool toCont = true;
            for (int j = 0; j < end; j++)
            {
                if (toCont)
                {
                    StringBuilder tmp = new StringBuilder();
                    for (int k = 0; k < end; k++)
                    {
                        tmp.Append(tmpSB[k][j]);
                    }
                    for (int i = 0; i < stop; i++)
                    {
                        if (tmp.ToString() == sb[i].ToString())
                        {
                            toCont = true;
                            break;
                        }
                        toCont = false;
                    }
                }
                else return false;
            }
            return true;
        }

        static void RowRecurs(int[] nums, int index, int stop, int end, StringBuilder[] sb)
        {
            if (end == index)
            {
                StringBuilder[] tmpSB = new StringBuilder[sb.Length];
                for (int i = 0; i < end; i++)
                {
                    tmpSB[i] = new StringBuilder();
                    tmpSB[i].Append(sb[nums[i] - 1]);
                }

                if (CheckColInRow(nums, 0, stop, end, sb, tmpSB))
                {
                    Save(tmpSB, end);
                }
                return;
            }
            else
                for (int i = 1; i <= stop; i++)
                {
                    nums[index] = i;
                    RowRecurs(nums, index + 1, stop, end, sb);
                }
            return;
        }

        static StringBuilder[] LASTRESULT = new StringBuilder[7];

        static void Main(string[] args)
        {
            //define some stuff
            int numWords = int.Parse(Console.ReadLine());
            string[] theWords = new string[numWords * 2];
            StringBuilder[] sb = new StringBuilder[numWords * 2];

            //input
            for (int i = 0; i < theWords.Length; i++)
            {
                string line = Console.ReadLine();
                sb[i] = new StringBuilder();
                sb[i].Append(line);
            }

            //call recurs
            int[] nums = new int[numWords * 2];
            //DateTime start = new DateTime();
            //DateTime end = new DateTime();
            //start = DateTime.Now;
            RowRecurs(nums, 0, numWords * 2, numWords, sb);
            //end = DateTime.Now;
            //Console.WriteLine(end-start);

            Print(LASTRESULT, numWords);
            //print
            //Print(sb);
        }

        private static void Print(StringBuilder[] sb, int end)
        {
            if (saveCall == false) Console.WriteLine("NO SOLUTION!");
            else
            {
                for (int i = 0; i < end; i++)
                {
                    Console.WriteLine(sb[i].ToString());
                }
            }
        }
    }
}