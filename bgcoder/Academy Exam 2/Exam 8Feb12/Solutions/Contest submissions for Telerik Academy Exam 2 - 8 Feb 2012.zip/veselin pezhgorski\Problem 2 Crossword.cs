using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Crossword
{
    class Crossword
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] input = new string[n * 2];
            for (int i = 0; i < n * 2; i++)
            {
                input[i] = Console.ReadLine();
            }
            int offset = 0;
            StringBuilder sb = new StringBuilder();
            char[][] charInput = new char[n * 2][];
            for (int i = 0; i < n * 2; i++)
            {
                charInput[i] = input[i].ToArray();
            }
            //for (int i = 0; i < n*2; i++)
            //{
            //    Console.Write("Element({0}): ", i);
            //    for (int j = 0; j < charInput[i].Length; j++)
            //    {
            //        Console.Write("{0} {1}", charInput[i][j], j == (charInput[i].Length - 1) ? "" : " ");
            //    }
            //    Console.WriteLine();
            //}
            string[,] mat = new string[n * 2, n];
            for (int i = 0; i < n * 2; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    mat[i, j] = charInput[i][j].ToString();
                }
            }
            //for (int i = 0; i < n * 2; i++)
            //{
            //    for (int j = 0; j <n ; j++)
            //    {
            //        Console.Write("{0} ",mat[i, j]);
            //    }
            //    Console.WriteLine();
            //}
            string[] compare = new string[100];
            int count = 0;
            StringBuilder sb1 = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                for (offset = 0; offset < n + 1; offset++)
                {
                    for (int j = 0 + offset; j < n + offset; j++)
                    {
                        sb1.Append(mat[j, i]);
                    }
                    compare[count] = sb1.ToString();
                    count++;
                    sb1.Clear();
                }
            }
            //for (int i = 0; i < count; i++)
            //{
            //    Console.WriteLine(compare[i]);
            //}
            //Console.WriteLine();
            //int count2 = 0;
            //string[] com = new string[100];
            //for (int i = 0; i < count; i++)
            //{
            //    for (int j = i+1; j < count; j++)
            //    {
            //        if (compare[i] == compare[j])
            //        {
            //            compare[i] = com[i];
            //            count2++;
            //        }
            //    }
            //}
            //for (int i = 0; i < count2; i++)
            //{
            //    Console.WriteLine(com[i]);
            //}
            string[] result = RemoveDuplicates(compare);
            //for (int i = 0; i < result.Length; i++)
            //{
            //    Console.WriteLine(result[i]);
            //}
            //Console.WriteLine();
            int rows = 0;
            //string[] fuck = new string[100];
            if (n == 1)
            {
                Console.WriteLine(input[0]);
            }
            else
            {
                int flag = 0;
                for (int i = 0; i < result.Length; i++)
                {
                    for (int j = 0; j < n * 2; j++)
                    {
                        if (result[i] == input[j])
                        {
                            rows++;
                            if (rows<=n)
                            {
                                Console.WriteLine(result[i]);
                                flag = 1;
                            }
                        }
                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine("NO SOLUTION!");
                }
            }
            //for (int i = 0; i < rows; i++)
            //{
            //    Console.WriteLine(fuck[i]);
            //}
        }
        public static string[] RemoveDuplicates(string[] s)
        {
            HashSet<string> set = new HashSet<string>(s);
            string[] result = new string[set.Count];
            set.CopyTo(result);
            return result;
        }
 
    }
}