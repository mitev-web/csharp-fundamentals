using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zadacha1
{
    class Zadacha1
    {
        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());
            int[] arrB = new int[n];
            string[] tokens = Console.ReadLine().Split();
            for (int i = 0; i < n; i++)
            {
                arrB[i] = int.Parse(tokens[i]);
            }
            //int[] arrB = {1, 2, 3, 5, 7, 8};
            //int[] arrB = { 1, 2, 3, 5, 7, 1 };
                int [] arr = new int [arrB.Length];
                int count = 0;
                 for (int i = 0; i < arr.Length; i++)
                 {
                         count = i;
                         arr[i] = FindNext(0, arrB, count);     
                 }
                 if (arr[arr.Length - 1] == 2000000001)
                 {
                     Console.Write("{0} ", 0);
                     for (int i = 0; i < arr.Length - (arr.Length - count + 2); i++)
                     {
                         Console.Write("{0} ", arr[i]);
                     }
                     Console.Write("{0}", arr[arr.Length - (arr.Length - count + 2)]);
                 }
                 else if (arr[arr.Length - 1] == 2000000002)
                 {
                     Console.Write("{0}(", 0);

                     for (int i = 0; i < arr.Length - (arr.Length - count+2); i++)
                     {
                         Console.Write("{0} ", arr[i]);
                     }
                     Console.Write("{0})", arr[arr.Length - (arr.Length - count+2)]);
                 }  
        }
        public static int FindNext(int memArr, int[] arr, int counter)
        {   
            if (counter == 0)
            {
                return arr[counter];
            }
            if (arr[counter] > arr.Length - 1)
            {
                return 2000000001;
            }
            if (arr[counter] == arr[0])
            {
                return 2000000002;
            }
            if (arr[counter] <= arr.Length - 1)
            {
                return arr[arr[counter - 1]];
            }
            return 1;
        } 
    }
}
