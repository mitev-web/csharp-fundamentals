using System;
using System.Linq;
using System.Text;
namespace SolvingProblems
{
    class SolvingProblemsTask
    {
        static StringBuilder builder;
        static int satisfaction;
        static int minimal = int.MaxValue;
        static int maximal = int.MinValue;
        static void Main(string[] args)
        {
            Solve();
        }
        static bool CheckMinAndMax(int current)
        {
            if (current < minimal)
            {
                minimal = current;
            }
            if (current > maximal)
            {
                maximal = current;
            }
            if (maximal != int.MaxValue && minimal != int.MaxValue && maximal - minimal >= satisfaction)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Solve()
        {
            builder = new StringBuilder();
            string line1 = Console.ReadLine();
            int currentNumber;
            string line2 = Console.ReadLine();
            satisfaction = int.Parse(line2);
            int count = 0;
            for (int i = 0; i < line1.Length; i++)
            {
                char character = line1[i];
                if (character == ',')
                {
                    currentNumber = int.Parse(builder.ToString());
                    count++;
                    builder = new StringBuilder();
                    i++;

                    if (CheckMinAndMax(currentNumber))
                    {
                        Console.WriteLine((count) / 2 + 1);
                        return;
                    }
                }
                else
                {
                    builder.Append(character);
                }
            }
            currentNumber = int.Parse(builder.ToString());
            count++;
            if (CheckMinAndMax(currentNumber))
            {
                Console.WriteLine((count) / 2 + 1);
                return;
            }
            else
            {
                Console.WriteLine(count);
                return;
            }
        }
    }
}