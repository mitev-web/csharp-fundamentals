using System;
using System.Text;
using System.Collections.Generic;

class BasicBasic
{
    static int n = 0;
    static List<string> words = new List<string>();
    static bool checker = false;
    static string final = "NO SOLUTION!";

    static void Gen01(int index, string[] vector, int start)
    {
        if (index == -1)
        {
            checker = Check(vector);
        }
        else
        {
            for (int i = 0; i <= words.Count - 1; i++)
            {
                vector[index] = words[i];
                Gen01(index - 1, vector, i + 1);
            }
        }
    }

    static bool Check(string[] vector)
    {
        if (CheckCols(vector))
        {
            string current = string.Join("\n", vector);
            if (string.Compare(final, current) == 1)
            {
                final = current;
            }
            return true;
        }
        return false;
    }

    static bool CheckCols(string[] vector)
    {
        int count = 0;
        for (int col = 0; col < n; col++)
        {
            if (count < col)
            {
                break;
            }
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < n; j++)
            {
                sb.Append(vector[j][col]);
            }
            string result = sb.ToString();

            for (int i = 0; i < words.Count; i++)
            {
                if (result == words[i])
                {
                    count++;
                }
            }
        }
        if (count == n)
        {
            return true;
        }
        return false;
    }

    static void Main()
    {
        n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n * 2; i++)
        {
            words.Add(Console.ReadLine());
        }

        string[] vector = new string[n];
        Gen01(n - 1, vector, 0);
        Console.WriteLine(final);
    }
}
