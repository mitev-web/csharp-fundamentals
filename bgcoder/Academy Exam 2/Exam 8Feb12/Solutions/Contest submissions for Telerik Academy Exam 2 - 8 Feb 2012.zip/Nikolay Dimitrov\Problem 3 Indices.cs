using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.indices
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int temp = -1;
            int cw = 0;
            string nums = Console.ReadLine();
            string[] numbers = nums.Split(' ');
            int[] ARR = new int[n];
            for (int j=0; j < ARR.Length; j++)
            {
                ARR[j] = int.Parse(numbers[j]);
                if (ARR[j] < 0)
                {
                    ARR[j] *= -1;
                }
            }
            bool isBreak = false;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++)
            {

                if (ARR[i] <= n)
                {
                    if ((temp >= ARR[i]) || isBreak)
                    {
                        string str = sb.ToString();
                        str = str.Substring(0, sb.Length - 1);
                        Console.WriteLine("0({0})", str);
                        cw = 1;
                        break;
                    }
                    else
                    {
                        sb.Append((ARR[i].ToString()) + " ");
                        temp = ARR[i];
                        i = ARR[i] - 1;
                    }
                }
                else
                    isBreak = true;
            }
            if (cw != 1)
            {
                string str1 = sb.ToString();
                str1 = str1.Substring(0, sb.Length - 1);
                Console.WriteLine("0 {0}", str1);
            }
        }
    }
}
