using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tubes
{
    class Tubes
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-1");
        }
    }
}
