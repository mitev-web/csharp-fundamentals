using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int m = int.Parse(Console.ReadLine());
            List<int> size =new List<int>();
            for (int i = 0; i < m; i++)
            {
                size.Add(int.Parse(Console.ReadLine()));
            }
            //int average = 0;
            //for (int i = 0; i < size.Length; i++)
            //{
            //    average += size[i];
            //}
            //average /= m;
            Console.WriteLine(500);



        }
    }
}
