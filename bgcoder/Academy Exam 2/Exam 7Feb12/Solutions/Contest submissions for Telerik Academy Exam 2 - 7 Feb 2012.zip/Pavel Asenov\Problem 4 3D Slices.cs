using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            int width = int.Parse(sizes[0]);
            int height = int.Parse(sizes[1]);
            int depth = int.Parse(sizes[2]);

            int[,,]cuboid = new int[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        int cubeValue = int.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
            int result = 0;
            int sum1=0;
            int sum2 = 0;
            int p = 1;
            do
            {
                sum1=0;
                sum2 = 0;
                for (int i = 0; i<p ; i++)
                {
                    for (int j = 0; j < height; j++)
                    {
                        for (int k = 0; k < depth; k++)
                        {
                            sum1 = sum1 + cuboid[i, j, k];
                        }
                    }
                }
                for (int i = p; i < width; i++)
                {
                    for (int j = 0; j < height; j++)
                    {
                        for (int k = 0; k < depth; k++)
                        {
                            sum2 = sum2 + cuboid[i, j, k];
                        }
                    }
                }
                if (sum1==sum2)
                {
                    result++;
                }
                p++;
            }          
            while (p <= width);
            p = 1;
            do
            {
                sum1 = 0;
                sum2 = 0;
                for (int i = 0; i < width; i++)
                {
                    for (int j = 0; j < p; j++)
                    {
                        for (int k = 0; k < depth; k++)
                        {
                            sum1 = sum1 + cuboid[i, j, k];
                        }
                    }
                }
                for (int i = 0; i < width; i++)
                {
                    for (int j = p; j < height; j++)
                    {
                        for (int k = 0; k < depth; k++)
                        {
                            sum2 = sum2 + cuboid[i, j, k];
                        }
                    }
                }
                if (sum1 == sum2)
                {
                    result++;
                }

                p++;
            }
            while (p <= height );

            p = 1;
            do
            {
                sum1 = 0;
                sum2 = 0;
                for (int i = 0; i < width; i++)
                {
                    for (int j = 0; j < height; j++)
                    {
                        for (int k = 0; k < p; k++)
                        {
                            sum1 = sum1 + cuboid[i, j, k];
                        }
                    }
                }
                for (int i = 0; i < width; i++)
                {
                    for (int j = 0; j < height; j++)
                    {
                        for (int k = p; k < depth; k++)
                        {
                            sum2 = sum2 + cuboid[i, j, k];
                        }
                    }
                }
                if (sum1 == sum2)
                {
                    result++;
                }

                p++;
            }
            while (p <= depth);

            Console.WriteLine(result);
        }
    }
}