using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1_Basic_Language
{
    class Program
    {
        public static void Main()
        {
            string line;
            string[] splitedLine;
            string[] stringSeparators = new string[] {"EXIT;"};
            string[] stringSeparators1 = new string[] { "FOR" };
            StringBuilder Output = new StringBuilder();
            StringBuilder Output1 = new StringBuilder();
            string Data;
            string [] SplitedData;

            do
            {
                line = Console.ReadLine();
                splitedLine = line.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i <= splitedLine.Length - 1; i++)
                {
                    Output.Append(splitedLine[i]);
                }

            } while (line.IndexOf("EXIT;") < 0);

            Data = Output.ToString();
            SplitedData = Data.Split(stringSeparators1, StringSplitOptions.RemoveEmptyEntries);

            // Тук проверявам сплитнатите по "FOR" дали започват с "P" >> Директно ще се принтират или
            // започват с "(" ще трябва да се прочете колко пъти ще се повтори принтирането!
            for (int i = 0; i <= SplitedData.Length - 1; i++)
            {
                if (SplitedData[i].IndexOf("PRINT") == 0)
                {
                    SplitedData[i].Trim('P', 'R', 'I', 'N', 'T', '(', ')', ';');
                }
                else
                {
                    //Тук трябва да се екстрактнат параметрите на FOR и да се отпечата съответен брой пъти съобщението!
                    SplitedData[i].Trim('P', 'R', 'I', 'N', 'T', '(', ')', ';', ',', '0'); 
                }

                
            }
            // Възниква проблем с работата на String.Trim ??

            // тук отново се сглобява стринга за отпечатване...
            for (int i = 0; i <= SplitedData.Length - 1; i++)
            {
                Output1.Append(SplitedData[i]);
            }

            Console.WriteLine(Output1);

        }

    }
}
