using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex._02
{
    class Program
    {
        static string code;
        static string mes;
        static Dictionary<long, Char> dic = new Dictionary<long, char>();
       // static int[] codeArr;
        static List<List<long>> finalList = new List<List<long>>();
        static void Main(string[] args)
        {
            Read();

            for (int i = 0; i < code.Length; i++)
            {
                List<long> ll = new List<long>() { KeyGenerator(0, i) };
                testc(i + 1, ll);
            }
            Console.WriteLine(finalList.Count);
            foreach (List<long> item in finalList)
            {
                StringBuilder sb = new StringBuilder();
                foreach (long intt in item)
                {
                    sb.Append(dic[intt]);
                }
                Console.WriteLine(sb.ToString());
            }
 
        }

        private static void testc(int p, List<long> list)
        {

 
                for (int ii = 0; ii < code.Length -p; ii++)
                {
                    List<long> newList = new List<long>(list) { KeyGenerator(p, p + ii) };
                    testc(p + ii+1, newList);
                }
                if (p == code.Length)
                {
                    bool isOk = true;
                    foreach (var item in list)
                    {
                        if (!dic.ContainsKey(item)) 
                        {
                            isOk = false;
                        }
                    }
                    if (isOk) 
                    {
                        finalList.Add(list);
                    }
                    
                }
        }

    
        static long KeyGenerator(int from, int to) 
        {
            return long.Parse(code.Substring(from,to-from+1));
        }

        private static void Read()
        {
            code = Console.ReadLine();
            mes = Console.ReadLine();
            //mes = "1B11C11D2";
            //code = "1122";
            //codeArr = new int[code.Length];
            //for (int i = 0; i < code.Length; i++)
            //{
            //    codeArr[i] = int.Parse(code[i].ToString());
            //}

            StringBuilder numberStr = new StringBuilder();
            StringBuilder decoded = new StringBuilder();
            char chNew =',';
            int start = 0;
            for (int i = 0; i < mes.Length; i++)
            {
                if (Char.IsLetter(mes[i])) 
                {
                    chNew = mes[0];
                    start = i+1;
                    break;
                }
            }
            
            char temp;
            
            for (int i = start; i < mes.Length; i++)
            {
                if (Char.IsLetter(mes[i]))
                {
                    long key;
                    temp = mes[i];              
                    

                    //try{

                         key = long.Parse(numberStr.ToString());
                    //}
                    //catch (Exception)
                    //{
                    //    throw new ExecutionEngineException();
                    //}
                        dic.Add(key, chNew);
                        chNew = temp;
                        numberStr.Clear();
    

                }

                else
                {
                    numberStr.Append(mes[i]);
                }

            }
            dic.Add(long.Parse(numberStr.ToString()), chNew);

        }
    }
}
