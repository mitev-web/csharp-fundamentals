using System;
using System.Text;
using System.Collections.Generic;

namespace MessagesinABottle
{
    class Program
    {
        public static int globalSum = 0;
        public static string[,] lettersWithCodes;
        public static string firstMassage;
        public static string secondMassage;
        public static List<string> allCombinations = new List<string>();
        static void Main(string[] args)
        {
            // read from console
            firstMassage = Console.ReadLine();
                //"778";
            secondMassage = Console.ReadLine();
                //"Z123A7787X666Y234";
                
            // lenght = 26
            
            char[] numbers = new char[] { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
            string[] splitedLetters = secondMassage.Split(numbers);
           
            StringBuilder builder = new StringBuilder();
            foreach (string value in splitedLetters)
            {
                builder.Append(value);
            }
            string letters = builder.ToString();
            lettersWithCodes = new string[letters.Length, 2];
            int indexOfNextLetter = 0;
            int indexOfCurrentLetter = 0;
            for (int currentLetter = 0; currentLetter < lettersWithCodes.GetLength(0); currentLetter++)
            {
                lettersWithCodes[currentLetter, 0] = letters[currentLetter].ToString();
                if (currentLetter + 1 >= letters.Length)
	            {
                    indexOfNextLetter = secondMassage.Length;
	            }
                else
	            {
                    indexOfNextLetter = secondMassage.IndexOf(letters[currentLetter + 1]);
	            }
                indexOfCurrentLetter = secondMassage.IndexOf(letters[currentLetter])+1;
                lettersWithCodes[currentLetter, 1] = secondMassage.Substring(indexOfCurrentLetter, indexOfNextLetter - indexOfCurrentLetter);
            }

            DecipherCode(0);
            Console.WriteLine(allCombinations.Count);
            foreach (string item in allCombinations)
            {
                Console.WriteLine(item);
            }
            
        }

        static void DecipherCode(short currentPosition,  string currentCombination = "")
        {
           
            // bottom of recursion
            if (currentPosition >= firstMassage.Length)
            {
                allCombinations.Add(currentCombination);
                return;
            }
            bool isLetterFound = false;
            for (int currentLetter = 0; currentLetter  < lettersWithCodes.GetLength(0); currentLetter ++)
			{
                if (lettersWithCodes[currentLetter, 1].Length < firstMassage.Length-currentPosition+1)
                {
                    if (firstMassage.Substring(currentPosition, lettersWithCodes[currentLetter, 1].Length) == lettersWithCodes[currentLetter, 1])
                    {
                        //currentCombination.Append(lettersWithCodes[currentLetter, 0]);
                        isLetterFound = true;
                        DecipherCode((short)(currentPosition + lettersWithCodes[currentLetter, 1].Length), currentCombination + lettersWithCodes[currentLetter, 0]);
                        
                    }
                }
			}
            if (!isLetterFound && currentCombination.Length > 0)
            {
                allCombinations.Add(currentCombination);
                return;
            }
            
            
        }
    }
}
