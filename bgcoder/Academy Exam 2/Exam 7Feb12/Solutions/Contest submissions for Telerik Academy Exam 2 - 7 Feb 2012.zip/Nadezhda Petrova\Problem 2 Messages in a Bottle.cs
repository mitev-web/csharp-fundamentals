using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2_MessageInABottle
{
    class MessageInABottle
    {
        static string[] words = new string[2048];
        static int index = 0;
        static int longestCode = 0;

        static void Main(string[] args)
        {
            string code = Console.ReadLine();
            string cipher = Console.ReadLine();
            Dictionary<string, char> dic = GetMeaning(cipher, code.Length);
            int maskLimit = GenerateMaskLimit(code) / 2;
            FindMessages(code, dic, maskLimit);
            Console.WriteLine(index);
            Array.Sort(words, 0, index);
            for (int i = 0; i < index; i++)
            {
                Console.WriteLine(words[i]);
            }
        }

        private static void FindMessages(string code, Dictionary<string, char> dic, int maskLimit)
        {
            int mask = 0;
            int length = code.Length;
            StringBuilder sb = new StringBuilder();
            StringBuilder result = new StringBuilder();
            bool exist = true;
            for (mask = 0; mask <= maskLimit; mask++)
            {
                sb.Clear();
                result.Clear();
                int prevBit = BitAtPosition(mask, length - 1);
                exist = true;
                for (int j = length - 1; j >= 0; j--)
			    {
                    int curBit = BitAtPosition(mask, j);
                    if (curBit == prevBit)
                    {
                        sb.Append(code[length - j - 1]);
                    }
                    else
                    {
                        if (longestCode < sb.Length)
                        {
                            exist = false;
                            sb.Clear();
                            break;
                        }
                        else if (sb.Length > 0)
                        {
                            if (dic.ContainsKey(sb.ToString()))
                            {
                                result.Append(dic[sb.ToString()]);
                                sb.Clear();
                                sb.Append(code[length - j - 1]);
                            }
                            else
                            {
                                exist = false;
                                sb.Clear();
                                break;
                            }
                        }
                    }
                    prevBit = curBit;
                }
                if (sb.Length > 0 && exist)
                {
                    if (longestCode < sb.Length)
                    {
                        exist = false;
                    }
                    else
                    {
                        if (dic.ContainsKey(sb.ToString()))
                        {
                            result.Append(dic[sb.ToString()]);
                        }
                        else
                        {
                            exist = false;
                        }
                    }
                }
                if (exist)
                {
                    words[index] = result.ToString();
                    index++;
                    result.Clear();
                    sb.Clear();
                }
            }
        }

        private static int BitAtPosition(int number, int position)
        {
            int mask = 1 << position;
            int result = mask & number;
            if (result == 0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        private static int GenerateMaskLimit(string code)
        {
            int limit = 1;
            for (int i = 0; i < code.Length - 1; i++)
            {
                limit = (limit << 1) | 1;
            }
            return limit;
        }

        private static Dictionary<string, char> GetMeaning(string cipher, int codeLength)
        {
            Dictionary<string, char> dic = new Dictionary<string, char>();
            StringBuilder sb = new StringBuilder();
            char letter = new char();
            for (int i = 0; i < cipher.Length; i++)
            {
                char c = cipher[i];
                if (char.IsLetter(c))
                {
                    if (sb.Length > 0 && sb.Length <= codeLength)
                    {
                        if (sb.Length > longestCode)
                        {
                            longestCode = sb.Length;
                        }
                        dic.Add(sb.ToString(), letter);
                        sb.Clear();
                    }
                    else
                    {
                        sb.Clear();
                    }
                    letter = c;
                }
                if (char.IsDigit(c))
                {
                    sb.Append(c);
                }
            }
            if (sb.Length > 0 && sb.Length <= codeLength)
            {
                if (sb.Length > longestCode)
                {
                    longestCode = sb.Length;
                }
                dic.Add(sb.ToString(), letter);
            }
            return dic;
        }
    }
}
