using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] prop = input.Split(' ');
            int x = int.Parse(prop[0]);
            int y = int.Parse(prop[1]);
            int z = int.Parse(prop[2]);

            int[, ,] cuboid = new int[x, y, z];
            string[] data = new string[y];
            List<string> split = new List<string>();
            char[] splitRow = { ' ', '|' };

            for (int i = 0; i < y; i++)
            {
                data[i] = Console.ReadLine();

            }

            for (int i = 0; i < y; i++)
            {
                string[] sp = data[i].Split(splitRow, StringSplitOptions.RemoveEmptyEntries);
                int count = 0;
                for (int j = 0; j < x; j++)
                {
                    for (int p = 0; p < z; p++)
                    {
                        cuboid[j, i, p] = int.Parse(sp[count]);
                        count++;
                    }
                }
            }

            long sumOfItems = 0;
            int output = 0;
            foreach (int item in cuboid)
            {
                sumOfItems += item;
            }

            output = MatchesX(cuboid, x, y, z, sumOfItems);
            Console.WriteLine(output);
        }
        static int MatchesX(int[, ,] cuboid, int x, int y, int z, long sum)
        {
            int separator = 0;
            int matches = 0;
            long tempSum = 0;

            for (int i = 0; i < x - 1; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    for (int p = 0; p < z; p++)
                    {
                        tempSum += cuboid[i, j, p];
                    }
                }
                if (tempSum == sum - tempSum)
                {
                    matches++;
                }
            }

            tempSum = 0;

            for (int i = 0; i < y -1; i++)
            {
                for (int j = 0; j < x; j++)
                {
                    for (int p = 0; p < z; p++)
                    {
                        tempSum += cuboid[j, i, p];
                    }
                }
                if (tempSum == sum - tempSum)
                {
                    matches++;
                }
            }
            tempSum = 0;

            for (int i = 0; i < z - 1; i++)
            {
                for (int j = 0; j < y ; j++)
                {
                    for (int p = 0; p < x ; p++)
                    {
                        tempSum += cuboid[p, j, i];
                    }
                }
                if (tempSum == sum - tempSum)
                {
                    matches++;
                }
            }
            return matches;
        }
    }
}
