using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3DSlices
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int w, h, d;
            int[, ,] cube;
            int sum = 0;
            string temp = Console.ReadLine();
            string[] numbers = temp.Split(' ');
            w = int.Parse(numbers[0]);
            h = int.Parse(numbers[1]);
            d = int.Parse(numbers[2]);
            cube = new int[w, h, d];
            int dim1,dim2,dim3;
            for (int i = 0; i < h; i++)
            {
                dim2 = i;
                dim1 = 0;
                dim3 = 0;
                temp = Console.ReadLine();
                numbers = temp.Split(' ');
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (numbers[j] == "|")
                    {
                        dim3++;
                        dim1 = 0;
                    }
                    else
                        if (numbers[j] != null)
                        {
                            cube[dim1, dim2, dim3] = int.Parse(numbers[j]);
                            sum+=cube[dim1,dim2,dim3];
                            dim1++;
                        }
                }
            }

          /*  for (int i = 0; i < w; i++)
                for (int j = 0; j < h; j++)
                    for (int k = 0; k < d; k++)
                        Console.WriteLine(cube[i, j, k]);
           */

            int sum1=0;
            int sum2=0;
            int ans=0;
            // po w
            for (int i = 0; i < w - 1; i++)
            {
                for (int j = 0; j < h; j++)
                    for (int k = 0; k < d; k++)
                        sum1 += cube[i, j, k];
                sum2 = sum - sum1;

                if (sum2 == sum1)
                {
                    ans++;
                }
            }
        
        //po h
            sum1 = 0;
            for (int j = 0; j < h-1; j++)
            {
                for (int i = 0; i < w;i++ )
                    for (int k = 0; k < d; k++)
                        sum1 += cube[i, j, k];
                sum2 = sum - sum1;

                if (sum2 == sum1)
                {
                    ans++;
                }
            }

            sum1 = 0;
            //po d
            for (int k = 0; k < d - 1; k++)
            {
                for (int j = 0; j < h; j++)
                    for (int i = 0; i < w; i++)
                        sum1 += cube[i, j, k];
                sum2 = sum - sum1;

                if (sum2 == sum1)
                {
                    ans++;
                }
            }

            Console.WriteLine(ans);
        }
    }
}
