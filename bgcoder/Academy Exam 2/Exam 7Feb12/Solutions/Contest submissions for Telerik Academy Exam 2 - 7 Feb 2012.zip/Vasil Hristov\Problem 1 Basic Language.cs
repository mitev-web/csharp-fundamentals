using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.Print
{
    class Program
    {


        static void Main()
        {
          //  string text = "PRINT(Black and yellow, );" +
          //      "FOR(0,1)PRINT(black and yellow, );" +
           //     "PRINT(black and yellow...);" +
           //     "EXIT;";
            string az=Console.ReadLine();
            string text = string.Empty;
           int stop= az.IndexOf("EXIT;");
           text += az;
         //  text += "\n";
            while (stop==-1)
          {
              
              az = Console.ReadLine();
              text += az;
           //   text += "\n";
              stop = az.IndexOf("EXIT;");
          }
            az = string.Empty;
            string[] commands = { "PRINT", "FOR", "EXIT" };
            int i = 0;
            int sign = 1;
            string command = string.Empty;
            StringBuilder print = new StringBuilder();
            text.TrimStart();
            int how = 1;
            StringBuilder currentPrint = new StringBuilder();
            while (i<text.Length)
            {
                while (text[i] !='F'&&text[i] !='E'&&text[i] !='P')
                {
                    i++;
                }

                currentPrint.Clear();
                command = string.Empty;
                while (text[i] != ' ' && text[i] != '(' && text[i]!=';')
                {
                    command += text[i];
                    i++;

                }
                command.ToUpper();
                if (command == commands[1])
                {

                    int help = 0;
                    int stepen = 0;
                    while (text[i] != ')')
                    {
                      
                        if (int.TryParse(text[i].ToString(), out help))
                        {
                            int how1 = 0;
                            int p = i;
                            sign = 1;
                            if (text[i - 1] == '-') sign= -1;
                            while (int.TryParse(text[p].ToString(), out help))
                            {

                                stepen++;
                                p++;
                            }
                            stepen--;
                            while (int.TryParse(text[i].ToString(), out help))
                            {
                                how1 = how1 + (help * (int)Math.Pow(10, stepen));
                                i++;
                            }
                            how1 *= sign;
                            while (text[i] != ')' && text[i] != ',')
                            {
                                i++;
                            }
                            if (text[i] == ')') { if (text[i + 1] == ';') { how1 = 1; } how *= how1; break; }
                            if (text[i] == ',')
                            {
                                int how2 = 0;
                                while (int.TryParse(text[i].ToString(), out help) == false)
                                {

                                    i++;
                                }
                                sign = 1;
                                if (text[i - 1] == '-') { sign= -1; }
                                p = i;
                                stepen = 0;
                                while (int.TryParse(text[p].ToString(), out help))
                                {

                                    stepen++;
                                    p++;
                                }
                                stepen--;
                                while (int.TryParse(text[i].ToString(), out help))
                                {
                                    how2 += (help * (int)Math.Pow(10, stepen));
                                    i++;
                                }
                                how2 *= sign;
                                while (text[i] != ')')
                                {
                                    i++;
                                }
                                i++;
                                how1 = (how2 - how1 + 1);
                                if (text[i + 1] == ';') { how1 = 1; }
                                how *= how1;
                                how1 = 0;
                                how2 = 0;
                                sign = 1;
                                break;
                            }
                            
                        }
                        else { i++; }

                    }
                  
                }
                if (command == commands[0]) {
                    while (text[i]!='(')
                    {
                        i++;
                    }
                    i++;
                    while (text[i]!=')')
                    {


                        if (text[i] == '\\' && text[i + 1] == 'n') { currentPrint.AppendLine(); i++; }
                        else { currentPrint.Append(text[i]); }
                        i++;
                        
                    }
                    for (int j = 0; j < how; j++)
                    {
                        

                           
                    print.Append(currentPrint.ToString());
                       
                    }
                    how = 1;
                    
                }

            
           


            if (command == commands[2]) { break; }

            }
        
            string k = print.ToString();
            
           Console.WriteLine(k+"\n");
       
         //   Console.WriteLine();
        }
    }
}
