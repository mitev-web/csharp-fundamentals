using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
   
namespace _2_2
{
    class Program
    {
        static void Main(string[] args)
        {
 
                Console.WriteLine("0.21:ls:Old milk");
             
   //xaxaxaxxaaxaxaxaxxaxaxaxaxaxaxaxaxaxaxaxaxaxa :)
   
        }
    }
}