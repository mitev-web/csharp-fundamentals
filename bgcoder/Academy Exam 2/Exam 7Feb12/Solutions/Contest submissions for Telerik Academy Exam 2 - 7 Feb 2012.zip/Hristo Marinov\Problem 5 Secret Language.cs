using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SecretLanguage
{
    class SecretLanguage
    {
        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
            string temp = Console.ReadLine();
            string[] temp2 = temp.Split(' ');
            string[] words = new string[temp2.Length];
            temp2 = temp.Split(' ', ',', '"');
            int j = 0;
            for (int i = 0; i < temp2.Length;i++ )
            {
                if (temp2[i] != "")
                {
                    words[j] = temp2[i];
                    j++;
                }
            }

            int[,] leters = new int[words.Length, 26];
            for (int i = 0; i < words.Length; i++)
            {
                for (j = 0; j < words[i].Length; j++)
                {
                    leters[i,(words[i][j]-'a')]++;
                }
            }
            int ans=0;
            int[] letsen = new int[26];
            temp="";
            for(int i=0;i<sentence.Length;i++)
            {
                letsen[sentence[i] - 'a']++;
                temp += sentence[i];
                //bool flag1 = false;
                bool flag2 = true;
                int minncos=100;
                for (int k = 0; k < words.Length; k++)
                {
                    flag2 = true;
                    for (int z = 0; z < 26; z++)
                    {
                        if (letsen[z] != leters[k, z])
                        {
                            flag2 = false;
                            break;
                        }
                    }
                    if (flag2 == true)
                    {
                        int br = 0;
                        for (int z = 0; z < words[k].Length; z++)
                        {
                            if (words[k][z] != temp[z]) br++;
                        }
                        if (br < minncos) minncos = br;
                    }
                }
                if (minncos != 100)
                {
                    ans += minncos;
                    temp = "";
                    for (int ff = 0; ff < 26; ff++)
                    {
                        letsen[ff] = 0;
                    }
                }
            }
            if (temp != "") Console.WriteLine(-1);
            else
            Console.WriteLine(ans);
        }
    }
}
