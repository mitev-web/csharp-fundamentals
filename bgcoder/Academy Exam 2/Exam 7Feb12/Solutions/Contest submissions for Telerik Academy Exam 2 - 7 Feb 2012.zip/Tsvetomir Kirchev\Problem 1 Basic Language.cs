using System;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace _01_BasicLanguage
{
    class BasicLanguage
    {
        static StringBuilder fullText = new StringBuilder();

        static void Main(string[] args)
        {
            bool inPrintMode = false;
            bool inLoopMode = false;

//            string language = @"PRINT(Black and yellow, );
//                        FOR(0,1) PRINT(black and yellow, ); 
//                        PRINT(black and yellow...); 
//                        EXIT;";
            //string language = "FOR   (1 , 5 ) PRINT  (ha)  ; FOR(2)FOR(2, 3)PRINT(xi);EXIT";

            string language = Console.ReadLine();

            StringBuilder sb = new StringBuilder();
            StringBuilder forPrint = new StringBuilder();
            StringBuilder forLoop = new StringBuilder();

            //Stopwatch sw = new Stopwatch();
            //sw.Start();

            for (int i = 0; i < language.Length; i++)
            {
                //if (language[i] == ' ')
                //{
                //    continue;
                //}

                sb.Append(language[i]);

                if (sb.ToString().Trim().Equals("PRINT("))
                {
                    inPrintMode = true;
                    sb.Clear();
                    i += 1;
                }

                if (forPrint.Length != 0 && language[i] == ')' &&
                    i != language.Length && language[i + 1] == ';')
                {
                    Print(forPrint.ToString());
                    forPrint.Clear();
                }

                if (language[i] == ')' && i != language.Length
                    && language[i + 1] == ';' && inPrintMode)
                {
                    inPrintMode = false;
                    sb.Clear();
                    if (i < language.Length)
                    {
                        i += 1;
                    }
                }

                if (forLoop.Length != 0 && language[i] == ';')
                {
                    ForLoop(forLoop.ToString());
                    forLoop.Clear();
                    sb.Clear();
                    inLoopMode = false;
                }


                if (sb.ToString().Trim().Equals("FOR"))
                {
                    inLoopMode = true;
                    sb.Clear();
                }

                if (inPrintMode)
                {
                    forPrint.Append(language[i]);
                }

                if (inLoopMode)
                {
                    forLoop.Append(language[i]);
                }
            }

            Console.WriteLine(fullText.ToString());
            Console.WriteLine();

            //sw.Stop();
            //Console.WriteLine(sw.Elapsed);
        }

        static void ForLoop(string text)
        {
            int secondLoop = 0;
            if (text.IndexOf("FOR") != -1)
            {
                StringBuilder builder = new StringBuilder();
                int indexOne = text.IndexOf("FOR(") + 3;
                int indexTwo = text.IndexOf(')', indexOne + 1);

                for (int i = indexOne + 1; i < indexTwo; i++)
                {
                    if (text[i].Equals(" "))
                    {
                        continue;
                    }
                    builder.Append(text[i]);
                }

                string[] nums = builder.ToString().Split(',');

                secondLoop = Int32.Parse(nums[0]); //Int32.Parse(numbers[0]);
                if (nums.Length > 0)
                {
                    secondLoop = Int32.Parse(nums[1]) - Int32.Parse(nums[0]) + 1;
                }
            }

            int firstIndex = text.IndexOf('(');
            int secondIndex = text.IndexOf(')', firstIndex + 1);

            int printLastIndex = text.LastIndexOf(')');
            int printIndex = text.LastIndexOf('(', printLastIndex - 1);
            StringBuilder sb = new StringBuilder();

            for (int i = firstIndex + 1; i < secondIndex; i++)
            {
                if (text[i].Equals(" "))
                {
                    continue;
                }
                sb.Append(text[i]);
            }

            string[] numbers = sb.ToString().Split(',');

            int numberOfIterations = Int32.Parse(numbers[0]); //Int32.Parse(numbers[0]);
            if (numbers.Length > 1)
            {
                numberOfIterations = Int32.Parse(numbers[1]) - Int32.Parse(numbers[0]) + 1;
            }

            numberOfIterations += secondLoop;
            //Console.WriteLine(numberOfIterations);
            sb.Clear();
            //int index = printLastIndex - printIndex;
            for (int i = printIndex + 1; i < printLastIndex; i++)
            {
                sb.Append(text[i]);   
            }

            for (int i = 0; i < numberOfIterations; i++)
            {
                fullText.Append(sb);
            }
        }

        static void Print(string text)
        {
            fullText.Append(text);
            //Console.Write(fullText.ToString());
        }
    }
}
