using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _04._3DSlices
{
    class Program
    {
        static int[, ,] cube;
        static int[] sumX;
        static int[] sumY;
        static int[] sumZ;
        static int totalSum = 0;

        static void ShowCube()
        {
            Console.WriteLine("The Cube:");
            for (int x = 0; x < cube.GetLength(2); x++)
            {
                for (int y = 0; y < cube.GetLength(1); y++)
                {
                    for (int z = 0; z < cube.GetLength(0); z++)
                    {
                        Console.Write(cube[z, y, x] + "");
                    }
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            Console.WriteLine("--------");
        }
        // Z Y X
        static void MakeSums()
        {
            for (int x = 0; x < cube.GetLength(2); x++)
            {
                for (int y = 0; y < cube.GetLength(1); y++)
                {
                    for (int z = 0; z < cube.GetLength(0); z++)
                    {
                        sumX[z] += cube[z, y, x];
                        sumY[y] += cube[z, y, x];
                        sumZ[x] += cube[z, y, x];
                    }
                }
            }
        }
        static void ShowSums(string dim)
        {
            if (dim == "X")
            {
                Console.Write("sumX:  ");
                for (int i = 0; i < sumX.Length; i++)
                {
                    Console.Write(sumX[i] + " ");
                }
            }
            if (dim == "Y")
            {
                Console.Write("sumY:  ");
                for (int i = 0; i < sumY.Length; i++)
                {
                    Console.Write(sumY[i] + " ");
                }
            }
            if (dim == "Z")
            {
                Console.Write("sumZ:  ");
                for (int i = 0; i < sumZ.Length; i++)
                {
                    Console.Write(sumZ[i] + " ");
                }
            }
            Console.WriteLine();
        }

        static void MakeTotalSum()
        {
            for (int i = 0; i < sumZ.Length; i++)
            {
                totalSum += sumZ[i];
            }
        }

        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] sepertors = { " " };
            string[] temp = input.Split(sepertors, StringSplitOptions.RemoveEmptyEntries);
            int cubeX = int.Parse(temp[0]);
            int cubeY = int.Parse(temp[1]);
            int cubeZ = int.Parse(temp[2]);
            sumX = new int[cubeX];
            sumY = new int[cubeY];
            sumZ = new int[cubeZ];

            cube = new int[cubeX, cubeY, cubeZ];
            string[] separatorsLine = { "|" };
            for (int y = 0; y < cubeY; y++)
            {
                input = Console.ReadLine();
                string[] line = input.Split(separatorsLine, StringSplitOptions.RemoveEmptyEntries);
                for (int z = 0; z < cubeZ; z++)
                {
                    string[] nums = line[z].Split(sepertors, StringSplitOptions.RemoveEmptyEntries);
                    for (int x = 0; x < cubeX; x++)
                    {
                        cube[x, y, z] = int.Parse(nums[x]);
                    }
                }
            }
           // ShowCube();
            MakeSums();
           // ShowSums("X");
          //  ShowSums("Y");
          //  ShowSums("Z");
            MakeTotalSum();
           // Console.WriteLine(totalSum);
            int answer=0;
            int currentSum = 0;
            for (int i = 0; i < sumX.Length-1; i++)
            {
                currentSum += sumX[i];
                if (currentSum * 2 == totalSum)
                {
                    answer++;
                }
            }
            currentSum = 0;
            for (int i = 0; i < sumY.Length-1; i++)
            {
                currentSum += sumY[i];
                if (currentSum * 2 == totalSum)
                {
                    answer++;
                }
            }
            currentSum = 0;
            for (int i = 0; i < sumZ.Length-1; i++)
            {
                currentSum += sumZ[i];
                if (currentSum * 2 == totalSum)
                {
                    answer++;
                }
            }
            Console.WriteLine(answer);




        }
    }
}
