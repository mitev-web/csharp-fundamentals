using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicLanguage
{
    class BasicLanguage
    {
        static void CallFor(long times, string print)
        {
            for (int i = 0; i < times; i++)
            {
                CallPrint(print);
            }
        }
        static int CalculatingNumber(List<char> num)
        {
            int number = 0;
            int tens = 1;
            for (int i = num.Count - 1; i >= 0; i--)
            {
                number += (int)(num[i] - '0') * tens;
                tens *= 10;
            }
            for (int l = 0; l < num.Count; l++)
            {
                num.RemoveAt(0);
            }
            return number;
        }
         static int ExtractingFromFor(int indexFor, string BL, List<char> num )
        {
            int a = 0;
            int b = 0;
            int inFor = 0;
            int forLoops = 0;
            for (int i = indexFor; ; i++)
            {
                if (BL[i] == ')')
                {
                    if (inFor == 2)
                    {
                        b = CalculatingNumber(num);
                        forLoops = b - a + 1;
                    }
                    if (inFor == 1)
                    {
                        a = CalculatingNumber(num);
                        forLoops = a;
                    }
                    break;
                }
                if (BL[i] >= '0' && BL[i] <= '9' && inFor == 2)
                {
                    num.Add(BL[i]);
                }
                if (BL[i] == ',')
                {
                    inFor = 2;
                    a = CalculatingNumber(num);
                    for (int l = 0; l < num.Count; l++)
                    {
                        num.RemoveAt(0);
                    }
                }
                if (BL[i] >= '0' && BL[i] <= '9' && inFor == 1)
                {
                    num.Add(BL[i]);
                }
                if (BL[i] == '(' && inFor == 0)
                {
                    inFor = 1;
                }
            }
            return forLoops;
        }
        static void CallPrint(string str)
        {
            Console.Write(str);
        }
        static string ExtractFromPrint(int indexPrint, string BL)
        {
            StringBuilder sb = new StringBuilder();
            string str="";
            int inPrint = 0;
            for (int i = indexPrint; ; i++)
            {
                if (BL[i] == ')')
                {
                    break;
                }
                if (inPrint == 1 && BL[i] != ')')
                {
                    sb.Append(BL[i]);
                }
                if (BL[i] == '(' && inPrint == 0)
                {
                    inPrint = 1;
                }
            }
            inPrint = 0;
            str=sb.ToString();
            sb.Clear();
            return str;
        }
        static void Main(string[] args)
        {
            string BL = Console.ReadLine();
            int indexExit = 0;
            int forFlag = 0;
            int forLoops = 1;
            int indexPrint = 0;
            int indexFor = 0;
            int indexSeparator=0;
            string message="";
            List<char> num = new List<char>();
            int flagPrint = 0;
            int flagFor = 0;
            while (indexSeparator!=-1 || indexPrint!=-1)
            {
                
                indexSeparator = BL.IndexOf(";",indexSeparator+1);
                if (flagPrint == 1)
                {
                    indexPrint = BL.IndexOf("PRINT", indexPrint + 1);
                }
                if (flagPrint == 0)
                {
                    indexPrint = BL.IndexOf("PRINT");
                    flagPrint = 1;

                }
                if (flagFor == 1)
                {
                    indexFor = BL.IndexOf("FOR", indexFor + 1);                    
                }
                else
                {
                    indexFor = BL.IndexOf("FOR");
                    flagFor = 1;
                }
                if (indexSeparator == -1)
                {
                    break;
                }
                if (indexFor==-1 && indexPrint < indexSeparator)
                {
                    message = ExtractFromPrint(indexPrint, BL);
                    Console.Write(message);
                }
                if (indexPrint < indexFor && indexSeparator<indexFor)
                {
                    message = ExtractFromPrint(indexPrint, BL);
                    Console.Write(message);
                }
                if (indexFor < indexPrint && (indexSeparator>indexFor && indexSeparator>indexPrint) && indexFor!=-1)
                {
                    
                    while (indexFor<indexPrint)
                    {
                        if (indexFor == -1)
                        {
                            break;
                        }
                        forLoops *= ExtractingFromFor(indexFor, BL, num);
                        indexFor = BL.IndexOf("FOR", indexFor + 1);
                    }
                    message = ExtractFromPrint(indexPrint, BL);
                    CallFor(forLoops, message);
                    forLoops = 1;
                }
            }
                     
        }
    }
}
