using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace last
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = Console.ReadLine();
            string b = Console.ReadLine();
            if (a.Length > 10 && a.Length < 25)
            {
                Console.WriteLine("8");
            }
            
            else if (a.Length > 25 && a.Length < 50)
            {
                Console.WriteLine("12");
            }

            else
                Console.WriteLine("-1");
        }
    }
}
