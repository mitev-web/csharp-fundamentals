using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagesInBottle
{
    class Program
    {
        static string encoding;
        static List<char> temporary =  new List<char>();
        static List<List<char>> results = new List<List<char>>();
        static string cipher;
        static SortedDictionary<char, string> rules = new SortedDictionary<char, string>();
        static void rec(int index)
        {
            if (index >= encoding.Length)
            {
                List<char> tmp = new List<char>();
                foreach (char a in temporary)
                {
                    tmp.Add(a);
                }
                results.Add(new List<char>(tmp));
            }
            foreach (char key in rules.Keys)
            {
                string val = rules[key];
                int pos = encoding.IndexOf(val,index);
                if (pos != index) continue;
                if (pos != -1)
                {
                    temporary.Add(key);
                    rec(pos+val.Length);
                    temporary.RemoveAt(temporary.Count-1);
                }
            }
        }
        static void Main(string[] args)
        {
            encoding = Console.ReadLine();
            cipher = Console.ReadLine();
            StringBuilder temp =new StringBuilder("");
            char currentSymbol;
            char currentLetter=cipher[0];
            for (int i = 1; i < cipher.Length; i++)
            {
               currentSymbol =  cipher[i];
               if (char.IsDigit(currentSymbol) == true)
               {
                   temp.Append(currentSymbol);
               }
               else
               {
                   string result = temp.ToString();
                   rules.Add(currentLetter, result);
                   temp.Clear();
                   currentLetter = cipher[i];
               }
            }
            rules.Add(currentLetter, temp.ToString());
            rec(0);
            Console.WriteLine(results.Count);
            for (int i = 0; i < results.Count; i++)
            {
                for(int j =0; j<results[i].Count; j++)
                    Console.Write(results[i][j].ToString());
                Console.WriteLine();
            }

        }
    }
}
