using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Exam2
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder text = new StringBuilder();
            do
            {
                string line = Console.ReadLine();
                if (line == "EXIT;")
                {
                    break;
                }
                text.Append(line);
                string openPrint = "PRINT(";
                string closePrint = ");";
                string openFor = "FOR(";
                string closeFor = ")";
                text = text.Replace(openPrint, "");
                text = text.Replace(closePrint, "");
                text = text.Replace(openFor, "");
                text = text.Replace(closeFor, "");
            } while (true);
            

            StringReader sr = new StringReader(text.ToString());
            string lineToPrint = null;
            while ((lineToPrint = sr.ReadLine()) != null)
            {
                if (!string.IsNullOrWhiteSpace(lineToPrint))
                {
                    Console.WriteLine(lineToPrint);
                }
            }
        }
    }
}
