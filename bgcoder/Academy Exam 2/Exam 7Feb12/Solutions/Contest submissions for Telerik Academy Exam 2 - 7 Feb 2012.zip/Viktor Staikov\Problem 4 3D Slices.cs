using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3DSlices
{
    class Program
    {
        static void Main(string[] args)
        {
            int W, H, D;
            char[] splitters = {' ','|'};
            string[] tokens = Console.ReadLine().Split();
            W = int.Parse(tokens[0]);
            H = int.Parse(tokens[1]);
            D = int.Parse(tokens[2]);
            int[, ,] cube = new int[W, H, D];
            int[, ,] sumCube = new int[W, H, D];
            bool notEmpty = false;
            for (int i = 0; i < H; i++)
            {
                tokens = Console.ReadLine().Split(splitters,StringSplitOptions.RemoveEmptyEntries);

                for (int j = 0; j < D; j++)
                {
                    for (int p = 0; p < W; p++)
                    {
                        cube[p, i, j] = int.Parse(tokens[j * W + p]);
                        if (cube[p, i, j] != 0)
                            notEmpty = true;
                    }
                }
            }

            for (int i = 0; i < D; i++)
            {
                for (int j = 0; j < H; j++)
                {
                    sumCube[0, j, i] = cube[0, j, i];
                    for (int p = 1; p < W; p++)
                    {
                        sumCube[p, j, i] = sumCube[p - 1, j, i] + cube[p, j, i];
                    }
                }
            }
            for (int i = 0; i < D; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    for (int p = 1; p < H; p++)
                    {
                        sumCube[j, p, i] = sumCube[j, p - 1, i] + sumCube[j, p, i];
                    }
                }
            }
            for (int i = 0; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    for (int p = 1; p < D; p++)
                    {
                        sumCube[j, i, p] = sumCube[j, i, p - 1] + sumCube[j, i, p];
                    }
                }
            }


            int total = sumCube[W - 1, H - 1, D - 1];
            //int total = 1000 * 100 * 100 * 100;
            //Console.WriteLine(total);
            int counter = 0;
            if (notEmpty==false)
            {
                Console.WriteLine(W - 1 + H - 1 + D - 1);
            }else
            if (total % 2 != 0)
                Console.WriteLine(0);
            else
            {
                for (int i = 0; i < W-1; i++)
                {
                    if (sumCube[i, H - 1, D - 1] == total / 2)
                        counter++;
                }
                for (int i = 0; i < H-1; i++)
                {
                    if (sumCube[W - 1, i, D - 1] == total / 2)
                        counter++;
                }
                for (int i = 0; i < D-1; i++)
                {
                    if (sumCube[W - 1, H - 1, i] == total / 2)
                        counter++;
                }
                Console.WriteLine(counter);
            }
        }
    }
}
//for (int i = 0; i < D; i++)
//{
//    for (int j = 0; j < H; j++)
//    {
//        for (int p = 0; p < W; p++)
//        {
//            Console.Write("{0} ", cube[p, j, i]);
//        }
//        Console.WriteLine();
//    }
//    Console.WriteLine("*");
//}