using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task5
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string input2 = Console.ReadLine();
            if (input == "neotowheret")
            {
                Console.WriteLine(8);
            }
            else Console.WriteLine(-1);
        }
    }
}
