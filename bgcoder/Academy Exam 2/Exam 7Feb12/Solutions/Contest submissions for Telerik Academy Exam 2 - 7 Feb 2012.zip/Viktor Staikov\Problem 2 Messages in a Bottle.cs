using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Messages
{
    class Messages
    {
        public static string message = Console.ReadLine();
        public static List<pair> chip = new List<pair>();
        public static Stack<char> ans = new Stack<char>();
        public static List<List<char>> answers = new List<List<char>>();
        public static int counter = 0;

        public struct pair
        {
            char letter;
            string code;
            public string Code
            {
                get
                {
                    return this.code;
                }
                set
                {
                    this.code = value;
                }
            }

            public char Letter
            {
                get
                {
                    return this.letter;
                }
                set
                {
                    this.letter = value;
                }
            }
        }
        public static int Comp(pair a, pair b)
        {
            return (a.Code.CompareTo(b.Code));
        }
        public static int Comp2(List<char> a, List<char> b)
        {
            int res = 0;
            for (int i = 0; i < Math.Min(a.Count, b.Count); i++)
            {
                res = a[i].CompareTo(b[i]);
                if (res != 0)
                    return res;
            }
            return a.Count.CompareTo(b.Count);
        }
        static void Main(string[] args)
        {
            char ch = ' ';
            char letter = ' ';
            StringBuilder code = new StringBuilder();
            pair p = new pair();
            letter = (char)Console.Read();
            while (true)
            {
                ch = (char)Console.Read();
                if (char.IsLetterOrDigit(ch) == false)
                {
                    p.Letter = letter;
                    p.Code = code.ToString();
                    chip.Add(p);
                    break;
                }
                if (char.IsLetter(ch) == true)
                {
                    p.Letter = letter;
                    p.Code = code.ToString();
                    chip.Add(p);
                    letter = ch;
                    code = new StringBuilder();
                }
                if (char.IsDigit(ch) == true)
                    code.Append(ch);
            }
            chip.Sort(Comp);

            Decode(0, message.Length - 1);
            Console.WriteLine(counter);
            for (int i = 0; i < counter; i++)
            {
                answers[i].Reverse();
            }

            answers.Sort(Comp2);

            for (int i = 0; i < answers.Count; i++)
            {
                if (answers[i].Count < 1)
                    continue;
                for (int j = 0; j < answers[i].Count; j++)
                {
                    Console.Write(answers[i][j]);
                }
                Console.WriteLine();
            }
        }

        private static void Decode(int start, int end)
        {
            if (start > end)
            {
                foreach (var item in ans)
                {
                    answers.Add(new List<char>());
                    answers[counter].Add(item);
                }
                counter++;
                return;
            }
            for (int i = 0; i <= end-start; i++)
            {
                int res = SearchFor(message.Substring(start, i+1));
                if (res < 0)
                    continue;
                else
                {
                    ans.Push(chip[res].Letter);
                    Decode(start + i + 1, end);
                    ans.Pop();
                }
            }
        }

        private static int SearchFor(string str)
        {
            int left = 0;
            int right = chip.Count - 1;
            int mid = (left + right) / 2;
            int cmp = 0;
            while (left <= right)
            {
                cmp = chip[mid].Code.CompareTo(str);
                if (cmp == 0)
                {
                    return mid;
                }
                if (cmp == 1)
                {
                    right = mid - 1;
                }
                if (cmp == -1)
                {
                    left = mid + 1;
                }
                mid = (left + right) / 2;
            }
            if (chip[mid].Code.CompareTo(str) == 0)
            {
                return mid;
            }
            else
                return -1;
        }
    }
}
