using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace _4._3DSlices
{
    class Slices3sD
    {
        static char[] splitChar = new char[] { ' ' };
        class Cuboid
        {
            public readonly int Width;
            public readonly int Height;
            public readonly int Depth;
            public int[, ,] cuboid;
            public Cuboid(int width, int height, int depth)
            {
                this.Width = width;
                this.Height = height;
                this.Depth = depth;
                this.cuboid = new int[this.Width, this.Height, this.Depth];
            }


            public long SumPart(int startWidth, int endWidth, int startHeight, int endHeight, int startDepth, int endDepth)
            {
                long sum = 0;
                for (int w = startWidth; w < endWidth; w++)
                {
                    for (int h = startHeight; h < endHeight; h++)
                    {
                        for (int d = startDepth; d < endDepth; d++)
                        {
                            sum += this.cuboid[w, h, d];
                        }
                    }
                }

                return sum;
            }

            public void InitializeViaConsole()
            {
                for (int h = 0; h < this.Height; h++)
                {
                    string[] input = Console.ReadLine().Split('|');
                    for (int d = 0; d < this.Depth; d++)
                    {
                        string[] numbersByWidth = input[d].Split(splitChar, StringSplitOptions.RemoveEmptyEntries);
                        for (int w = 0; w < this.Width; w++)
                        {
                            this.cuboid[w, h, d] = Convert.ToInt32(numbersByWidth[w]);
                        }
                    }
                }
            }

        }
        static void Main(string[] args)
        {
            string[] dimensions = Console.ReadLine().Split(' ');
            int width = Convert.ToInt32(dimensions[0]);
            int height = Convert.ToInt32(dimensions[1]);
            int depth = Convert.ToInt32(dimensions[2]);

            Cuboid bigCuboid = new Cuboid(width, height, depth);
            bigCuboid.InitializeViaConsole();
            long possibleSplits = 0;

            long maxSum = bigCuboid.SumPart(0, bigCuboid.Width, 0, bigCuboid.Height, 0, bigCuboid.Depth);
            //for width
            for (int w = 1; w < bigCuboid.Width; w++)
            {
                long sumFirstPart = bigCuboid.SumPart(0, w, 0, bigCuboid.Height, 0, bigCuboid.Depth);
                if (sumFirstPart == (maxSum - sumFirstPart))
                {
                    possibleSplits++;
                }
            }

            //for height
            for (int h = 1; h < bigCuboid.Height; h++)
            {
                long sumFirstPart = bigCuboid.SumPart(0, bigCuboid.Width, 0, h, 0, bigCuboid.Depth);
                if (sumFirstPart == (maxSum - sumFirstPart))
                {
                    possibleSplits++;
                }
            }

            //for depth
            for (int d = 1; d < bigCuboid.Depth; d++)
            {
                long sumFirstPart = bigCuboid.SumPart(0, bigCuboid.Width, 0, bigCuboid.Height, 0, d);
                if (sumFirstPart == (maxSum - sumFirstPart))
                {
                    possibleSplits++;
                }
            }
            Console.WriteLine(possibleSplits);
        }
    }
}
