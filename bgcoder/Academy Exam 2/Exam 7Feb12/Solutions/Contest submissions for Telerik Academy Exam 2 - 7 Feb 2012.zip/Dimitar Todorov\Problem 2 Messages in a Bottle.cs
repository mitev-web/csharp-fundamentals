using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.MessageInABottle
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder secretCode = new StringBuilder(Console.ReadLine());
            string cipher = Console.ReadLine();
            cipher = cipher + "/";
            StringBuilder code = new StringBuilder();
            for (int i=0;i<secretCode.Length;i++)
            {
                if (char.IsDigit(secretCode[i]))
                {
                    code.Append((int)secretCode[i]);
                    code.Append(" ");
                }
            }
         
            //Decipher
            StringBuilder deCipher = new StringBuilder();
            int number = 0;
            for (int i = 0; i < cipher.Length; i++)
            {
                if (cipher[i] == '/')
                {
                    deCipher.Append(number);
                }
                if (char.IsLetter(cipher[i]))
                {
                    if (number != 0)
                    {
                        deCipher.Append(number + " ");
                        number = 0;
                    }
                    deCipher.Append(cipher[i]);
                }
                else
                {
                    number = number * 10 + (cipher[i] - '0');
                }
            }

            int counter = 0;
            string letters = deCipher.ToString();
            string[] arrayOfLetters = letters.Split(' ');
            string numbers = code.ToString();
            string[] arrayOfNumber = numbers.Split(' ');
            StringBuilder possibleMessages = new StringBuilder();
            foreach (var num in arrayOfNumber)
            {
                for (int i = 0; i<arrayOfLetters.Length;i++)
                {
                    if (arrayOfLetters[i].IndexOf(num) != -1)
                    {
                        counter++;
                        possibleMessages.Append(arrayOfLetters[i]);
                        possibleMessages.Append(" ");
                    }
                }
            }
            Console.WriteLine(counter-1);
            StringBuilder possible = new StringBuilder();
            for (int i=0;i<possibleMessages.Length;i++)
            {
                if (char.IsLetter(possibleMessages[i]))
                {
                    possible.Append(possibleMessages[i]);
                }
            }
            
        }
    }
}
