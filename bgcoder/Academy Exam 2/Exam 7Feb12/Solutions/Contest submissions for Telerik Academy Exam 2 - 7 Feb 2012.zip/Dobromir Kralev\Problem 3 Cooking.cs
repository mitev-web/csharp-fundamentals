using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3__Cooking
{
    class Program
    {
        static int WhichIsLess(string str1, string str2)
        {
            int res = 0;
            if (str1 == "tbsps" && str2 == "tsps")
            {    res = 3;
               return res;
            }
            if (str1 == "ls" && str2 == "mls")
            {
                res = 1000;
                return res;
            }
            if (str1 == "cups" && str2 == "fl ozs")
            {    res = 8;
                return res;
            }
            if (str1 == "tsps" && str2 == "mls")
            {    res = 5;
                return res;
            }
            if (str1 == "gals" && str2 == "quarts")
            {    res = 4;   
                return res;
            }
            if (str1 == "pts" && str2 == "cups")
            {    res = 2;
               return res;
            }
            if (str1 == "qts" && str2 == "pts")
            {    res = 2;
               return res;
            }
            if (str1 == "cups" && str2 == "tsps")
            {    res = 48;
               return res;
            }
            return res;
        }
        static decimal Convert(string str1, string str2, decimal quantity)
        {
            decimal temp;
            if (str1 == str2)
                return quantity;
            int n = WhichIsLess(str1, str2);

            if (n == 0)
            {
                temp = Convert(str2, str1, quantity);
            }
            else
            {
                temp = quantity / n;
            }
            return temp ;
        }
        static void MissingIngredience(string[] str1, string[] str2)
        {
            for (int i = 0; i < str1.Length; i++)
            {
                string unit1=str1[i].Substring(str1[i].IndexOf(':')+1,str1[i].LastIndexOf(':')-str1[i].IndexOf(':')-1);
                if (str1.Length == str2.Length)
                    for (int j = 0; j < str2.Length; j++)
                    {
                        string unit2 = str2[j].Substring(str2[j].IndexOf(':') + 1, str2[j].LastIndexOf(':') - str2[j].IndexOf(':') - 1);
                        if (str1[i].Substring(str1[i].LastIndexOf(':')).ToLower() == str2[j].Substring(str2[j].LastIndexOf(':')).ToLower())
                        {
                            decimal value1 = decimal.Parse(str1[i].Substring(0, str1[i].IndexOf(':')));
                            decimal value2 = decimal.Parse(str2[j].Substring(0, str2[j].IndexOf(':')));
                            if (WhichIsLess(unit1, unit2) == 0)
                                Console.WriteLine("{0,4:F}:{1}:{2}", decimal.Ceiling(value2) - Convert(unit2, unit1, value1), unit1, str1[j].Substring(str1[i].LastIndexOf(':')+1));
                            else
                                Console.WriteLine("{0,4:F}:{1}:{2}", decimal.Ceiling(value1) - Convert(unit1, unit2, value2), unit1, str1[j].Substring(str1[i].LastIndexOf(':')+1));
                        }
                    }
                else
                {
                    for (int j = 0; j < str1.Length; j++)
                    {
                        string unit2 = str1[j].Substring(str1[j].IndexOf(':') + 1, str1[j].LastIndexOf(':') - str1[j].IndexOf(':') - 1);
                        if (str1[i].Substring(str1[i].LastIndexOf(':')).ToLower() == str1[j].Substring(str1[j].LastIndexOf(':')).ToLower())
                        {
                            decimal value1 = decimal.Parse(str1[i].Substring(0, str1[i].IndexOf(':')));
                            decimal value2 = decimal.Parse(str1[j].Substring(0, str1[j].IndexOf(':')));
                            if (WhichIsLess(unit1, unit2) == 0)
                                Console.WriteLine("{0,4:F}:{1}:{2}", (value2 + Convert(unit2, unit1, value1)), unit1, str1[j].Substring(str1[i].LastIndexOf(':')+1));
                            else
                                Console.WriteLine("{0,4:F}:{1}:{2}", (value1 + Convert(unit1, unit2, value2)), unit1, str1[j].Substring(str1[i].LastIndexOf(':')+1));
                        }
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            int n=int.Parse(Console.ReadLine());
            string[] ingredients = new string[n];
            for (int i = 0; i < ingredients.Length; i++)
            {
                ingredients[i] = Console.ReadLine();
            }
            //ingredients[0] = "1.006:ls:Old Milk";
            int m = int.Parse(Console.ReadLine());
            string[] alreadyUsed = new string[m];
            //alreadyUsed[0] = "800:mls:Old MILK";
            for (int i = 0; i < alreadyUsed.Length; i++)
            {
                alreadyUsed[i] = Console.ReadLine();
            }
            MissingIngredience(ingredients, alreadyUsed);
        }
    }
}
