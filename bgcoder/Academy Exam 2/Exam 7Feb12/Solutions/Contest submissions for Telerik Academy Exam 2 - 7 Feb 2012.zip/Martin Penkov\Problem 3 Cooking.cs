using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;


namespace _03.Cooking
{
    class Program
    {
        public class Ingridient
        {
            public double quantiti;
            public string measurement;
            public string name;
            public Ingridient(double quantiti, string measurement, string name)
            {
                this.quantiti = quantiti;
                this.measurement = measurement;
                this.name = name;
            }
            public Ingridient(string quantiti, string measurement, string name)
            {
                this.quantiti = double.Parse(quantiti);
                this.measurement = measurement;
                this.name = name;
            }
            public void Remove()
            {
                this.name = "-";
            }
        }
        static string fixDouble(string x)
        {
            int position = x.IndexOf('.');
            if (position == -1)
            {
                return x;
            }
            else
            {
                return x.Substring(0, position) + "," + x.Substring(position + 1);
            }
        }
        static string unfixDouble(double x)
        {
            x = Math.Round(x, 2);
            string result = x.ToString();
            return fixDouble(result);
        }
        static double Convert(string fromMeasurement, string toMeasurement, double quantiti)
        {
            if (fromMeasurement == "tablespoons") fromMeasurement = "tbsps";
            if (fromMeasurement == "teaspoons") fromMeasurement = "tsps";
            if (fromMeasurement == "liters") fromMeasurement = "ls";
            if (fromMeasurement == "milliliters") fromMeasurement = "mls";
            if (fromMeasurement == "fluid ounces") fromMeasurement = "fl ozc";
            if (fromMeasurement == "gallons") fromMeasurement = "gals";
            if (fromMeasurement == "quarts" && (toMeasurement=="pints" || toMeasurement=="pts")) fromMeasurement = "qts";
            if (fromMeasurement == "pints") fromMeasurement = "pts";

            if (toMeasurement == "tablespoons") toMeasurement = "tbsps";
            if (toMeasurement == "teaspoons") toMeasurement = "tsps";
            if (toMeasurement == "liters") toMeasurement = "ls";
            if (toMeasurement == "milliliters") toMeasurement = "mls";
            if (toMeasurement == "fluid ounces") toMeasurement = "fl ozc";
            if (toMeasurement == "gallons") toMeasurement = "gals";
            if (toMeasurement == "quarts" && (fromMeasurement=="pints" || fromMeasurement=="pts")) toMeasurement = "qts";
            if (toMeasurement == "pints") toMeasurement = "pts";

            if (fromMeasurement == toMeasurement)
            {
                return (double)  quantiti;
            }
            if (fromMeasurement == "tbsps" && toMeasurement == "tsps")
            {
                return (double)  quantiti * 3;
            }
            if (fromMeasurement == "tsps" && toMeasurement == "tbsps")
            {
                return (double)  quantiti * 1.0 / 3.0;
            }
            if (fromMeasurement == "ls" && toMeasurement == "msl")
            {
                return (double)  quantiti * 1000;
            }
            if (fromMeasurement == "mls" && toMeasurement == "ls")
            {
                return (double)  quantiti * 1.0 / 1000.0;
            }
            if (fromMeasurement == "fl ozs" && toMeasurement == "cups")
            {
                return (double)  quantiti * 1.0 / 8.0;
            }
            if (fromMeasurement == "cups" && toMeasurement == "fl ozs")
            {
                return (double)  quantiti * 8;
            }
            if (fromMeasurement == "teaspoons" && toMeasurement == "msl")
            {
                return (double)  quantiti * 5;
            }
            if (fromMeasurement == "msl" && toMeasurement == "teaspoons")
            {
                return (double)  quantiti * 1.0 / 5.0;
            }

            if (fromMeasurement == "gals" && toMeasurement == "quarts")
            {
                return (double)  quantiti * 4;
            }
            if (fromMeasurement == "quarts" && toMeasurement == "gals")
            {
                return (double)  quantiti * 1.0 / 4.0;
            }
            if (fromMeasurement == "pts" && toMeasurement == "cups")
            {
                return (double)  quantiti * 2;
            }
            if (fromMeasurement == "cups" && toMeasurement == "pts")
            {
                return (double)  quantiti * 1.0 / 2.0;
            }
            if (fromMeasurement == "qts" && toMeasurement == "pts")
            {
                return (double)  quantiti * 2;
            }
            if (fromMeasurement == "pts" && toMeasurement == "qts")
            {
                return (double)  quantiti * 1.0 / 2.0;
            }
            if (fromMeasurement == "cups" && toMeasurement == "tsps")
            {
                return (double)  quantiti * 48;
            }
            if (fromMeasurement == "tsps" && toMeasurement == "cups")
            {
                return (double)  quantiti * 1.0 / 48.0;
            }
            //Console.WriteLine("FAILD AT CONVERSION!");
           // recepie[(int)-quantiti - 1].quantiti = 0;
            return (double)  quantiti;
        }
        static List<Ingridient> recepie = new List<Ingridient>();
        static List<Ingridient> takenIngredient = new List<Ingridient>();

        static double FindHowMuchIsNeeded(int position)
        {
            double needed = recepie[position].quantiti;
            for (int i = position + 1; i < recepie.Count; i++)
            {
                if (recepie[i].name.ToLower() == recepie[position].name.ToLower())
                {
                    needed += Convert(recepie[i].measurement, recepie[position].measurement, recepie[i].quantiti);
                    recepie[i].Remove();
                }
            }
            return needed;
        }
        static double FindHowMuchIsPossesed(int position)
        {
            double possesed = 0;
            for (int i = 0; i < takenIngredient.Count; i++)
            {
                if (recepie[position].name.ToLower() == takenIngredient[i].name.ToLower())
                {
                    possesed += Convert(takenIngredient[i].measurement, recepie[position].measurement, takenIngredient[i].quantiti);
                }
            }
            return possesed;
        }

        static void Main(string[] args)
        {
            string[] separators = { ":", };
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            int recepieSize = int.Parse(Console.ReadLine());
            for (int i = 0; i < recepieSize; i++)
            {
                string input = Console.ReadLine();
                string[] devided = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                recepie.Add(new Ingridient(devided[0], devided[1], devided[2]));
            }
            int takenIngredientsSize = int.Parse(Console.ReadLine());
            for (int i = 0; i < takenIngredientsSize; i++)
            {
                string input = Console.ReadLine();
                string[] devided = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                takenIngredient.Add(new Ingridient(devided[0], devided[1], devided[2]));
            }

            bool printed = false;
            for (int i = 0; i < recepie.Count; i++)
            {
                if (recepie[i].name != "-")
                {
                    double quantitiNeeded = FindHowMuchIsNeeded(i);
                    double quantitiInPossesion = FindHowMuchIsPossesed(i);
                    if (Math.Abs(quantitiInPossesion - quantitiNeeded) < 0.00001) continue;
                    if (quantitiNeeded>quantitiInPossesion)
                    {
                        Console.WriteLine("{0:0.00}:{1}:{2}", quantitiNeeded - quantitiInPossesion, recepie[i].measurement, recepie[i].name);
                        printed = true;
                    }
                }
            }
            if (printed == false)
            {
                Console.WriteLine();
            }

        }
    }
}
