using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Problem03_Cooking
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            
            string input;
            List<string> recipe = new List<string>();
            
            
            char[] separator = { ':' };
            for (int i = 0; i < N; i++)
            {
                input = Console.ReadLine();
                recipe.Add(input);
            }
            int M = int.Parse(Console.ReadLine());
            List<string> usedProducts = new List<string>();
            for (int j = 0; j < M; j++)
            {
                input = Console.ReadLine();
                usedProducts.Add(input) ;
            }
            string[] final = new string[100];
            string str = null;
            int count = 0;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            foreach (string ingredient in recipe)
            {
                string[] a = ingredient.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                foreach (string item in usedProducts)
                {
                    string[] b = item.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                    if (a[2].ToLower() == b[2].ToLower())
                    {
                        if (a[0] != b[0])
                        {
                            str += a[2];
                            str += ':';
                            str += a[1];
                            str += ':';
                            decimal difference = Math.Abs(decimal.Parse(a[0].ToString()) - decimal.Parse(b[0].ToString()) / 1000);
                            str += difference;
                        }
                    }
                }
                final[count] = str;
                count++;
                str = null;
            }

        }

        
    }
}
