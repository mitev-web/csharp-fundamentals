using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace T02.MessageInBotthle
{
    class Program
    {
        static Dictionary<string, char> dicoo = new Dictionary<string, char>();
        static StringBuilder text = new StringBuilder();
        static List<string> texts = new List<string>();

        static void Decode(string code, int minLenght)
        {
            if (code.Length < minLenght)
            {
                texts.Add(text.ToString());
                return;
            }
            int pos = text.Length;
            foreach (var item in dicoo.Keys)
            {
                if (code.StartsWith(item))
                {
                    text.Append(dicoo[item]);
                    Decode(code.Substring(item.Length), minLenght);
                    text.Remove(pos, text.Length - pos);
                }
            }
        }

        static void Main(string[] args)
        {
            //string code = "1122";
            //string cipher = "A1b12c11d2".ToUpper();
            string code = Console.ReadLine().Trim();
            string cipher = Console.ReadLine().Trim().ToUpper();
            int maxKeyLength = 0, minKeyLength = int.MaxValue;
            for (int i = 0; i < cipher.Length; i++)
            {
                char ch = cipher[i];
                if (char.IsLetter(ch))
                {
                    StringBuilder sb = new StringBuilder();
                    char dig = '0';
                    while (++i < cipher.Length)
                    {
                        if (char.IsDigit(dig = cipher[i]))
                        {
                            sb.Append(dig);
                        }
                        else
                        {
                            break;
                        }
                    }
                    i--;
                    int keyLength = sb.ToString().Length;
                    if (keyLength > maxKeyLength) maxKeyLength = keyLength;
                    if (keyLength < minKeyLength) minKeyLength = keyLength;
                    if (keyLength > 0 && !dicoo.ContainsKey(sb.ToString())) dicoo.Add(sb.ToString(), ch);
                }
            }
            Decode(code, minKeyLength);
            //            Console.WriteLine("{0}/{1}/{2}", code, cipher, texts.Count);
            int count = texts.Count;
            if (count > 2048) count = 2048;
            Console.WriteLine(count);
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(texts[i]);
            }
        }
    }
}
