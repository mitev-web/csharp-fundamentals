using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Basic
{
    class Program
    {
        static bool semafor = false;
        static Queue<int[]> fors = new Queue<int[]>();
        static void loop(StringBuilder text, Match argum)
        {
            while (fors.Count > 0)
            {
                int[] f = fors.Dequeue();
                for (int i = f[0]; i <= f[1]; i++)
                {
                    if (!semafor)
                        break;
                    loop(text, argum);
                    text.Append(argum.ToString());
                    text.Remove(0, 1);
                    text.Remove(text.Length - 1, 1);
                    Console.Write(text.ToString());
                    semafor = true;
                }

            }
        }

        static void Main(string[] args)
        {
            StringBuilder text = new StringBuilder(1000);
            //commands.Append("PRINT()");
            string s = "FOR(2 4,) PRINT (jhjklh ) EXIT";
            Match comand = Regex.Match(s, @"\b[\w]{3,5}\s*");
            Match argum = Regex.Match(s, @"[\(]{1}s*[\w\d\W]*\s*[\)]{1}");
            while (comand.NextMatch().ToString() != "EXIT")
            {
                switch (comand.ToString())
                {
                    case "PRINT":
                        while (fors.Count >0)
                        {
                            int[] f = fors.Dequeue();
                            for (int i = f[0]; i <= f[1]; i++)
                            {
                                loop(text, argum);
                                semafor = false;
                            }
                            
                        }
                        text.Append(argum.ToString());
                        text.Remove(0, 1);
                        text.Remove(text.Length-1, 1);
                        Console.Write(text.ToString());
                        break;
                    case "FOR":
                        Match digits = Regex.Match(argum.ToString(), @"\d{1,}");
                        fors.Enqueue(new int[] { int.Parse(digits.ToString()), int.Parse(digits.NextMatch().ToString()) });                        
                        break;
                    

                }
                Console.WriteLine(argum.ToString());
                comand = comand.NextMatch();
                argum =argum.NextMatch();
            }
           

        }
    }
}
