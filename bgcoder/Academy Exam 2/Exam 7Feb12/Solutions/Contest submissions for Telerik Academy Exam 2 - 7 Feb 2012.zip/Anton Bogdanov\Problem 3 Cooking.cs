using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Ex._03
{
    class Program
    {
        static List<string> listRec = new List<string>();
        static List<string> listUse = new List<string>();
        static List<string> final = new List<string>();
        static Dictionary<string, line> dicRec = new Dictionary<string, line>();
        static Dictionary<string, line> dicUSE = new Dictionary<string, line>();
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Reader();
            Prepare();
            Print();
        }

        private static void Print()
        {
            foreach (var rec in dicRec)
            {
                if (dicUSE.ContainsKey(rec.Key))
                {
                    line ln = dicRec[rec.Key] - dicUSE[rec.Key];
                    if (ln.size > 0)
                    {
                        Console.WriteLine( ln.ToString()+":"+ rec.Key);
                    }
                }
                else 
                {
                    Console.WriteLine(dicRec[rec.Key].ToString()+":"+ rec.Key);
                }
            }
        }

        private static void Prepare()
        {
            foreach (var item in listRec)
            {
                string[] arr = item.Split(':');
                if (dicRec.ContainsKey(arr[2].ToLower()))
                {
                    dicRec[arr[2]] += dicRec[arr[2]];
                }
                else 
                {
                    dicRec.Add(arr[2].ToLower(), new line(double.Parse(arr[0]), arr[1]));
                }
            }
            foreach (var item in listUse)
            {
                string[] arr = item.Split(':');
                if (dicUSE.ContainsKey(arr[2].ToLower()))
                {
                    dicUSE[arr[2]] += dicUSE[arr[2]];
                }
                else
                {
                    dicUSE.Add(arr[2].ToLower(), new line(double.Parse(arr[0]), arr[1]));
                }
            }
        }

        private static void Reader()
        {
            int N = int.Parse(Console.ReadLine());

            for (int i = 0; i < N; i++)
            {
                listRec.Add(Console.ReadLine());
            }
            int M = int.Parse(Console.ReadLine());

            for (int i = 0; i < N; i++)
            {
                listUse.Add(Console.ReadLine());
            }
        }
    }
    class line 
    {
        public double size;
        public string type;
        public string firsttype;

        public line(double size, string type) 
        {
            this.size = size;
            this.type = type;
            this.firsttype = this.type;
            for (int i = 0; i < 8; i++)
            {
                Trans();
            }
        }

        private void Trans()
        {
            if (this.type == "tbsps" || this.type == "tablespoons") 
            {
                this.type = "mls";
                this.size *=15;
               
            }
            if (this.type == "ls" || this.type == "liters")
            {
                this.type = "mls";
                this.size *= 1000;

            }
            if (this.type == "fl ozs" || this.type == "fluid ounces")
            {
                this.type = "cups";
                this.size /=8 ;

            }
            if (this.type == "teaspoons")
            {
                this.type = "mls";
                this.size *= 5;

            }
            if (this.type == "gallons" || this.type =="qals")
            {
                this.type = "quarts";
                this.size *= 4;

            }
            if (this.type == "pints" || this.type == "pts")
            {
                this.type = "cups";
                this.size *= 2;

            }
            if (this.type == "quarts" || this.type == "qts")
            {
                this.type = "pints";
                this.size *= 2;

            }
            if (this.type == "cups")
            {
                this.type = "tsps";
                this.size *= 48;

            }
        }
        public static line operator +(line one, line two) 
        {
            return new line(one.size + two.size, one.type);
        }
        public static line operator -(line one, line two)
        {
            return new line(one.size - two.size, one.type);
        }
        public override string ToString()
        {
            //if (this.firsttype == "tbsps" || this.firsttype == "tablespoons")
            //{
            //    this.type = this.firsttype;
            //    this.size *= ;

            //}
            //if (this.firsttype == "ls" || this.firsttype == "liters")
            //{
            //    this.type = this.firsttype;
            //    this.size *= 1000;

            //}
            //if (this.firsttype == "fl ozs" || this.firsttype == "fluid ounces")
            //{
            //    this.type = this.firsttype;
            //    this.size /= 8;

            //}
            //if (this.firsttype == "teaspoons")
            //{
            //    this.type = this.firsttype;
            //    this.size *= 5;

            //}
            //if (this.firsttype == "gallons" || this.firsttype == "qals")
            //{
            //    this.type = this.firsttype;
            //    this.size *= 4;

            //}
            //if (this.firsttype == "pints" || this.firsttype == "pts")
            //{
            //    this.type = this.firsttype;
            //    this.size *= 2;

            //}
            //if (this.firsttype == "quarts" || this.firsttype == "qts")
            //{
            //    this.type = this.firsttype;
            //    this.size *= 2;

            //}
            //if (this.firsttype == "cups")
            //{
            //    this.type = this.firsttype;
            //    this.size *= 48;

            //}
            StringBuilder sb = new StringBuilder();
            sb.Append(this.size.ToString("F1", CultureInfo.InvariantCulture));
            sb.Append(":");
            sb.Append(this.type);
            return sb.ToString();
        }
    }
}
