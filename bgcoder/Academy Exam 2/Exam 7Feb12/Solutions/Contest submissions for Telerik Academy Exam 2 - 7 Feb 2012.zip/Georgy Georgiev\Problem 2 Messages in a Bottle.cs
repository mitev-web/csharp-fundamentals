using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Message
{    
    class Program
    {
        static SortedDictionary<char, string> letters = new SortedDictionary<char,string>();
        static string encoded;
        static List<string> decoded = new List<string>();

        static void InputLet(string code)
        {
            Match match = Regex.Match(code, @"[A-Z]{1}[\d]{1,}");
            while (match.Success)
            {
                char let = match.ToString()[0];
                string cod = match.ToString().Substring(1);
                if (!letters.ContainsKey(let))
                {
                    letters.Add(let, cod);
                }
                
                match = match.NextMatch();
            }
           
        }

        static string TestLet(string encoded)
        {
            StringBuilder sb = new StringBuilder(12);
            StringBuilder result = new StringBuilder(12);
            sb.Append(encoded);
            foreach (var item in letters)
            {
                Match match = Regex.Match(sb.ToString(), @"\b" + item.Value);
                if (match.Success)
                {
                    result.Append(item.Key);
                    sb.Remove(0,item.Value.Length);
                    NextLetter(match, sb, result);
                    sb.Clear();
                    sb.Append(encoded);
                    result.Clear();
                    match = match.NextMatch();
                }
            }
            return result.ToString();

        }

        static void NextLetter(Match match, StringBuilder sb, StringBuilder result)
        {
            if (sb.Length == 0)
            {
                decoded.Add(result.ToString());
                sb.Clear();
                sb.Append(encoded);
                result.Clear();
                return;
            }
            //match = match.NextMatch();
            foreach (var item in letters)
            {
                Match match1 = Regex.Match(sb.ToString(), @"\b" + item.Value);
                if (match1.Success)
                {
                    string copysb = sb.ToString();
                    string copyresult = result.ToString();
                    result.Append(item.Key);                    
                    sb.Remove(0, item.Value.Length);
                    NextLetter(match, sb, result);
                    sb.Clear();
                    //if (copysb != item.Value)
                    //{
                        sb.Append(copysb);
                    //}
                    result.Clear();
                    result.Append(copyresult);
                  // match = match.NextMatch();
                } 
            }
            
        }

        static void Main(string[] args)
        {
            string sec = Console.ReadLine();
            string let = Console.ReadLine();
            InputLet(let);
            //foreach (var item in letters)
            //{
            //    Console.Write(item.Key+" "); 

            //    Console.WriteLine(item.Value);
            //}
            TestLet(sec);
            //Console.WriteLine(TestLet("1122"));
            Console.WriteLine(decoded.Count);
            Prn(decoded);

        }

        static void Prn(List<string> values)
        {
            foreach (var item in values)
            {
                Console.WriteLine(item);
            }
        }
    }
}
