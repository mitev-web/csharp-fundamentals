using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _1.BasicLanguage
{
    class BasicLanguage
    {
        static bool inPrint;
        static BigInteger iterations;
        static StringBuilder output;
        static StringBuilder currentPrint;
        static char[] splitFor = new char[] { ',', ' ' };

        static void CreateOutput()
        {
            if (currentPrint.Length == 0)
            {
                iterations = 0;
                return;
            }
            if (iterations == 0)
            {
                output.Append(currentPrint);
            }
            else
            {
                if (currentPrint.Length == 1)
                {
                    if (iterations > Int32.MaxValue)
                    {
                        throw new Exception();
                    }
                    output.Append(new string(currentPrint[0], (int)iterations));
                }
                else
                {
                    for (int counter = 0; counter < iterations; counter++)
                    {
                        output.Append(currentPrint);
                    }
                }
            }
            currentPrint.Clear();
            iterations = 0;
        }


        static void ProcessInput(string input)
        {
            if (input.Length == 0)
            {
                return;
            }
            if (inPrint == true)
            {
                int indexCloseBracket = input.IndexOf(')');
                currentPrint.Append(input.Substring(0, indexCloseBracket));
                inPrint = false;
                CreateOutput();
                return;

            }

            #region getCommands
            else //inprint = false
            {
                for (int index = 0; index < input.Length; index++)
                {
                    if (input[index] == 'P') //entering a print
                    {
                        inPrint = true;
                        int indexOpen = input.IndexOf('(', index + 2);
                        ProcessInput(input.Substring(indexOpen + 1));
                        index = input.IndexOf(')', index);
                    }
                    else if (input[index] == 'F') //entering a loop
                    {
                        
                        //Get the iterations
                        int indexClosedBracket = input.IndexOf(')', index + 3);
                        int indexOpenBracket = input.IndexOf('(', index + 2);
                        GetIterations(input.Substring(indexOpenBracket + 1, indexClosedBracket - indexOpenBracket - 1));
                        index = indexClosedBracket;
                    }
                    else if (input[index] == 'E') //exiting the program
                    {
                        return;
                    }
                    else if (input[index] == ';') //end of line operant
                    {
                        iterations = 0;
                    }
                    else //not a meaningfull char?
                    {
                        //throw new Exception("Something's wrong");
                    }
                }
            }
            #endregion
            return;
        }

        static void GetIterations(string forParameters)
        {
            if (forParameters.Contains(',') == true) //a and b
            {
                string[] iterationsParam = forParameters.Split(splitFor, StringSplitOptions.RemoveEmptyEntries);
                long b = Convert.ToInt64(iterationsParam[1]);
                long a = Convert.ToInt64(iterationsParam[0]);
                if (iterations == 0)
                {
                    iterations += b - a + 1;
                }
                else
                {
                    iterations = iterations * (b - a + 1);
                }
            }
            else //just a
            {
                long a = Convert.ToInt64(forParameters);
                if (iterations == 0)
                {
                    iterations += a;
                }
                else
                {
                    iterations *= a;
                }
            }
        }

        static string GetInput()
        {
            string line;
            bool foundExit = false;
            StringBuilder input = new StringBuilder();
            do
            {
                line = Console.ReadLine();
                for (int index = 0; index < line.Length; index++)
                {
                    if (inPrint == true && line[index] == ')')
                    {
                        inPrint = false;
                    }
                    if (line[index] == 'P')
                    {
                        inPrint = true;
                    }
                    if (line[index] == 'E' && inPrint == false)
                    {
                        foundExit = true;
                    }
                }
                input.Append(line);
                if (inPrint == true)
                {
                    input.AppendLine();
                }
            }
            while (foundExit == false);

            return input.ToString();
        }
        static void Main(string[] args)
        {
            inPrint = false;
            iterations = 0;
            output = new StringBuilder(10000000);
            currentPrint = new StringBuilder(10000);

            string input = GetInput();
            ProcessInput(input);
            Console.WriteLine(output);
        }
    }
}
