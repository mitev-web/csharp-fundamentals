using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad2
{
    class Program
    {
        static int width;
        static int height;
        static int depth;
        static short[, ,] cuboid;
        static void Main(string[] args)
        {
            ReadCuboid();
        }
        private static void ReadCuboid()
        {
 
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);
            cuboid = new short[width, height, depth];
            int sum = 0;
            int sum1 = 0;
            int sum2 = 0;
            int sum3 = 0;
            int counter = 0;
            int equalSum = 0;
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                        sum = sum + cuboid[w,h,d];
                        for (int i = 1; i < width; i++)
                        {
                            for (int w1 = w + i; w1 < width; w1++)
                            {
                                short cubeValue1 = short.Parse(numbers[w1]);
                                cuboid[w1, h, d] = cubeValue1;
                                sum1 = sum1 + cuboid[w1, h, d];
                                equalSum = sum - sum1;
                                if (equalSum == sum1)
                                {
                                    counter++;
                                }
                            }
                        }
                        for (int i = 1; i < height; i++)
                        {
                            for (int h1 = h + i; h1 < height; h1++)
                            {
                                short cubeValue2 = short.Parse(numbers[h1]);
                                cuboid[w, h1, d] = cubeValue2;
                                sum2 = sum2 + cuboid[w, h1, d];
                                equalSum = sum - sum2;
                                if (equalSum == sum2)
                                {
                                    counter++;
                                }
                            }
                        }
                        for (int i = 1; i < depth; i++)
                        {
                            for (int d1 = d + i; d1 < depth; d1++)
                            {
                                short cubeValue3 = short.Parse(numbers[d1]);
                                cuboid[w, h, d1] = cubeValue3;
                                sum3 = sum3 + cuboid[w, h, d1];
                                equalSum = sum - sum3;
                                if (equalSum == sum3)
                                {
                                    counter++;
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine(counter);
        }
    }
}
