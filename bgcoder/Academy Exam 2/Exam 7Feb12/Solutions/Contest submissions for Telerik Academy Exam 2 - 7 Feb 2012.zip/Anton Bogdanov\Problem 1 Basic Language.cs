using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex._01
{
    class Program
    {
        static StringBuilder lines = new StringBuilder();
        static StringBuilder final = new StringBuilder(); 

        static void Main(string[] args)
        {
            ReadInPut();
            Preparator();
            Console.WriteLine(final.ToString());
        }

        private static void Preparator()
        {
            string inPut = lines.ToString();

            int indexStart = 0;
            //int indexEnd = 0;

            int inBra = 0;
            


            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i] == '(')
                {
                    inBra++;
                }
                if (lines[i] == ')')
                {
                    inBra--;
                }
                if (lines[i] == ';' && inBra == 0) 
                {
                    
                    AddToPrinter(inPut.Substring(indexStart, i - indexStart));
     
                    indexStart = i;
                } 
            }
        }

        private static void AddToPrinter(string p)
        {
            List<int> listOpenBra = new List<int>();
            List<int> listCloseBra = new List<int>();
            for (int i = 0; i < p.Length; i++)
            {
                if (p[i] == '(')
                {
                    listOpenBra.Add(i);
                }
                if (p[i] == ')')
                {
                    listCloseBra.Add(i);
                }
            }
            int multy =1;
            for (int i = 0; i < listCloseBra.Count; i++)
            {
                if (p[listOpenBra[i] - 1] == 'R')
                {
                    multy *= ForPrepare(listOpenBra[i], listCloseBra[i], p);
                }
                else 
                {
                    for (int ii = 0; ii < multy; ii++)
                    {
                        try
                        {
                            final.Append(p.Substring(listOpenBra[i] + 1, listCloseBra[i] - listOpenBra[i] - 1));
                        }
                        catch (Exception) 
                        {
                            throw new InvalidCastException();
                        }
                    }
                }
            }

        }

        private static int ForPrepare(int p, int p_2, string p_3)
        {
            string str = p_3.Substring(p+1, p_2 - p-1);
            if (!str.Contains(','))
            {
                return int.Parse(str.Trim());
            }
            else 
            {
                string[] ab = str.Split(',');

                return int.Parse(ab[1].Trim()) - int.Parse(ab[0].Trim()) + 1;
            }
        }

        private static void ReadInPut()
        {
            while (true)
            {
                string str = Console.ReadLine();
                //string str = "FOR(0,1)PRINT ();FOR(22) PRINT(C); EXIT ;";

                    StringBuilder sb = new StringBuilder();
                    int inBra = 0;
                    for (int i = 0; i < str.Length; i++)
                    {
                        if (str[i] == '(')
                        {
                            inBra++;
                        }
                        if (str[i] == ')')
                        {
                            inBra--;
                        }
                        if (inBra == 0 && str[i] != ' ')
                        {
                            sb.Append(str[i].ToString().ToUpper());
                        }
                        if (inBra != 0)
                        {
                            sb.Append(str[i]);
                        }

                    }
                    string newStr = sb.ToString();
                    lines.Append(newStr);
                
                if(newStr.Contains("EXIT"))
                {
                    if (newStr.Substring(newStr.Length - 5) == "EXIT;") 
                    {
                        break;
                    }
                }

            }
        }
    }
}
