using System;
using System.Text;

namespace _1.BasicLanguage
{
    class BasicLanguage
    {
        static bool isForOn = false;
        static long forIterations = 0;
        static StringBuilder result;

        static void ExecuteCode(string line)
        {
            for (int currentChar = 0; currentChar < line.Length; currentChar++)
            {
                if (line[currentChar] == 'P')
                {
                    if (line.Substring(currentChar, 5) == "PRINT")
                    {
                        int indexOfOpeningBracket = line.IndexOf('(', currentChar + 5);
                        int indexOfClosingBracket = line.IndexOf(')', indexOfOpeningBracket + 1);
                        if (isForOn == true)
                        {
                            for (long iterations = 0; iterations < forIterations; iterations++)
                            {
                                result.Append(line.Substring(indexOfOpeningBracket + 1,
                                    indexOfClosingBracket - (indexOfOpeningBracket + 1)));
                            }
                            forIterations = 0;
                            isForOn = false;
                        }
                        else
                        {
                            result.Append(line.Substring(indexOfOpeningBracket + 1,
                            indexOfClosingBracket - (indexOfOpeningBracket + 1)));
                        }

                        currentChar = line.IndexOf(';', indexOfClosingBracket);
                    }
                }
                else if (line[currentChar] == 'F')
                {
                    if (line.Substring(currentChar, 3) == "FOR")
                    {
                        int indexOfOpeningBracket = line.IndexOf('(', currentChar + 3);
                        int indexOfClosingBracket = line.IndexOf(')', indexOfOpeningBracket + 1);
                        string forInside = line.Substring(indexOfOpeningBracket + 1,
                            indexOfClosingBracket - (indexOfOpeningBracket + 1));
                        if (forInside.IndexOf(',') == -1)
                        {
                            if (isForOn == true)
                            {
                                forIterations *= long.Parse(forInside.Trim());
                            }
                            else
                            {
                                forIterations += long.Parse(forInside.Trim());
                            }
                        }
                        else
                        {
                            string[] doubleForComponents = forInside.Split(new char[] { ' ', ',' },
                                StringSplitOptions.RemoveEmptyEntries);
                            if (isForOn == true)
                            {
                                forIterations *= (long.Parse(doubleForComponents[1]) -
                                              long.Parse(doubleForComponents[0]) + 1);

                            }
                            else
                            {
                                forIterations += (long.Parse(doubleForComponents[1]) -
                                              long.Parse(doubleForComponents[0]) + 1);
                            }
                        }
                        currentChar = indexOfClosingBracket;
                        isForOn = true;
                    }
                }
                else if (line[currentChar] == 'E')
                {
                    if (line.Substring(currentChar, 4) == "EXIT")
                    {
                        break;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            result = new StringBuilder();
            StringBuilder input = new StringBuilder();
            string line = string.Empty;
            int lastIndexOfEnd = -1;

            while (lastIndexOfEnd == -1)
            {
                line = Console.ReadLine();
                input.Append(line);
                lastIndexOfEnd = line.Replace(" ", "").LastIndexOf("EXIT;");
            }

            ExecuteCode(input.ToString());
            Console.WriteLine(result);
        }
    }
}