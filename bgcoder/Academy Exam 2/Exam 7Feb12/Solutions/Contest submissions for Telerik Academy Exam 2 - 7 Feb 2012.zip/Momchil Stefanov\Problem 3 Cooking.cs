using System;
using System.Collections.Generic;
using System.Linq;

namespace _03.Cooking
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Tuple<decimal, string, string>> recipe = new List<Tuple<decimal, string, string>>();
            int N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                string line = Console.ReadLine();
                string[] product = line.Split(':');
                recipe.Add(new Tuple<decimal,string,string>(decimal.Parse(product[0]), product[1], product[2]));
            }
            List<Tuple<decimal, string, string>> used = new List<Tuple<decimal, string, string>>();
            int M = int.Parse(Console.ReadLine());
            for (int i = 0; i < M; i++)
            {
                string line = Console.ReadLine();
                string[] product = line.Split(':');
                used.Add(new Tuple<decimal, string, string>(-decimal.Parse(product[0]), product[1], product[2]));
            }

            List<Tuple<decimal, string, string>> productsLeft = new List<Tuple<decimal, string, string>>();

            for (int i = 0; i < recipe.Count; i++)
            {
                if (productsLeft.Count == 0)
                {
                    productsLeft.Add(new Tuple<decimal, string, string>(recipe[i].Item1, recipe[i].Item2, recipe[i].Item3));
                    continue;
                }
                for (int j = 0; j < productsLeft.Count; j++)
                {
                    if (recipe[i].Item3.ToLowerInvariant() == productsLeft[j].Item3.ToLowerInvariant())
                    {
                        productsLeft[j] = new Tuple<decimal, string, string>(AddQuantities(recipe[i],productsLeft[j]), productsLeft[j].Item2, productsLeft[j].Item3);
                    }
                    else
                    {
                        productsLeft.Add(new Tuple<decimal, string, string>(recipe[i].Item1, recipe[i].Item2, recipe[i].Item3));
                        break;
                    }
                }
            }

            for (int i = 0; i < used.Count; i++)
            {
                for (int j = 0; j < productsLeft.Count; j++)
                {
                    if (used[i].Item3.ToLowerInvariant() == productsLeft[j].Item3.ToLowerInvariant())
                    {
                        productsLeft[j] = new Tuple<decimal, string, string>(AddQuantities(used[i],productsLeft[j]), productsLeft[j].Item2, productsLeft[j].Item3);
                    }
                }
            }

            productsLeft = productsLeft.Where(x => x.Item1 > 0).ToList();

            foreach (var product in productsLeft)
            {
                Console.WriteLine("{0:F2}:{1}:{2}", product.Item1, product.Item2, product.Item3);
            }
        }

        static decimal AddQuantities(Tuple<decimal, string, string> first, Tuple<decimal, string, string> second)
        {
            return ConvertMlsToAny(ConvertAnyToMls(first.Item1, first.Item2) + ConvertAnyToMls(second.Item1, second.Item2), second.Item2);
        }

        static decimal ConvertAnyToMls(decimal quantity, string name)
        {
            decimal mls = 0;
            decimal weightInMls = 0;
            switch (name)
            {
                case "mls":
                case "milliliters":
                    weightInMls = 1;
                    break;
                case "teaspoons":
                case "tsps":
                    weightInMls = 5;
                    break;
                case "tablespoons":
                case "tbsps":
                    weightInMls = 15;
                    break;
                case "fluid ounces":
                case "fl ozs":
                    weightInMls = 30;
                    break;
                case "cups":
                    weightInMls = 240;
                    break;
                case "pints":
                case "pts":
                    weightInMls = 480;
                    break;
                case "quarts":
                case "qts":
                    weightInMls = 960;
                    break;
                case "liters":
                case "ls":
                    weightInMls = 1000;
                    break;
                case "gallons":
                case "gals":
                    weightInMls = 3840;
                    break;
                default:
                    Console.WriteLine("Error in quantities calculation!");
                    break;
            }

            mls = quantity * weightInMls;
            return mls;
        }

        static decimal ConvertMlsToAny(decimal mls, string name)
        {
            decimal quantity = 0;
            decimal weightInMls = 0;
            switch (name)
            {
                case "mls":
                case "milliliters":
                    weightInMls = 1;
                    break;
                case "teaspoons":
                case "tsps":
                    weightInMls = 5;
                    break;
                case "tablespoons":
                case "tbsps":
                    weightInMls = 15;
                    break;
                case "fluid ounces":
                case "fl ozs":
                    weightInMls = 30;
                    break;
                case "cups":
                    weightInMls = 240;
                    break;
                case "pints":
                case "pts":
                    weightInMls = 480;
                    break;
                case "quarts":
                case "qts":
                    weightInMls = 960;
                    break;
                case "liters":
                case "ls":
                    weightInMls = 1000;
                    break;
                case "gallons":
                case "gals":
                    weightInMls = 3840;
                    break;
                default:
                    Console.WriteLine("Error in quantities calculation!");
                    break;
            }

            quantity = mls / weightInMls;
            return quantity;
        }
    }
}
