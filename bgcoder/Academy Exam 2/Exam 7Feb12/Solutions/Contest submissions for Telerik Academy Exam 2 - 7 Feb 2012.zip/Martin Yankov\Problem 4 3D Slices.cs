using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3DSlices
{
    class Program
    {
        static int[, ,] GetCuboidValues()
        {
            int[, ,] cuboid;
            int[] size = new int[3];
            string[] input;

            input = Console.ReadLine().Split(' ');

            for (int index = 0; index < input.Length; index++)
            {
                size[index] = int.Parse(input[index]);
            }

            cuboid = new int[size[0], size[1], size[2]];

            for (int line = 0; line < size[1]; line++)
            {
                input = Console.ReadLine().Split(' ');
                int planeCounter = 0;
                int colCounter = 0;

                for (int index = 0; index < input.Length; index++)
                {
                    if (input[index] == "|")
                    {
                        colCounter = 0;
                        planeCounter++;
                        continue;
                    }

                    cuboid[colCounter, line, planeCounter] = int.Parse(input[index]);
                    colCounter++;
                }
            }

            return cuboid;
        }

        static int CalculateSumOfCuboid(int[,,] cuboid)
        {
            int sum = 0;
            //int len0 = cuboid.GetLength(0);
            //int len2 = cuboid.GetLength(2);
            //int len1 = cuboid.GetLength(1);

            for (int dindex = 0; dindex < cuboid.GetLength(2); dindex++)
            {
                for (int hindex = 0; hindex < cuboid.GetLength(1); hindex++)
                {
                    for (int windex = 0; windex < cuboid.GetLength(0); windex++)
                    {
                        sum += cuboid[windex, hindex, dindex];
                    }
                }
            }

            return sum;
        }

        static void Main(string[] args)
        {
            int[, ,] cuboid = GetCuboidValues();
            int wholeSum = CalculateSumOfCuboid(cuboid);
            //int[,,] cuboid = new int[4,2,3];
            int splitCounter = 0;
            int sum = 0;
            int len0 = cuboid.GetLength(0);
            int len2 = cuboid.GetLength(2);
            int len1 = cuboid.GetLength(1);

            //spliting by width
            for (int separator = 1; separator < len0; separator++)
            {
                for (int dindex = 0; dindex < len2; dindex++)
                {
                    for (int hindex = 0; hindex < len1; hindex++)
                    {
                        for (int windex1 = 0; windex1 < separator; windex1++)
                        {
                            sum += cuboid[windex1, hindex, dindex];
                        }
                    }
                }

                if (sum == wholeSum - sum)
                {
                    splitCounter++;
                }

                sum = 0;
            }

            //spliting by height
            for (int separator = 1; separator < len1; separator++)
            {
                for (int dindex = 0; dindex < len2; dindex++)
                {
                    for (int windex = 0; windex < len0; windex++)
                    {
                        for (int hindex1 = 0; hindex1 < separator; hindex1++)
                        {
                            sum += cuboid[windex, hindex1, dindex];
                        }
                    }
                }

                if (sum == wholeSum - sum)
                {
                    splitCounter++;
                }

                sum = 0;
            }

            //spliting by depth
            for (int separator = 1; separator < len2; separator++)
            {
                for (int windex = 0; windex < len0; windex++)
                {
                    for (int hindex = 0; hindex < len1; hindex++)
                    {
                        for (int dindex1 = 0; dindex1 < separator; dindex1++)
                        {
                            sum += cuboid[windex, hindex, dindex1];
                        }
                    }
                }

                if (sum == wholeSum - sum)
                {
                    splitCounter++;
                }

                sum = 0;
            }

            Console.WriteLine(splitCounter);

        }
    }
}
