using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.BasicLanguage
{
    class Program
    {
        static void Main(string[] args)
        {            
            StringBuilder sb = new StringBuilder();
            //int i = 0;                                //Read the text
            while (true)
            {
                string tempText = Console.ReadLine();
                if (tempText.IndexOf("EXIT") != -1) //check cases when exit is in print statement !!
                {                   

                    sb.Append(tempText); //add line breaks only if in print()
                    break;
                }
                else
                {
                    if (tempText == "")
                    {
                        tempText = "\n";
                    }
                    sb.Append("\n");
                    sb.Append(tempText);
                }
            }
            string allText = sb.ToString();
                                                        //Split the text in string[] - the last is EXIT;
            string[] allCommands = allText.Split(';');
            for (int f = 0; f < allCommands.Length - 2; f++) 
            {              
                
                //---------------- Print Function ----------------------------
                int printStart = allCommands[f].IndexOf("PRINT", 0);
                printStart = allCommands[f].IndexOf("(", printStart) + 1; // Can be optimized !!!
                int printEnd = allCommands[f].IndexOf(")", printStart);
                string myMessage = allCommands[f].Substring(printStart, printEnd - printStart);

                //---------------- For Loop ----------------------------------
                int forStart = allCommands[f].IndexOf("FOR", 0);
                int forEnd = 0; //Not necessary ot initialize
                if (forStart != -1)
                {
                    forEnd = allCommands[f].IndexOf(")", forStart);
                }
                int forParam = 1;
                while ((forStart != -1) & forStart < printStart)
                {
                    string forState = allCommands[f].Substring(forStart, forEnd - forStart + 1);
                    forParam = forParam * ForFunction(forState);

                    forStart = allCommands[f].IndexOf("FOR", forEnd + 1);
                    if (forStart != -1)
                    {
                        forEnd = allCommands[f].IndexOf(")", forStart);
                    }
                }             
                                
                ExecuteProgram(forParam, myMessage);                
            }
            Console.Write("\n");
            Console.Write("\n");
        }

        static int ForFunction(string myText)
        {            
            int startIndex = myText.IndexOf("(") + 1;
            int endIndex = myText.IndexOf(")") - 1;

            if (myText.IndexOf(",") != -1)  //For with two parameters
            {
                int endIndex2 = myText.IndexOf(",") - 1;

                string myNum = myText.Substring(startIndex, endIndex2 - startIndex + 1).Trim();
                int param1 = int.Parse(myNum);

                endIndex2 = endIndex2 + 2;
                myNum = myText.Substring(endIndex2, endIndex - endIndex2 + 1).Trim();
                int param2 = int.Parse(myNum);

                return (param2 - param1 + 1);
            }
            else                            //For with one parameter
            {
                string myNum = myText.Substring(startIndex, endIndex - startIndex + 1).Trim();
                int param1 = int.Parse(myNum);
                return param1;
            }                              
        }

        static void ExecuteProgram(int i, string myMessage)
        {            
            for (int g = 1; g <= i; g++)
            {
                Console.Write(myMessage);
            }
        }
    }
}
