using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_1
{
    class Program
    {
        public static void Print(int openBracketIndex, int closedBracketIndex, string[] newText, int index)
        {
            int j = openBracketIndex + 1;
            while (j < closedBracketIndex)
            {
                Console.Write(newText[index][j]);
                j++;
            }
        }

        public static int CountsFors(string[] text, int index)
        {
            int indexF = text[index].IndexOf("F");
            int counter = 0;
            while (indexF != -1)
            {
                counter++;
                indexF = text[index].IndexOf("F", indexF + 1);
            }
            return counter;
        }
        public static int FindsForCounter(string[] fors, int index)
        {
            int comaIndex = fors[index].IndexOf(",");
            int openBracket = fors[index].IndexOf("(");
            int number = 0;
            if (comaIndex < 0)
            {
                string interval = fors[index].Substring(openBracket + 1).Trim();
                if (interval[interval.Length - 1] == ' ')
                {
                    interval.TrimEnd();
                }
                if (interval[0] == ' ')
                {
                    interval.TrimStart();
                }
                number = int.Parse(interval);
            }
            else
            {
                string firstNum = fors[index].Substring(openBracket + 1, comaIndex - openBracket - 1).Trim();
                number = int.Parse(firstNum);
                string secondNum = fors[index].Substring(comaIndex + 1).Trim();
                int num2 = int.Parse(secondNum);
                number = num2 - number + 1;
            }
            return number;
        }

        public static int FindSingleForCounter(string[] text, int index)
        {
            int comaIndex = text[index].IndexOf(",");
            int openBracket = text[index].IndexOf("(");
            int closedBracket = text[index].IndexOf(")");
            int number = 0;
            if (comaIndex < 0)
            {
                string interval = text[index].Substring(openBracket + 1, closedBracket - openBracket - 1).Trim();
                number = int.Parse(interval);
            }
            else
            {
                string firstNum = text[index].Substring(openBracket + 1, comaIndex - openBracket - 1).Trim();
                number = int.Parse(firstNum);
                string secondNum = text[index].Substring(comaIndex + 1, closedBracket - comaIndex - 1).Trim();
                int num2 = int.Parse(secondNum);
                number = num2 - number + 1;
            }
            return number;
        }
        static void Main(string[] args)
        {
            string line;
            string textBL = string.Empty;
            do
            {
                line = Console.ReadLine();
                textBL = textBL + line;
            } while (line != "EXIT;" && line[line.Length - 2] != 'T');
            char[] separators = new char[] { ';' };
            string[] text = textBL.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < text.Length - 1; i++)
            {
                int j = 0;
                while (text[i][j] == ' ')
                {
                    j++;
                }
                char symbol = text[i][j];
                int openBracketIndex = text[i].IndexOf("(");
                int closedBracketIndex = text[i].IndexOf(")");
                if (symbol == 'P')
                {
                    Print(openBracketIndex, closedBracketIndex, text, i);
                }
                else
                {
                    int counter = CountsFors(text, i);
                    int loopsCounter = 1;
                    if (counter > 1)
                    {
                        char[] separator = new char[] { ')' };
                        string[] fors = text[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);
                        for (int index = 0; index < fors.Length; index++)
                        {
                            if (fors[index][0] != 'P')
                            {
                                loopsCounter = loopsCounter * FindsForCounter(fors, index);
                            }
                        }
                        int printIndex = text[i].IndexOf("P");
                        openBracketIndex = text[i].IndexOf("(", printIndex);
                        closedBracketIndex = text[i].IndexOf(")", printIndex);
                        for (int index = 0; index < loopsCounter; index++)
                        {
                            Print(openBracketIndex, closedBracketIndex, text, i);  
                        }
                    }
                    else
                    {
                        loopsCounter = loopsCounter * FindSingleForCounter(text, i);
                        int printIndex = text[i].IndexOf("P");
                        openBracketIndex = text[i].IndexOf("(", printIndex);
                        closedBracketIndex = text[i].IndexOf(")", printIndex);
                        for (int index = 0; index < loopsCounter; index++)
                        {
                            Print(openBracketIndex, closedBracketIndex, text, i);
                        }
                    }

                }

            }
        }
    }
}
