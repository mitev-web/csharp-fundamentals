using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessageInABottle
{
    class MessageInABottle
    {
       

        static void Main(string[] args)
        {

            string secretMessage = Console.ReadLine();
            string cipher = Console.ReadLine();

            StringBuilder letters = new StringBuilder();
            List<int> digits = new List<int>();
            StringBuilder tempDigit = new StringBuilder();
            int k = 0;
            int variations = 0;
            int b = 0;
            int messNumber = 0;
            bool found=false;
            do
            {
                if (k == cipher.Length-1) found = true;
                if (cipher[k] >= 'A' && cipher[k] <= 'Z') letters.Append(cipher[k]);
                if(found==false) k++;
               
                if ((cipher[k]-'0') >= 1 && (cipher[k]-'0') <= 9 && found==false)
                {

                    tempDigit.Append(cipher[k]);

                            
                }
                else if (cipher[k] >= 'A' && cipher[k] <= 'Z' || k==cipher.Length-1)
                {

                    digits.Add(int.Parse(tempDigit.ToString()));
                    tempDigit.Clear();
                }

            } while (found != true);
            
        
            

            //calculate

            List<int> comb = new List<int>();
            StringBuilder temp = new StringBuilder();
            int g = 0;
            int raise = secretMessage.Length;
            int error=0;
            if(raise%2==0) error=1;
            else error=0;

            do
            {
                
                for (int i = g; i < raise; i++)
                {
                   

                        temp.Append(secretMessage[i]);
                    comb.Add(int.Parse(temp.ToString()));

                    variations++;
                       
                      
                    }
                  
                    temp.Clear();
                    
                  
                    if (g == secretMessage.Length - error)
                    {
                        g = 0;
                        g+=2;   
                        raise--;
                    }
                    g++;
                    
                     
            } while (raise != 1);
            int counter=0;
         
            comb.Sort();
     
            int yes = 0;
            StringBuilder tmp = new StringBuilder();

            
           
                for (int x = 0; x < digits.Count; x++)
                {
                    if (digits[x] < (int.Parse(secretMessage))) counter = -1;
                }
                if (counter == 0) Console.WriteLine(0);


                if (digits.Count == 1) Console.WriteLine(1);
                if (digits.Count == 2) Console.WriteLine(1);
    
                if (digits.Count == 3) Console.WriteLine(3);
            
           
        }

       
    }
}
