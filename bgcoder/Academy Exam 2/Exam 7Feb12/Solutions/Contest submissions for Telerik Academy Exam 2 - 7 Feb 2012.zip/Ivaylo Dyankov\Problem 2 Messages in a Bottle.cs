using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MessageInBottle
{
    class Program
    {
        static void GetAndSortLettersCode(string[] arrayOfLetters, string[] arrayOfCodes, Dictionary<string, string> listDict)
        {
            for (int i = 0; i < arrayOfLetters.Length; i++)
            {
                if (arrayOfLetters[i] != null)
                {
                    listDict.Add(arrayOfLetters[i] ,arrayOfCodes[i + 1]);
                }
            }

        }

        static void Main(string[] args)
        {
            string message = Console.ReadLine();
            string cipher = Console.ReadLine();
            string[] stringSeparators = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };

            string[] arrayOfLetters = cipher.Split(stringSeparators , StringSplitOptions.RemoveEmptyEntries);
            string[] arrayOfCodes = Regex.Split(cipher, "[A-Z]");


            Dictionary<string, string> listDict = new Dictionary<string, string>();

            GetAndSortLettersCode(arrayOfLetters, arrayOfCodes, listDict);
            Array.Sort(arrayOfLetters);

            List<string> outputStrings = new List<string>();

            int startStringComparison = 0;
            int strCounter = 0;

            foreach (string str in arrayOfLetters)
            {
                StringBuilder localSB = new StringBuilder();

                while (message.IndexOf(listDict[str], startStringComparison) == startStringComparison)
                {
                    localSB.Append(str);
                    startStringComparison += listDict[str].Length;

                    for (int i = 0; i < arrayOfLetters.Length; i++)
                    {
                        while (message.IndexOf(listDict[arrayOfLetters[i]], startStringComparison) == startStringComparison)
                        {
                            localSB.Append(arrayOfLetters[i]);
                            startStringComparison += listDict[arrayOfLetters[i]].Length;
                        }

                        if (startStringComparison == message.Length)
                        {
                            outputStrings.Add(localSB.ToString());
                            strCounter++;
                        }
                    }
                }

                startStringComparison = 0;
            }

            Console.WriteLine(strCounter);
            foreach (string str in outputStrings)
            {
                Console.WriteLine(str);
            }
        }
    }
}
