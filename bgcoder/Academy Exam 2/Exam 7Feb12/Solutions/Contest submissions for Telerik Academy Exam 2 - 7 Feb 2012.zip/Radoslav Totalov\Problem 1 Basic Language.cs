using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;



namespace BasicLanguage
{
    class BasicLanguage
    {


        public static void Main()
        {
                   
            
            StringBuilder code = new StringBuilder();
            //StringBuilder a = new StringBuilder();
            //int[] numbers = new int[2];
                    //numbers[1] = int.MinValue;
            //StringBuilder b = new StringBuilder();


            bool inForLoop = false;
            //bool singleFor = false;
            bool inPrint = false;
            bool inBrackets = false;
            bool inExit = false;

            string line = Console.ReadLine();
            //line = Console.ReadLine();
            for (int j = 0; j < line.Length; j++)
            {
                if (line[j] == 'P')
                {
                    inPrint = true;
                }
                if (inPrint)
                {

                    if (line[j] == '(')
                    {
                       
                        inBrackets = true;
                        continue;

                    }
                    if (inPrint && inBrackets)
                    {
                        if (line[j] == ')')
                        {
                          
                            inBrackets = false;
                            continue;
                        }
                        code.Append(line[j]);
                    }


                }
                if (line[j] == 'F')
                {
                    inForLoop = true;
                }
                if (inForLoop&&!inPrint)
                {
                    if (line[j] == '(')
                    {
                        inBrackets = true;
                        continue;
                    }
                    if (inForLoop && inBrackets)
                    {
                        if (line[j] == ')')
                        {

                            inBrackets = false;
                            continue;
                        }
                        //a.Append(line[j]);  
                        
                    }

                }
                if (inExit)
                {
                    if (line[j] == 'E')
                    {
                        j++;
                        continue;
                    }
                    if (line[j] == 'X')
                    {
                        j++;
                        continue;
                    }
                    if (line[j] == 'I')
                    {
                        j++;
                        continue;
                    }
                    if (line[j] == 'T')
                    {
                        j++;
                        continue;
                    }


                }
                if (line[j] == ';')
                {

                    j++;
                    continue;
                }

                //code.Append(line[j]);
            }
            //a = new StringBuilder();

            
            StringReader sr = new StringReader(code.ToString());
           
            string lineToPrint = null;
            while ((lineToPrint = sr.ReadLine()) != null)
            {
                if (!string.IsNullOrWhiteSpace(lineToPrint))
                {
                    Console.WriteLine(lineToPrint);

                }
            }
            
        }

    }
}
