using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{

    class Program
    {
        static  string variant = null;
        public static int cost = 0;
        

        public static string CheckCombination(char[] vector, char[] word)
        {
            char[] temp = new char[vector.Length];
            for (int i = 0; i < vector.Length; i++)
            {
                temp[i] = vector[i];
            }
            Array.Sort(temp);
            Array.Sort(word);


            if (new string(temp) == new string(word))
            {
                return new string(vector);
            }

            return "none";
            
        }

        public static void checkCost(string sentence, string word)
        {
            
            int index = sentence.IndexOf(variant);            
            for (int i = 0; i < word.Length; i++)
            {
                if (sentence[i+index]!=word[i])
                {
                    cost = cost + 1;
                }
            }

        }
        
        
        public static void Gen01(int index, char[] vector,string word, string sentence)
        {
            if (index == -1)
            {
                
                variant = CheckCombination(vector, word.ToCharArray());
                if (variant != "none" && sentence.IndexOf(variant)!=-1)
                {
                    checkCost(sentence, word);
                }
            }

            else
                for (int i = 0; i < word.Length; i++)
                {
                    vector[index] = word[i];
                    Gen01(index - 1, vector, word, sentence);
                }
        }


        public static void Main(string[] args)
        {

            //int size = 3;
            //string word = "one";
            //string sentence = "neotowheret";
            //char[] vector = new char[size];
            //Gen01(size - 1, vector,word,sentence);


            string sentence = Console.ReadLine();
            string wordsLine = Console.ReadLine();

            string[] words = wordsLine.Split(new char[] { '"', ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string word in words)
            {

                char[] vector = new char[word.Length];
                Gen01(word.Length - 1, vector, word, sentence);
            }

  

            Console.WriteLine(cost);

        }
    }
}
