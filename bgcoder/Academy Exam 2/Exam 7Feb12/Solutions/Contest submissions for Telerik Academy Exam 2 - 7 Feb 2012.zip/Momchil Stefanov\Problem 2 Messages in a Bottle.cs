using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.MessagesInABottle
{
    class MessagesInABottle
    {
        static List<string> possibleMessages = new List<string>();
        static char[] current = new char[100];
        static string secretCode;

        static void Main(string[] args)
        {
            secretCode = Console.ReadLine();
            string cipher = Console.ReadLine();

            FindPossibleMessages(secretCode, SplitAndSortCipher(cipher));

            Console.WriteLine(possibleMessages.Count);
            if (possibleMessages.Count > 0)
            {
                foreach (var message in possibleMessages)
                {
                    Console.WriteLine(message);
                }
            }
        }

        static void FindPossibleMessages(string code, IEnumerable<KeyValuePair<char, string>> dictionary)
        {
            if (code.Length == 0)
            {
                possibleMessages.Add(new string(current.Where(x => Char.IsLetter(x)).ToArray()));
                return;
            }

            foreach (var pair in dictionary)
            {
                if (code.IndexOf(pair.Value) == 0)
                {
                    current[secretCode.Length - code.Length] = pair.Key;
                    FindPossibleMessages(code.Substring(pair.Value.Length), dictionary);
                }
                current[secretCode.Length - code.Length] = Char.MinValue;
            }
        }

        static IEnumerable<KeyValuePair<char, string>> SplitAndSortCipher(string cipher)
        {
            char letter = cipher[0];
            IDictionary<char, string> cipherDictionary = new Dictionary<char, string>();
            StringBuilder number = new StringBuilder();
            for (int i = 1; i < cipher.Length; i++)
            {
                if (i < cipher.Length - 1)
                {
                    if (Char.IsLetter(cipher[i]))
                    {
                        cipherDictionary[letter] = number.ToString();
                        number.Clear();
                        letter = cipher[i];
                    }
                    else
                    {
                        number.Append(cipher[i]);
                    }
                }
                else
                {
                    number.Append(cipher[i]);
                    cipherDictionary[letter] = number.ToString();
                }
            }

            return cipherDictionary.OrderBy(x => x.Key);
        }
    }
}
