using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace TestCompetition2
{
    class Program
    {
        //static string[] separatorFor = { "FOR" };
        //static string[] separatorPrint = { "PRINT", "(", ")" };
  
        static void Main(string[] args)
        {
            // string text = "FOR  blabla (  1  ,   5   ) PRINT (ha)sdfsd)      exit;exit;FOR(2)FOR(2,3)PRINT(xi);PRINT(i);EXIT; PRINT(error);";
            StringBuilder sb2 = new StringBuilder();
            string text;
            while (true)
            {
                text = Console.ReadLine();
                if (text.IndexOf("EXIT") > -1)
                {
                    break;
                }
                sb2.Append(text);
            }
            text = sb2.ToString();
            StringBuilder sb = new StringBuilder();
            string[] inputLines = text.Split(';');
  
  
            //List<int> countOfCicles = new List<int>();
            //List<int> loops = new List<int>();
  
            for (int i = 0; i < inputLines.Length; i++)
            {
                //if (inputLines[i].IndexOf("EXIT") > -1)
                //{
                //    break;
                //}
                int indexPrint = inputLines[i].IndexOf("PRINT");
                int indexFor = inputLines[i].IndexOf("FOR");
                if (indexPrint < 0)
                {
                    continue;
                }
                if (indexFor < 0)
                {
  
                    string toPrint = inputLines[i].Remove(0, inputLines[i].IndexOf('(') + 1);
                    toPrint = toPrint.Remove(toPrint.IndexOf(')'));
                    sb.Append(toPrint);
                    continue;
  
                }
                else
                {
                    ForLine(inputLines[i], sb);
                }
  
            }
            Console.WriteLine(sb.ToString());
  
        }
        static void ForLine(string text, StringBuilder sb)
        {
            char[] ch = { ',' };
            List<int> loop = new List<int>();
  
            string[] separator = { "PRINT" };
            string[] separator2 = { "FOR" };
            string[] separatesText = text.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            separatesText[0] = separatesText[0].Replace(" ", "");
            string[] loopsStrings = separatesText[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);
            List<int> loopValues = new List<int>();
  
            for (int i = 0; i < loopsStrings.Length; i++)
            {
                string loopValue = loopsStrings[i].Remove(0, loopsStrings[i].IndexOf('(') + 1);
                loopValue = loopValue.Remove(loopValue.IndexOf(')'));
                int b;
                bool a = int.TryParse(loopValue, out  b);
                if (a)
                {
                    loopValues.Add(b);
                }
                else
                {
  
                    string[] splitLoopValues = loopValue.Split(ch, StringSplitOptions.RemoveEmptyEntries);
                    int d = int.Parse(splitLoopValues[0]);
                    int c = int.Parse(splitLoopValues[1]);
                    int res = c - d + 1;
                    loopValues.Add(res);
                }
            }
  
  
  
            string toPrint = separatesText[1].Remove(0, separatesText[1].IndexOf('(') + 1);
            toPrint = toPrint.Remove(toPrint.IndexOf(')'));
  
            printingRows(loopValues, toPrint, 0, sb);
  
  
        }
  
        static void printingRows(List<int> loopValues, string toPrint, int start, StringBuilder sb)
        {
  
            if (start == loopValues.Count)
            {
                sb.Append(toPrint);
                return;
            }
            for (int i = 0; i < loopValues[start]; i++)
            {
                printingRows(loopValues, toPrint, start + 1, sb);
            }
        }
    }
}