using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace _3.Cooking
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            string[,] relationship = {
                                        {"1","tbsps","3","tsps"},
                                        {"1","ls","1000","mls"},
                                        {"1","cups","8","fl ozs"},
                                        {"1","tsps","5","mls"},
                                        {"1","gals","4","qts"},
                                        {"1","pts","2","cups"},
                                        {"1","qts","2","pts"},
                                        {"1","cups","48","tsps"}
                                    };

            int receptNumber = int.Parse(Console.ReadLine());
            string[,] recept = GetProduct(receptNumber);

            int krissiReceptNumber = int.Parse(Console.ReadLine());
            string[,] krissi = GetProduct(krissiReceptNumber);

          

            CorectRecept(receptNumber, recept, relationship);

            CorectKrissi(krissiReceptNumber, krissi, relationship);

            for (int rec = 0; rec < recept.GetLength(1); rec++)
            {
                if (recept[2, rec] != null)
                {
                    bool find = false;
                    for (int i = 0; i < krissi.GetLength(1); i++)
                    {
                        if (krissi[2, i] != null)
                        {
                            if (recept[2, rec].Equals(krissi[2, i], StringComparison.OrdinalIgnoreCase))
                            {
                                find = true;
                                krissi[2, i] = null;
                                if (recept[1, rec].Equals(krissi[1, i], StringComparison.OrdinalIgnoreCase))
                                {
                                    double newQuant = double.Parse(recept[0, rec]) - double.Parse(krissi[0, i]);
                                    recept[0, rec] = newQuant.ToString();
                                }
                                else
                                {
                                    bool findMeas = false;
                                    for (int rel = 0; rel < relationship.GetLength(0); rel++)
                                    {
                                        if (relationship[rel, 1].Equals(recept[1, rec]) && relationship[rel, 3].Equals(krissi[1, i]))
                                        {
                                            findMeas = true;
                                            double newResult = double.Parse(recept[0, rec]) - double.Parse(krissi[0, i]) / double.Parse(relationship[rel, 2]);
                                            recept[0, rec] = newResult.ToString();
                                            break;
                                        }
                                    }
                                    if (!findMeas)
                                    {
                                        for (int rel = 0; rel < relationship.GetLength(0); rel++)
                                        {
                                            if (relationship[rel, 3].Equals(recept[1, rec]) && relationship[rel, 1].Equals(krissi[1, i]))
                                            {
                                                double newResult = double.Parse(recept[0, rec]) - double.Parse(relationship[rel, 2]) * double.Parse(krissi[0, i]);
                                                recept[i, rec] = newResult.ToString();
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (double.Parse(recept[0, rec])>0)
                                {
                                    Console.WriteLine("{0}:{1}:{2}", double.Parse(recept[0, rec]).ToString("0.00"), recept[1, rec], recept[2, rec]);
                                }
                            }
                        }
                    }
                    if (!find)
                    {
                        Console.WriteLine("{0}:{1}:{2}", double.Parse(recept[0, rec]).ToString("0.00"), recept[1, rec], recept[2, rec]);
                    }
                }

            }




        }

        private static void CorectKrissi(int krissiReceptNumber, string[,] krissi, string[,] relationship)
        {
            for (int i = 0; i < krissiReceptNumber; i++)
            {
                if (krissi[2, i] != null)
                {
                    for (int j = i + 1; j < krissiReceptNumber - 1; j++)
                    {
                        if (krissi[2, j] != null)
                        {
                            if (krissi[2, i].Equals(krissi[2, j], StringComparison.OrdinalIgnoreCase))
                            {
                                if (krissi[1, i].Equals(krissi[1, j], StringComparison.OrdinalIgnoreCase))
                                {
                                    double newQuant = double.Parse(krissi[0, i]) + double.Parse(krissi[0, j]);
                                    krissi[0, i] = newQuant.ToString();
                                }
                                else
                                {
                                    bool find = false;
                                    for (int rel = 0; rel < relationship.GetLength(0); rel++)
                                    {
                                        if (relationship[rel, 1].Equals(krissi[1, j]) && relationship[rel, 3].Equals(krissi[1, i]))
                                        {
                                            find = true;
                                            double newResult = double.Parse(krissi[0, j]) * double.Parse(relationship[rel, 2]) + double.Parse(krissi[0, i]);
                                            krissi[0, i] = newResult.ToString();
                                            break;
                                        }
                                    }
                                    if (!find)
                                    {
                                        for (int rel = 0; rel < relationship.GetLength(0); rel++)
                                        {
                                            if (relationship[rel, 3].Equals(krissi[1, j]) && relationship[rel, 1].Equals(krissi[1, i]))
                                            {
                                                double newResult = double.Parse(krissi[0, j]) / double.Parse(relationship[rel, 2]) + double.Parse(krissi[0, i]);
                                                krissi[0, i] = newResult.ToString();
                                                break;
                                            }
                                        }
                                    }
                                }
                                krissi[2, j] = null;
                            }
                        }
                    }
                }
            }
        }

        private static void CorectRecept(int receptNumber, string[,] recept, string[,] relationship)
        {
            for (int i = 0; i < receptNumber; i++)
            {
                if (recept[2, i] != null)
                {
                    for (int j = i + 1; j < receptNumber - 1; j++)
                    {
                        if (recept[2, j] != null)
                        {
                            if (recept[2, i].Equals(recept[2, j], StringComparison.OrdinalIgnoreCase))
                            {
                                if (recept[1, i].Equals(recept[1, j], StringComparison.OrdinalIgnoreCase))
                                {
                                    double newQuant = double.Parse(recept[0, i]) + double.Parse(recept[0, j]);
                                    recept[0, i] = newQuant.ToString();
                                }
                                else
                                {
                                    bool find = false;
                                    for (int rel = 0; rel < relationship.GetLength(0); rel++)
                                    {
                                        if (relationship[rel, 1].Equals(recept[1, j]) && relationship[rel, 3].Equals(recept[1, i]))
                                        {
                                            find = true;
                                            double newResult = double.Parse(recept[0, j]) * double.Parse(relationship[rel, 2]) + double.Parse(recept[0, i]);
                                            recept[0, i] = newResult.ToString();
                                            break;
                                        }
                                    }
                                    if (!find)
                                    {
                                        for (int rel = 0; rel < relationship.GetLength(0); rel++)
                                        {
                                            if (relationship[rel, 3].Equals(recept[1, j]) && relationship[rel, 1].Equals(recept[1, i]))
                                            {
                                                double newResult = double.Parse(recept[0, j]) / double.Parse(relationship[rel, 2]) + double.Parse(recept[0, i]);
                                                recept[0, i] = newResult.ToString();
                                                break;
                                            }
                                        }
                                    }
                                }
                                recept[2, j] = null;
                            }
                        }
                    }
                }
            }
        }
  
        private static string[,] GetProduct(int receptNumber)
        {
            string currentInserRow;
            string[,] recept = new string[3, receptNumber];
            int indexSepar = 0;
            int indexSepar2 = 0;
            for (int i = 0; i < receptNumber; i++)
            {
                currentInserRow = Console.ReadLine();
                indexSepar = currentInserRow.IndexOf(':');
                recept[0, i] = currentInserRow.Substring(0, indexSepar);
                indexSepar2 = currentInserRow.IndexOf(':', indexSepar+1);
                recept[1, i] = currentInserRow.Substring(indexSepar+1, indexSepar2-indexSepar-1);
                recept[2, i] = currentInserRow.Substring(indexSepar2 + 1);
            }
            return recept;
        }
    }
}
