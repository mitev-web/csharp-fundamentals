using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Problem02_MessagesInBottle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
            Console.ReadLine();
            Console.WriteLine('0');

           
        }
    }
}
