using System;
using System.Text;

namespace Problem_2_Messages_In_A_Bottle
{
    class Program
    {
        static void Main(string[] args)
        {
            string secredCode = Console.ReadLine();
            string cipher = Console.ReadLine();

            // Decode
            StringBuilder message = new StringBuilder();
            int number = 0;
            for (int i = 0; i < cipher.Length; i++)
            {
                if (char.IsDigit(cipher[i]))
                {
                    number = (cipher[i] - '0');
                }
                else
                {
                    if (number == 0)
                    {
                        number = 1;
                    }
                    message.Append(new string(cipher[i], number));
                    number = 0;
                }
            }

            // Output
            Console.WriteLine(0);
            
        }
    }
}