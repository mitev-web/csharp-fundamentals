using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task4
{
    class Program
    {
        public static int ans = 0;

        static void Main(string[] args)
        {
            string WandHandD = Console.ReadLine();
            string[] parameters = WandHandD.Split(' ');
            int W = int.Parse(parameters[0]);
            int H = int.Parse(parameters[1]);
            int D = int.Parse(parameters[2]);
            string[] inputLines = new string[H];
            for (int i = 0; i < H; i++)
            {
                inputLines[i] = Console.ReadLine();
            }
            int[, ,] cuboid = new int[W, H, D];
            int counter = 0;
            long sum = 0;
            for (int d = 0; d < D; d++)
            {
                for (int h = 0; h < H; h++)
                {
                    string[] splittedLine = inputLines[h].Split(new string[] { " ", "|" }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < W; w++)
                    {
                        cuboid[w, h, d] = int.Parse(splittedLine[w + counter]);
                        sum += (long)(cuboid[w, h, d]);
                    }
                }
                counter += W;
            }
            
            SplitByWidth(cuboid, W, H, D, sum);
            SplitByHeigth(cuboid, W, H, D, sum);
            SplitByDepth(cuboid, W, H, D, sum);
            Console.WriteLine(ans);
            /*
4 2 3
3 4 1 9 | 1 2 3 8 | 1 5 6 7
1 2 1 9 | 5 1 3 9 | 5 3 3 8
            */

        }
        public static void SplitByDepth(int[, ,] cuboid, int W, int H, int D, long sum)
        {
            int splitter = 0;
            long partialSum = 0;
            for (int i = 1; i < D; i++)
            {
                    splitter = i;
                    for (int x = i-1; x < splitter; x++)
                    {
                        for (int y = 0; y < H; y++)
                        {
                            for (int z = 0; z < W; z++)
                            {
                                partialSum += (long)(cuboid[z, y, x]);
                            }

                        }

                    }
                if (partialSum == sum - partialSum)
                {
                    ans++;
                }

            }
        }

        public static void SplitByHeigth(int[, ,] cuboid, int W, int H, int D, long sum)
        {
            int splitter = 0;
            long partialSum = 0;
            for (int i = 1; i < H; i++)
            {
                    splitter = i;
                    for (int x = 0; x < D; x++)
                    {
                        for (int y = i-1; y < splitter; y++)
                        {
                            for (int z = 0; z < W; z++)
                            {
                                partialSum += (long)(cuboid[z, y, x]);
                            }

                        }

                    }
                if (partialSum == sum - partialSum)
                {
                    ans++;
                }

            }
        }

        public static void SplitByWidth(int[, ,] cuboid, int W, int H, int D, long sum)
        {
            int splitter = 0;
            long partialSum = 0;
            for (int i = 1; i < W; i++)
            {
                splitter = i;
                    for (int x = 0; x < D; x++)
                    {
                        for (int y = 0; y < H; y++)
                        {
                            for (int z = i-1; z < splitter; z++)
                            {
                                partialSum += (long)(cuboid[z, y, x]);
                            }

                        }

                    }
                
                if (partialSum == sum - partialSum)
                {
                    ans++;
                }

            }
        }
    }
}
