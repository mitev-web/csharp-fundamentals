using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BasicLanguage
{
    class BasicLanguage
    {
        public static bool FOR(int start, int end, string item)
        {
            if (item.Length < 1)
                return false;
            bool makeSense = true;
            if (item[0] == 'P')
            {
                string output = item.Substring(6, item.Length - 7);
                for (int i = start; i <= end; i++)
                {
                    PRINT(output);
                }
            }
            else
                for (int i = start; i <= end; i++)
                {
                    makeSense = handleFOR(item);
                    if (makeSense == false)
                        return false;
                }
            return true;
        }
        public static bool handleFOR(string item)
        {
            int closingBracket = item.IndexOf(')');
            int comma = item.IndexOf(',');
            int param1 = 1, param2 = 1;
            if (comma == -1 || comma > closingBracket)
            {
                param2 = int.Parse(item.Substring(4, closingBracket - 4));
            }
            else
            {
                param1 = int.Parse(item.Substring(4, comma - 4));
                param2 = int.Parse(item.Substring(comma + 1, closingBracket - comma - 1));
            }
            return FOR(param1, param2,item.Substring(closingBracket+1));
        }
        static void Main(string[] args)
        {
            //StreamReader input = new StreamReader(@"text.txt");
            StringBuilder line = new StringBuilder();
            char ch = ' ';
            bool brackets = false;
            bool forBrackets = false;
            bool endProgram = false;
            while (true)
            {
                //ch = (char)input.Read();
                ch = (char)Console.Read();
                if (ch == ';')
                {
                    if (line.Length > 0)
                    {
                        endProgram = HandleCommand(line);
                        line.Clear();
                        if (endProgram)
                            break;
                    }
                }
                else
                    if (char.IsWhiteSpace(ch) == true)
                    {
                        if (brackets == true)
                            line.Append(ch);
                    }
                    else
                        if (ch == '(')
                        {
                            if (line[line.Length - 1] == 'R')
                                forBrackets = true;
                            else
                                brackets = true;
                            line.Append(ch);
                        }
                        else
                            if (ch == ')')
                            {
                                if (forBrackets == true)
                                    forBrackets = false;
                                else
                                    brackets = false;
                                line.Append(ch);
                            }
                            else
                                line.Append(ch);
            }

            Console.WriteLine();
            //input.Dispose();
        }

        private static bool HandleCommand(StringBuilder line)
        {
            if (line[0] == 'P')
            {
                PRINT(line.ToString(6, line.Length - 7));
            }
            if (line[0] == 'F')
            {
                handleFOR(line.ToString());
            }
            if (line[0] == 'E')
                return true;
            return false;
        }

        private static void PRINT(string item)
        {
            Console.Write(item);
        }
    }
    
}
//FOR           (1  ,   5) PRINT              (ha)    ;
//FOR(2)FOR(2,3)PRINT(xi);PRINT(i);EXIT;
