using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_1_Basic_language
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder inputText = new StringBuilder(100000);

            bool isEndOfCode = false;
            string line = "";
            do
            {
                line = Console.ReadLine();
                

                if (line.LastIndexOf("EXIT") > line.LastIndexOf(')'))
                {
                    isEndOfCode = true;
                }
                inputText.AppendLine(line);



            } while (isEndOfCode == false);



            string[] commands = inputText.ToString().Split(';');
            StringBuilder outputText = new StringBuilder();
            List<int> fors = new List<int>();
            // List<string> printText = new List<string>();
            bool inFor = false;
            bool inPrint = false;
            for (int i = 0; i < commands.Length; i++)
            {
                bool isOpenBracket = false;
                bool isClosedBracket = false;
                string parameters = "";
                int startOfParameters = 0;
                int endOfParameters = 0;
                for (int j = 0; j < commands[i].Length; j++)
                {
                    if (commands[i][j] == 'F' && j + 2 < commands[i].Length && commands[i][j + 1] == 'O' &&
                        commands[i][j + 2] == 'R' && isOpenBracket == false)
                    {
                        inFor = true;
                        j++;
                        continue;

                    }
                    if (commands[i][j] == 'P' && j + 4 < commands[i].Length && commands[i][j + 1] == 'R' &&
                       commands[i][j + 2] == 'I' && commands[i][j + 3] == 'N' && commands[i][j + 4] == 'T' && isOpenBracket == false)
                    {
                        inPrint = true;
                        j = j + 4;
                        continue;

                    }

                    if (commands[i][j] == '(')
                    {
                        isOpenBracket = true;
                        startOfParameters = j;
                        continue;
                    }

                    if (commands[i][j] == ')')
                    {
                        isClosedBracket = true;
                        endOfParameters = j;
                        parameters = commands[i].Substring(startOfParameters + 1, endOfParameters - startOfParameters - 1);
                        if (inFor == true)
                        {
                            string[] splitedParameters = parameters.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                            if (splitedParameters.Length == 1)
                            {
                                fors.Add(int.Parse(splitedParameters[0]));
                            }
                            if (splitedParameters.Length == 2)
                            {
                                fors.Add(int.Parse(splitedParameters[1]) - int.Parse(splitedParameters[0]) + 1);
                            }



                        }
                        if (inPrint == true)
                        {
                            if (fors.Count != 0)
                            {
                                int countFors = 1;
                                for (int k = 0; k < fors.Count; k++)
                                {
                                    countFors = countFors * fors[k];
                                }
                                fors.Clear();
                                for (int m = 0; m < countFors; m++)
                                {
                                    outputText.Append(parameters);
                                }

                            }
                            else
                            {
                                fors.Clear();
                                outputText.Append(parameters);
                            }

                        }
                        inPrint = false;
                        isOpenBracket = false;
                        inFor = false;
                        continue;
                    }

                }

            }
            Console.Write(outputText);
        }
    }
}