using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string line = Environment.NewLine + "FOR (2)FOR ( 1,    5  ) PRINT (HA    )PRINT (lll )PRINT (HAkk    )   ;FOR(2)FOR(2,3)PRINT(xi);PRINT(" + Environment.NewLine + ");EXIT;";
                string line = "";
                            StringBuilder for1 = new StringBuilder();
                StringBuilder for2 = new StringBuilder();
                StringBuilder toPrint = new StringBuilder();
                StringBuilder inPrint = new StringBuilder();
                bool print = false;
                bool isInFor = false;
                bool doubleFor = false;
                char prv = ' ';
                int stop = 1;
                List<int> numberFors = new List<int>();
            bool isBreak = false;
            do
           {
                line = Console.ReadLine();
  
                for (int i = 0; i < line.Length; i++)
                {
                    //Console.WriteLine("ggg");
                    if (!print && !isInFor)
                    {
                        if (line[i] != ' ' && line[i] != ';')
                        {
                           // Console.WriteLine("fff");
                            if (line[i] == '(' && prv == 'T')
                            {
                                print = true;
                                // isInFor = false;
                            }
  
                            if (line[i] == '(' && prv == 'R')
                            {
                                isInFor = true;
                                //Console.WriteLine("forr");
                            }
                            if (line[i] == 'T' && prv == 'I')
                            {
                                isBreak = true;
                                break;
                            }
                            prv = line[i];
                        }
                    }
                    else if (print) // IN PRINT
                    {
                        if (line[i] == ')')
                        {
                            print = false;
                            if (numberFors.Count == 0)
                            {
                                toPrint.Append(inPrint) ;
                            }
                            else
                            {
                                foreach (int n in numberFors)
                                {
                                    stop = stop * n;
                                }
                                for (int j = 0; j < stop; j++)
                                {
                                    toPrint.Append(inPrint);
                                }
                            }
                            stop = 1;
                            numberFors.Clear();
                            inPrint.Clear();
  
                        }
                        else
                        {
  
                                inPrint.Append(line[i]);
      
                        }
  
                    }
                    else if (isInFor)// IN FOR
                    {
                        if (line[i] != ' ')
                        {
                            if (line[i] == ')')
                            {
                                isInFor = false;
                                if (doubleFor)
                                {
                                    numberFors.Add(int.Parse(for2.ToString()) - int.Parse(for1.ToString()) + 1);
                                }
                                else
                                {
                                    numberFors.Add(int.Parse(for1.ToString()));
                                }
                                for1.Clear();
                                for2.Clear();
                                 
                                doubleFor = false;
                            }
                            else
                            {
                                if (line[i] == ',')
                                {
                                    doubleFor = true;
                                }else if (doubleFor)
                                {
                                    for2.Append(line[i]);
                                }
                                else
                                {
                                    for1.Append(line[i]);
                                }
                            }
                        }
                    }
  
                }
                  
            } while (!isBreak);
             Console.Write(toPrint.ToString());
        }
    }
}