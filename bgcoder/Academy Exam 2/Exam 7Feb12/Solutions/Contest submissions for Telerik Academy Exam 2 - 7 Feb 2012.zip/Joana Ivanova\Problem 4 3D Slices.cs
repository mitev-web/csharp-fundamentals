using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3d_slices
{
    class Program
    {
        public static int[, ,] matrix = new int[0,0,0];

        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            string[] array = line.Split(' ');
            int W = int.Parse(array[0]);
            int H = int.Parse(array[1]);
            int D = int.Parse(array[2]);
            matrix = new int[H, D, W];
            string li = "";
            for (int c = 0; c < H; c++)
            {
                li += Console.ReadLine();
                li += " ";
            }
            char[] character = { ' ', '|', '\n' };
            string[] array2 = li.Split(character, StringSplitOptions.RemoveEmptyEntries);
            int p = 0;
            for (int o = 0; o < H; o++)
            {
                for (int m = 0; m < D; m++)
                {
                    for (int d = 0; d < W; d++)
                    {
                        matrix[o, m, d] = int.Parse(array2[p]);
                        p++;
                    }
                }
            }
            int count = 0;
            int otherCount = 0;
            int anotherCount = 0;
            List<int> list = new List<int>();
            int i=0;
            int r=0;
            while (i<H)
            {
                count = 0;
                for (int j = 0; j < D; j++)
                {
                    for (int k = 0; k < W; k++)
                    {
                        count += matrix[i, j, k];
                    }
                }
                list.Add(count);
                i++;
            }
            list.Sort();
            for (int j = 0; j < list.Count-1; j++)
            {
                if (list[j] == list[j+1])
                {
                    list.Remove(list[j]);
                }
            }
            int numb = list.Count;
            while (r < W)
            {
                otherCount = 0;
                for (int j = 0; j < H; j++)
                {
                    for (int k = 0; k < D; k++)
                    {
                        otherCount += matrix[j, k, r];
                    }
                }
                list.Add(otherCount);
                r++;
            }
            list.Sort();
            for (int j = numb; j < list.Count - 1; j++)
            {
                if (list[j] == list[j + 1])
                {
                    list.Remove(list[j]);
                }
            }
            numb = list.Count;
            int q = 0;
            while (q < D)
            {
                anotherCount = 0;
                for (int j = 0; j < H; j++)
                {
                    for (int k = 0; k < W; k++)
                    {
                        anotherCount += matrix[j, q, k];
                    }
                }
                list.Add(anotherCount);
                q++;
            }
            list.Sort();
            for (int j = numb; j < list.Count - 1; j++)
            {
                if (list[j] == list[j + 1])
                {
                    list.Remove(list[j]);
                }
            }
            int equal = 1;
            int bestEqual = 0;
            for (int y = 0; y < list.Count-1; y++)
            {
                if (list[y] == list[y+1])
                {
                    equal++;
                }
                else
                {
                    equal = 1;
                }
                if (equal>bestEqual)
                {
                    bestEqual = equal;
                }
            }
            if (equal == 1)
            {
                equal = 0;
            }
            Console.WriteLine(bestEqual);
        }
    }
}