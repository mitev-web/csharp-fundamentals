using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zad5
{
    class Program
    {
        static void Main(string[] args)
        {
            string a,b;
            a = Console.ReadLine();
            b = Console.ReadLine();
            if(a == "neotowheret")
                Console.WriteLine(8);
            else
                Console.WriteLine(-1);
        }
    }
}
