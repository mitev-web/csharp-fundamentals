using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Basic_Language
{
    class Program
    {
        static StringBuilder code = new StringBuilder();
        static StringBuilder result = new StringBuilder();
        static string text; 
        static void Main(string[] args)
        {
            Read();
 
            text = code.ToString();
 
            for (int i = 0; i < text.Length; i++)
            {
                i = ExecuteCode(i);
            }
            Console.WriteLine();
        }
 
        static void Read()
        {
            string input;
            do
            {
                input = Console.ReadLine();
                code.Append(input);
            } while (input.IndexOf("EXIT;") == -1);          
        }
 
 
        static int ExecuteCode(int startPosition)
        {
            bool toPrint, inLoop, newLine;
 
            int endPosition = text.IndexOf(';', startPosition);
            if (text[startPosition].Equals(" "))
            {
                endPosition = startPosition + 1;
                return endPosition;
            }
            if (text[startPosition].Equals('P'))
            {
                toPrint = true;
                int indexOfFirstBracket = text.IndexOf('(', startPosition);
                int indexOfClosingBracket = text.IndexOf(')', startPosition);
                int lengthOfString = indexOfClosingBracket - indexOfFirstBracket - 1;
                string forPrint = text.Substring(indexOfFirstBracket + 1, lengthOfString);
                Console.Write(forPrint);
            }
 
            return endPosition;
        }
    }
}