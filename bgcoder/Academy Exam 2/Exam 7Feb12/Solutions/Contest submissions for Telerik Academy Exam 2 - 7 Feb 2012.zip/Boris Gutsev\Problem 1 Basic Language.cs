using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.BasicLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            //read form console
            int index = -1;
            bool exit = false;
            bool inPrint = false;
            bool print = false;            
            bool endPrint = false;
            bool endBrack = false;

            bool inFor = false;
            bool forr = false;
            bool endFor = false;

            bool nextCommand = false;
            bool inFirstNumber = false;
            bool inNewRowCommand = false;

            double loops = 0;

            StringBuilder sbText = new StringBuilder();
            StringBuilder sbFirstNumber = new StringBuilder();
            StringBuilder sbSecondNumber = new StringBuilder();
            StringBuilder sbInLoops = new StringBuilder();
            do
            {
                bool firstChar = false;
                if (!inPrint && !inFor)
                {
                   firstChar = true;
                }
                
                //string currentRow = Console.ReadLine();
                string currentRow = Console.ReadLine();
                if (currentRow != null && currentRow != "")
                {

                        GetNextCommand(ref print, ref forr, ref exit, currentRow[0]);
                        nextCommand = false;
                    
                    foreach (char item in currentRow)
                    {
                        if (!firstChar)
                        {
                            if (nextCommand)
                            {
                                if (GetNextCommand(ref print, ref forr, ref exit, item))
                                {
                                    nextCommand = false;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                            if (print)
                            {
                                if (!inPrint)
                                {
                                    if (item == '(')
                                    {
                                        inPrint = true;
                                        continue;
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                else
                                {
                                    if (!endPrint)
                                    {
                                        if (item != ')' && !endBrack)
                                        {

                                            if (loops == 0)
                                            {
                                                sbText.Append(item);
                                                continue;
                                            }
                                            else
                                            {
                                                sbInLoops.Append(item);
                                                continue;
                                            }
                                            
                                        }
                                        else
                                        {
                                            endBrack = true;
                                            endPrint = true;
                                            if (loops != 0)
                                            {
                                                for (double i = 0; i < loops; i++)
                                                {
                                                    sbText.Append(sbInLoops);
                                                }
                                                loops = 0;
                                                sbInLoops.Clear();
                                            }
                                            continue;
                                        }
                                    }
                                    else
                                    {
                                        if (item == ';')
                                        {
                                            endPrint = false;
                                            endBrack = false;
                                            inPrint = false;
                                            print = false;
                                            nextCommand = true;
                                            continue;
                                        }
                                    }
                                }
                            }
                            if (forr)
                            {
                                if (!inFor)
                                {
                                    if (item == '(')
                                    {
                                        inFor = true;
                                        inFirstNumber = true;
                                        continue;
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                else
                                {
                                    if (item == ' ')
                                    {
                                        continue;
                                    }
                                    if (item == ',')
                                    {
                                        inFirstNumber = false;
                                        continue;
                                    }
                                    else if (item == ')')
                                    {
                                        if (loops == 0)
                                        {
                                            loops = 1;
                                        }
                                        inFor = false;
                                        int firstNumber = int.Parse(sbFirstNumber.ToString());
                                        int secondNumber = 0;
                                        bool secondLoop = false;
                                        if (sbSecondNumber.Length != 0)
                                        {
                                            secondLoop = true;
                                            secondNumber = int.Parse(sbSecondNumber.ToString());
                                        }
                                        if (!secondLoop)
                                        {
                                            loops *= firstNumber;
                                        }
                                        else
                                        {
                                            loops *= secondNumber - firstNumber + 1;
                                        }
                                        sbFirstNumber.Clear();
                                        sbSecondNumber.Clear();
                                        inFor = false;
                                        forr = false;
                                        nextCommand = true;
                                        continue;
                                    }
                                    if (inFirstNumber)
                                    {
                                        sbFirstNumber.Append(item);
                                        continue;
                                    }
                                    else
                                    {
                                        sbSecondNumber.Append(item);
                                        continue;
                                    }
                                }
                            }
                        }
                        else
                        {
                            firstChar = false;
                            continue;
                        }
                    }
                }
                else if(inPrint)
                {
                    if (loops == 0)
                    {
                        sbText.Append(Environment.NewLine);
                        continue;
                    }
                    else
                    {
                        sbInLoops.Append(Environment.NewLine);
                        continue;
                    }
                }
            } while (!exit);
            if (sbText.Length!=0)
            {
                Console.WriteLine(sbText.ToString());
            }
            else
            {
                Console.WriteLine();
            }
        }

       

        private static bool GetNextCommand(ref bool print, ref bool forr, ref bool exit, char item)
        {
            if (item != ' ')
            {
                if (item == 'P')
                {
                    print = true;
                    forr = false;
                    exit = false;
                }
                else if (item == 'F')
                {
                    print = false;
                    forr = true;
                    exit = false;
                }
                else if (item == 'E')
                {
                    print = false;
                    forr = false;
                    exit = true;
                }
                return true;
            }
            return false;
        }
    }
}
