using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace TelerikChsarpFundamentalsExam2
{
    class Program
    {
        static int maxInstruction = 0;
        static bool exitFlag = false;
        static KeyValuePair<String,int> getNextInstruction(string s,int index)
        {
            KeyValuePair<String, int> invalid = new KeyValuePair<string, int>("invalid", -1);
            int k = s.IndexOf("FOR",index);
            int l = s.IndexOf("PRINT",index);
            int m = s.IndexOf("EXIT",index);
            if (k == l && m>=0) return new KeyValuePair<string, int>("EXIT", m);
            if(l==m && k>=0) return new KeyValuePair<string, int>("FOR", k);
            if (k == m && l >= 0) return new KeyValuePair<string, int>("PRINT", l);
            if (k == m && m == l) return new KeyValuePair<string, int>("no instruction", -1);
            if (k > l)
            {
                if (l > m)// znachi m e nai malko
                {
                    if (m >= 0)
                    {
                        return new KeyValuePair<string, int>("EXIT", m);
                    }// imame EXIT;
                    else if (l >= 0)
                    {
                        return new KeyValuePair<string, int>("PRINT", l);
                    }
                    else if (k >= 0) return new KeyValuePair<string, int>("FOR", k);
                    return invalid;
                }
                else if(m>l) // m>=l
                {
                    //l e nai malkoto
                    if (l >= 0) return new KeyValuePair<string, int>("PRINT", l);
                    else
                    {
                        if (k > m)
                        {
                            // m e nai malkoto
                            if (m >= 0) return new KeyValuePair<string, int>("EXIT", m);
                            else if(k>=0) return new KeyValuePair<string, int>("FOR", k);
                        }
                        else if (k < m) // k e nai malkoto polojitelno
                        {
                            if (k >= 0)return new KeyValuePair<string, int>("FOR", k);
                            else if (m >= 0) return new KeyValuePair<string, int>("EXIT", m); 
                        }

                    }
                    return invalid;
                }
            }
            else if (k < l)
            {
                if (l < m) // k e nai malkoto k<l<m
                {
                    if(k>=0) return new KeyValuePair<string, int>("FOR", k);
                    else if (l >= 0) return new KeyValuePair<string, int>("PRINT", l);
                    else if (m >= 0) return new KeyValuePair<string, int>("EXIT", m);
                }
                else if (l >= m) // l e nai golqmo
                {
                    if (k < m)
                    {
                        // k<m<l
                        if (k >= 0) return new KeyValuePair<string, int>("FOR", k);
                        else if (m >= 0) return new KeyValuePair<string, int>("EXIT", m);
                        else if (l >= 0) return new KeyValuePair<string, int>("PRINT", l);
                    }
                    else if (k > m) // m<k<L
                    {
                        if (m >= 0) return new KeyValuePair<string, int>("EXIT", m);
                        else if (k >= 0) return new KeyValuePair<string, int>("FOR", k);
                        else if (l >= 0) return new KeyValuePair<string, int>("PRINT", l);
                    }
                }
                return invalid;
            }
            return invalid;
            
        }
        static void wrapper(string s)
        {
            int index = 0;
            while(exitFlag == false)
            {
                int k = Process(s,index);
                index = k+1;      
            }
            Console.WriteLine();
        }
        static int Process(string s, int index)
        {
            if (exitFlag == true) return -1;
            KeyValuePair<string, int> command = getNextInstruction(s,index);
            if (command.Key == "PRINT")
            {
                int left = s.IndexOf('(', command.Value);
                int right = s.IndexOf(')', command.Value);
                if (right != -1) Console.Write(s.Substring(left + 1, right - left - 1));
                int currentInstruction = right + 1;
                if (currentInstruction > maxInstruction) maxInstruction = currentInstruction;
            }
            if (command.Key == "EXIT")
            {
                exitFlag = true;
                return -1;
            }
            if (command.Key == "FOR")
            {
                int finalNumber;
                int indexOfComma = s.IndexOf(',', command.Value);
                int indexOfRightParenthesis = s.IndexOf(')',command.Value);
                int indexOfLeftParenthesis = s.IndexOf('(', command.Value);
                if (indexOfComma < indexOfRightParenthesis && indexOfComma >= 0)
                {
                    String number1 = s.Substring(indexOfLeftParenthesis+1, indexOfComma - indexOfLeftParenthesis-1).Trim();
                    String number2 = s.Substring(indexOfComma + 1, indexOfRightParenthesis - indexOfComma - 1).Trim();
                    int num1 = Int32.Parse(number1);
                    int num2 = Int32.Parse(number2);
                    finalNumber = num2 - num1 + 1;
                }
                else
                {
                    string number = s.Substring(indexOfLeftParenthesis+1, indexOfRightParenthesis - indexOfLeftParenthesis-1).Trim();
                    finalNumber = Int32.Parse(number);
                }
                for (int i = 1; i <= finalNumber; i++)
                {
                    Process(s, indexOfRightParenthesis+1);
                }
                if (indexOfRightParenthesis > maxInstruction) maxInstruction = indexOfRightParenthesis;                 
            }
            return maxInstruction;
            
        }
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            StringBuilder result = new StringBuilder(s);
            while (s.IndexOf("EXIT") == -1)
            {
                s = Console.ReadLine();
                result.Append(s);
            }
            wrapper(result.ToString());
        }
    }
}
