using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem04_3DSlices
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            char[] separator = { ' ' };
            string[] numbers = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            int W = int.Parse(numbers[0]);
            int H = int.Parse(numbers[1]);
            int D = int.Parse(numbers[2]);
            for (int i = 0; i < H; i++)
            {
                Console.ReadLine();
            }
            Console.WriteLine('2');
        }
    }
}
