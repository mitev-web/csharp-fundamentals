using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace TaskFive
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            string code = Console.ReadLine();
            //string code = "neotowheret";
            int wordLength;
            string decodedWord;
            int counter = 0;
            bool flag = true;
            string[] words = Console.ReadLine().Split(new char[] { '\"', ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            //string[] words = "\"one\", \"two\", \"three\", \"there\"".Split(new char[] { '\"', ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var word in words)
            {
                wordLength = word.Length;
                char[] characters = word.ToArray();
                Array.Sort(characters);
                for (int i = 0; i < code.Length - wordLength + 1; i++)
                {
                    flag = true;
                    decodedWord = code.Substring(i, wordLength);
                    char[] decodedCharacters = decodedWord.ToArray();
                    Array.Sort(decodedCharacters);
                    for (int j = 0; j < wordLength; j++)
                    {
                        if (characters[j] != decodedCharacters[j])
                        {
                            flag = false;
                            break;
                        }
                         
                    }
                    if (flag)
                    {
                        StringBuilder some = new StringBuilder();
                        some.Append(decodedCharacters);
                        if (dictionary.ContainsKey(some.ToString()))
                        {
                            int count = 0;
                            for (int j = 0; j < wordLength; j++)
                            {
                                if (word[j] != decodedWord[j])
                                {
                                    count++;
                                }
                            }
                            if (dictionary[some.ToString()] > count)
                            {
                                dictionary[some.ToString()] = count;
                            }
                        }
                        else
                        {
                            int count = 0;
                            for (int j = 0; j < wordLength; j++)
                            {
                                if (word[j] != decodedWord[j])
                                {
                                    count++;
                                }
                            }
                            dictionary.Add(some.ToString(), count);
                        }
                        break;
                    }
                }
            }
            foreach (var element in dictionary)
            {
                counter += element.Value;
            }
            if (counter != 0)
            {
                Console.WriteLine(counter);
            }
            else
            {
                Console.WriteLine(-1);
            }
 
        }
    }
}