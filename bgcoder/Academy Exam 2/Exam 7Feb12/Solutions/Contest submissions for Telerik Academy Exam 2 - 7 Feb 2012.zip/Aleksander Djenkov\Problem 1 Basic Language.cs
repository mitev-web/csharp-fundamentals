using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    class Problem1
    {
        static void Main(string[] args)
        {
            int i = 0;
            int exit=0;
            int k = 0;
         
            string line;
            int lines = 0;
            StringBuilder text = new StringBuilder();
            do
            {
              
                 line = Console.ReadLine();
                k = 0;
                do
                {
                 
                  text.Append(line[k]);
                  if (line[k] == ';') lines++;
                  
                    k++;
                } while (k<=line.Length-1);
                
                
      
                
                if (line.Contains("EXIT;"))   exit = 1;
                
                
                line = string.Empty;

            } while (exit!=1);

            StringBuilder final = new StringBuilder();
            StringBuilder text2 = new StringBuilder();
            int v=0;
            int h = 0;
            int multiplayer =1;
            int exitFor=0;
            int start = 0;
            
            int e = 0;
            int flagForLoop = 0;
            int exitPrint = 0;
            int position=0;
            char[] del = { ',', ' ',')'};
            StringBuilder tempFor=new StringBuilder();
            StringBuilder tempPrint = new StringBuilder();
        
            do
            {
                multiplayer = 1; 
                do
                {

                    text2.Append(text[v]);
                    v++;
                    if (text[v] == ';') lines--;
                } while (text[v] != ';');
               
                
               
                while ((i = text2.ToString().IndexOf("FOR", i)) != -1)
                {
                    flagForLoop = 1;
                    h=i+2;
                    do
                    {
                        if (text2[h] == '(') start = 1;
                        if (text2[h] == ')')
                        {
                            start = 0;
                            exitFor = 1;
                        }
                        if (start == 1 && text2[h] != ')')
                        {
                            tempFor.Append(text2[h+1]);
                        }

                        h++;
                    } while (exitFor != 1);
                    string[] loops = tempFor.ToString().Split(del, StringSplitOptions.RemoveEmptyEntries);
                    int firstLoop = int.Parse(loops[0]);
                    int secondLoop=0;
                    if (loops.Length == 2) secondLoop = int.Parse(loops[1]);
                    if (loops.Length == 2) multiplayer *= (secondLoop - firstLoop )+ 1;
                    else multiplayer *= firstLoop;
                  
                    exitFor = 0;
                    tempFor.Clear();
                    h = 0;
                    start = 0;
                  
                    i++;
                }
              
                while ((e = text2.ToString().IndexOf("PRINT", e)) != -1)
                {

                     position= e+2;
                    int startPrint = 0;
                    do
                    {
                       
                        if (text2[position] == ')')
                        {
                            startPrint = 0;
                            exitPrint = 1;
                            
                        }
                        if (startPrint == 1 && text2[position] != ')')
                        {
                            tempPrint.Append(text2[position]);
                        }
                        if (text2[position] == '(') startPrint = 1;
                        position++;
                    } while (exitPrint != 1);
                    if (flagForLoop == 1)
                    {
                        for (int w = 0; w <multiplayer; w++)
                        {
                            final.Append(tempPrint);
                        }   
                    }
                    else final.Append(tempPrint);
                    flagForLoop = 0;
                    tempPrint.Clear();
                    exitPrint = 0;
                    position = 0;
                    e++;
                }

               


               
                text2.Clear();
                i = 0;
                e=0;
            } while (lines != 0);

           
            Console.WriteLine(final);
        }
    }
}
