using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskFive
{
    class Program
    {
        static void Main(string[] args)
        {
            int h=int.Parse(Console.ReadLine().Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries)[1]);
            for (int i = 0; i < h; i++)
            {
                string input = Console.ReadLine();
            }
            Console.WriteLine(0);
        }
    }
}