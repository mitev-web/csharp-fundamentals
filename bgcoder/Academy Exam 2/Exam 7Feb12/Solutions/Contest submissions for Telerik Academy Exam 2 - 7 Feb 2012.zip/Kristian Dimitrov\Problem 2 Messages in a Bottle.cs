using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace _02Message
{
    class Program
    {
        public struct transType 
        {
            public string st1;
            public string st2;
        }

        public static transType[] transf;
        public static string str1;
        public static int[] translation = new int[2048];
        public static int pN,total=0;
        public static List<string> words = new List<string>();

        static void Main(string[] args)
        {
            string code = Console.ReadLine();
            str1 = code;
            string letter = Console.ReadLine();
            Regex reg = new Regex(@"(?<letter>[A-Z])(?<number>(\d)+)");
            MatchCollection matches = reg.Matches(letter);
            transType[] tempTransf= new transType[matches.Count];
            for (int i = 0; i < matches.Count; i++)
			{
                tempTransf[i].st1 = matches[i].Groups["letter"].Value.ToString();
                tempTransf[i].st2 = matches[i].Groups["number"].Value.ToString();
            }
            transf = tempTransf;
            pN = 0;
            NextLetter(0);
            if (words.Count == 0)
                Console.WriteLine(0);
            else
            {
                Console.WriteLine(total);
                words.Sort();
                foreach (string item in words)
                {
                    Console.WriteLine(item);
                }
            }
        }

        public static void NextLetter(int count)
        {

            int i, k;
            if (count == str1.Length)
            {
                AddTranslation(); return;
            }
            for (k = 0; k < transf.Length; k++)
            {
                int len = transf[k].st2.Length;
                for (i = 0; i < len; i++)
                {
                    if (i + count > str1.Length - 1) break;
                    if (str1[i + count] != transf[k].st2[i]) break;
                }
                if (i == len)
                {
                    translation[pN++] = k;
                    NextLetter(count + transf[k].st2.Length);
                    pN--;
                }
            }

        }

        public static void AddTranslation()
        {
            StringBuilder sb = new StringBuilder();
            int i;
            total++;
            for (i = 0; i < pN; i++)
            {
                sb.Append(transf[translation[i]].st1);
            }
            words.Add(sb.ToString());
        }
    }
}