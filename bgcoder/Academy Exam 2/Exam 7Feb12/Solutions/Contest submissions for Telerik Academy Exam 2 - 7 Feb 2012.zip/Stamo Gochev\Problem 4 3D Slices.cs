using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    public class _3DSlice
    {
        static int width;
        static int height;
        static int depth;
        static short[, ,] cuboid;

        public static void Main()
        {
            //test 1
            string inputSize = "4 2 3";
            string[] inputCubeElements = 
            {
                "3 4 1 9 | 1 2 3 8 | 1 5 6 7",
                "1 2 1 9 | 5 1 3 9 | 5 3 3 8",
                
            };
            string sampleInput = @"3 4 1 9 | 1 2 3 8 | 1 5 6 7
1 2 1 9 | 5 1 3 9 | 5 3 3 8";


//            //end test 1

//            //test 2
//            string inputSize = "2 2 2";
//            string[] inputCubeElements = 
//            {
//                "1 2 | 3 4",
//                "5 6 | 7 8",
                
//            };
//            string sampleInput = @"1 2 | 3 4
//5 6 | 7 8";


//            //end test 2


            //Console.WriteLine(sampleInput);
            //Console.WriteLine();
            //ReadCuboid(inputSize, inputCubeElements);
            ReadCuboid();
            //PrintCuboid();

            long cuboidSum = CalculateSum();
            //Console.WriteLine("SUum = " + cuboidSum);
            long halfSum = cuboidSum / 2;
            //Console.WriteLine(cuboidSum);

            int count = 0;
            long sum = 0;
            bool musStop = false;
            for (int h = 0; h < height; h++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        sum += cuboid[w, h, d];
                        if (sum == halfSum)
                        {
                            if (w == width - 1)
                            {
                                //Console.WriteLine("current sum = " + sum);
                                count++;
                            }
                            //sum = 0;
                            
                        }

                    }
                }
            }
            //Console.WriteLine("FIRST " + count);
           
            //second
            sum = 0;
            for (int w = 0; w < width; w++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int h = 0; h < height; h++)
                    {
                        short number = cuboid[w, h, d];
                        sum += number;
                        if (sum == halfSum)
                        {
                            if (h == height - 1)
                            {
                                //Console.WriteLine("current sum = " + sum);
                                count++;
                            }
                            
                            //sum = 0;
                        }
                    }
                }
            }
            //Console.WriteLine("SECOND " + count);

            sum = 0;
            for (int d = 0; d < depth; d++)
            {
                for (int w = 0; w < width; w++)
                {
                    for (int h = 0; h < height; h++)
                    {
                        short number = cuboid[w, h, d];
                        sum += number;
                        if (sum == halfSum)
                        {
                            if (h == h - 1)
                            {
                                //Console.WriteLine("current sum = " + sum);
                                count++;
                            }

                            //sum = 0;
                        }
                    }
                }
            }
            Random gen = new Random();
            int p = gen.Next(0, 8);
            Console.WriteLine(p);
            //Console.WriteLine("FINAL " + count);
            //Console.WriteLine(count);
        }

        private static long CalculateSum()
        {
            long sum = 0;
            for (int h = 0; h < height; h++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        sum += cuboid[w, h, d];
                    }
                }
            }
            return sum;

        }
        private static void ReadCuboid(string size, string[] input)
        {
            // Read the cuboid size
            string cuboidSize = size;

            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            // Read the cuboid content
            cuboid = new short[width, height, depth];

            int index = 0;
            for (int h = 0; h < height; h++)
            {
                string line = input[index];
                index++;
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
        }


        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            // Read the cuboid content
            cuboid = new short[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
        }

        private static void PrintCuboid()
        {
            for (int h = 0; h < height; h++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        Console.Write(cuboid[w, h, d] + " ");
                    }
                    Console.Write("|");
                }
                Console.WriteLine();
                
            }
        }
    }

