using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = "";
            string p = "";
            bool endInput = false;
            do
            {
                p = Console.ReadLine();
                input += p;
                try
                {
                    if (p.Substring(p.Length - 5, 5) == "EXIT;" || p == "")
                    {
                        endInput = true;
                    }
                }
                catch (ArgumentOutOfRangeException)
                {
                    continue;
                }
            } while (endInput == false);
            bool inPrint = false;
            bool beforePrint = false;
            bool inFor = false;
            bool beforeFor = false;
            bool inSplit = false;
            int start = 0;
            int end = 0;
            BigInteger counter = 1;
            string PrintString = "";
            string ForString = "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == 'P' && inPrint == false) //print 
                {
                    beforePrint = true;
                }
                if (input[i] == 'F' && inPrint == false) // for
                {
                    beforeFor = true;
                }
                if (input[i] == '(' && inPrint == false)                     // otvarq se For ili Print
                {
                    if (beforePrint == true)
                    {
                        inPrint = true;
                        start = i;
                    }
                    if (beforeFor == true)
                    {
                        inFor = true;
                        start = i;
                    }
                }
                if (input[i] == ',' && inFor == true)     // za splita pri for
                {
                    inSplit = true;
                }
                if (input[i] == ')')                      // zatvarq se for ili print
                {
                    if (inPrint == true)
                    {
                        end = i;
                        PrintString = input.Substring(start + 1, end - start - 1);



                        for (long s = 1; s <= counter; s++)
                        {
                            sb.Append(PrintString);
                        }
                        counter = 1;
                        inPrint = false;
                        beforePrint = false;
                    }
                    if (inFor == true)
                    {
                        end = i;
                        ForString = input.Substring(start + 1, end - start - 1);
                        if (inSplit == true)
                        {
                            string[] cleanArray = ForString.Split(',');
                            string a = cleanArray[0].Trim();
                            string b = cleanArray[1].Trim();
                            counter *= (BigInteger.Parse(b) - BigInteger.Parse(a) + 1);
                            inSplit = false;
                        }
                        else
                        {
                            string a = ForString.Trim();
                            counter *= long.Parse(a);
                        }
                        inFor = false;
                        beforeFor = false;

                    }
                }
                if (input[i] == 'E' && inPrint == false)
                {
                    break;
                }
            }
            Console.WriteLine(sb.ToString());
            /*
PRINT(Black and yellow, ); 
FOR(0,1)PRINT(black and yellow, );
FOR(2)FOR(2,3)PRINT(XI );EXIT;
            */
        }
    }
}
