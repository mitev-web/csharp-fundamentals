using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Task3_Cooking
{

    class Triple
    {
        public double count {get; set;}
            public string measurement {get; set;}
            public string name{get; set;}

            public Triple(double count, string measurement, string name)
            {
                this.count = count;
                this.measurement = measurement;
                this.name = name;
            }
    }

    class Cooking
    {

        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Dictionary<string, Triple> dic = new Dictionary<string, Triple>();
            char[] separators = new char[] { ':' };
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                string[] ingr = line.Split(separators);
                if (dic.ContainsKey(ingr[2].ToLower()))
                {
                    string measurement = dic[ingr[2].ToLower()].measurement;
                    double newCount = ConvertMeasurement(ingr[1], measurement, Convert.ToDouble(ingr[0]));
                    dic[ingr[2].ToLower()].count = dic[ingr[2].ToLower()].count + newCount;
                }
                else
                {
                    dic.Add(ingr[2].ToLower(), new Triple(Convert.ToDouble(ingr[0]), ingr[1], ingr[2]));
                }
            }
            Dictionary<string, Triple> hasAlready = new Dictionary<string, Triple>();
            int m = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < m; i++)
            {
                string line = Console.ReadLine();
                string[] ingr = line.Split(separators);
                if (hasAlready.ContainsKey(ingr[2].ToLower()))
                {
                    string measurement = hasAlready[ingr[2].ToLower()].measurement;
                    double newCount = ConvertMeasurement(ingr[1], measurement, Convert.ToDouble(ingr[0]));
                    hasAlready[ingr[2].ToLower()].count = hasAlready[ingr[2].ToLower()].count + newCount;
                }
                else
                {
                    hasAlready.Add(ingr[2].ToLower(), new Triple(Convert.ToDouble(ingr[0]), ingr[1], ingr[2]));
                }
            }
            Dictionary<string, Triple>.Enumerator enumerator = dic.GetEnumerator();
            Dictionary<string, Triple> haveToAdd = new Dictionary<string, Triple>();

            while (enumerator.MoveNext())
            {
                string key = enumerator.Current.Key.ToLower();
                if (!hasAlready.ContainsKey(key) && !haveToAdd.ContainsKey(key))
                {
                    haveToAdd.Add(key, new Triple(
                        enumerator.Current.Value.count, enumerator.Current.Value.measurement, enumerator.Current.Value.name));
                    continue;
                }
                if (!haveToAdd.ContainsKey(key))
                {
                    double count = hasAlready[key].count;
                    string measurement = hasAlready[key].measurement;
                    double wantedCount = enumerator.Current.Value.count;
                    string wantedMeasurement = enumerator.Current.Value.measurement;
                    double newCount = new double();
                    double left = new double();
                    if (!measurement.Equals(wantedMeasurement))
                    {
                        newCount = ConvertMeasurement(measurement, wantedMeasurement, count);
                        left = wantedCount - newCount;
                    }
                    else
                    {
                        left = wantedCount - count;
                    }
                    if (left > 0)
                    {
                        haveToAdd.Add(key, new Triple(left, wantedMeasurement, enumerator.Current.Value.name));
                    }
                }
                else
                {
                    double wantedCount = haveToAdd[key].count;
                    string wantedMeasurement = haveToAdd[key].measurement;
                    double count = enumerator.Current.Value.count;
                    string measurement = enumerator.Current.Value.measurement;
                    double newCount = new double();
                    double left = new double();
                    if (!measurement.Equals(wantedMeasurement))
                    {
                        newCount = ConvertMeasurement(measurement, wantedMeasurement, count);
                        left = wantedCount - newCount;
                    }
                    else
                    {
                        left = wantedCount - count;
                    }
                    if (left > 0)
                    {
                        haveToAdd.Add(key, new Triple(left, wantedMeasurement, enumerator.Current.Value.name));
                    }
                }
            }
            Dictionary<string, Triple>.Enumerator addEnumerator = haveToAdd.GetEnumerator();

            while (addEnumerator.MoveNext())
            {
                Console.WriteLine("{0:0.00}:{1}:{2}",
                    addEnumerator.Current.Value.count, addEnumerator.Current.Value.measurement, 
                    addEnumerator.Current.Value.name);
            }
            //Console.WriteLine();
        }

        private static double ConvertMeasurement(string from, string to, double count)
        {
            if (from == "tbsps" && to == "tsps")
            {
                return count * 3;
            }
            if (from == "tsps" && to == "tbsps")
            {
                return count / 3;
            }
            if (from == "ls" && to == "mls")
            {
                return count * 1000;
            }
            if (from == "mls" && to == "ls")
            {
                return count / 1000;
            }
            if (from == "fl ozs" && to == "cups")
            {
                return count / 8;
            }
            if (from == "cups" && to == "fl ozs")
            {
                return count * 8;
            }
            if (from == "tsps" && to == "mls")
            {
                return count * 5;
            }
            if (from == "mls" && to == "tsps")
            {
                return count / 5;
            }
            if (from == "gals" && to == "qts")
            {
                return count * 4;
            }
            if (from == "qts" && to == "gals")
            {
                return count / 4;
            }
            if (from == "pts" && to == "cups")
            {
                return count * 2;
            }
            if (from == "cups" && to == "pts")
            {
                return count / 2;
            }
            if (from == "qts" && to == "pts")
            {
                return count * 2;
            }
            if (from == "pts" && to == "qts")
            {
                return count / 2;
            }
            if (from == "cups" && to == "tsps")
            {
                return count * 48;
            }
            if (from == "tsps" && to == "cups")
            {
                return count / 48;
            }
            return 0;
        }

    }
}
