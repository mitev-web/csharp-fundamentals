using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Cooking
{
    class Program
    {
        static string pattern = "([0-9.]*):([A-Za-z ]*):([A-Za-z ]*)";//"([0-9.]*):([tbsp|tsp|ls|mls|teaspoon|mls|gals|quarts|pts|cups|qts|tsps]){1}:([A-Za-z ]*)";
        static Regex regex = new Regex(pattern);

        class Product : IEquatable<Product>
        {
            public string productName;
            public double productQuantity;
            public string measurementUnit;

            public Product(string productName, double productQuantity, string measurenmentUnit)
            {
                this.productName = productName;
                this.productQuantity = productQuantity;
                this.measurementUnit = measurenmentUnit;
            }

            public bool Equals(Product other)
            {
                if (this.productName.ToLower() == other.productName.ToLower())
                {
                    return true;
                }

                return false;
            }
        }

        static void Main(string[] args)
        {
            #region recipe
            int n = int.Parse(Console.ReadLine());

            List<Product> recipe = new List<Product>();
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                Product currentProduct = ExtractData(line);
                int currentIndex = recipe.IndexOf(currentProduct);
                if (currentIndex == -1)
                {
                    recipe.Add(currentProduct);
                }
                else
                {
                    if (recipe[currentIndex].measurementUnit == currentProduct.measurementUnit)
                    {
                        recipe[currentIndex].productQuantity += currentProduct.productQuantity;
                    }
                    else
                    {
                        recipe[currentIndex].productQuantity +=
                            Convert(currentProduct.measurementUnit, recipe[currentIndex].measurementUnit, currentProduct.productQuantity);
                    }
                }
            }
            #endregion

            #region Already used products
            int m = int.Parse(Console.ReadLine());

            List<Product> used = new List<Product>();
            for (int i = 0; i < m; i++)
            {
                string line = Console.ReadLine();
                Product currentProduct = ExtractData(line);
                int currentIndex = used.IndexOf(currentProduct);
                if (currentIndex == -1)
                {
                    used.Add(currentProduct);
                }
                else
                {
                    if (used[currentIndex].measurementUnit == currentProduct.measurementUnit)
                    {
                        used[currentIndex].productQuantity += currentProduct.productQuantity;
                    }
                    else
                    {
                        used[currentIndex].productQuantity +=
                            Convert(currentProduct.measurementUnit, used[currentIndex].measurementUnit, currentProduct.productQuantity);
                    }
                }
            }
            #endregion

            for (int i = 0; i < recipe.Count; i++)
            {
                int currentIndex = used.IndexOf(recipe[i]);
                if (currentIndex != -1)
                {
                    if (used[currentIndex].measurementUnit != recipe[i].measurementUnit)
                    {
                        used[currentIndex].productQuantity =
                            Convert(used[currentIndex].measurementUnit, recipe[i].measurementUnit, used[currentIndex].productQuantity);
                    }
                    if (recipe[i].productQuantity > used[currentIndex].productQuantity)
                    {
                        Console.WriteLine("{0:0.00}:{1}:{2}", recipe[i].productQuantity - used[currentIndex].productQuantity, recipe[i].measurementUnit, recipe[i].productName);
                    }
                }
                else
                {
                    Console.WriteLine("{0:0.00}:{1}:{2}", recipe[i].productQuantity, recipe[i].measurementUnit, recipe[i].productName);
                }
            }
        }

        static Product ExtractData(string line)
        {
            Match match = regex.Match(line);

            string productName = match.Groups[3].ToString();
            double productQuanity = double.Parse(match.Groups[1].ToString());
            string measurenmentUnit = match.Groups[2].ToString();
                    
            return new Product(productName, productQuanity, measurenmentUnit);
        }

        static double ConvertAnyToLiters(double quantity, string unitType)
        {
            switch (unitType)
            {
                case "mls":
                    return quantity * 0.001;
                case "fl ozs":
                    return quantity * 0.03;
                case "tsps":
                    return quantity * 0.005;
                case "tbsps":
                    return quantity * 0.015;
                case "cups":
                    return quantity * 0.24;
                case "pts":
                    return quantity * 0.48;
                case "qts":
                    return quantity * 0.96;
                case "gals":
                    return quantity * 3.84;
                case "ls":
                    return quantity;
                default:
                    return -1;
            }
        }

        static double ConvertLitersToAny(double quantity, string unitType)
        {
            switch (unitType)
            {
                case "mls":
                    return quantity / 0.001;
                case "fl ozs":
                    return quantity / 0.03;
                case "tsps":
                    return quantity / 0.005;
                case "tbsps":
                    return quantity / 0.015;
                case "cups":
                    return quantity / 0.24;
                case "pts":
                    return quantity / 0.48;
                case "qts":
                    return quantity / 0.96;
                case "gals":
                    return quantity / 3.84;
                case "ls":
                    return quantity;
                default:
                    return -1;
            }
        }
        
        static double Convert(string unitType1, string unitType2, double quantity)
        {
            double liters = ConvertAnyToLiters(quantity, unitType1);

            return ConvertLitersToAny(liters, unitType2);
        }
    }
}