using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SecretLanguage
{
    class SecretLanguage
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            char[] splitters = {' ',',','"'};
            string[] word = Console.ReadLine().Split(splitters, StringSplitOptions.RemoveEmptyEntries);
            char[][] sortedWord = new char[word.Length][];
            for (int i = 0; i < word.Length; i++)
            {
                sortedWord[i] = word[i].ToCharArray();
                Array.Sort(sortedWord[i]);
            }


            char[,][] substr = new char[s.Length, s.Length][];
            for (int i = 0; i < s.Length; i++)
            {
                for (int j = 0; j < s.Length; j++)
                {
                    if (i + j < s.Length)
                    {
                        substr[i, j] = s.Substring(i, j + 1).ToCharArray();
                        Array.Sort(substr[i, j]);
                    }
                }
            }

            int start = 0, end = 0;
            int minCost = int.MaxValue;
            int sumCost = 0;
            bool found = false;
            int cost = -1;
            while (start <= end && end < s.Length)
            {

                found = false;
                for (int i = 0; i < sortedWord.Length; i++)
                {
                    if (Comp(sortedWord[i],substr[start, end-start]))
                    {
                        found = true;
                        cost = calcCost(word[i], s.Substring(start, end-start+1));
                        if (cost < minCost)
                        {
                            minCost = cost;
                        }
                    }
                }
                if (found == false)
                {
                    end++;
                }
                else
                {
                    sumCost += minCost;
                    minCost = int.MaxValue;
                    start=end+1;
                    end++;
                }
            }
            if (found == true)
            {
                Console.WriteLine(sumCost);
            }
            else
                Console.WriteLine(-1);

        }

        private static bool Comp(char[]  p, char[] q)
        {
            for (int i = 0; i < Math.Min(p.Length, q.Length); i++)
            {
                if (p[i].CompareTo(q[i])!=0)
                    return false;
            }
            return (p.Length.CompareTo(q.Length) == 0);
        }

        private static int calcCost(string p, string q)
        {
            int cost = 0;
            for (int i = 0; i < p.Length; i++)
            {
                if (p[i] != q[i])
                    cost++;
            }
            return cost;
        }
    }
}
