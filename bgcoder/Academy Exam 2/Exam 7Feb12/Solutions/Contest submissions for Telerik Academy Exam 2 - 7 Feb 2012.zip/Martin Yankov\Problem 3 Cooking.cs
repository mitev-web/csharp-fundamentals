using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Recipe
{
    class Program
    {
        class Measurement
        {
            private double quantity;
            private string type;

            public Measurement(double quant, string typ)
            {
                this.quantity = quant;
                this.type = typ;
            }

            public double Quantity
            {
                get { return this.quantity; }
            }

            public string Type
            {
                get { return this.type; }
            }

            public double ConvertToMililiters()
            {
                double mililiters = 0;

                switch (this.type)
                {
                    case "tablespoons":
                    case "tbsps":
                        mililiters = 15;
                        break;
                    case "milliliters":
                    case "mls":
                        mililiters = 1;
                        break;
                    case "liters":
                    case "ls":
                        mililiters = 1000;
                        break;
                    case "fluid ounces":
                    case "fl ozs":
                        mililiters = 30;
                        break;
                    case "teaspoons":
                    case "tsps":
                        mililiters = 5;
                        break;
                    case "gallons":
                    case "gals":
                        mililiters = 3840;
                        break;
                    case "pints":
                    case "pts":
                        mililiters = 480;
                        break;
                    case "quarts":
                    case "qts":
                        mililiters = 960;
                        break;
                    case "cups":
                        mililiters = 240;
                        break;
                }

                return mililiters * this.quantity;
            }

            public double ConvertFromMililiters(double mililiters)
            {
                double units = 0;

                switch (this.type)
                {
                    case "tablespoons":
                    case "tbsps":
                        units = mililiters / 15;
                        break;
                    case "mililiters":
                    case "mls":
                        units = mililiters / 1;
                        break;
                    case "liters":
                    case "ls":
                        units = mililiters / 1000;
                        break;
                    case "fluid ounces":
                    case "fl ozs":
                        units = mililiters / 30;
                        break;
                    case "teaspoons":
                    case "tsps":
                        units = mililiters / 5;
                        break;
                    case "gallons":
                    case "gals":
                        units = mililiters / 3840;
                        break;
                    case "pints":
                    case "pts":
                        units = mililiters / 480;
                        break;
                    case "quarts":
                    case "qts":
                        units = mililiters / 960;
                        break;
                    case "cups":
                        units = mililiters / 240;
                        break;
                }

                return units;
            }
        }

        class Ingredient
        {
            private string name;
            private Measurement measure;

            public Ingredient(string nam, Measurement measur)
            {
                this.name = nam;
                this.measure = measur;
            }

            public string Name
            {
                get { return this.name; }
            }

            public Measurement Measure
            {
                get { return this.measure; }
            }

            public override string ToString()
            {
                StringBuilder ingredient = new StringBuilder();

                ingredient.Append(String.Format("{0:0.00}", this.measure.Quantity));
                ingredient.Append(':');
                ingredient.Append(this.measure.Type);
                ingredient.Append(':');
                ingredient.Append(this.name);

                return ingredient.ToString();
            }
        }

        static List<Ingredient> SearchForIdenticalIngredients(Ingredient[] recipe)
        {
            List<Ingredient> list = new List<Ingredient>();
            List<string> used = new List<string>();
            double mililiters = 0;
            int len = recipe.Length;

            for (int index = 0; index < len; index++)
            {
                mililiters = recipe[index].Measure.ConvertToMililiters();
                bool repetition = false;

                for (int i = 0; i < used.Count; i++)
                {
                    if (String.Compare(recipe[index].Name, used[i], true) == 0)
                    {
                        repetition = true;
                        break;
                    }
                }

                if (repetition == true)
                {
                    continue;
                }

                for (int search = index + 1; search < len; search++)
                {
                    if (String.Compare(recipe[index].Name, recipe[search].Name, true) == 0)
                    {
                        mililiters += recipe[search].Measure.ConvertToMililiters();
                        used.Add(recipe[index].Name);
                        repetition = true;
                    }
                }

                if (repetition == true)
                {
                    list.Add(new Ingredient(recipe[index].Name, 
                        new Measurement(recipe[index].Measure.ConvertFromMililiters(mililiters),
                            recipe[index].Measure.Type)));
                }
                else
                {
                    list.Add(recipe[index]);
                }
            }

            return list;
        }

        static void CompareLists(List<Ingredient> list1, List<Ingredient> list2)
        {
            List<Ingredient> result = new List<Ingredient>();
            int len1 = list1.Count;
            int len2 = list2.Count;
            bool match = false;

            for (int index1 = 0; index1 < len1; index1++)
            {
                match = false;
                
                for (int index2 = 0; index2 < len2; index2++)
                {
                    if (String.Compare(list1[index1].Name, list2[index2].Name, true) == 0)
                    {
                        match = true;

                        if (list1[index1].Measure.ConvertToMililiters() <= list2[index2].Measure.ConvertToMililiters())
                        {                            
                        }
                        else
                        {
                            double mililiters = list1[index1].Measure.ConvertToMililiters() -
                                list2[index2].Measure.ConvertToMililiters();

                            result.Add(new Ingredient(list1[index1].Name,
                                new Measurement(list1[index1].Measure.ConvertFromMililiters(mililiters),
                                    list1[index1].Measure.Type)));
                        }
                    }
                }

                if (match == false)
                {
                    result.Add(list1[index1]);
                }
            }

            foreach (Ingredient item in result)
            {
                Console.WriteLine(item.ToString());
            }
        }

        static void Main(string[] args)
        {
            int inputInt = 0;
            string inputStr = "";
            string[] format = new string[3];

            inputInt = int.Parse(Console.ReadLine());
            Ingredient[] recipe = new Ingredient[inputInt];

            for (int line = 0; line < inputInt; line++)
            {
                inputStr = Console.ReadLine();
                format = inputStr.Split(':');

                recipe[line] = new Ingredient(format[2], new Measurement(double.Parse(format[0]), format[1]));
            }

            inputInt = int.Parse(Console.ReadLine());
            Ingredient[] used = new Ingredient[inputInt];

            for (int line = 0; line < inputInt; line++)
            {
                inputStr = Console.ReadLine();
                format = inputStr.Split(':');

                used[line] = new Ingredient(format[2], new Measurement(double.Parse(format[0]), format[1]));
            }

            List<Ingredient> recipeList = SearchForIdenticalIngredients(recipe);
            List<Ingredient> usedList = SearchForIdenticalIngredients(used);

            CompareLists(recipeList, usedList);
        }
    }
}
