using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex3_Cooking
{
    class Program
    {
        static void ToLitres(double[] quantities, string[] measurements)
        {
            for (int i = 0; i < quantities.Length; i++)
            {
                switch (measurements[i])
                {
                    case ("tsps"): quantities[i] *= 0.005; break;
                    case ("tbsps"): quantities[i] *= 0.030; break;
                    case("flo ozs"): quantities[i] *= 0.030; break;
                    case ("cups"): quantities[i] *= 0.235; break;
                    case ("pts"): quantities[i] *= 0.473; break;
                    case("qts"): quantities[i] *= 0.95; break;
                    case ("gal"): quantities[i] *= 3.84; break;
                    case ("mls"): quantities[i] *= 0.001; break;
                    default: break;
                }
                measurements[i] = "ls";
            }
            

        }
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int n = int.Parse(input);
            string[] recipeIngredients=new string[n];
            for (int i = 0; i < n; i++)
            {
                recipeIngredients[i]=Console.ReadLine();
            }
            string input2 = Console.ReadLine();
            int m = int.Parse(input2);
            string[] addedIngredients=new string[m];
            for (int i = 0; i < m; i++)
			{
                addedIngredients[i]=Console.ReadLine();
			}
            string[] recipeProducts=new string[n];
            string[] addedProducts=new string[m];
            double[] recipeQuantities=new double[n];
            double[] addedQuantities=new double[m];
            string[] recipeMeasurements=new string[n];
            string[] addedMeasurements=new string[m];
            string quantity = "";
            for (int i = 0; i < n; i++)
			{
                string temp=recipeIngredients[i];
                int k=0;
                while (char.IsDigit(temp[k])) 
                {
                    quantity=quantity+ temp[k];
                    k++;
                } 
                recipeQuantities[i] = double.Parse(quantity);
                do
                {
                    k++;
                    recipeMeasurements[i] = recipeMeasurements[i] + temp[k];
                } while (temp[k+1] != ':');
                k++;
                do
                {
                    if (k == temp.Length-1)
                    {
                        break;
                    }
                        k++;
                    
                    recipeProducts[i] = recipeProducts[i] + temp[k];
                } while (temp[k] != ':');
			}
            quantity = "";
            for (int i = 0; i < m; i++)
            {
                string temp2 = addedIngredients[i];
                int k = 0;
                while (char.IsDigit(temp2[k])) 
                {
                    quantity = quantity + temp2[k];
                    k++;
                } 
                addedQuantities[i] = double.Parse(quantity);
                do
                {
                    k++;
                    addedMeasurements[i] = addedMeasurements[i] + temp2[k];
                } while (temp2[k + 1] != ':'); k++;
                do
                {
                    if (k == temp2.Length - 1)
                    {
                        break;
                    }
                    k++;

                    addedProducts[i] = addedProducts[i] + temp2[k];
                } while (temp2[k] != ':');
            }
            ToLitres(addedQuantities, addedMeasurements);
            ToLitres(recipeQuantities, recipeMeasurements);
            for (int i = 0; i < n; i++)
            {
                for (int j = 1; j < n; j++)
                {
                    if (recipeProducts[i].ToUpper() == recipeProducts[j].ToUpper())
                    {
                        recipeQuantities[i] += recipeQuantities[j];
                        recipeQuantities[j] = 0;
                    }
                }
            }
            string[] neededIngredients = new string[n];
            bool check = false;
            double neededQuantity=0;
            int l=0;
            for (int i = 0; i < n; i++)
            {
                check = false;
                for (int j = 0; j < m; j++)
                {
                    if (recipeProducts[i].ToUpper() == addedProducts[j].ToUpper())
                    {
                        check = true;
                        if (addedQuantities[j] < recipeQuantities[i])
                        {

                            neededQuantity = recipeQuantities[i] - addedQuantities[j];
                            neededIngredients[l] = neededIngredients[l] + neededQuantity + ":";
                            neededIngredients[l] = neededIngredients[l] + recipeMeasurements[i] + ":";
                            neededIngredients[l] = neededIngredients[l] + recipeProducts[i];
                            l++;
                        }
                    }
                }
                if (check == false)
                {
                    neededIngredients = recipeIngredients;
                }
                for (int o = 0; o < neededIngredients.Length; o++)
                {
                    Console.WriteLine(neededIngredients[o]);
                }
            }
            
            
        }
    }
}
