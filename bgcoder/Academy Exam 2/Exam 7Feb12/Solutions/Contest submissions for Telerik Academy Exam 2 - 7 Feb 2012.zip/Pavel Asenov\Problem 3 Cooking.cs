using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task_3_Cooking
{
    class Measurement
    {
        
        public double Quantity { get; set; }
        public VolumeType Unit { get; set; }
        public string Product { get; set; }
        public double QuantityMLS { get; set; }
        public enum VolumeType
        {
           milliliters = 0,
            tablespoons = 1,
            teaspoons = 2,
            liters = 3,
            cups=4,
            fluidounces=5,
            pints=6,
            quarts=7,
            gallons=8,
            
            mls=9,
            tbsps=10,
            tsps=11,
            ls=12,
            flozs=13,
            pts=14,
            qts=15,
            gals=16
        }
        public static double ConvertUnitsToMLS(double units, VolumeType from)
        {
            double[] factor = new double[]
            {1,15,5,1000,240,30,480,960,3840,1,15,5,1000,30,480,960,3840 };
            return units * factor[(int)from];
        }
        public static double ConvertUnitsTo(double mlsUnits, VolumeType to)
        {
            double[] factor = new double[]
            {1,15,5,1000,240,30,480,960,3840,1,15,5,1000,30,480,960,3840 };
            return mlsUnits / factor[(int)to];
        }

     
    }
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] availableIngredients = new string[n];
            List<string> keyList= new List<string>();
            List<Measurement> list = new List<Measurement>();
            Dictionary<string, Measurement> defaultUnits = new Dictionary<string, Measurement>();
            for (int i = 0; i < n; i++)
            {
                availableIngredients[i] = Console.ReadLine();
                string[] ingredienceInfo = availableIngredients[i].Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                Measurement item = new Measurement();
                item.Quantity = double.Parse(ingredienceInfo[0].Trim());

                SelectUnit(ingredienceInfo, item);

                item.QuantityMLS = Measurement.ConvertUnitsToMLS(item.Quantity, item.Unit);
                item.Product = ingredienceInfo[2].Trim();
                if (!defaultUnits.ContainsKey(item.Product.ToLower()))
                {
               keyList.Add(item.Product);
                    defaultUnits.Add(item.Product.ToLower(), item);
                   
                }

                list.Add(item);
            }

            int m = int.Parse(Console.ReadLine());
            string[] putIngredients = new string[m];
            List<Measurement> listUsed = new List<Measurement>();
           
            for (int i = 0; i < m; i++)
            {
                putIngredients[i] = Console.ReadLine();
                string[] ingredienceInfo = putIngredients[i].Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                Measurement item = new Measurement();
                item.Quantity = double.Parse(ingredienceInfo[0].Trim());
                SelectUnit(ingredienceInfo, item);
                item.QuantityMLS = Measurement.ConvertUnitsToMLS(item.Quantity, item.Unit);
                item.Product = ingredienceInfo[2].Trim();
                listUsed.Add(item);
            }

           
            foreach (var items in list)
            {
                if (defaultUnits.ContainsKey(items.Product.ToLower()))
                {

                    if (!keyList.Contains(items.Product))
                    {
                        string key = items.Product.ToLower();

                        defaultUnits[key].QuantityMLS = defaultUnits[key].QuantityMLS + items.QuantityMLS;
                    }
                    else
                    {
                        keyList.Remove(items.Product);
                    }
                   
                    
                }
            }
            foreach (var item in listUsed)
            {
                if (defaultUnits.ContainsKey(item.Product.ToLower()))
                {
                    string key = item.Product.ToLower();
                    defaultUnits[key].QuantityMLS = defaultUnits[key].QuantityMLS - item.QuantityMLS;

                }
            }
                foreach (var item in defaultUnits)
            {

                item.Value.Quantity = Measurement.ConvertUnitsTo(item.Value.QuantityMLS, item.Value.Unit);
            }


            //print
                foreach (var item in defaultUnits)
                {
                    if (item.Value.Quantity>0)
                    {
                        Console.WriteLine("{0:F2}:{1}:{2}",item.Value.Quantity,item.Value.Unit,item.Value.Product);
                    }
                }



        }
                
         

        private static void SelectUnit(string[] ingredienceInfo, Measurement item)
        {
            switch (ingredienceInfo[1].Trim())
            {
                case "milliliters": item.Unit = Measurement.VolumeType.milliliters; break;
                case "tablespoons": item.Unit = Measurement.VolumeType.tablespoons; break;
                case "teaspoons": item.Unit = Measurement.VolumeType.teaspoons; break;

                case "liters": item.Unit = Measurement.VolumeType.liters; break;
                case "cups": item.Unit = Measurement.VolumeType.cups; break;
                case "fluid ounces": item.Unit = Measurement.VolumeType.fluidounces; break;
                case "pints": item.Unit = Measurement.VolumeType.pints; break;
                case "quarts": item.Unit = Measurement.VolumeType.quarts; break;
                case "gallons": item.Unit = Measurement.VolumeType.gallons; break;
                case "mls": item.Unit = Measurement.VolumeType.mls; break;
                case "tbsps": item.Unit = Measurement.VolumeType.tbsps; break;
                case "tsps": item.Unit = Measurement.VolumeType.tsps; break;
                case "fl ozs": item.Unit = Measurement.VolumeType.flozs; break;
                case "ls": item.Unit = Measurement.VolumeType.ls; break;
                case "pts": item.Unit = Measurement.VolumeType.pts; break;
                case "qts": item.Unit = Measurement.VolumeType.qts; break;
                case "gals": item.Unit = Measurement.VolumeType.gals; break;


                default: Console.WriteLine("Wrong unit");
                    break;
            }
        }
    }
}
