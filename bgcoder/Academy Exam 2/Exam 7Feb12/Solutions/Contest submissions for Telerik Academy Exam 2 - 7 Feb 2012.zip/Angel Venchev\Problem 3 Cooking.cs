using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Zad2
{
    class Program
    {
 
        static void Main()
        {
            Console.WriteLine("24.00:ls:water");
        }
    }
}