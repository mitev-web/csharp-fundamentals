using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicLanguage
{
    class Program
    {
        static bool isInputEnd = false;
        static void FillListWithStrings(string input, List<string> stringList, string delimiter)
        {
            int startIndex = 0;
            int endIndex = input.IndexOf(delimiter);

            while (endIndex >= 0)
            {
                string strToBeAdded = input.Substring(startIndex, (endIndex + 1) - startIndex);
                stringList.Add(strToBeAdded);
                startIndex = endIndex + 1;
                endIndex = input.IndexOf(delimiter, startIndex);

                if (strToBeAdded.IndexOf("EXIT;") >= 0)
                {
                    isInputEnd = true;
                    //return on input
                    return;
                }
            }

            if (input.IndexOf("EXIT") >= 0)
            {
                stringList.Add("EXIT");
                //return when internal parse command, due to lack of ")" after exit
                return;
            }

        }

        static void RecursevlyExecution(List<string> commandsList, int currCommand)
        {
            if (commandsList[currCommand].IndexOf("EXIT") >= 0)
            {
                Console.WriteLine();
                return;
            }

            // Gets the string between ( and )
            string argument = commandsList[currCommand].Substring(
                commandsList[currCommand].IndexOf("(") + 1, commandsList[currCommand].IndexOf(")") - commandsList[currCommand].IndexOf("(") - 1);

            if (commandsList[currCommand].IndexOf("PRINT") >= 0)
            {
                Console.Write(argument);
                if (currCommand < commandsList.Count - 1)
                {
                    RecursevlyExecution(commandsList, currCommand + 1);
                }
            }
            else if (commandsList[currCommand].IndexOf("FOR") >= 0)
            {
                argument = argument.Replace(" ", "");
                int localRecursiveCounter = 0;
                
                int indexOfComma = argument.IndexOf(",");
                if (indexOfComma > 0)
                {
                    string[] locChArray = argument.Split(',');
                    localRecursiveCounter = int.Parse(locChArray[1]) - int.Parse(locChArray[0]) + 1;
                }
                else
                {
                    localRecursiveCounter = int.Parse(argument);
                }

                for (int i = 0; i < localRecursiveCounter; i++)
                {
                    RecursevlyExecution(commandsList, currCommand + 1);
                }
            }
        }

        static void ExecuteCommandsInLine(string command)
        {
            List<string> localCommands = new List<string>();

            FillListWithStrings(command, localCommands, ")");

            RecursevlyExecution(localCommands, 0);
        }

        static void Main(string[] args)
        {
            string inputStr = null;
            List<string> inputData = new List<string>();

            do
            {
                inputStr = Console.ReadLine();

                FillListWithStrings(inputStr, inputData, ";");

            } while (isInputEnd == false);

            foreach (string str in inputData)
            {
                ExecuteCommandsInLine(str);
            }
        }
    }
}
