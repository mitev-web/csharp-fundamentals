using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4_Slices
{
    class Slices
    {
        static int width;
        static int height;
        static int depth;
        static short[, ,] cuboid;

        static void Main(string[] args)
        {
            ReadCuboid();
            Console.Write(CheckSums());
        }

        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            // Read the cuboid content
            cuboid = new short[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
        }

        private static int[] SumDepth()
        {
            int[] result = new int[depth];
            int sum = 0;
            for (int i = 0; i < depth; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    for (int k = 0; k < height; k++)
                    {
                        sum += cuboid[j, k, i];
                    }
                }
                result[i] = sum;
                sum = 0;
            }
            return result;
        }

        private static int[] SumHeight()
        {
            int[] result = new int[height];
            int sum = 0;
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    for (int k = 0; k < depth; k++)
                    {
                        sum += cuboid[j, i, k];
                    }
                }
                result[i] = sum;
                sum = 0;
            }
            return result;
        }

        private static int[] SumWidth()
        {
            int[] result = new int[width];
            int sum = 0;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    for (int k = 0; k < depth; k++)
                    {
                        sum += cuboid[i, j, k];
                    }
                }
                result[i] = sum;
                sum = 0;
            }
            return result;
        }

        private static bool CheckSplits(int start,int[] input)
        {
            int sum1 = 0;
            int sum2 = 0;

            for (int i = 0; i < start; i++)
            {
                sum1 += input[i];
            }
            for (int i = start; i < input.Length; i++)
            {
                sum2 += input[i];
            }

            if (sum2 == sum1)
            {
                return true;
            }
            else return false;
        }

        private static int CheckSums()
        {
            int result = 0;
            int[] depthSum = SumDepth();
            int[] widthSum = SumWidth();
            int[] heightSum = SumHeight();

            for (int i = 1; i <= depthSum.Length - 1; i++)
            {
                if (CheckSplits(i,depthSum))
                {
                    result++;
                }
            }

            for (int i = 1; i <= widthSum.Length - 1; i++)
            {
                if (CheckSplits(i, widthSum))
                {
                    result++;
                }
            }

            for (int i = 1; i <= heightSum.Length - 1; i++)
            {
                if (CheckSplits(i, heightSum))
                {
                    result++;
                }
            }
            return result;

        }
    }
}