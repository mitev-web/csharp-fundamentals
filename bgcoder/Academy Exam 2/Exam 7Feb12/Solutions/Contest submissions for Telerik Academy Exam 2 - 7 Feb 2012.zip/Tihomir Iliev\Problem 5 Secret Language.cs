using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.SecretLanguage
{
    class SecretLanguage
    {
        static string sentence;
        static string[] words;
        static char[] word;
        static int cost = 0;
        static int[] used;
        static char[] permutation;
        static int length;
        static bool isWordFound = false;

        static void Permute(int position)
        {
            if (isWordFound == true)
            {
                return;
            }
            if (position == length)
            {
                int takeAway = 0;
                for (int i = 0; i < length; i++)
                {
                    if (word[i] != permutation[i])
                    {
                        takeAway++;                                                
                    }
                }
                CheckPermutation(takeAway);
                return;
            }

            for (int index = 0; index < length; index++)
            {
                if (used[index] == 0)
                {
                    permutation[position] = word[index];
                    used[index] = 1;
                    Permute(position + 1);
                    used[index] = 0;
                }
            }
        }

        static void PrintPermutation()
        {
            foreach (int element in permutation)
            {
                Console.Write((char)element);
            }
            Console.WriteLine();
        }

        static void CheckPermutation(int takeAway)
        {
            string perm = new string(permutation);
            int index = sentence.IndexOf(perm);
            if (index != -1)
            {
                sentence = sentence.Remove(index, perm.Length);
                cost += takeAway;
                isWordFound = true;                                
            }
        }

        static void Main(string[] args)
        {
            sentence = Console.ReadLine();
            words = Console.ReadLine().Split(new char[] { '"', ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            for (int everyWord = 0; everyWord < words.Length; everyWord++)
            {
                word = words[everyWord].ToCharArray();
                length = word.Length;
                used = new int[length];
                permutation = new char[length];
                isWordFound = false;
                Permute(0);
            }

            if (cost == 0)
            {
                Console.WriteLine(-1);
            }
            else
            {
                Console.WriteLine(cost);
            }            
        }
    }
}