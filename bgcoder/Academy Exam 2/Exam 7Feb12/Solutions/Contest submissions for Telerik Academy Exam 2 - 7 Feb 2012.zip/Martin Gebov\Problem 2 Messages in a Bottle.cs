using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class MessagesInABottle
{
    static string secretMessage = Console.ReadLine();
    static string cypher = Console.ReadLine();
    static List<string> letters = new List<string>();
    static List<string> digits = new List<string>();
    static List<string> codes = new List<string>();
    static void Main(string[] args)
    {
        Separate();
        Decypher();
        Print();
    }

    private static void Print()
    {
        var distinctElements = codes.Distinct();
        var orderedElements = distinctElements.OrderBy(x => x);

        Console.WriteLine(distinctElements.Count());
        if (distinctElements.Count() > 0)
        {
            foreach (var item in orderedElements)
            {
                Console.WriteLine(item);
            }
        }
    }
    static void Separate()
    {
        string number = "";
        bool digitFound = false;
        for (int i = 0; i < cypher.Length; i++)
        {

            if (char.IsLetter(cypher[i]))
            {
                letters.Add(cypher[i].ToString());
                if (digitFound)
                {
                    digits.Add(number);
                    number = "";
                }
            }
            else
            {
                number += cypher[i];
                digitFound = true;
                if (i == cypher.Length - 1)
                {
                    digits.Add(number);
                }
            }
        }
    }

    static void Decypher()
    {
        bool containsDigits = false;

        string currentValue = secretMessage;
        for (int j = 0; j < digits.Count; j++)
        {
            currentValue = secretMessage;
            currentValue = currentValue.Replace(digits[j], letters[j]);
            for (int i = 0; i < digits.Count; i++)
            {
                currentValue = currentValue.Replace(digits[i], letters[i]);
            }
            if (!currentValue.Equals(secretMessage))
            {
                for (int i = 0; i < currentValue.Length; i++)
                {
                    if (char.IsDigit(currentValue[i]))
                    {
                        containsDigits = true;
                        break;
                    }
                }
                if (!containsDigits)
                {
                    codes.Add(currentValue);
                }
                containsDigits = false;
            }
        }
    }
}

