using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagesInABottle
{
    class MessagesInABottle
    {
        static List<string> ans = new List<string>();
        static string code="";
        static string[] letters = new string[27];
        static string letter="";
        static string [] shemi = new string[13];
        static int len;
        static void print()
        {
            Console.WriteLine(ans.Count);
            ans.Sort();
            foreach (string s in ans)
            {
                Console.WriteLine(s);
            }
        }
        static int br = 0;
        static void prov(int ll)
        {
            br++;
            bool flag1 = true;
            bool flag2 = false;
            string temp = "";
            for (int i = 0; i < ll; i++)
            {
                flag2 = false;
                for (int j = 0; j < 26; j++)
                {
                    if (shemi[i] == letters[j])
                    {
                        flag2 = true;
                        char ch = (char)('A' + j);
                        temp += ch;
                        break;
                    }
                }
                if (flag2 == false)
                {
                    flag1 = false;
                    break;
                }
            }
            if (flag1 == true)
            {
                ans.Add(temp);
            }
        }


        static void func(int i,int j)
        {
            if(i>=len)
            {
                prov(j);
                return;
            }
            for (int k = i; k < len; k++)
            {
                shemi[j] += code[k];
                func(k + 1, j + 1);
            }
            shemi[j] = "";
        }
        static void Main(string[] args)
        {
            code = Console.ReadLine();
            len = code.Length;
            letter = Console.ReadLine();
            string temp="";
            for(int i=0;i<letter.Length;i++)
            {
                if (letter[i] >= 'A' && letter[i] <= 'Z')
                {
                    for (int j = i + 1; j < letter.Length; j++)
                    {
                        if (letter[j] >= '0' && letter[j] <= '9')
                        {
                            temp += letter[j];
                        }
                        else break;
                    }
                    letters[letter[i] - 'A'] = temp;
                    temp = "";
                }
            }
           
            func(0, 0);
            print();
            //Console.WriteLine(br);
        }
    }
}
