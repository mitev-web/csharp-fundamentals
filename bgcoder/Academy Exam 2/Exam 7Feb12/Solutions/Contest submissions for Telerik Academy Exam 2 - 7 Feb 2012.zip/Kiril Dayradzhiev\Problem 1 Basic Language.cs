using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace BasicLanguage
{
    class Program
    {
        static string input;
        static StringBuilder finalResult = new StringBuilder();
        static StringBuilder some = new StringBuilder();
        static bool inLoop = false;
        static int cicles = 1;
        static void Main(string[] args)
        {
            string someInput;
            while (true)
            {
                someInput = Console.ReadLine();
                input+=someInput;
                if (someInput.LastIndexOf("EXIT;") != -1)
                {
                    break;
                }
            }
            //input = "FOR   (1 ,  5  )     PRINT(ha)    ;   FOR(2)FOR(2,3)PRINT(xi);PRINT(i);EXIT;";
            Func(0);
        }
  
        static void Func(int current)
        {
            if (current == input.Length - 1)
            {
                Console.WriteLine(finalResult);
                Environment.Exit(0);
            }
            if (some.ToString().Equals("EXIT"))
            {
                Console.WriteLine(finalResult);
                Environment.Exit(0);
            }
            else if (some.ToString().Equals("FOR"))
            {
                int indexOfOpenBracket = input.IndexOf('(', current);
                int indexOfCloseBracket = input.IndexOf(')', current + 1);
                string[] numbers = input.Substring(indexOfOpenBracket + 1, indexOfCloseBracket - (indexOfOpenBracket + 1)).Split(new char[2] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
                some.Clear();
                current = indexOfCloseBracket;
                  
                if (numbers.Length == 1)
                {
                    if (inLoop)
                    {
                        cicles = cicles *( int.Parse(numbers[0]));
                        Func(current + 1);
                    }
                    else
                    {
                        inLoop = true;
                        cicles =  int.Parse(numbers[0]);
                        Func(current + 1);
                    }
                    cicles = 1;
                }
                else
                {
                    if (inLoop)
                    {
                        cicles = cicles*(int.Parse(numbers[1]) - int.Parse(numbers[0]) + 1);
                        Func(current + 1);
                    }
                    else
                    {
                        inLoop = true;
                        cicles = int.Parse(numbers[1]) - int.Parse(numbers[0]) + 1;
                        Func(current + 1);
                    }
                    cicles = 1;
                }
            }
            else if (some.ToString() == "PRINT")
            {
                int indexOfOpenBracket = input.IndexOf('(', current);
                int indexOfCloseBracket = input.IndexOf(')', current + 1);
                if (inLoop)
                {
                    for (int i = 0; i < cicles; i++)
                    {
                        finalResult.Append(input.Substring(indexOfOpenBracket + 1, indexOfCloseBracket - current - 1));
                    }
                }
                else
                {
                    finalResult.Append(input.Substring(indexOfOpenBracket + 1, indexOfCloseBracket - current - 1));
                }
                inLoop = false;
                current = indexOfCloseBracket;
                some.Clear();
                Func(current + 1);
                  
            }
            else if (input[current] != ';' && input[current] != '\n' && input[current] != '\r' && input[current] != ' ')
            {
                some.Append(input[current]);
                Func(current + 1);
            }
            else
            {
                Func(current + 1);
            }
        }
    }
}