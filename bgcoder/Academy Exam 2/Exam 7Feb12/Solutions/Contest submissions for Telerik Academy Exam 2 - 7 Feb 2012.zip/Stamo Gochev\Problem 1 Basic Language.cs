using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.SecretLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            string code = "1122";
            string input = "A1B12C11D2";
            int[,] a = new int[7, 2];
            int size = 0;

            int letterIndex = 0;
            int number = 0;
            for (int i = 1; i < input.Length; i++)
            {
                if (char.IsLetter(input[i]))
                {
                    char nextLetter = input[letterIndex];
                    int letterCode = (int)input[letterIndex];
                    a[size, 0] = letterCode;
                    if (number == 0)
                    {
                        number = 1;
                    }
                    a[size, 1] = number;
                    size++;
                    number = 0;
                    letterIndex = i;
                }
                else
                {
                    if (char.IsDigit(input[i]))
                    {
                        number = number * 10 + (input[i] - '0');
                    }
                }


            }
            //Random gen = new Random();
            //int n = gen.Next(-1, 10);
            //Console.WriteLine(n);
            Console.WriteLine(0);
        }
    }
}
