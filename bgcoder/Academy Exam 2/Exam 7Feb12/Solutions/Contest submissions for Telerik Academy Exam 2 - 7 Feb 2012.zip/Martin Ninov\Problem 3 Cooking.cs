using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P3_Cooking
{
    

    class Program
    {
        public struct Ingredient
        {
            public double Value;
            public string Measure;
            public string Type;

            public double Amount
            {
                get
                {
                    return this.Value / ConversionTable[this.Measure.ToLower()];
                }
                set
                {
                    this.Value = value * ConversionTable[this.Measure.ToLower()];
                }
            }

            public Ingredient(double howMuch, string mag, string ofWhat)
            {
                Measure = mag;
                Type = ofWhat;
                Value = 0;//howMuch * ConversionTable[this.Measure.ToLower()];
                Amount = howMuch;
            }
        }

        static void Main(string[] args)
        {
            initConversionTable();

            Dictionary<string, Ingredient> Recipy = new Dictionary<string, Ingredient>();// { new Ingredient(1.006, "ls", "old milk") };
            Dictionary<string, Ingredient> Input = new Dictionary<string, Ingredient>();// { new Ingredient(800, "mls", "old milk") };
            //Recipy.Add("old MILK".ToLower(), new Ingredient(1.006, "ls", "old MILK"));
            //Input.Add("OLD milk".ToLower(), new Ingredient(800, "mls", "OLD milk"));
            Dictionary<string, Ingredient> Output;
            
            
            string read;
            string[] split;
            List<string> recipyKeys = new List<string>();

            read = Console.ReadLine();
            int recipyCount = int.Parse(read);
            for (int i = 0; i < recipyCount; i++)
            {
                read = Console.ReadLine();
                split = read.Split(':');
                try
                {
                    if (!Recipy.ContainsKey(split[2].ToLower()))
                    {
                        Recipy.Add(split[2].ToLower(), new Ingredient(double.Parse(split[0]), split[1], split[2]));
                        recipyKeys.Add(split[2].ToLower());
                    }
                    else
                    {
                        Ingredient temp = Recipy[split[2].ToLower()];
                        temp.Value += double.Parse(split[0]) * ConversionTable[split[1]];
                        Recipy.Remove(split[2].ToLower());
                        Recipy.Add(split[2].ToLower(), temp);
                    }
                }
                catch (KeyNotFoundException)
                {
                }
                
            }

            read = Console.ReadLine();
            int inputCount = int.Parse(read);
            for (int i = 0; i < inputCount; i++)
            {
                read = Console.ReadLine();
                split = read.Split(':');
                try
                {
                    if (!Input.ContainsKey(split[2].ToLower()))
                    {
                        Input.Add(split[2].ToLower(), new Ingredient(double.Parse(split[0]), split[1], split[2]));
                    }
                    else
                    {
                        Ingredient temp = Input[split[2].ToLower()];
                        temp.Value += double.Parse(split[0]) * ConversionTable[split[1]];
                        Input.Remove(split[2].ToLower());
                        Input.Add(split[2].ToLower(), temp);
                    }
                }
                catch (KeyNotFoundException)
                {
                }
                
            }

            Output = GetMissingIngridients(Recipy, Input);

            foreach (var item in recipyKeys)
            {
                if(Output.ContainsKey(item))
                    Console.WriteLine("{0:f2}:{1}:{2}", Output[item].Amount, Output[item].Measure, Output[item].Type);
            }
        }



        public static Dictionary<string, Ingredient> GetMissingIngridients(Dictionary<string, Ingredient> Recipy, Dictionary<string, Ingredient> Input)
        {
            Dictionary<string, Ingredient> result = new Dictionary<string, Ingredient>();
            foreach (var item in Recipy)
            {
                if (Input.ContainsKey(item.Key))
                {
                    if (Input[item.Key].Value < item.Value.Value)
                    {
                        result.Add(item.Value.Type.ToLower(), new Ingredient((item.Value.Value - Input[item.Key].Value) / ConversionTable[item.Value.Measure], item.Value.Measure, item.Value.Type));
                    }
                }
                else
                {
                    result.Add(item.Value.Type.ToLower(), new Ingredient(item.Value.Amount, item.Value.Measure, item.Value.Type));
                }
            }
            return result;
        }

        public static Dictionary<string, double> ConversionTable;

        public static void initConversionTable()
        {
            ConversionTable = new Dictionary<string, double>();

            ConversionTable.Add("mls", 1);
            ConversionTable.Add("milliliters", 1);

            ConversionTable.Add("ls", 1000 * ConversionTable["mls"]);
            ConversionTable.Add("liters", ConversionTable["ls"]);

            ConversionTable.Add("tsps", 5*ConversionTable["mls"]);
            ConversionTable.Add("teaspoons", ConversionTable["tsps"]);

            ConversionTable.Add("tbsps", 3 * ConversionTable["tsps"]);
            ConversionTable.Add("tablespoons", ConversionTable["tbsps"]);

            ConversionTable.Add("cups", 48 * ConversionTable["tsps"]);

            ConversionTable.Add("pts", 2 * ConversionTable["cups"]);
            ConversionTable.Add("pints", ConversionTable["pts"]);

            ConversionTable.Add("qts", 2 * ConversionTable["pts"]);
            ConversionTable.Add("quarts", ConversionTable["qts"]);

            ConversionTable.Add("gals", 4 * ConversionTable["qts"]);
            ConversionTable.Add("gallons", ConversionTable["gals"]);

            ConversionTable.Add("fl ozs", ConversionTable["cups"] / 8);
            ConversionTable.Add("fluid ounces", ConversionTable["fl ozs"]);
        }
    }
}
