using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2_2
{
    class Program
    {
        static void Main(string[] args)
        {

            //string line1 = "1122";
           // string line2 = "A1B12C11D2";
            string line1 = Console.ReadLine();
            string line2 = Console.ReadLine();
            StringBuilder letter = new StringBuilder();
            StringBuilder digit = new StringBuilder();
            StringBuilder answersSB = new StringBuilder();
            Dictionary<string, string>  dictionary = new Dictionary<string, string>();
            List<string> answers = new List<string>();
            bool first = true;
            for (int i = 0; i < line2.Length; i++)
            {
                if (line2[i] == '0' || line2[i] == '1' || line2[i] == '2' || line2[i] == '3' || line2[i] == '4' || line2[i] == '5' || line2[i] == '6' || line2[i] == '7' || line2[i] == '8' || line2[i] == '9')
                {
                    digit.Append(line2[i]);
                }
                else
                {
                    if (!first)
                    {
                        dictionary.Add(digit.ToString(), letter.ToString());
                        letter.Clear();
                        digit.Clear();
                    }
                    first = false;
                    letter.Append(line2[i]);
                }
            }
            dictionary.Add(digit.ToString(), letter.ToString());
            letter.Clear();
            digit.Clear();
            string value = "";
            List<KeyValuePair<string, string>> tt = new List<KeyValuePair<string, string>>();
            for (int i = 0; i < line1.Length; i++)
            {
                answersSB.Append(line1[i]);
                for (int j = i+1; j < line1.Length; j++)
                {
                    
                    if (dictionary.ContainsKey(answersSB.ToString()))
                    {
                        //Console.WriteLine(dictionary[answersSB.ToString()]);
                        tt.Add(new KeyValuePair<string, string>(answersSB.ToString(), dictionary[answersSB.ToString()]));
                    }
                    answersSB.Append(line1[j]);
                }
                if (dictionary.ContainsKey(answersSB.ToString()))
                {
                    //Console.WriteLine(dictionary[answersSB.ToString()]);
                    tt.Add(new KeyValuePair<string, string>(answersSB.ToString(), dictionary[answersSB.ToString()]));
                }
                answersSB.Clear();
            }
            int bit = 0;
            //foreach (KeyValuePair<string, string> item in tt)
            //{
            //    Console.WriteLine(item.Key);
            //    Console.WriteLine(item.Value);
            //}
            for (int i = 1; i < Math.Pow(2, tt.Count); i++)
            {
                
                for (int j = 0; j < tt.Count; j++)
                {
                    bit = ((i >> j) & 1);
                   // Console.Write(bit);
                    if (bit == 1)
                    {
                        digit.Append(tt[j].Key);
                        letter.Append(tt[j].Value);
                    }
                }
                if (digit.ToString() == line1)
                {
                    if (!answers.Contains(letter.ToString()))
                    {
                        answers.Add(letter.ToString());
                    }
                }
                //Console.WriteLine();
                letter.Clear();
                digit.Clear();
            }
            answers.Sort();
            Console.WriteLine(answers.Count);
            foreach (string answ in answers)
            {
                Console.WriteLine(answ);
            }


        }
    }
}
