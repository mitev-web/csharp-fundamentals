using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1BasicLanguage
{
    class BasicLanguage
    {
        static void Main(string[] args)
        {
            string[] input = new string[10000];
            int counter = 0;
            int iterations = 0;
            for (int i = 0; i < 10000; i++)
            {
                input[i] = Console.ReadLine();
                iterations++;
                if (input[i] == "EXIT;") break;
            }
            string[] numbers;
            for (counter = 0; counter < iterations; counter++)
            {
                string[] commands = ExtractCommands(input[counter]);
                for (int i = 0; i < commands.Length; i++)
                {
                    if (commands[i] == "FOR")
                    {
                        numbers = ExtractNumbers(input[counter].Substring(input[counter].IndexOf("FOR") + 3, input[counter].IndexOf(")") - input[counter].IndexOf("(")));
                        if (input[counter].IndexOf("FOR") != -1)
                        {
                            input[counter] = input[counter].Remove(0, input[counter].IndexOf(")") + 1);
                        }
                        if (numbers.Length == 1)
                        {
                            ForFunc(int.Parse(numbers[0]), i + 1, commands, input[counter]);
                        }
                        else
                        {
                            ForFunc(int.Parse(numbers[0]), int.Parse(numbers[1]), i + 1, commands, input[counter]);
                        }
                        break;
                    }
                    if (commands[i] == "PRINT")
                    {
                        PrintFunc(input[counter]);
                    }
                    if (commands[i] == "EXIT")
                    {
                        ExitFunc();
                    }
                }
            }
        }
        static void PrintFunc(string s)
        {
            Console.Write(s.Substring(s.LastIndexOf("PRINT") + 6).Trim(';', ')'));
        }
        static void ForFunc(int a, int i, string[] commands, string input)
        {
            string[] numbers;
            for (int k = 0; k < a; k++)
            {
                if (commands[i] == "FOR")
                {
                    numbers = ExtractNumbers(input.Substring(input.IndexOf("FOR") + 3, input.IndexOf(")") - input.IndexOf("(")));
                    //if (input.IndexOf("FOR") != -1)
                    //{
                    //    input = input.Remove(0, input.IndexOf(")")+ 1);
                    //}
                    if (numbers.Length == 1)
                    {
                        ForFunc(int.Parse(numbers[0]), ++i, commands, input);
                        i--;
                    }
                    else
                    {
                        ForFunc(int.Parse(numbers[0]), int.Parse(numbers[1]), ++i, commands, input);
                        i--;
                    }
                }
                if (commands[i] == "PRINT")
                {
                    PrintFunc(input);
                }
                if (commands[i] == "EXIT")
                {
                    ExitFunc();
                }
            }
        }
        static void ForFunc(int a, int b, int i, string[] commands, string input)
        {
            string[] numbers;
            for (int k = 0; k < b - a + 1; k++)
            {
                if (commands[i] == "FOR")
                {
                    numbers = ExtractNumbers(input.Substring(input.IndexOf("FOR") + 3, input.IndexOf(")") - input.IndexOf("(")));
                    //if (input.IndexOf("FOR") != -1)
                    //{
                    //    input = input.Remove(0, input.IndexOf(")") + 1);
                    //}
                    if (numbers.Length == 1)
                    {
                        ForFunc(int.Parse(numbers[0]), ++i, commands, input);
                        i--;
                    }
                    else
                    {
                        ForFunc(int.Parse(numbers[0]), int.Parse(numbers[1]), ++i, commands, input);
                        i--;
                    }
                }
                if (commands[i] == "PRINT")
                {
                    PrintFunc(input);
                }
                if (commands[i] == "EXIT")
                {
                    ExitFunc();
                }
            }
        }
        static void ExitFunc()
        {
            return;
        }
        static string[] ExtractNumbers(string expr)
        {
            expr = expr.Trim(' ');
            //  string input = expr.Substring(expr.IndexOf("FOR"), 10);
            string[] separators = { "(", ")", ",", "A", "B", "C", "D", "E", "F", "G", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", ";" };
            string[] numbers = expr.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = numbers[i].Trim();
            }
            return numbers;
        }
        static string[] ExtractCommands(string expr)
        {
            expr = expr.Trim();
            string[] separators = { "(", ")", ",", ";", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "-" };
            string[] commands = expr.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            return commands;
        }
    }
}