using System;

namespace Exam
{
    class Task1
    {
        static int For( string input )
        {
            int check = input.IndexOf ( ',' );
            if ( check == -1 )
            {
                return Int32.Parse ( input );
            }
            else
            {
                string[]nums = input.Split ( ',' );
                return ( Int32.Parse ( nums[1] ) - Int32.Parse ( nums[0] ) + 1 );
            }
        }

        static void ParseItem( string item )
        {
            string input = item.Trim ();
            int closeBracket;
            if ( input[0].ToString () == "P" )
            {
                Console.Write ( input.Substring ( 6, input.IndexOf ( ')' )-6 ) );
                return;
            }
            if ( item.IndexOf ( "PRINT" ) == -1 )
                return;
            int prod = 1;
            while ( input[0].ToString () == "F" )
            {
                closeBracket = input.IndexOf ( ')' );
                prod *= For ( input.Substring ( 4, closeBracket-4 ) );
                input = input.Substring ( closeBracket+1 ).Trim ();
            }
            for ( int i = 0; i < prod; i++ )
                Console.Write ( input.Substring ( 6, input.IndexOf ( ')' )-6 ) );
        }

        static void Parse( string input )
        {
            int pos;
            while ( ( pos = input.IndexOf ( ");" ) ) >= 0 )
            {
                ParseItem ( input.Substring ( 0, pos+1 ).Trim () );
                input = input.Substring ( pos + 2 );
            }
        }

        static void Main( string[] args )
        {
            Parse ( Console.ReadLine () );
        }
    }
}