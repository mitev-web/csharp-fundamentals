using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex1_BasicLanguage
{
    class Program
    {
        static int repeats = 0;
        static int i;
        static string ReadCommand(StringBuilder code)
        {
            string command = "";
            for ( i= i; i< i+5; i++)
            {
                while (char.IsLetter(code[i]))
                {
                    command = command + code[i];
                    i++;
                }
                if (command +';'=="EXIT;")
                {
                    return "EXIT;";
                }
                if (command == "PRINT")
                {
                    return "PRINT"; 
                }
                if (command == "FOR")
                {
                    return "FOR"; 
                }
            }
             return "1";
        }
        static void FORcommand(StringBuilder code)
        {
            Loops(code);
            for (int j = 0; j < repeats; j++)
            {
                switch (ReadCommand(code))
                {
                    case "FOR": FORcommand(code); break;
                    case "PRINT": PRINTcommand(code); break;
                    default: break;
                }
            }
        }
        
        static void Loops(StringBuilder code)
        {
            repeats = 0;
            int a = 0;
            int b = 0;
            do
            {
                i++;
            }
            while (code[i] == '(');         //search for opening bracket
            if (!char.IsDigit(code[i]))
            {
                do
                {
                    i++;
                }
                while (code[i] == (char)(32));
            }
            do
            {
                a = a * 10 + (code[i] - '0');
                i++;
            }
            while (char.IsDigit(code[i]));
            i++;
            if (!char.IsDigit(code[i]))
            {
                do
                {
                    i++;
                }
                while (code[i] == (char)(32));
            }
            i++;
            if (code[i] == ',')
            {
                if (!char.IsDigit(code[i]))
                {
                    do
                    {
                        i++;
                    }
                    while (code[i] == (char)(32));
                    i++;
                }
                do
                {
                    b = b * 10 + (code[i] - '0');
                    i++;
                }
                while (char.IsDigit(code[i]));
                i++;
            }
            if (b == 0)
            {
                repeats=  a;
            }
            else
            {
                repeats =b - a + 1;
            }
        }
        static void PRINTcommand(StringBuilder code)
        {
            i++;
            do
            {
                Console.Write(code[i]);
                i++;
            }
            while (code[i] != ')');

        }
        static void Main(string[] args)
        {
            
            StringBuilder code = new StringBuilder(100000);
            char ch;
            do
            {
                ch=(char)Console.ReadLine();
                code.Append(ch);
            } while(ch!=-1);
            Console.WriteLine(code);
            string command = "";
            bool check = true;
            do
            {
                command=ReadCommand(code);
                if (command == "EXIT;")
                {
                    break;
                }
                switch (command)
                {
                    case "FOR": FORcommand(code); break;
                    case "PRINT": PRINTcommand(code);  break;
                    case "EXIT;": check = false; break;
                    default: break;
                }
                
            }
            while(check);     
            


        }
    }
}
