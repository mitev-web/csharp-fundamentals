using System;
using System.Text;

class BasicLanguage
{
    private static StringBuilder output = new StringBuilder();
    private static StringBuilder command = new StringBuilder();
    private static StringBuilder printText = new StringBuilder();

    static void Main(string[] args)
    {
        /*
         * PRINT(); all but ")"
         * FOR(a)   a times
         * FOR(a,b) b-a+1 times
         * EXIT;
        */
        int code;
        long count = 1;
        while (true)
        {
            code = Console.Read();
            if (code == ' ' || code == 13 || code == 10)
            {
                continue;
            }
            if (code != '(')
            {
                if (code == ';')
                {
                    if (command.ToString() == "EXIT")
                    {
                        break;
                    }
                    command.Clear();
                    count = 1;
                }
                else
                {
                    command.Append((char)code);
                }
            }
            else
            {
                if (command.ToString() == "PRINT")
                {
                    printText.Clear();
                    Print();
                    for (long i = 1; i <= count; i++)
                    {
                        output.Append(printText.ToString());
                    }
                    command.Clear();
                    continue;
                }
                if (command.ToString() == "FOR")
                {
                    count *= For();
                    command.Clear();
                    continue;
                }
                command.Clear();
            }
        }
        Console.WriteLine(output.ToString());
    }

    static void Print()
    {
        int code = Console.Read();
        while (code != ')')
        {
            printText.Append((char)code);
            code = Console.Read();
        }
    }

    static long For()
    {
        int code;
        long a = 0, b = 0;
        bool minus = false;
        while (true)
        {
            code = Console.Read();
            if (code == '-')
            {
                minus = true;
            }
            if (code >= '0' && code <= '9')
            {
                a *= 10;
                a += code - '0';
            }
            else
            {
                if (code == ',')
                {
                    a *= (minus) ? -1 : 1;
                    minus = false;
                    while (true)
                    {
                        code = Console.Read();
                        if (code == '-')
                        {
                            minus = true;
                        }
                        if (code >= '0' && code <= '9')
                        {
                            b *= 10;
                            b += code - '0';
                        }
                        else
                        {
                            if (code == ')')
                            {
                                b *= (minus) ? -1 : 1;
                                break;
                            }
                        }
                    }
                }
                if (code == ')')
                {
                    break;
                }
            }
        }
        return (a >= b) ? a : b - a + 1;
    }
}