using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicLanguage
{
    class BasicLanguage
    {

        static List<string> s = new List<string>();
        static int times = 1;
        static void read()
        {
            string temp;
            while (true)
            {
                temp = Console.ReadLine();
                s.Add(temp);
                if (temp.IndexOf("EXIT") != -1) break;
            }
        }

        static void print(string temp)
        {
            for (int i = 0; i < times; i++)
            {
                Console.Write(temp);
            }
        }
        static void Main(string[] args)
        {
            read();
            string temp = "";
            int inds1, inds2, inde1, inde2;
            for (int i = 0; i < s.Count; i++)
            {
                for (int j = 0; j < s[i].Length; j++)
                {
                    if (s[i][j] == 'F')
                    {
                        int ot = 0, doo = 0, indzape = -1;
                        inds1 = i;
                        inds2 = s[i].IndexOf('(', j);
                        inde1 = i;
                        inde2 = s[i].IndexOf(')', j);
                        bool minus = false;
                        if (inds2 == -1)
                        {
                            
                                for (int k = i + 1; k < s.Count(); k++)
                                {
                                    inds2 = s[k].IndexOf('(');
                                    inds1 = k;
                                    if (inds2 != -1) break;
                                }
                            
                        }
                        if (inde2 == -1)
                        {
                                for (int k = i + 1; k < s.Count(); k++)
                                {
                                    inde2 = s[k].IndexOf(')');
                                    inde1 = k;
                                    if (inde2 != -1) break;
                                }
                            
                        }

                        for (int ss = inds1; ss < s.Count; ss++)
                        {
                            if (ss > inde1) break;
                            for (int ff = 0; ff < s[ss].Length; ff++)
                            {
                                if (ss > inde1) break;
                                if (ss == inde1 && ff >= inde2) break;

                                if ((ss == inds1 && ff > inds2) || ss > inds1)
                                {
                                    if (s[ss][ff] == '-') minus = true;
                                    if (s[ss][ff] >= '0' && s[ss][ff] <= '9' && indzape == -1)
                                    {
                                        ot *= 10;
                                        ot += s[ss][ff] - '0';
                                    }

                                    if (s[ss][ff] == ',')
                                    {
                                        indzape = ff;
                                        if(minus==true)ot *= -1;
                                        minus = false;
                                    }

                                    if (s[ss][ff] >= '0' && s[ss][ff] <= '9' && indzape != -1)
                                    {
                                        doo *= 10;
                                        doo += s[ss][ff] - '0';
                                    }
                                }
                            }
                        }
                        i = inde1;
                        j = inde2;
                        if (indzape != -1)
                        {
                            if (minus == true) doo *= -1;
                            minus = false;
                            times *= (doo - ot + 1);
                        }
                        else
                        {
                            times *= ot;
                        }

                    }

                    if (s[i][j] == ';') times = 1;

                    if (s[i][j] == 'P')
                    {
                        inds1 = i;
                        inds2 = s[i].IndexOf('(', j);
                        inde1 = i;
                        inde2 = s[i].IndexOf(')', j);
                        if (inds2 == -1)
                        {
                            
                                for (int k = i + 1; k < s.Count(); k++)
                                {
                                    inds2 = s[k].IndexOf('(');
                                    inds1 = k;
                                    if (inds2 != -1) break;
                                }
                            
                        }
                        if (inde2 == -1)
                        {
                                for (int k = i + 1; k < s.Count(); k++)
                                {
                                    inde2 = s[k].IndexOf(')');
                                    inde1 = k;
                                    if (inde2 != -1) break;
                                }
                        }

                        for (int ss = inds1; ss < s.Count; ss++)
                        {
                            if (ss > inde1) break;
                            if (temp != "") temp += '\n';
                            for (int ff = 0; ff < s[ss].Length; ff++)
                            {
                                if (ss > inde1) break;
                                    if(ss == inde1 && ff >= inde2) break;

                                if ((ss == inds1 && ff > inds2) || ss > inds1)
                                {
                                    temp += s[ss][ff];
                                }
                            }
                        }
                        print(temp);
                        temp = "";
                        i = inde1;
                        j = inde2;
                    }


                }
            }
        }
    }
}