using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.Cooking
{
    class CookingException : ApplicationException
    {
    }
    class Cooking
    {
        struct MeasureRecord
        {
            public string fromMeasure;
            public string to;
            public double convertCoeff;

            public MeasureRecord(string from, string to, double convertCoeff)
            {
                this.fromMeasure = from;
                this.to = to;
                this.convertCoeff = convertCoeff;
            }
        }


        class MeasureConverter
        {
            public static readonly string[] NormalizedMeasures = new string[]
            {
                "tablespoons", "teaspoons", "liters", "milliliters", "fluid ounces", "gallons", "quarts", "pints", "cups",
            };
            static readonly MeasureRecord[] measuresTable = new MeasureRecord[]
            {
                new MeasureRecord("gallons", "liter", 96.0 / 25),
                new MeasureRecord("gallons", "quarts", 4),
                new MeasureRecord("gallons", "pints", 8),
                new MeasureRecord("gallons", "cups", 16),
                new MeasureRecord("gallons", "fluid ounces", 16 * 8),
                new MeasureRecord("gallons", "teaspoons", 16 * 48),
                new MeasureRecord("gallons", "tablespoons", 16 * 48 * (1 / 3.0)),
                new MeasureRecord("gallons", "milliliters", 16 * 48 * 5),
                new MeasureRecord("gallons", "liters", (16 * 48 * 5) / 1000.0),
                new MeasureRecord("quarts", "pints", 2),
                new MeasureRecord("quarts", "cups", 4),
                new MeasureRecord("quarts", "fluid ounces", 32),
                new MeasureRecord("quarts", "teaspoons", 4 * 48),
                new MeasureRecord("quarts", "tablespoons", 4 * 48 * (1 / 3.0)),
                new MeasureRecord("quarts", "milliliters", 4 * 48 * 5),
                new MeasureRecord("quarts", "liters", ( 4 * 48 * 5) / 1000.0),
                new MeasureRecord("pints", "cups", 2),
                new MeasureRecord("pints", "fluid ounces", 16),
                new MeasureRecord("pints", "teaspoons", 96),
                new MeasureRecord("pints", "tablespoons", 96 * (1.0 / 3)),
                new MeasureRecord("pints", "milliliters", 96 * 5),
                new MeasureRecord("pints", "liters", 96 / 200.0),
                new MeasureRecord("cups", "fluid ounces", 8),
                new MeasureRecord("cups", "teaspoons", 48),
                new MeasureRecord("cups", "tablespoons", 16),
                new MeasureRecord("cups", "milliliters", 48 * 5),
                new MeasureRecord("cups", "liters", 48 / 200.0),
                new MeasureRecord("teaspoons", "tablespoons", 1 / 3.0),
                new MeasureRecord("teaspoons", "milliliters", 5),
                new MeasureRecord("teaspoons", "liters", 1 / 200.0),
                new MeasureRecord("teaspoons", "fluid ounces", 1 / 6.0),
                new MeasureRecord("tablespoons", "fluid ounces", 1 / 2.0),
                new MeasureRecord("tablespoons", "milliliters", 15),
                new MeasureRecord("tablespoons", "liters", 15 / 1000.0),
                new MeasureRecord("liters", "milliliters", 1000),
                new MeasureRecord("milliliters", "fluid ounces", 1 / 30.0),
                new MeasureRecord("liters", "fluid ounces", 100 / 3.0),
            };

            public static double ConvertMeasure(string from, string to, double amount)
            {
                from = Normalize(from);
                to = Normalize(to);

                if (from.CompareTo(to) == 0)
                {
                    return amount;
                }
                foreach (var record in measuresTable)
                {
                    if (record.fromMeasure.CompareTo(from) == 0 && record.to.CompareTo(to) == 0)
                    {
                        return record.convertCoeff * amount;
                    }
                    else if (record.fromMeasure.CompareTo(to) == 0 && record.to.CompareTo(from) == 0)
                    {
                        return amount / record.convertCoeff;
                    }
                }
                throw new CookingException();
            }

            public static string Normalize(string measure)
            {
                switch (measure)
                {
                    case "tbsps": return "tablespoons";
                    case "tsps": return "teaspoons";
                    case "ls": return "liters";
                    case "fl ozs": return "fluid ounces";
                    case "mls": return "milliliters";
                    case "gals": return "gallons";
                    case "pts": return "pints";
                    case "qts": return "quarts";
                    default:
                        return measure;
                }
            }
        }

        class Ingredient : IEquatable<Ingredient>
        {
            public readonly string Name;
            public double Amount;
            public string BaseMeasurement;

            public Ingredient(string name, double amount, string measurement)
            {
                this.Name = name;
                this.Amount = amount;
                this.BaseMeasurement = measurement;
            }

            public Ingredient(string inputConsole)
            {
                string[] meaningParts = inputConsole.Split(':');

                this.Amount = Convert.ToDouble(meaningParts[0]);
                this.BaseMeasurement = meaningParts[1];
                this.Name = meaningParts[2];
            }
            public bool Equals(Ingredient secondIngr)
            {
                if (this.Name.ToLower().CompareTo(secondIngr.Name.ToLower()) == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public override string ToString()
            {
                return String.Format("{0:0.00}:{1}:{2}", this.Amount, this.BaseMeasurement, this.Name);
            }
        }

        static List<Ingredient> GetIngredients()
        {
            int amountOfIngr = Convert.ToInt32(Console.ReadLine());
            List<Ingredient> recipe = new List<Ingredient>();
            for (int counter = 0; counter < amountOfIngr; counter++)
            {
                string line = Console.ReadLine();
                Ingredient currentIngr = new Ingredient(line);
                int index = recipe.IndexOf(currentIngr);
                if (index == -1)
                {
                    recipe.Add(currentIngr);
                }
                else
                {
                    string recipeMeasurement = recipe[index].BaseMeasurement.ToLower();
                    string itemMeasurement = currentIngr.BaseMeasurement.ToLower();
                    if (recipe[index].BaseMeasurement.CompareTo(currentIngr.BaseMeasurement) == 0)
                    {
                        recipe[index].Amount += currentIngr.Amount;
                    }
                    else
                    {
                        recipe[index].Amount += MeasureConverter.ConvertMeasure(currentIngr.BaseMeasurement, recipe[index].BaseMeasurement, currentIngr.Amount);
                    }
                }
            }

            return recipe;
        }


        static void Main(string[] args)
        {
            List<Ingredient> recipe = GetIngredients();
            List<Ingredient> usedIngredients = GetIngredients();

            StringBuilder output = new StringBuilder();
            foreach (var recipeItem in recipe)
            {
                bool foundRecipeItem = false;
                for (int index = 0; index < usedIngredients.Count; index++)
                {
                    if (usedIngredients[index].Equals(recipeItem) == true)
                    {
                        foundRecipeItem = true;
                        //string recipeMeasure = MeasureConverter.Normalize(recipeItem.BaseMeasurement);
                        //string itemMeasure = MeasureConverter.Normalize(usedIngredients[index].BaseMeasurement);
                        if (recipeItem.BaseMeasurement.CompareTo(usedIngredients[index].BaseMeasurement) == 0)
                        {
                            if (usedIngredients[index].Amount < recipeItem.Amount)
                            {
                                output.AppendLine(String.Format("{0:0.00}:{1}:{2}", recipeItem.Amount - usedIngredients[index].Amount,
                                    recipeItem.BaseMeasurement, recipeItem.Name));
                            }
                        }
                        else
                        {
                            double converted = MeasureConverter.ConvertMeasure(usedIngredients[index].BaseMeasurement,
                                recipeItem.BaseMeasurement, usedIngredients[index].Amount);
                            if (converted < recipeItem.Amount)
                            {
                                output.AppendLine(String.Format("{0:0.00}:{1}:{2}", recipeItem.Amount - converted, recipeItem.BaseMeasurement, recipeItem.Name));
                                //Console.WriteLine("{0:0.00}:{1}:{2}", recipeItem.Amount - converted, recipeItem.BaseMeasurement, recipeItem.Name);
                            }
                        }
                    }
                }
                if (foundRecipeItem == false)
                {
                    output.AppendLine(recipeItem.ToString());
                    //Console.WriteLine(recipeItem);
                }
            }
            Console.WriteLine(output);
        }
    }
}
