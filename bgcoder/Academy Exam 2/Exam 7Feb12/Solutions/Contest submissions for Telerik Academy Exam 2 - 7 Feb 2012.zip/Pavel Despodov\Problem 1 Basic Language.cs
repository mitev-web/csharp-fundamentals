using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace ConsoleApplication2
{
    class Program
    {
        static string str;
        static void Main(string[] args)
        {
           
           str  = Console.ReadLine();
           Print(str);
         
        }
        static void Print(string str)
        {
            int nachalo = 0;
            int krai = 0;
            int start = str.IndexOf("PRINT");
            StringBuilder abv = new StringBuilder(str);
            for (int i = start; i < abv.Length; i++)
            {
                if (abv[i] == '(')
                {
                    nachalo = i;
                    break;
                }
            }
            for (int i = start; i < abv.Length; i++)
            {
                if (abv[i] == ')')
                {
                    krai = i;
                    break;
                }
            }

            int len = krai - nachalo;
            string substring = str.Substring(nachalo + 1, len - 1);
            string correct = substring.Replace(")", "");
            Console.WriteLine(correct);

        }
            
        static void For(string str)
        {
            int start = str.IndexOf("FOR");
            StringBuilder build = new StringBuilder(str);
            for (int i = start; i < build.Length; i++)
            {
                
            }
 
        }
    }
}