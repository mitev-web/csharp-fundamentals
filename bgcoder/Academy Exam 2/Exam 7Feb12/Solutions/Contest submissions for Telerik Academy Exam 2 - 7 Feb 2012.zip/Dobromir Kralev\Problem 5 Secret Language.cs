using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Secret_language
{
    class Program
    {
        static void Permutations(int n, int k, char[] permutation)
        {
            if (k == n)
            {
                 if (loestCountPerm > count && normal[q]==permutation.ToString())
                     loestCountPerm = count;
            }
            else
            {
                for (int i = k; i < n; i++)
                {
                    char temp = permutation[k];
                    permutation[k] = permutation[i];
                    permutation[i] = temp;
                    count++;

                    Permutations(n, k + 1, permutation);

                    temp = permutation[k];
                    permutation[k] = permutation[i];
                    permutation[i] = temp;
                    count = 0;
                }
            }
        }
        static int count=0;
        static int loestCountPerm=0;
        static string secret;
        static string[] normal;
        static int q;
        static void Main(string[] args)
        {
            secret = "neotwheret";//Console.ReadLine();
            string temp=Console.ReadLine();
            string[] normal = temp.Split(',');

            for (int i = 0; i < normal.Length; i++)
            {
                normal[i]=normal[i].Trim(' ','\"');
            }

            int sumPermutations = 0;

            
            for (q=0; q < normal.Length; q++)
            {
                
                int n = normal[q].Length;
                int k = 0;
                char[] permutation = new char[n];
                int index = 0;
                for (int z = index; z < index + normal[q].Length; z++)
                {
                    permutation[z] = secret[z];
                }
                index += permutation.Length;
                Permutations(n, k, permutation);
                sumPermutations += loestCountPerm;
            } Console.WriteLine(sumPermutations);
            
        }
    }
}
