using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.BasicLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder text = new StringBuilder();
            bool read = true;
            while (read)
            {
                text.Append(Console.ReadLine());
                string stop = text.ToString();
                if (stop.IndexOf("EXIT;") != -1)
                {
                    read = false;
                }
               
            }
            string code = text.ToString();
            string[] lines = code.Split(';');
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i] != "")
                {
                    lines[i] = lines[i] + "; ";
                }
            }

            //output
            bool inLoop = false;
            bool inPrint = false;
            bool nestedLoop = false;
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i] == "")
                {
                    break;
                }
                if (lines[i].IndexOf("EXIT") != -1)
                {
                    break;
                }
                if (lines[i].IndexOf("PRINT") != -1)
                {
                    inPrint = true;
                }
                if (lines[i].IndexOf("FOR") != -1)
                {
                    inLoop = true;
                }
                if (inLoop)
                {
                    if (lines[i].IndexOf("FOR",lines[i].IndexOf("FOR")+1) != -1)
                    {
                        nestedLoop = true;
                    }
                }
                if (nestedLoop)
                {
                    if (lines[i].IndexOf("FOR") >= 0)
                    {
                        int start1 = lines[i].IndexOf("FOR") + 1;
                        int length1 = lines[i].IndexOf(")", lines[i].IndexOf(")") + 1) - lines[i].IndexOf("(", lines[i].IndexOf("(") + 1);
                        string loop = lines[i].Substring(start1, length1);
                        bool comma = false;
                        long a = 0;
                        long b = 0;
                        for (int j = 0; j < loop.Length; j++)
                        {
                            if (loop[j] == ',')
                            {
                                comma = true;
                            }
                            if (char.IsDigit(loop[j]) && comma == true)
                            {
                                b = loop[j] - '0';
                            }
                            if (char.IsDigit(loop[j]) && comma == false)
                            {
                                a = loop[j] - '0';
                            }
                        }
                        if (b != 0)
                        {
                            int start = lines[i].IndexOf("(", lines[i].LastIndexOf("PRINT"));
                            int length = lines[i].IndexOf(")", lines[i].IndexOf("PRINT")) - lines[i].IndexOf("(", lines[i].LastIndexOf("PRINT"));
                            for (long k = 1; k <= ((b - a) + 1); k++)
                            {
                                Console.Write(lines[i].Substring(start + 1, length - 1));
                            }
                        }

                        if (b == 0)
                        {
                            inPrint = false;
                            int start = lines[i].IndexOf("(", lines[i].LastIndexOf("PRINT"));
                            int length = lines[i].IndexOf(")", lines[i].IndexOf("PRINT")) - lines[i].IndexOf("(", lines[i].IndexOf("PRINT"));
                            for (long k = 1; k <= a; k++)
                            {
                                Console.Write(lines[i].Substring(start + 1, length - 1));
                            }
                        }


                    }
                }
                if (inLoop)
                {

                    if (lines[i].IndexOf("FOR") >= 0)
                    {
                        string loop = lines[i].Substring(lines[i].IndexOf("FOR"), (lines[i].IndexOf(")") - lines[i].IndexOf("FOR")));
                        bool comma = false;
                        long a = 0;
                        long b = 0;
                        for (int j = 0; j < loop.Length; j++)
                        {
                            if (loop[j] == ',')
                            {
                                comma = true;
                            }
                            if (char.IsDigit(loop[j]) && comma == true)
                            {
                                b = loop[j] - '0';
                            }
                            if (char.IsDigit(loop[j]) && comma == false)
                            {
                                a = loop[j] - '0';
                            }
                        }
                        if (b != 0)
                        {
                            int start = lines[i].IndexOf("(", lines[i].LastIndexOf("PRINT"));
                            int length = lines[i].IndexOf(")", lines[i].IndexOf("PRINT")) - lines[i].IndexOf("(", lines[i].LastIndexOf("PRINT"));
                            for (long k = 1; k < ((b - a) + 1); k++)
                            {
                                Console.Write(lines[i].Substring(start + 1, length - 1));
                            }
                        }

                        if (b == 0)
                        {
                            inPrint = false;
                            int start = lines[i].IndexOf("(", lines[i].LastIndexOf("PRINT"));
                            int length = lines[i].IndexOf(")", lines[i].IndexOf("PRINT")) - lines[i].IndexOf("(", lines[i].IndexOf("PRINT"));
                            for (long k = 1; k <= a; k++)
                            {
                                Console.Write(lines[i].Substring(start + 1, length - 1));
                            }
                        }

                    }
                    
                }
                if (inPrint)
                {
                    int start = lines[i].IndexOf("(", lines[i].IndexOf("PRINT"));
                    int length = lines[i].IndexOf(")", lines[i].IndexOf("PRINT")) - start;
                    Console.Write(lines[i].Substring(start + 1, length - 1));
                }
                inLoop = false;
                inPrint = false;
                nestedLoop = false;
            }
            Console.WriteLine();
        }
    }
}