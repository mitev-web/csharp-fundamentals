using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Problem2_MessagesInABottle
{
	class MessagesInABottle
	{
		static List<string> messages;

		static void Main(string[] args)
		{
			messages = new List<string>();

			string messageString;
			string codesString;
			ReadMessageAndCodes(out messageString, out codesString);

			List<int> message = new List<int>();
			InitMessage(messageString, message);

			Dictionary<long, List<char>> codes = new Dictionary<long, List<char>>();
			InitCodes(codesString, codes);

			Combine(message, 0, codes, "");
			Console.WriteLine(messages.Count);
			string[] array = new string[messages.Count];
			for (int i = 0; i < messages.Count; i++)
			{
				array[i] = messages[i];
			}
			Array.Sort(array);
			foreach (var item in array)
			{
				Console.WriteLine(item);
			}
		}

		private static void Combine(List<int> message, int startIndex, Dictionary<long, List<char>> codes, string result)
		{
			if (startIndex == message.Count)
			{
				if (result.Length != 0)
				{
					if (!messages.Contains(result.ToString()))
					{
						messages.Add(result.ToString());
					}

					result = "";//result.Clear();

					return;
				}
			}

			long currentCode = 0;

			for (int i = startIndex; i < message.Count; i++)
			{
				currentCode = currentCode * 10 + message[i];
				if (codes.ContainsKey(currentCode))
				{
					foreach (char c in codes[currentCode])
					{
						result += c; // result.Append(c);
						Combine(message, i + 1, codes, result);
						result = result.Substring(0, result.Length - 1);
					}
				}
			}
		}

		private static void InitMessage(string messageString, List<int> message)
		{
			for (int i = 0; i < messageString.Length; i++)
			{
				int digit = int.Parse(messageString[i].ToString());
				message.Add(digit);
			}
		}

		private static void InitCodes(string codesString, Dictionary<long, List<char>> codes)
		{
			for (int i = 0; i < codesString.Length; i++)
			{
				if (char.IsLetter(codesString[i]))
				{
					char letter = codesString[i];
					i++;
					long code = 0;
					while (i < codesString.Length
						&& char.IsDigit(codesString[i]))
					{
						int digit = int.Parse(codesString[i].ToString());
						code = code * 10 + digit;
						i++;
					}

					if (codes.ContainsKey(code))
					{
						if (!codes[code].Contains(letter))
						{
							codes[code].Add(letter);
						}
					}
					else
					{
						List<char> letters = new List<char>();
						letters.Add(letter);
						codes.Add(code, letters);
					}

					i--;
				}
			}
		}

		private static void ReadMessageAndCodes(out string messageString, out string codesString)
		{
			string inputFileName = "input.txt";

			//using (StreamReader reader = new StreamReader(inputFileName))
			{
				messageString = Console.ReadLine(); // Console
				codesString = Console.ReadLine();
			}
		}
	}
}