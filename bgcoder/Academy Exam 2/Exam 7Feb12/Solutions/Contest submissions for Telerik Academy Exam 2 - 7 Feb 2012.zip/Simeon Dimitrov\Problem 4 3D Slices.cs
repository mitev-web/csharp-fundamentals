using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_4_3D_Max_Walk
{
    class MaxWalk3D
    {
        static int width;
        static int height;
        static int depth;
        static short[, ,] cuboid;
        //static bool[, ,] visited;
        //static int sum1 = 0;
        //static int sum2 = 0;
        //static int answers = 0;

        static void Main()
        {
            List<int> sum1opt = new List<int>();
            List<int> sum2opt = new List<int>();
            int sum1 = 0;
            int sum2 = 0;
            int sum = 0;
            int answers = 0;
            bool flag = false;
            ReadCuboid();
            //
            for (int i = 0; i < height - 1; i++)
            {
                //  for (int c = i; c <= i; c++)
                {
                    for (int k = 0; k < width; k++)
                    {
                        for (int j = 0; j < depth; j++)
                        {
                            // Console.Write(cuboid[k, i, j]);
                            sum = sum + cuboid[k, i, j];
                        }
                    }
                    sum1opt.Add(sum);
                    sum = 0;
                    foreach (int s in sum1opt)
                    {
                        sum1 = sum1 + s;
                    }
                }
                
                // Console.WriteLine();
                if (!flag)
                {
                    for (int obri = height - 1; obri > i; obri--)
                    {
                        for (int k = 0; k < width; k++)
                        {
                            for (int j = 0; j < depth; j++)
                            {
                                sum = sum + cuboid[k, obri, j];
                                flag = true;
                            }
                        }
                        sum2opt.Add(sum);
                        sum = 0;

                    }
                    foreach (int s in sum2opt)
                    {
                        sum2 = sum2 + s;
                    }
                }
                else
                {
                    sum2 = sum2 - sum2opt[sum2opt.Count - i];
                }
                // Console.WriteLine();
                if (sum1 == sum2)
                {
                    answers++;
                }
                //Console.WriteLine(sum1);
              // Console.WriteLine(sum2);
                sum1 = 0;
                //sum2 = 0;
                sum = 0;

            }
            sum2 = 0;
            sum1opt.Clear();
            sum2opt.Clear();
            flag = false;
            for (int i = 0; i < width - 1; i++)
            {
                // for (int c = 0; c <= i; c++)
                {

                    for (int k = 0; k < height; k++)
                    {
                        for (int j = 0; j < depth; j++)
                        {
                            sum = sum + cuboid[i, k, j];

                          // Console.Write(cuboid[i, k, j]);
                        }
                    }
                    
                    sum1opt.Add(sum);
                    sum = 0;
                    foreach (int s in sum1opt)
                    {
                        sum1 = sum1 + s;
                    }

                }
                
                ///Console.WriteLine();
                if (!flag)
                {
                    for (int obri = width - 1; obri > i; obri--)
                    {
                        for (int k = 0; k < height; k++)
                        {
                            for (int j = 0; j < depth; j++)
                            {
                                sum = sum + cuboid[obri, k, j];
                                flag = true;
                               // Console.Write(cuboid[obri, k, j]);

                            }

                        }
                        //Console.WriteLine();
                        sum2opt.Add(sum);
                       // Console.WriteLine();
                        //Console.WriteLine("sum:{0}", sum);
                        sum = 0;

                    }
                    foreach (int s in sum2opt)
                    {
                        sum2 = sum2 + s;
                       // Console.WriteLine("s:{0}", s);
                    }
                }
                else
                {
                    sum2 = sum2 - sum2opt[sum2opt.Count - i];
                }
                if (sum1 == sum2)
                {
                    answers++;
                }
                //Console.WriteLine(sum1);
               // Console.WriteLine(sum2);
                sum1 = 0;
               // sum2 = 0;
                sum = 0;

            }
            sum1opt.Clear();
            sum2opt.Clear();
            flag = false;
            sum2 = 0;
            for (int i = 0; i < depth - 1; i++)
            {
                ///
                //for (int c = 0; c <= i; c++)
                {

                    for (int k = 0; k < height; k++)
                    {
                        for (int j = 0; j < width; j++)
                        {
                            sum = sum + cuboid[j, k, i];

                            //Console.Write(cuboid[j, k, c]);
                            // sum1 = sum1 + cuboid[j, k, c];
                        }
                    }
                    
                    sum1opt.Add(sum);
                    sum = 0;
                    foreach (int s in sum1opt)
                    {
                        sum1 = sum1 + s;
                    }

                }
                // Console.WriteLine();
                if (!flag)
                {
                    for (int obri = depth - 1; obri > i; obri--)
                    {
                        for (int k = 0; k < height; k++)
                        {
                            for (int j = 0; j < width; j++)
                            {

                                // sum = sum + cuboid[j, k, depth - i - 1];

                                sum = sum + cuboid[j, k, obri];
                                flag = true;
                            }
                        }
                        sum2opt.Add(sum);
                        sum = 0;

                    }
                    foreach (int s in sum2opt)
                    {
                        sum2 = sum2 + s;
                    }
                }
                else
                {
                    sum2 = sum2 - sum2opt[sum2opt.Count - i];
                }
                if (sum1 == sum2)
                {
                    answers++;
                }

                sum1 = 0;
                //sum2 = 0;
                sum = 0;

            }
            sum1opt.Clear();
            sum2opt.Clear();
            // answers = 0;
            Console.WriteLine(answers);
            // Console.WriteLine(sum2);

        }



        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            // Read the cuboid content
            cuboid = new short[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
        }
    }
}
