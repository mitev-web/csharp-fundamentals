using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem1_BL
{
    class Program
    {
        static void Main(string[] args)
        {
            bool foundExit = false;
            List<string> whole = new List<string>();
            for (int i = 0; i < 100; i++)
            {
                if (foundExit == true)
                {
                    break;
                }
                string line = Console.ReadLine();
                char[] character = { ';' };
                string[] split = line.Split(character,StringSplitOptions.RemoveEmptyEntries);
                for (int h = 0; h < split.Length; h++)
                {
                    whole.Add(split[h]);
                    if (split[h] == "EXIT")
                    {
                        foundExit = true;
                        break;
                    }
                }
            }
            string lo = "";
            for (int i = 0; i < whole.Count; i++)
            {
                bool isFor = false;
                if (whole[i] == "EXIT")
                {
                    break;
                }
                int index = whole[i].IndexOf("FOR");
                if (index != -1)
                {
                    isFor = true;
                }
                if (isFor == false)
                {
                    lo = "";
                    int p = whole[i].IndexOf("(");
                    int c = whole[i].IndexOf(")");
                    for (int l = p+1; l < c; l++)
                    {
                        lo += whole[i].ElementAt(l);
                    }
                    Console.Write(lo);
                }
                int count = 0;
                while (index != -1)
                {
                    count++;
                    index = whole[i].IndexOf("FOR", index + 1);
                }
                if (count == 1 && isFor == true)
                {
                    int index1 = whole[i].IndexOf("FOR");
                    int index2 = whole[i].IndexOf("PRINT");
                    int skoba = whole[i].IndexOf("(", index1, index2 - index1);
                    int zSkoba = whole[i].IndexOf(")", index1, index2 - index1);
                    int zap = whole[i].IndexOf(",", skoba, zSkoba - skoba);
                    if (zap != -1)
                    {
                        int start = 0;
                        int final = 0;
                        for (int o = skoba+1; o < zap; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out start);
                            if (number == true)
                            {
                                start = whole[i].ElementAt(o)-48;
                            }
                        }
                        for (int o = zap+1; o < zSkoba; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out final);
                            if (number == true)
                            {
                                final = whole[i].ElementAt(o)-48;
                            }
                        }
                        int print = whole[i].IndexOf("PRINT");
                        int p = whole[i].IndexOf("(", print);
                        int c = whole[i].IndexOf(")", print);
                        string ko = "";
                        for (int l = p+1; l < c; l++)
                        {
                            ko += whole[i].ElementAt(l);
                        }
                        for (int t = start; t <= final; t++)
                        {
                            Console.Write(ko);
                        }
                    }
                    else
                    {
                        int start = 0;
                        for (int o = skoba+1; o < zSkoba; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out start);
                            if (number == true)
                            {
                                start = whole[i].ElementAt(o)-48;
                            }
                        }
                        int print = whole[i].IndexOf("PRINT");
                        int p = whole[i].IndexOf("(", print);
                        int c = whole[i].IndexOf(")", print);
                        string mo = "";
                        for (int l = p+1; l < c; l++)
                        {
                            mo += whole[i].ElementAt(l);
                        }
                        for (int t = 0; t < start; t++)
                        {
                            Console.Write(mo);
                        }
                    }
                }
                if (count == 2 && isFor == true)
                {
                    int ind = whole[i].IndexOf("FOR");
                    int ind2 = whole[i].IndexOf("FOR", ind + 1);
                    int sk = whole[i].IndexOf("(", ind, ind2 - ind);
                    int zSk = whole[i].IndexOf(")", ind, ind2 - ind);
                    int zap = whole[i].IndexOf(",", sk, zSk - sk);
                    int st = 0;
                    int fi = 0;
                    if (zap != -1)
                    {
                        for (int o = sk + 1; o < zap; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out st);
                            if (number == true)
                            {
                                st = whole[i].ElementAt(o) - 48;
                            }
                        }
                        for (int o = zap + 1; o < zSk; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out fi);
                            if (number == true)
                            {
                                fi = whole[i].ElementAt(o) - 48;
                            }
                        }
                    }
                    else
                    {
                        st = 1;
                        fi = 0;
                        for (int o = sk + 1; o < zSk; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out fi);
                            if (number == true)
                            {
                                fi = whole[i].ElementAt(o) - 48;
                            }
                        }
                    }
                    int index2 = whole[i].IndexOf("PRINT");
                    int skoba = whole[i].IndexOf("(", ind2, index2 - ind2);
                    int zSkoba = whole[i].IndexOf(")", ind2, index2 - ind2);
                    int zap2 = whole[i].IndexOf(",", skoba, zSkoba - skoba);
                    if (zap2 != -1)
                    {
                        int start = 0;
                        int final = 0;
                        for (int o = skoba + 1; o < zap2; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out start);
                            if (number == true)
                            {
                                start = whole[i].ElementAt(o) - 48;
                            }
                        }
                        for (int o = zap2 + 1; o < zSkoba; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out final);
                            if (number == true)
                            {
                                final = whole[i].ElementAt(o) - 48;
                            }
                        }
                        int print = whole[i].IndexOf("PRINT");
                        int p = whole[i].IndexOf("(", print);
                        int c = whole[i].IndexOf(")", print);
                        string To = "";
                        for (int l = p + 1; l < c; l++)
                        {
                            To += whole[i].ElementAt(l);
                        }
                        for (int U = st; U <= fi; U++)
                        {
                            for (int t = start; t <= final; t++)
                            {
                                Console.Write(To);
                            }                            
                        }
                    }
                    else
                    {
                        int start = 0;
                        for (int o = skoba + 1; o < zSkoba; o++)
                        {
                            bool number = int.TryParse(whole[i].ElementAt(o).ToString(), out start);
                            if (number == true)
                            {
                                start = whole[i].ElementAt(o) - 48;
                            }
                        }
                        int print = whole[i].IndexOf("PRINT");
                        int p = whole[i].IndexOf("(", print);
                        int c = whole[i].IndexOf(")", print);
                        string Yo = "";
                        for (int l = p + 1; l < c; l++)
                        {
                            Yo += whole[i].ElementAt(l);
                        }
                        for (int r = st; r <= fi; r++)
                        {
                            for (int t = 0; t < start; t++)
                            {
                                Console.Write(Yo);
                            }                            
                        }
                    }

                }
            }
        }
    }
}