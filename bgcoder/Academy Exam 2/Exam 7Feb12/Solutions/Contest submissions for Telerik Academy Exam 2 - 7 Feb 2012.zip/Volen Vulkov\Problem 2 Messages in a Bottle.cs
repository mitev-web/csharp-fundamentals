using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_2___MessageInBottle
{
    class MessageInBotle
    {
        //static int lastEmpty;
        //static List<char> result = new List<char> { };

        static Dictionary<char, int> code = new Dictionary<char, int> { };
        static Dictionary<int, char> codeIntegers = new Dictionary<int, char> { };


        static bool IsDigit(char symbol)
        {
            return ((int)symbol - 48 >= 0 && (int)symbol - 48 <= 9);
        }

        static void MakeDictionary(string cipher)
        {

            StringBuilder temp = new StringBuilder();
            int numCounter;
            int charCounter;
            for (int i = 0; i < cipher.Length - 1; i++)
            {
                charCounter = i;
                numCounter = i + 1;
                while (numCounter < cipher.Length)
                {
                    if (IsDigit(cipher[numCounter]) == false)
                    {
                        i = numCounter - 1;
                        break;
                    }

                    temp.Append(cipher[numCounter]);
                    numCounter++;
                }
                code.Add(cipher[charCounter], int.Parse(temp.ToString()));
                temp.Clear();
            }
        }

        static void MakeIntDictionary(string cipher)
        {

            StringBuilder temp = new StringBuilder();
            int numCounter;
            int charCounter;
            for (int i = 0; i < cipher.Length - 1; i++)
            {
                charCounter = i;
                numCounter = i + 1;
                while (numCounter < cipher.Length)
                {
                    if (IsDigit(cipher[numCounter]) == false)
                    {
                        i = numCounter - 1;
                        break;
                    }

                    temp.Append(cipher[numCounter]);
                    numCounter++;
                }
                codeIntegers.Add(int.Parse(temp.ToString()), cipher[charCounter]);
                temp.Clear();
            }
        }

        static List<string> holder = new List<string> { };
        static string result = "";
       
        static void FindMessages(string message, int position, string number)
        {
            number += message[position];
            if (position == message.Length - 1)
            {
                if (code.ContainsValue(int.Parse(number)))
                {
                    result +=codeIntegers[int.Parse(number)];
                    
                    string a = result;
                    holder.Add(a);
                    result = "";
                    return;
                }
                else
                {                   
                    return;
                }
            }

            if (code.ContainsValue(int.Parse(number)))
            {
                result += codeIntegers[int.Parse(number)];
                FindMessages(message, position + 1, "");

            }


            for (int i = position; i < message.Length; i++)
            {
                number += message[i];
                if (code.ContainsValue(int.Parse(number)))
                {
                    result += codeIntegers[int.Parse(number)];
                    if (position != message.Length - 1)
                    {
                        FindMessages(message, position + 1, "");
                    }
                    
                }
            }

        }

        
        static void Main(string[] args)
        {

            string input = Console.ReadLine();
            string ceriph = Console.ReadLine();
            MakeDictionary(ceriph);
            MakeIntDictionary(ceriph);
            FindMessages(input, 0, "");
            Console.WriteLine(holder.Count);
            for (int i = 0; i < holder.Count; i++)
            {
                Console.WriteLine(holder[i]);
            }
        }
    }
}
