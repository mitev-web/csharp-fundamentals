using System;
using System.Linq;

namespace _04._3DSlices
{
    class Program
    {
        static int[, ,] cuboid;
        static int count = 0;
        static int totalSum = 0;
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] inputLine = input.Split(' ');
            int W = int.Parse(inputLine[0]);
            int H = int.Parse(inputLine[1]);
            int D = int.Parse(inputLine[2]);

            cuboid = new int[W, H, D];

            for (int h = 0; h < H; h++)
            {
                input = Console.ReadLine();
                inputLine = input.Split(new string[] { " | " }, StringSplitOptions.RemoveEmptyEntries);
                for (int d = 0; d < D; d++)
                {
                    string[] widthLine = inputLine[d].Split(' ');
                    for (int w = 0; w < W; w++)
                    {
                        cuboid[w, h, d] = int.Parse(widthLine[w]);
                    }
                }
            }

            totalSum = Sum(0, W, 0, H, 0, D);

            if (W > 1)
            {
                SliceByWidth(W, H, D);
            }
            if (H > 1)
            {
                SliceByHeight(W, H, D);
            }
            if (D > 1)
            {
                SliceByDepth(W, H, D);
            }

            Console.WriteLine(count);
        }

        static void SliceByWidth(int w, int h, int d)
        {
            for (int i = 1; i <= w/2; i++)
            {
                int currentSum = Sum(0, i, 0, h, 0, d);
                if ( currentSum == totalSum / 2)
                {
                    count++;
                }
            }

            for (int i = w/2 + 1; i < w; i++)
            {
                int currentSum = Sum(i, w, 0, h, 0, d);
                if ( currentSum == totalSum / 2)
                {
                    count++;
                }
            }
        }

        static void SliceByHeight(int w, int h, int d)
        {
            for (int i = 1; i <= h/2; i++)
            {
                int currentSum = Sum(0, w, 0, i, 0, d);
                if (currentSum == totalSum / 2)
                {
                    count++;
                }
            }

            for (int i = h / 2 + 1; i < h; i++)
            {
                int currentSum = Sum(0, w, i, h, 0, d);
                if (currentSum == totalSum / 2)
                {
                    count++;
                }
            }
        }

        static void SliceByDepth(int w, int h, int d)
        {
            for (int i = 1; i <= d/2; i++)
            {
                int currentSum = Sum(0, w, 0, h, 0, i);
                if (currentSum == totalSum / 2)
                {
                    count++;
                }
            }

            for (int i = d / 2 + 1; i < d; i++)
            {
                int currentSum = Sum(0, w, 0, h, i, d);
                if (currentSum == totalSum / 2)
                {
                    count++;
                }
            }
        }

        static int Sum(int wStart, int wEnd, int hStart, int hEnd, int dStart, int dEnd)
        {
            int sum = 0;
            for (int w = wStart; w < wEnd; w++)
            {
                for (int h = hStart; h < hEnd; h++)
                {
                    for (int d = dStart; d < dEnd; d++)
                    {
                        sum += cuboid[w, h, d];
                    }
                }
            }
            return sum;
        }
    }
}
