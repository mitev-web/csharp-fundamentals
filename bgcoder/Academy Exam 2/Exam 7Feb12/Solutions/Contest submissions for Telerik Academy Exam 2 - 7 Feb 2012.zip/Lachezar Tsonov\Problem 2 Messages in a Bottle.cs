using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.MessagesInABottle
{
    class MessagesBottle
    {
        static Dictionary<string, char> codes;
        static List<char[]> possibleInputs;
        static char[] currentCombination;
        static int maxLength;
        static void GetCodes()
        {
            codes = new Dictionary<string, char>();
            string cipher = Console.ReadLine();
            StringBuilder getCode = new StringBuilder(100);
            for (int index = 0; index < cipher.Length; index++)
            {
                if (Char.IsDigit(cipher[index]) == false)
                {
                    char letter = cipher[index];
                    //get the code for the letter
                    index++;
                    while (index < cipher.Length && Char.IsDigit(cipher[index]) == true)
                    {
                        getCode.Append(cipher[index]);
                        index++;
                    }
                    string codeInString = getCode.ToString();
                    if (codes.ContainsKey(codeInString) == true)
                    {
                        throw new Exception();
                    }
                    else
                    {
                        codes.Add(codeInString, letter);
                    }
                    getCode.Clear();
                    
                    index--; //we moved one step ahead
                }
            }
        }

        static List<string> Sort(List<char[]> input)
        {
            List<string> output = new List<string>(input.Count);
            foreach (var charArr in input)
            {
                output.Add(new string(charArr));
            }
            output.Sort();
            return output;
        }
        static void Decipher(string input, int position = 0)
        {
            if (position == maxLength || input == "")
            {
                char[] combination = new char[currentCombination.Length];
                currentCombination.CopyTo(combination, 0);
                possibleInputs.Add(combination);
                return;
            }
            foreach (var codeLetter in codes)
            {
                if (input.StartsWith(codeLetter.Key) == true)
                {
                    currentCombination[position] = codeLetter.Value;
                    Decipher(input.Substring(codeLetter.Key.Length), position + 1);
                    currentCombination[position] = '\0';
                }
            }
        }
        static void Main(string[] args)
        {
            string secretCode = Console.ReadLine();
            currentCombination = new char[secretCode.Length];
            maxLength = secretCode.Length;
            possibleInputs = new List<char[]>();
            GetCodes();
            Decipher(secretCode);
            Console.WriteLine(possibleInputs.Count);
            List<string> result = Sort(possibleInputs);
            foreach (var possibleInput in result)
            {
                Console.WriteLine(possibleInput);
            }
        }
    }
}
