using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SecretLanguage
{
    class SecretLanguage
    {
        static int CheckEqual(string str, string word)
        {
            int cost = 0;
            int counterChanges = 0;
            char[] arr = str.ToCharArray();
            char[] str2 = word.ToCharArray();
            List<char> temp1 = new List<char>();
            List<char> temp2 = new List<char>();
            int counter = 0;
            for (int i = 0; i < str2.Length; i++)
            {
                if (str2[i] == arr[i])
                {
                    str2[i] = '0';
                    arr[i] = '0';
                    counter++;
                }
                else
                {
                    temp1.Add(arr[i]);
                    temp2.Add(str2[i]);
                }
            }
            str = str2.ToString();
            int flag = 0;
            for (int i = 0; i < temp1.Count; i++)
            {
                for (int j = temp1.Count - 1; j >= 0; j--)
                {
                    if (temp1[i] == temp2[j])
                    {

                        if (i != j)
                        {
                            cost += 1;
                        }
                        //temp1.RemoveAt(i);
                        //temp2.RemoveAt(j);
                        counterChanges++;
                        break;
                    }
                }
            }
            if (counterChanges ==temp1.Count)
            {
                return cost;
            }
            else
            {
                return -1;
            }
        }

        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
            string elements = Console.ReadLine();
            string compare = "";
            char[] delimeter = { '"', ' ', ',' };
            List<string> alreadyChecked = new List<string>();
            List<int> costs = new List<int>();
            string[] words = elements.Split(delimeter, StringSplitOptions.RemoveEmptyEntries);
            int totalCost = 0;
            int checker = 0;
            int equal = 0;
            int equalFlag = 0;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < words.Length; i++)
            {
                for (int j = 0; j < sentence.Length; j++)
                {
                    for (int k = j; k<j+words[i].Length; k++)
                    {
                        if (k == sentence.Length)
                        {
                            break;
                        }
                        sb.Append(sentence[k]);
                    }                                       
                    if (sb.Length == words[i].Length)
                    {
                        checker=CheckEqual(sb.ToString(), words[i]);
                        if (checker >= 0)
                        {
                            compare = sb.ToString();
                            if (alreadyChecked.Count == 0)
                            {
                                alreadyChecked.Add(compare);
                                costs.Add(checker);
                            }
                            for(int z=0 ;z<alreadyChecked.Count;z++)
                            {
                                equal=string.Compare(alreadyChecked[z],compare);
                                if (equal==0)
                                {
                                    equalFlag = 1;
                                    if (checker < costs[z])
                                    {
                                        costs[z] = checker;
                                    }
                                }
                            }
                            if (equalFlag == 0)
                            {
                                alreadyChecked.Add(compare);
                                costs.Add(checker);
                            }
                        }
                    }
                    sb.Clear();
                    equalFlag = 0;
                }
            }
            long sum = 0;
            for (int i = 0; i < costs.Count; i++)
            {
                sum += costs[i];
            }
            if (sum == 0)
            {
                Console.WriteLine(-1);
            }
            else
            {
                Console.WriteLine(sum);
            }
            

        }
    }
}
