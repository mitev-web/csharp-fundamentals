using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3D
{
    class Program
    {
        static int width;
        static int height;
        static int depth;
        static short[, ,] cuboid;
        static int totalSum = 0;
        static int count = 0;

        static void Main(string[] args)
        {
            int currentSum = 0;
            ReadCuboid();

            for (int h = 0; h < height; h++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        currentSum += cuboid[w, h, d];
                    }
                }
                if (currentSum == totalSum - currentSum)
                {
                    count++;   
                }
            }
            currentSum = 0;
            for (int w = 0; w < width; w++)
            {
                for (int d = 0; d < depth; d++)
                {
                    for (int h = 0; h < height; h++)
                    {
                        currentSum += cuboid[w, h, d];
                    }
                }
                if (currentSum == totalSum - currentSum)
                {
                    count++;
                }
            }
            currentSum = 0;
            for (int d = 0; d < depth; d++)
            {
                for (int h = 0; h < height; h++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        currentSum += cuboid[w, h, d];
                    }
                }
                if (currentSum == totalSum - currentSum)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
        }
        private static void ReadCuboid()
        {
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            cuboid = new short[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                        totalSum += cubeValue;
                    }
                }
            }
        }
    }
}
