using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace _02.bootle
{
    class Program
    {
        static string getChar(int position,int leght,string fromWhere)
        {
            string a="";
            a = fromWhere.Substring(position, leght);

            return a;
        }
        static void recursian(string code,string[] number,string[] letters,ref int count,ref StringBuilder output)
        {
            int line1 = 1;
            int line2 = 1;
            while (true)
            {
                string use = string.Empty;
                if (line2 > line1) { line1++; line2 = 1; }
                if (line2 == code.Length+1) { break; }
                for (int i = 0; i+line1 < code.Length; i++)
                {
                    int start = i;
                    int end = i + line1;
                    use = getChar(i, line1, code);
                     string newStoinost = "";
                    int flag2 = 0;
                    for (int k = 1; k < number.Length; k++)
                    {
                        if (use == number[k].ToString()) { newStoinost += letters[k-1]; flag2 = 1; break; }
                    }
                    if (flag2 == 1)
                    {
                        int check = 1;
                        for (int j = 0; j +line2 <= code.Length; j++)
                        {
                            int flag = 0;
                            for (int s = start; s < end; s++)
                            {
                                if (j == s) { flag = 1; break; }
                                if (j + line2-1 == s) { flag = 1; break; }
                            }
                            if (flag == 0)
                            {
                                use = getChar(j, line2, code);
                                for (int k = 1; k < number.Length; k++)
                                {
                                    if (use == number[k].ToString()) { newStoinost += letters[k - 1]; flag2 = 1; check++; break; }
                                    else { flag2 = 0; }

                                }
                            //    if (flag2 == 0) { break; }
                            }
                            else { flag2 = 0; }
                          
                            

                        }
                        string proverka = "";
                        char[] c = newStoinost.ToCharArray();

                        Array.Sort(c);
                        string sadas = "";
                        foreach (var item in c)
                        {
                            sadas += item.ToString();
                        }
                        newStoinost = sadas;
                        for (int l = 0; l < newStoinost.Length; l++)
                        {

                          int h=finddd(letters, newStoinost[l].ToString());
                          proverka += number[h+1];
                        }
                        if (proverka==code) { count++; output.Append(newStoinost); output.Append("\n"); }
                    }
                    if (line1 == 1 && line2 == 1) break;
                }
               
                line2++;
                
            }
        }
        static int finddd(string[] array, string stoinost)
        {
          
            for (int y = 0; y <array.Length; y++)
            {
                if (array[y] == stoinost)
                {
                    return y;
                }

            }
            return -1;
        }
        static void Main(string[] args)
        {
           // string toDecode = "1122";
            string toDecode = Console.ReadLine();
         //  string theCode="A1B12C11D2";
            string theCode = Console.ReadLine();
          List<string> hh=new List<string>();
          StringBuilder answear = new StringBuilder();
            string[] help=Regex.Split(theCode, @"\d");
  //  string codeLetters
   for (int i = 0; i < help.Length; i++)
			{
                if (help[i] != "") { hh.Add(help[i]); }
			}
   string[] codeLetters = hh.ToArray();
   string[] codeNumbers = Regex.Split(theCode, @"[A-Z]");
 
   int count = 0;
 
   recursian(toDecode, codeNumbers, codeLetters,ref count,ref answear);
   string newCode = answear.ToString();

         //   int lines=0;
            string[] array = newCode.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
       
           Array.Sort(array);
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 0; j <  array.Length; j++)
                {
                    if (array[i] == array[j] && i != j) { count--; array[i] = "999"; }
                }
            }
   Console.WriteLine(count);
  
   for (int i = 0; i < array.Length; i++)
   {
       if(array[i]!="999")Console.WriteLine(array[i]);  
   }

        }
    }
}
