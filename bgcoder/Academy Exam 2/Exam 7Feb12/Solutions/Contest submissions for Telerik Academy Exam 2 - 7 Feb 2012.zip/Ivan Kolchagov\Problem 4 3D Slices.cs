using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace T04.Cuboid
{
    class Program
    {
        enum Dimensions { Width, Height, Depth };
        static int[] IntInputSystem()
        {
            string inputData = Console.ReadLine();
            List<string> splitData = new List<string>();
            foreach (var item in inputData.Replace('|', ' ').Split())
            {
                if (!String.IsNullOrWhiteSpace(item)) splitData.Add(item);
            }
            int[] data = new int[splitData.Count];
            int i = 0;
            foreach (var item in splitData)
            {
                if (int.TryParse(item, out data[i])) i++;
            }
            return data;
        }

        static int CubeSum(short[, ,] arr, int height, int width, int depth)
        {
            if (height == 0) height = arr.GetLength(0);
            if (width == 0) width = arr.GetLength(1);
            if (depth == 0) depth = arr.GetLength(2);
            int sum = 0;
            for (int h = 0; h < height; h++)
            {
                for (int w = 0; w < width; w++)
                {
                    for (int d = 0; d < depth; d++)
                    {
                        sum += arr[h, w, d];
                    }
                }
            }
            return sum;
        }

        static int OtherCubeSum(short[, ,] arr, int height, int width, int depth)
        {
            int sum = 0;
            for (int h = height; h < arr.GetLength(0); h++)
            {
                for (int w = width; w < arr.GetLength(1); w++)
                {
                    for (int d = 0; d < arr.GetLength(2); d++)
                    {
                        sum += arr[h, w, d];
                    }
                }
            }
            return sum;
        }

        static void Main(string[] args)
        {

            int[] sizes = IntInputSystem();
            int width = sizes[0], height = sizes[1], depth = sizes[2];
            short[, ,] arr = new short[height, depth, width];
            for (int h = 0; h < height; h++)
            {
                int[] lane = IntInputSystem();
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                            arr[h, d, w] = (short)lane[d * (depth-1) + w];
                    }
                }
            }
            int splitCount = 0;
            for (int h = 1; h < height ; h++)
            {
                if (CubeSum(arr, h, 0, 0) == OtherCubeSum(arr, h, 0, 0))
                {
                    splitCount++;
                }
            }
            for (int d = 1; d < depth; d++)
            {
                if (CubeSum(arr, 0, 0, d) == OtherCubeSum(arr, 0, 0, d))
                {
                    splitCount++;
                }
            }
            for (int w = 1; w < width ; w++)
            {
                if (CubeSum(arr, 0, w, 0) == OtherCubeSum(arr, 0, w, 0))
                {
                    splitCount++;
                }
            }
            Console.WriteLine(splitCount*2);
        }
    }
}
