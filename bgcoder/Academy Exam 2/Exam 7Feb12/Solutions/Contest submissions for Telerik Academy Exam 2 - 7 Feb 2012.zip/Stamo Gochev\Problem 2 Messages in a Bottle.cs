using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    public class MessagesSolver
    {
        const int MAX_SIZE = 180;

        public static void Main()
        {
            //input
            //string s = Console.ReadLine();
            //string input = Console.ReadLine();

            string code = "1122";
            string input = "A1B12C11D2";
            int[,] a = new int[MAX_SIZE, 2];
            int size = 0;

            int letterIndex = 0;
            int number = 0;
            for (int i = 1; i < input.Length; i++)
            {
                if (char.IsLetter(input[i]))
                {
                    char nextLetter = input[letterIndex];
                    int letterCode = (int)input[letterIndex];
                    a[size, 0] = letterCode;
                    if (number == 0)
                    {
                        number = 1;
                    }
                    a[size, 1] = number;
                    size++;
                    number = 0;
                    letterIndex = i;
                }
                else
                {
                    if (char.IsDigit(input[i]))
                    {
                        number = number * 10 + (input[i] - '0');
                    }
                }


            }
            char lastLetter = input[letterIndex];
            int lastLetterCode = (int)input[letterIndex];
            a[size, 0] = lastLetterCode;
            if (number == 0)
            {
                number = 1;
            }
            a[size, 1] = number;
            size++;
            List<int> listOfNumbers = GetPossibleNumbers(code);
            listOfNumbers.Sort();
            //PrintList(listOfNumbers);
            StringBuilder sb = new StringBuilder();
            StringBuilder builder = new StringBuilder();

            int count = 0;
            StringBuilder answer = new StringBuilder();
            List<int> tempList = new List<int>(MAX_SIZE);
            int Length = code.Length;
            int len = 0;
            for (int i = 0; i < listOfNumbers.Count; i++)
            {
                builder.Clear();
                for (int index = 0; index < size; index++)
                {
                    if (listOfNumbers[i] == a[index, 1])
                    {
                        sb.Append(listOfNumbers[i].ToString());
                        len = listOfNumbers[i].ToString().Length;
                        char ck = (char)a[index, 0];
                        builder.Append(ck);
                        break;
                    }
                }

                bool mustStop = false;
                for (int j = i + 1; j < listOfNumbers.Count; j++)
                {
                    for (int k = j; k < listOfNumbers.Count; k++)
                    {
                        if (mustStop == false)
                        {
                            for (int index = 0; index < size; index++)
                            {
                                if (listOfNumbers[k] == a[index, 1])
                                {
                                    sb.Append(listOfNumbers[k].ToString());
                                    //tempList.Add(listOfNumbers[k]);
                                    //Console.WriteLine(listOfNumbers[k]);
                                    char c = (char)a[index, 0];
                                    builder.Append(c);
                                    int numberLength =
                                        listOfNumbers[k].ToString().Length;
                                    len += numberLength;
                                    if (len > Length)
                                    {
                                        builder.Clear();
                                        mustStop = true;
                                        break;
                                    }

                                    if (len == Length)
                                    {
                                        string finalCode = sb.ToString();
                                        if (finalCode == code)
                                        {
                                            count++;

                                            answer.Append(builder.ToString());
                                            answer.Append('\n');
                                            //Console.WriteLine(builder.ToString());
                                            //Console.WriteLine();
                                        }
                                        sb.Clear();
                                        builder.Clear();
                                        len = 0;
                                        mustStop = true;
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            break;
                        }
                        
                    }
                }
            }
            string answer2 = answer.ToString();
            answer2 = answer2.TrimEnd();
            Console.WriteLine(count);
            Console.WriteLine(answer2);
        }

        private static void PrintLettersAndCode(int[,] a, int size)
        {
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("{0} -> {1}", a[i, 0], a[i, 1]);
            }
        }

        private static void PrintList(List<int> numbers)
        {
            Console.WriteLine("LIST:");
            foreach (var n in numbers)
            {
                Console.WriteLine(n);
            }
        }

        private static List<int> GetPossibleNumbers(string s)
        {
            List<int> numbers = new List<int>();


            for (int i = 0; i < s.Length; i++)
            {
                int next = s[i] - '0';
                numbers.Add(next);

            }
            for (int i = 0; i < s.Length; i++)
            {
                int n = s[i] - '0';
                //Console.WriteLine(n);
                for (int j = i + 1; j < s.Length; j++)
                {
                    int nextNumber = s[j] - '0';
                    n = 10 * n + nextNumber;
                    //Console.WriteLine(n);
                    //if (!numbers.Contains(n))
                    //{
                    numbers.Add(n);
                    //}


                }

            }
            return numbers;
        }
    }

