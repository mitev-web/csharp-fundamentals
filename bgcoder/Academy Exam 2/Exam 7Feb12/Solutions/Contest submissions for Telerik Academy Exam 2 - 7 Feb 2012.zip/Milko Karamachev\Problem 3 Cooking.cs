using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace recipy
{
    public class Ingredient
    {
        public double quantity { get; set; }
        public string dimension { get; set; }
        public string product { get; set; }

        public Ingredient(double q, string d, string p)
        {
            this.quantity = q;
            this.dimension = d;
            this.product = p;

        }
        public Ingredient()
        {
            this.quantity = 0;
            this.dimension = "";
            this.product = "";
        }
    }


    class Program
    {

        static void ConvertToMl(Ingredient p)
        {
            switch (p.dimension.ToUpper())
            {
                case "TABLESPOONS":
                    {
                        p.quantity = p.quantity * 15;
                    }
                    break;
                case "TBSPS":
                    {
                        p.quantity = p.quantity * 15;
                    }
                    break;
                case "LITERS":
                    {
                        p.quantity = p.quantity * 1000;
                    }
                    break;
                case "LS":
                    {
                        p.quantity = p.quantity * 1000;
                    }
                    break;
                case "FLUID OUNCES":
                    {
                        p.quantity = p.quantity * 30;
                    }
                    break;

                case "FL OZS":
                    {
                        p.quantity = p.quantity * 30;
                    }
                    break;
                case "TEASPOONS":
                    {
                        p.quantity = p.quantity * 5;
                    }
                    break;

                case "TSPS":
                    {
                        p.quantity = p.quantity * 5;
                    }
                    break;
                case "GALLONS":
                    {
                        p.quantity = p.quantity * 3840;
                    }
                    break;
                case "GALS":
                    {
                        p.quantity = p.quantity * 3840;
                    }
                    break;
                case "PINTS":
                    {
                        p.quantity = p.quantity * 480;
                    }
                    break;
                case "PTS":
                    {
                        p.quantity = p.quantity * 480;
                    }
                    break;
                case "QUARTS":
                    {
                        p.quantity = p.quantity * 960;
                    }
                    break;
                case "QTS":
                    {
                        p.quantity = p.quantity * 960;
                    }
                    break;
                case "CUPS":
                    {
                        p.quantity = p.quantity * 240;
                    }
                    break;
                case "MLS":
                    {
                        p.quantity = p.quantity;
                    }
                    break;
                case "MILILITERS":
                    {
                        p.quantity = p.quantity;
                    }
                    break;

                default:
                    {
                        Console.WriteLine("Wrong data!");
                    }
                    break;


            }
            p.dimension = "mls";

        }

        static void ConvertToOrig(Ingredient p, string s)
        {
            
            switch (s.ToUpper())
            {
                case "TABLESPOONS":
                    {
                        p.quantity = p.quantity / 15.0;
                        p.dimension = s;
                    }
                    break;
                case "TBSPS":
                    {
                        p.quantity = p.quantity / 15.0;
                        p.dimension = s;
                    }
                    break;
                case "LITERS":
                    {
                        p.quantity = p.quantity / 1000.0;
                        p.dimension = s;
                    }
                    break;
                case "LS":
                    {
                        p.quantity = p.quantity / 1000.0;
                        p.dimension = s;
                    }
                    break;
                case "FLUID OUNCES":
                    {
                        p.quantity = p.quantity / 30.0;
                        p.dimension = s;
                    }
                    break;

                case "FL OZS":
                    {
                        p.quantity = p.quantity / 30.0;
                        p.dimension = s;
                    }
                    break;
                case "TEASPOONS":
                    {
                        p.quantity = p.quantity / 5.0;
                        p.dimension = s;
                    }
                    break;

                case "TSPS":
                    {
                        p.quantity = p.quantity / 5.0;
                        p.dimension = s;
                    }
                    break;
                case "GALLONS":
                    {
                        p.quantity = p.quantity / 3840.0;
                        p.dimension = s;
                    }
                    break;
                case "GALS":
                    {
                        p.quantity = p.quantity / 3840.0;
                        p.dimension = s;
                    }
                    break;
                case "PINTS":
                    {
                        p.quantity = p.quantity / 480.0;
                        p.dimension = s;
                    }
                    break;
                case "PTS":
                    {
                        p.quantity = p.quantity / 480.0;
                    }
                    break;
                case "QUARTS":
                    {
                        p.quantity = p.quantity / 960.0;
                        p.dimension = s;
                    }
                    break;
                case "QTS":
                    {
                        p.quantity = p.quantity / 960.0;
                        p.dimension = s;
                    }
                    break;
                case "CUPS":
                    {
                        p.quantity = p.quantity / 240.0;
                        p.dimension = s;
                    }
                    break;
                case "MLS":
                    {
                        p.quantity = p.quantity;
                        p.dimension = s;
                    }
                    break;
                case "MILILITERS":
                    {
                        p.quantity = p.quantity;
                        p.dimension = s;
                    }
                    break;

                default:
                    {
                        p.dimension = s;
                       // Console.WriteLine("Wrong data!");
                    }
                    break;


            }


        }


        static void Main(string[] args)
        {
           // StreamReader input = new StreamReader("input.txt");

            //using (input)
            //{
                int N = int.Parse(Console.ReadLine());

                //Console.WriteLine(N);

                List<Ingredient> originalrecipy = new List<Ingredient>();

               // int[] q=new int[N];

               

                for (int i = 0; i < N; i++)
                {
                    string line=Console.ReadLine();

                    string[] temprecipy = line.Split(new char[] {':'}, StringSplitOptions.None);
                    if (temprecipy.Length != 3)
                    {
                        return;
                    }
                    if (double.Parse(temprecipy[0] )< 0)
                    {
                        return;
                    }
                    
                    originalrecipy.Add(new Ingredient(double.Parse(temprecipy[0].Trim()),temprecipy[1].Trim(),temprecipy[2]));

                }


                int M = int.Parse(Console.ReadLine());

               


                List<Ingredient> krisi = new List<Ingredient>();

                for (int i = 0; i < M; i++)
                {
                    string[] temprecipy = Console.ReadLine().Split(new char[] {':'}, StringSplitOptions.None);
                    if (temprecipy.Length != 3)
                    {
                        return;
                    }

                    if (double.Parse(temprecipy[0]) < 0)
                    {
                        return;
                    }

                    krisi.Add(new Ingredient(double.Parse(temprecipy[0].Trim()), temprecipy[1].Trim(), temprecipy[2]));
                }







                if(originalrecipy.Count>=2)
                {

                    for (int i = 0; i < originalrecipy.Count - 1; i++)
                    {

                        for (int j = i + 1; j < originalrecipy.Count; j++)
                        {
                            if (originalrecipy[i].product.ToUpper() == originalrecipy[j].product.ToUpper())
                            {
                                Ingredient temp1 = new Ingredient();
                                temp1.quantity = originalrecipy[i].quantity;
                                temp1.dimension = originalrecipy[i].dimension;
                                temp1.product = originalrecipy[i].product;

                                Ingredient temp2 = new Ingredient();
                                temp2.quantity = originalrecipy[j].quantity;
                                temp2.dimension = originalrecipy[j].dimension;
                                temp2.product = originalrecipy[j].product;

                                ConvertToMl(temp1);

                                ConvertToMl(temp2);

                                temp1.quantity = temp1.quantity + temp2.quantity;

                                ConvertToOrig(temp1, originalrecipy[i].dimension);

                                originalrecipy[i].quantity = temp1.quantity;


                                originalrecipy.RemoveAt(j);
                                j--;


                            }

                        }




                    }
                }

                if ((krisi.Count > 0) && (originalrecipy.Count > 0))
                {


                    for (int i = 0; i < originalrecipy.Count; i++)
                    {

                        for (int j = 0; j < krisi.Count; j++)
                        {
                            if (originalrecipy[i].product.ToUpper() == krisi[j].product.ToUpper())
                            {
                                Ingredient temp1 = new Ingredient();
                                temp1.quantity = originalrecipy[i].quantity;
                                temp1.dimension = originalrecipy[i].dimension;
                                temp1.product = originalrecipy[i].product;

                                ConvertToMl(temp1);

                                ConvertToMl(krisi[j]);


                                if (temp1.quantity >= krisi[j].quantity)
                                {
                                    temp1.quantity = temp1.quantity - krisi[j].quantity;

                                    ConvertToOrig(temp1, originalrecipy[i].dimension);

                                    originalrecipy[i].quantity = temp1.quantity;

                                }
                                else
                                {
                                    originalrecipy.RemoveAt(i);
                                    //Console.WriteLine("OOOO "+i);
                                    i--;

                                }



                            }

                        }

                    }
                }
                else
                {
                    return;
                }


                if (originalrecipy.Count > 0)
                {

                    foreach (var item in originalrecipy)
                    {
                        if (item.quantity > 0)
                        {
                            Console.Write("{0:0.00}:{1}:{2}", item.quantity, item.dimension, item.product);
                            Console.WriteLine();
                        }
                    }
                }

                /*
                foreach (var item in krisi)
                {
                    ConvertToMl(item);

                    Console.Write("{0} {1} {2} ", item.quantity, item.dimension, item.product);
                    Console.WriteLine();
                }
               */


            




        }
    }
}
