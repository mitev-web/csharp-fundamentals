using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace BasicLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            


            //string s = @"   PRINT    ( Black and yellow);
             //       FOR(0,1)   PRINT(black and yellow, );
           // PRINT(black and yellow...);
             //       EXIT;";

       

               StringBuilder sb = new StringBuilder();
               // Console.WriteLine(sb);

                bool inBrackets = false;
                char[] temparray = new char[5];


                while (true)
                {
                    
                    string s = Console.ReadLine();

                    for (int i = 0; i < s.Length; i++)
                    {
                        if (s[i] == '(')
                        {
                            inBrackets = true;
                        }

                        if (s[i] == ')')
                        {
                            inBrackets = false;
                        }

                        if (inBrackets == false)
                        {
                            if (s[i] == ' ')
                            {
                                continue;
                            }
                            else
                            {
                                sb.Append(s[i]);
                            }
                        }
                        else
                        {
                            sb.Append(s[i]);
                        }
                    }
                        if(sb.ToString().Contains("EXIT;"))
                        {
                            break;
                        }

                                     
                                    
                }
               // Console.WriteLine(sb.ToString());
               // sb.Replace("FOR(", "F(");
                    //sb.Replace("PRINT(","P(");

                    int forMultiplyer = 1;
                    string p = sb.ToString();
                    
                    string[] last = p.Split(new char[] {')'}, StringSplitOptions.RemoveEmptyEntries);

                   /* foreach (var item in last)
                    {
                         Console.WriteLine(item.ToString());
                    }*/
         
           // Console.WriteLine(last.ToString());


                    for (int i = 0; i < last.Length; i++)
                    {
                        StringBuilder temp1 = new StringBuilder(last[i]);

                        if(temp1.ToString().Contains("FOR("))
                        {
                            
                            temp1.Replace("FOR(", "");
                            temp1.Replace(";", "");  
                            int a;
                            int b;

                            if (temp1.ToString().Contains(','))
                            {
                                string[] temp2 = temp1.ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                                a =int.Parse(temp2[0].Trim());

                                b = int.Parse(temp2[1].Trim());

                                forMultiplyer=(b - a + 1) * forMultiplyer;
                            }
                            else
                            {
                                a = int.Parse(temp1.ToString().Trim());

                                forMultiplyer = forMultiplyer * a;
                            }



                        }
                        if (temp1.ToString().Contains("PRINT("))
                        {
                            temp1.Replace("PRINT(", "");
                            if (temp1[temp1.Length - 1] == ';')
                            {

                                temp1.Remove(temp1.Length - 1, 1);
                            }
                            if (temp1[0] == ';')
                            {
                                temp1.Remove(0, 1);
                            }

                            if (forMultiplyer > 0)
                            {
                                for (int k = 0; k < forMultiplyer; k++)
                                {
                                    Console.Write(temp1.ToString());
                                }
                            }
                            forMultiplyer = 1;
                        }

                        if(temp1.ToString().Contains("EXIT"))
                        {
                            break;
                        }


                    }



            
                    
        }

                

    }
    
}
