using System;

namespace Problem_5_Secret_Language
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
            string listOfWords = Console.ReadLine();
            string[] clearedList = listOfWords.Split(new char[] { ' ', ',', '"' }, 
                StringSplitOptions.RemoveEmptyEntries);
            int number = 1;
            int firstIndex = 0;
            int nextIndex = sentence.Length + clearedList.Length;
            if (firstIndex > number)
            {
                return;
            }
            for (int i = nextIndex; i < sentence.Length; i++)
            {
                Console.WriteLine(-1);
            }
            Console.WriteLine(-1);
        }
    }
}