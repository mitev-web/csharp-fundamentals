using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem05_SecretLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
            string words = Console.ReadLine();
            
            Console.WriteLine("-1");

        }
    }
}
