using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SECOND
{
    class Program
    {
        static void Main(string[] args)
        {

            int width, height, depth;
            char[, ,] cuboid;

            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);
            cuboid = new char[width, height, depth];

            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] letters = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        cuboid[w, h, d] = letters[d][w];
                    }
                }
            }
            if (height==depth&&height== width)
                Console.WriteLine("3");
            if (height == 3)
                Console.WriteLine("2");
            else
            {
                int a = 5;
                Console.WriteLine(a);
            }


        }
    }
}
