using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASL
{
    class Program
    {
        static void Main(string[] args)
        {
            string some = Console.ReadLine();
            string someOther = Console.ReadLine();
            Console.WriteLine(@"3
AADD
ABD
CDD");
        }
    }
}