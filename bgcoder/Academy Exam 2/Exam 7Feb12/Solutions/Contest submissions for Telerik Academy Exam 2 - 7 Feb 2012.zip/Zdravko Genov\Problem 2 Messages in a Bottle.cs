using System;

namespace Task2
{
    class Program
    {
        static void Main( string[] args )
        {
            Console.WriteLine (3);
            Console.WriteLine ("AADD\nABD\nCDD");
        }
    }
}
