using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05_SecretLanguage
{
    class Program
    {
        static int counter = 0;

        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
            string stringWords = Console.ReadLine();

            //string sentence = "neotowheret";
            //string stringWords = "one, two, three, there";

            char[] separators = new char[] { ',', '.' };

            string[] words = stringWords.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                words[i] = words[i].Trim();
            }

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < words.Length; i++)
            {
                sb.Append(words[i]);
            }

            StringBuilder builder = new StringBuilder();
            int index = 0;
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length + index > sentence.Length)
                {
                    break;
                }
                for (int j = index; j < words[i].Length + index; j++)
                {
                    builder.Append(sentence[j]);
                }
                 
                CalculateCost(words[i], builder.ToString());

                builder.Clear();

                index += words[i].Length;
                if (index >= sentence.Length)
                {
                    break;
                }
            }
            Console.WriteLine(counter);
        }

        static void CalculateCost(string word, string sWord)
        {
            for (int i = 0; i < word.Length; i++)
            {
                if (word[i] != sWord[i])
                {
                    counter++;
                }
            }
        }
    }
}