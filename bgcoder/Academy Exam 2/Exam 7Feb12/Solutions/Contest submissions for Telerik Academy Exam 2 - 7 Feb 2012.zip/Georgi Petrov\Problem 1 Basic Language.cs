using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace _03_Cooking
{
    class Program
    {
        enum productType {tbsps, tsps, ls, flozs, mls, gals, pts, qts, cups};
        static Dictionary<string, double> dictQuantity = new Dictionary<string, double>();
        static Dictionary<string, productType> dictType = new Dictionary<string, productType>();
        static string ProductTypeToString(productType type)
        {
            switch (type)
            {
                case productType.tbsps:
                    return "tbsps";
                case productType.tsps:
                    return "tsps";
                case productType.ls:
                    return "ls";
                case productType.mls:
                    return "mls";
                case productType.flozs:
                    return "fl ozs";
                case productType.gals:
                    return "gals";
                case productType.pts:
                    return "pts";
                case productType.qts:
                    return "qts";
                case productType.cups:
                    return "cups";
            }
            return "";
        }


        static productType DetermineType(string type)
        {
            if (type.Equals("tbsps") == true)
            {
                return productType.tbsps;
            }
            if (type.Equals("tsps") == true)
            {
                return productType.tsps;
            }
            if (type.Equals("ls") == true)
            {
                return productType.ls;
            }
            if (type.Equals("mls") == true)
            {
                return productType.mls;
            }
            if (type.Equals("fl ozs") == true)
            {
                return productType.flozs;
            }
            if (type.Equals("gals") == true)
            {
                return productType.gals;
            }
            if (type.Equals("pts") == true)
            {
                return productType.pts;
            }
            if (type.Equals("qts") == true)
            {
                return productType.qts;
            }
            if (type.Equals("cups") == true)
            {
                return productType.cups;
            }
            return productType.cups;
        }
        static double ConvertFrom(double quantity, productType type)
        {
            // Everything to cups
            switch (type)
            {
                case productType.cups:
                    return quantity;
                case productType.flozs:
                    return quantity / 8;
                case productType.gals:
                    return quantity / 4 / 2 / 2;
                case productType.ls:
                    return quantity / 1000 * 5 * 48;
                case productType.mls:
                    return quantity / 5 * 48;
                case productType.pts:
                    return quantity / 2;
                case productType.qts:
                    return quantity / 2 / 2;
                case productType.tbsps:
                    return quantity * 48;
                case productType.tsps:
                    return quantity * 3 * 48;
            }
            return 0;
        }

        static double ConvertTo(double quantity, productType type)
        {
            switch (type)
            {
                case productType.cups:
                    return quantity;
                case productType.flozs:
                    return quantity * 8;
                case productType.gals:
                    return quantity * 4 * 2 * 2;
                case productType.ls:
                    return quantity * 1000 / 5 / 48;
                case productType.mls:
                    return quantity * 5 / 48;
                case productType.pts:
                    return quantity * 2;
                case productType.qts:
                    return quantity * 2 * 2;
                case productType.tbsps:
                    return quantity / 48;
                case productType.tsps:
                    return quantity / 3 / 48;
            }
            return 0;

        }

        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("");
            int N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                string line = Console.ReadLine();
                string[] words = line.Split(new string[] {":"}, StringSplitOptions.RemoveEmptyEntries);
                words[2] = words[2].ToUpper();
                if (dictQuantity.ContainsKey(words[2]))
                {
                    productType type = DetermineType(words[1]);
                    double quantity = double.Parse(words[0]);
                    quantity = ConvertFrom(quantity, type);

                    double previous = dictQuantity[words[2]];
                    quantity += previous;
                    dictQuantity[words[2]] = quantity;
                }
                else
                {
                    // Parse the value
                    productType type = DetermineType (words[1]);
                    double quantity = double.Parse(words[0]);
                    quantity = ConvertFrom(quantity, type);
                    dictQuantity.Add(words[2], quantity);
                    dictType.Add(words[2], type);
                }
            }
            int M = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                string line = Console.ReadLine();
                string[] words = line.Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                words[2] = words[2].ToUpper();
                if (dictQuantity.ContainsKey(words[2]))
                {
                    productType type = DetermineType(words[1]);
                    double quantity = double.Parse(words[0]);
                    quantity = ConvertFrom(quantity, type);

                    double previous = dictQuantity[words[2]];
                    quantity -= previous;
                    dictQuantity[words[2]] = quantity;
                }
            }
            foreach (KeyValuePair<string, double> pair in dictQuantity)
            {
                if (pair.Value != 0)
                {
                    productType requiredType = dictType[pair.Key];
                    double requiredValue = ConvertTo(pair.Value, requiredType);
                    Console.WriteLine("{0,2}:{1}:{2}", requiredValue, ProductTypeToString(requiredType), pair.Key);
                }
            }

        }
    }
}
