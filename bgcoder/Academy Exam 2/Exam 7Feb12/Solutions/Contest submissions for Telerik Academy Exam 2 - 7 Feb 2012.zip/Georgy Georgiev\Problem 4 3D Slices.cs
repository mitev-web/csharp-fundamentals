using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Cubes
{ 
   
    class Program
    {
        static int w;
        static int h;
        static int d;
        static int[,,] cube;
        

        static void Input()
        {
            Match match = Regex.Match(Console.ReadLine(), @"[\d]{1,}");
            w = int.Parse(match.ToString());
            h = int.Parse(match.NextMatch().ToString());
            match = match.NextMatch();
            d = int.Parse(match.NextMatch().ToString());
        }

        static void InputCube()
        {
            // int index = -1;
            // int offset = 0;
            cube = new int[w, d, h];
            // StringBuilder sb = new StringBuilder((w + 1) * d);
            //sb.Append("3 4 1 9 | 1 2 3 8 | 1 5 6 7 | 1 2 1 9 | 5 1 3 9 | 5 3 3 8");
            for (int i = 0; i < h; i++)
            {
                //sb.Append(Console.ReadLine());
                Match match = Regex.Match(Console.ReadLine(), @"-*[\d]{1,}");
                for (int j = 0; j < d; j++)
                {
                    //index++;
                    for (int k = 0; k < w; k++)
                    {
                        cube[k, j, i] = int.Parse(match.ToString());
                        if (k == w - 1)
                        {
                            break;
                        }
                        if (match.Success)
                        {
                            match = match.NextMatch();
                        }
                       
                        // Console.WriteLine(k + index + j * w);
                    }
                    //offset += 1;
                }
                //if (sb.Length >= 30)
                //{
                //    sb.Remove(0, 30);
                //} 
                // Console.WriteLine(sb.Length);

                //sb.Clear();
                // index = -1;
                // offset = 0;

            }
        }

        //static void InputCube()
        //{
        //    int index = -1;
        //    int offset = 0;
        //    cube = new int[w, d, h];
        //    StringBuilder sb = new StringBuilder((w + 1) * d);
        //    //sb.Append("3 4 1 9 | 1 2 3 8 | 1 5 6 7 | 1 2 1 9 | 5 1 3 9 | 5 3 3 8");
        //    for (int i = 0; i < h; i++)
        //    {
        //        sb.Append(Console.ReadLine());
        //        for (int j = 0; j < d; j++)
        //        {
        //            index++;
        //            for (int k = 0; k < w; k++)
        //            {
        //                cube[k, j, i] = int.Parse(sb[2 * k + index + 2 * j * w + offset].ToString());
        //                // Console.WriteLine(k + index + j * w);
        //            }
        //            offset += 1;
        //        }
        //        //if (sb.Length >= 30)
        //        //{
        //        //    sb.Remove(0, 30);
        //        //} 
        //        // Console.WriteLine(sb.Length);

        //        sb.Clear();
        //        index = -1;
        //        offset = 0;

        //    }
        //}

        static int Volume(int width, int dept, int height )
        {
            if (width == 0 || height == 0 || dept == 0)
            {
                return 0;
            }
            
            if (width ==1 && height==1 && dept ==1)
            {
                return cube[0,0,0];
            }

            int volume = 0;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < dept; j++)
                {
                    for (int k = 0; k < height; k++)
                    {
                        volume += cube[i, j, k];
                    }
                }                
            }
            return volume;
        }

        static int Slices()
        {
            int slices = 0;
            int volume  = Volume(w,d,h);
            for (int i = 0; i < w; i++)
            {
                int vol =  Volume(i, d, h);

                if (volume - vol == vol)
                {
                    slices++;
                }
            }
            for (int i = 0; i < d; i++)
            {
                int vol = Volume(w,i, h);

                if (volume - vol == vol)
                {
                    slices++;
                }
            }
            for (int i = 0; i < h; i++)
            {
                int vol = Volume(w,d,i);

                if (volume - vol == vol)
                {
                    slices++;
                }
            }
            return slices;
        }






        static void Main(string[] args)
        {
            Input();
            //if (w==1 && d==1 && h==1)
            //{
            //    Console.WriteLine("{0} {1}", 1, 1);
            //    return;
            //}
           // Console.WriteLine(w + ", " + h + ", " + d);
            InputCube();
            //foreach (var item in cube)
            //{
            //    Console.Write(item);
            //}
            //Console.WriteLine(":"+cube[3,1,1]*1);
            //Console.WriteLine(  cube.Length);
            //Console.WriteLine(Volume(w,d,h));
           Console.WriteLine(Slices());
            
        }
    }
}
