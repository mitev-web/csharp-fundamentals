using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace zad2
{
    struct Cipher
    {
        public char value;
        public string code;
    }
    class Program
    {
        static List<Cipher> makeList(string cipher)
        {
            List<Cipher> list = new List<Cipher>();
            StringBuilder s = new StringBuilder();
            Cipher temp = new Cipher();
            s.Append(cipher[0]);
            for (int i = 1; i < cipher.Length; i++)
            {

                if (!Char.IsLetter(cipher[i]))
                    s.Append(cipher[i]);
                else
                {
                    temp.value = s[0];
                    temp.code = s.ToString().Substring(1);
                    list.Add(temp);
                    s.Clear();
                    s.Append(cipher[i]);
                }
            }
            temp.value = s[0];
            temp.code = s.ToString().Substring(1);
            list.Add(temp);
            return list;
        }
        static void Main(string[] args)
        {
            string digit = Console.ReadLine();
            string cipher = Console.ReadLine();
            List<Cipher> list = new List<Cipher>();
            string digitCopy = digit;
            StringBuilder helper = new StringBuilder(digit);
            list = makeList(cipher);
            List<string> result = new List<string>();
            foreach (Cipher c in list)
            {
                helper.Append(  helper.ToString().Replace(c.code, c.value.ToString()));
                for (int i = 0; i < list.Count; i++)
                    digitCopy = digitCopy.Replace(list[i].code, list[i].value.ToString());
                result.Add(digitCopy);
                digitCopy = digit;
            }
            string[] lol = result.Distinct().ToArray();
            long k;
            Console.WriteLine(lol.Count());
            foreach (string s in lol)
            {
                if (Int64.TryParse(s, out k))
                {
                    Console.WriteLine(0);
                    return;
                }
                Console.WriteLine(s);
            }



        }

    }


}
