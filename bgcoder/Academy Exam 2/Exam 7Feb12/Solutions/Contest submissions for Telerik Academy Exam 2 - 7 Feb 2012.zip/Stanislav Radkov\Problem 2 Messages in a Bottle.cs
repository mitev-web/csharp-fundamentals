using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class LetterCoding
    {
        public char Letter { get; set; }
        public string Code { get; set; }

        public override string ToString()
        {
            return Letter.ToString() + Code;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<string> possibleDecodings = new List<string>();
            StringBuilder currentDecoding = new StringBuilder();

            string message = Console.ReadLine();
            string cipher = Console.ReadLine();

            List<LetterCoding> letterCodings = BreakDownCipher(cipher);
            FindPossibleDecodings(message, 0, letterCodings, possibleDecodings, currentDecoding);

            Console.WriteLine(possibleDecodings.Count);
            possibleDecodings.Sort();
            possibleDecodings.ForEach( decoding => Console.WriteLine(decoding));
        }

        private static void FindPossibleDecodings(string message, Int32 currentIndex, List<LetterCoding> letterCodings, List<string> possibleDecodings, StringBuilder currentDecoding)
        {
            foreach (LetterCoding letter in letterCodings)
            {
                if (CodeMatch(message, currentIndex, letter))
                {
                    currentDecoding.Append(letter.Letter);

                    Int32 nextIndex = currentIndex + letter.Code.Length;
                    if (nextIndex == message.Length)
                    {
                        possibleDecodings.Add(currentDecoding.ToString());
                    }
                    else
                    { 
                        FindPossibleDecodings( message,  nextIndex, letterCodings,  possibleDecodings, currentDecoding);
                    }
                    
                    currentDecoding.Remove(currentDecoding.Length - 1, 1);
                }
            }
        }


        private static List<LetterCoding> BreakDownCipher(string cipher)
        {
            List<LetterCoding> letterCodings = new List<LetterCoding>();
            char letter = cipher[0]; ;
            StringBuilder code = new StringBuilder();
            LetterCoding lc = new LetterCoding();

            for (int i = 1; i < cipher.Length; i++)
            {

                if (Char.IsDigit(cipher[i]))
                {
                    code.Append(cipher[i]);
                }
                else
                {
                    lc = new LetterCoding();
                    lc.Letter = letter;
                    lc.Code = code.ToString();
                    letterCodings.Add(lc);

                    code.Clear();
                    letter = cipher[i];
                }

            }

            lc = new LetterCoding();
            lc.Letter = letter;
            lc.Code = code.ToString();
            letterCodings.Add(lc);

            return letterCodings;
        }

        private static bool CodeMatch(string message, Int32 index, LetterCoding codedLetter)
        {
            bool match = true;

            for (int i = 0; i < codedLetter.Code.Length; i++)
            {
                if ((index + i) >= message.Length)
                {
                    match = false;
                    break;
                }

                if (message[index + i] != codedLetter.Code[i])
                {
                    match = false;
                    break;
                }
            }

            return match;
        }

    }
}
