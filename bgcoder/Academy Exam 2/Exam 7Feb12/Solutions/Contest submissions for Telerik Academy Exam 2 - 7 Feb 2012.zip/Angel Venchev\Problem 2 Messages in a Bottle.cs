using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zad2
{
    class Program
    {

        static void Main(string[] args)
        {
            const int size = 10000;
            string msg = Console.ReadLine();
            string code = Console.ReadLine();
            //string msg = "111111322";
            //string code = "A1B11C111D1111E13F22G3";
            char[] chars;
            string[] key;
            bool startReadKey = false;
            int count = 0;
            int pointer = -1, combCount = 0, realCount = 0;
            bool found = true, lampa = false;
            StringBuilder[] combinations = new StringBuilder[size];
            string[] results = new string[size];
            for (int i = 0; i < size; i++)
            {
                combinations[i] = new StringBuilder();
            }
            StringBuilder temp = new StringBuilder();
            for (int i = 0; i < code.Length; i++)
            {
                if (code[i] < '0' || code[i] > '9')
                {
                    count++;
                }
            }
            chars = new char[3*count];
            key = new string[3*count];
            for (int i = 0; i < code.Length; i++)
            {
                if (code[i] > '0' && code[i] < '9')
                {
                    temp.Append(code[i]);
                    startReadKey = true;
                }
                else
                {
                    if (startReadKey)
                    {
                        key[pointer] = temp.ToString();
                        temp = new StringBuilder();
                    }
                    pointer++;
                    chars[pointer] = code[i];
                }
            }
            key[pointer] = temp.ToString();
            for (int i = 0; i < count; i++)
            {
                key[count + i] = key[i];
                chars[count + i] = chars[i];
                key[2 * count + i] = key[i];  
            }

 
            for(int jm = 0; jm < count; jm++)
            {
                for (int i = 0; i < msg.Length; i++)
                {
                    for (int k = jm; k < count + jm; k++)
                    {
                        if (key[k].Length > msg.Length)
                        {
                            continue;
                        }
                        for (int j = 0; j < key[k].Length; j++)
                        {
                            if (msg[i + j] != key[k][j])
                            {
                                found = false;
                                break;
                            }
                        }
                        if (found == true)
                        {
                            combinations[combCount].Append(chars[k]);
                            i += key[k].Length-1;
                            lampa = true;
                            break;
                        }
                        found = true;
                    }
                    if (!lampa)
                        break;
                }
                if (!lampa)
                    break;
                combCount++;
            }



            int tr = 0;
            for (int jm = 0; jm < count; jm++)
            {
                for (int i = 0; i < msg.Length; i++)
                {
                    for (int k = jm; k < count + jm; k++)
                    {
                        if (key[k].Length > msg.Length)
                        {
                            continue;
                        }
                        for (int j = 0; j < key[k].Length; j++)
                        {
                            if (msg[i + j] != key[k][j])
                            {
                                found = false;
                                break;
                            }
                        }
                        if (found == true)
                        {
                            combinations[combCount].Append(chars[k]);
                            i += key[k].Length - 1;
                            jm++;
                            lampa = true;
                            break;
                        }
                        found = true;
                    }
                    if (!lampa)
                        break;
                }
                if (!lampa)
                    break;
                combCount++;
                jm = tr;
                tr++;
            }





            if (!lampa)
            {
                Console.WriteLine(0);
                return;
            }



            for(int i = 0; i < combCount; i++)
            {
                for(int k = i+1; k < combCount;k++)
                {
                    if(combinations[i].Equals(combinations[k]))
                    {
                        combinations[k] = new StringBuilder();
                    }
                }
            }
            int t = 0;
            for(int i = 0; i < combCount;i++)
            {
                if(combinations[i].Length > 0)
                {
                    results[t] = combinations[i].ToString();
                    realCount++;
                    t++;
                }
            }
            for(int i = 0; i < realCount-1;i++)
            {
                for(int k = i+1; k < realCount;k++)
                {
                    if(string.Compare(results[i], results[k], true) > 0)
                    {
                        string zaMalko = results[i];
                        results[i] = results[k];
                        results[k] = zaMalko;
                    }
                }
            }
            Console.WriteLine(realCount);
            for (int i = 0; i < realCount; i++)
            {
                Console.WriteLine(results[i]);
            }
        }
    }
}
