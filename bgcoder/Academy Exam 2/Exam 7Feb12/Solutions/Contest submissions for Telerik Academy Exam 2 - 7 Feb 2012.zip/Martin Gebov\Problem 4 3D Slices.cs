using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.IO;

class Program
{
    static int width;
    static int height;
    static int depth;
    static int totalCounter = 0;
    static short[, ,] cuboid;
    //static StreamReader sr = new StreamReader("Cube.txt");
    static void Main(string[] args)
    {
        ReadCuboid();
        SplitsByHeight();
        SplitsByDepth();
        SplitsByWidth();
        Console.WriteLine(totalCounter);

    }

    private static void SplitsByWidth()
    {
        int[] splitsByWidth = new int[width];
        int counter = 0;

        for (int w = 0; w < width; w++)
        {
            for (int h = 0; h < height; h++)
            {
                for (int d = 0; d < depth; d++)
                {
                    splitsByWidth[counter] += cuboid[w, h, d];
                }
            }
            counter++;
        }
        int firstChunk = 0;
        int secondChunk = 0;
        for (int i = 0; i < splitsByWidth.Length-1; i++)
        {
            for (int k = 0; k <= i; k++)
            {
                firstChunk += splitsByWidth[k];
            }
            for (int j = i + 1; j < splitsByWidth.Length; j++)
            {
                secondChunk += splitsByWidth[j];

            }
            if (firstChunk == secondChunk)
            {
                totalCounter++;
            }
            firstChunk = 0;
            secondChunk = 0;
        }
    }

    private static void SplitsByDepth()
    {
        int[] splitsByDepth = new int[depth];
        int counter = 0;

        for (int d = 0; d < depth; d++)
        {
            for (int h = 0; h < height; h++)
            {
                for (int w = 0; w < width; w++)
                {
                    splitsByDepth[counter] += cuboid[w, h, d];
                }
            }
            counter++;
        }
        int firstChunk = 0;
        int secondChunk = 0;
        for (int i = 0; i < splitsByDepth.Length-1; i++)
        {
            for (int k = 0; k <= i; k++)
            {
                firstChunk += splitsByDepth[k];
            }
            for (int j = i + 1; j < splitsByDepth.Length; j++)
            {
                secondChunk += splitsByDepth[j];

            }
            if (firstChunk == secondChunk)
            {
                totalCounter++;
            }
            firstChunk = 0;
            secondChunk = 0;
        }
    }

    private static void SplitsByHeight()
    {
        int[] splitsByHeight = new int[height];
      
        int counter = 0;
        for (int h = 0; h < height; h++)
        {
            for (int d = 0; d < depth; d++)
            {
                for (int w = 0; w < width; w++)
                {
                    splitsByHeight[counter] += cuboid[w, h, d];
                }
            }
            counter++;
        }
        int firstChunk = 0;
        int secondChunk = 0;
        for (int i = 0; i < splitsByHeight.Length-1; i++)
        {

            for (int k = 0; k <=i; k++)
            {
                firstChunk += splitsByHeight[k];
            }
            for (int j = i + 1; j < splitsByHeight.Length; j++)
            {
                secondChunk += splitsByHeight[j];

            }
            if (firstChunk == secondChunk)
            {
                totalCounter++;
            }
            firstChunk = 0;
            secondChunk = 0;
        }
    }
    private static void ReadCuboid()
    {
        // Read the cuboid size
        string cuboidSize = Console.ReadLine();
        string[] sizes = cuboidSize.Split();
        width = int.Parse(sizes[0]);
        height = int.Parse(sizes[1]);
        depth = int.Parse(sizes[2]);

        // Read the cuboid content
        cuboid = new short[width, height, depth];
        for (int h = 0; h < height; h++)
        {
            string line = Console.ReadLine();
            string[] sequences = line.Split('|');
            for (int d = 0; d < depth; d++)
            {
                string[] numbers = sequences[d].Split(
                    new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for (int w = 0; w < width; w++)
                {
                    short cubeValue = short.Parse(numbers[w]);
                    cuboid[w, h, d] = cubeValue;
                }
            }
        }
    }
}
