using System;
using System.Collections.Generic;
using System.Linq;

namespace _05.SecretLanguage
{
    class SecretLanguage
    {
        static string sentence;
        static void Main(string[] args)
        {
            sentence = Console.ReadLine();

            string[] words = Console.ReadLine().Split("\", ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

            Console.WriteLine(CalculateCost(words));
        }

        static int CalculateCost(string[] words)
        {
            int sum = 0;
            int cost = 0;
            int index = 0;
            foreach (var word in words)
            {
                if (word.Length > sentence.Length - index)
                {
                    continue;
                }
                cost = CalculateWordCost(sentence.Substring(index, word.Length), word);
                index += word.Length;
                if (cost > 0)
                {
                    sum += cost;
                }
                if (index >= sentence.Length)
                {
                    index = index - word.Length;
                }
            }

            if (sum > 0)
            {
                return sum;   
            }
            else
            {
                return -1;
            }
        }

        static int CalculateWordCost(string sentencePart,string word)
        {
            List<char> letters = new List<char>();
            List<int> positions = new List<int>();
            if (sentencePart == word)
            {
                return 0;
            }
            else
            {
                for (int i = 0; i < sentencePart.Length; i++)
                {
                    if (sentencePart[i] != word[i])
                    {
                        letters.Add(word[i]);
                        positions.Add(letters.Count - 1);
                    }
                    else
                    {
                        positions.Add(-1);
                        letters.Add(' ');
                    }
                }
                char[] current = new char[word.Length];
                int shiftCount = 0;
                string check = String.Empty;
                while (check != sentencePart)
                {
                    shiftCount++;
                    letters = Shift(letters);
                    for (int i = 0; i < sentencePart.Length; i++)
                    {
                        if (positions[i] >= 0)
                        {
                            current[i] = letters[positions[i]];
                        }
                        else
                        {
                            current[i] = word[i];
                        }
                    }

                    check = new string(current);
                    if (shiftCount == letters.Count)
                    {
                        return -1;
                    }
                }
                return shiftCount * letters.Count;
            }
        }

        static List<char> Shift(List<char> letters)
        {
            char last = letters[0];
            for (int i = 0; i < letters.Count - 1; i++)
			{
                letters[i] = letters[i + 1];
			}

            letters[letters.Count - 1] = last;

            return letters;
        }
    }
}
