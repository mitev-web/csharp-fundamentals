using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem01_BasicLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            StringBuilder command = new StringBuilder();
            StringBuilder text = new StringBuilder();
            bool isBettwenBrackets = false;
            bool previousCommandWasFor = false;
            long forCount = 1;
            long currentForCount = 0;
            string forStr = "";
            while (input != "EXIT;")
            {
                
                for (int index = 0; index < input.Length; index++)
                {
                    if (input[index] != ' ' && isBettwenBrackets == false)
                    {
                        if (input[index] != ';')
                        {
                            command.Append(input[index]);
                        }
                        else if (input[index] == ';')
                        {
                            forCount = 1;
                        }
                        switch (command.ToString())
                        {
                            case "PRINT":
                                command.Clear();
                                int currentIndex = index;
                                if (forCount < 1)
                                {
                                    Console.WriteLine();
                                    return;
                                }
                                for (int i = 0; i < forCount; i++)
                                {
                                    index = currentIndex;
                                    while (isBettwenBrackets == false)
                                    {

                                        if (input[index] == '(')
                                        {
                                            isBettwenBrackets = true;
                                        }
                                        index++;
                                    }
                                    while (input[index] != ')')
                                    {
                                        text.Append(input[index]);
                                        index++;
                                    }
                                    
                                    isBettwenBrackets = false;
                                    previousCommandWasFor = false;
                                }
                                
                                break;
                            case "FOR":
                                command.Clear();
                                while (isBettwenBrackets == false)
	                            {
                                    if (input[index] == '(')
	                                {
                                        isBettwenBrackets = true;
	                                }
	                                index++;
	                            }
                                while (input[index] != ')')
                                {
                                    if (input[index] != ' ')
                                    {
                                        forStr += (input[index]);
                                    }
                                    
                                    index++;
                                }
                                isBettwenBrackets = false;
                                if (forStr != "")
                                {
                                    char[] separators = { ',' };
                                    string[] numbers = forStr.ToString().Split(separators, StringSplitOptions.RemoveEmptyEntries);
                                    if (long.Parse(numbers[0]) > 2000000000 || long.Parse(numbers[0]) < -2000000000 || long.Parse(numbers[0]) > 2000000000 || long.Parse(numbers[0]) < -2000000000)
                                    {
                                        Console.WriteLine();
                                        return;
                                    }
                                    if (numbers.Length == 2)
                                    {

                                        currentForCount = long.Parse(numbers[1]) - long.Parse(numbers[0]) + 1;


                                    }
                                    else
                                    {
                                        currentForCount = long.Parse(numbers[0]);

                                    }

                                    forStr = null;
                                    if (previousCommandWasFor == true)
                                    {
                                        forCount *= currentForCount;
                                    }
                                    else
                                    {
                                        forCount = currentForCount;
                                    }
                                    previousCommandWasFor = true;
                                }
                                else
                                {
                                    forCount = 1;
                                }
                                
                                
                                break;
                            case "EXIT":
                                input = "EXIT;";
                                break;
                            default:
                                break;
                        }
                        
                    }
                }
                if (input != "EXIT;")
                {
                    input = Console.ReadLine();
                }
                
            }
            Console.WriteLine(text);
            Console.WriteLine();
        }
    }
}
