using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.SecretLanguage
{

    class SecretLanguage
    {
        class Decomposer
        {
            static private int[,] costForMorph = new int[51, 51];
            static private int[,] lettersForWords = new int[51, 51];
            static private string encodedSentance;
            static private string[] searchWords;


            static private int Search(int startIndex, int endIndex)
            {
                int min = -2;
                if (startIndex > endIndex) //invalid search
                {
                    return 0;
                }
                if (costForMorph[startIndex, endIndex] != -1) //already recorded
                {
                    return costForMorph[startIndex, endIndex];
                }
                for (int index = startIndex; index <= endIndex; index++)
                {
                    int[] lettersInWord = new int[51];
                    for (int i = startIndex; i <= index; i++)
                    {
                        lettersInWord[encodedSentance[i] - 'a']++;
                    }
                    for (int word = 0; word < searchWords.Length; word++)
                    {
                        int letterCounter;
                        for (letterCounter = 0; letterCounter <= 50; letterCounter++)
                        {
                            if (lettersInWord[letterCounter] != lettersForWords[word, letterCounter])
                            {
                                break;
                            }
                        }
                        if (letterCounter == 51)
                        {
                            int count = 0;
                            for (int letterIndex = 0, indexOfLetter = startIndex; letterIndex < searchWords[word].Length; letterIndex++, indexOfLetter++)
                            {
                                if (encodedSentance[indexOfLetter] != searchWords[word][letterIndex])
                                {
                                    count++;
                                }
                            }
                            int costToMorphTheRest = Search(index + 1, endIndex);
                            if (costToMorphTheRest >= 0)
                            {
                                count += costToMorphTheRest;
                            }
                            else 
                            { 
                                continue; 
                            }
                            if (min == -2)
                            {
                                min = count;
                            }
                            else if (min > count)
                            {
                                min = count;
                            }
                        }
                    }
                }
                costForMorph[startIndex, endIndex] = min;
                return costForMorph[startIndex, endIndex];
            }
            static public int Decompose(string sentence, string[] validWords)
            {
                //initialize the searching arrays
                for (int i = 0; i <= 50; i++)
                {
                    for (int j = 0; j <= 50; j++)
                    {
                        costForMorph[i, j] = -1;
                        lettersForWords[i, j] = 0;
                    }
                }

                for (int wordsCounter = 0; wordsCounter < validWords.Length; wordsCounter++)
                {
                    for (int letterInWord = 0; letterInWord < validWords[wordsCounter].Length; letterInWord++)
                    {
                        lettersForWords[wordsCounter, validWords[wordsCounter][letterInWord] - 'a']++;
                    }
                }
                encodedSentance = sentence;
                searchWords = validWords;
                int cost = Search(0, sentence.Length - 1);
                if (cost < 0) //can't decompose
                {
                    return -1;
                }
                else return cost;
            }
        }
        static void Main(string[] args)
        {
            string sentence = Console.ReadLine();
            string[] validWords = Console.ReadLine().Split(new char[] { ',', ' ', '"' }, StringSplitOptions.RemoveEmptyEntries);

            Console.WriteLine(Decomposer.Decompose(sentence, validWords));
        }
    }
}
