using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
namespace Exam2
{
    class Program
    {
        static bool isSingleFor(string s, out int result)
        {

            string k = s.Substring(4, s.Length - 5);
            if (Int32.TryParse(k, out result))
                return true;
            return false;
        }
        static void parse(string s, Queue<string> commands)
        {
           
            StringBuilder res = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                if (!Char.IsWhiteSpace(s[i]))
                    res.Append(s[i]);
                if (s[i] == '(')
                {
                    string k = res.ToString();
                    if (String.Compare(k, "PRINT(") == 0)
                        while (s[i] != ')')
                        {
                            i++;
                            res.Append(s[i]);

                        }
                    else if (String.Compare(k, "FOR(") == 0)
                    {
                        while (s[i] != ')')
                        {
                            i++;
                            if (!Char.IsWhiteSpace(s[i]))
                                res.Append(s[i]);

                        }
                    }
                    else if (String.Compare(k, "EXIT(") == 0)
                    {
                        res.Remove(res.Length - 1, 1);
                        
                    }
                    commands.Enqueue(res.ToString());
                    res.Clear();
                }


            }

        }
        static int forCount = 0;
        static void ExecuteCommands(Queue<string> commands)
        {

            if (commands.Count == 0)
                return;
            string nextCommand = commands.First();
            if (nextCommand.StartsWith("EXIT"))
            {
                
                Environment.Exit(0);
            }
            commands.Dequeue();
            if (nextCommand.StartsWith("PRINT"))
            {

                string toPrint = nextCommand.Substring(6, nextCommand.Length - 7);
                if (forCount == 0)
                    Console.Write(toPrint);
                else
                {
                    for (int i = 0; i < forCount; i++)
                    {
                       Console.Write(toPrint);

                    }
                    forCount = 0;
                }

            }
            if (nextCommand.StartsWith("FOR"))
            {
                int k;
                if (isSingleFor(nextCommand, out k))
                {
                    forCount += k;
                }
                else
                {
                    int indexOfComma = nextCommand.IndexOf(',');
                    string firstNumber = nextCommand.Substring(4, nextCommand.Length - indexOfComma - 2);

                    string secondNumber = nextCommand.Substring(indexOfComma + 1, nextCommand.Length - indexOfComma - 2);
                    k = Math.Abs(Int32.Parse(firstNumber) - Int32.Parse(secondNumber)) + 1;
                    forCount += k;
                }
            }



        }
     
        static void Main(string[] args)
        {
            Queue<string> queue = new Queue<string>();
            
            string s = "PRINT(Black and yellow, );\nFOR(0,1)PRINT(BLAACK and yellow, );\nPRINT(black and yellow...);\nEXIT;";
            string line = Console.ReadLine();
            line = line.Replace(";", "");

            line = line.Replace("EXIT", "EXIT(");
            
            parse(line, queue);

            while (queue.Count != 0)
            {
                ExecuteCommands(queue);
            }

        }
    }
}