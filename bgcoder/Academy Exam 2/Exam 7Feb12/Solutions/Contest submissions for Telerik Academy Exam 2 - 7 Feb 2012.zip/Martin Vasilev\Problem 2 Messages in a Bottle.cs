using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace task2
{
    class Program
    {
        public static int ans = 0;
        public static int counter = 0;
        public static StringBuilder DecodedMessages = new StringBuilder();
        public static List<string> DecodedWords = new List<string>();
        static void Main(string[] args)
        {
            string SecretMessage = Console.ReadLine();
            SecretMessage += "@";
            char[] code = SecretMessage.ToCharArray();
            string Cipher = Console.ReadLine();
            StringBuilder sb = new StringBuilder(Cipher);
            for (int i = 1; i < sb.Length; i++)
            {
                if (char.IsLetter(sb[i]))
                {
                    sb.Insert(i + 1, ',');
                    sb.Insert(i, ',');
                    i++;
                }
            }
            sb.Insert(1, ',');
            string[] array = sb.ToString().Split(new string[]{","},StringSplitOptions.RemoveEmptyEntries);
            int answer = FindMessages(array, code, code[0],SecretMessage);
            Console.WriteLine(answer);
            DecodedWords.Sort();
            for (int i = 0; i < DecodedWords.Count; i++)
            {
                Console.WriteLine(DecodedWords[i]);
            }
         
  
        }
        public static int FindMessages(string[] ciphers, char[] codes, char current,string SecretMessage)
        {
            
            if (current == '@')
            {
                ans++;
                DecodedWords.Add(DecodedMessages.ToString());
            }
            for (int i = 1; i < SecretMessage.Length; i++)
            {
                string SubMessage = SecretMessage.Substring(0,i);
                for (int s = 1; s < ciphers.Length; s++)
                {
                    
                    if (SubMessage == ciphers[s])
                    {
                        DecodedMessages.Append(ciphers[s-1]);
                        counter += i;
                        string NewSecretMessage = SecretMessage.Substring(i);
                        FindMessages(ciphers, codes, codes[counter], NewSecretMessage);
                        counter -= i;
                        DecodedMessages.Remove(DecodedMessages.Length - 1, 1);
                    }
                    s++;
                }

            }

            return ans;
        }
        /*
1122
A1B12C11D2
         */
    }
}
