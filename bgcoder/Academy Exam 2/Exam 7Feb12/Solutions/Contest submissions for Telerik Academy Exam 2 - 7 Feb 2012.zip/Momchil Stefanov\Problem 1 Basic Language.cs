using System;
using System.Linq;
using System.Text;

namespace _01.BasicLanguage
{
    class BasicLanguage
    {
        static string input;
        static void Main(string[] args)
        {
            StringBuilder blCode = new StringBuilder(100000);
            input = Console.ReadLine();
            while (true)
            {
                blCode.AppendLine(input);
                if (input.Contains("EXIT"))
                {
                    break;
                }
                input = Console.ReadLine();
            }

            input = blCode.ToString();
            blCode.Clear();
            bool print = false;
            bool cycle = false;
            int cycles = 1;

            for (int i = 0; i < input.Length; i++)
            {
                if (cycle)
                {
                    if (input[i] == '(')
                    {
                        int a = 0;
                        int b = 0;
                        int index = i + 1;
                        StringBuilder builder = new StringBuilder(11);
                        while (input[index] != ',' && input[index] != ')')
                        {
                            if (input[index] == '-' || Char.IsDigit(input[index]))
                            {
                                builder.Append(input[index]);
                            }
                            index++;
                        }
                        a = int.Parse(builder.ToString());
                        if (input[index] == ',')
                        {
                            index++;
                            builder.Clear();
                            while (input[index] != ')')
                            {
                                if (input[index] == '-' || Char.IsDigit(input[index]))
                                {
                                    builder.Append(input[index]);
                                }
                                index++;
                            }
                            b = int.Parse(builder.ToString());
                            cycles *= b - a + 1;
                        }
                        else
                        {
                            cycles *= a;
                        }

                        i = index;
                    }
                    if (input.Substring(i, 5) == "PRINT")
                    {
                        int index = i + 5;
                        while (input[index] != '(')
	                    {
                            index++;
	                    }

                        i = Print(index + 1, cycles);
                        cycles = 1;
                        cycle = false;
                    }
                }
                else if (print)
                {
                    if (input[i] == '(')
                    {
                       i = Print(i + 1);
                    }
                    print = false;
                }
                else
                {
                    if (i + 3 < input.Length && input.Substring(i, 3) == "FOR")
                    {
                        cycle = true;
                        i += 2;
                    }
                    if (i + 5 < input.Length && input.Substring(i, 5) == "PRINT")
                    {
                        print = true;
                        i += 4;
                    }
                }
            }
            Console.WriteLine();
        }

        static int Print(int index)
        {
            StringBuilder builder = new StringBuilder();
            while (input[index] != ')')
            {
                builder.Append(input[index]);
                index++;
            }
            string output = builder.ToString();
            Console.Write(output);
            return index;
        }

        static int Print(int index, int loops)
        {
            StringBuilder builder = new StringBuilder();
            while (input[index] != ')')
            {
                builder.Append(input[index]);
                index++;
            }
            string output = builder.ToString();
            for (int i = 0; i < loops; i++)
            {
                Console.Write(output);
            }
            
            return index;
        }
    }
}
