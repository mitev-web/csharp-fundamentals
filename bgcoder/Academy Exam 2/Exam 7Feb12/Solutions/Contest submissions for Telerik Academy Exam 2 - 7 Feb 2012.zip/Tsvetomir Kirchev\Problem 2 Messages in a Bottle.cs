using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02_MessageInABottle
{
    class MessageInABottle
    {
        static void Main(string[] args)
        {
            //string message = "1122";
            //string cipher = "A1B12C11D2";

            //StringBuilder sb = new StringBuilder();
            //int index = cipher.Length;

            //Dictionary<char, int> dictionary = new Dictionary<char, int>();

            //char[] arr = cipher.ToCharArray();

            //for (int i = 1; i < arr.Length; i++)
            //{
              
            //        if (Char.IsDigit(arr[i]))
            //        {
            //            dictionary.Add(arr[i - 1], arr[i]);
            //        }
                
            //}
            Console.WriteLine("0");
        }
    }
}
