using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.Basic_Language
{
    class Program
    {
        static void Main(string[] args)
        {
            // StringBuilder input = new StringBuilder();
            string text = "";
            while (true)
            {
                string temp = Console.ReadLine();
                text += temp;
                // input.Append(temp);
                if (temp.IndexOf("EXIT") != -1) break;
            }
            // string text = input.ToString();
            string[] separators = { ";" };
            string[] commands = text.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            string[] separators1 = { ")" };
            string[] separatorsNums = { "FOR", " ", ",", "(", "\n" };
            for (int currentCommand = 0; currentCommand < commands.GetLength(0) - 1; currentCommand++)
            {
                string[] tasks = commands[currentCommand].Split(separators1, StringSplitOptions.RemoveEmptyEntries);
                long iterations = 1;
                int currentTask = 0;
                for (currentTask = 0; currentTask < tasks.GetLength(0) - 1; currentTask++)
                {
                    if (tasks[currentTask].IndexOf("PRINT") != -1) break;
                    string[] nums = tasks[currentTask].Split(separatorsNums, StringSplitOptions.RemoveEmptyEntries);
                    if (nums.GetLength(0) == 1)
                    {
                        iterations *= long.Parse(nums[0]);
                    }
                    else
                    {
                        iterations *= (long.Parse(nums[1]) - long.Parse(nums[0]) + 1);
                    }
                }
                string print = tasks[currentTask].Substring(tasks[currentTask].IndexOf("(") + 1);
               // char[] arrayOfChars = new char[print.Length];
               // for (int i = 0; i < arrayOfChars.Length; i++)
             //   {
            //        arrayOfChars[i] = print[i];
           //     }
              //  string onConsole = new string(arrayOfChars, iterations);
                StringBuilder x = new StringBuilder();
                for(int i=0; i<iterations; i++)
                {
                    x.Append(print);
                }
                
                Console.Write(x.ToString());
            }
            Console.WriteLine();
        }
    }
}
