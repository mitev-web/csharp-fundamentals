using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.MessagesInBottle
{
    class Program
    {

        public static List<string> PermuteWords(string[] s)
        {
            string[] ss = s;//{ " AZ ", " TI ", "TOJ" };//s.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            bool[] used = new bool[ss.Length];
            string res = "";
            List<string> list = new List<string>();
            permute(ss, used, res, 0, list);
            return list;
        }

        private static void permute(string[] ss, bool[] used, string res, int level, List<string> list)
        {
            if (level == ss.Length && res != "")
            {
                list.Add(res);
                return;
            }
            for (int i = 0; i < ss.Length; i++)
            {
                if (used[i]) continue;
                used[i] = true;
                permute(ss, used, res + " " + ss[i], level + 1, list);
                used[i] = false;
            }
        }


        static void Main(string[] args)
        {
            string myMessage = Console.ReadLine();            
            string cipher = Console.ReadLine();
            //string myMessage = "1239811";
            //string cipher = "A123C11B98";
            //string myMessage = "1122";
            //string cipher = "A1B12C11D2";
            CipherSplitter(cipher);
            int maxLen = MaxLength();

            //Some loop all n!
            string newMessage = ""; // ????????????

            string[] myPermut = new string[myNum.Count];
            for (int i = 0; i < myNum.Count; i++)
            {
                myPermut[i] = (i + 1).ToString();
            }

            List<string> allPermut = PermuteWords(myPermut);

                       
            for (int g = 0; g < allPermut.Count; g++)
            {
                newMessage = myMessage;
                string[] innerPermut = allPermut[g].Split(' ');
                for (int c = 1; c < innerPermut.Length; c++)
                {
                    int i = int.Parse(innerPermut[c]) - 1;
                    int tempIndex = myMessage.IndexOf(myNum[i].ToString());
                    if ((tempIndex) != -1)
                    {
                        newMessage = newMessage.Replace(myNum[i].ToString(), myChar[i].ToString());
                    }                    
                }
                if (IsEncoded(newMessage))
                {
                    origMessage.Add(newMessage);
                }
            }
            origMessage.Sort();
                                                                  //Is this a valid loop ??? because of removing ?
            for (int g = 0; g < origMessage.Count - 1; g++)
            {
                for (int i = 0; i < origMessage.Count - 1; i++)
                {
                    if (origMessage[i] == origMessage[i + 1])
                    {
                        origMessage.Remove(origMessage[i]);
                    }
                }
                
            }
            
            
            //End loop
                                                            //SORT THEM !!!
            Console.WriteLine(origMessage.Count);
            foreach (string item in origMessage)
            {
                Console.WriteLine(item);
            }

        }

        static bool IsEncoded(string myMessage)
        {
            for (int i = 0; i < myMessage.Length; i++)
            {
                if (ABC.IndexOf(myMessage[i]) == -1)
                {
                    return false;
                }
            }
            return true;
        }

        static int MaxLength()
        {
            int myMax = 1;
            foreach (int item in myNum)
            {
                int myCounter = 0;
                int tempNum = item;

                while (tempNum % 10 != 0)
                {
                    tempNum = tempNum / 10;
                    myCounter++;
                }
                if (myCounter > myMax)
                {
                    myMax = myCounter;
                }
            }
            return myMax;
        }


        static List<char> myChar = new List<char>();
        static List<int> myNum = new List<int>();
        static List<string> origMessage = new List<string>();
        static string ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        static void CipherSplitter (string cipher)
        {
            for (int i = 0; i < cipher.Length; i++)
            {
                if (ABC.IndexOf(cipher[i]) != -1)
                {
                    myChar.Add(cipher[i]);
                    int g = i + 1;
                    int tempIndex = ABC.IndexOf(cipher[g]);
                    StringBuilder sb = new StringBuilder();
                    while ((tempIndex == -1))               //The loop can be optimized... i = g....???
                    {
                        sb.Append(cipher[g]);
                        g++;
                        if (g == cipher.Length)
                        {
                            break;
                        }
                        tempIndex = ABC.IndexOf(cipher[g]);
                    }
                    myNum.Add(int.Parse(sb.ToString()));
                }
            }
        }
    }
}
