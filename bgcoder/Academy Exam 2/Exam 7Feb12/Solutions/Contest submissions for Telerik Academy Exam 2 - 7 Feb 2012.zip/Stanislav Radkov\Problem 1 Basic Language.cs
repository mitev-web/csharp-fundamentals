using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task01
{
    enum CurrentState
    {
        WaitingForCommand,
        For,
        ForBracketOpened,
        Print,
        PrintBracketOpened,
        PrintInALoopBracketOpened,
        PrintInALoop,

        WaitingForPrint,
    }

    class Program
    {
        const string PrintCommand = "PRINT";
        const string ForCommand = "FOR";
        const string ExitCommand = "EXIT";

        private static StringBuilder output;
        private static StringBuilder innerLoop;
        private static StringBuilder nestedForLoops;

        static void Main(string[] args)
        {
            output = new StringBuilder();
            innerLoop = new StringBuilder();
            nestedForLoops = new StringBuilder();

            ParseCode();

            Console.Write(output);
            
        }

        public static void ParseCode()
        {
            Stack<Int32> loops = new Stack<int>();
            CurrentState state = CurrentState.WaitingForCommand;
            bool exitCommandFound = false;
            string inputLine;

            StringBuilder forLoop = new StringBuilder();

            while (!exitCommandFound)
            {
                inputLine = Console.ReadLine();

                for (int indexCnt = 0; indexCnt < inputLine.Length && !exitCommandFound; indexCnt++)
                {
                    switch (state)
                    {
                        case CurrentState.WaitingForCommand:
                            {
                                switch (inputLine[indexCnt])
                                {
                                    case 'E':
                                        {
                                            exitCommandFound = true;                                            
                                        }break;

                                    case 'P':
                                        {
                                            state = CurrentState.Print;
                                            indexCnt += PrintCommand.Length-1;
                                        } break;

                                    case 'F':
                                        {
                                            state = CurrentState.For;
                                            indexCnt += ForCommand.Length-1;
                                        } break;


                                    default:
                                        break;
                                }
                            }
                            break;

                        case CurrentState.For:
                            {
                                if (inputLine[indexCnt] == '(')
                                    state = CurrentState.ForBracketOpened;
                            }
                            break;

                        case CurrentState.ForBracketOpened:
                            {
                                if (inputLine[indexCnt] != ')')
                                {
                                    forLoop.Append(inputLine[indexCnt]);
                                }
                                else
                                {
                                    Int32 iterations = CalculateIterations(forLoop.ToString());
                                    forLoop.Clear();
                                    loops.Push(iterations);
                                    state = CurrentState.WaitingForCommand;
                                }
                            }break;

                        case CurrentState.WaitingForPrint:
                            {
                                if (inputLine[indexCnt] == ';')
                                {
                                    loops.Clear();
                                    state = CurrentState.WaitingForPrint;
                                }
                                else if (inputLine[indexCnt] == 'P')
                                {
                                    state = CurrentState.Print;
                                    indexCnt += PrintCommand.Length - 1;
                                }
                            }break;

                        case CurrentState.Print:
                            {
                                if (inputLine[indexCnt] == '(')
                                {
                                    if (loops.Count == 0)
                                    {
                                        state = CurrentState.PrintBracketOpened;
                                    }
                                    else
                                    {
                                        state = CurrentState.PrintInALoopBracketOpened;
                                    }
                                }
                            }
                            break;

                        case CurrentState.PrintBracketOpened:
                            {
                                if (inputLine[indexCnt] != ')')
                                {
                                    
                                    output.Append(inputLine[indexCnt]);
                                }
                                else
                                {
                                    state = CurrentState.WaitingForCommand;
                                }
                            }
                            break;

                        case CurrentState.PrintInALoopBracketOpened:
                            {
                                if (inputLine[indexCnt] != ')')
                                {
                                    innerLoop.Append(inputLine[indexCnt]);
                                }
                                else
                                {
                                    state = CurrentState.PrintInALoop;
                                }
                            }
                            break;

                        case CurrentState.PrintInALoop:
                            {
                                
                                Int32 iterations = loops.Pop();
                                
                                for (int i = 0; i < iterations; i++)
                                {
                                    nestedForLoops.Append(innerLoop);
                                }
                                
                                if (loops.Count == 0)
                                {
                                    output.Append(nestedForLoops);
                                }
                                else
                                {  
                                    while (loops.Count > 0)
                                    {
                                        iterations = loops.Pop();

                                        for (int i = 0; i < iterations-1; i++)
                                        {
                                            nestedForLoops.Append(nestedForLoops);
                                        }
                                    }
                                    output.Append(nestedForLoops);
                                }
                               
                                innerLoop.Clear();
                                nestedForLoops.Clear();

                                state = CurrentState.WaitingForCommand;
                            }
                            break;
                    }
                }
               
            }
        }        

        public static Int32 CalculateIterations(string forParams)
        {
            Int32 iterations = 0;
            string[] numbers = forParams.Split(',');

            if (numbers.Length == 1)
            {
                iterations = Int32.Parse(numbers[0]);
            }
            else
            {
                Int32 a = Int32.Parse(numbers[0]);
                Int32 b = Int32.Parse(numbers[1]);

                iterations = b - a + 1;
            }

            return iterations;
        }
    }
}