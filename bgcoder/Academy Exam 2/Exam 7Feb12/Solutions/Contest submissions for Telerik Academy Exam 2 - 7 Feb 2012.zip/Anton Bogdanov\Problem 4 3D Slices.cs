using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex._04
{
    class Program
    {
        static short[, ,] cuboid;
        static int width;
        static int height;
        static int depth;
        static int count = 0;
        static void Main(string[] args)
        {
            ReadCuboid();
            CSplit();
            Console.WriteLine(count);
        }

        private static void CSplit()
        {
            #region w
            for (int i = 0; i < width; i++)
            {
                int sumLeft = 0;
                for (int ii = 0; ii <= i; ii++)
                {
                    for (int h = 0; h < height; h++)
                    {
                        for (int d = 0; d < depth; d++)
                        {
                            sumLeft += cuboid[ii, h, d];
                        }
                    }
                }
                int sumRight = 0;
                for (int ii = i + 1; ii < width; ii++)
                {
                    for (int h = 0; h < height; h++)
                    {
                        for (int d = 0; d < depth; d++)
                        {
                            sumRight += cuboid[ii, h, d];
                        }
                    }
                }
                if (sumLeft == sumRight)
                {
                    count++;
                }
            }
            #endregion

            #region H
            for (int i = 0; i < height; i++)
            {
                int top = 0;
                for (int ii = 0; ii <= i; ii++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        for (int d = 0; d < depth; d++)
                        {
                            top += cuboid[w, ii, d];
                        }
                    }
                }
                int down = 0;
                for (int ii = i + 1; ii < height; ii++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        for (int d = 0; d < depth; d++)
                        {
                            down += cuboid[w, ii, d];
                        }
                    }
                }
                if (top == down)
                {
                    count++;
                }
            }
            #endregion

            #region D
            for (int i = 0; i < depth; i++)
            {
                int top = 0;
                for (int ii = 0; ii <= i; ii++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        for (int h = 0; h < height; h++)
                        {
                            top += cuboid[w, h, ii];
                        }
                    }
                }
                int down = 0;
                for (int ii = i + 1; ii < depth; ii++)
                {
                    for (int w = 0; w < width; w++)
                    {
                        for (int h = 0; h < height; h++)
                        {
                            down += cuboid[w, h, ii];
                        }
                    }
                }
                if (top == down)
                {
                    count++;
                }
            #endregion
            }
        }

        private static void ReadCuboid()
        {
            // Read the cuboid size
            string cuboidSize = Console.ReadLine();
            string[] sizes = cuboidSize.Split();
            width = int.Parse(sizes[0]);
            height = int.Parse(sizes[1]);
            depth = int.Parse(sizes[2]);

            // Read the cuboid content
            cuboid = new short[width, height, depth];
            for (int h = 0; h < height; h++)
            {
                string line = Console.ReadLine();
                string[] sequences = line.Split('|');
                for (int d = 0; d < depth; d++)
                {
                    string[] numbers = sequences[d].Split(
                        new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int w = 0; w < width; w++)
                    {
                        short cubeValue = short.Parse(numbers[w]);
                        cuboid[w, h, d] = cubeValue;
                    }
                }
            }
        }
    }
}

