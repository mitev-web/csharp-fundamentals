using System;
using System.Collections.Generic;

namespace _3.Cooking
{
    class Cooking
    {
        static void Main(string[] args)        
        {
            Console.WriteLine();

        }
    }
}
