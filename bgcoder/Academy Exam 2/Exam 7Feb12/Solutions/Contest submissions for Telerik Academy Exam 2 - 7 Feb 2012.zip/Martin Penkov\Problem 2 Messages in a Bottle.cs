using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _02.MessageInABottle2
{
    class Program
    {
        public struct MyChipher
        {
            public string letter;
            public string code;
            public MyChipher(string letter, string code)
            {
                this.letter = letter;
                this.code = code;
            }
        }
        public struct Decode
        {
            public int position;
            public string value;
            public Decode(int position, string value)
            {
                this.position = position;
                this.value = value;
            }

        }
        static List<List<Decode>> position = new List<List<Decode>>();
        //static List<int> path = new List<int>();
        static string path = "";
        static int END;
        static List<string> paths = new List<string>();
        static void print()
        {

            Console.WriteLine(path);
        }
        static void DFS(int current)
        {
            if (current == END)
            {
                paths.Add(path);
                return;
            }
            if (current > END)
            {
                return;
            }
            for (int i = 0; i < position[current].Count; i++)
            {
                path += position[current][i].value;
                DFS(position[current][i].position);
                path = path.Substring(0, path.Length - position[current][i].value.Length);
            }
        }

        static void Main(string[] args)
        {
            string inputCode = Console.ReadLine();
            string inputChipher = Console.ReadLine();
            END = inputCode.Length;
            List<MyChipher> chiphers = new List<MyChipher>();
            string letter = "";
            string code = "";
            bool onLetter = true;
            for (int i = 0; i < inputChipher.Length; i++)
            {
                if (inputChipher[i] >= 'A' && inputChipher[i] <= 'Z')
                {
                    if (onLetter == true)
                    {
                        letter += inputChipher[i];
                    }
                    else
                    {
                        chiphers.Add(new MyChipher(letter, code));
                        letter = "";
                        letter += inputChipher[i];
                        code = "";
                    }
                    onLetter = true;

                }
                else
                {
                    onLetter = false;
                    code += inputChipher[i];
                }
            }
            chiphers.Add(new MyChipher(letter, code));
            /*
            foreach (MyChipher x in chiphers)
            {
                Console.WriteLine("Letter: {0}   Code: {1}", x.letter, x.code);
            }
            */


            for (int i = 0; i < inputCode.Length + 180; i++)
            {
                position.Add(new List<Decode>());
            }

            for (int i = 0; i < chiphers.Count; i++)
            {
                int currentPosition = inputCode.IndexOf(chiphers[i].code);
                while (currentPosition != -1)
                {
                    position[currentPosition].Add(new Decode(currentPosition + chiphers[i].code.Length,chiphers[i].letter));
                    currentPosition = inputCode.IndexOf(chiphers[i].code, currentPosition + 1);
                }
            }
            /*
            for (int i = 0; i < inputCode.Length + 5; i++)
            {
                Console.Write("{0,2} :  Ends ", i);
                for (int j = 0; j < position[i].Count; j++)
                {
                    Console.Write("{0,2} ", position[i][j].position);
                }
                Console.WriteLine();
            }
             */
            DFS(0);
            paths.Sort();
            Console.WriteLine(paths.Count);
            foreach (string x in paths)
            {
                Console.WriteLine(x);
            }

        }
    }
}
