using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace drProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            string line1 = ""; ;
            for (int i = 0; i < N; i++)
            {
                line1 += Console.ReadLine().Replace('.', ',');
                line1 += "\n";
            }
            int M = int.Parse(Console.ReadLine());
            string line2 = "";
            for (int i = 0; i < M; i++)
            {
                line2 += Console.ReadLine().Replace('.', ',');
                line2 += "\n";
            }
            char[] character = { ':', '\n' };
            line1.ToLower();
            line2.ToLower();
            string[] array1 = line1.Split(character, StringSplitOptions.RemoveEmptyEntries);
            string[] array2 = line2.Split(character, StringSplitOptions.RemoveEmptyEntries);
            int j = 2;
            for (int i = 2; i < array1.Length; i += 3)
            {
                bool found = false;
                while (j < array2.Length)
                {
                    if (array1[i] == array2[j])
                    {
                        found = true;
                        if (array1[i - 1] == array2[j - 1])
                        {
                            decimal h = decimal.Parse(array1[i - 2].Replace('.', ',')) - decimal.Parse(array2[j - 2].Replace('.', ','));
                            Console.WriteLine("{0}:{1}:{2}", h, array2[i - 1], array2[i]);
                            break;
                        }
                        else
                        {
                            decimal l = 0;
                            if (array1[i-1] == "ls")
                            {
                                if (array2[j-1] == "mls")
                                {                                   
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - (decimal.Parse(array2[j - 2].Replace('.', ',')) / 1000);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break; 
                                }
                            }
                            if (array1[i - 1] == "tbsps")
                            {
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - (decimal.Parse(array2[j - 2].Replace('.', ',')) / 3);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - (decimal.Parse(array2[j - 2].Replace('.', ',')) * 2);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - (decimal.Parse(array2[j - 2].Replace('.', ',')) * 16);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ',')))*4.90625m);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 256);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 64);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 32);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "tsps")
                            {
                                if (array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /3);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 6);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 48);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 15);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 768);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 192);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 96);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "fl ozs")
                            {
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /6);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /2);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 8);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 30);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) *128);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) *32);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 16);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "cups")
                            {
                                if (array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 16);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 48);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /8);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 240);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 16);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 4);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 2);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "mls")
                            {
                                if (array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 15);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 5);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 30);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j-1] == "ls")
                                {
                                    
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - (decimal.Parse(array2[j - 2].Replace('.', ',')) *1000);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 240);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 3840);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 960);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 480);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "gals")
                            {
                                if (array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 256);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 768);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 128);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 16);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 3840);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /4);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 8);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "qts")
                            {
                                if (array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 64);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /192);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /32);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /4);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /960);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /4);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "pts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) / 2);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                            if (array1[i - 1] == "pts")
                            {
                                if(array2[j - 1] == "tbsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /32);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "tsps")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /96);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "fl ozs")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /16);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "cups")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /2);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "mls")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) /480);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "gals")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) *8);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                                if (array2[j - 1] == "qts")
                                {
                                    l = decimal.Parse(array1[i - 2].Replace('.', ',')) - ((decimal.Parse(array2[j - 2].Replace('.', ','))) * 2);
                                    Console.WriteLine("{0,2}:{1}:{2}", l, array2[i - 1], array2[i]);
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        j = +2;
                    }
                }
                if (found == false)
                {
                    Console.WriteLine("{0}:{1}:{2}", array2[i - 2], array2[i - 1], array2[i]);
                }
            }
        }
    }
}