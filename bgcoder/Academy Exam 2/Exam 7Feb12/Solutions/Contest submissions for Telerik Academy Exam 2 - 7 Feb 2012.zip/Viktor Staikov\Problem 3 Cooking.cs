using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cooking
{
    class Cooking
    {
        public struct product
        {
            decimal quantity;
            int measurement;
            int measurmentType;
            string productName;
            string originalName;
            public string OriginalName
            {
                get
                {
                    return this.originalName;
                }
                set
                {
                    this.originalName = value;
                    this.ProductName = this.OriginalName.ToLower();
                }
            }

            public string ProductName
            {
                get
                {
                    return this.productName;
                }
                private set
                {
                    this.productName = value;
                }
            }

            public int MeasurmentType
            {
                get
                {
                    return this.measurmentType;
                }
                set
                {
                    this.measurmentType = value;
                }
            }

            public int Measurement
            {
                get
                {
                    return this.measurement;
                }
                set
                {
                    this.measurement = value;
                }
            }

            public decimal Quantity
            {
                get
                {
                    product variable = this;
                    return variable.quantity;
                }
                set
                {
                    this.quantity = value;
                }
            }
        }

        public static string[,] name = {
                                           {"tablespoons","tbsps"},
                                           {"liters","ls"},
                                           {"fluid ounces","fl ozs"},
                                           {"teaspoons","tsps"},
                                           {"gallons","gals"},
                                           {"pints","pts"},
                                           {"quarts","qts"},
                                           {"cups","cups"},
                                           {"milliliters","mls"},
                                       };

        public static decimal[,] measurmentTrans = {
                            {  1.000M,   0.015M,   0.500M,   3.000M,   0.004M,   0.031M,   0.016M,   0.062M,  15.000M, },
                            { 66.667M,   1.000M,  33.333M, 200.000M,   0.260M,   2.083M,   1.042M,   4.167M, 1000.000M, },
                            {  2.000M,   0.030M,   1.000M,   6.000M,   0.008M,   0.063M,   0.031M,   0.125M,  30.000M, },
                            {  0.333M,   0.005M,   0.167M,   1.000M,   0.001M,   0.010M,   0.005M,   0.021M,   5.000M, },
                            {256.000M,   3.840M, 128.000M, 768.000M,   1.000M,   8.000M,   4.000M,  16.000M, 3840.000M, },
                            { 32.000M,   0.480M,  16.000M,  96.000M,   0.125M,   1.000M,   0.500M,   2.000M, 480.000M, },
                            { 64.000M,   0.960M,  32.000M, 192.000M,   0.250M,   2.000M,   1.000M,   4.000M, 960.000M, },
                            { 16.000M,   0.240M,   8.000M,  48.000M,   0.063M,   0.500M,   0.250M,   1.000M, 240.000M, },
                            {  0.067M,   0.001M,   0.033M,   0.200M,   0.000M,   0.002M,   0.001M,   0.004M,   1.000M, },
                        };

        public static product[] recipe;
        public static int recipeLenght = 0;
        public static void JoinIf(product p)
        {
            bool stopped = false;
            for (int i = 0; i < recipeLenght; i++)
            {
                if (p.ProductName == recipe[i].ProductName)
                {
                    if (p.Measurement != recipe[i].Measurement)
                    {
                        p.Quantity = p.Quantity * measurmentTrans[p.Measurement, recipe[i].Measurement];
                    }
                    recipe[i].Quantity = p.Quantity + recipe[i].Quantity;
                    stopped = true;
                    break;
                }
            }
            if (!stopped)
            {
                recipe[recipeLenght] = p;
                recipeLenght++;
            }
        }
        public static void AddToTheMeal(product p)
        {
            for (int i = 0; i < recipeLenght; i++)
            {
                if (p.ProductName == recipe[i].ProductName)
                {
                    if (p.Measurement != recipe[i].Measurement)
                    {
                        p.Quantity = p.Quantity * measurmentTrans[p.Measurement, recipe[i].Measurement];
                    }
                    recipe[i].Quantity = recipe[i].Quantity - p.Quantity;
                    break;
                }
            }
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            recipe = new product[n];
            string[] tokens = null;
            product p = new product();
            bool stop = false;
            for (int i = 0; i < n; i++)
            {
                tokens = Console.ReadLine().Split(':');
                p.Quantity=decimal.Parse(tokens[0]);
                for (int j = 0; j < 9; j++)
                {
                    for (int k = 0; k < 2; k++)
                    {
                        if (name[j,k] == tokens[1])
                        {
                            p.Measurement = j;
                            p.MeasurmentType = k;
                            stop = true;
                            break;
                        }
                    }
                    if (stop)
                    {
                        stop = false;
                        break;
                    }
                }
                p.OriginalName = tokens[2];
                JoinIf(p);
            }

            int m = int.Parse(Console.ReadLine());
            for (int i = 0; i < m; i++)
            {
                tokens = Console.ReadLine().Split(':');
                p.Quantity = decimal.Parse(tokens[0]);
                for (int j = 0; j < 9; j++)
                {
                    for (int k = 0; k < 2; k++)
                    {
                        if (name[j,k] == tokens[1])
                        {
                            p.Measurement = j;
                            p.MeasurmentType = k;
                            stop = true;
                            break;
                        }
                    }
                    if (stop)
                    {
                        stop = false;
                        break;
                    }
                }
                p.OriginalName = tokens[2];
                AddToTheMeal(p);
            }

            for (int i = 0; i < recipeLenght; i++)
            {
                if (recipe[i].Quantity > 0.0M)
                {
                    Console.WriteLine("{0:F2}:{1}:{2}",
                        recipe[i].Quantity, name[recipe[i].Measurement,recipe[i].MeasurmentType],recipe[i].OriginalName);
                }
            }
        }
    }
}
//1 - tablespoon/tbsps
//2 - liters/ls
//3 - fluid ounces/fl ozs
//4 - teaspoons/tsps
//5 - galons/gals
//6 - pints/pts
//7 - quarts/qts
//8 - cups/cups
//9 - milliliters/mls