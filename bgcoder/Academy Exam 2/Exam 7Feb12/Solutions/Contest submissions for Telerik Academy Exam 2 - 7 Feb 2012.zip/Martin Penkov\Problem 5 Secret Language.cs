using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.SecretLanguage
{
    class Program
    {
        public struct Decode
        {
            public int position;
            public int price;
            public Decode(int position, int price)
            {
                this.position = position;
                this.price = price;
            }

        }
        static List<Decode> nextNode = new List<Decode>();
        static int[] pathValue;
        static bool[] usedPosition;
        static List<List<Decode>> position = new List<List<Decode>>();
        //static List<int> path = new List<int>();
        static string path = "HA";
        static int END;
        static bool DONE = false;
        static List<string> paths = new List<string>();
        static void print()
        {

            Console.WriteLine(path);
        }
        static void Diikstra(int current)
        {
            //  if (current > END || DONE==true)
            //    {
            //        return;
            //      }
            if (current == END)
            {
                Console.WriteLine(pathValue[current]);
                DONE = true;
                return;
            }
            usedPosition[current] = true;
            for (int i = 0; i < position[current].Count; i++)
            {
                if (usedPosition[position[current][i].position] == true) continue;
                if (pathValue[position[current][i].position] > pathValue[current] + position[current][i].price)
                {
                    pathValue[position[current][i].position] = pathValue[current] + position[current][i].price;
                }
            }
            int nextValue = int.MaxValue;
            int nextPosition = -1;
            for (int i = 0; i < pathValue.Length; i++)
            {
                if (nextValue > pathValue[i] && usedPosition[i] == false)
                {
                    nextValue = pathValue[i];
                    nextPosition = i;
                }
            }
            if (nextPosition == -1)
            {
                return;
                //Console.WriteLine("FATAL ERROR!");
            }
            else
            {
                Diikstra(nextPosition);
            }
        }

        static void DFS(int current)
        {
            if (current == END)
            {
                paths.Add(path);
                return;
            }
            if (current > END || DONE == true)
            {
                return;
            }
            for (int i = 0; i < position[current].Count; i++)
            {
                // path += position[current][i].price;
                DFS(position[current][i].position);
                //path = path.Substring(0, path.Length - position[current][i].price.Length);
            }
        }
        static int ChangeCost(string x, string y)
        {
            int price = 0;
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i] != y[i])
                {
                    price++;
                }
            }
            return price;
        }
        static bool isEqual(string x, string y)
        {
            int[] letters = new int[27];
            for (int i = 0; i < x.Length; i++)
            {
                letters[(int)x[i] - 'a']++;
                letters[(int)y[i] - 'a']--;
            }
            for (int i = 0; i < letters.Length; i++)
            {
                if (letters[i] != 0)
                {
                    return false;
                }
            }
            return true;
        }

        static void Main(string[] args)
        {
            string inputCode = Console.ReadLine();
            string inputChipher = Console.ReadLine();
            string[] separators = { "\"", " ", ",", };
            string[] chiphers = inputChipher.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            END = inputCode.Length;
            //Array.Sort(chiphers);
            for (int i = 0; i < inputCode.Length + 50; i++)
            {
                position.Add(new List<Decode>());
            }

            for (int substringSize = 1; substringSize < inputChipher.Length; substringSize++)
            {
                for (int currentPosition = 0; currentPosition < inputCode.Length - substringSize + 1; currentPosition++)
                {
                    for (int currentChiper = 0; currentChiper < chiphers.Length; currentChiper++)
                    {
                        if (chiphers[currentChiper].Length != substringSize)
                        {
                            continue;
                        }
                        if (isEqual(inputCode.Substring(currentPosition, substringSize), chiphers[currentChiper]) == true)
                        {
                            position[currentPosition].Add(new Decode(currentPosition + substringSize, ChangeCost(inputCode.Substring(currentPosition, substringSize), chiphers[currentChiper])));

                        }
                    }
                }
            }

            /*
            for (int i = 0; i < inputCode.Length + 5; i++)
            {
                Console.Write("{0,2} :  Ends ", i);
                for (int j = 0; j < position[i].Count; j++)
                {
                    Console.Write("{0,2} ", position[i][j].position);
                }
                Console.WriteLine();
            }
             */


            pathValue = new int[inputCode.Length + 50];
            for (int i = 1; i < pathValue.Length; i++)
            {
                pathValue[i] = int.MaxValue;
            }
            usedPosition = new bool[inputCode.Length + 50];
            //used=false !!!
            Diikstra(0);
            if (DONE == false)
            {
                Console.WriteLine(-1);
            }
        }
    }
}
