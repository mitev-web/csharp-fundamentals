using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Task03
{
    enum MeasurementUnit
    {
        TableSpoon,
        TeaSpoon,

        Liter,
        Milliliter,

        FluidOunce,
        Cup,

        Gallon,
        Quart,

        Pint,

    }

    class Ingredient
    {
        public Double Quantity { get; set; }
        public string MeasurementUniteAsInInput { get; set; }
        public MeasurementUnit Unit { get; set; }
        public string Name { get; set; }

        public bool Used { get; set; }
        public override bool Equals(object obj)
        {
            Ingredient other = obj as Ingredient;

            return this.Name.ToLower() == other.Name.ToLower();
        }

        public override string ToString()
        {
            return string.Format("{0:0.00}:{1}:{2}", Quantity, MeasurementUniteAsInInput, Name);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            List<Ingredient> recipe = null;
            List<Ingredient> used = null;
            List<Ingredient> toAdd = null;


            recipe = ReadIngredients();
            used = ReadIngredients();
            recipe = SumUpSameProducts(recipe);
            used = SumUpSameProducts(used);
            
            toAdd = RemoveUsed(recipe, used);


            toAdd.ForEach(x => Console.WriteLine(x));
        }

        private static List<Ingredient> RemoveUsed(List<Ingredient> recipe, List<Ingredient> used)
        {
            if (used.Count == 0)
                return recipe;

            List<Ingredient> newRecipe = new List<Ingredient>();
            Ingredient ingr;

            for (int i = 0; i < recipe.Count; i++)
            {
                if (recipe[i].Used == true)
                    continue;

                List<Ingredient> usedQuantityOfThisProduct = (from u in used
                                                              where recipe[i].Name.ToLower() == u.Name.ToLower()
                                                              select u).ToList();

                if (usedQuantityOfThisProduct.Count == 0)
                {
                    newRecipe.Add(recipe[i]);
                }
                else
                {
                    ingr = new Ingredient();
                    ingr.Name = recipe[i].Name;
                    ingr.MeasurementUniteAsInInput = recipe[i].MeasurementUniteAsInInput;
                    ingr.Unit = recipe[i].Unit;
                    ingr.Quantity = recipe[i].Quantity;

                    usedQuantityOfThisProduct.ForEach(p =>
                    {
                        ingr.Quantity -= Convert(p.Quantity, p.Unit, ingr.Unit);
                        p.Used = true;
                    });

                    if (ingr.Quantity > 0)
                        newRecipe.Add(ingr);

                }
            }

            return newRecipe;
        }

        private static List<Ingredient> SumUpSameProducts(List<Ingredient> recipe)
        {
            if (recipe.Count == 0)
                return recipe;

            List<Ingredient> newRecipe = new List<Ingredient>();
            Ingredient ingr;

            for (int i = 0; i < recipe.Count; i++)
            {
                if (recipe[i].Used == true)
                    continue;

                List<Ingredient> sameProducts = (from p in recipe
                                                 where recipe[i].Name.ToLower() == p.Name.ToLower()
                                                 select p).ToList();

                if (sameProducts.Count == 1)
                {
                    newRecipe.Add(recipe[i]);
                }
                else
                {
                    ingr = new Ingredient();
                    ingr.Name = recipe[i].Name;
                    ingr.MeasurementUniteAsInInput = recipe[i].MeasurementUniteAsInInput;
                    ingr.Unit = recipe[i].Unit;

                    sameProducts.ForEach(p =>
                        {
                            ingr.Quantity += Convert(p.Quantity, p.Unit, ingr.Unit);
                            p.Used = true;
                        });

                    newRecipe.Add(ingr);

                }
            }

            return newRecipe;
        }

        private static List<Ingredient> ReadIngredients()
        {
            List<Ingredient> recipe = new List<Ingredient>();
            Int32 N = Int32.Parse(Console.ReadLine());
            Ingredient currentIngr;

            for (int i = 0; i < N; i++)
            {
                string[] input = Console.ReadLine().Split(':');

                currentIngr = new Ingredient();
                currentIngr.Name = input[2];
                currentIngr.Quantity = Double.Parse(input[0]);
                currentIngr.MeasurementUniteAsInInput = input[1];
                currentIngr.Unit = ParseMeasurementUnit(input[1].Trim());              

                recipe.Add(currentIngr);
            }

            return recipe;
        }

        private static MeasurementUnit ParseMeasurementUnit(string unit)
        {
            switch (unit.ToLower())
            {
                case "tablespoons":
                    return MeasurementUnit.TableSpoon;
                case "tbsps":
                    return MeasurementUnit.TableSpoon;

                case "teaspoons":
                    return MeasurementUnit.TeaSpoon;
                case "tsps":
                    return MeasurementUnit.TeaSpoon;

                case "liters":
                    return MeasurementUnit.Liter;
                case "ls":
                    return MeasurementUnit.Liter;

                case "milliliters":
                    return MeasurementUnit.Milliliter;

                case "mls":
                    return MeasurementUnit.Milliliter;

                case "fluid ounces":
                    return MeasurementUnit.FluidOunce;
                case "fl ozs":
                    return MeasurementUnit.FluidOunce;

                case "cups":
                    return MeasurementUnit.Cup;

                case "gallons":
                    return MeasurementUnit.Gallon;
                case "gals":
                    return MeasurementUnit.Gallon;
                case "pints":
                    return MeasurementUnit.Pint;
                case "pts":
                    return MeasurementUnit.Pint;
                case "quarts":
                    return MeasurementUnit.Quart;
                case "qts":
                    return MeasurementUnit.Quart;

                default:
                    throw new ArgumentException();
            }
        }

        private static Double Convert(Double quantity, MeasurementUnit from, MeasurementUnit to)
        {
            if (from == to)
                return quantity;

            switch (from)
            {
                case MeasurementUnit.TableSpoon:
                    {
                        if (to == MeasurementUnit.TeaSpoon)
                            return quantity * 3.0;
                    }
                    break;

                case MeasurementUnit.TeaSpoon:
                    {
                        switch (to)
                        {
                            case MeasurementUnit.TableSpoon:
                                return quantity / 3.0;

                            case MeasurementUnit.Milliliter:
                                return quantity * 5.0;

                            case MeasurementUnit.Cup:
                                return quantity / 48.0;
                        }
                    }
                    break;

                case MeasurementUnit.Liter:
                    {
                        if (to == MeasurementUnit.Milliliter)
                            return quantity * 1000.0;
                    }
                    break;
                case MeasurementUnit.Milliliter:
                    {
                        if (to == MeasurementUnit.Liter)
                            return quantity / 1000.0;

                        if (to == MeasurementUnit.TeaSpoon)
                            return quantity / 5.0;
                    }
                    break;
                case MeasurementUnit.FluidOunce:
                    {
                        if (to == MeasurementUnit.Cup)
                            return quantity / 8.0;
                    }
                    break;
                case MeasurementUnit.Cup:
                    {
                        switch (to)
                        {
                            case MeasurementUnit.FluidOunce:
                                return quantity * 8.0;

                            case MeasurementUnit.Pint:
                                return quantity / 2.0;

                            case MeasurementUnit.TeaSpoon:
                                return quantity * 48.0;
                        }
                    }
                    break;
                case MeasurementUnit.Gallon:
                    {
                        if (to == MeasurementUnit.Quart)
                            return quantity * 4.0;
                    }
                    break;
                case MeasurementUnit.Quart:
                    {
                        if (to == MeasurementUnit.Pint)
                            return quantity * 2.0;
                        if (to == MeasurementUnit.Gallon)
                            return quantity / 4.0;
                    }
                    break;
                case MeasurementUnit.Pint:
                    {
                        if (to == MeasurementUnit.Cup)
                            return quantity * 2.0;
                        if (to == MeasurementUnit.Quart)
                            return quantity / 2.0;
                    }
                    break;
            }

            throw new Exception();
        }
    }
}
