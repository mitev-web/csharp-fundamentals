using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheExam
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = "";
            string end = "";

            while (input != "EXIT;")
            {
                input = Console.ReadLine();


                if (input != "EXIT;")
                {
                    string[] wholeInput = input.Split(';');

                    if (input[0] == 'F')
                    {
                        for (int j = 0; j < wholeInput.Length; j++)
                        {
                            input = wholeInput[j];
                            if (input == "EXIT") { Console.WriteLine(); return; }
                            if (input != "")
                            {

                                long forCounts = 0;
                                int secondStart = input.IndexOf('R');
                                string forCommand = input.Substring(secondStart + 2, input.IndexOf(')') - 4);
                                string[] forComm = forCommand.Split(',');
                                for (int i = 0; i < forComm.Length; i++)
                                {
                                    if (forComm.Length > 1)
                                    {
                                        forCounts = (Convert.ToInt64(forComm[1]) - Convert.ToInt64(forComm[0])) + 1;
                                    }
                                    else
                                    {
                                        forCounts = Convert.ToInt64(forComm[0]);
                                    }

                                }
                                //Console.WriteLine(forCounts);
                                int start = input.IndexOf('T');
                                for (int i = 0; i < forCounts; i++)
                                {
                                    Console.Write(input.Substring(start + 2, input.LastIndexOf(')') - (start + 2)));
                                }
                            }

                        }
                    }
                    else
                    {
                        int start = input.IndexOf('T');
                        Console.Write(input.Substring(start + 2, input.IndexOf(')') - (start + 2)));
                    }

                }
            }
            //Console.WriteLine();
        }
    }
}