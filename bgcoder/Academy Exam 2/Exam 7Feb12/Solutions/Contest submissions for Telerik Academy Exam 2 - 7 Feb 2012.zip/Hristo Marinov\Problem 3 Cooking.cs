using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cooking
{
    public struct recipe
    {
        public double quan;
        public string measure;
        public string product;
        public recipe(double quan, string measure, string product)
        {
            this.quan = quan;
            this.measure = measure;
            this.product = product;
        }
    }
    
    class Program
    {
       static double conv(double a, string s)
       {
           double ans = a;
           if (s == "tsps") ans /= 200;
           if (s == "mls") ans /= 1000;
           if (s == "tbsps") ans /= 66.6667;
           if (s == "cups") ans /= 4.16667;
           if (s == "pts") ans /= 2.083;
           if (s == "qts") ans /= 1.041;
           if (s == "gals") ans /= 0.26;
           if (s == "fl ozs") ans /= 33.33;

           return ans;
       }

        static double conv2(double a, string s)
       {
           double ans = a;
           if (s == "tsps") ans *= 200;
           if (s == "mls") ans *= 1000;
           if (s == "tbsps") ans *= 66.6667;
           if (s == "cups") ans *= 4.16667;
           if (s == "pts") ans *= 2.083;
           if (s == "qts") ans *= 1.041;
           if (s == "gals") ans *= 0.26;
           if (s == "fl ozs") ans *= 33.33;

           return ans;
       }
        static void Main(string[] args)
        {
            recipe[] a = new recipe[1028];
            int n = int.Parse(Console.ReadLine());
            string temp1;
            string[] temp2;
            recipe temp3 = new recipe();
            int br=0;
            for(int i=0;i<n;i++)
            {
                temp1 = Console.ReadLine();
                temp2 = temp1.Split(':');
                temp3.quan = double.Parse(temp2[0]);
                temp3.measure = temp2[1];
                temp3.product = temp2[2];
                temp3.quan = conv(double.Parse(temp2[0]), temp3.measure);
                bool flag = true;
                for (int j = 0; j < br; j++)
                {
                    if (a[j].product.ToLower() == temp3.product.ToLower())
                    {
                        a[j].quan += temp3.quan;
                        flag = false;
                    }
                }
                if (flag == true)
                {
                    
                    a[br] = temp3;
                    br++;
                }
            }

            n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                temp1 = Console.ReadLine();
                temp2 = temp1.Split(':');
                temp3.quan = double.Parse(temp2[0]);
                temp3.measure = temp2[1];
                temp3.product = temp2[2];
                temp3.quan = conv(double.Parse(temp2[0]), temp3.measure);
                for (int j = 0; j < br; j++)
                {
                    if (a[j].product.ToLower() == temp3.product.ToLower())
                    {
                        a[j].quan -= temp3.quan;
                    }
                }
            }
            
            for(int i=0;i<=br;i++)
            {
                a[i].quan = conv2(a[i].quan,a[i].measure);

                if (a[i].quan >= 0.01)
                {
                    Console.WriteLine("{0:F2}:{1}:{2}", a[i].quan, a[i].measure, a[i].product);
                }
            }

        }
     }
}
