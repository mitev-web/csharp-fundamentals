using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04
{
    class Program
    {
        static void Main(string[] args)
        {
            Int32[, ,] cuboid = ReadCuboid();
            Int32 possibleWays = cuboid.PossibleWaysToSliceTheCuboidIntoEvenParts();
            Console.WriteLine(possibleWays);
        }

        private static Int32[, ,] ReadCuboid()
        {
            string[] dimensions = Console.ReadLine().Split(' ');
            Int32 w = Int32.Parse(dimensions[0]);
            Int32 h = Int32.Parse(dimensions[1]);
            Int32 d = Int32.Parse(dimensions[2]);

            Int32[, ,] cuboid = new Int32[w, h, d];

            for (int height = 0; height < h; height++)
            {
                string line = Console.ReadLine();

                string[] levels;

                if (d > 0)
                {
                    levels = line.Split('|');
                }
                else
                {
                    levels = new string[] { line };
                }

                for (int depth = 0; depth < d; depth++)
                {
                    string[] width = levels[depth].Trim().Split(' ');
                    for (int i = 0; i < width.Length; i++)
                    {
                        cuboid[i, height, depth] = Int32.Parse(width[i]);
                    }
                }
            }

            return cuboid;
        }
    }


    /// <summary>
    /// Represents the coordinates of a cell in a 3D array
    /// Stanislav Radkov®  2012 :D 
    /// </summary>
    public partial class Index3D
    {
        public Int32 W { get; set; }
        public Int32 H { get; set; }
        public Int32 D { get; set; }

        public Index3D(Int32 w, Int32 h, Int32 d)
        {
            this.W = w;
            this.H = h;
            this.D = d;
        }

        public Index3D()
            : this(0, 0, 0)
        { }

        public static Index3D operator +(Index3D a, Index3D b)
        {
            Index3D result = new Index3D();
            result.W = a.W + b.W;
            result.H = a.H + b.H;
            result.D = a.D + b.D;

            return result;
        }

        public static Index3D operator -(Index3D a, Index3D b)
        {
            Index3D result = new Index3D();
            result.W = a.W - b.W;
            result.H = a.H - b.H;
            result.D = a.D - b.D;

            return result;
        }

        public static bool operator ==(Index3D a, Index3D b)
        {
            return a.Equals(b);
        }

        public static bool operator !=(Index3D a, Index3D b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;

            if (this.GetType() != obj.GetType()) return false;

            Index3D otherIndex = (Index3D)obj;

            bool isWidthEqual = this.W == otherIndex.W;
            bool isHeightEqual = this.H == otherIndex.H;
            bool isDeepEqual = this.D == otherIndex.D;

            return isWidthEqual && isHeightEqual && isDeepEqual;
        }

        public override string ToString()
        {
            return String.Format("W:{0} H:{1} D:{2}", this.W, this.H, this.D);
        }
    }

    /// <summary>
    /// Represents the 4 directions
    /// Stanislav Radkov®  2012 :D 
    /// </summary>
    public partial class Index3D
    {
        //We assume top-left is [0,0,0]
        public static Index3D Left = new Index3D(-1, 0, 0);
        public static Index3D Right = new Index3D(1, 0, 0);
        public static Index3D Up = new Index3D(0, -1, 0);
        public static Index3D Down = new Index3D(0, 1, 0);
        public static Index3D In = new Index3D(0, 0, 1);
        public static Index3D Out = new Index3D(0, 0, -1);
    }



    /// <summary>
    /// Represents the value in a 3d array
    /// Stanislav Radkov®  2012 :D 
    /// </summary>
    public class Cell3D : Index3D, IComparable
    {
        public Int32 Value { get; set; }

        public Cell3D(Int32[, ,] array, Index3D cellIndex)
            : this(array[cellIndex.W, cellIndex.H, cellIndex.D], cellIndex)
        { }

        public Cell3D(Int32 value, Index3D cellIndex)
            : base(cellIndex.W, cellIndex.H, cellIndex.D)
        {
            this.Value = value;
        }

        public Cell3D(Int32 value, Int32 W, Int32 H, Int32 D)
            : base(W, H, D)
        {
            this.Value = value;
        }

        public int CompareTo(object obj)
        {
            if (null == obj) return 1;

            Cell3D otherCell = obj as Cell3D;
            if (otherCell != null)
                return otherCell.Value - this.Value;
            else
                throw new ArgumentException("Object is not a Cell3D");
        }

        public override string ToString()
        {
            return base.ToString() + string.Format(" Value:{0}", this.Value);
        }
    }


    /// <summary>
    /// Adds functionality to 2D Int32 arrays
    /// Stanislav Radkov®  2012 :D 
    /// 
    /// Assumes that all arrays are created in the followin manner:
    ///         Int32[,,] array = new Int32[W, H, D];
    /// </summary>
    public static class Array3DExtensions
    {
        public static bool IsInBoundary(this Int32[, ,] array, Index3D cellIndex)
        {
            bool isWidthValid = cellIndex.W >= 0 && cellIndex.W < array.GetLength(0);
            bool isHeightValid = cellIndex.H >= 0 && cellIndex.H < array.GetLength(1);
            bool isDepttValid = cellIndex.D >= 0 && cellIndex.D < array.GetLength(2);

            return isWidthValid && isHeightValid && isDepttValid;
        }

        public static Int32 GetValue(this Int32[, ,] array, Index3D cellIndex)
        {
            Int32 value = array[cellIndex.W, cellIndex.H, cellIndex.D];
            return value;
        }

        public static bool SearchInDirections(this Int32[, ,] array, Int32 value, Index3D startIndex, Index3D direction)
        {
            if (!array.IsInBoundary(startIndex))
            {
                string message = string.Format("The given index is not in the boundaries of the array! Given index:{0} , Max index in the array:{1}", startIndex, new Index3D(array.GetLength(0), array.GetLength(1), array.GetLength(2)));
                throw new ArgumentException(message);
            }

            bool found = false;
            Index3D currentPosition = startIndex;

            while (array.IsInBoundary(currentPosition))
            {
                if (array.GetValue(currentPosition) == value)
                {
                    found = true;
                    break;
                }
                else
                {
                    currentPosition += direction;
                }
            }

            return found;
        }

        public static List<Index3D> IndexOf(this Int32[, ,] array, Int32 value)
        {
            List<Index3D> cellsContainingValue = new List<Index3D>();

            for (int w = 0; w < array.GetLength(0); w++)
            {
                for (int h = 0; h < array.GetLength(1); h++)
                {
                    for (int d = 0; d < array.GetLength(2); d++)
                    {
                        if (array[w, h, d] == value)
                        {
                            cellsContainingValue.Add(new Index3D(w, h, d));
                        }
                    }
                }
            }

            return cellsContainingValue;
        }

        /// <summary>
        /// Searches for the max value in the given direction while in the boundaries of the array
        /// </summary>
        /// <param name="startIndex">The position to start the search from [including]</param>
        /// <param name="direction"> The direction to search in </param>
        /// <returns>Max value</returns>
        public static Int32 SearchForMaxValueInDirection(this Int32[, ,] array, Index3D startIndex, Index3D direction)
        {
            if (!array.IsInBoundary(startIndex))
            {
                string message = string.Format("The given index is not in the boundaries of the array! Given index:{0} , Max index in the array:{1}", startIndex, new Index3D(array.GetLength(0), array.GetLength(1), array.GetLength(2)));
                throw new ArgumentException(message);
            }

            Int32 maxValue = Int32.MinValue;
            Index3D currentPosition = startIndex;

            while (array.IsInBoundary(currentPosition))
            {
                if (array.GetValue(currentPosition) > maxValue)
                {
                    maxValue = array.GetValue(currentPosition);
                }
                else
                {
                    currentPosition += direction;
                }
            }

            return maxValue;
        }

        public static List<Cell3D> FromStartToEndInDesiredDirectionToList(this Int32[, ,] array, Index3D startIndex, Index3D direction)
        {
            if (!array.IsInBoundary(startIndex))
            {
                string message = string.Format("The given index is not in the boundaries of the array! Given index:{0} , Max index in the array:{1}", startIndex, new Index3D(array.GetLength(0), array.GetLength(1), array.GetLength(2)));
                throw new ArgumentException(message);
            }

            List<Cell3D> elements = new List<Cell3D>();
            Index3D currentIndex = startIndex;

            while (array.IsInBoundary(currentIndex))
            {
                Cell3D element = new Cell3D(array.GetValue(currentIndex), currentIndex);
                elements.Add(element);

                currentIndex += direction;
            }

            return elements;
        }

        public static Int32 PossibleWaysToSliceTheCuboidIntoEvenParts(this Int32[, ,] cuboid)
        {
            Int32 possibleWays = 0;

            possibleWays += cuboid.PossibleWaysToSliceHorizontallyInToEvenPieces();
            possibleWays += cuboid.PossibleWaysToSliceVerticallyInToEvenPieces();
            possibleWays += cuboid.PossibleWaysToSliceInDeepInToEvenPieces();

            return possibleWays;
        }

        private static Int32 PossibleWaysToSliceHorizontallyInToEvenPieces(this Int32[, ,] cuboid)
        {

            Index3D horizontalSlicingIndex = new Index3D(0, 0, 0);

            List<Cell3D> tube = new List<Cell3D>();
            List<Int32> slicesSums = new List<Int32>();

            while (cuboid.IsInBoundary(horizontalSlicingIndex))
            {
                Index3D currentPositionToGetListFrom = horizontalSlicingIndex;

                Int32 currentSliceSum = 0;
                while (cuboid.IsInBoundary(currentPositionToGetListFrom))
                {
                    tube = cuboid.FromStartToEndInDesiredDirectionToList(currentPositionToGetListFrom, Index3D.In);
                    tube.ForEach(cell => currentSliceSum += cell.Value);

                    currentPositionToGetListFrom += Index3D.Right;
                }

                slicesSums.Add(currentSliceSum);
                horizontalSlicingIndex += Index3D.Down;
            }

            return CountEventSlices(slicesSums);
        }

        private static Int32 PossibleWaysToSliceVerticallyInToEvenPieces(this Int32[, ,] cuboid)
        {

            Index3D verticalSlicingIndex = new Index3D(0, 0, 0);

            List<Cell3D> tube = new List<Cell3D>();
            List<Int32> slicesSums = new List<Int32>();

            while (cuboid.IsInBoundary(verticalSlicingIndex))
            {
                Index3D currentPositionToGetListFrom = verticalSlicingIndex;

                Int32 currentSliceSum = 0;
                while (cuboid.IsInBoundary(currentPositionToGetListFrom))
                {
                    tube = cuboid.FromStartToEndInDesiredDirectionToList(currentPositionToGetListFrom, Index3D.In);
                    tube.ForEach(cell => currentSliceSum += cell.Value);

                    currentPositionToGetListFrom += Index3D.Down;
                }

                slicesSums.Add(currentSliceSum);
                verticalSlicingIndex += Index3D.Right;
            }

            return CountEventSlices(slicesSums);
        }

        private static Int32 PossibleWaysToSliceInDeepInToEvenPieces(this Int32[, ,] cuboid)
        {

            Index3D inDeepSlicingIndex = new Index3D(0, 0, 0);

            List<Cell3D> tube = new List<Cell3D>();
            List<Int32> slicesSums = new List<Int32>();

            while (cuboid.IsInBoundary(inDeepSlicingIndex))
            {
                Index3D currentPositionToGetListFrom = inDeepSlicingIndex;

                Int32 currentSliceSum = 0;
                while (cuboid.IsInBoundary(currentPositionToGetListFrom))
                {
                    tube = cuboid.FromStartToEndInDesiredDirectionToList(currentPositionToGetListFrom, Index3D.Right);
                    tube.ForEach(cell => currentSliceSum += cell.Value);

                    currentPositionToGetListFrom += Index3D.Down;
                }

                slicesSums.Add(currentSliceSum);
                inDeepSlicingIndex += Index3D.In;
            }

            return CountEventSlices(slicesSums);
        }

        private static Int32 CountEventSlices(List<Int32> slicesSums)
        {
            Int32 possibleWaysSliceHorizontallyInToEvenPieces = 0;

            Int32 sliceOneSum, sliceTwoSum;
            for (int i = 1; i < slicesSums.Count; i++)
            {
                sliceOneSum = 0;
                sliceTwoSum = 0;

                for (int firstSlice = 0; firstSlice < i; firstSlice++)
                {
                    sliceOneSum += slicesSums[firstSlice];
                }

                for (int secondSlice = i; secondSlice < slicesSums.Count; secondSlice++)
                {
                    sliceTwoSum += slicesSums[secondSlice];
                }

                if (sliceOneSum == sliceTwoSum)
                    possibleWaysSliceHorizontallyInToEvenPieces++;
            }

            return possibleWaysSliceHorizontallyInToEvenPieces;
        }
    }
}
