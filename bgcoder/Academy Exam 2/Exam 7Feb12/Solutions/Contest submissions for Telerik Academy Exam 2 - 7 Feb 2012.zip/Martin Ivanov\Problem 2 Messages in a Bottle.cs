using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Messages_in_a_Bottle
{
    class Program
    {
        static void Main(string[] args)
        {
            string secretCode = Console.ReadLine();
            string cipher = Console.ReadLine();

            Dictionary<ulong, char> codes = new Dictionary<ulong, char>();

            codes = ExtractCodes(cipher);

            Console.WriteLine(1);
            foreach (char symbol in secretCode)
            {
                ulong key = symbol - (ulong)'0';
                if (codes.ContainsKey(key))
                    Console.Write("{0}", codes[key]);
            }
        }

        static Dictionary<ulong, char> ExtractCodes(string cipher)
        {
            Dictionary<ulong, char> codes = new Dictionary<ulong, char>();

            string pattern = "([A-Z]{1})([0-9]*)";

            Regex regex = new Regex(pattern);

            MatchCollection matches = regex.Matches(cipher);

            foreach (Match match in matches)
            {
                char letter = match.Groups[1].ToString()[0];
                ulong code = ulong.Parse(match.Groups[2].ToString());
                codes.Add(code, letter);
            }

            return codes;
        }
    }
}