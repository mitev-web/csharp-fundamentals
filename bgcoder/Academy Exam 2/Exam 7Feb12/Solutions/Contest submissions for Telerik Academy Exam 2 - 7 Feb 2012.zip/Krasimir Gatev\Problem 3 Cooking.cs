using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3_Cooking
{
    class Measure
    {
        double value;

        public double Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Measure(string measureName, double measureValue)
        {
            Name = measureName;
            Value = measureValue;
        }
    }

    class Ingredient
    {
        Measure measure;

        internal Measure Measure
        {
            get { return measure; }
            set { measure = value; }
        }
        string ingredientName;

        public string IngredientName
        {
            get { return ingredientName; }
            set { ingredientName = value; }
        }

        public Ingredient(string name, string ingName, double ingValue)
        {
            IngredientName = name;
            Measure = new Measure(ingName,ingValue);
        }

        //Format Here !!!!!!!!!!!!!!!!!!!!!!!!
        public override string ToString()
        {
            return String.Format("{0:0.00}", Math.Round((decimal)Measure.Value, 2))  + ":" + Measure.Name + ":" + IngredientName;
        }

        static public Measure ConvertMinMeasure(Measure input)
        {
            Measure result = new Measure (input.Name,input.Value);

            if (result.Name == "tbsps")
            {
                result.Value = result.Value * 3.0;
                result.Name = "tsps";
                ConvertMinMeasure(result);
            }
            if (result.Name == "tablespoons")
            {
                result.Value = result.Value * 3.0;
                result.Name = "teaspoons";
                ConvertMinMeasure(result);
            }

            if (result.Name == "ls")
            {
                result.Value = result.Value * 1000.0;
                result.Name = "mls";
                ConvertMinMeasure(result);
            }
            if (result.Name == "liters")
            {
                result.Value = result.Value * 1000.0;
                result.Name = "milliliters";
                ConvertMinMeasure(result);
            }

            if (result.Name == "fl ozs")
            {
                result.Value = result.Value / 8.0;
                result.Name = "cups";
                ConvertMinMeasure(result);
            }
            if (result.Name == "fluid ounces")
            {
                result.Value = result.Value / 8.0;
                result.Name = "Cups";
                ConvertMinMeasure(result);
            }

            if (result.Name == "tsps")
            {
                result.Value = result.Value * 5.0;
                result.Name = "mls";
                ConvertMinMeasure(result);
            }
            if (result.Name == "teaspoons")
            {
                result.Value = result.Value * 5.0;
                result.Name = "milliliters";
                ConvertMinMeasure(result);
            }

            if (result.Name == "gals")
            {
                result.Value = result.Value * 4.0;
                result.Name = "qts";
                ConvertMinMeasure(result);
            }
            if (result.Name == "gallons")
            {
                result.Value = result.Value * 4.0;
                result.Name = "quarts";
                ConvertMinMeasure(result);
            }

            if (result.Name == "pts")
            {
                result.Value = result.Value * 2.0;
                result.Name = "cups";
                ConvertMinMeasure(result);
            }
            if (result.Name == "pints")
            {
                result.Value = result.Value * 2.0;
                result.Name = "Cups";
                ConvertMinMeasure(result);
            }

            if (result.Name == "qts")
            {
                result.Value = result.Value * 2.0;
                result.Name = "pts";
                ConvertMinMeasure(result);
            }
            if (result.Name == "quarts")
            {
                result.Value = result.Value * 2.0;
                result.Name = "pints";
                ConvertMinMeasure(result);
            }

            if (result.Name == "cups")
            {
                result.Value = result.Value * 48.0;
                result.Name = "tsps";
                ConvertMinMeasure(result);
            }
            if (result.Name == "Cups")
            {
                result.Value = result.Value * 48.0;
                result.Name = "teaspoons";
                ConvertMinMeasure(result);
            }

            if (result.Name == "mls" || result.Name == "milliliters")
            {
                return result;
            }
            return result;
        }

        //Convert Measures!
        public static Measure ConvertMeasures(Measure firstRecepie, Measure secondPlaced)
        {
            Measure temp = ConvertMinMeasure(secondPlaced);
            Measure result = new Measure(temp.Name, temp.Value);
            if (firstRecepie.Name.ToLower() == result.Name.ToLower())
            {
                return result;
            }

            // first mls
            if (result.Name == "mls" && firstRecepie.Name == "ls" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 1000.0;
                result.Name = "ls";
                return result;
            }
            if (result.Name == "milliliters" && firstRecepie.Name == "liters" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 1000.0;
                result.Name = "liters";
                return result;
            }
            //second mls
            if (result.Name == "mls" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 5.0;
                result.Name = "tsps";
                ConvertMinMeasure(result);
            }

            if (result.Name == "teaspoons" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 5.0;
                result.Name = "milliliters";
                ConvertMinMeasure(result);
            }

            //first tea
            if (result.Name == "tsps" && firstRecepie.Name == "tbsps" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 3.0;
                result.Name = "tbsps";
                return result;
            }
            if (result.Name == "teaspoons" && firstRecepie.Name == "tablespoons" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 3.0;
                result.Name = "tablespoons";
                return result;
            }

            // second tea
            if (result.Name == "tsps" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 48.0;
                result.Name = "cups";
                ConvertMinMeasure(result);
            }
            if (result.Name == "teaspoons" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 48.0;
                result.Name = "Cups";
                ConvertMinMeasure(result);
            }

            // first cups
            if (result.Name == "cups" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value * 8.0;
                result.Name = "fl ozs";
                return result;
            }
            if (result.Name == "Cups" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value * 8.0;
                result.Name = "fluid ounces";
                return result;
            }

            // second cups Warning!

            if (result.Name == "cups" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 2.0;
                result.Name = "pts";
                ConvertMinMeasure(result);
            }
            if (result.Name == "Cups" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 2.0;
                result.Name = "pints";
                ConvertMinMeasure(result);
            }

            //pints
            if (result.Name == "pts" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 2.0;
                result.Name = "qts";
                ConvertMinMeasure(result);
            }
            if (result.Name == "pints" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 2.0;
                result.Name = "quarts";
                ConvertMinMeasure(result);
            }

            //quarts
            if (result.Name == "qts" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 4.0;
                result.Name = "gals";
                ConvertMinMeasure(result);
            }
            if (result.Name == "quarts" && firstRecepie.Name != result.Name)
            {
                result.Value = result.Value / 4.0;
                result.Name = "gallons";
                ConvertMinMeasure(result);
            }
            if (result.Name == "gallons" || result.Name == "gals")
            {
                return result;
            }

            return result;
        }

        public static Ingredient Subtract(Ingredient firstRecepie, Ingredient secondPlaced)
        {
            Ingredient result = new Ingredient (firstRecepie.IngredientName,firstRecepie.Measure.Name,firstRecepie.Measure.Value);
            Ingredient second = new Ingredient(secondPlaced.IngredientName, secondPlaced.Measure.Name, secondPlaced.Measure.Value);
            double subtraction = ConvertMinMeasure(result.Measure).Value - ConvertMinMeasure(secondPlaced.Measure).Value;
            //Warning
            second.Measure.Value = subtraction;
            if (second.Measure.Name == "gallons" || second.Measure.Name == "quarts" || second.Measure.Name == "pints" || second.Measure.Name == "Cups" || second.Measure.Name == "fluid ounces" || second.Measure.Name == "teaspoons" || second.Measure.Name == "tablespoons" || second.Measure.Name == "milliliters")
            {
                second.Measure.Name = "milliliters";
            }
            else second.Measure.Name = "mls";
            
            result.Measure = ConvertMeasures(result.Measure,second.Measure);
            return result;  
        }

        public static Ingredient Add(Ingredient firstRecepie, Ingredient secondPlaced)
        {
            Ingredient result = new Ingredient(firstRecepie.IngredientName, firstRecepie.Measure.Name, firstRecepie.Measure.Value);
            Ingredient second = new Ingredient(secondPlaced.IngredientName, secondPlaced.Measure.Name, secondPlaced.Measure.Value);
            double addition = ConvertMinMeasure(result.Measure).Value + ConvertMinMeasure(secondPlaced.Measure).Value;
            //Warning
            second.Measure.Value = addition;
            if (second.Measure.Name == "gallons" || second.Measure.Name == "quarts" || second.Measure.Name == "pints" || second.Measure.Name == "Cups" || second.Measure.Name == "fluid ounces" || second.Measure.Name == "teaspoons" || second.Measure.Name == "tablespoons" || second.Measure.Name == "milliliters")
            {
                second.Measure.Name = "milliliters";
            }
            else second.Measure.Name = "mls";

            result.Measure = ConvertMeasures(result.Measure, second.Measure);
            return result;
        }


    }
    class Program
    {
        List<string> originalNames = new List<string>();

        public static List<Ingredient> CompareLists(List<Ingredient> firstRecepie, List<Ingredient> secondPlaced)
        {
            List<Ingredient> result = new List<Ingredient>();
            bool flag = false;
            for (int i = 0; i < firstRecepie.Count; i++)
            {
                for (int j = 0; j < secondPlaced.Count; j++)
                {
                    if (firstRecepie[i].IngredientName.ToLower() == secondPlaced[j].IngredientName.ToLower())
                    {
                        if (Ingredient.ConvertMinMeasure(firstRecepie[i].Measure).Value <= Ingredient.ConvertMinMeasure(secondPlaced[j].Measure).Value)
                        {
                            flag = true;
                            break;
                        }
                        else
                        {
                            result.Add(Ingredient.Subtract(firstRecepie[i], secondPlaced[j]));
                            flag = true;
                        }
                    }

                }
                if (!flag)
                {
                    result.Add(firstRecepie[i]);
                    flag = false;
                }

            }
            return result;

        }

        static void Main(string[] args)
        {
            //Input
            int N = int.Parse(Console.ReadLine());
            List<Ingredient> recipe = new List<Ingredient>();
            for (int i = 1; i <= N; i++)
            {
                string ingString = Console.ReadLine();
                string[] ingParts = ingString.Split(new char[] { ':' }, StringSplitOptions.None);
                recipe.Add(new Ingredient(ingParts[2], ingParts[1],double.Parse(ingParts[0])));
            }

            int M = int.Parse(Console.ReadLine());
            List<Ingredient> alreadyPlaced = new List<Ingredient>();
            for (int i = 1; i <= M; i++)
            {
                string ingString = Console.ReadLine();
                string[] ingParts = ingString.Split(new char[] { ':' }, StringSplitOptions.None);
                alreadyPlaced.Add(new Ingredient(ingParts[2], ingParts[1], double.Parse(ingParts[0])));
            }

            for (int i = 0; i < recipe.Count; i++)
            {
                
                for (int j = 0; j < recipe.Count; j++)
                {
                    if (i != j)
                    {
                        if (recipe[i].IngredientName.ToLower() == recipe[j].IngredientName.ToLower())
                        {
                            recipe[i] = Ingredient.Add(recipe[i], recipe[j]);
                            //recipe.Remove(recipe[j]);
                            recipe.RemoveAt(j);
                        }
                    }
                }
            }

            List<Ingredient> preResult = CompareLists(recipe, alreadyPlaced);

            for (int i = 0; i < preResult.Count; i++)
            {
                if (preResult[i].Measure.Name == "Cups")
                {
                    preResult[i].Measure.Name = "cups";
                }
            }

            for (int i = 0; i < recipe.Count; i++)
            {
                for (int j = 0; j < preResult.Count; j++)
                {
                    if (preResult[j].IngredientName.ToLower() == recipe[i].IngredientName.ToLower())
                    {
                        preResult[j].IngredientName = recipe[i].IngredientName;
                    }
                }

            }

            foreach (var item in preResult)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}