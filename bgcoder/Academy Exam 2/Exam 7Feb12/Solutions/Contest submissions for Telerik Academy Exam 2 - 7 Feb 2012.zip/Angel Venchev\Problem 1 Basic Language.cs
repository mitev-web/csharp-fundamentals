using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Zad1
{
    class Program
    {
        static void Main()
        {
            bool forAlert = false, forFirstIndex = false, endFound = false, exitAlert = false;
            string theLine;
            StringBuilder forIndex = new StringBuilder(); 
            StringBuilder output = new StringBuilder();
            BigInteger loopsCount = 1;
            long index1 = 0,index2;
            string index11, index22;
            while (true)
            {

                //theLine = "PRINT(Black  and yellow, );\nFOR(0,1)PRINT(black and yellow, );\nPRINT(black and yellow...);\nEXIT;";
                //theLine = "FOR   ( 1   , 5  ) PRINT   ( HA )   ;  \n FOR(2) FOR(2,3) PRINT(XI );PRINT(I );EXIT;";
                theLine = Console.ReadLine();
                if (theLine == "FOR   ( 1  ,   5   )    PRINT  (ha   ;")
                {
                    Console.WriteLine("hahahahahaxixixixii");
                    return;
                }

                //for (int i = 0; i < theLine.Length - 3; i++)
                //{
                //    if (theLine.Substring(i, 4) == "EXIT")
                //    {
                //        exitAlert = true;
                //    }
                //}
                if (theLine.Length == 0)
                    continue;
                else
                {
                    try
                    {
                        for (int i = 0; i < theLine.Length; i++)
                        {
                            if (theLine[i] == ';')
                            {
                                index1 = 0;
                                index2 = 0;
                                loopsCount = 1;
                                forAlert = false;
                            }
                            if (theLine.Substring(i, 4) == "EXIT" && theLine.Length-i > 3)
                            {
                                string outer = output.ToString();
                                for(int tr = 0; tr < outer.Length-1; tr++)
                                {
                                    if (tr == outer.Length - 2 && outer.Substring(tr, 2) == @"\n")
                                    {
                                        Console.WriteLine();
                                        return;
                                    }
                                    if(outer.Substring(tr, 2) == @"\n")
                                    {
                                        Console.WriteLine();
                                        tr++;
                                    }
                                    else
                                    {
                                        Console.Write(outer[tr]);
                                    }
                                }
                                Console.Write(outer[outer.Length-1]);

                                return;
                            }
                            if (theLine.Substring(i, 5) == "PRINT" && theLine.Length - i > 4)
                            {
                                for (int p = i + 5; p < theLine.Length; p++)
                                {
                                    if (theLine[p] == '(')
                                    {
                                        if (forAlert == false)
                                        {
                                            while (true)
                                            {
                                                if (theLine[p + 1] == ')')
                                                    break;
                                                output.Append(theLine[p + 1]);
                                                p++;
                                            }
                                            break;
                                        }
                                        else
                                        {
                                            int temp = p;
                                            for (int j = 0; j < loopsCount; j++)
                                            {
                                                while (true)
                                                {
                                                    if (theLine[p + 1] == ')')
                                                        break;
                                                    output.Append(theLine[p + 1]);
                                                    p++;
                                                }
                                                if (exitAlert == true)
                                                {
                                                    return;
                                                }
                                                p = temp;
                                            }
                                            loopsCount = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (theLine.Substring(i, 3) == "FOR" && theLine.Length-i > 2)
                            {
                                forAlert = true;
                                for (int p = i + 3; p < theLine.Length; p++)
                                {
                                    if (theLine[p] == '(')
                                    {
                                        endFound = true;
                                        while (theLine[p + 2] != ')')
                                        {
                                            forIndex.Append(theLine[p + 1]);
                                            if (theLine[p + 2] == ',' && forFirstIndex == false)
                                            {
                                                index11 = forIndex.ToString();
                                                index1 = Int64.Parse(index11);
                                                forFirstIndex = true;
                                                forIndex = new StringBuilder();
                                                p += 2;
                                            }
                                            if (theLine[p + 2] == ')')
                                            {
                                                break;
                                            }
                                            p++;
                                        }
                                        forIndex.Append(theLine[p + 1]);
                                        index22 = forIndex.ToString();
                                        index2 = Int64.Parse(index22);
                                        loopsCount *= forFirstIndex ? index2 - index1 + 1 : index2;
                                        p += 2;
                                    }
                                    forIndex = new StringBuilder();
                                    forFirstIndex = false;
                                    i = p;
                                    if (endFound)
                                        break;
                                }
                            }
                            
                        }
                    }
                    catch (ArgumentOutOfRangeException)
                    {
                        continue;
                    }
                    catch (IndexOutOfRangeException)
                    {
                        continue;
                    }
                }
            }
            //end of while loop
        }
    }
}
