using System;
using System.Linq;
using System.Text;


namespace Problem_1___Basic_Language
{
    class BasicLanguage
    {
        static string Read()
        {
            StringBuilder result = new StringBuilder();
            string input;
            while (true)
            {
                input = Console.ReadLine();
                if (input.Contains("EXIT"))
                {
                    result.Append(input);
                    break;
                }

                result.Append(input);
                result.Append("\n");
            }

            return result.ToString();
        }                

        static string RemoveSpaces(string text)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < text.Length; i++)
			{
                if (text[i] != ' ' && text[i] != '\n' && text[i] != ';')
                {
                    result.Append(text[i]);
                }			 
			}
            return result.ToString();
        }

        static int MakeFor(string text)
        {            
            if (text.Contains(','))
            {
                StringBuilder number1 = new StringBuilder();
                StringBuilder number2 = new StringBuilder();
                int temp = text.IndexOf(',');
                for (int i = 4; i < temp; i++)
                {
                    number1.Append(text[i]);
                }

                for (int i = temp + 1; i < text.Length; i++)
                {
                    number2.Append(text[i]);
                }

                return int.Parse(number2.ToString()) - int.Parse(number1.ToString()) + 1;
            }

            StringBuilder number = new StringBuilder();
            for (int i = 4; i < text.Length; i++)
            {
                number.Append(text[i]);
            }
            return int.Parse(number.ToString());
        }

        static string MakePrint(string text)
        {
            StringBuilder result = new StringBuilder();

            int pos = text.IndexOf("(");
            for (int i = pos+1; i < text.Length; i++)
            {
                result.Append(text[i]);
            }

            return result.ToString();
        }

        static void MakeCode(string code)
        {
            string[] codeArray = code.Split(')');
            for (int i = 0; i < codeArray.Length; i++)
            {
                if (codeArray[i].Contains("PRINT"))
                {                    
                    continue;
                }
                codeArray[i] = RemoveSpaces(codeArray[i]);
            }

            string printValue;
                        
            int forCounter = 1;
            for (int i = 0; i < codeArray.Length - 1; i++)
            {
                if (codeArray[i][0] == 'F')
                {
                    forCounter *= MakeFor(codeArray[i]);
                    continue;
                }
                if (codeArray[i].Contains("PRINT"))
                {
                    if (codeArray[i].IndexOf(';') >= 0)
                    {
                        forCounter = 1;
                    }
                    if (forCounter == 1)
                    {

                        Console.Write(MakePrint(codeArray[i]));
                    }

                    else
                    {
                        printValue = MakePrint(codeArray[i]);
                        for (int j = 0; j < forCounter; j++)
                        {
                            Console.Write(printValue);
                        }
                        forCounter = 0;
                    }
                }
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            string input = Read();
            MakeCode(input);                     
            
                       
        }
    }
}
