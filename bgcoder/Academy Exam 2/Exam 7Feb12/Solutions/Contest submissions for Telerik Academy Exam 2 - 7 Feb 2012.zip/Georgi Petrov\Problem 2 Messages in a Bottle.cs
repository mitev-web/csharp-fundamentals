using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace _02_Messages_in_a_Bottle
{
    class Program
    {
        static Dictionary<string, char> dict = new Dictionary<string, char>();
        static string message;
        static int foundCombinations = 0;
        static string[] sortedOutput = new string[2048];
 
        static void ParseCipher(string cipher)
        {
            int numberStartPos = 0;
            bool insideNumber = false;
            char ourChar = cipher[0];
            int i;
            string number;
            for (i = 1; i < cipher.Length; i++)
            {
                if (Char.IsDigit(cipher[i]) == false)
                {
                    if (insideNumber == true)
                    {
                        insideNumber = false;
                        number = cipher.Substring(numberStartPos, i - numberStartPos);
                        dict.Add(number, ourChar);
                    }
                    ourChar = cipher[i];
                }
                else
                {
                    if (insideNumber == false)
                    {
                        insideNumber = true;
                        numberStartPos = i;
                    }
                }
            }
            number = cipher.Substring(numberStartPos, cipher.Length - numberStartPos);
            dict.Add(number, ourChar);
        }
 
        static void Solve(int pos, StringBuilder output)
        {
            bool atLeastOne = false;
            for (int i = pos; i < message.Length; i++)
            {
                string toTest = message.Substring(pos, i - pos + 1);
                if (dict.ContainsKey(toTest) == true)
                {
                    atLeastOne = true;
                    string toLookup = message.Substring(pos, i - pos+1);
                    char toAppend = dict[toLookup];
                    output.Append(toAppend);
                    Solve(i+1, output);
                    output.Remove(output.Length - 1, 1);
 
                    //sortedOutput[foundCombinations] = toAppend.ToString();
                    //foundCombinations++;
                }
            }
            if (atLeastOne == false && pos!=0)
            {
                sortedOutput[foundCombinations] = output.ToString();
                foundCombinations++;
            }
            /*
            if (pos < message.Length && dict.ContainsKey(message.Substring(pos, 1)) == true)
            {
                string toLookup = message.Substring(pos, 1);
                sortedOutput[foundCombinations] =  dict[toLookup].ToString();
                foundCombinations++;
            }
             */
        }
 
        static void Main(string[] args)
        {
            message = Console.ReadLine();
            string cipher = Console.ReadLine();
             
            //message = "0123";
            //string cipher = "A0B2C3";
            ParseCipher(cipher);
            StringBuilder output = new StringBuilder(2048);
            Solve(0, output);
            Console.WriteLine(foundCombinations);
            Array.Sort(sortedOutput);
            foreach (string word in sortedOutput)
            {
                if (word != null)
                {
                    Console.WriteLine(word);
                }
            }
        }
    }
}