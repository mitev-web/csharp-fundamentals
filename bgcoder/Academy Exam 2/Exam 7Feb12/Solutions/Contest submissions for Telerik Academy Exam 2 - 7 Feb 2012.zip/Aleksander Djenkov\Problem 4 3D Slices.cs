using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cuboid
{
    class Program
    {
        static void Main(string[] args)
        {
            string tokens = Console.ReadLine();
            string[] tokens2 = tokens.Split(' ');
            char[] del = { ' ','|'};
            int W = int.Parse(tokens2[0]);
            int H = int.Parse(tokens2[1]);
            int D = int.Parse(tokens2[2]);

            int count=0;
            int[, ,] arr = new int[W, H, D];
            int sum1 = 0;
            int sum2 = 0;
         

            for (int i = 0; i < H; i++)
            {
                string line = Console.ReadLine();
                string[] loops = line.ToString().Split(del, StringSplitOptions.RemoveEmptyEntries);
                Console.WriteLine(loops.Length);
                for (int b = 0; b < D; b++)
                {
                    for (int c = 0; c < W; c++)
                    {
                        arr[i, b, c] = int.Parse(loops[count]);
                        count++;
                    }
                }
                count=0;
            }
            for (int i = 0; i < H; i++)
            {
                for (int a = 0; a < D; a++)
                {
                    for (int c = 0; c < W; c++)
                    {
                       if(i==0) sum1 += arr[i, a, c];
                       if (i == 1) sum2 += arr[i, a, c];
                        //Console.Write(arr[i,a,c]);
                    }
                   // Console.Write(" " );
                }
                Console.WriteLine();
            }

            Console.WriteLine(sum1);
            Console.WriteLine(sum2);



        }
    }
}
