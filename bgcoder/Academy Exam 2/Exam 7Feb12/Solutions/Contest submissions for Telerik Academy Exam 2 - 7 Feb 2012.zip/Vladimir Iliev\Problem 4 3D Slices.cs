using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

namespace _3DSlices
{
    class Program
    {
        static void Main(string[] args)
        {
            /// Width / Height / Depth
            string cudeDimenstionsinput = Console.ReadLine();
                //"2 2 2"; // replace with ConsoleReadLine
            string [] cubeDimensions = cudeDimenstionsinput.Split(' ');
            int[, ,] cuboid = new int[int.Parse(cubeDimensions[0]), int.Parse(cubeDimensions[1]), int.Parse(cubeDimensions[2])];


            /// Cube input
            /// READ LINES[rows]

           
            
            for (int height = 0; height < int.Parse(cubeDimensions[1]); height++)
            {
                /// REPLACE
                string currentInputRow = Console.ReadLine();

                //if (height == 0)
                //{
                //    currentInputRow = " 1 | 1";
                //        //"3 4 1 9 | 1 2 3 8 | 1 5 6 7"; // replace with ConsoleReadLine
                //}
                //else
                //{
                //    //currentInputRow = 
                //        //"1 2 1 9 | 5 1 3 9 | 5 3 3 8"; // replace with ConsoleReadLine
                //}
                /// REPLACE
                
                string[] cubeCurrentRow = currentInputRow.Split('|');
                string[] tempArray;

                for (int depth = 0; depth < cubeCurrentRow.Length; depth++)
                {
                    cubeCurrentRow[depth] = cubeCurrentRow[depth].Trim();
                    tempArray = cubeCurrentRow[depth].Split(' ');
                    for (int width = 0; width < tempArray.Length; width++)
                    {

                        cuboid[width, height, depth] = int.Parse(tempArray[width]);
                    }
                }
            }

            // First check slices by width
            int sumOne = 0;
            int sumTwo = 0;
            int globalSumOne = 0;
            //int globalSumTwo = 0;
            int globalSumOfCorrectCombinations = 0;
            if (cuboid.GetLength(0) > 1)
            {
                for (int widthSlice = 0; widthSlice < cuboid.GetLength(0); widthSlice++)
                {
                    sumOne = 0;
                    sumTwo = 0;
                    //from zero to current slice
                    if (widthSlice == 0)
                    {
                        sumOne += SumCurrentWidthSlice(cuboid, 0);
                        globalSumOne = sumOne;
                    }
                    else
                    {
                        sumOne += SumCurrentWidthSlice(cuboid, widthSlice) + globalSumOne;
                        globalSumOne = sumOne;
                    }


                    //from current slice to getLenght(0)
                    for (int currentWidth = widthSlice + 1; currentWidth < cuboid.GetLength(0); currentWidth++)
                    {
                        sumTwo += SumCurrentWidthSlice(cuboid, currentWidth);
                    }

                    // Check if sum is equal
                    if (sumOne == sumTwo)//&& sumOne != 0 && sumTwo != 0)
                    {
                        globalSumOfCorrectCombinations++;
                    }
                } 
            }
            

            globalSumOne = 0;
            //globalSumTwo = 0;
            //Second check slices by height
            if (cuboid.GetLength(1) > 1)
            {
                for (int heightSlice = 0; heightSlice < cuboid.GetLength(1); heightSlice++)
                {
                    sumOne = 0;
                    sumTwo = 0;
                    //from zero to current slice
                    if (heightSlice == 0)
                    {
                        sumOne += SumCurrentHeightSlice(cuboid, 0);
                        globalSumOne = sumOne;
                    }
                    else
                    {
                        sumOne += SumCurrentHeightSlice(cuboid, heightSlice) + globalSumOne;
                        globalSumOne = sumOne;
                    }
                    //from current slice to getLenght(0)
                    for (int currentHeight = heightSlice + 1; currentHeight < cuboid.GetLength(1); currentHeight++)
                    {
                        sumTwo += SumCurrentHeightSlice(cuboid, currentHeight);
                    }

                    // Check if sum is equal
                    if (sumOne == sumTwo)// && (sumOne != 0 && sumTwo != 0))
                    {
                        globalSumOfCorrectCombinations++;
                    }
                }
            }
            

            globalSumOne = 0;
            //globalSumTwo = 0;
            //Third check slices by depth
            if (cuboid.GetLength(2) > 1)
            {
                for (int depthtSlice = 0; depthtSlice < cuboid.GetLength(2); depthtSlice++)
                {
                    sumOne = 0;
                    sumTwo = 0;
                    //from zero to current slice
                    if (depthtSlice == 0)
                    {
                        sumOne += SumCurrentDepthSlice(cuboid, 0);
                        globalSumOne = sumOne;
                    }
                    else
                    {
                        sumOne += SumCurrentDepthSlice(cuboid, depthtSlice) + globalSumOne;
                        globalSumOne = sumOne;
                    }

                    //from current slice to getLenght(0)
                    for (int currentDepth = depthtSlice + 1; currentDepth < cuboid.GetLength(2); currentDepth++)
                    {
                        sumTwo += SumCurrentDepthSlice(cuboid, currentDepth);
                    }

                    // Check if sum is equal
                    if (sumOne == sumTwo)// && sumOne != 0 && sumTwo != 0)
                    {
                        globalSumOfCorrectCombinations++;
                    }
                } 
            }
            
            Console.WriteLine(globalSumOfCorrectCombinations);
        }

        static int SumCurrentWidthSlice(int[, ,] cuboid, int currentSlice)
        { 
            int sum = 0;
            for (int height = 0; height < cuboid.GetLength(1); height++)
			{
                for (int depth = 0; depth < cuboid.GetLength(2); depth++)
                {
                    sum += cuboid[currentSlice, height, depth];
                }
			}
            return sum;
        }

        static int SumCurrentHeightSlice(int[, ,] cuboid, int currentSlice)
        {
            int sum = 0;
            for (int width = 0; width < cuboid.GetLength(0); width++)
            {
                for (int depth = 0; depth < cuboid.GetLength(2); depth++)
                {
                    sum += cuboid[width, currentSlice, depth];
                }
            }
            return sum;
        }

        static int SumCurrentDepthSlice(int[, ,] cuboid, int currentSlice)
        {
            int sum = 0;
            for (int width = 0; width < cuboid.GetLength(0); width++)
            {
                for (int height = 0; height < cuboid.GetLength(1); height++)
                {
                    sum += cuboid[width, height, currentSlice];
                }
            }
            return sum;
        }
    }
}
