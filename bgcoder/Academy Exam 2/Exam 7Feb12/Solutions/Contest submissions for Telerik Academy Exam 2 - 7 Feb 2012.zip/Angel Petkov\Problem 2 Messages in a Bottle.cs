using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace test2
{
    class test2
    {
        static void Gen01(int index, int[] vector, int values, char[] letters,
        int[] numbers, string encoded, ref StringBuilder str, ref int counter)
        {
            if (index == -1)
            {
                Print(vector, letters, numbers, encoded, ref str, ref counter);
            }
            else
                for (int i = 0; i < values; i++)
                {
                    vector[index] = numbers[i];
                    Gen01(index - 1, vector, values, letters, numbers, encoded, ref str, ref counter);
                }
        }

        static void Print(int[] vector, char[] letters, int[] numbers, string encoded,
            ref StringBuilder str, ref int counter)
        {
            StringBuilder temp = new StringBuilder();
            
            Hashtable hash = new Hashtable();

            for (int i = 0; i < numbers.Length; i++)
            {
                hash.Add(numbers[i], letters[i]);
            }

            foreach (int i in vector)
            {
                temp.Append(i);
            }
            if (temp.ToString() == encoded)
            {
                counter++;
                for (int i = 0; i < vector.Length; i++)
                {
                    str.Append(hash[vector[i]]);
                }
                str.Append("\r\n");

            }

            //Console.WriteLine();
        }

        static void Main(string[] args)
        {  
            
            string encoded = Console.ReadLine();
            string key = Console.ReadLine();

            string[] numbersAll = key.Split(new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
                 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' },
                 StringSplitOptions.RemoveEmptyEntries);
            string[] lettersAll = key.Split(new char[] { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' },
                StringSplitOptions.RemoveEmptyEntries);

            int lettersPresent = 0;
            for (int i = 0; i < numbersAll.Length; i++)
            {
                if (key.IndexOf(numbersAll[i]) != -1)
                {
                    lettersPresent++;
                }
            }

            char[] letters = new char[lettersPresent];
            int[] numbers = new int[lettersPresent];
            int index = 0 ;
            for (int i = 0; i < numbersAll.Length; i++)
            {
               if (key.IndexOf(numbersAll[i]) != -1)
                {
                    letters[index] = char.Parse(lettersAll[i]);
                    numbers[index] = int.Parse(numbersAll[i]);
                    index++;
                } 
            }

            StringBuilder str = new StringBuilder();
            str.Append("-1\r\n");
            int counter = 0;

            for (int i = numbers.Length; i > 0; i--)
            {

                int number = i;
                int[] vector = new int[number];                
                Gen01(number - 1, vector, numbers.Length, letters, numbers, encoded, ref str, ref counter);
            }

            Console.WriteLine(str.Replace("-1", counter.ToString()));

        }
    }
}
