using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagesInABottle
{
    class Program
    {
        class Cipher
        {
            private char symbol;
            private string code;
            private static List<Cipher> cipherArray;

            public Cipher(char symb, string cod)
            {
                this.symbol = symb;
                this.code = cod;
            }

            public char Symbol
            {
                get { return this.symbol; }
            }

            public string Code
            {
                get { return this.code; }
            }

            public static List<Cipher> CipherArray
            {
                get { return cipherArray; }
                set
                {
                    cipherArray = value;
                }
            }

            public static void CollectCipherArrayFromString(string cipher)
            {
                int startIndex = 0;
                int cipherCounter = 0;
                List<Cipher> ciphersArray = new List<Cipher>();

                while (startIndex != cipher.Length)
                {
                    StringBuilder number = new StringBuilder();
                    char letter = cipher[startIndex];
                    startIndex++;

                    while (IsANumber(cipher[startIndex]) == true)
                    {
                        number.Append(cipher[startIndex]);
                        startIndex++;

                        if (startIndex == cipher.Length)
                        {
                            break;
                        }
                    }

                    string temp = number.ToString();
                    ciphersArray.Add(new Cipher(letter, temp));
                    cipherCounter++;
                }

                Cipher.CipherArray = ciphersArray;
            }
        }

        static bool IsANumber(char symbol)
        {
            bool isANumber = false;

            for (int i = 0; i < 10; i++)
            {
                if (symbol == (char)(i+48))
                {
                    isANumber = true;
                }
            }

            return isANumber;
        }

        static StringBuilder deciphered = new StringBuilder();

        static List<string> solutions = new List<string>();

        static void Decipher(string secret)
        {
            if (secret == "")
            {
                solutions.Add(deciphered.ToString());
                deciphered.Remove(deciphered.Length - 1, 1);
                return;
            }
            else
            {
                for (int len = 1; len <= secret.Length; len++)
                {
                    string checker = secret.Substring(0, len);
                    string rest = secret.Substring(len);

                    for (int index = 0; index < Cipher.CipherArray.Count; index++)
                    {
                        if (checker == Cipher.CipherArray[index].Code)
                        {
                            deciphered.Append(Cipher.CipherArray[index].Symbol);
                            Decipher(rest);
                            break;
                        }
                    }

                    if (len == secret.Length)
                    {
                        if (deciphered.Length == 0)
                        {
                            break;
                        }

                        deciphered.Remove(deciphered.Length - 1, 1);
                        return;
                    }
                }
            }

            Console.WriteLine(solutions.Count);

            solutions.Sort();

            foreach (string solution in solutions)
            {
                Console.WriteLine(solution);
            }
        }

        static void Main(string[] args)
        {
            string secret = Console.ReadLine();
            string code = Console.ReadLine();

            Cipher.CollectCipherArrayFromString(code);

            Decipher(secret);
        }
    }
}
