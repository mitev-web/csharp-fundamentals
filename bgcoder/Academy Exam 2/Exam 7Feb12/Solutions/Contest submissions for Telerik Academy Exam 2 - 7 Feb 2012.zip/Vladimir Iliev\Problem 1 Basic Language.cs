using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicLanguage
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<string> commandsInput = new Queue<string>();

            string currentLine = "";
            while (currentLine != "EXIT;" && (currentLine.IndexOf("EXIT;") == -1))
            {
                currentLine = Console.ReadLine();
                commandsInput.Enqueue(currentLine);
            }
            int counter = commandsInput.Count;
            for (int i = 0; i < counter; i++)
            {
                currentLine = commandsInput.Dequeue();
                currentLine = currentLine.Trim();
                //SimulatenestedLoops(currentLine);
                string[] splitedLines = currentLine.Split(';');

                for (int partOfLine = 0; partOfLine < splitedLines.Length - 1; partOfLine++)
                {
                    SimulatenestedLoops(splitedLines[partOfLine]);
                }
            }

            //currentLine = "FOR (   1  , 5  ) PRINT   (haha)    ;
            //FOR(2)";
            //SimulatenestedLoops(currentLine);
             
            Console.WriteLine();

        }

        static void SimulatenestedLoops(string currentLine)
        {
            currentLine = currentLine.Trim();
            string currentForParams = "";
            int indexOfOpeningBrackets = currentLine.IndexOf('(');
            int indexOfClosingBrackets = currentLine.IndexOf(')');
            if (currentLine.Substring(0, 3) == "FOR")
            {
                currentForParams = currentLine.Substring(indexOfOpeningBrackets + 1, (indexOfClosingBrackets- indexOfOpeningBrackets) - 1);
                //currentForParams = currentForParams.Trim();
                string[] splitedForParams = currentForParams.Split(',');
                
                int endIndex = 0;
                if (splitedForParams.Length == 1)
                {
                    endIndex = int.Parse(splitedForParams[0].Trim());
                }
                else
                {
                    endIndex = (int.Parse(splitedForParams[1].Trim()) - int.Parse(splitedForParams[0].Trim())) + 1;
                }

                for (int i = 0; i < endIndex; i++)
                {
                    SimulatenestedLoops(currentLine.Substring(indexOfClosingBrackets + 1));
                }
                
            }
            else if (currentLine.Substring(0,3) == "PRI")
            {
                //bottom for now
                Console.Write(currentLine.Substring(indexOfOpeningBrackets + 1, (indexOfClosingBrackets- indexOfOpeningBrackets) - 1));
            }
        }
    }
}
