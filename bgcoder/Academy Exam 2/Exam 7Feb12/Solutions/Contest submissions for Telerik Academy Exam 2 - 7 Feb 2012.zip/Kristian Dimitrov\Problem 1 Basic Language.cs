using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
 
namespace _01BL
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            do
            {
                sb.Append(Console.ReadLine());
            }
            while (sb.ToString().IndexOf("EXIT") == -1);
            string[] lines = sb.ToString().Split(';');
            foreach (string item in lines)
            {
                ExecuteLine(item);
            }
            Console.WriteLine();
        }
 
        public static void ExecuteLine(string line)
        {
            if (line.IndexOf("EXIT") != -1)
                return;
            int numberOfTimes = 1;
            Regex reg = new Regex(@"(?<operation>FOR)\s*(\(\s*(?<first>\d)\s*,\s*(?<second>\d)\s*\))");
            MatchCollection matches = reg.Matches(line);
            foreach (Match item in matches)
            {
                int sum = 0;
                sum = int.Parse(item.Groups["second"].Value.ToString()) - int.Parse(item.Groups["first"].Value.ToString()) + 1;
                numberOfTimes *= sum;
            }
 
            Regex reg2 = new Regex(@"(?<operation>FOR)(\(\s*(?<first>\d)\)\s*)");
            MatchCollection matches2 = reg2.Matches(line);
            foreach (Match item in matches2)
            {
                numberOfTimes *= int.Parse(item.Groups["first"].Value.ToString());
            }
 
            Regex printReg = new Regex(@"PRINT\s*\((?<toprint>[^\)]*)\)");
            Match print = printReg.Match(line);
            if (print.Success)
            {
                for (int i = 0; i < numberOfTimes; i++)
                {
                    Console.Write(print.Groups["toprint"].Value.ToString());
                }
            }
        }
    }
}