using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P2_MessagesInABottle
{
    class Program
    {
        static void Main(string[] args)
        {
            string cipher = "A1B12C11D22";
            string message = "1122";
            List<string> output = new List<string>();

            
            message = Console.ReadLine();
            cipher = Console.ReadLine();
            
            var cipherDict = parseCipher(cipher);
            string cipherCombo = String.Join(" ", cipherDict.Keys);
            RecursiveCombinatorics combos = new RecursiveCombinatorics(cipherCombo, RecursiveCombinatorics.Mode.Combination);

            StringBuilder str;
            
            for (int i = 1; i <= cipherDict.Count; i++)
            {
                for (int j = 0; j < combos.Count; j++)
                {
                    str = new StringBuilder(message.Length);
                    for (int k = 0; k < i; k++)
                    {
                        str.Append(combos[j][k]);
                    }
                    if (str.Length == message.Length && str.ToString() == message)
                    {
                        //Console.WriteLine("Combo " + j + " with " + i + " elements: " + str.ToString());
                        str = new StringBuilder();
                        for (int p = 0; p < i; p++)
                        {
                            str.Append(cipherDict[combos[j][p]]);
                        }
                        //Console.WriteLine(str);
                        output.Add(str.ToString());
                    }
                }
            }
            Console.WriteLine(output.Count);
            output.Sort();
            for (int i = 0; i < output.Count; i++)
            {
                Console.WriteLine(output[i]);
            }
            
        }

        string[][] combos;
        string message;
        public string[] TryDecodeMessage(string message, string cipher)
        {
            var dict = parseCipher(cipher);

            bool fail = false;

            while (!fail)
            {

            }

            return new string[] {"boo"};
        }
        


        private static Dictionary<string, char> parseCipher(string input)
        {
            Dictionary<string, char> data = new Dictionary<string,char>();

            for (int i = 1, enumerator = 1; i < input.Length; i = ++enumerator)
            {
                while (enumerator < input.Length && (int)input[enumerator] >= 48 && (int)input[enumerator] < 58)
                {
                    enumerator++;
                }
                if (enumerator - i != 0)
                {
                    data.Add(input.Substring(i, enumerator - i), input[i-1]);
                }
            }
            return data;
        }

        private static Dictionary<int, char> parseCipherInt(string input)
        {
            Dictionary<int, char> data = new Dictionary<int, char>();

            for (int i = 1, enumerator = 1; i < input.Length; i = ++enumerator)
            {
                while (enumerator < input.Length && (int)input[enumerator] >= 48 && (int)input[enumerator] < 58)
                {
                    enumerator++;
                }
                if (enumerator - i != 0)
                {
                    data.Add(int.Parse(input.Substring(i, enumerator - i)), input[i - 1]);
                }
            }
            return data;
        }
    }

    class RecursiveCombinatorics
    {
        public enum Mode { Variation, Combination, Permutation };

        readonly Mode modusOperandi;
        private int loopCount = -1;
        private int setSize;
        private int[] elementIndices;
        private List<string[]> output;

        public string[] this[int i]
        {
            get { return output[i]; }
            set { output[i] = value; }
        }

        private string[] inputSet;
        public string[] InputSet
        {
            get { return inputSet; }
            private set { inputSet = value; }
        }

        private int count = 0;
        public int Count
        {
            get { return count; }
            private set { count = value; }
        }

        public RecursiveCombinatorics(string input, Mode MO, int param = 0)
        {
            modusOperandi = MO;
            InputSet = MakeInputArray(input);
            output = new List<string[]>();
            switch (modusOperandi)
            {
                case Mode.Variation:
                    Variation(param);
                    //Console.Write("# of Variations: " + Count + "\n");
                    break;
                case Mode.Combination:
                    Combination(param);
                    //Console.Write("# of Combinations: " + Count + "\n");
                    break;
                case Mode.Permutation:
                    Permutation();
                    //Console.Write("# of Permutations: " + Count + "\n");
                    break;
                default:
                    break;
            }
        }

        private string[] MakeInputArray(string InputString)
        {
            string[] setString;
            if (InputString.IndexOf(' ') < 0)
            {
                setString = new string[InputString.Length];
                for (int i = 0; i < InputString.Length; i++)
                {
                    setString[i] = InputString[i].ToString();
                }
            }
            else
            {
                setString = InputString.Split(' ');
            }
            elementIndices = new int[setString.Length];
            setSize = setString.Length;
            return setString;
        }


        private void Permutation(int k = 0)
        {
            loopCount++;
            elementIndices[k] = loopCount;

            if (loopCount == setSize)
            {
                PrintSet(elementIndices);
                Count++;
            }
            else
            {
                for (int i = 0; i < setSize; i++)
                {
                    if (elementIndices[i] == 0)
                    {
                        Permutation(i);
                    }
                }
            }
            loopCount--;
            elementIndices[k] = 0;
        }

        private void Variation(int n = 0)
        {
            if (n == 0)
            {
                loopCount = setSize;
            }
            else
            {
                loopCount = n < setSize ? n : setSize;
            }
            _Variation();
        }

        private void _Variation(int levelCarry = 0)
        {
            if (levelCarry == (loopCount < setSize ? loopCount : setSize))
            {
                // Functional code here
                output.Add(new string[elementIndices.Length]);
                for (int i = 0; i < elementIndices.Length; i++)
                {
                    output[count][i] = inputSet[elementIndices[i]];
                }
                //PrintSet(elementIndices);
                count++;
            }
            else
            {
                for (int i = 0; i < setSize; i++)
                {
                    elementIndices[levelCarry] = i;
                    _Variation(levelCarry + 1);
                }
            }
        }

        private void Combination(int n = 0)
        {
            if (n == 0)
            {
                loopCount = setSize;
            }
            else
            {
                loopCount = n < setSize ? n : setSize;
            }
            _Combination();
        }

        private void _Combination(int levelCarry = 0)
        {
            if (levelCarry == (loopCount < setSize ? loopCount : setSize))
            {
                // Functional code here
                output.Add(new string[elementIndices.Length]);
                for (int i = 0; i < elementIndices.Length; i++)
                {
                    output[count][i] = inputSet[elementIndices[i]];
                }
                //PrintSet(elementIndices);
                count++;
            }
            else
            {
                for (int i = (0 > levelCarry - 1 ? 0 : elementIndices[levelCarry - 1]); i < setSize; i++)
                {
                    elementIndices[levelCarry] = i;
                    _Combination(levelCarry + 1);
                }
            }
        }

        private void PrintSet(int[] value)
        {
            switch (modusOperandi)
            {
                case Mode.Variation:
                case Mode.Combination:
                    for (int i = 0; i < loopCount; i++)
                    {
                        Console.Write(inputSet[elementIndices[i]] + " ");
                    }
                    break;
                case Mode.Permutation:
                    foreach (int i in value)
                    {
                        Console.Write(inputSet[i - 1] + " ");
                    }
                    break;
                default:
                    break;
            }
            Console.WriteLine();
        }
    }
}
