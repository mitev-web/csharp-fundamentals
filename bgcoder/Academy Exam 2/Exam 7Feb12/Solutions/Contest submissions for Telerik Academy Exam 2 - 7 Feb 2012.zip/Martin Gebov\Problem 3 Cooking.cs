using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

class Cooking
{

    static void Main(string[] args)
    {
        
        int n = int.Parse(Console.ReadLine());
        List<decimal> leftDoses = new List<decimal>();
        List<string> leftIngredients = new List<string>();
        List<string> leftUnits = new List<string>();
        decimal[] recipeDoses = new decimal[n];
        string[] recipeIngredients = new string[n];
        string[] recipeUnits = new string[n];
        for (int i = 0; i < n; i++)
        {
            string ingredient = Console.ReadLine();
            ExtractIngredientDetails(ingredient, i, recipeIngredients, recipeDoses,recipeUnits);
        }

        int m = int.Parse(Console.ReadLine());
        decimal[] usedDoses = new decimal[m];
        string[] usedIngredients = new string[m];

        for (int i = 0; i < m; i++)
        {
            string usedIngredient = Console.ReadLine();
            ExtractIngredientDetails(usedIngredient, i, usedIngredients, usedDoses);
        }
        
        for (int i = 0; i < usedIngredients.Length; i++)
        {
            for (int j = 0; j < recipeIngredients.Length; j++)
            {
                if (usedIngredients[j].ToLower().Equals(recipeIngredients[i].ToLower()))
                {
                    if (recipeDoses[j] > usedDoses[i])
                    {
                        leftDoses.Add(recipeDoses[j]-usedDoses[i]);
                        leftIngredients.Add(recipeIngredients[j]);
                        leftUnits.Add(recipeUnits[j]);
                    }
                }
            }
        }
        for (int i = 0; i < leftDoses.Count; i++)
        {
            Console.WriteLine(ConvertBack(leftDoses[i], leftUnits[i]) + ":" + leftUnits[i] + ":" + leftIngredients[i]);
        }

     

 
    }
    static void ExtractIngredientDetails(string ingredient, int position, string[] ingredients, decimal[] doses)
    {
       
        string pattern = "(?<value>.+):(?<unit>.+):(?<ingredient>.+)";
        Match ingredientMatch = Regex.Match(ingredient, pattern);

        string dose = ingredientMatch.Groups["value"].Value;
        string unit = ingredientMatch.Groups["unit"].Value;
        string ingredientName = ingredientMatch.Groups["ingredient"].Value;
        ingredients[position] = ingredientName;
        doses[position] = Convert(dose, unit);
    }
    static void ExtractIngredientDetails(string ingredient, int position, string[] ingredients, decimal[] doses,string[] units)
    {

        string pattern = "(?<value>.+):(?<unit>.+):(?<ingredient>.+)";
        Match ingredientMatch = Regex.Match(ingredient, pattern);

        string dose = ingredientMatch.Groups["value"].Value;
        string unit = ingredientMatch.Groups["unit"].Value;
        string ingredientName = ingredientMatch.Groups["ingredient"].Value;
        ingredients[position] = ingredientName;
        doses[position] = Convert(dose, unit);
        units[position] = unit;
    }

    static decimal Convert(string value, string unit)
    {
        decimal mililiters = decimal.Parse(value);
       
        if (unit.Equals("ls"))
        {
            mililiters *= 1000;
        }
        else if (unit.Equals("tbsps"))
        {
            mililiters *= 15;
        }
        else if (unit.Equals("gals"))
        {
            mililiters *= 16 * 48 * 5;
        }
        else if (unit.Equals("qts"))
        {
            mililiters *= 4 * 48 * 5;
        }
        else if (unit.Equals("pts"))
        {
            mililiters *= 2 * 48 * 5;
        }
        else if (unit.Equals("cups"))
        {
            mililiters *= 48 * 5;
        }
        else if (unit.Equals("tsps"))
        {
            mililiters *= 5;
        }
        else if (unit.Equals("fl ozs"))
        {
            mililiters *= 30;
        }
        return mililiters;
    }
    static string ConvertBack(decimal value, string unit)
    {
        if (unit.Equals("tbsp"))
        {
            value /= 15;
        }
        else if (unit.Equals("tsps"))
        {
            value /= 5;
        }
        else if (unit.Equals("ls"))
        {
            value /= 1000;
        }
        else if (unit.Equals("fl ozs"))
        {
            value /= 30;
        }
        else if (unit.Equals("gals"))
        {
            value /= 8 * 48 * 5;
        }
        else if (unit.Equals("qts"))
        {
            value /= 20 * 48;
        }
        else if (unit.Equals("pts"))
        {
            value /= 2 * 48 * 5;
        }
        else if (unit.Equals("cups"))
        {
            value /= 48 * 5;
        }
        value = Math.Round(value,2);
        return value.ToString();
    }
}


