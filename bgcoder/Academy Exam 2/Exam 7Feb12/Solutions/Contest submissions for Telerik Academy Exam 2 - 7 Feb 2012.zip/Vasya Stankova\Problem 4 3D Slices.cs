using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Problem4_3DSlices
{
	class Slices3D
	{
		static void Main(string[] args)
		{
			int[, ,] cuboid = ReadCuboid();

			int sums = CalcSums(cuboid);

			Console.WriteLine(sums);
		}

		private static int CalcSums(int[, ,] cuboid)
		{
			int width = cuboid.GetLength(0);
			int height = cuboid.GetLength(1);
			int depth = cuboid.GetLength(2);

			int[] widthsSums = CalcWidthSums(cuboid);
			int equalWidthSums = CalcEqualSums(widthsSums);

			int[] heightSums = CalcHeightSums(cuboid);
			int equalHeightSums = CalcEqualSums(heightSums);

			int[] depthSums = CalcDepthSums(cuboid);
			int equalDepthSums = CalcEqualSums(depthSums);

			int result = equalWidthSums + equalHeightSums + equalDepthSums;

			return result;
		}

		private static int CalcEqualSums(int[] widthsSums)
		{
			int sum1 = 0;
			int sum2 = 0;
			for (int index = 0; index < widthsSums.Length; index++)
			{
				sum2 += widthsSums[index];
			}

			int sumsCount = 0;

			for (int i = 0; i < widthsSums.Length - 1; i++)
			{
				sum1 += widthsSums[i];
				sum2 -= widthsSums[i];
				if (sum1 == sum2)
				{
					sumsCount++;
				}
			}

			return sumsCount;
		}

		private static int[] CalcDepthSums(int[, ,] cuboid)
		{
			int width = cuboid.GetLength(0);
			int height = cuboid.GetLength(1);
			int depth = cuboid.GetLength(2);
			int[] sums = new int[depth];

			for (int d = 0; d < depth; d++)
			{
				int currentSum = 0;
				for (int w = 0; w < width; w++)
				{
					for (int h = 0; h < height; h++)
					{
						currentSum += cuboid[w, h, d];
					}
				}
				sums[d] = currentSum;
			}

			return sums;
		}

		private static int[] CalcHeightSums(int[, ,] cuboid)
		{
			int width = cuboid.GetLength(0);
			int height = cuboid.GetLength(1);
			int depth = cuboid.GetLength(2);
			int[] sums = new int[height];

			for (int h = 0; h < height; h++)
			{
				int currentSum = 0;
				for (int w = 0; w < width; w++)
				{
					for (int d = 0; d < depth; d++)
					{
						currentSum += cuboid[w, h, d];
					}
				}
				sums[h] = currentSum;
			}

			return sums;
		}

		private static int[] CalcWidthSums(int[, ,] cuboid)
		{

			int width = cuboid.GetLength(0);
			int height = cuboid.GetLength(1);
			int depth = cuboid.GetLength(2);
			int[] sums = new int[width];

			for (int w = 0; w < width; w++)
			{
				int currentSum = 0;
				for (int h = 0; h < height; h++)
				{
					for (int d = 0; d < depth; d++)
					{
						currentSum += cuboid[w, h, d];
					}
				}
				sums[w] = currentSum;
			}

			return sums;
		}

		private static int[, ,] ReadCuboid()
		{
			string inputFileName = "input.txt";

			int[, ,] cuboid = null;

			//using (StreamReader reader = new StreamReader(inputFileName))
			{
				string dimentionsLine = Console.ReadLine(); // Console
				string[] dimentionsStrings = dimentionsLine.Split(' ');

				int width = int.Parse(dimentionsStrings[0]);
				int height = int.Parse(dimentionsStrings[1]);
				int depth = int.Parse(dimentionsStrings[2]);

				cuboid = new int[width, height, depth];

				for (int h = 0; h < height; h++)
				{
					string nextLine = Console.ReadLine();

					string[] line = nextLine.Split('|');

					for (int d = 0; d < depth; d++)
					{
						string[] l = line[d].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
						for (int w = 0; w < width; w++)
						{
							cuboid[w, h, d] = int.Parse(l[w]);
						}
					}
				}
			}

			return cuboid;
		}
	}
}
