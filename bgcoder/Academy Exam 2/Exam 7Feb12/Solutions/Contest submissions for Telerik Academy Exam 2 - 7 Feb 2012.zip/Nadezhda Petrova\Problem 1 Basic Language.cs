using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1_BasicLanguage
{
    class BasicLanguage
    {
        static void Main(string[] args)
        {
            bool isExit = false;
            bool isInPrint = false;
            bool isInFor = false;
            bool isNothing = true;
            bool hasFirstB = false;
            bool hasSecondB = false;
            bool lookingForBraket = false;
            int a = new int();
            int b = new int();
            long times = new long();
            StringBuilder sb = new StringBuilder();
            StringBuilder line = new StringBuilder();
            StringBuilder result = new StringBuilder();
            while (!isExit)
            {
                string l = Console.ReadLine();
                line.Clear();
                line.Append(l);
                line.Append(Environment.NewLine);
                for (int i = 0; i < line.Length; i++)
                {
                    char c = line[i];
                    if (isNothing && char.IsLetter(c))
                    {
                        sb.Append(c);
                    }
                    else if (isNothing && !char.IsLetter(c) && sb.Length > 0)
                    {
                        string command = sb.ToString();
                        sb.Clear();
                        if (command == "EXIT")
                        {
                            isExit = true;
                            break;
                        }
                        else if (command == "PRINT")
                        {
                            isInPrint = true;
                            isNothing = false;
                            lookingForBraket = true;
                        }
                        else if (command == "FOR")
                        {
                            isInFor = true;
                            isNothing = false;
                            lookingForBraket = true;
                        }
                        if (c == '(' && lookingForBraket)
                        {
                            lookingForBraket = false;
                            continue;
                        }
                    }
                    else if (c == '(' && lookingForBraket)
                    {
                        lookingForBraket = false;
                    }
                    else if (!isInPrint && (c == ' ' || c == '\r' || c == '\n' || c == '\t'))
                    {
                        continue;
                    }
                    else if (isInPrint && !lookingForBraket)
                    {
                        if (c != ')')
                        {
                            sb.Append(c);
                        }
                        else
                        {
                            string message = sb.ToString();
                            sb.Clear();
                            if (times != 0)
                            {
                                for (int j = 0; j < times; j++)
                                {
                                    result.Append(message);
                                }
                            }
                            else
                            {
                                result.Append(message);
                            }
                            times = 0;
                            isInPrint = false;
                            isNothing = true;
                        }
                    }
                    else if (isInFor && !lookingForBraket)
                    {
                        if (c != ')')
                        {
                            sb.Append(c);
                        }
                        else
                        {
                            char[] separators = { ' ', '\t', '\n', '\r', ',' };
                            string param = sb.ToString();
                            sb.Clear();
                            string[] numbers = param.Split(separators);
                            if (numbers.Length == 1)
                            {
                                a = Convert.ToInt32(numbers[0]);
                                times = times + a;
                            }
                            else
                            {
                                a = Convert.ToInt32(numbers[0]);
                                b = Convert.ToInt32(numbers[1]);
                                times = times + (b - a + 1);
                            }
                            isInFor = false;
                            isNothing = true;
                        }
                    }
                }
            }
            Console.WriteLine(result.ToString());
            //Console.WriteLine();
        }
    }
}
