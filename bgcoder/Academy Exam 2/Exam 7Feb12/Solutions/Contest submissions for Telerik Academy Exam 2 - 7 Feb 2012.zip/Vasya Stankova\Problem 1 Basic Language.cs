using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
   
namespace Problem1_BasicLanguage
{
    class BasicLanguage
    {
        static void Main(string[] args)
        {
            string inputLine = ReadCode();
   
            string output = ExecuteProgram(inputLine);
            Console.WriteLine(output);
        }
   
        private static string ExecuteProgram(string inputLine)
        {
            StringBuilder result = new StringBuilder();
   
            string[] commands = inputLine.Split(';');
   
            for (int i = 0; i < commands.Length; i++)
            {
                string lineExecutionResult = ExecuteCommand(commands[i]);
                result.Append(lineExecutionResult);
                if (commands[i].Contains("EXIT"))
                {
                    return result.ToString();
                }
            }
   
            return result.ToString();
        }
   
        private static string ExecuteCommand(string command)
        {
            StringBuilder result = new StringBuilder();
   
            string[] elements = command.Split(new char[] { '(', ')' });
   
            int forCount = 1;
   
            for (int i = 0; i < elements.Length; i += 2)
            {
                if (elements[i].Contains("FOR"))
                {
                    string[] arguments = elements[i + 1].Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
   
                    if (arguments.Length == 1)
                    {
                        int count = int.Parse(arguments[0]);
                        forCount *= count;
                    }
                    else
                    {
                        int a = int.Parse(arguments[0]);
                        int b = int.Parse(arguments[1]);
                        int count = b - a + 1;
                        forCount *= count;
                    }
                }
                else if (elements[i].Contains("PRINT"))
                {
                    string printedText = elements[i + 1];
                    if (!printedText.Equals(string.Empty))
                    {
                        for (int j = 0; j < forCount; j++)
                        {
                            result.Append(printedText);
                        }
                    }
                    forCount = 1;
                }
                else if (elements[i].Contains("EXIT"))
                {
                    return result.ToString();
                }
            }
   
            return result.ToString();
        }
   
        private static string ReadCode()
        {
            string inputFileName = "input.txt";
   
            StringBuilder result = new StringBuilder();
   
            //using (StreamReader reader = new StreamReader(inputFileName))
            {
                string newLine = Console.ReadLine(); // Console
                while (true)
                {                
                    result.Append(newLine);
                    if (newLine.Contains("EXIT;"))
                    {
                        break;
                    }
                    newLine = Console.ReadLine();
                }
            }
   
            return result.ToString();
        }
    }
}