using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Problem3_Cooking
{
	class Cooking
	{
		static Dictionary<string, double> units = new Dictionary<string, double>();

		static void Main(string[] args)
		{
			InitUnits();

			Dictionary<string, Product> recipe = new Dictionary<string, Product>();
			Dictionary<string, Product> used = new Dictionary<string, Product>();

			InitLists(recipe, used);

			Dictionary<string, Product> unused = new Dictionary<string, Product>();
			AddProducts(recipe, used, unused);
			foreach (var item in unused)
			{
				Console.WriteLine("{0:F2}:{1}:{2}", item.Value.amount, item.Value.unit, item.Key);
			}
		}

		private static void InitUnits()
		{
			units.Add("ls", 1);
			units.Add("mls", 1000);
			units.Add("tsps", 200);
			units.Add("cups", (double)200 / (double)48);
			units.Add("fl ozs", (double)200 / (double)6);
			units.Add("pts", (double)100 / (double)48);
			units.Add("qts", (double)50 / (double)48);
			units.Add("gals", (double)25 / (double)96);
			units.Add("tbsps", (double)200 / (double)3);

			units.Add("liters", 1);
			units.Add("milliliters", 1000);
			units.Add("teaspoons", 200);
			units.Add("fluid ounces", (double)200 / (double)6);
			units.Add("pints", (double)100 / (double)48);
			units.Add("quarts", (double)50 / (double)48);
			units.Add("gallons", (double)25 / (double)96);
			units.Add("tablespoons", (double)200 / (double)3);
		}

		private static void AddProducts(Dictionary<string, Product> recipe, Dictionary<string, Product> used, Dictionary<string, Product> unused)
		{
			foreach (var item in recipe)
			{
				if (used.ContainsKey(item.Key.ToLower()))
				{
					double recipeAmountInLitres = ConvertToLitres(item.Value.amount, item.Value.unit);

					string name = item.Key.ToLower();
					double usedAmount = used[name].amount;
					//string usedUnit = used[name].unit;

					//double usedAmountInLitres = ConvertToLitres(usedAmount, usedUnit);

					if (usedAmount < recipeAmountInLitres)
					{
						double difference = recipeAmountInLitres - usedAmount;
						double add = ConvertTo(difference, item.Value.unit);

						unused.Add(item.Key, new Product(add, item.Value.unit));
					}
				}
				else
				{
					unused.Add(item.Key, item.Value);
				}
			}
		}

		private static double ConvertTo(double difference, string unit)
		{
			double coef = units[unit];
			double result = difference * coef;
			return result;
		}

		private static double ConvertToLitres(double amount, string unit)
		{
			double coef = units[unit];
			double result = amount / coef;
			return result;
		}

		private static void InitLists(Dictionary<string, Product> recipe, Dictionary<string, Product> used)
		{
			string inputFileName = "input.txt";

			//using (StreamReader reader = new StreamReader(inputFileName))
			{
				string recipeCountString = Console.ReadLine(); // Console
				int recipeCount = int.Parse(recipeCountString);

				for (int i = 0; i < recipeCount; i++)
				{
					string productLine = Console.ReadLine();
					string[] elements = productLine.Split(':');
					double amount = double.Parse(elements[0]);
					string unit = elements[1];
					string name = elements[2];

					bool added = false;
					foreach (var item in recipe)
					{
						if (item.Key.ToLower() == name.ToLower())
						{
							double amountToLitres = ConvertToLitres(amount, unit);

							double realAmount = ConvertTo(amountToLitres, item.Value.unit);

							item.Value.amount += realAmount;

							added = true;
							break;
						}
					}
					if (added == false)
					{
						Product pr = new Product(amount, unit);
						recipe.Add(name, pr);
					}
				}

				string usedCountString = Console.ReadLine();
				int usedCount = int.Parse(usedCountString);

				for (int i = 0; i < usedCount; i++)
				{
					string productLine = Console.ReadLine();
					string[] elements = productLine.Split(':');

					double amount = double.Parse(elements[0]);
					string unit = elements[1];

					double amountToLitres = ConvertToLitres(amount, unit);

					string name = elements[2].ToLower();

					if (used.ContainsKey(name))
					{
						used[name].amount += amountToLitres;
					}
					else
					{
						Product pr = new Product(amountToLitres, "ls");
						used.Add(name, pr);
					}
				}
			}
		}
	}

	class Product
	{
		public double amount;
		public string unit;

		public Product(double amount, string unit)
		{
			this.amount = amount;
			this.unit = unit;
		}
	}
}
