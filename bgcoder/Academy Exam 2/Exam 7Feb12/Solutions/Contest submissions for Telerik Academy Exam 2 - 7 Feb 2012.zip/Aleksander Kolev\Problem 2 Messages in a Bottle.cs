using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class MessagesInABottle
{
    private static Dictionary<string, char> code = new Dictionary<string, char>();
    private static int[] key = null;
    private static string msg = null;
    private static List<string> msgs = new List<string>();

    static void Main(string[] args)
    {
        //msg = "1122";
        //string cypher = "A1B12C11D2";
        msg = Console.ReadLine();
        string cypher = Console.ReadLine();

        char letter = cypher[0];
        int pos = 1;
        for (int i = 1; i < cypher.Length; i++)
        {
            if (cypher[i] >= 'A' && cypher[i] <= 'Z')
            {
                code.Add(cypher.Substring(pos, i - pos), letter);
                letter = cypher[i];
                pos = i + 1;
            }
        }
        code.Add(cypher.Substring(pos), letter);


        key = new int[msg.Length];
        Combinations(0);
        msgs.Sort();
        Console.WriteLine(msgs.Count);
        foreach (string word in msgs)
        {
            Console.WriteLine(word);
        }
    }

    static void Print()
    {
        for (int i = 0; i < key.Length; i++)
        {
            Console.Write("{0} ", key[i]);
        }
        Console.WriteLine();
    }

    static bool CheckSum()
    {
        int sum = 0;
        for (int i = key.Length - 1; i >= 0; i--)
        {
            sum += key[i];
            if (sum > key.Length || (key[i] == 0 && sum > 0))
            {
                sum = -1;
                break;
            }
        }
        if (sum == key.Length)
        {
            return true;
        }
        return false;
    }

    static void Combinations(int pos)
    {
        if (pos >= key.Length)
        {
            return;
        }
        for (int i = 0; i < key.Length; i++)
        {
            key[pos] = i;
            Combinations(pos + 1);
            if (CheckSum())
            {
                //Print();
                CreateWord();
            }
        }
    }

    static void CreateWord()
    {
        StringBuilder word = new StringBuilder();
        char value;
        int pos = 0;
        for (int i = 0; i < key.Length; i++)
        {
            if (code.TryGetValue(msg.Substring(pos, key[i]), out value))
            {
                word.Append(value);
                pos += key[i];
            }
            else
            {
                if (key[i] != 0)
                {
                    word.Clear();
                    return;
                }
                else
                {
                    break;
                }
            }
        }
        msgs.Add(word.ToString());
    }
}