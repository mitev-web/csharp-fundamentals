using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Basic2
{
    class Program
    {
        static string RemoveNewLine(string input)
        {
            StringBuilder removedNewLine = new StringBuilder();

            for (int index = 0; index < input.Length; index++)
            {
                if (input[index] == '\n' || input[index] == '\r')
                {
                    index++;
                }
                else
                {
                    removedNewLine.Append(input[index]);
                }
            }

            return removedNewLine.ToString();
        }

        static void Main(string[] args)
        {
            int loopCounter = 1;
            string command = "";
            int startIndex = 0;
            string input = "";
 
            input = Console.ReadLine();
 
            for (int index = 0, inplen = input.Length; index < inplen; index++)
            {
                if (input[index] == ';')
                {
                    loopCounter = 1;
                    command = input.Substring(startIndex, index - startIndex);
                    command = command.Trim();
                    startIndex = 0;
 
                    while (startIndex != command.Length)
                    {
                        if (command.IndexOf("FOR",startIndex) != -1 && command.IndexOf("PRINT",startIndex) != -1 && command.IndexOf("FOR",startIndex) < command.IndexOf("PRINT",startIndex))
                        {
                            string[] arguments = command.Substring(command.IndexOf('(',startIndex) + 1, command.IndexOf(')',startIndex) - command.IndexOf('(',startIndex) - 1).Split(',');
 
                            for (int remove = 0; remove < arguments.Length; remove++)
                            {
                                arguments[remove] = RemoveNewLine(arguments[remove]);
                            }
 
                            if (arguments.Length == 1)
                            {
                                loopCounter *= int.Parse(arguments[0].Trim());
                            }
                            else
                            {
                                loopCounter *= int.Parse(arguments[1].Trim()) - int.Parse(arguments[0].Trim()) + 1;
                            }
 
                            startIndex = command.IndexOf(')',startIndex) + 1;
                        }
                        /*else if (command.IndexOf("FOR",startIndex) != -1 && command.IndexOf("PRINT",startIndex) != -1 && command.IndexOf("PRINT",startIndex) < command.IndexOf("FOR",startIndex))
                        {
                            string output = command.Substring(command.IndexOf(')', startIndex) + 1, command.IndexOf(')', startIndex) - command.IndexOf('(', startIndex) - 1);
 
                            if (command.IndexOf("FOR",startIndex) == -1 ) && command.IndexOf("PRINT",startIndex) == -1)
                            {
                                for (int loop = 0; loop < loopCounter; loop++)
                                {
                                    Console.Write(output);
                                }
                            }
 
                            startIndex = command.IndexOf(')', startIndex) + 1;
                        }*/
                     
                        else if (command.IndexOf("FOR",startIndex) == -1 && command.IndexOf("PRINT",startIndex) != -1)
                        {
                            int len = command.IndexOf(')', startIndex) - command.IndexOf('(', startIndex) - 1;
 
                            string output = command.Substring(command.IndexOf('(', startIndex) + 1,len);
 
                            for (int loop = 0; loop < loopCounter; loop++)
                            {
                                Console.Write(output);
                            }
 
                            startIndex = command.IndexOf(')', startIndex) + 1;
                        }
                    }
 
                    startIndex = index + 1;
                }
            }
        }
    }
}
