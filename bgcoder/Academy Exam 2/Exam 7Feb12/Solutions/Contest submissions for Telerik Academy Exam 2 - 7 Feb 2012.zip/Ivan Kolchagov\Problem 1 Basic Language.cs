using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace T01.BasicLanguage
{
    class Program
    {
        static BigInteger currentIterationCount = 0;
        static BigInteger maxLoopCount = 1000000000000000000;
        struct pos
        {
            public int Beg, End, Length;
        }

        static pos FindTags(string html, string beginTag, string endTag)
        {
            pos p = new pos();
            p.Beg = html.IndexOf(beginTag);
            p.End = html.IndexOf(endTag) + endTag.Length;
            p.Length = p.End - p.Beg;
            return p;
        }
        static bool HasNext(pos p)
        {
            return p.Beg >= 0 && p.End >= 0;
        }

        static bool ExecuteCommand(string command)
        {
            string cmd = command;
            string par = "";
            string cmdEx = "";
            bool isExit = false;

            if (String.IsNullOrWhiteSpace(cmd) || currentIterationCount >= maxLoopCount)
            {
                return false;
            }
            pos p = FindTags(command, "(", ")");
            if (HasNext(p))
            {
                cmd = command.Substring(0, p.Beg);
                par = command.Substring(p.Beg + 1, p.Length - 2);
                cmdEx = command.Substring(p.End);
            }

            if (cmd.Trim().ToUpper().Equals("EXIT"))
            {
                return true;
            }
            else if (cmd.Trim().ToUpper().Equals("PRINT"))
            {
                if (par.Length > 1000000)
                {
                    par = par.Substring(0, 99999);
                }
                Console.Write(par);
                isExit = ExecuteCommand(cmdEx);
            }
            else if (cmd.Trim().ToUpper().Equals("FOR"))
            {
                string[] counts = par.Split(',');
                if (String.IsNullOrWhiteSpace(cmdEx))
                {
                    return false;
                }
                int a = 0, b = 0;
                int count = 0;
                if (counts.Length == 1)
                {
                    int.TryParse(counts[0], out count);
                }
                else if (counts.Length == 2)
                {
                    int.TryParse(counts[0], out a);
                    int.TryParse(counts[1], out b);
                    count = Math.Abs(b - a + 1);
                }
                int max = 1000000;
                if (currentIterationCount == 0)
                {
                    currentIterationCount = count;
                }
                else
                {
                    currentIterationCount *= count;
                }
                if (count > max || currentIterationCount>= maxLoopCount) return false;
                for (int i = 0; i < count; i++)
                {
                    isExit = ExecuteCommand(cmdEx);
                }
            }
            else
            {
                if (!isExit) isExit = ExecuteCommand(cmdEx);
            }
            return isExit;
        }

        static string[] CustomSplit(string toSplit)
        {
            List<string> res = new List<string>();
            int bracesCount = 0;
            int beg = 0;
            for (int i = 0; i < toSplit.Length; i++)
            {
                char ch = toSplit[i];
                if (ch == '(') bracesCount = 1;
                if (ch == ')')
                {
                    if (bracesCount > 0) bracesCount--;
                }
                if (ch == ';' && bracesCount == 0)
                {
                    res.Add(toSplit.Substring(beg, i - beg));
                    beg = i + 1;
                }
            }
            return res.ToArray();
        }

        static void Analyze(string line)
        {
            string[] commands = CustomSplit(line);

            foreach (var item in commands)
            {
                currentIterationCount = 0;
                if (ExecuteCommand(item) == true) return;
            }
        }
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder(100011);
            string exit = "EXIT;";
            int exCmd = 0;
            while (exCmd < exit.Length)
            {
                char ch = (char) Console.Read();
                int bracesCount = 0;
                if (ch == '(') bracesCount++;
                if (ch == ')')
                {
                    if (bracesCount > 0) bracesCount--;
                }
                if (ch != ' ' && bracesCount == 0)
                {
                    sb.Append(ch);
                    if (char.ToUpper(ch) == exit[exCmd])
                    {
                        exCmd++;
                        if (exCmd == exit.Length)
                        {
                            break;
                        }
                    }
                    else
                    {
                        exCmd = 0;
                    }
                }
                else
                {
                    sb.Append(ch);
                }
                if (sb.Length > 10000) break;
            }
            Analyze(sb.ToString());
            Console.WriteLine();
        }
    }
}