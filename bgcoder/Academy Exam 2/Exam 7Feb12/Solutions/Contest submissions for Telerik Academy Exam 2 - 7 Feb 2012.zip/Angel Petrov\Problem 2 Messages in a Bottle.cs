using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagesInBottle
{
    class MessagesInBottle
    {
        static void Main(string[] args)
        {
            string encoded = Console.ReadLine();
            string cypher = Console.ReadLine();
            List<char> letters = new List<char>();
            List<string> encodement = new List<string>();
            List<string> variations = new List<string>();
            StringBuilder sb = new StringBuilder();
            string copy = encoded;
            int flag = 0;
            int flag2 = 0;
            for (int i = 0; i < cypher.Length; i++)
            {
                if (flag == 1 && cypher[i] >= 'A' && cypher[i] <= 'Z')
                {
                    encodement.Add(sb.ToString());
                    sb.Clear();
                    flag = 0;
                }
                if (cypher[i] >= 'A' && cypher[i] <= 'Z')
                {
                    letters.Add(cypher[i]);
                }
                if (cypher[i] >= '0' && cypher[i] <= '9')
                {
                    sb.Append(cypher[i]);
                    flag = 1;
                }
            }
            if (flag == 1)
            {
                encodement.Add(sb.ToString());
                sb.Clear();
            }
            flag = 0;
            for (int j = 0; j < encodement.Count; j++)
            {
                int index = 0;
                for (int i = j; i < encodement.Count; i++)
                {
                    index = encoded.IndexOf(encodement[i]);
                    if (index != -1)
                    {
                        copy = copy.Replace(encodement[i], letters[i].ToString());
                        flag2 = 1;
                    }
                }
                index = 0;
                for (int i = 0; i < encodement.Count; i++)
                {
                    index = encoded.IndexOf(encodement[i], index + 1);                   
                    if (index != -1)
                    {
                        copy = copy.Replace(encodement[i], letters[i].ToString());
                        flag2 = 1;

                    }
                }
                for (int i = 0; i < variations.Count; i++)
                {
                    if (copy == variations[i])
                    {
                        flag = 1;
                    }
                }
                if (flag == 0 && flag2==1)
                {
                    variations.Add(copy);
                }
                copy = encoded;
            }
            Console.WriteLine(variations.Count);
            if (variations.Count > 0)
            {
                variations.Sort();
                for (int i = 0; i < variations.Count; i++)
                {
                    Console.WriteLine(variations[i]);
                }
            }
        }
    }
}