using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Problem_4_3D_Max_Walk
{
    class MaxWalk3D
    {
 
 
        static void Main()
        {
 Console.WriteLine(-1);
        }
    }
}