using System;
using System.Text;
using System.Collections.Generic;

namespace _2.MessageInBottles
{
    class MessageInBottles
    {
        static StringBuilder secretCode;
        static Queue<string> answers;
        //static List<Letters> letters;

        //public struct Letters
        //{
        //    public string letter;
        //    public string encoding;
        //}

        static string[,] letters;
        //{
        //    {"1", "12", "11", "2"},
        //    {"A", "B", "C", "D"}
        //};

        static void Next(int length)
        {
            if (length == secretCode.Length)
            {
                string s = secretCode.ToString();
                if (!answers.Contains(s.ToString()))
                {
                    answers.Enqueue(s);                                        
                }
                return;
            }
            
            for (int letter = 0; letter < letters.GetLength(1); letter++)
            {
                int findSpotIndex = secretCode.ToString().IndexOf(letters[0, letter]);
                if (findSpotIndex != -1)
                {
                    secretCode = secretCode.Remove(findSpotIndex, letters[0, letter].Length);
                    secretCode = secretCode.Insert(findSpotIndex, letters[1, letter]);
                    length += letters[1, letter].Length;

                    Next(length);

                    length -= letters[1, letter].Length;
                    secretCode = secretCode.Remove(findSpotIndex, letters[1, letter].Length);
                    secretCode = secretCode.Insert(findSpotIndex, letters[0, letter]);                  
         
                }
            }
       	    
        }

        static void Main(string[] args)
        {
            char[] separators = "ABCDEFGHIGKLMNOPQRSTUVWXYZ".ToCharArray();
            char[] separators2 = "01234567890".ToCharArray();
            secretCode = new StringBuilder(Console.ReadLine());
            string originalMessage = Console.ReadLine();
            string[] numbers = originalMessage.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            string[] lettersInput = originalMessage.Split(separators2, StringSplitOptions.RemoveEmptyEntries);
            
            letters = new string[2, numbers.Length];

            for (int values = 0; values < letters.GetLength(1); values++)
            {
                letters[0, values] = numbers[values];
            }

            for (int values = 0; values < letters.GetLength(1); values++)
            {
                letters[1, values] = lettersInput[values];
            }
            
            answers = new Queue<string>();
            Next(0);
            Console.WriteLine(answers.Count);
            int length = answers.Count;
            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(answers.Dequeue());                
            }
        }
    }
}