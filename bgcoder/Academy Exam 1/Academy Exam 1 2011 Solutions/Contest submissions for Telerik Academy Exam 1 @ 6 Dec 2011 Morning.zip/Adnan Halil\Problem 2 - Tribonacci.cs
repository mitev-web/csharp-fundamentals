using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {

            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            short n = short.Parse(Console.ReadLine());
            BigInteger sum=0;
            for (int i = 3; i < n; i++)
            {
                sum = a + b + c;
                a = b;
                b = c;
                c = sum;


            }
            Console.WriteLine("{0}",sum);
        }
    }
}
