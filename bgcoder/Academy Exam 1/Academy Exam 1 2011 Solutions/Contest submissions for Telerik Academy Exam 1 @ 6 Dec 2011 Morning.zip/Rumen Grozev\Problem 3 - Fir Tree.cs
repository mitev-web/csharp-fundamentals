using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, k = 1,t, n;
            n = int.Parse(Console.ReadLine());

            for (i = 1; i < n; i++)
            {
                for (j = 1; j <= 2 * n - 2; j++)
                {
                    if (i + j == n)
                    {
                        for (t = 0; t < k; t++)
                        {
                            Console.Write("*");
                            j++;
                        }
                        k += 2;
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
            //Console.WriteLine();
            for (i = 1; i < 2 * n - 2; i++)
            {
                if (i == n - 1)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
