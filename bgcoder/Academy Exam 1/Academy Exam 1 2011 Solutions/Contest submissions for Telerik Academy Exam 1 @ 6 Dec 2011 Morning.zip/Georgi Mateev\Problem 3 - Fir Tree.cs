using System;


namespace _3_Fir_Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            byte width = (byte)(2*n-3);
            byte mid = (byte)(width / 2 + 1);
            byte l = mid;
            byte r = mid;

            for (int row = 1; row <=n-1 ; row++)
            {
                for (int col = 1; col <= width; col++)
                {
                    if (col>=l && col<=r)
                    {
                        Console.Write('*');
                    }
                    else
                    {
                        Console.Write('.');
                    }
                }
                l--;
                r++;
                Console.WriteLine();
            }
            for (int i = 1; i <= width; i++)
            {
                if (i==mid)
                {
                    Console.Write('*');
                }
                else
                {
                    Console.Write('.');
                }
            }
        }
    }
}
