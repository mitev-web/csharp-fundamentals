using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger current = 0;
            BigInteger t1;
            BigInteger t2;
            BigInteger t3;
            short n;

            t1 = BigInteger.Parse(Console.ReadLine());
            t2 = BigInteger.Parse(Console.ReadLine());
            t3 = BigInteger.Parse(Console.ReadLine());           
            n = short.Parse(Console.ReadLine());

            if (n == 1)
            {
                Console.WriteLine(t1); 
            }
            if (n == 2)
            {
                Console.WriteLine(t2);
            }
            if (n == 3)
            {
                Console.WriteLine(t3);
            }

            if (n == 4)
            {
                current = t1 + t2 + t3;                
            }
            if (n > 4)
            {
                for (int i = 3; i < n; i++)
                {
                    current = t1 + t2 + t3;
                    t1 = t2;
                    t2 = t3;
                    t3 = current;
                }
                Console.WriteLine(current);
            }         
        }
    }
}