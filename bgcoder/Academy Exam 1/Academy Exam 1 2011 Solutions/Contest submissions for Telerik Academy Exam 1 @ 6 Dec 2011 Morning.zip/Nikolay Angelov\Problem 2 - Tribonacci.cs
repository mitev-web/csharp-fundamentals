using System;
using System.Numerics;

namespace ex2a
{
    class Program
    {
        public static BigInteger trib(int a, int b, int c, int n)
        {
            BigInteger[] numbers = new BigInteger[n];
            BigInteger d = 0;
            if (n == 0)
            {
                return d;
            }
            else if(n == 1)
            {
                return d = a;
            }
            else if(n == 2)
            {
                return d = b;
            }
            else if(n == 3)
            {
                return d = c;
            }
            else if(n > 3)
            {
                numbers[0] = a;
                numbers[1] = b;
                numbers[2] = c;
                numbers[3] = numbers[2] + numbers[1] + numbers[0];
                for (int i = 2; i < n-1; i++)
                {
                    if (i + 1 != n)
                    {
                        numbers[i + 1] = numbers[i] + numbers[i - 1] + numbers[i - 2];
                    }
                }
                d = numbers[n-1];
                return d;
            }

            return d;
        }
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());

            int x = int.Parse(Console.ReadLine());
            Console.WriteLine(trib(a, b, c, x));
        }
    }
}
