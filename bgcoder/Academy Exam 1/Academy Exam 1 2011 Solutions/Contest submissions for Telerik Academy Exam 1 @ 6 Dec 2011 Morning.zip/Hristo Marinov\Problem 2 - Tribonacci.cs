using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger t1, t2, t3,n,tn=0;
            t1 = BigInteger.Parse(Console.ReadLine());
            t2 = BigInteger.Parse(Console.ReadLine());
            t3 = BigInteger.Parse(Console.ReadLine());
            n = BigInteger.Parse(Console.ReadLine());
            if(n==1)Console.WriteLine(t1);
            else
            if(n==2)Console.WriteLine(t2);
            else
                if (n == 3) Console.WriteLine(t3);
                else
                {
                    for (int i = 4; i <= n; i++)
                    {
                        tn = t1 + t2 + t3;
                        t1 = t2;
                        t2 = t3;
                        t3 = tn;
                       // Console.WriteLine(tn);
                    }
                    Console.WriteLine(tn);
                }
        }
    }
}
