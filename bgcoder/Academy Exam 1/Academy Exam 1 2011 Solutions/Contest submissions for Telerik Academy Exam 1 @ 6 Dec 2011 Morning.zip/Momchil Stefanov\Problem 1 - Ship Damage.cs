using System;

namespace _01.CalculateShipDamage
{
    class CalculateShipDamage
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            int C1hit;
            int C2hit;
            int C3hit;
            float damage = 0.0f;

            if (Cy1 > 0 && Cy1 < H)
            {
                C1hit = 2 * H - Cy1;
            }
            else if (Cy1 > H)
            {
                C1hit = 2 * H - Cy1;
            }
            else if (Cy1 < H)
            {
                C1hit = Math.Abs(Cy1) + 2 * H;
            }
            else
            {
                C1hit = H;
            }

            if (Cy2 > 0 && Cy2 < H)
            {
                C2hit = 2 * H - Cy2;
            }
            else if (Cy2 > H)
            {
                C2hit = 2 * H - Cy2;
            }
            else if (Cy2 < H)
            {
                C2hit = Math.Abs(Cy2) + 2 * H;
            }
            else
            {
                C2hit = H;
            }

            if (Cy3 > 0 && Cy3 < H)
            {
                C3hit = 2 * H - Cy3;
            }
            else if (Cy3 > H)
            {
                C3hit = 2 * H - Cy3;
            }
            else if (Cy3 < H)
            {
                C3hit = Math.Abs(Cy3) + 2 * H;
            }
            else
            {
                C3hit = H;
            }

            //  First catapult

            if (Cx1 > Math.Min(Sx1,Sx2) && Cx1 < Math.Max(Sx1,Sx2) && C1hit > Math.Min(Sy1,Sy2) && C1hit < Math.Max(Sy1,Sy2))
            {
                damage += 1;
            }

            if (Cx1 > Math.Min(Sx1, Sx2) && Cx1 < Math.Max(Sx1, Sx2) && (C1hit == Sy1 || C1hit == Sy2))
            {
                damage += 0.5f;
            }

            if (C1hit > Math.Min(Sy1, Sy2) && C1hit < Math.Max(Sy1, Sy2) && (Cx1 == Sx1 || Cx1 == Sx2))
            {
                damage += 0.5f;
            }

            if (Cx1 == Sx1 && (C1hit == Sy1 || C1hit == Sy2))
            {
                damage += 0.25f;
            }

            if (Cx1 == Sx2 && (C1hit == Sy1 || C1hit == Sy2))
            {
                damage += 0.25f;
            }

            //  Second catapult

            if (Cx2 > Math.Min(Sx1, Sx2) && Cx2 < Math.Max(Sx1, Sx2) && C2hit > Math.Min(Sy1, Sy2) && C2hit < Math.Max(Sy1, Sy2))
            {
                damage += 1;
            }

            if (Cx2 > Math.Min(Sx1, Sx2) && Cx2 < Math.Max(Sx1, Sx2) && (C2hit == Sy1 || C2hit == Sy2))
            {
                damage += 0.5f;
            }

            if (C2hit > Math.Min(Sy1, Sy2) && C2hit < Math.Max(Sy1, Sy2) && (Cx2 == Sx1 || Cx2 == Sx2))
            {
                damage += 0.5f;
            }

            if (Cx2 == Sx1 && (C2hit == Sy1 || C2hit == Sy2))
            {
                damage += 0.25f;
            }

            if (Cx2 == Sx2 && (C2hit == Sy1 || C2hit == Sy2))
            {
                damage += 0.25f;
            }

            //  Third catapult

            if (Cx3 > Math.Min(Sx1, Sx2) && Cx3 < Math.Max(Sx1, Sx2) && C3hit > Math.Min(Sy1, Sy2) && C3hit < Math.Max(Sy1, Sy2))
            {
                damage += 1;
            }

            if (Cx3 > Math.Min(Sx1, Sx2) && Cx3 < Math.Max(Sx1, Sx2) && (C3hit == Sy1 || C3hit == Sy2))
            {
                damage += 0.5f;
            }

            if (C3hit > Math.Min(Sy1, Sy2) && C3hit < Math.Max(Sy1, Sy2) && (Cx3 == Sx1 || Cx3 == Sx2))
            {
                damage += 0.5f;
            }

            if (Cx3 == Sx1 && (C3hit == Sy1 || C3hit == Sy2))
            {
                damage += 0.25f;
            }

            if (Cx3 == Sx2 && (C3hit == Sy1 || C3hit == Sy2))
            {
                damage += 0.25f;
            }

            Console.WriteLine("{0:##0%}", damage);
        }
    }
}
