using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3ProblemFirTree
{
    class FirTree
    {
        static void Main(string[] a)
        {

            int heigh = int.Parse(Console.ReadLine());
            int width = ((heigh - 1) * 2) -1;
            int i = 0;

            for (int row = 1; row <= heigh; row++)
            {
                for (int col = 1; col <= width; col++)
                {
                   
                    if ((col == (width / 2)+1) && (row == 1))
                    {
                        Console.Write("*");
                    }
                    else if ((col == (width / 2)+1) && (row == heigh))
                    {
                        Console.Write("*");
                    }

                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();

            }
        }
    }
}