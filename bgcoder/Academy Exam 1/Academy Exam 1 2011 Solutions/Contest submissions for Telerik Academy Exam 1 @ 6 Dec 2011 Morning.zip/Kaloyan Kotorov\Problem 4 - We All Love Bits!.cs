using System;

namespace WeAllHateBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int[] numberP = new int[n];
            int[] numberPExchanged = new int[n];
            int[] numberPReversed = new int[n];
            int[] numberPNew = new int[n];

            
            int a = 0;
            a = ~a;

            for (int i = 0; i < n; i++)
            {
                numberP[i] = int.Parse(Console.ReadLine());
            }

            for (int j = 0; j < n; j++)
            {
                int counter = 0;
                for (int i = 31; i >= 0; i--)
                {
                    if ((numberP[j] >> i) % 2 == 1)
                    {
                        
                        numberPExchanged[j] = ~numberP[j];
                        numberPExchanged[j] = (a << (i + 1)) ^ numberPExchanged[j];
                        break;
                    }
                    counter++;
                }
                int b = numberP[j];
                for (int c = 0; c < 32; c++)
                {
                    numberPReversed[j] = (numberPReversed[j] << 1) + (b & 1);
                    b = b >> 1;
                }
                numberPReversed[j] = numberPReversed[j] >> counter;
                numberPReversed[j] = (a << (32 - counter)) ^ numberPReversed[j];
            }
            
            for (int i = 0; i < n; i++)
			{
                int z = numberP[i];
                int x = numberPExchanged[i];
                int y = numberPReversed[i];
                numberPNew[i] = (z ^ x) & y;
                Console.WriteLine(numberPNew[i]);
			}
        }
    }
}
