using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] initialNumbers = new int[3];
            int n, i;
            BigInteger[] tribonacci;
            for (i = 0; i < 3; i++)
            {
                initialNumbers[i] = int.Parse(Console.ReadLine());
            }
            n = int.Parse(Console.ReadLine());
            tribonacci = new BigInteger[n];
            for (i = 0; i < n; i++)
            {
                if (i < 3)
                {
                    tribonacci[i] = initialNumbers[i];
                }
                else
                {
                    tribonacci[i] = tribonacci[i - 1] + tribonacci[i - 2] + tribonacci[i - 3];
                }
            }
            Console.WriteLine(tribonacci[n - 1]);
        }
    }
}
