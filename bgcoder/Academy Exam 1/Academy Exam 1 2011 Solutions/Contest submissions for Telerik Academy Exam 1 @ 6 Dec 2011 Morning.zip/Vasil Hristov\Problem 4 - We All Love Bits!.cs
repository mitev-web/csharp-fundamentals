using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem4
{
    class Program
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int[] numbers= new int[N];
            for (int i = 0; i < N; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
             int[] inversNumbers= new int[N];
            int p = 0;
            for (int i = 0; i < N; i++)
            {
                inversNumbers[i] = ~numbers[i];
            }
            int[] bits1 = new int[32];
            int[] reversNumber = new int[N];
            for (int i = 0; i < N; i++)
            {
                int k=numbers[i];
                for (int j = 31,l=0; j >= 0; j--,l++)
                {
                    if ((k & 1) == 1) { bits1[l] = 1; }
                    else { bits1[l] = 0; }
                   k >>= (1);
                   // Console.Write(bits1[l]);
                }
                
             //   for (int n = 0,u=31; n < 32; n++)
              //  {
               //    if (bits1[n] == 1) k = 1;
               //    if (k == 1&&!(u<=n)) {
                //        int po = bits1[n];
                //     bits1[n] = bits1[u];
                //        bits1[u] = po;
                   //     u--;
                 // }
               // }
               
                int[] reversed = bits1.Reverse().ToArray();
               // Console.WriteLine();
               // for (int y = 0; y < 32; y++)
               // {
               //     Console.Write(bits1[y]);
              //  }
                //Console.WriteLine();
                int mamo = -1;
                for (int t = 31,x=0; t >=0; t--)
                {
                    
                    if (bits1[t] == 1)
                    {
                        mamo = 1;
                        reversNumber[i] = reversNumber[i] | (int)(1 << x);
                       // x++;
                     //  Console.WriteLine(reversNumber[i]);
                    }
                    if (mamo == 1) x++;
                 //  else
                  //  {
                     //   reversNumber[i] = reversNumber[i] & (~(int)(1 << i));
                     //   Console.WriteLine(reversNumber[i] = reversNumber[i] & (~(int)(1 << i)));
                   // }
                }
                    

             //   Console.WriteLine();
              //  Console.WriteLine(reversNumber[i]);
            }
            for (int i = 0; i < N; i++)
			{
                long P = (numbers[i] ^ inversNumbers[i]) & reversNumber[i];
                Console.WriteLine(P);
			}
            
        }
    }
}
