using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
 
 
namespace FirThree
{
    class FirThree
    {
        static void Main(string[] args)
        {
             int n = Convert.ToInt32(Console.ReadLine());
             for (int i = 1; i <= n; i++)
             {
                  for (int j = n - 1; j >= i; j--)
                  {
                       Console.Write(".");
                  }
                  for (int k = 1; k <= i; k++)
                  {
                       Console.Write("*");
                  }
                  for (int m = 2; m <= i; m++)
                  {
                       Console.Write("*");
                  }
                  for (int z = n; z >= i + 1; z--)
                  {
                       Console.Write(".");
                  }
                  for (int y = i; y <= i; y++)
                  {
                       Console.WriteLine();
                  }
             }
             for (int i = 1; i <= n - 1; i++)
             {
                  Console.Write(".");
             }
             Console.Write("*");
             for (int i = 1; i <= n - 1; i++)
             {
                  Console.Write(".");
             }
             Console.WriteLine();
        }
    }
}