using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("");
            long a = long.Parse(Console.ReadLine());
            Console.Write("");
            long b = long.Parse(Console.ReadLine());
            Console.Write("");
            long c = long.Parse(Console.ReadLine());
            Console.Write("");
            ushort n = ushort.Parse(Console.ReadLine());
            long d = 0;

            for (int i = 3; i < n; i++)
            {
                d = a + b + c;
                a = b;
                b = c;
                c = d;
            }
            Console.WriteLine((BigInteger)d);

        }
    }
}