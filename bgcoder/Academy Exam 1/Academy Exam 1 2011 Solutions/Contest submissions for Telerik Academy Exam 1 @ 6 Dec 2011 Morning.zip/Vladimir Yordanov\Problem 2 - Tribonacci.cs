using System;

namespace ExamProblem2
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());
            int element = int.Parse(Console.ReadLine());
            int temp=0;
            temp = num1 + num2 + num3;

            for (int i = 4; i < element; i++)
            {
                num1 = num2;
                num2 = num3;
                num3 = temp;
                temp = num1 + num2 + num3;
            }

            Console.WriteLine(temp);
        }
    }
}