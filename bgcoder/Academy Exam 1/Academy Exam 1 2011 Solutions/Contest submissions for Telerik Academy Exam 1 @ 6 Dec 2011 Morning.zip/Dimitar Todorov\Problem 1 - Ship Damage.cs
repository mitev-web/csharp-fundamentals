using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
  
namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
  
            int damage = 0;
            cy1 = Math.Abs(cy1) + h;
            cy2 = Math.Abs(cy2) + h;
            cy3 = Math.Abs(cy3) + h;
  
            int temp = sx1;
            if(sx1<sx2)
            {
                sx1 = sx2;
                sx2 = temp;
            }
  
            if ((cx1 < sx1) && (cx1 > sx2))
            {
                if (sy2 > sy1)
                {
                    if (cy1 < sy2 && cy1 > sy1)
                    {
                        damage = damage + 100;
                    }
                    else if (cy1 == sy2 || cy1 == sy1)
                    {
                        damage = damage + 50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else
                {
                    if (cy1 < sy1 && cy1 > sy2)
                    {
                        damage = damage + 100;
                    }
                    else if (cy1 == sy1 || cy1 == sy2)
                    {
                        damage = damage + 50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
  
                }
  
            }
            else if (cx1 == sx1 || cx1 == sx2)
            {
                if (sy2 > sy1)
                {
                    if (cy1 < sy2 && cy1 > sy1)
                    {
                        damage = damage + 50;
                    }
                    else if (cy1 == sy2 || cy1 == sy1)
                    {
                        damage = damage + 25;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else
                {
                    if (cy1 < sy1 && cy1 > sy2)
                    {
                        damage = damage + 50;
                    }
                    else if (cy1 == sy1 || cy1 == sy2)
                    {
                        damage = damage + 25;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
  
                }
                damage = damage + 25;
            }
            else if(cx1>sx1)
            {
                damage = damage + 0;
            }
            else if (cx1 < sx2)
            {
                damage = damage + 0;
            }
  
  
            if ((cx2 < sx1) && (cx2 > sx2))
            {
                if (sy2 > sy1)
                {
                    if (cy2 < sy2 && cy2 > sy1)
                    {
                        damage = damage + 100;
                    }
                    else if (cy2 == sy2 || cy2 == sy1)
                    {
                        damage = damage + 50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else
                {
                    if (cy2 < sy1 && cy2 > sy2)
                    {
                        damage = damage + 100;
                    }
                    else if (cy2 == sy1 || cy2 == sy2)
                    {
                        damage = damage + 50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
  
                }
  
            }
  
  
            else if (cx2 == sx1 || cx2 == sx2)
            {
                if (sy2 > sy1)
                {
                    if (cy2 < sy2 && cy2 > sy1)
                    {
                        damage = damage + 50;
                    }
                    else if (cy2 == sy2 || cy2 == sy1)
                    {
                        damage = damage + 25;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else
                {
                    if (cy2 < sy1 && cy2 > sy2)
                    {
                        damage = damage + 50;
                    }
                    else if (cy2 == sy1 || cy2 == sy2)
                    {
                        damage = damage + 25;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
  
                }
                damage = damage + 25;
            }
  
  
            else if(cx2>sx1)
            {
                damage = damage + 0;
            }
            else if (cx2 < sx2)
            {
                damage = damage + 0;
            }
  
  
  
  
            if ((cx3 < sx1) && (cx3 > sx2))
            {
                if (sy2 > sy1)
                {
                    if (cy3 < sy2 && cy3 > sy1)
                    {
                        damage = damage + 100;
                    }
                    else if (cy3 == sy2 || cy3 == sy1)
                    {
                        damage = damage + 50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else
                {
                    if (cy3 < sy1 && cy3 > sy2)
                    {
                        damage = damage + 100;
                    }
                    else if (cy3 == sy1 || cy3 == sy2)
                    {
                        damage = damage + 50;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
  
                }
  
            }
  
            else if (cx3 == sx1 || cx3 == sx2)
            {
                if (sy2 > sy1)
                {
                    if (cy3 < sy2 && cy3 > sy1)
                    {
                        damage = damage + 50;
                    }
                    else if (cy3 == sy2 || cy3 == sy1)
                    {
                        damage = damage + 25;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
                }
                else
                {
                    if (cy3 < sy1 && cy3 > sy2)
                    {
                        damage = damage + 50;
                    }
                    else if (cy3 == sy1 || cy3 == sy2)
                    {
                        damage = damage + 25;
                    }
                    else
                    {
                        damage = damage + 0;
                    }
  
                }
                damage = damage + 25;
            }
            else if(cx3 > sx1)
            {
                damage = damage + 0;
            }
            else if (cx3 < sx2)
            {
                damage = damage + 0;
            }
            Console.WriteLine(damage +"%");
  
              
        }
    }
}