using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars_05
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] n = new byte[8];            
            byte[] count = new byte[8];
            int i = 0;
            for (i = 0; i < 8; i++)
            {
                n[i] = byte.Parse(Console.ReadLine());
            }

            //for 2^7
            for (i = 0; i < 8; i++)
            {
                byte c = 128;
                if (n[i] >= c)
                {
                    count[7]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^6
            for (i = 0; i < 8; i++)
            {
                byte c = 64;
                if (n[i] >= c)
                {
                    count[6]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^5
            for (i = 0; i < 8; i++)
            {
                byte c = 32;
                if (n[i] >= c)
                {
                    count[5]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^4
            for (i = 0; i < 8; i++)
            {
                byte c = 16;
                if (n[i] >= c)
                {
                    count[4]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^3
            for (i = 0; i < 8; i++)
            {
                byte c = 8;
                if (n[i] >= c)
                {
                    count[3]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^2
            for (i = 0; i < 8; i++)
            {
                byte c = 4;
                if (n[i] >= c)
                {
                    count[2]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^1
            for (i = 0; i < 8; i++)
            {
                byte c = 2;
                if (n[i] >= c)
                {
                    count[1]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            //for 2^0
            for (i = 0; i < 8; i++)
            {
                byte c = 1;
                if (n[i] >= c)
                {
                    count[0]++;
                    n[i] = (byte)(n[i] - c);
                }
            }
            
            
            int check = 0;
            for (i = 7; i >= 0; i--)
            {
                int sumL = 0;
                int sumR = 0;
                for (int j = 7; j > i; j--)
                {
                    sumL=sumL+count[j];
                }
                for (int j = i - 1; j >= 0;j-- )
                {
                    sumR = sumR + count[j];
                }
                if (sumR == sumL)
                {
                    Console.WriteLine(i);
                    Console.WriteLine(sumL);
                    check = 2;
                    break;
                }
            }
            if (check == 0)
            {
                Console.WriteLine("No");
            }


        }
    }
}
