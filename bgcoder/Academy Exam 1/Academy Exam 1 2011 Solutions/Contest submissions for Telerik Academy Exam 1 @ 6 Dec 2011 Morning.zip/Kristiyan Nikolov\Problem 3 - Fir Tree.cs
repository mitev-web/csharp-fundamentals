using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prob3_FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            byte n = byte.Parse(input);

            for (int i = 0; i < n - 1; i++)
            {
                Console.Write(new String('*', i).PadLeft(n - 2, '.'));
                Console.Write('*');
                Console.WriteLine(new String('.', n - i - 2).PadLeft(n - 2, '*'));
            }
            Console.Write(new String('.', n - 2));
            Console.Write('*');
            Console.WriteLine(new String('.', n - 2));
        }
    }
}
