using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ship
{
    class Program
    {
        struct Ship
        {
            public int x1;
            public int y1;
            public int x2;
            public int y2;
            public int range;
        };
        struct Catpult
        {
            public int x1;
            public int y1;
            public int range;
        };


        static void Main()
        {
            double res = 0;
            Catpult[] cArray = new Catpult[3];
            Ship s = new Ship();
            s.x1 = Convert.ToInt32(Console.ReadLine());
            s.y1 = Convert.ToInt32(Console.ReadLine());
            s.x2 = Convert.ToInt32(Console.ReadLine());
            s.y2 = Convert.ToInt32(Console.ReadLine());
            int H = Convert.ToInt32(Console.ReadLine());
            
            for (int i = 0; i < 3; i++)
            {
                cArray[i].x1 = Convert.ToInt32(Console.ReadLine());
                cArray[i].y1 = Convert.ToInt32(Console.ReadLine());
                cArray[i].range = H - cArray[i].y1 + H;
            }
           
            for(int i = 0; 
                i < 3;i++)
            {
                if( (cArray[i].x1 <= s.x2  && cArray[i].x1 >= s.x1) || (cArray[i].x1 <= s.x1  && cArray[i].x1 >= s.x2) )
                    if ((cArray[i].range >= s.y1 && cArray[i].range <= s.y2)  || (cArray[i].range >=s.y2 && cArray[i].range <=s.y1))
                    {
                        if (cArray[i].x1 == s.x1 || cArray[i].x1 == s.x2)
                        {
                            if (cArray[i].range == s.y1 || cArray[i].range == s.y2)
                                res += 0.25;
                            else
                                res += 0.5;
                        }
                        else if (cArray[i].range ==s.y1 || cArray[i].range == s.y2)
                            res += 0.5;
                        else
                            res += 1;
                    }
            }
            Console.WriteLine("{0}%", res * 100);
        }
       
        
    }
}
