using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Battleship
{
    class battleship
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine()); 
            int Sy1 = int.Parse(Console.ReadLine()); 
            int Sx2 = int.Parse(Console.ReadLine()); 
            int Sy2 = int.Parse(Console.ReadLine()); 
            int H = int.Parse(Console.ReadLine()); 
            int Cx1 = int.Parse(Console.ReadLine()); 
            int Cy1 = int.Parse(Console.ReadLine()); 
            int Cx2 = int.Parse(Console.ReadLine()); 
            int Cy2 = int.Parse(Console.ReadLine()); 
            int Cx3 = int.Parse(Console.ReadLine()); 
            int Cy3 = int.Parse(Console.ReadLine()); 
            int result=0;
            if (Sx1 < 0)
            {
                Sx1 *= -1;
            }
            if (Sx2 < 0)
            {
                Sx2 *= -1;
            }
            if (Cx1 < 0)
            {
                Cx1 *= -1;
            }
            if (Cx2 < 0)
            {
                Cx2 *= -1;
            }
            if (Cx3 < 0)
            {
                Cx3 *= -1;
            }
            if (Cy1<0)
            {
             Cy1 = H + 1 + (Cy1 * (-1));   
            }
            
            if (Cy2<0)
            {
                Cy2 = H + 1 + (Cy2 * (-1));  
            }
            if (Cy3<0)
            {
                Cy3 = H + 1 + (Cy3 * (-1));
            }
            
            
            if ((Sx1 == Cx1) && (Sy1 == Cy1))
            {
                result += 25;
                
            }
            if ((Sx1 == Cx2) && (Sy1 == Cy2))
            {
                result += 25;
                
            }
            if ((Sx1 == Cx3) && (Sy1 == Cy3))
            {
                result += 25;
                
            }
            

            if ((Sx1 == Cx1) && (Sy1 == Cy1))
            {
                result += 25;
                
            }
            if ((Sx1 == Cx2) && (Sy1 == Cy2))
            {
                result += 25;
                
            }
            if ((Sx1 == Cx3) && (Sy1 == Cy3))
            {
                result += 25;
                
            }

            
            
            if ((Sx2 == Cx1) && (Sy2 == Cy1))
            {
                result += 25;
                
            }
            if ((Sx2 == Cx2) && (Sy2 == Cy2))
            {
                result += 25;
                
            }
            if ((Sx2 == Cx3) && (Sy2 == Cy3))
            {
                result += 25;
                
            }


            if (((Cx1>Sx2)&&(Cx1<Sx1))||((Cx1>Sx1)&&(Cx1<Sx2)))
            {
                if ((Sx2 < Cx1) && (Cx1 < Sx1) && (Sy2 < Cy1) && (Cy1 < Sy1))
                {
                    result += 100;

                }
                else
               result += 50;   
            }
            if (((Cx2 > Sx2) && (Cx2 < Sx1)) || ((Cx2 > Sx1) && (Cx2 < Sx2)))
            {
                if ((Sx2 < Cx2) && (Cx2 < Sx1) && (Sy2 < Cy2) && (Cy2 < Sy1))
                {
                    result += 100;

                }
                else
               result += 50;

            }
            if (((Cx3 > Sx2) && (Cx3 < Sx1))||((Cx3>Sx1)&&(Cx3<Sx2)))
            {
                if ((Sx2 < Cx3) && (Cx3 < Sx1) && (Sy2 < Cy3) && (Cy3 < Sy1))
                {
                    result += 100;

                }
                else
               result += 50;
            }
            if (((Cy1>Sy2)&&(Cy1<Sy1))||((Cy1>Sx1)&&(Cy1<Sx2)))
            {
                if ((Sx2 < Cx1) && (Cx1 < Sx1) && (Sy2 < Cy1) && (Cy1 < Sy1))
                {
                    result += 100;

                }
                else
                    result += 50;   
            }
            if (((Cy2>Sy2)&&(Cy2<Sy1))||((Cy2>Sx1)&&(Cy2<Sx2)))
            {
                if ((Sx2 < Cx2) && (Cx2 < Sx1) && (Sy2 < Cy2) && (Cy2 < Sy1))
                {
                    result += 100;

                }
                else
                    result += 50;
            }
            if (((Cy3>Sy2)&&(Cy3<Sy1))||((Cy3>Sx1)&&(Cy3<Sx2)))
            {
                if ((Sx2 < Cx3) && (Cx3 < Sx1) && (Sy2 < Cy3) && (Cy3 < Sy1))
                {
                    result += 100;

                }
                else
                    result += 50;
            }



            

            Console.WriteLine("{0}%", result);
        }
    }
}
