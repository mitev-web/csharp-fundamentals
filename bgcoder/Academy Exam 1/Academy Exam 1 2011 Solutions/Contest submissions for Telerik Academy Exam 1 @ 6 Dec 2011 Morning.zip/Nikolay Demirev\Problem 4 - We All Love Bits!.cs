using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort N;
            int P;
            string input;

            input = Console.ReadLine();
            N = ushort.Parse(input);

            for (ushort counter = 0; counter < N; counter++)
            {
                input = Console.ReadLine();
                P = int.Parse(input);
                int inverterP = Invert(P);
                int reversedP = Reverse(P);
                int result = (int)((int)((int)P ^ (int)inverterP) & (int)reversedP);
                Console.WriteLine(result.ToString());
            }
        }

        private static int Invert(int number)
        {
            if (number == 0) return number;

            byte counter = 30;
            do
            {
                counter--;
            }
            while (counter > 0 && !GetBit(number, counter));

            while (counter > 0)
            {
                if (GetBit(number, counter))
                {
                    ResetBit(ref number, counter);
                }
                else
                {
                    SetBit(ref number, counter);
                }
                counter--;
            }

            if (GetBit(number, counter))
            {
                ResetBit(ref number, counter);
            }
            else
            {
                SetBit(ref number, counter);
            }

            return number;
        }

        private static int Reverse(int number)
        {
            byte counter = 30;
            do
            {
                counter--;
            }
            while (counter > 0 && !GetBit(number, counter));

            byte end = (byte)((counter + 1) / 2);

            for (byte i = 0; i < end; i++)
            {
                bool leftBit = GetBit(number, (byte)(counter - i));
                bool rightBit = GetBit(number, i);
                if (leftBit)
                {
                    SetBit(ref number, i);
                }
                else
                {
                    ResetBit(ref number, i);
                }

                if (rightBit)
                {
                    SetBit(ref number, (byte)(counter - i));
                }
                else
                {
                    ResetBit(ref number, (byte)(counter - i));
                }
            }

            return number;
        }

        private static void SetBit(ref int number, byte position)
        {
            int mask = 1;
            mask <<= position;
            number |= mask;
        }

        private static void ResetBit(ref int number, byte position)
        {
            int mask = 1;
            mask <<= position;
            mask = (int)~mask;
            number &= mask;
        }

        private static bool GetBit(int number, byte position)
        {
            return (int)((number >> position) & 1) == 1;
        }
    }
}
