using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
   class Program
   {
      static void Main(string[] args)
      {
         long n = long.Parse(Console.ReadLine());
         string result = "";
         string reverse = "";
         int count = 0;
         for (int i = 1; i <= n; i++)
         {
            long sequence = long.Parse(Console.ReadLine());

            while (sequence > 0)
            {
               long temp = sequence % 2;

               if (temp == 0)
               {
                  reverse = reverse + 0;
                  result = "0" + result;
                  count++;
               }
               else
               {

                  reverse = reverse + 1;
                  result = "1" + result;

               }
               sequence = sequence / 2;
            }

            // for (int i = 1; i <= n; i++)
            //{
            //   uint sequence = uint.Parse(Console.ReadLine());
            //   while (n > 0)
            //   {
            //      int temp = n % 2;

            //      if (temp == 0)
            //      {
            //         reverse = reverse + 0;
            //         result = "0" + result;
            //         count++;
            //      }
            //      else
            //      {
            //         reverse = reverse + 1;
            //         result = "1" + result;
            //         count++;
            //      }
            //      n = n / 2;
            //   }
            //}}

            //Console.WriteLine(result);
            //Console.WriteLine(reverse);

            // sbyte myInt = 1;
            // myInt = ~myInt;

            //Console.WriteLine(~ myInt);

            //sbyte a =sbyte.Parse(result);
            //Console.WriteLine(~(a));


            char a = ' ';
            // int sum = 0;

            string b = "";

            for (int j = 0; j < result.Length; j++)
            {
               a = result[j];

               if (a == '0')
               {
                  b = b + '1';
                  continue;
               }
               if (a == '1')
               {
                  b = b + '0';
               }

               //a = result[i];
               //if (a == '0')
               //{
               //   sum = 1;
               //}
               //else if (a == '1')
               //{
               //   sum = 0;
               //}
               // Console.WriteLine(b);
            }
            //Console.WriteLine(b);

            int c = int.Parse(result);
            Console.WriteLine(c);

            int d = int.Parse(reverse);
            Console.WriteLine(reverse);

            int e = int.Parse(b);
            Console.WriteLine(e);


            int res = (c ^ d) & e;
            Console.WriteLine(res);
         }
      }
   }
}
