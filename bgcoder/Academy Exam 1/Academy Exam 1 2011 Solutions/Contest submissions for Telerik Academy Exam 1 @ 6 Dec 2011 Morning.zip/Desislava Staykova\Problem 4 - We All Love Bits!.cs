using System;
using System.Numerics;
namespace Bits
{
    class Program
    {
        public static BigInteger MyReverse(BigInteger a)
        {
            int[] order = new int[8];

            for (int i = 0; i < 8; i++)
            {
                if ((a & Convert.ToInt32((Math.Pow(2, i)))) != 0)
                {
                    order[7 - i] = 1;
                }
                else
                {
                    order[7 - i] = 0;
                }
            }

            double result = 0;
            for (int i = 0; i < 8; i++)
            {
                result += order[i] * Math.Pow(2, i);
            }
            return (short)result;
        }


        static void Main(string[] args)
        {
            int n=int.Parse(Console.ReadLine());
            for (int i = 0; i < n;i++ )
            { BigInteger num = BigInteger.Parse(Console.ReadLine()); 
            
            BigInteger revN = MyReverse(num);
            BigInteger[] br = new BigInteger[8];
            BigInteger result;
            BigInteger copyN = num;
            for (int j = 0; i < 8; i++)
            {
                int p = i;

                int mask = 1 << p;        // 00000000 00100000
                BigInteger nAndMask = num & mask;  // 00000000 00100000
                BigInteger bit = nAndMask >> p;  // 00000000 00000001
                if (bit == 1)
                {
                    int mask2 = ~(1 << p);       // 11111111 11011111
                    result = num & mask;      // 00000000 00000011
                    br[i] = result;
                }
                else
                {
                    BigInteger mask1 = 1 << p;          // 00000000 00010000
                    result = num | mask;
                    br[i] = result;
                }

            }
            }
            Console.WriteLine(n);





        }
    }
}
