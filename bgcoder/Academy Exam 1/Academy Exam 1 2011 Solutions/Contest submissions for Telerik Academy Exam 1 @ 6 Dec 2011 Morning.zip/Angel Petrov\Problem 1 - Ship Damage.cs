using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sx1=int.Parse(Console.ReadLine());
            int sy1=int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
            int sx3, sx4, sy3, sy4;
            int damage=0;
            int cy11;
            int cy22;
            int cy33;
            int tmp;
            if (sx2 < sx1)
            {
                tmp = sx2;
                sx2 = sx1;
                sx1 = tmp;
            }
            if (sy2 > sy1)
            {
                tmp = sy2;
                sy2 = sy1;
                sy1 = tmp;
            }
            sx3 = sx1;
            sy3 = sy2;
            sx4 = sx2;
            sy4 = sy1;
            cy11 = (H - cy1) + H;
            cy22 = (H - cy2) + H;
            cy33 = (H - cy3) + H;
            if((cy11>sy2 && cy11<sy1) && (cx1>sx1 && cx1<sx2))
            {
                damage+=100;
            }
            if((cy22>sy2 && cy22<sy1) && (cx2>sx1 && cx2<sx2))
            {
                damage+=100;
            }
            if((cy33>sy2 && cy33<sy1) && (cx3>sx1 && cx3<sx2))
            {
                damage+=100;
            }
            if ((cy11 == sy1 && cx1 == sx1) || (cy11 == sy2 && cx1 == sx2) || (cy11 == sy3 && cx1 == sx3) || (cy11 == sy4 && cx1 == sx4))
            {
                damage += 25;
            }
            if ((cy22 == sy1 && cx2 == sx1) || (cy22 == sy2 && cx2 == sx2) || (cy22 == sy3 && cx2 == sx3) || (cy22 == sy4 && cx2 == sx4))
            {
                damage += 25;
            }
            if ((cy33 == sy1 && cx3 == sx1) || (cy33 == sy2 && cx3 == sx2) || (cy33 == sy3 && cx3 == sx3) || (cy33 == sy4 && cx3 == sx4))
            {
                damage += 25;
            }
            if (((cy22 == sy1) || (cy22 == sy2)) && (cx2 > sx1 && cx2 < sx2))
            {
                damage += 50;
            }
            if (((cy11 == sy1) || (cy11 == sy2)) && (cx1 > sx1 && cx1 < sx2))
            {
                damage += 50;
            }
            if ((cy33 == sy1 || cy33 == sy2) && (cx3 > sx1 && cx3 < sx2))
            {
                damage += 50;
            }
            if ((cx1 == sx1 || cx1 == sx2) && (cy11 > sy2 && cy11 < sy1))
            {
                damage += 50;
            }
            if ((cx2 == sx1 || cx2 == sx2) && (cy22 > sy2 && cy22 < sy1))
            {
                damage += 50;
            }
            if ((cx3 == sx1 || cx3 == sx2) && (cy33 > sy2 && cy33 < sy1))
            {
                damage += 50;
            }
            Console.WriteLine("{0}%",damage);
        }
    }
}
