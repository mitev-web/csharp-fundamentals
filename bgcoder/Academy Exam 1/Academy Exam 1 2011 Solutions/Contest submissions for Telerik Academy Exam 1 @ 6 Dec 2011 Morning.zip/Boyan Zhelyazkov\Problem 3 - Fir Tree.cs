using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirThree
{
    class Program
    {
        static void Main(string[] args)
        {
            int N,ind,three;
            N = int.Parse(Console.ReadLine());
            ind = N - 2;
            three = 1;

            for (int i = 0; i < N - 1; i++)
            {
                
                for (int j = 0; j < 2 * N - 3; j++)
                {
                    if (j < ind)
                    {
                        Console.Write(".");
                    }
                    else if (j < ind + three)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                ind--;
                three=three+2;
                Console.WriteLine();
            }
            ind = N - 2;
            three = 1;
            for (int j = 0; j < 2 * N - 3; j++)
            {
                if (j < ind)
                {
                    Console.Write(".");
                }
                else if (j < ind + three)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
        }
    }
}
