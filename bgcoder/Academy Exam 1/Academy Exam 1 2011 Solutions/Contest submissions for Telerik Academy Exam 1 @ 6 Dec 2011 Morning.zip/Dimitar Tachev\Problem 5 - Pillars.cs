using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam
{
    class Pillars
    {
        /// <summary>
        /// Returns you the value of the bit you want. (from byte)
        /// </summary>
        /// <param name="number">Byte from which you want to take a bit</param>
        /// <param name="bitNumber">The posiotion of the bit that you chose from the byte (starts from 0).</param>
        /// <returns>Returs you 0 if the value of the bit is 0 or returns 1 if the value is 1.</returns>
        public static byte GetBit(byte number, byte bitNumber)
        {
            byte pBit = (byte)((byte)1 << bitNumber);
            if ((pBit & number) == 0)
                return 0;
            else return 1;
        }
        static void Main(string[] args)
        {
            byte coll=0;
            byte cellLeft=0;
            bool flag = false;
            byte cellRight = 0;
            byte cells = 0;
            byte[] mas = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                mas[i] = byte.Parse(Console.ReadLine());
            }
            for (byte i = 0; i < 8; i++)
            {
                for (byte j = 0; j < 8; j++)
                {
                    if (j==i)
                    {
                        j++;
                    }
                    if (j==8)
                    {
                        break;
                    }
                    for (byte k = 0; k < 8; k++)
                    {
                        if (GetBit(mas[k],j)==1)
                        {
                            if (j<i)
                            {
                                cellRight++;
                            }
                            else
                            {
                                cellLeft++;
                            }
                        }
                    }

                }
                if (cellLeft == cellRight)
                {
                    coll = i;
                    cells = cellRight;
                    flag = true;
                }
                cellRight = 0;
                cellLeft = 0;
            }
            if (flag)
            {
                Console.WriteLine(coll);
                Console.WriteLine(cells);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
