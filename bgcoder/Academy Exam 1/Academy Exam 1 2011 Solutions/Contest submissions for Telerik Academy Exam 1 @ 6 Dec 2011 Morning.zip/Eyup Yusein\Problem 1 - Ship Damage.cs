using System;

namespace RealExam01
{
    class RealExam01
    {
        static void Main()
        {
            int minX = int.Parse(Console.ReadLine());
            int minY = int.Parse(Console.ReadLine());
            int maxX = int.Parse(Console.ReadLine());
            int maxY = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int c1x = int.Parse(Console.ReadLine());
            int c1y = int.Parse(Console.ReadLine());
            int c2x = int.Parse(Console.ReadLine());
            int c2y = int.Parse(Console.ReadLine());
            int c3x = int.Parse(Console.ReadLine());
            int c3y = int.Parse(Console.ReadLine());
            int sum = 0;

            if (minX > maxX)
            {
                minX = minX + maxX;
                maxX = minX - maxX;
                minX = minX - maxX;
            }
            if (minY > maxY)
            {
                minY = minY + maxY;
                maxY = minY - maxY;
                minY = minY - maxY;
            }

            c1y = Math.Abs(c1y - h) + h;
            c2y = Math.Abs(c2y - h) + h;
            c3y = Math.Abs(c3y - h) + h;

            if (c1x > minX && c1x < maxX && c1y > minY && c1y < maxY)
            {
                sum += 100;
            }
            if ((c1x == minX && c1y == minY) ||
                     (c1x == minX && c1y == maxY) ||
                     (c1x == maxX && c1y == minY) ||
                     (c1x == maxX && c1y == maxY))
            {
                sum += 25;
            }
            if ((c1x == minX && c1y > minY) && (c1x == minX && c1y < maxY)
               || (c1x == maxX && c1y > minY) && (c1x == maxX && c1y < maxY)
               || (c1y == minY && c1x > minX) && (c1y == minY && c1x < maxX)
               || (c1y == maxY && c1x > minX) && (c1y == maxY && c1x < maxX))
            {
                sum += 50;
            }


            if (c2x > minX && c2x < maxX && c2y > minY && c2y < maxY)
            {
                sum += 100;
            }
            if ((c2x == minX && c2y == minY) ||
                     (c2x == minX && c2y == maxY) ||
                     (c2x == maxX && c2y == minY) ||
                     (c2x == maxX && c2y == maxY))
            {
                sum += 25;
            }
            if ((c2x == minX && c2y > minY) && (c2x == minX && c2y < maxY)
                || (c2x == maxX && c2y > minY) && (c2x == maxX && c2y < maxY)
                || (c2y == minY && c2x > minX) && (c2y == minY && c2x < maxX)
                || (c2y == maxY && c2x > minX) && (c2y == maxY && c2x < maxX))
            {
                sum += 50;
            }

            if (c3x > minX && c3x < maxX && c3y > minY && c3y < maxY)
            {
                sum += 100;
            }
            if ((c3x == minX && c3y == minY) ||
                      (c3x == minX && c3y == maxY) ||
                      (c3x == maxX && c3y == minY) ||
                      (c3x == maxX && c3y == maxY))
            {
                sum += 25;
            }
            if ((c3x == minX && c3y > minY) && (c3x == minX && c3y < maxY)
                  || (c3x == maxX && c3y > minY) && (c3x == maxX && c3y < maxY)
                  || (c3y == minY && c3x > minX) && (c3y == minY && c3x < maxX)
                  || (c3y == maxY && c3x > minX) && (c3y == maxY && c3x < maxX))
            {
                sum += 50;
            }
            Console.WriteLine(sum + "%");
        }
    }
}
