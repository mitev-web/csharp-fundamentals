using System;

namespace Task01_ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int temp;
            int temp2;
            if (sY1 > sY2)
            {
                temp = sY1;
                sY1 = sY2;
                sY2 = temp;
               
            }
            

            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            int first = 2 * h - cY1;
            int second = 2 * h - cY2;
            int third = 2 * h - cY3;
            int score = 0;


            if ((cX1 == cX2 && cY1 == cY2) || (cX1 == cX3 && cY1 == cY3) || (cX2 == cX3 && cY2 == cY3))
            {
                //Console.WriteLine(score + "%");
                return;
            }


            if (sY1 == sY2 || sX1 == sX2)
            {
                //Console.WriteLine(score + "%");
                return;
            }
            if (h >= sY2 && h <= sY1)
            {
                //Console.WriteLine(score + "%");
                return;
            }
            

            if ((first <= sY2 && sY1 <= first) || (second <= sY2 && sY1 <= second) || (third <= sY2 && sY1 <= second))
            {
                if (((cX1 == sX1 || cX1 == sX2) && first == sY1) || (((cX1 == sX1) || cX1 == sX2) && first == sY2))
                {    
                    score = score + 25;
                }
                if (((cX2 == sX1 || cX2 == sX2) && second == sY1) || (((cX2 == sX1) || cX2 == sX2) && second == sY2))
                {
                    score = score + 25;
                }
                if (((cX3 == sX1 || cX3 == sX2) && third == sY1) || (((cX3 == sX1) || cX3 == sX2) && third == sY2))
                {
                    score = score + 25;
                }
                if (((cX1 == sX1 || cX1 == sX2) && (first < sX2 && first >sX1)) || (first == sY1 || first == sY2) && (cX1 < sX1 && cX1 > sX2))
                {
                    score = score + 50;
                }
                if (((cX2 == sX1 || cX2 == sX2) && (second < sX2 && second >sX1)) || (second == sY1 || second == sY2) && (cX2 < sX1 && cX2 > sX2))
                {
                    score = score + 50;
                }
                if (((cX3 == sX1 || cX3 == sX2) && (third < sX2 && third >sX1)) || (third == sY1 || third == sY2) && (cX3 < sX1 && cX3>  sX2))
                {
                    score = score + 50;
                }
                if (((cX1 > sX1 || cX1 < sX2) && (first > sY2 && first < sY1)) || ((first > sY1 || first < sY2) && (cX1 > sX1 && cX1 < sX2)))
                {
                    score = score + 100;
                }
                if (((cX2 > sX1 || cX2 < sX2) && (second > sY2 && second < sY1)) || ((second > sY1 || second < sY2) && (cX2 > sX1 && cX2 < sX2)))
                {
                    score = score + 100;
                }
                if (((cX3 > sX1 || cX3 < sX2) && (third > sY2 && third < sY1)) || ((third > sY1 || third < sY2) && (cX3 > sX1 && cX3 < sX2)))
                {
                    score = score + 100;
                }
            }
            Console.WriteLine(score + "%");
        }
    }
}
