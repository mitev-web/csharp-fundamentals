using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            string readN = Console.ReadLine();
            byte n = byte.Parse(readN);

            char dot = '.';
            char asterisk = '*';
            string tree = null;

            ushort startPosition = (ushort)(n - 2);
            ushort endPosition = (ushort)(n - 2);

            for (int i = 0; i < n -1; i++)
            {
                for (int j = 0; j < startPosition; j++)
                {
                    tree = tree + dot;
                }

                for (int j = startPosition; j <= endPosition; j++)
                {
                    tree = tree + asterisk;
                }

                for (int j = endPosition; j < startPosition + endPosition; j++)
                {
                    tree = tree + dot;
                }

                Console.WriteLine(tree);
                tree = null;
                startPosition--;
                endPosition++;
            }

            startPosition = (ushort)(n - 2);
            endPosition = (ushort)(n - 2);

            for (int j = 0; j < startPosition; j++)
            {
                tree = tree + dot;
            }

            for (int j = startPosition; j <= endPosition; j++)
            {
                tree = tree + asterisk;
            }

            for (int j = endPosition; j < startPosition + endPosition; j++)
            {
                tree = tree + dot;
            }

            Console.WriteLine(tree);
        }
    }
}
