using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2.Tribonacci
{
    class tribonacci
    {
        static void Main(string[] args)
        {
            int t1 = int.Parse(Console.ReadLine());
            int t2 = int.Parse(Console.ReadLine());
            int t3 = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            t1 = 0;
            t2 = 1;
            t3 = 1;
            int sum = 0;
            

            for (int i = 3; i < N; i++)
            {
                sum = t1 * (i - 1) + t2 * (i - 2) + t3 * (i - 3);
                Console.WriteLine(sum);
            }

            
            

        }
    }
}
