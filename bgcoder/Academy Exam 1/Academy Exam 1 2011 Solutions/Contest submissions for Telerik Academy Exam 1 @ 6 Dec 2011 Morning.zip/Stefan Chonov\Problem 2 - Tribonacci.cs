using System;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            string readT1 = Console.ReadLine();
            string readT2 = Console.ReadLine();
            string readT3 = Console.ReadLine();
            string readN = Console.ReadLine();

            BigInteger t1 = BigInteger.Parse(readT1);
            BigInteger t2 = BigInteger.Parse(readT2);
            BigInteger t3 = BigInteger.Parse(readT3);
            ushort n = ushort.Parse(readN);

            BigInteger tribonacciNumber = 0;

            for (ushort i = 0; i < n - 3; i++)
            {
                tribonacciNumber = t1 + t2 + t3;
                t1 = t2;
                t2 = t3;
                t3 = tribonacciNumber;
            }

            Console.Write("{0}",tribonacciNumber);
        }
    }
}
