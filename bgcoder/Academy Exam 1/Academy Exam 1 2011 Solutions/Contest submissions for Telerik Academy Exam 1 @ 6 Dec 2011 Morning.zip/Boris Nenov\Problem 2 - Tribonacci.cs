using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task2Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            long fibo1;
            long fibo2;
            long fibo3;
            ushort n;
           
            fibo1 = long.Parse(Console.ReadLine());
            fibo2 = long.Parse(Console.ReadLine());
            fibo3 = long.Parse(Console.ReadLine());
            n = ushort.Parse(Console.ReadLine());
            long nfibo = fibo1 + fibo2 + fibo3; ;
            
            for (int i = 0; i < n-4; i++)
            {
               
                fibo1 = fibo2;
                fibo2 = fibo3;
                fibo3 = nfibo;
                nfibo = fibo1 + fibo2 + fibo3;
            }
            Console.WriteLine(nfibo);
           
            
             
            
           

        }
    }
}
