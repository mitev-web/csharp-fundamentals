using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Globalization;

namespace bitwise_algorith
{
    class Program
    {
        static void Main(string[] args)
        {
        sbyte n = sbyte.Parse(Console.ReadLine());

            int b = n;
            Console.WriteLine(Convert.ToString(n, 2).PadLeft(4));
            n = (sbyte)~n;
            int p;
            int mask = ~(1 << 15);      
            int result = n & mask;      
             mask = ~(1 << 14);       
             result = n & mask;    
             p = 13;
             mask = ~(1 << 12);       
             result = n & mask;     
             p = 12;
             mask = ~(0 << 11);       
             result = n & mask;
             p = 11;
             mask = ~(1 << 10);       
             result = n & mask;
         
             mask = ~(1 << 5);      
             result = n & mask;
             p = 0;
             mask = ~(1 << p);       
             result = n & mask;

        

            Console.WriteLine(Convert.ToString(result, 2).PadLeft(4,'0'));

            


            Console.WriteLine("{0}",n);





            
            

        }
    }
}
