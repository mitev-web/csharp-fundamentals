using System;
using System.Numerics;

namespace _02.Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger T1 = BigInteger.Parse(Console.ReadLine());
            BigInteger T2 = BigInteger.Parse(Console.ReadLine());
            BigInteger T3 = BigInteger.Parse(Console.ReadLine());
            short N = short.Parse(Console.ReadLine());
            BigInteger Tn = 0;

            if (N == 1)
            {
                Tn = T1;
            }
            if (N == 2)
            {
                Tn = T2;
            }
            if (N == 3)
            {
                Tn = T3;
            }
            else
            {
                for (int i = 3; i < N; i++)
                {
                    Tn = T1 + T2 + T3;
                    if (i % 3 == 0)
                    {
                        T1 = Tn;
                    }
                    else if (i % 3 == 1)
                    {
                        T2 = Tn;
                    }
                    else if (i % 3 == 2)
                    {
                        T3 = Tn;
                    }
                }
            }

            Console.WriteLine(Tn);
        }
    }
}
