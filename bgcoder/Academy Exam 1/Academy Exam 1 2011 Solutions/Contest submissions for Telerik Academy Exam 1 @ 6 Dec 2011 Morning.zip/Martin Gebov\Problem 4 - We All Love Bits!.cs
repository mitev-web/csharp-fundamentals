using System;

class WeAllLoveBits
{
    static void Main(string[] args)
    {
        int n;
        int p;
        int pInv;
        int pRev;
        int pNew;
        double sum = 0;
        bool bit;
        bool bit2;
        bool flag = true;
        int bitCounter = 0;
        int temp;
        n = int.Parse(Console.ReadLine());
        int[] numbers = new int[n];
        for (int j = 0; j < n; j++)
        {
            numbers[j] = int.Parse(Console.ReadLine());
        }

        for (int j = 0; j < n; j++)
        {
            sum = 0;
            flag = true;
            bitCounter = 0;
            p = numbers[j];
            pInv = p;
            pRev = p;
            temp = p;
            do
            {
                bitCounter++;
                temp = temp / 2;

            } while (temp >= 1);


            if (bitCounter == 31)
            {
                for (int i = 0; i <= bitCounter; i++)
                {
                    pInv ^= (1 << i);
                }
            }
            else
            {
                for (int i = 0; i < bitCounter; i++)
                {
                    pInv ^= (1 << i);
                }
            }


            for (int i = 0; i < bitCounter / 2; i++)
            {
                bit = (p & (1 << i)) != 0;

                bit2 = (p & (1 << bitCounter - i - 1)) != 0;

                if (bit != bit2)
                {
                    pRev ^= (1 << i);
                    pRev ^= (1 << bitCounter - i - 1);
                }
            }
            pNew = (p ^ pInv) & pRev;

            Console.WriteLine(pNew);
        }



    }
}
