using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam
{
    class FirThree
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            short width = 1;
            byte row = 0;
            for (int i = 0; i < n - 2; i++)
            {
                width += 2;
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= width; j++)
                {
                    if (j == ((width / 2) - row) )
                    {
                        if (row == 0)
                        {
                            Console.Write("*");
                            j++;
                        }
                        else
                        {
                            for (int k = 0; k < row * 2 + 1; k++)
                            {
                                Console.Write("*");
                                j++;
                            }
                        }
                        row++;
                    }
                    else
                    {
                        if (i==n-1 && j==width/2)
                        {
                            Console.Write("*");
                            j++;
                            j++;
                        }
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
