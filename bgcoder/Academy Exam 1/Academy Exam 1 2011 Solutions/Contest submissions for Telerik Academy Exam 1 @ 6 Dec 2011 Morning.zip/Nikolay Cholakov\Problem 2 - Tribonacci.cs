using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _2.TribonacciSequence
{
    class TribonacciSequence
    {
        static void Main(string[] args)
        {
            int choise = int.Parse(Console.ReadLine());

            BigInteger memberOne = BigInteger.Parse(Console.ReadLine());
            BigInteger memberTwo = BigInteger.Parse(Console.ReadLine());
            BigInteger memberThree = BigInteger.Parse(Console.ReadLine());

            BigInteger temp = 0;

            for (int i = 0; i <= (choise - 4); i++)
            {
                BigInteger nextMember = memberOne + memberTwo + memberThree;
                temp = nextMember;
                memberOne = memberTwo;
                memberTwo = memberThree;
                memberThree = temp;
            }
        }
    }
}
