using System;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace TribonacciSequence
{
    class Program
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            BigInteger firstNumber =  long.Parse(Console.ReadLine());
            BigInteger secondNumber = long.Parse(Console.ReadLine());
            BigInteger thirdNumber = long.Parse(Console.ReadLine());
            long n = long.Parse(Console.ReadLine());

            BigInteger result = 0;

            if (n == 1)
            {
                result = firstNumber;
            }
            else if (n == 2)
            {
                result = secondNumber;
            }
            else if (n == 3)
            {
                result = thirdNumber;
            }
            else
            {
                for (int i = 4; i <= n; i++)
                {
                    result = (firstNumber + secondNumber + thirdNumber);
                    firstNumber = secondNumber;
                    secondNumber = thirdNumber;
                    thirdNumber = result;
                }
            }
            
            Console.WriteLine(result);
        }
    }
}