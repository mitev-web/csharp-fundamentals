
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _2.Tribonaccii
{
    class Tribonaci
    {
        static void Main(string[] args)
        {

            string value1 = Console.ReadLine();
            BigInteger tribValue1 = BigInteger.Parse(value1);
            string value2 = Console.ReadLine();
            BigInteger tribValue2 = BigInteger.Parse(value2);
            string value3 = Console.ReadLine();
            BigInteger tribValue3 = BigInteger.Parse(value3);
            string n = Console.ReadLine();
            int N = int.Parse(n);

            BigInteger tribonacci1 = tribValue1;
            BigInteger tribonacci2 = tribValue2;
            BigInteger tribonacci3 = tribValue3;

            if (tribValue1 >= -2000000000 & tribValue1 <= 2000000000 & tribValue2 >= -2000000000 & tribValue2 <= 2000000000 & tribValue3 >= -2000000000 & tribValue3 <= 2000000000 & N>=1 & N<=15000)
            {
                for (int i = 1; i <= N-3; i++)
                {
                    BigInteger tempTribonacci3 = tribonacci3;
                    tribonacci3 += (tribonacci1 + tribonacci2);
                    tribonacci1 = tribonacci2;
                    tribonacci2 = tempTribonacci3;
                }
                Console.WriteLine(tribonacci3);
            }
   

        }
    }
}
