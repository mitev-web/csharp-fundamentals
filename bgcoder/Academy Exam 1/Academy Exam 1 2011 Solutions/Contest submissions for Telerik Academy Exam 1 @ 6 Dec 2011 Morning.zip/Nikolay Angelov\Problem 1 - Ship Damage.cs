using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            int percent = 0;
            /*** Rectangle ***/
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());

            int h = int.Parse(Console.ReadLine());
            int sy3 = sy1 + h;
            int sy4 = sy2 + h;
            /*** End Rectangle ***/

            int c1x = int.Parse(Console.ReadLine());
            int c1y = int.Parse(Console.ReadLine());
            int c2x = int.Parse(Console.ReadLine());
            int c2y = int.Parse(Console.ReadLine());
            int c3x = int.Parse(Console.ReadLine());
            int c3y = int.Parse(Console.ReadLine());

            if ((((-1) * c1y) > sy1 && ((-1) * c1y) < sy2) &&  c1x == sx1 || c1x == sx2 )   // point c1
            {
                percent += 25;
            }
            if ((((-1) * c2y) > sy1 && ((-1) * c2y) < sy2) && c2x == sx1 || c2x == sx2)   // point c2
            {
                percent += 25;
            }
            if ((((-1) * c3y) > sy1 && ((-1) * c3y) < sy2) && c3x == sx1 || c3x == sx2)   // point c3
            {
                percent += 25;
            }

            if ((c1x > sx1 && c1x < sx2) && ((-1) * c1y) > sy3 && ((-1) * c1y) < sy4 ) // point c1 - up
            {
                percent += 100;
            }
            if ((c2x > sx1 && c2x < sx2) && ((-1) * c2y) > sy3 && ((-1) * c2y) < sy4) // point c2 - up
            {
                percent += 100;
            }
            if ((c3x > sx1 && c3x < sx2) && ((-1) * c3y) > sy3 && ((-1) * c3y) < sy4) // point c3 - up
            {
                percent += 100;
            }

            if ((c1x > sx1 && c1x < sx2) && ((-1) * c1y) > sy1 && ((-1) * c1y) < sy2) // point c1 - down
            {
                percent += 100;
            }
            if ((c2x > sx1 && c2x < sx2) && ((-1) * c2y) > sy1 && ((-1) * c2y) < sy2) // point c2 - down
            {
                percent += 100;
            }
            if ((c3x > sx1 && c3x < sx2) && ((-1) * c3y) > sy1 && ((-1) * c3y) < sy2) // point c3 - down
            {
                percent += 100;
            }
            if(sy1 != sy2 && c1x < c1y)
            {
                percent += 100;
            }
            Console.WriteLine(percent + "%");
        }
    }
}
