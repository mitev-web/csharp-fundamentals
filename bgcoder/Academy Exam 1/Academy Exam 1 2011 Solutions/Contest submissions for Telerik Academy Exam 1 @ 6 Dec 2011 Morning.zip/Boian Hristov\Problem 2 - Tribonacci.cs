using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Tribonacci
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int x, y, z,d;
        int c = 0;
        int a = 0;
        int b = 1;

        while (c != 100)
        {
            c = c + 1;
            Console.WriteLine(a);
            d = a + b;
            a = b;
            b = d;
        }
    }
}
