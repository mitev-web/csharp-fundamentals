using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            line = Console.ReadLine();
            long t1 = long.Parse(line);
            line = Console.ReadLine();
            long t2 = long.Parse(line);
            line = Console.ReadLine();
            long t3 = long.Parse(line);
            line=Console.ReadLine();
            uint n = uint.Parse(line);
            long[] trib = new long[n+3];
           

            trib[0] = t1;
            trib[1] = t2;
            trib[2] = t3;
            for (int i = 3; i < n; i++)
            {
                trib[i] = trib[i - 1] + trib[i - 2] + trib[i - 3];
                
            }
            Console.WriteLine(trib[n-1]);
        }
    }
}
