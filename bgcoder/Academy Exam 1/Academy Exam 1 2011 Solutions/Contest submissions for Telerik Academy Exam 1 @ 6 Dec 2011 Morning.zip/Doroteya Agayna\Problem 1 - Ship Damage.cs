using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FundamentalsExam1
{
    class Program
    {
        static void Main(string[] args)
        {
            int shipX1, shipY1, shipX2, shipY2;
            int h;
            int[,] cannon = new int[3, 2];
            bool inner = false, onHeight = false, onWidth = false;
            bool corner1 = false, corner2 = false, corner3 = false, corner4 = false;
            int result = 0;
            
            //Input
            shipX1 = int.Parse(Console.ReadLine());
            shipY1 = int.Parse(Console.ReadLine());
            shipX2 = int.Parse(Console.ReadLine());
            shipY2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cannon[0, 0] = int.Parse(Console.ReadLine());
            cannon[0, 1] = (2 * h) - int.Parse(Console.ReadLine());
            cannon[1, 0] = int.Parse(Console.ReadLine());
            cannon[1, 1] = (2 * h) - int.Parse(Console.ReadLine());
            cannon[2, 0] = int.Parse(Console.ReadLine());
            cannon[2, 1] = (2 * h) - int.Parse(Console.ReadLine());
            
            //Processing
            //To be really easy I make sure I always have upper left corner and lower right corner
            if (shipX1 > shipX2)
            {
                h = shipX1;
                shipX1 = shipX2;
                shipX2 = h;
            }
            if (shipY1 < shipY2)
            {
                h = shipY1;
                shipY1 = shipY2;
                shipY2 = h;
            }
            for (h = 0; h < 3; h++)
            {
                inner = (cannon[h, 0] > shipX1 && cannon[h, 0] < shipX2) && (cannon[h, 1] < shipY1 && cannon[h, 1] > shipY2);
                onHeight = ((cannon[h, 0] == shipX1 || cannon[h, 0] == shipX2) && ((cannon[h, 1] < shipY1 && cannon[h, 1] > shipY2)));
                onWidth = ((cannon[h, 0] > shipX1 && cannon[h, 0] < shipX2) && ((cannon[h, 1] == shipY1 || cannon[h, 1] == shipY2)));
                corner1 = (cannon[h, 0] == shipX1 && cannon[h, 1] == shipY1);
                corner2 = (cannon[h, 0] == shipX1 && cannon[h, 1] == shipY2);
                corner3 = (cannon[h, 0] == shipX2 && cannon[h, 1] == shipY1);
                corner4 = (cannon[h, 0] == shipX2 && cannon[h, 1] == shipY2);
                if (inner)
                {
                    result = result + 100;
                }
                else if (onHeight || onWidth)
                {
                    result = result + 50;
                }
                else if (corner1 || corner2 || corner3 || corner4)
                {
                    result = result + 25;
                }
            }
            Console.WriteLine(result + "%");
        }
    }
}
