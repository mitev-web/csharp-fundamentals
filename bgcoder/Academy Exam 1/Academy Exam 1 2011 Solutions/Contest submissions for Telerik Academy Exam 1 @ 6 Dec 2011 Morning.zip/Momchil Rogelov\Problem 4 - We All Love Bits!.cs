using System;

namespace BitsBits
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                int n = int.Parse(Console.ReadLine());
                for (int i = 0; i < n; i++)
                {
                    uint p = uint.Parse(Console.ReadLine());
                    Console.WriteLine(pnew(p));
                }
            }
        }

        static uint pnew(uint p)
        {
            return (p ^ Pnina(p)) & Pdots(p);
        }

        static uint Pdots(uint myInt)
        {
            int lastSet = lastSetBit(myInt);
            int iterations = (lastSet+1) / 2;
            for (int i = 0; i < iterations; i++)
            {
                int proxy;
                int pos1 = i;
                int pos2 = lastSet-i;

                proxy = getBit(myInt, pos1);
                myInt = setBit(myInt, pos1, getBit(myInt, pos2));
                myInt = setBit(myInt, pos2, proxy);
                
            }

            return myInt;
        }

        static uint Pnina(uint myInt)
        {
            int lastSet = lastSetBit(myInt);
            for (int i = 0; i <= lastSet; i++)
            {
                if (getBit(myInt, i) == 1)
                {
                    myInt = setBit(myInt,i,0);
                }
                else 
                {
                    myInt = setBit(myInt, i, 1);
                }
            }
            return myInt;
        }
        static void showAllBits(uint shw)
        {
            for (int i = 0; i < 32; i++)
            {
                Console.WriteLine(getBit(shw, i));
            }
        }
        static int lastSetBit(uint myInt)
        {
            int last= -1;
            for (int i = 0; i < 32; i++)
			{
                if (getBit(myInt, i) == 1)
                {
                    last = i;
                }
			}
            return last;
        }

        static int getBit(uint myInt, int pos) 
        {
            uint mask = 1;
            myInt = myInt >> pos;
            return  (int)(myInt & mask);
        }

        static uint setBit(uint myInt, int x, int value)
        {
            if (value == 1)
            {
                myInt |= (uint)1 << x;
            }
            else 
            {
                myInt &= ~((uint)1 << x);

            }
            return myInt;
        }
    }
}
