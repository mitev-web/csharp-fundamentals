using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bits
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort N = ushort.Parse(Console.ReadLine());
            uint p1;
            uint p2;
            uint sum = 0;
            for (int i = 1; i <= N; i++)
            {
                uint p = uint.Parse(Console.ReadLine());
                while(p!=0)
                {
                    p1 = (uint)~p;
                    p2 = RotateByte(p);
                    sum = (p ^ p1) & p2; 
                 }   
                Console.WriteLine(sum);
            }
        }
        static uint RotateByte(uint B)
        {
            const int byteLength = 4;
 
            uint value = (uint)B;
            uint mask = 1 << byteLength - 1;
            uint extract = 0;
            uint rotated = 0;
            uint result = 0;
            for (int i = 0; i < byteLength; i++)
            {
                extract = value & mask;
                mask = mask >> 1;
                rotated = extract << 2 * i + 1; 
                result += rotated;
                rotated = 0;
            }
            result >>= byteLength;
            return (uint)result;
        }
    }
}