using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prob1_ShipDamage
{
    class ShipDamage
    {
        struct Point
        {
            public int X;
            public int Y;

            public Point(int x, int y)
            {
                X = x;
                Y = y;
            }

        }

        static void Main(string[] args)
        {
            // ship coordinates
            Point[] s = new Point[2];
            string input;
            for (int i = 0; i < 2; i++)
            {
                input = Console.ReadLine();
                s[i].X = int.Parse(input);
                input = Console.ReadLine();
                s[i].Y = int.Parse(input);
            }
       
            // line H (horizont
            input = Console.ReadLine();
            int h = int.Parse(input);

            // Catapults' coordinates
            Point[] c = new Point[3];
            for (int i = 0; i < 3; i++)
            {
                input = Console.ReadLine();
                c[i].X = int.Parse(input);
                input = Console.ReadLine();
                c[i].Y = int.Parse(input);
            }

            // makes horizont to zero (h = 0)
            for (int i = 0; i < 2; i++)
            {
                s[i].Y -= h;
            }
            for (int i = 0; i < 3; i++)
			{
                c[i].Y -= h;
			}

            int dmg = 0;
            byte left = (byte)(s[0].X < s[1].X ? 0 : 1);
            byte right = (byte)(s[0].X > s[1].X ? 0 : 1);
            byte up = (byte)(s[0].Y > s[1].Y ? 0 : 1);
            byte down = (byte)(s[0].Y < s[1].Y ? 0 : 1);
            
            for (int i = 0; i < 3; i++)
            {
                if ((c[i].X == s[0].X || c[i].X == s[1].X) &&
                    (c[i].Y == -s[0].Y || c[i].Y == -s[1].Y))
                {
                    dmg += 25;
                }
                else if (((c[i].X == s[0].X || c[i].X == s[1].X) &&
                    -c[i].Y > s[down].Y && -c[i].Y < s[up].Y) ||
                    ((c[i].Y == -s[0].Y || c[i].Y == -s[1].Y) &&
                    c[i].X > s[left].X && c[i].X < s[right].X))
                {
                    dmg += 50;
                }
                else if (c[i].X > s[left].X && c[i].X < s[right].X &&
                    -c[i].Y > s[down].Y && -c[i].Y < s[up].Y)
                {
                    dmg += 100;
                }
            }

            Console.WriteLine("{0}%", dmg);

        }
    }
}
