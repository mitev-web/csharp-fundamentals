using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            

            
            uint n = uint.Parse(Console.ReadLine());
            //int count = 1;
            for (uint row = 1; row <= n - 1; row++)
            {
                for (uint col = n - 1; col >= 1; col--)
                {
                    if (col <= row)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                    //count++;
                }
                for (uint col = 1; col <= n - 2; col++)
                {
                    if (row == 1)
                    {
                        Console.Write(".");
                    }
                    else if (col < row)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine("");
            }
            for (int i = 1; i <= 1; i++)
            {
                for (uint col = 1; col <= 2 * n - 3; col++)
                {
                    if (col == n - 1)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine("");
            }
        }
    }
}