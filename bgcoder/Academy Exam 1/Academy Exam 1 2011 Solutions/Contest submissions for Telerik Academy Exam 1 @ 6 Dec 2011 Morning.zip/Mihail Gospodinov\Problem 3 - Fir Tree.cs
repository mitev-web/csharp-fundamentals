using System;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N = byte.Parse(Console.ReadLine());

            for (int i = 0; i < N-1; i++)
            {
                int counter = N - 2 - i;
                for (int j = 0; j < counter; j++)
                {
                    Console.Write(".");
                }
                for (int j = 0; j < 1 + i * 2; j++)
                {
                    Console.Write("*");
                }
                for (int j = 0; j < counter; j++)
                {
                    Console.Write(".");
                }
                Console.WriteLine();
            }

            int count = N - 2;
            for (int j = 0; j < count; j++)
            {
                Console.Write(".");
            }
            Console.Write("*");
            for (int j = 0; j < count; j++)
            {
                Console.Write(".");
            }

        }
    }
}