using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
//first line
            int width = (n * 2) - 3;
            int mid = (width / 2) + 1;

//middle lines
            for (int i = 1; i <= (n - 1); i++)
            {
                for (int j = 1; j <= mid; j++)
                {
                    if (j <= (mid - i))
                    {
                        Console.Write(".");
                    }
                    else { Console.Write("*"); }
                }
                
                for (int j1 = 1; j1 < mid; j1++)
                {
                    if (j1 <= (i - 1))
                    {
                        Console.Write("*");
                    }
                    else { Console.Write("."); }
                }
                
            
                Console.WriteLine();
            }
            

//last line
            for (int i = 1; i < mid; i++)
            {
                Console.Write(".");
            }
            Console.Write("*");
            for (int i = 1; i < mid; i++)
            {
                Console.Write(".");
            }
            Console.WriteLine();
        }
    }
}