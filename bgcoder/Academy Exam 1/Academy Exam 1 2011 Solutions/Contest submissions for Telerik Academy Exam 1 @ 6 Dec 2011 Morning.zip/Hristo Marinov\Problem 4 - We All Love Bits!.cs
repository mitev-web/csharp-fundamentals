using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            int n,pnew,p,tilp,revp,br;
            n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                p = int.Parse(Console.ReadLine());
                int temp = p;
                revp=0;
                br=0;
                while (temp > 0)
                {
                    temp /= 2;
                    br++;
                }
                temp = p;
                br--;
                while (temp > 0)
                {
                    if (temp % 2 == 1)
                        revp += (int)Math.Pow(2, br);
                    temp /= 2;
                    br--;
                }
                br = 0;
                temp = p;
                    tilp=0;
                while (temp > 0)
                {
                    if (temp % 2 == 0)
                        tilp += (int)Math.Pow(2, br);
                    temp /= 2;
                    br++;
                }
                pnew = p ^ tilp;
                pnew = pnew & revp;
               // Console.WriteLine(tilp);
               // Console.WriteLine(revp);
                Console.WriteLine(pnew);
            }
        }
    }
}
