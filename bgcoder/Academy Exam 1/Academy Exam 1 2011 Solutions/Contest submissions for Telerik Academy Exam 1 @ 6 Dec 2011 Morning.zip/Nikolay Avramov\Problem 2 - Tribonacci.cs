using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Problem5
{
    static void Main(string[] args)
    {

        double a = double.Parse(Console.ReadLine());
        double b = double.Parse(Console.ReadLine());
        double c = double.Parse(Console.ReadLine());
        double n =double.Parse(Console.ReadLine());
        double d = 0;
        int i;
        double grater = 0;
        if (n == 1)
        {
            grater = a;
        }else if(n == 2)
        {
            grater=b;
        }
        else if (n == 3)
        {
            grater = c;
        }
        else
        {
            for (i = 4; i <= n; i++)
            {
                d = a + b + c;
                grater = d;
                a = b;
                b = c;
                c = d;
            }
        }
      Console.WriteLine(grater);
    }
}
