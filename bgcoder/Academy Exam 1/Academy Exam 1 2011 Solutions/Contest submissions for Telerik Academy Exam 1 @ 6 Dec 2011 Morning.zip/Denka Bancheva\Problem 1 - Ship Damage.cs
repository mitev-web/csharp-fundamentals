using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1.shipDamage
{
    class shipDamage
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int Hline = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            int sum;
            int innership= 100;
            int corners = 25;

            if (Cy2 == 25 && Cy1 == 25 && Cy3 == 25)
            {
                Console.WriteLine(corners);

            }
            if (Cx1 == 25 && Cx2 == 25 && Cx3 == 25)
            {
                Console.WriteLine(corners);
            }
            if (Sx1 == 100 && Sx2 == 100)
            {
                Console.WriteLine(innership);
            }
            if (Sy1 == 100 && Sy1 == 100)
            {
                Console.WriteLine(innership);
            }
            sum = innership + corners;
        }
    }
}
