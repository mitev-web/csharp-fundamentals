using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskTrib
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());
            int result;
            for (int i = 0; i < (n -3); i++)
            {
                result = a + b + c;

                a = b;
                b = c;
                c = result;
            }
            Console.WriteLine(c);
           
            
        }
    }
}
