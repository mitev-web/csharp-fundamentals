using System;
namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Int16.Parse(Console.ReadLine());
            int width = 1 + (n - 2) * 2;
            int aster = 1;
            int dots = width / 2;

            while (aster <= width)
            { 
                for (int i = 0; i < dots; i++)
			    {
                    Console.Write(".");
			    }

                for (int i = 0; i < aster; i++)
                {
                    Console.Write("*");
                }

                for (int i = 0; i < dots; i++)
                {
                    Console.Write(".");
                }

                Console.WriteLine();
                aster += 2;
                dots--;
            }

            aster = 1;
            dots = width / 2;

            for (int i = 0; i < dots; i++)
            {
                Console.Write(".");
            }

            for (int i = 0; i < aster; i++)
            {
                Console.Write("*");
            }

            for (int i = 0; i < dots; i++)
            {
                Console.Write(".");
            }


        }
    }
}
