using System;
using System.Collections.Generic;
using System.Threading;
using System.Text;
using System.Globalization;
 
 
namespace Task1
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            //ships
            int shipX1 = int.Parse(Console.ReadLine());
            int shipY1 = int.Parse(Console.ReadLine());
            int shipX2 = int.Parse(Console.ReadLine());
            int shipY2 = int.Parse(Console.ReadLine());
 
            // H
            int horizLine = int.Parse(Console.ReadLine());
 
            // catapults
            int catpX1 = int.Parse(Console.ReadLine());
            int catpY1 = int.Parse(Console.ReadLine());
             
            int catpX2 = int.Parse(Console.ReadLine());
            int catpY2 = int.Parse(Console.ReadLine());
            int catpX3 = int.Parse(Console.ReadLine());
            int catpY3 = int.Parse(Console.ReadLine());
 
            //int a = Math.Abs(-3);
            //Console.WriteLine(a);
            double hit = 0;
 
            //if (shipX1 > shipX2 )
            //{
            //    int changeVal = shipX2;
            //    shipX2 = shipX1;
            //    shipX1 = changeVal;
            //}
            //if (shipY1 > shipY2)
            //{
            //    int changeVal = shipY2;
            //    shipY2 = shipY1;
            //    shipY1 = changeVal;
            //}
 
            // symmetrical catapults
            int symmCatpX1 = catpX1;
            int symmCatpY1 = (catpY1 * (-1)) + 2 * horizLine;
 
            int symmCatpX2 = catpX2;
            int symmCatpY2 = (catpY2 * (-1)) + 2 * horizLine;
 
            int symmCatpX3 = catpX3;
            int symmCatpY3 = (catpY3 * (-1)) + 2 * horizLine;
 
            if (((symmCatpX1 >= shipX1) && (symmCatpX1 <= shipX2)) || ((symmCatpY1 >= shipY1) && (symmCatpY1 <= shipY2)))
            {
                if ((symmCatpX1 == shipX1 && symmCatpY1 == shipY1) || (symmCatpX1 == shipX2 && symmCatpY1 == shipY2))
                {
                    hit = hit + 0.25;
                }
                else if ((symmCatpX1 == shipX1) || (symmCatpY1 == shipY1) || (symmCatpX1 == shipX2) || (symmCatpY1 == shipY2))
                {
                    hit = hit + 0.50;
                }
                else
                {
                    hit = hit + 1;
                }
            }
            //Console.WriteLine(hit);
            if (((symmCatpX2 >= shipX1) && (symmCatpX2 <= shipX2)) || ((symmCatpY2 >= shipY1) && (symmCatpY2 <= shipY2)))
            {
                if ((symmCatpX2 == shipX1 && symmCatpY2 == shipY1) || (symmCatpX2 == shipX2 && symmCatpY2 == shipY2))
                {
                    hit = hit + 0.25;
                }
                else if ((symmCatpX2 == shipX1) || (symmCatpY2 == shipY1) || (symmCatpX2 == shipX2) || (symmCatpY2 == shipY2))
                {
                    hit = hit + 0.50;
                }
                else
                {
                    hit = hit + 1;
                }
            }
            //Console.WriteLine(hit);
            if (((symmCatpX3 >= shipX1) && (symmCatpX3 <= shipX2)) || ((symmCatpY3 >= shipY1) && (symmCatpY3 <= shipY2)))
            {
                if ((symmCatpX3 == shipX1 && symmCatpY3 == shipY1) || (symmCatpX3 == shipX2 && symmCatpY3 == shipY2))
                {
                    hit = hit + 0.25;
                }
                else if ((symmCatpX3 == shipX1) || (symmCatpY3 == shipY1) || (symmCatpX3 == shipX2) || (symmCatpY3 == shipY2))
                {
                    hit = hit + 0.50;
                }
                else
                {
                    hit = hit + 1;
                }
            }
            //Console.WriteLine(hit);
            //double hit = 0.25;
            //Console.WriteLine("{0:###%}", hit);
            Console.WriteLine("{0:###%}", hit);
        }
    }
}