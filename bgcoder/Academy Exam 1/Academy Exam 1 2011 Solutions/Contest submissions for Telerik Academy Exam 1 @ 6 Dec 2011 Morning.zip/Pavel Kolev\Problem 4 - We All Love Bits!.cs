using System;
using System.Threading;
using System.Globalization;

namespace We_all_love_bits
{
    class Program
    {
        static void Main(string[] args)
        {

            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-us");
            int n = int.Parse(Console.ReadLine());
            int[] mas = new int[n];
            for (int i = 0; i < n; i++)
            {
                mas[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                int h = ~mas[i];
                int rev = IntReverse(mas[i]);
                int xored = mas[i] ^ h;
                mas[i] = xored & rev;
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine((int)mas[i]);
            }
        }
        public static int IntReverse(int n)
        {
            int result = 0;
            byte flag = 0;
            int rev=0;
            for (int bitPos = 31; bitPos >= 0; bitPos--)
            {
                int mask = 1 << bitPos;
                int nAndMask = n & mask;
                bool bit = ((nAndMask >> bitPos) == 1) ? true : false;
                if (bit)
                {
                    mask = 1 << rev;
                    result |= mask;
                    flag++;
                }
                if (flag != 0)
                {
                    rev++;
                }
            }
            return result;
        }
    }
}
