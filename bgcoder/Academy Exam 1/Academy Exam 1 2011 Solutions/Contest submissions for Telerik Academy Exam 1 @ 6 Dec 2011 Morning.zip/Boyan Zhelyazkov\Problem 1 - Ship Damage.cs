using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace ShioDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1, Sy1, Sx2, Sy2, H, desti;
            int[,] Ci = new int[3, 2];
 
            int smallerShipY, smallerShipX, biggerShipY, biggerShipX, damage = 0;
            Sx1 = ReadInput();
            Sy1 = ReadInput();
            Sx2 = ReadInput();
            Sy2 = ReadInput();
            H = ReadInput();
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Ci[i, j] = ReadInput();
                }
            }
 
            smallerShipX = Math.Min(Sx1, Sx2);
            smallerShipY = Math.Min(Sy1, Sy2);
 
            biggerShipX = Math.Max(Sx1, Sx2);
            biggerShipY = Math.Max(Sy1, Sy2);
            for (int i = 0; i < 3; i++)
            {
                desti = Math.Abs(Ci[i, 1] - H);
                 
                if (H <= smallerShipY)
                {
                    Ci[i, 1] = H + desti;
                }
                else
                {
                    Ci[i, 1] = H - desti;
                }
 
                if ((smallerShipY < Ci[i, 1] && Ci[i, 1] < biggerShipY) && (smallerShipX < Ci[i, 0] && Ci[i, 0] < biggerShipX))
                {
                    damage = damage + 100;
                }
                else if (((smallerShipY == Ci[i, 1] || Ci[i, 1] == biggerShipY) && (smallerShipX < Ci[i, 0] && Ci[i, 0] < biggerShipX)))
                {
                    damage = damage + 50;
                }
                else if ((smallerShipY < Ci[i, 1] && Ci[i, 1] < biggerShipY) && (smallerShipX == Ci[i, 0] || Ci[i, 0] == biggerShipX))
                {
                    damage = damage + 50;
                }
                else if ((smallerShipY == Ci[i, 1] || Ci[i, 1] == biggerShipY) && (smallerShipX == Ci[i, 0] || Ci[i, 0] == biggerShipX))
                {
                    damage = damage + 25;
                }
            }
            Console.WriteLine(damage + "%");
        }
 
        private static int ReadInput()
        {
            return int.Parse(Console.ReadLine());
        }
    }
}