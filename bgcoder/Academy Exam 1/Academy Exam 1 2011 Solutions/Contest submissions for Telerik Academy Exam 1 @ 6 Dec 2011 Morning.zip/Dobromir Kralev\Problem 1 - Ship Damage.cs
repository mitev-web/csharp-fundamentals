using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ship_Damage
{
    class Program
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int hallDamage=0;
            int biggerSX = Math.Max(sX1, sX2),
                smallerSX = Math.Min(sX1, sX2);
            int biggerSY = Math.Max(sY1, sY2),
                smallerSY = Math.Min(sY1, sY2);
                int cX = int.Parse(Console.ReadLine());
                int cY = int.Parse(Console.ReadLine());
                if ((cX > smallerSX) && (cX < biggerSX))
                {
                    if (((cY + 2 * Math.Abs(H - cY)) < biggerSY) && ((cY + 2 * Math.Abs(H - cY)) > smallerSY))
                    {
                        hallDamage += 100;
                    }
                    if (((cY + 2 * Math.Abs(H - cY)) == biggerSY) || ((cY + 2 * Math.Abs(H - cY)) == smallerSY))
                    {
                        hallDamage += 50;
                    }
                }
                if ((cX == smallerSX) || (cX == biggerSX))
                {
                    if (((cY + 2 * Math.Abs(H - cY)) < biggerSY) && ((cY + 2 * Math.Abs(H - cY)) > smallerSY))
                    {
                        hallDamage += 50;
                    }
                    if (((cY + 2 * Math.Abs(H - cY)) == biggerSY) || ((cY + 2 * Math.Abs(H - cY)) == smallerSY))
                    {
                        hallDamage += 25;
                    }
                }


                cX = int.Parse(Console.ReadLine());
                cY = int.Parse(Console.ReadLine());
                if ((cX > smallerSX) && (cX < biggerSX))
                {
                    if (((cY + 2 * Math.Abs(H - cY)) < biggerSY) && ((cY + 2 * Math.Abs(H - cY)) > smallerSY))
                    {
                        hallDamage += 100;
                    }
                    if (((cY + 2 * Math.Abs(H - cY)) == biggerSY) || ((cY + 2 * Math.Abs(H - cY)) == smallerSY))
                    {
                        hallDamage += 50;
                    }
                }
                if ((cX == smallerSX) || (cX == biggerSX))
                {
                    if (((cY + 2 * Math.Abs(H - cY)) < biggerSY) && ((cY + 2 * Math.Abs(H - cY)) > smallerSY))
                    {
                        hallDamage += 50;
                    }
                    if (((cY + 2 * Math.Abs(H - cY)) == biggerSY) || ((cY + 2 * Math.Abs(H - cY)) == smallerSY))
                    {
                        hallDamage += 25;
                    }
                }
                cX = int.Parse(Console.ReadLine());
                cY = int.Parse(Console.ReadLine());
                if ((cX > smallerSX) && (cX < biggerSX))
                {
                    if (((cY + 2 * Math.Abs(H - cY)) < biggerSY) && ((cY + 2 * Math.Abs(H - cY)) > smallerSY))
                    {
                        hallDamage += 100;
                    }
                    if (((cY + 2 * Math.Abs(H - cY)) == biggerSY) || ((cY + 2 * Math.Abs(H - cY)) == smallerSY))
                    {
                        hallDamage += 50;
                    }
                }
                if ((cX == smallerSX) || (cX == biggerSX))
                {
                    if (((cY + 2 * Math.Abs(H - cY)) < biggerSY) && ((cY + 2 * Math.Abs(H - cY)) > smallerSY))
                    {
                        hallDamage += 50;
                    }
                    if (((cY + 2 * Math.Abs(H - cY)) == biggerSY) || ((cY + 2 * Math.Abs(H - cY)) == smallerSY))
                    {
                        hallDamage += 25;
                    }
                }
            Console.WriteLine("{0}%",hallDamage);
        }
    }
}
