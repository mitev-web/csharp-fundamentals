using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1 = int.Parse(Console.ReadLine());
            BigInteger t2 = int.Parse(Console.ReadLine());
            BigInteger t3 = int.Parse(Console.ReadLine());
            short n = short.Parse(Console.ReadLine());
            short counter = 3;
            while (true)
            {
                t1 += t2 + t3;
                counter++;
                if (counter == n)
                {
                    Console.WriteLine(t1);
                    break;
                }
                t2 += t1 + t3;
                counter++;
                if (counter == n)
                {
                    Console.WriteLine(t2);
                    break;
                }
                t3 += t1 + t2;
                counter++;
                if (counter == n)
                {
                    Console.WriteLine(t3);
                    break;
                }
            } 
        }
    }
}