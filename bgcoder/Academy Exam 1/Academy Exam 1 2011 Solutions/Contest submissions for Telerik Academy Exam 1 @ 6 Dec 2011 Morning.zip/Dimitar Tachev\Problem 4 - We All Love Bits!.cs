using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam
{
    class WeAllLoveBits
    {
        /// <summary>
        /// Returns you the value of the bit you want. (from integer)
        /// </summary>
        /// <param name="number">Integer from which you want to take a bit</param>
        /// <param name="bitNumber">The posiotion of the bit that you chose from the integer (starts from 0).</param>
        /// <returns>Returs you 0 if the value of the bit is 0 or returns 1 if the value is 1.</returns>
        public static byte GetBit(int number, byte bitNumber)
        {
            int pBit = 1 << bitNumber;
            if ((pBit & number) == 0)
                return 0;
            else return 1;
        }
        /// <summary>
        /// Sets the bit of the integer on the posiotion that you want with value that you chose.
        /// </summary>
        /// <param name="number">The integer where we will set the bit.</param>
        /// <param name="bitNumber">The bit position.</param>
        /// <param name="value">The new value of the bit.</param>
        /// <returns>Returns the new value of the integer</returns>
        public static int SetBit(int number, byte bitNumber, byte value)
        {
            int pBit = 1 << bitNumber;
            if (value == 0)
            {
                number &= ~pBit;
                return number;
            }
            else
            {
                number &= ~pBit;
                number |= pBit;
                return number;
            }
        }
        static void Main(string[] args)
        {
            short n = short.Parse(Console.ReadLine());
            byte counter = 0;
            int tempNumber;
            int numberReverse;
            int numberInvert;
            int number;
            for (int i = 0; i < n; i++)
            {
                number = int.Parse(Console.ReadLine());
                tempNumber = number;
                numberReverse = number;
                numberInvert = number;
                //p~
                while (tempNumber != 0)
                {
                    if (GetBit(tempNumber, 0) == 0)
                    {
                        numberInvert = SetBit(numberInvert, counter, 1);
                    }
                    else
                    {
                        numberInvert = SetBit(numberInvert, counter, 0);
                    }
                    tempNumber >>= 1;
                    counter++;
                }
                //p..
                tempNumber = number;
                counter--;

                while (tempNumber != 0)
                {
                    if (GetBit(tempNumber, 0) == 0)
                    {
                        numberReverse = SetBit(numberReverse, counter, 0);
                    }
                    else
                    {
                        numberReverse = SetBit(numberReverse, counter, 1);
                    }
                    tempNumber >>= 1;
                    counter--;
                }
                counter = 0;
                Console.WriteLine((number^numberInvert)&numberReverse);
            }

        }
    }
}