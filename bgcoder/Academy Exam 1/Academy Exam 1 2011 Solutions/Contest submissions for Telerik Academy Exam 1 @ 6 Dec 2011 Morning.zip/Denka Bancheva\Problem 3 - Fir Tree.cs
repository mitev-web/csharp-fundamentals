using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.firtree
{
    class firtree
    {
        static void Main()
        {
            uint n = uint.Parse(Console.ReadLine());
            int i = 0;
            int numberofstars = 0;
            uint height = n;



            for (int j = 0; j <= 100 * n; j++)
            {

                for (int k = 1; n - k > 0; )
                {
                    Console.Write(".");
                    k++;
                }

                for (int k = 0; k < numberofstars; )
                {
                    Console.Write("*");
                    k++;
                }


                numberofstars += 2;
                i += 2;
                n--;

                Console.WriteLine("*");

            }
         
         }
        }
    }

