using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikTest
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            if (((-cX1) > sX1 + h) && ((-cX2) < sX2 + h) && ((-cY1) > sY1 + h) && ((-cY1) < sY2 + h))
            {
                Console.WriteLine("100%");
            }
            

            
        }
    }
}
