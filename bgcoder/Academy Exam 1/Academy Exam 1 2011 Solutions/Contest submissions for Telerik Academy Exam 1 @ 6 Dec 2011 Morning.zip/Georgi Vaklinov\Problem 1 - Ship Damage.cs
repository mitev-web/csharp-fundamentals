using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine()); 
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            int maxX = Math.Max(Sx1, Sx2);
            int minX = Math.Min(Sx1, Sx2);
            int maxY = Math.Max(Sy1, Sy2);
            int minY = Math.Min(Sy1, Sy2);
            int damageC1 = 0;
            int damageC2 = 0;
            int damageC3 = 0;

   // projectile coordinates  c1       
            if (Cy1 < h)
            {
                Cy1 = Cy1 + 2 * (h - Cy1);
            }
            else if (Cy1 > h)
            {
                Cy1 = Cy1 - 2 * (Cy1 - h);
            }
            else if (Cy1 == h) { damageC1 = 0; }

// check for damage c1
            if (((Cx1 < maxX) && (Cx1 > minX)) && ((Cy1 < maxY) && (Cy1 > minY)))
            {
                damageC1 = 100;
            }
            else if (((Cx1 == Sx1) ^ (Cx1 == Sx2)) && (Cy1 > minY) && (Cy1 < maxY))
            {
                damageC1 = 50;
            }
            else if (((Cy1 == Sy1) ^ (Cy1 == Sy2)) && (Cx1 > minX) && (Cx1 < maxX))
            {
                damageC1 = 50;
            }
            else if (((Cx1 == Sx1) ^ (Cx1 == Sx2)) && ((Cy1 == Sy1) ^ (Cy1 == Sy2)))
            {
                damageC1 = 25;
            }

     // projectile coordinates  c2     
            if (Cy2 < h)
            {
                Cy2 = Cy2 + 2 * (h - Cy2);
            }
            else if (Cy2 > h)
            {
                Cy2 = Cy2 - 2 * (Cy2 - h);
            }
            else if (Cy2 == h) { damageC2 = 0; }

 // check for damage c2
            if (((Cx2 < maxX) && (Cx2 > minX)) && ((Cy2 < maxY) && (Cy2 > minY)))
            {
                damageC2 = 100;
            }
            else if (((Cx2 == Sx1) ^ (Cx2 == Sx2)) && (Cy2 > minY) && (Cy2 < maxY))
            {
                damageC2 = 50;
            }
            else if (((Cy2 == Sy1) ^ (Cy2 == Sy2)) && (Cx2 > minX) && (Cx2 < maxX))
            {
                damageC2 = 50;
            }
            else if (((Cx2 == Sx1) ^ (Cx2 == Sx2)) && ((Cy2 == Sy1) ^ (Cy2 == Sy2)))
            {
                damageC2 = 25;
            }

      // projectile coordinates  c3     
            if (Cy3 < h)
            {
                Cy3 = Cy3 + 2 * (h - Cy3);
            }
            else if (Cy3 > h)
            {
                Cy3 = Cy3 - 2 * (Cy3 - h);
            }
            else if (Cy3 == h) { damageC3 = 0; }

      // check for damage c3
            if (((Cx3 < maxX) && (Cx3 > minX)) && ((Cy3 < maxY) && (Cy3 > minY)))
            {
                damageC3 = 100;
            }
            else if (((Cx3 == Sx1) ^ (Cx3 == Sx2)) && (Cy3 > minY) && (Cy3 < maxY))
            {
                damageC3 = 50;
            }
            else if (((Cy3 == Sy1) ^ (Cy3 == Sy2)) && (Cx3 > minX) && (Cx3 < maxX))
            {
                damageC3 = 50;
            }
            else if (((Cx3 == Sx1) ^ (Cx3 == Sx2)) && ((Cy3 == Sy1) ^ (Cy3 == Sy2)))
            {
                damageC3 = 25;
            }
            int damage = damageC1 + damageC2 + damageC3;
            Console.WriteLine(damage + "%");
        }
    }
}