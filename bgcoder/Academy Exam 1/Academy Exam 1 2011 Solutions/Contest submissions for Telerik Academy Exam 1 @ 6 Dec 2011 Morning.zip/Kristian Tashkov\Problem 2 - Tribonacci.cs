using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a=BigInteger.Parse(Console.ReadLine()), b=BigInteger.Parse(Console.ReadLine()), c=BigInteger.Parse(Console.ReadLine());
            int n = Int32.Parse(Console.ReadLine());
            while ((n-3) > 0)
            {
                BigInteger temp = a;
                a = b;
                b = c;
                c = a + b+temp;
                n--;
            }
            Console.WriteLine(c);
        }
    }
}
