using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prob4_LoveBits
{
    class LoveBits
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            short n = short.Parse(input);

            int[] p = new int[n];
            for (int i = 0; i < n; i++)
            {
                input = Console.ReadLine();
                p[i] = int.Parse(input);
            }

            string output = "";

            for (int i = 0; i < n; i++)
            {
                int temp = p[i];
                int reversed = 0;
                int bitsCount = 0;
                while (temp > 0)
                {
                    temp >>= 1;
                    bitsCount++;
                }

                for (int j = 0; j < bitsCount / 2; j++)
                {
                    reversed |= (p[i] & (1 << j)) << (bitsCount - 2 * j - 1);
                }
                byte add = (byte)((bitsCount & 1) == 0 ? 1 : 0);
                
                for (int j = bitsCount / 2; j < bitsCount; j++)
                {
                    reversed |= (p[i] & ( 1 << j)) >> (add + ( 2 * (j - bitsCount / 2)));
                }

                output += ((p[i] ^ ~p[i]) & reversed).ToString() + "\n";
            }
            Console.WriteLine(output);
        }
    }
}
