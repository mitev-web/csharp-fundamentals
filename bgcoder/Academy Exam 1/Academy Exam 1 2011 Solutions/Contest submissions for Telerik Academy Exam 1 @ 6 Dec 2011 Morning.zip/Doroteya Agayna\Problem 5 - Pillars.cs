using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem5
{
    class Program
    {

        static byte GetBitValue(byte number, byte index)
        {
            byte mask = 0;
            mask = (byte)(1 << index);
            number = (byte)((number & mask) >> index);
            return number;
        }
        
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            byte i, p = 0, left = 0, right = 0, numIposP, strike, pillar = 0, count = 0;
            bool success = false;
            //Input
            for (i = 0; i < 8; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }
            //Processing
            for (strike = 0; strike < 8; strike++)
            {
                right = 0;
                left = 0;
                for (p = 0; p < 8; p++)
                {
                    if (p != strike)
                    {
                        for (i = 0; i < 8; i++)
                        {
                            numIposP = GetBitValue(numbers[i], p);
                            if (strike > p && numIposP == 1)
                            {
                                right++;
                            }
                            else if (strike < p && numIposP == 1)
                            {
                                left++;
                            }
                        }
                    }
                }
                if (left == right)
                {
                    pillar = strike;
                    count = right;
                    success = true;
                }
            }
            if (success)
            {
                Console.WriteLine(pillar);
                Console.WriteLine(count);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
