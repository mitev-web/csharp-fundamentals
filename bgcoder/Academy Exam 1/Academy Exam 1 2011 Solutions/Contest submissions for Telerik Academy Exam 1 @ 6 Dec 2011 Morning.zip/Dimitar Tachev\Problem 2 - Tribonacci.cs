using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace TelerikExam
{
    class Tribonachi
    {
        static void Main(string[] args)
        {
            BigInteger t1 = int.Parse(Console.ReadLine());
            BigInteger t2 = int.Parse(Console.ReadLine());
            BigInteger t3 = int.Parse(Console.ReadLine());
            short n = short.Parse(Console.ReadLine());
            BigInteger sum = 0;
            if (n == 1)
            {
                Console.WriteLine(t1);
            }
            if (n == 2)
            {
                Console.WriteLine(t2);
            }
            if (n == 3)
            {
                Console.WriteLine(t3);
            }
            for (short i = 0; i < n - 3; i++)
            {
                sum = t1 + t2 + t3;
                t1 = t2;
                t2 = t3;
                t3 = sum;
            }
            if (n>3)
            {
                Console.WriteLine(sum);
            } 
        }
    }
}