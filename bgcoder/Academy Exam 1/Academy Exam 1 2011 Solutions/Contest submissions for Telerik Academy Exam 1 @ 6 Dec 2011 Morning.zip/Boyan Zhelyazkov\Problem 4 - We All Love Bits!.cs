using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int N;
            N = int.Parse(Console.ReadLine());
            for (int l = 0; l < N; l++)
            {
                int P, copyP, ampP = 0, dotsP = 0;
                P = int.Parse(Console.ReadLine());
                copyP = P;
                while (copyP > 0)
                {
                    int bit;
                    int maskDotP, maskAmpP;
                    bit = copyP & 1;
                    copyP = copyP >> 1;


                    if (bit == 1)
                    {
                        maskDotP = 1;
                        dotsP = dotsP | maskDotP;
                        dotsP = dotsP << 1;
                    }
                    else
                    {
                        maskDotP = 0;
                        dotsP = dotsP << 1;
                    }
                }

                string number = Convert.ToString(P, 2);
                for (int i = 0; i <= number.Length - 1; i++)
                {
                    int maskAmpP;
                    if (number[i] == '1')
                    {
                        ampP = ampP << 1;
                    }
                    else
                    {
                        maskAmpP = 1;
                        ampP = ampP | maskAmpP;
                        ampP = ampP << 1;
                    }

                }
                dotsP = dotsP >> 1;
                ampP = ampP >> 1;
                int Pnew;
                Pnew = (P ^ ampP) & dotsP;
                Console.WriteLine(Pnew);
            }
            
        }
    }
}
