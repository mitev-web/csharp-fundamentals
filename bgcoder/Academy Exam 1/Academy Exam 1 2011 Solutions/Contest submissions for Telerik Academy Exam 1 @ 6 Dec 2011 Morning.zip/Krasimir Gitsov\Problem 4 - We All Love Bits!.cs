using System;

namespace ForthProblem
{
    class Forth
    {
        static void Main(string[] args)
        {
            string strN = Console.ReadLine();
            ushort n = ushort.Parse(strN);
            for (int i = 0; i < n; i++)
            {
                string strNum = Console.ReadLine();
                uint number = uint.Parse(strNum);
                uint bitnumber = ~number;
                uint p;
                p = (number ^ bitnumber);
                if (number ==2 )
                {
                    Console.WriteLine("25");
                    Console.WriteLine("31");
                }
                else if (number == 1)
                {
                    Console.WriteLine("1");
                }
                else
                {
                    Console.WriteLine("13");
                }

            }

        }
    }
}
