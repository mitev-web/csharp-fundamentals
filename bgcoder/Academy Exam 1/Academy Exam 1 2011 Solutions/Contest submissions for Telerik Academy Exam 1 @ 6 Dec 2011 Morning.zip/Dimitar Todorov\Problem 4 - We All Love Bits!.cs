using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BitLove
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int n = int.Parse(Console.ReadLine());

            int[] p = new int[n];
            int[] p2 = new int[n];
            int[] pI = new int[n];
            int[] pR = new int[n];
            int[] pN = new int[n];

            for (int i = 0; i < n; i++)
            {
                p[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                p2[i] = p[i];
 
            }
            for (int i = 0; i < n; i++)
            {
                pI[i] = ~p[i];
            }
            for (int i = 0; i < n; i++)
            {
                pR[i] = (p[i] ^ (~p[i]));
                pR[i] = (pR[i] ^ p[i]);
            }
            for (int i = 0; i < n; i++)
            {
                pN[i] = ((p[i] ^ pI[i]) & pR[i]);
 
            }
            for (int i =0; i<n; i++)
            {
                Console.WriteLine(pN[i]);
            }   


           
        }
    }
}
