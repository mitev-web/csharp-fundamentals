using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            string inpunt;
            byte fullCellsCounter = 0;

            for (byte counter = 0; counter < 8; counter++)
            {
                inpunt = Console.ReadLine();
                numbers[counter] = byte.Parse(inpunt);
                fullCellsCounter += CountOnesInNumber(numbers[counter]);
            }

            byte[] columnsCount = new byte[8];

            for (byte column = 0; column < 8; column++)
            {
                columnsCount[column] = CountOnesInColumn(numbers, column);
            }

            //columnsCount[0] = 1;
            //columnsCount[1] = 2;
            //columnsCount[2] = 3;
            //columnsCount[3] = 2;
            //columnsCount[4] = 2;
            //columnsCount[5] = 3;
            //columnsCount[6] = 2;
            //columnsCount[7] = 1;

            byte leftIndex = 7;
            byte rightIndex = 0;
            byte rightSum = columnsCount[rightIndex];
            byte leftSum = columnsCount[leftIndex];

            while (leftIndex > rightIndex)
            {
                if (leftSum > rightSum)
                {
                    rightIndex++;
                    rightSum += columnsCount[rightIndex];
                }
                else if (leftSum < rightSum)
                {
                    leftIndex--;
                    leftSum += columnsCount[leftIndex];
                }
                else if (leftSum == rightSum && leftIndex - 1 > rightIndex + 1)
                {
                    leftIndex--;
                    rightIndex++;
                    rightSum += columnsCount[rightIndex];
                    leftSum += columnsCount[leftIndex];
                }
                else if (leftSum == rightSum && leftIndex - 1 == rightIndex)
                {
                    if (columnsCount[leftIndex] == 0)
                    {
                        Console.WriteLine(leftIndex - 1);
                        Console.WriteLine(leftSum);
                        return;
                    }
                    else if (columnsCount[rightIndex] == 0)
                    {
                        Console.WriteLine(leftIndex);
                        Console.WriteLine(leftSum);
                        return;
                    }
                    //else if (columnsCount[leftIndex] == columnsCount[rightIndex])
                    //{
                    //    Console.WriteLine(leftIndex);
                    //    leftSum -= columnsCount[leftIndex];
                    //    Console.WriteLine(leftSum);
                    //    return;
                    //}
                    break;
                }
            }

            if (leftIndex == rightIndex && leftSum == rightSum)
            {
                Console.WriteLine(leftIndex);
                leftSum -= CountOnesInColumn(numbers, leftIndex);
                Console.WriteLine(leftSum);
            }
            else
            {

                Console.WriteLine("No");
            }
        }

        private static byte CountOnesInNumber(byte number)
        {
            byte counter = 0;

            for (int index = 0; index < 8; index++)
            {
                if (((number >> index) & 1) == 1)
                {
                    counter++;
                }
            }

            return counter;
        }

        private static byte CountOnesInColumn(byte[] numbers, byte column)
        {
            byte counter = 0;

            for (int row = 0; row < 8; row++)
            {
                if (((numbers[row] >> column) & 1) == 1)
                {
                    counter++;
                }
            }

            return counter;
        }
    }
}
