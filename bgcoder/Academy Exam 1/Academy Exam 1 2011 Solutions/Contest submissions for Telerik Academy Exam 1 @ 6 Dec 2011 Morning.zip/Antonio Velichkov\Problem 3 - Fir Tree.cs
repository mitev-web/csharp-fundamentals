using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int f = n - 2;
            int f1 = f;
            int m = 3; 
            int p = (2 * n - 3) - f - 1;

            
            for (int a = 0; a < f; a++)
            {
                Console.Write(".");
                
            }
            Console.Write("*");
            for (int a = 0; a < f; a++)
            {
                Console.Write(".");
            }
            Console.WriteLine();




            for (int b = 1; b <= f; b++)
            {
                for (int c = 1; c < f1; c++)
                {
                    Console.Write(".");
                }

                for (int d = 1; d <= m; d++)
                {
                    Console.Write("*");
                }

                for (int e = 1; e < p; e++) 
                {
                    Console.Write(".");
                }

                    Console.WriteLine();
                p--;
                m += 2;
                f1--;
            }

            



            for (int a = 0; a < f; a++)
            {
                Console.Write(".");

            }
            Console.Write("*");
            for (int a = 0; a < f; a++)
            {
                Console.Write(".");
            }
            Console.WriteLine();
        }
    }
}
