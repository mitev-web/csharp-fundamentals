using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChristmasTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int row;
            int col;
            bool b=true;
            int middle = (((2 * n) - 2) / 2);
            for (row = 1; row <= n; row++)
            {
                for (col = 1; col <= ((2 * n) - 3); col++)
                {
                    if (row == 1)
                    {
                        if (col == middle)
                        {
                            Console.Write("*");

                        }
                        else 
                        {
                            Console.Write(".");
                        }
                    }
                    else if (row > 1 && row < n)
                    {
                        if (col != middle)
                        {
                            
                            
                                for (int i = 1; i < row; i++)
                                {
                                    if (col == (middle - i) || col == (middle + i))
                                    {

                                        Console.Write("*");
                                        b = false;
                                        break;
                                    }
                                    else
                                    {
                                        b = true;
                                    }

                                }
                                if (b)
                                {
                                    Console.Write(".");
                                }
       
                        }
                        if (col == middle)  
                        {

                            Console.Write("*");

                        }
                        
                        
                    }
                    else if(row == n)
                    {
                        if (col == middle)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
 
                    }
                    
                }
                Console.WriteLine();
            }


        }
    }
}
