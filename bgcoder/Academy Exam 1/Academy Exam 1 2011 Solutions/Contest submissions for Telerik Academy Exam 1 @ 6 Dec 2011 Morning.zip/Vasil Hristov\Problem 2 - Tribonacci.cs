using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace Problem2
{
    class Program
    {
        static void Main()
        {

            
            BigInteger tribonaciAnswer=0,tribonacii3=0,tribonacii1=0, tribonacii2=0;
            tribonacii1 = BigInteger.Parse(Console.ReadLine());
            tribonacii2 = BigInteger.Parse(Console.ReadLine());
            tribonacii3 = BigInteger.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            if (N == 1) Console.WriteLine(tribonacii1);
            else if (N == 2) Console.WriteLine(tribonacii2);
            else if (N == 3) Console.WriteLine(tribonacii3);
            else
            {
                for (int i = 4; i <= N; i++)
                {
                    tribonaciAnswer = tribonacii1 + tribonacii2 + tribonacii3;

                    tribonacii1 = tribonacii2;
                    tribonacii2 = tribonacii3;
                    tribonacii3 = tribonaciAnswer;
                }
                Console.WriteLine(tribonaciAnswer);
            }
          
        }
    }
}
