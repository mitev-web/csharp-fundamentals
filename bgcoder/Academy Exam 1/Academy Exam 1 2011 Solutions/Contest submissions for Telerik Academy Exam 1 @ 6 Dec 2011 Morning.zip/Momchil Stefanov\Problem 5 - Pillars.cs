using System;

namespace _05.Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            byte[] grid = new byte[8];
            byte fullCellsCounterLeft = 0;
            byte fullCellsCounterRight = 0;
            byte currentColumnIndex = 0;
            bool splitSuccessful = false;
            byte mask, bit;

            for (int i = 0; i < 8; i++)
            {
                grid[i] = byte.Parse(Console.ReadLine());
            }

            for (sbyte pillar = 7; pillar >= 0; pillar--)
            {
                for (byte row = 0; row < 8; row++)
                {
                    for (sbyte leftSide = 7; leftSide > pillar; leftSide--)
                    {
                        mask = (byte)(1 << leftSide);
                        bit = (byte)((grid[row] & mask) >> leftSide);
                        if (bit == 1)
                        {
                            fullCellsCounterLeft++;
                        }
                    }

                    for (sbyte rightSide = (sbyte)(pillar - 1); rightSide >= 0; rightSide--)
                    {
                        mask = (byte)(1 << rightSide);
                        bit = (byte)((grid[row] & mask) >> rightSide);
                        if (bit == 1)
                        {
                            fullCellsCounterRight++;
                        }
                    }
                }

                if (fullCellsCounterLeft == fullCellsCounterRight)
                {
                    currentColumnIndex = (byte)pillar;
                    splitSuccessful = true;                    
                    break;
                }

                fullCellsCounterLeft = 0;
                fullCellsCounterRight = 0;
            }

            if (splitSuccessful)
            {
                Console.WriteLine(currentColumnIndex);
                Console.WriteLine(fullCellsCounterLeft);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
