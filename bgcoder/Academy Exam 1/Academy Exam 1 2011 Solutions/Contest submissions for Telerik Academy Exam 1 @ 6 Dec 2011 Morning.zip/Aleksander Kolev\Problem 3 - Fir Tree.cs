using System;

class FirTree
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        int n = int.Parse(line);
        int step = 1;
        for (int i = 1; i < n; i++)
        {

            Print(n - i - 1, '.');
            Print(step, '*');
            Print(n - i - 1, '.');
            Console.WriteLine();
            step += 2;
        }
        Print(n - 2, '.');
        Console.Write("*");
        Print(n - 2, '.');
        Console.WriteLine();
    }
    static void Print(int x, char ch)
    {
        for (int i = 0; i < x; i++)
        {
            Console.Write(ch);
        }
    }

}