using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace We_All_Love_Bits_
{
    class Program
    {
        static void Main(string[] args)
        {
            
            ushort count = ushort.Parse(Console.ReadLine());
            for (int q = 0; q < count; q++)
            {

                uint a = uint.Parse(Console.ReadLine());
                uint temp = a;
                uint b = ~a;
                uint c = 0;
                uint bit = 0;
                int position = 0;
                for (int i = 0; i < 32; i++)
                {
                    uint mask = (uint)1 << i;
                    uint nAndMask = a & mask;
                    bit = nAndMask >> i;
                    if (bit == 1)
                        position = i;
                }
                uint j = 0;
                for (c = j; j <= position; j++)
                {
                    c = (c << 1) + (temp & 1);
                    temp >>= 1;
                }
                Console.WriteLine((a ^ b) & c);
            }
        }
    }
}
