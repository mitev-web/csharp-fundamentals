using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());

            BigInteger x = c;

                for (int i = 3; i < n; i++)
                {
                    x = a + b + c;
                    a = b;
                    b = c;
                    c = x;
                }

            Console.WriteLine(x);
        }
    }
}
