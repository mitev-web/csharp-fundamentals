using System;

namespace Task05_Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            byte[] nums = new byte[8];
            for (int k = 0; k <= 7; k++)
            {
                nums[k] = byte.Parse(Console.ReadLine());
            }
            int pillar = 0;
            int counterLeft = 0;
            int counterRight = 0;
            int mask = 1;
            int temp;
            int thisPillarWorks = 0;
            bool thereIsAPillar = false;
            int correctCounter = 0;
            for (int i = 0; i <= 7; i++)
            {
                for (int q = 0; q <= 7; q++)
                {
                    for (int j = 0; j <= 7; j++)
                    {

                        temp = nums[q] & (mask << j);
                        if (temp != 0 && j < pillar)
                        {
                            counterRight++;
                        }
                        else if (temp != 0 && j > pillar)
                        {
                            counterLeft++;
                        }
                    }
                    temp = 0;
                }
                
                if (counterRight == counterLeft)
                {
                    thisPillarWorks = pillar;
                    thereIsAPillar = true;
                    correctCounter = counterRight;
                    counterLeft = 0;
                    counterRight = 0;
                    pillar++;
                    continue;
                }
                counterLeft = 0;
                counterRight = 0;
                pillar++;
            }
            if (thereIsAPillar == false)
            {
                Console.WriteLine("No");
            }
            else
            {
                Console.WriteLine(thisPillarWorks);
                Console.WriteLine(correctCounter);
            }
        }
    }
}
