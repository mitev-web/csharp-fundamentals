using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fir_Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int rows = 3 * n - (n-1);
            for (int i = 0; i < n; i++)
            {
                if (i == 0 || i == n-1)
                {
                    Console.Write(new String('.',(rows - 1)/2 -2));
                    Console.Write(new String('*',1));
                    Console.Write(new String('.',(rows - 1)/2 -2));
                }
                else
                {

                    Console.Write(new String('.', (rows - (i * 3 - (i-1))-1) / 2  -1));
                    Console.Write(new String('*', i*3-(i-1)));
                    Console.Write(new String('.', (rows - (i * 3 - (i-1))-1) / 2  -1));
                }
                    Console.WriteLine();   
            }
        }
    }
}