using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int src = 0;
                uint num = uint.Parse(Console.ReadLine());
                

                char[] chars = Convert.ToString(num, 2).ToCharArray();
               

               Array.Reverse(chars);
              

               uint num2 = Convert.ToUInt32(new string(chars), 2);
              
               uint inv = ~num;

             ulong result = (num ^ inv) & num2;
             Console.WriteLine(result);

                   
      



            }
        }
    }
}