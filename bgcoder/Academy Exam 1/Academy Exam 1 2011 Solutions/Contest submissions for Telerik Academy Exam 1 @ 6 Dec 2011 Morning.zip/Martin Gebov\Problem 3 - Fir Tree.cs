using System;


class FirTree
{
    static int n;
    static string row;
    
    static void Main(string[] args)
    {
        n = int.Parse(Console.ReadLine());
        int j = n * 2 - 3;
        row = GetStringWithDot(j);
        Console.WriteLine(row);
        for (int i = 1; i < n - 1; i++)
        {

            row = row.Replace(".*", "**");
            row = row.Replace("*.", "**");

            Console.WriteLine(row);
        }
        row = GetStringWithDot(j);
        Console.WriteLine(row);
    }

    static string GetStringWithDot(int j)
    {
        string dotString = "";

        for (int i = 0; i < j - 1; i++)
        {
            dotString += ".";
        }
        dotString = dotString.Insert(j / 2, "*");

        return dotString;
    }
}

