using System;

namespace Problem3_FirTree
{
    class FirTree
    {
        static int N;
        static char[,] grid;

        static void DrawDots()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    grid[i, j] = '.';
                }
            }
        }

        static void DrawTree()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
			{
                if (i != grid.GetLength(0) - 1)
                {
                    for (int j = N - 2; j >= 0; j--)
                    {
                        grid[i, j] = '*';
                        if (j == N - 2 - i)
                        {
                            break;
                        }
                    }
                    for (int k = N - 2; k < grid.GetLength(1); k++)
                    {
                        grid[i, k] = '*';
                        if (k == N - 2 + i)
                        {
                            break;
                        }
                    }
                }
                else
                { 
                    grid[i, N - 2] = '*';
                }
            }
        }

        static void PrintGrid()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    Console.Write(grid[i, j]);
                }
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            N = int.Parse(Console.ReadLine());
            grid = new char[N, ((N - 1) * 2 - 1)];
            DrawDots();
            DrawTree();
            PrintGrid();
        }
    }
}
