using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_3_FirThree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N;
            string point = ".";
            string asterisk = "*";




            N = byte.Parse(Console.ReadLine());

            for (int i = 0; i < N; i++)
            {

                for (int s = N; s > i + 1; s--)
                {
                    if (i > 0)
                    {
                        Console.Write(point);
                    }

                }
                for (int d = 0; d < i; d++)
                {
                    if (d == 0)
                    {
                        Console.Write(asterisk);
                    }
                    else
                    {
                        Console.Write(asterisk);
                        Console.Write(asterisk);
                    }
                }
                for (int h = N; h > i + 1; h--)
                {
                    if (i > 0)
                    {
                        Console.Write(point);
                    }
                }
                if (i == (N - 1))
                {
                    Console.Write("\n");
                    for (int t = 0; t < N -2; t++)
                    {
                        Console.Write(point);
                    }
                    for (int v = 0; v < N - (N - 1); v++)
                    {
                        Console.Write(asterisk);
                    }
                    for (int t = 0; t < N - 2; t++)
                    {
                        Console.Write(point);
                    }
                    
                }
                if (i > 0)
                {

                    Console.Write("\n");
                }
                
            }

        }
    }
}
