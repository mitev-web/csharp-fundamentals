using System;


namespace Ship
{
    class Program
    {
        static void Main(string[] args)
        {
            double sx1 = double.Parse(Console.ReadLine());
            double sy1 = double.Parse(Console.ReadLine());
            double sx2 = double.Parse(Console.ReadLine());
            double sy2 = double.Parse(Console.ReadLine());
            double h = double.Parse(Console.ReadLine());
            double cx1 = double.Parse(Console.ReadLine());
            double cy1 = double.Parse(Console.ReadLine());
            double cx2 = double.Parse(Console.ReadLine());
            double cy2 = double.Parse(Console.ReadLine());
            double cx3 = double.Parse(Console.ReadLine());
            double cy3 = double.Parse(Console.ReadLine());
            double countPer = 0;
            double d1, d2, d3;
            sy1 -= h;
            sy2 -= h;
            cy1 -= h;
            cy2 -= h;
            cy3 -= h;
            d1 = cy1;
            d2 = cy2;
            d3 = cy3;
       
            if (sx1 < sx2)
            {
                if (cx1 > sx1)
                {
                    if (cx1 < sx2)
                    {
                        if (sy1 < sy2)
                        {
                            if (2 * d1 < sy2) { countPer += 100; }
                            else { if (2 * d1 == sy1) { countPer += 50; } }
                        }
                        else { if (2 * d1 < sy1) { countPer += 100; } }

                    }
                    else
                    {
                        if (cx1 == sx2) { countPer += 25; }
                    }

                }
                else { if (cx1 == sx1) { countPer += 25; } }

            }
            else
            {
                if (cx1 > sx2)
                {
                    if (cx1 < sx1)
                    {
                        if (sy1 < sy2)
                        {
                            if (2 * d1 < sy2) { countPer += 100; }
                            else { if (2 * d1 == sy1) { countPer += 50; } }
                        }
                        else { if (2 * d1 < sy1) { countPer += 100; } }

                    }
                    else
                    {
                        if (cx1 == sx1) { countPer += 25; }
                    }

                }
            }
            if (sx1 < sx2)
            {
                if (cx2 > sx1)
                {
                    if (cx2 < sx2)
                    {
                        if (sy1 < sy2)
                        {
                            if (2 * d2 < sy2) { countPer += 100; }
                            else { if (2 * d2 == sy1) { countPer += 50; } }
                        }
                        else { if (2 * d2 < sy1) { countPer += 100; } }

                    }
                    else
                    {
                        if (cx2 == sx2) { countPer += 25; }
                    }

                }
                else { if (cx2 == sx1) { countPer += 25; } }

            }
            else
            {
                if (cx2 > sx2)
                {
                    if (cx2 < sx1)
                    {
                        if (sy1 < sy2)
                        {
                            if (2 * d2 < sy2) { countPer += 100; }
                            else { if (2 * d2 == sy1) { countPer += 50; } }
                        }
                        else { if (2 * d2 < sy1) { countPer += 100; } }

                    }
                    else
                    {
                        if (cx2 == sx1) { countPer += 25; }
                    }

                }
            } 
            //

            if (sx1 < sx2)
            {
                if (cx3 > sx1)
                {
                    if (cx3 < sx2)
                    {
                        if (sy1 < sy2)
                        {
                            if (2 * d3 < sy2) { countPer += 100; }
                            else { if (2 * d3 == sy1) { countPer += 50; } }
                        }
                        else { if (2 * d3 < sy1) { countPer += 100; } }

                    }
                    else
                    {
                        if (cx3 == sx2) { countPer += 25; }
                    }

                }
                else { if (cx3 == sx1) { countPer += 25; } }

            }
            else
            {
                if (cx3 > sx2)
                {
                    if (cx3 < sx1)
                    {
                        if (sy1 < sy2)
                        {
                            if (2 * d3 < sy2) { countPer += 100; }
                            else { if (2 * d3 == sy1) { countPer += 50; } }
                        }
                        else { if (2 * d3 < sy1) { countPer += 100; } }

                    }
                    else
                    {
                        if (cx3 == sx1) { countPer += 25; }
                    }

                }
            } 
            
            
            
            
            Console.WriteLine("{0}%", countPer);
        }
    }
}




           




        
  