using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger t1;
            BigInteger t2;
            BigInteger t3;
            BigInteger n;
            int flag = 0;
            t1 = BigInteger.Parse(Console.ReadLine());
            t2 = BigInteger.Parse(Console.ReadLine());
            t3 = BigInteger.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());
            BigInteger currentTribonacci=0;
            for (int i = 3; i < n; i++)
            {
                currentTribonacci = (t1 + t2 + t3);
                t1 = t2;
                t2 = t3;
                t3 = currentTribonacci;
                flag = 1;
            }
            if (flag == 1)
            {
                Console.WriteLine(currentTribonacci);
            }
            else
            {
                if (n == 1)
                {
                    Console.WriteLine(t1);
                }
                if (n == 2)
                {
                    Console.WriteLine(t2);
                }
                if (n == 3)
                {
                    Console.WriteLine(t3);
                }
            }
        }
    }
}
