using System;

namespace ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = int.Parse(Console.ReadLine());
            int temp = x;
            int y = x * 2 - 3;

            for (int i = 1; i <= x; i++)
            {
                for (int j = 1; j <= temp-2; j++)
                {
                        Console.Write(".");
                }
                for (int k = 1; k <= i; k++)
                {
                    if (i != x)
                    {
                        Console.Write("*");
                    }
                }
                for (int k = 1; k <= i-1; k++)
                {
                    if (i != x)
                    {
                        Console.Write("*");
                    }
                }
                for (int j = 1; j <= temp-2; j++)
                {
                    Console.Write(".");
                }
                if (i == x)
                {
                    for (int v = 1; v <= y; v++)
                    {
                        if (v == x - 1)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                Console.WriteLine();
                temp--;
            }
        }
    }
}
