using System;
using System.Linq;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1 = int.Parse(Console.ReadLine());
            BigInteger t2 = int.Parse(Console.ReadLine());
            BigInteger t3 = int.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            BigInteger first = t1;
            BigInteger second = t2;
            BigInteger third = t3;
            BigInteger sum = 0;
            for (int i = 1; i <= N; i++)
            {
                if (1 <= i && i <= 3 && N == 1)
                {
                    sum = first;
                }
                if (1 <= i && i <= 3 && N == 2)
                {
                    sum = second;
                }
                if (1 <= i && i <= 3 && N == 3)
                {
                    sum = third;
                }
                if (i >= 4)
                {
                    sum = third + second + first;
                    first = second;
                    second = third;
                    third = sum;
                }
            }
            Console.WriteLine(sum);
        }
    }
}