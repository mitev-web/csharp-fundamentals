using System;
using System.Linq;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
            int sum = 0;
            if (((Math.Abs(cy1) + 2 * h) > sy1) && cx1 < sx1 || ((Math.Abs(cy1) + 2 * h) < sy2) && cx1 > sx2)
            {
                sum = sum + 0;
            }
            if (((Math.Abs(cy1) + 2 * h) == sy1) && cx1 == sx1 || ((Math.Abs(cy1) + 2 * h) == sy2) && cx1 == sx2)
            {
                sum = sum + 25;
            }
            if (((Math.Abs(cy1) + 2 * h) < sy1) && cx1 == sx1 || ((Math.Abs(cy1) + 2 * h) > sy2) && cx1 > sx2)
            {
                sum = sum + 50;
            }
            if (((Math.Abs(cy1) + 2 * h) < sy1) && cx1 > sx1 && ((Math.Abs(cy1) + 2 * h) > sy2) && cx1 < sx2)
            {
                sum = sum + 100;
            }
            if (((Math.Abs(cy2) + 2 * h) > sy1) && cx2 < sx1 || ((Math.Abs(cy2) + 2 * h) < sy2) && cx2 > sx2)
            {
                sum = sum + 0;
            }
            if (((Math.Abs(cy2) + 2 * h) == sy1) && cx2 == sx1 || ((Math.Abs(cy2) + 2 * h) == sy2) && cx2 == sx2)
            {
                sum = sum + 25;
            }
            if (((Math.Abs(cy2) + 2 * h) < sy1) && cx2 == sx1 && ((Math.Abs(cy2) + 2 * h) > sy2) && cx2 > sx2)
            {
                sum = sum + 50;
            }
            if (((Math.Abs(cy2) + 2 * h) < sy1) && cx2 > sx1 || ((Math.Abs(cy2) + 2 * h) > sy2) && cx2 < sx2)
            {
                sum = sum + 100;
            }
            if (((Math.Abs(cy3) + 2 * h) > sy1) && cx3 < sx1 || ((Math.Abs(cy3) + 2 * h) < sy2) && cx3 > sx2)
            {
                sum = sum + 0;
            }
            if (((Math.Abs(cy3) + 2 * h) == sy1) && cx3 == sx1 || ((Math.Abs(cy3) + 2 * h) == sy2) && cx3 == sx2)
            {
                sum = sum + 25;
            }
            if (((Math.Abs(cy3) + 2 * h) < sy1) && cx3 == sx1 || ((Math.Abs(cy3) + 2 * h) > sy2) && cx3 > sx2)
            {
                sum = sum + 50;
            }
            if (((Math.Abs(cy3) + 2 * h) < sy1) && cx3 > sx1 && ((Math.Abs(cy3) + 2 * h) > sy2) && cx3 < sx2)
            {
                sum = sum + 100;
            }
            Console.WriteLine("{0}%", sum);
        }
    }
}