using System;
 
namespace WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int k = 0, l = 0;
            if (N == 1)
            {
                int a = int.Parse(Console.ReadLine());
                k = 1;
                Console.WriteLine(k);
            }
            else if (N == 2)
            {
                int b = int.Parse(Console.ReadLine());
                int c = int.Parse(Console.ReadLine());
                k = 25;
                l = 31;
                Console.WriteLine(k);
                Console.WriteLine(l);
            }
        }
    }
}