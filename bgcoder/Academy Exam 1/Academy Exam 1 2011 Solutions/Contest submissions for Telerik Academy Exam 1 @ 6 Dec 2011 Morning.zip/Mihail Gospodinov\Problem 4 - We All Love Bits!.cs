using System;

namespace WeAllLikeBits
{
    class Program
    {
        static int BitReverse(long k)
        {
            long result = 0;
            if (k == 0) return (int)result;
            for (int i = 0; i <= 31; i++)
            {
                result += k % 2;
                if (i != 31)
                {
                    result = result << 1;
                    k = k >> 1;
                }
            }
            bool ZeroRemoved = true;
            while (ZeroRemoved)
            {
                ZeroRemoved = false;
                if (result % 2 == 0)
                {
                    result=result >> 1;
                    ZeroRemoved = true;
                }
            }
            return (int)result;
        }
        static int GetLastOnePos(int k)
        {
            int result = 0;
            for (int i = 0; i <= 31; i++)
            {
                if (k % 2 == 1) result = i;
                k = k >> 1;
            }
            return result;
        }
        static int AntiBit(int k)
        {
            int tmp = 0;
            int counter=GetLastOnePos(k);
            for (int i = 0; i <= counter; i++)
            {
                if (k % 2 == 0)
                {
                    tmp += 1;  
                }
                if (i != counter)
                {
                    tmp = tmp << 1;
                }
                k = k >> 1;
            }
            for (int i = 0; i <= counter; i++)
            {
                k += tmp % 2;
                if (i != counter)
                {
                    k = k << 1;
                    tmp = tmp >> 1;
                }
            }
            return k;
        }
        static void Main(string[] args)
        {
            short N = short.Parse(Console.ReadLine());
            string result = "";
            for (int i = 0; i < N; i++)
            {
                int num = int.Parse(Console.ReadLine());
                int res = (num ^ AntiBit(num)) & BitReverse(num);
                result +=  res+ "\n";
            }
            Console.WriteLine(result);

        }
    }
}