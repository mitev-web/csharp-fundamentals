using System;

namespace Problem1_ShipDamage
{
    class ShipDamage
    {
        static int Sx1;
        static int Sy1;
        static int Sx2;
        static int Sy2;
        static int H;
        static int Cx1;
        static int Cy1;
        static int Cx2;
        static int Cy2;
        static int Cx3;
        static int Cy3;
        static string consoleInputLine;
        static int damage = 0;

        static bool CheckHorizonShipAndPoint(int Cy)
        {
            if ((H >= Cy) && H >= Sy1)
            {
                return false;
            }
            if ((H <= Cy) && H <= Sy1)
            {
                return false;
            }
            return true;
        }

        static bool CheckPointX(int Cx)
        {
            if ((Cx >= Sx1 && Cx <= Sx2) || (Cx <= Sx1 && Cx >= Sx2))
            {
                return false;
            }
            return true;
        }

        static bool doesCatapultHitShip(int Cy)
        {
            if ((((Cy - H) * -1) < Sy1 - H) && (((Cy - H) * -1) > Sy2 - H) || 
                (((Cy - H) * -1) > Sy1 - H) && (((Cy - H) * -1) < Sy2 - H))
            {
                return true;
            }
            return false;
        }

        static int doesCatapultHitBorderOrCorner(int Cx, int Cy)
        {
            if ((((Cy - H) * -1) == Sy1 - H) || (((Cy - H) * -1) == Sy2 - H))
            {
                if (Sx1 == Cx || Sx2 == Cx)
                {
                    return 25;
                }
                return 50;
            }
            return 0;
        }

        static int CheckShipDamage(int Cx, int Cy)
        {
            if (!CheckHorizonShipAndPoint(Cy))
            {
                return 0;
            }
            if (CheckPointX(Cx))
            {
                return 0;
            }
            else 
            {
                if (doesCatapultHitShip(Cy))
                {
                    return 100;
                }
                else 
                {
                    return doesCatapultHitBorderOrCorner(Cx, Cy);
                }
                        
            }
        }

        static void Main(string[] args)
        {
            consoleInputLine = Console.ReadLine();
            Sx1 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Sy1 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Sx2 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Sy2 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            H = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Cx1 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Cy1 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Cx2 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Cy2 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Cx3 = int.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            Cy3 = int.Parse(consoleInputLine);
            //Sx1 = -6;
            //Sy1 = 6;
            //Sx2 = -11;
            //Sy2 = 3;
            //H = 1;
            //Cx1 = -9;
            //Cy1 = -4;
            //Cx2 = -11;
            //Cy2 = -1;
            //Cx3 = 2;
            //Cy3 = 2;

            //Sx1 = -11;
            //Sy1 = 6;
            //Sx2 = -6;
            //Sy2 = 3;
            //H = 1;
            //Cx1 = -9;
            //Cy1 = -3;
            //Cx2 = -12;
            //Cy2 = -4;
            //Cx3 = -6;
            //Cy3 = -1;

            damage = CheckShipDamage(Cx1, Cy1) + CheckShipDamage(Cx2, Cy2) + CheckShipDamage(Cx3, Cy3);
            Console.WriteLine("{0}%", damage);
            //Console.WriteLine();
            //Console.WriteLine("{0}%", CheckShipDamage(Cx1, Cy1));
            //Console.WriteLine("{0}%", CheckShipDamage(Cx2, Cy2));
            //Console.WriteLine("{0}%", CheckShipDamage(Cx3, Cy3));
        }
    }
}
