using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            int number1 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int number2 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int number3 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int count = int.Parse(Console.ReadLine());

            int []arr = new int [count];

            arr[0] = number1;
            arr[1] = number2;
            arr[2] = number3;
            int i;
            int tmp=0;
            for (i = 3; i < count; i++)
            {
                arr[i] = arr[i - 1] + arr[i - 2] + arr[i - 3];
            }
            for (i = 0; i < count; i++)
            {
                tmp = arr[i];
            }
            Console.WriteLine(tmp);
        }
    }
}
