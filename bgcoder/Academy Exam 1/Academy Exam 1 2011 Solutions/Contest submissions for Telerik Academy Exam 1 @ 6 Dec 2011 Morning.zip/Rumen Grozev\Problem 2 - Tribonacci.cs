using System;
using System.Numerics;

namespace Problem2Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1, t2, t3, temp;
            int i, n;

            t1 = BigInteger.Parse(Console.ReadLine());
            t2 = BigInteger.Parse(Console.ReadLine());
            t3 = BigInteger.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());

            for (i = 3; i < n; i++)
            {
                temp = t3;
                t3 = t1 + t2 + t3;
                t1 = t2;
                t2 = temp;
            }
            Console.WriteLine(t3);
        }
    }
}
