using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace _1.ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            string sx1 = Console.ReadLine();
            int Sx1 = int.Parse(sx1);
            string sy1 = Console.ReadLine();
            int Sy1 = int.Parse(sy1);
            string sx2 = Console.ReadLine();
            int Sx2 = int.Parse(sx2);
            string sy2 = Console.ReadLine();
            int Sy2 = int.Parse(sy2);

            string h = Console.ReadLine();
            int H = int.Parse(h);

            string cx1 = Console.ReadLine();
            int Cx1 = int.Parse(cx1);
            string cy1 = Console.ReadLine();
            int Cy1 = int.Parse(cy1);
            string cx2 = Console.ReadLine();
            int Cx2 = int.Parse(cx2);
            string cy2 = Console.ReadLine();
            int Cy2 = int.Parse(cy2);
            string cx3 = Console.ReadLine();
            int Cx3 = int.Parse(cx3);
            string cy3 = Console.ReadLine();
            int Cy3 = int.Parse(cy3);

            int sumCorner1 = 0;
            int sumCorner2 = 0;
            int sumCorner3 = 0;
            int sumSide1 = 0;
            int sumSide2 = 0;
            int sumSide3 = 0;
            int sumInside1 = 0;
            int sumInside2 = 0;
            int sumInside3 = 0;
          

            #region if Corner

                if ((Cx1 == Sx1 & (Math.Abs(Cy1) + H * 2) == Sy1) | (Cx1 == Sx1 & (Math.Abs(Cy1) + H * 2) == Sy2) | (Cx1 == Sx2 & (Math.Abs(Cy1) + H * 2) == Sy1) | (Cx1 == Sx2 & (Math.Abs(Cy1) + H * 2) == Sy2))
            {
                sumCorner1 = 25;
            }
                if ((Cx2 == Sx1 & (Math.Abs(Cy2) + H * 2) == Sy1) | (Cx2 == Sx1 & (Math.Abs(Cy2) + H * 2) == Sy2) | (Cx2 == Sx2 & (Math.Abs(Cy2) + H * 2) == Sy1) | (Cx2 == Sx2 & (Math.Abs(Cy2) + H * 2) == Sy2))
            {
                sumCorner2 = 25;
            }
                if ((Cx3 == Sx1 & (Math.Abs(Cy3) + H * 2) == Sy1) | (Cx3 == Sx1 & (Math.Abs(Cy3) + H * 2) == Sy2) | (Cx3 == Sx2 & (Math.Abs(Cy3) + H * 2) == Sy1) | (Cx3 == Sx2 & (Math.Abs(Cy3) + H * 2) == Sy2))
            {
                sumCorner3 = 25;
            }

            #endregion

            #region if Side

                if (Cx1 == Sx1 & (Math.Abs(Cy1) + H * 2) < Math.Max(Sy1, Sy2) & (Math.Abs(Cy1) + H * 2) > Math.Min(Sy1, Sy2) | Cx1 == Sx2 & (Math.Abs(Cy1) + H * 2) < Math.Max(Sy1, Sy2) & (Math.Abs(Cy1) + H * 2) > Math.Min(Sy1, Sy2) | (Math.Abs(Cy1) + H * 2) == Sy1 & Cx1 < Math.Max(Sx1, Sx2) & Cx1 > Math.Min(Sx1, Sx2) | (Math.Abs(Cy1) + H * 2) == Sy2 & Cx1 < Math.Max(Sx1, Sx2) & Cx1 > Math.Min(Sx1, Sx2))
            {
                sumSide1 = 50;
            }
                if (Cx2 == Sx1 & (Math.Abs(Cy2) + H * 2) < Math.Max(Sy1, Sy2) & (Math.Abs(Cy2) + H * 2) > Math.Min(Sy1, Sy2) | Cx2 == Sx2 & (Math.Abs(Cy2) + H * 2) < Math.Max(Sy1, Sy2) & (Math.Abs(Cy2) + H * 2) > Math.Min(Sy1, Sy2) | (Math.Abs(Cy2) + H * 2) == Sy1 & Cx2 < Math.Max(Sx1, Sx2) & Cx2 > Math.Min(Sx1, Sx2) | (Math.Abs(Cy2) + H * 2) == Sy2 & Cx2 < Math.Max(Sx1, Sx2) & Cx2 > Math.Min(Sx1, Sx2))
            {
                sumSide2 = 50;
            }
                if (Cx3 == Sx1 & (Math.Abs(Cy3) + H * 2) < Math.Max(Sy1, Sy2) & (Math.Abs(Cy3) + H * 2) > Math.Min(Sy1, Sy2) | Cx3 == Sx2 & (Math.Abs(Cy3) + H * 2) < Math.Max(Sy1, Sy2) & (Math.Abs(Cy3) + H * 2) > Math.Min(Sy1, Sy2) | (Math.Abs(Cy3) + H * 2) == Sy1 & Cx3 < Math.Max(Sx1, Sx2) & Cx3 > Math.Min(Sx1, Sx2) | (Math.Abs(Cy3) + H * 2) == Sy2 & Cx3 < Math.Max(Sx1, Sx2) & Cx3 > Math.Min(Sx1, Sx2))
             {
                 sumSide3 = 50;
             }

            #endregion

             #region if Inside

             if (Cx1 > Math.Min(Sx1,Sx2) & Cx1 < Math.Max(Sx1,Sx2))
             {
                 if ((Math.Abs(Cy1) + H * 2) > Math.Min(Sy1, Sy2) & (Math.Abs(Cy1) + H * 2) < Math.Max(Sy1, Sy2))
                 {
                     sumInside1 = 100;
                 }
             }
             if (Cx2 > Math.Min(Sx1,Sx2) & Cx2 < Math.Max(Sx1,Sx2))
             {
                 if ((Math.Abs(Cy2) + H * 2) > Math.Min(Sy1, Sy2) & (Math.Abs(Cy2) + H * 2) < Math.Max(Sy1, Sy2))
                 {
                     sumInside2 = 100;
                 }
             }
             if (Cx3 > Math.Min(Sx1, Sx2) & Cx3 < Math.Max(Sx1, Sx2))
             {
                 if ((Math.Abs(Cy3) + H * 2) > Math.Min(Sy1, Sy2) & (Math.Abs(Cy3) + H * 2) < Math.Max(Sy1, Sy2))
                 {
                     sumInside3 = 100;
                 }
             }
             #endregion

             int sum = sumCorner1 + sumCorner2 + sumCorner3 + sumSide1 + sumSide2 + sumSide3 + sumInside1 + sumInside2 + sumInside3;

            Console.WriteLine("{0}%",sum);
                
            
        }
    }
}
