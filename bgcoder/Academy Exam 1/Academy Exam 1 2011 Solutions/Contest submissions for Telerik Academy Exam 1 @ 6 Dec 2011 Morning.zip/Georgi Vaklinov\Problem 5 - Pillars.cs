using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int p0 = 0; int p1=0; int p2=0; int p3=0; int p4=0; int p5=0; int p6=0; int p7=0;
            
            byte n0 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n0 & 1) == 1)
                {   
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }  
                }
                n0 = (byte)(n0 >> 1);  
            }
            byte n1 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n1 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n1 = (byte)(n1 >> 1);

            }

            byte n2 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n2 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n2 = (byte)(n2 >> 1);
            }
            byte n3 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n3 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n3 = (byte)(n3 >> 1);
            }
            byte n4 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n4 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n4 = (byte)(n4 >> 1);
            }

            byte n5 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n5 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n5 = (byte)(n5 >> 1);
            }
            byte n6 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n6 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n6 = (byte)(n6 >> 1);
            }
            byte n7 = byte.Parse(Console.ReadLine());
            for (int i = 0; i <= 7; i++)
            {
                if ((n7 & 1) == 1)
                {
                    switch (i)
                    {
                        case 0: p0++; break;
                        case 1: p1++; break;
                        case 2: p2++; break;
                        case 3: p3++; break;
                        case 4: p4++; break;
                        case 5: p5++; break;
                        case 6: p6++; break;
                        case 7: p7++; break;
                        default:
                            break;
                    }
                }
                n7 = (byte)(n7 >> 1);
            }

            if ((p0 + p1 + p2 + p3 + p4 + p5 + p6 + p7) == 0)
            {
                Console.WriteLine(7);
                Console.WriteLine(0);
            }

            else if ((p0 + p1 + p2 + p3 + p4 + p5) == p7)
            {
                Console.WriteLine(6);
                Console.WriteLine(p7);
            }
            else if ((p0 + p1 + p2 + p3 + p4) == (p7 + p6))
            {
                Console.WriteLine(5);
                Console.WriteLine((p7 + p6));
            }
            else if ((p0 + p1 + p2 + p3) == (p7 + p6 + p5))
            {
                Console.WriteLine(4);
                Console.WriteLine((p7 + p6 + p5));
            }
            else if ((p0 + p1 + p2) == (p7 + p6 + p5 + p4))
            {
                Console.WriteLine(3);
                Console.WriteLine((p0 + p1 + p2));
            }
            else if ((p0 + p1) == (p7 + p6 + p5 + p4 + p3))
            {
                Console.WriteLine(2);
                Console.WriteLine((p0 + p1));
            }
            else if (p0 == (p7 + p6 + p5 + p4 + p3 + p2))
            {
                Console.WriteLine(1);
                Console.WriteLine(p0);
            }
            else if (0 == (p7 + p6 + p5 + p4 + p3 + p2 + p1))
            {
                Console.WriteLine(0);
                Console.WriteLine(0);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}