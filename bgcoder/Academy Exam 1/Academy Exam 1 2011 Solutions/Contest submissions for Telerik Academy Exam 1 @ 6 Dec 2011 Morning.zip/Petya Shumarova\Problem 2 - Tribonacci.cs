using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                
                BigInteger a = BigInteger.Parse(Console.ReadLine());
                BigInteger b = BigInteger.Parse(Console.ReadLine());
                BigInteger c = BigInteger.Parse(Console.ReadLine());
                BigInteger d = 0;
                int i;

               
                int n = int.Parse(Console.ReadLine());

                for (i = 3; i < n; i++)
                {
                    d = a + b + c;
                    a = b;
                    b = c;
                    c = d;

                   
                }

                Console.WriteLine(d);
               
            }
        }
    }
}
