using System;
namespace ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sx1, sy1, sx2, sy2, h, cx1, cy1, cx2, cy2, cx3, cy3;
            sx1 = int.Parse(Console.ReadLine());
            sy1 = int.Parse(Console.ReadLine());
            sx2 = int.Parse(Console.ReadLine());
            sy2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cx1 = int.Parse(Console.ReadLine());
            cy1 = int.Parse(Console.ReadLine());
            cx2 = int.Parse(Console.ReadLine());
            cy2 = int.Parse(Console.ReadLine());
            cx3 = int.Parse(Console.ReadLine());
            cy3 = int.Parse(Console.ReadLine());

            int br = 0;
            int px, py;
            px = cx1;
            py = h + (h - cy1);
            if (px < Math.Max(sx1, sx2) && px > Math.Min(sx1, sx2))
            {
                if (py > Math.Min(sy1, sy2) && py < Math.Max(sy1, sy2))
                {
                    br += 100;
                }
                else
                    if (py == Math.Min(sy1, sy2) || py == Math.Max(sy1, sy2))
                    {
                        br += 50;
                    }
            }
            if(px==Math.Max(sx1, sx2)||px==Math.Min(sx1, sx2))
            {
                if (py > Math.Min(sy1, sy2) && py < Math.Max(sy1, sy2))
                {
                    br += 50;
                }
                else
                    if (py == Math.Min(sy1, sy2) || py == Math.Max(sy1, sy2))
                    {
                        br += 25;
                    }
            }
            px = cx2;
            py = h + (h - cy2);
            if (px < Math.Max(sx1, sx2) && px > Math.Min(sx1, sx2))
            {
                if (py > Math.Min(sy1, sy2) && py < Math.Max(sy1, sy2))
                {
                    br += 100;
                }
                else
                    if (py == Math.Min(sy1, sy2) || py == Math.Max(sy1, sy2))
                    {
                        br += 50;
                    }
            }
            if (px == Math.Max(sx1, sx2) || px == Math.Min(sx1, sx2))
            {
                if (py > Math.Min(sy1, sy2) && py < Math.Max(sy1, sy2))
                {
                    br += 50;
                }
                else
                    if (py == Math.Min(sy1, sy2) || py == Math.Max(sy1, sy2))
                    {
                        br += 25;
                    }
            }
            px = cx3;
            py = h + (h - cy3);
            if (px < Math.Max(sx1, sx2) && px > Math.Min(sx1, sx2))
            {
                if (py > Math.Min(sy1, sy2) && py < Math.Max(sy1, sy2))
                {
                    br += 100;
                }
                else
                    if (py == Math.Min(sy1, sy2) || py == Math.Max(sy1, sy2))
                    {
                        br += 50;
                    }
            }
            if (px == Math.Max(sx1, sx2) || px == Math.Min(sx1, sx2))
            {
                if (py > Math.Min(sy1, sy2) && py < Math.Max(sy1, sy2))
                {
                    br += 50;
                }
                else
                    if (py == Math.Min(sy1, sy2) || py == Math.Max(sy1, sy2))
                    {
                        br += 25;
                    }
            }
            Console.WriteLine(br+"%");
        }
    }
}
