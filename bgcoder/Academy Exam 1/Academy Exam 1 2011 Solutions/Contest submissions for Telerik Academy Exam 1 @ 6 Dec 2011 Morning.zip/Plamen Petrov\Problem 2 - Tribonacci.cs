using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Task1
    {
        static void Main(string[] args)
        {





            Console.Write("n=");
            string line = Console.ReadLine();
            

            int n = int.Parse(line);
            
            


            
            if (n < 2000000)
            {

                if (n > -2000000)
                {
                    
                        double Tnum = n * 1.83929;
                        Console.WriteLine("TribNumber={0}", Tnum);
                    
                }

                

            }
        }
    }
}

    


