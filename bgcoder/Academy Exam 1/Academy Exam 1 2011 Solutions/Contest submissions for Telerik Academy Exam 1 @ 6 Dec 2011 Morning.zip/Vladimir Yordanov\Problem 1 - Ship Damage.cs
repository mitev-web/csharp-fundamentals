using System;

namespace ExamProblem1
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());

            int cx1sim = cx1;
            int cx2sim = cx2;
            int cx3sim = cx3;

            int cy1sim = h + (h - cy1);
            int cy2sim = h + (h - cy2);
            int cy3sim = h + (h - cy3);

            int sum = 0;
            int[] CsimXcoord = { cx1sim,cx2sim,cx3sim};
            int[] CsimYcoord = { cy1sim, cy2sim, cy3sim };

            for (int i = 0; i < 3; i++)
            {
                if (((CsimXcoord[i] == sx1) && (CsimYcoord[i] == sy1)) || ((CsimXcoord[i] == sx2) && (CsimYcoord[i] == sy2)))
                {
                    sum += 25;
                }
                else if (((CsimXcoord[i] == sx1) || (CsimXcoord[i] == sx2)) && ((Math.Abs(CsimYcoord[i] - sy1) < Math.Abs(sy1 - sy2)) || (Math.Abs(CsimYcoord[i] - sy2) < Math.Abs(sy1 - sy2))))
                    {

                        sum += 50;

                    }
                else if (((CsimYcoord[i] == sy1) || (CsimYcoord[i] == sy2)) && ((Math.Abs(CsimXcoord[i] - sx1) < Math.Abs(sx1 - sx2)) || (Math.Abs(CsimXcoord[i] - sx2) < Math.Abs(sx1 - sx2))))
                    {

                        sum += 50;

                    }
                else if (((Math.Abs(CsimYcoord[i] - sy1) < Math.Abs(sy1 - sy2)) || (Math.Abs(CsimYcoord[i] - sy2) < Math.Abs(sy1 - sy2))) && ((Math.Abs(CsimXcoord[i] - sx1) < Math.Abs(sx1 - sx2)) || (Math.Abs(CsimXcoord[i] - sx2) < Math.Abs(sx1 - sx2))))
                    {
                        sum += 100;
                    }
                else 
                    {
                        sum += 0;
                    }
               
            }

            Console.WriteLine(sum+"%");
        }
    }
}
