using System;
using System.Threading;
using System.Globalization;

namespace Exam1
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-us");
            int n = int.Parse(Console.ReadLine());
            char[,] trap = new char[n, 2*n-3];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 2 * n-3; j++)
                {
                    trap[i, j] = '*';
                }
            }
            int helper = n;
            for (int i = 0; i < n-1; i++)
            {
                for (int j = 0; j < helper-2; j++)
                {
                    trap[i, j] = '.';   
                }
                helper--;
            }
            helper = n-2;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = helper+1; j < 2*n-3; j++)
                {
                    trap[i, j] = '.';
                }
                helper++;
            }
            for (int i = 0; i < 2*n-3; i++)
            {
                trap[n-1, i] = '.';
                if (i == n - 2)
                {
                    trap[n - 1, i] = '*';
                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 2 * n - 3; j++)
                {
                    Console.Write(trap[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
