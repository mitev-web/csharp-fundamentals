using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonaccis

{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger T1 = int.Parse(Console.ReadLine());
            BigInteger T2 = int.Parse(Console.ReadLine());
            BigInteger T3 = int.Parse(Console.ReadLine());
            ushort N = byte.Parse(Console.ReadLine());
            BigInteger Tn = 0;
            for (ushort i = 4; i <= N; i++)
            {
                Tn = T1 + T2 + T3;
                T1 = T2;
                T2 = T3;
                T3 = Tn;
            }
            Console.WriteLine(Tn);
        }
    }
}