using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] cells= new byte[8];
            for (byte i = 0; i < 8; i++)
            {
                cells[i]=byte.Parse(Console.ReadLine());
            }
            //byte sum=0;
            byte count1 = 0, count2 = 0;
            byte position1 = 0, position2 = 0;
            for (byte j = 0; j < 8; j++)
            {
                for (byte i = 0; i < 4; i++)
                {
                    byte mask = (byte)(1 << i);
                    byte nAndMask = (byte)(cells[i] & mask);
                    byte bit1 = (byte)(nAndMask >> i);
                    if (bit1 == 1)
                    {
                        count1++;
                        position1 = i;
                    }
                }
                for (byte i = 7; i >=4; i--)
			    {
                    byte mask = (byte)(1 << i);
                    byte nAndMask = (byte)(cells[i] & mask);
                    byte bit2 = (byte)(nAndMask >> i);
                    if (bit2 == 1)
                    {
                        count2++;
                        position2 =i;
                    }   
                }
            }
            if (count1 == count2)
            {
                Console.WriteLine(position2);
                Console.WriteLine(count2);
            }
            else
                Console.WriteLine("No");
            
        }
    }
}
