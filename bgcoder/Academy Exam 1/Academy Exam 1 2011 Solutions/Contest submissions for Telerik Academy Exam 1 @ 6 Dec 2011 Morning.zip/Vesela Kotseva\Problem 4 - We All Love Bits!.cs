using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LoveBits_04
{
    class Program
    {
        static void Main(string[] args)
        {
            uint a = 0;
            int check = 0;
            int i = 1;
            int n = int.Parse(Console.ReadLine());
            uint[] p=new uint[n];
            for (i = 0; i < n;i++ )
            {
                p[i] = uint.Parse(Console.ReadLine());
            }

            for (int j = 0; j < n; j++)
            {
                // Check positions needed
                for (i = 1; i < 32; i++)
                {
                    a = p[j] >> i;                   
                    if(a==0)
                    {
                        check = i;
                        break;
                    }
                }
               
                // Inverted bits numner
                uint x = 0;
                for(i=0;i<check;i++)
                {
                    x = x+(uint)Math.Pow(2,i) ;
                }

                uint inverted = 2147483647 ^ x;
                
                inverted=inverted|p[j];
                
                inverted = ~inverted;
               

                // Reversed number
                uint buffer = p[j];
                int reversed = 0;
                for (i = 0; i < check; i++)
                {
                    uint aTemporary = buffer >> (1 + i);
                    uint b = aTemporary << (1 + i);

                    if (b != buffer)
                    {
                        reversed = reversed + (int)Math.Pow(2, (check - 1 - i));
                    }
                    buffer = b;
                }
               
                Console.WriteLine((p[j]^inverted)&reversed);
            }


        }
    }
}
