using System;
using System.Numerics;

class Tribonacci
{
    static void Main(string[] args)
    {
        BigInteger next = 0;
        string line = Console.ReadLine();
        BigInteger t1 = BigInteger.Parse(line);
        line = Console.ReadLine();
        BigInteger t2 = BigInteger.Parse(line);
        line = Console.ReadLine();
        BigInteger t3 = BigInteger.Parse(line);
        line = Console.ReadLine();
        int n = int.Parse(line);
        if (n < 4)
        {
            switch (n)
            {
                case 1:
                    Console.WriteLine(t1);
                    break;
                case 2:
                    Console.WriteLine(t2);
                    break;
                case 3:
                    Console.WriteLine(t3);
                    break;
            }
        }
        else
        {
            for (int i = 4; i <= n; i++)
            {
                next = t1 + t2 + t3;
                t1 = t2;
                t2 = t3;
                t3 = next;
            }
            Console.WriteLine(next);
        }
    }
}