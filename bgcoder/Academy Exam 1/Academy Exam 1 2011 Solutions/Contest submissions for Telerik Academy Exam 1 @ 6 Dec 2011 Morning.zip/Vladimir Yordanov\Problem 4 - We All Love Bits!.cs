using System;

namespace ExamProblem4
{
    class Program
    {
        static void Main(string[] args)
        {
            uint numbers = uint.Parse(Console.ReadLine());

            uint[] numHolder = new uint[numbers];

            for(int i=0;i<numbers;i++)
            {
                numHolder[i] = uint.Parse(Console.ReadLine());
            }

            uint[] result = new uint[numbers];

            int tempnum;
            int mask;
            int count;
            int bit;
            int reverse;

            for(int i=0;i<numbers;i++)
            {
                mask = 0;
                count = 0;
                tempnum = (int)numHolder[i];
                while (tempnum > 0)
                {
                    mask += 1 << count;
                    tempnum /= 2;
                    count++;
                }

                tempnum = (int)numHolder[i];
                for (int j = 0; j <= count; j++)
                {
                    bit = tempnum % 2;
                    reverse = count - j;
                    if (bit == 0)
                    {

                        mask &= ~(1 << (reverse-1));
                    }
                    tempnum /= 2;
                }

                result[i] = (uint)mask;
            }

            for (int i = 0; i < numbers; i++)
            {
                Console.WriteLine(result[i]);
            }
        }
    }
}