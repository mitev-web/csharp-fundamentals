using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3.FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            string n = Console.ReadLine();
            byte N = byte.Parse(n);
            byte height = N;
            byte width = 1;
            byte count = 0;

            if (N >= 4 & N <= 100)
            {
                for (int forWidth = 1; forWidth < N-1; forWidth++)
                {
                    width += 2;
                }
                int widthDivided = width / 2;

                for (int i1 = 1; i1 <= height; i1++)
                {
                    for (int i2 = 1; i2 <= width; i2++)
                    {
                        if (i2 <= widthDivided-count)
                        {
                            Console.Write(".");
                        }
                        else if (i2 > widthDivided + count+1)
                        {
                            Console.Write(".");
                        }
                        else if (i1 == height & i2!=widthDivided+1)
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                        
                        
                        
                    }
                    count++;
                    Console.WriteLine();
                }
            }
        }
    }
}
