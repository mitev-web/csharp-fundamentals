using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int damage = 0;
            int sx1 = Math.Abs(int.Parse(Console.ReadLine()));
            int sy1 = Math.Abs(int.Parse(Console.ReadLine()));
            int sx2 = Math.Abs(int.Parse(Console.ReadLine()));
            int sy2 = Math.Abs(int.Parse(Console.ReadLine()));
            int h   = Math.Abs(int.Parse(Console.ReadLine()));
            int cx1 = Math.Abs(int.Parse(Console.ReadLine()));
            int cy1 = Math.Abs(int.Parse(Console.ReadLine()));
            int cx2 = Math.Abs(int.Parse(Console.ReadLine()));
            int cy2 = Math.Abs(int.Parse(Console.ReadLine()));
            int cx3 = Math.Abs(int.Parse(Console.ReadLine()));
            int cy3 = Math.Abs(int.Parse(Console.ReadLine()));
            cy1 += (2 * h);
            cy2 += (2 * h);
            cy3 += (2 * h);
            if ((cx1 == sx1 || cx1 == sx2) && (cy1 == sy1) || (cy1 == sy2))
            {
                damage += 25;
            }
            if ((cx1 == sx1 || cx1 == sx2) && ((cy1 > sy1 && cy1 < sy2) || (cy1 < sy1 && cy1 > sy2)))
            {
                damage += 50;
            }
            if ((cy1 == sy1 || cy1 == sy2) && ((cx1 > sx1 && cx1 < sx2) || (cx1 < sx1 && cx1 > sx2)))
            {
                damage += 50;
            }


            if ((cx2 == sx1 || cx2 == sx2) && (cy2 == sy1) || (cy2 == sy2))
            {
                damage += 25;
            }
            if ((cx2 == sx1 || cx2 == sx2) && ((cy2 > sy1 && cy2 < sy2) || (cy2 < sy1 && cy2 > sy2)))
            {
                damage += 50;
            }
            if ((cy2 == sy1 || cy2 == sy2) && ((cx2 > sx1 && cx2 < sx2) || (cx2 < sx1 && cx2 > sx2)))
            {
                damage += 50;
            }


            if ((cx3 == sx1 || cx3 == sx2) && (cy3 == sy1) || (cy3 == sy2))
            {
                damage += 25;
            }
            if ((cx3 == sx1 || cx3 == sx2) && ((cy3 > sy1 && cy3 < sy2) || (cy3 < sy1 && cy3 > sy2)))
            {
                damage += 50;
            }
            if ((cy3 == sy1 || cy3 == sy2) && ((cx3 > sx1 && cx3 < sx2) || (cx3 < sx1 && cx3 > sx2)))
            {
                damage += 50;
            }


            if (sx1 > sx2)
            {
                if (cx1 > sx2 && cx1 < sx1)
                {
                    if (sy1 > sy2)
                    {
                        if (cy1 < sy1 && cy1 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else
                    {
                        if (cy1 > sy1 && cy1 < sy2)
                        {
                            damage += 100;
                        }
                    }
                }
            }
            else
            {
                if (cx1 < sx2 && cx1 > sx1)
                {
                    if (sy1 > sy2)
                    {
                        if (cy1 < sy1 && cy1 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else
                    {
                        if (cy1 > sy1 && cy1 < sy2)
                        {
                            damage += 100;
                        }
                    }
                }
            }
            if (sx1 > sx2)
            {
                if (cx2 > sx2 && cx2 < sx1)
                {
                    if (sy1 > sy2)
                    {
                        if (cy2 < sy1 && cy2 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else
                    {
                        if (cy2 > sy1 && cy2 < sy2)
                        {
                            damage += 100;
                        }
                    }
                }
            }
            else
            {
                if (cx2 < sx2 && cx2 > sx1)
                {
                    if (sy1 > sy2)
                    {
                        if (cy2 < sy1 && cy2 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else
                    {
                        if (cy2 > sy1 && cy2 < sy2)
                        {
                            damage += 100;
                        }
                    }
                }
            }
            if (sx1 > sx2)
            {
                if (cx3 > sx2 && cx3 < sx1)
                {
                    if (sy1 > sy2)
                    {
                        if (cy3 < sy1 && cy3 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else
                    {
                        if (cy3 > sy1 && cy3 < sy2)
                        {
                            damage += 100;
                        }
                    }
                }
            }
            else
            {
                if (cx3 < sx2 && cx3 > sx1)
                {
                    if (sy1 > sy2)
                    {
                        if (cy3 < sy1 && cy3 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else
                    {
                        if (cy3 > sy1 && cy3 < sy2)
                        {
                            damage += 100;
                        }
                    }
                }
            }
            Console.WriteLine(damage + "%");
        }
    }
}
