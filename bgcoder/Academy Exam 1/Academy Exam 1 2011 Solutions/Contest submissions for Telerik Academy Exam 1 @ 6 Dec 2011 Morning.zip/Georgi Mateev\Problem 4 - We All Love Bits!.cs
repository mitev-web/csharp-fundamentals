using System;

namespace _4_We_All_Love_Bits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            Int16 n = Int16.Parse(Console.ReadLine());
            uint[] changedNumbers = new uint[n];
            for (int i = 0; i < n; i++)
            {
                uint P = uint.Parse(Console.ReadLine());
                uint opP = 0;
                uint revP = 0;
                uint l = GetBinaryLenght(P);

            
                for (int j = 0; j < l; j++)
                {
                    uint mask = 1;
                    mask <<= j;
                    uint bit = (P & mask) >> j;
                    if (bit==0)
                    {                        
                        opP |= (uint)1 << j;
                    }
                    revP |= ( bit << (int)(l - 1 - j) );
                }
                uint newP = (P ^ opP) & revP;
                changedNumbers[i] = newP;
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(changedNumbers[i]);
            }
        }
        static uint GetBinaryLenght(uint n)
        {
            if (n == 0)
            {
                return 1;
            }
            uint counter = 0;
            while (n != 0)
            {
                n /= 2; counter++;
            }
            return counter;
        }
    }
}
