using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Task2
{
    class TribonacciNumber
    {
        static void Main(string[] args)
        {
 
            double t1 = double.Parse(Console.ReadLine());
            double t2 = double.Parse(Console.ReadLine());
            double t3 = double.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());
            double tN = 0;
            double previous = t1;
            double now = t2;
            double next = t3;
            for (int i = 3; i < n; i++)
            {
 
                tN = previous + now + next;
                previous = now;
                now = next;
                next = tN;
            }
            Console.WriteLine(tN);
        }
    }
}