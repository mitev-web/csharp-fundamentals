using System;


namespace _1_Ship_Damage
{
    class ShipDamage
    {
        private static int Sx1, Sy1, Sx2, Sy2, H, Cx1, Cy1, Cx2, Cy2, Cx3, Cy3;
        static void Main(string[] args)
        {
            
            Sx1 = int.Parse(Console.ReadLine());
            Sy1 = int.Parse(Console.ReadLine());
            Sx2 = int.Parse(Console.ReadLine());
            Sy2 = int.Parse(Console.ReadLine());
            H = int.Parse(Console.ReadLine());
            Cx1 = int.Parse(Console.ReadLine());
            Cy1 = int.Parse(Console.ReadLine());
            Cx2 = int.Parse(Console.ReadLine());
            Cy2 = int.Parse(Console.ReadLine());
            Cx3 = int.Parse(Console.ReadLine());
            Cy3 = int.Parse(Console.ReadLine());

           // Sx1 = -6; Sy1 = 6; Sx2 = -11; Sy2 = 3; H = 1; Cx1 = -9; Cy1 = -4; Cx2 = -11; Cy2 = -1; Cx3 = 2; Cy3 = 2;

            int opCy1,opCy2,opCy3;
            if (Cy1<H)
            {
                opCy1 = H + Math.Abs(Cy1 - H);
            }
            else
            {
                opCy1 = H - Math.Abs(Cy1 - H);
            }

            if (Cy2 < H)
            {
                opCy2 = H + Math.Abs(Cy2 - H);
            }
            else
            {
                opCy2 = H - Math.Abs(Cy2 - H);
            }

            if (Cy3 < H)
            {
                opCy3 = H + Math.Abs(Cy3 - H);
            }
            else
            {
                opCy3 = H - Math.Abs(Cy3 - H);
            }

            int damage = 0;
            damage += GetDamage(Cx1, opCy1);
            damage += GetDamage(Cx2, opCy2);
            damage += GetDamage(Cx3, opCy3);

            Console.WriteLine("{0}%",damage);

        }
        static int GetDamage(int x,int y)
        {
            bool isInside = ((y > Sy1 && y < Sy2) || (y < Sy1 && y > Sy2)) &&
                ((x > Sx1 && x < Sx2) || (x < Sx1 && x > Sx2));
            bool isVSide = (x == Sx1 || x == Sx2) && ((y > Sy1 && y < Sy2) || (y < Sy1 && y > Sy2));
            bool isHSide = (y == Sy1 || y == Sy2) && ((x > Sx1 && x < Sx2) || (x < Sx1 && x > Sx2));
            bool isCorner = (x == Sx1 && y == Sy1) || (x == Sx2 && y == Sy2) || (x == Sx1 && y == Sy2) || (x == Sx2 && y == Sy1);
            if (isInside)
            {
                return 100;
            }
            if (isHSide || isVSide)
            {
                return 50;
            }
            if (isCorner)
            {
                return 25;
            }
            return 0;
        }
    }
}
