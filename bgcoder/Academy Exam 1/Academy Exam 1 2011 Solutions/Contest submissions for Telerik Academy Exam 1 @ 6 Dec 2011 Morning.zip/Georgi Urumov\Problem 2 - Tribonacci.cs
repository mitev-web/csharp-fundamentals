using System;
using System.Numerics;


namespace zad2
{
    class zad2
    {
        static void Main()
        {
            int x1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int x3 = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            if (n == 1)
            {
                Console.WriteLine(x1);
            }
            else if (n == 2)
            {
                Console.WriteLine(x2);
            }
            else if (n == 3)
            {
                Console.WriteLine(x3);
            }
            else
            {
                BigInteger[] numb = new BigInteger[n];
                numb[0] = x1;
                numb[1] = x2;
                numb[2] = x3;
                for (int i = 3; i < n; i++)
                {
                    numb[i] = numb[i - 1] + numb[i - 2] + numb[i - 3];

                }
                Console.WriteLine(numb[n-1]);
            }
        }
    }
}
