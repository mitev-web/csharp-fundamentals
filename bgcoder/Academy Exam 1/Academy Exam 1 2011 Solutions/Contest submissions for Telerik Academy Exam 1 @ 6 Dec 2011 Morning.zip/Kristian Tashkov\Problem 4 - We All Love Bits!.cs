using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine()),p;
            for (int i = 0; i < n; i++)
            {
                p = Int32.Parse(Console.ReadLine());
                Console.WriteLine((p ^ inverted(p)) & reversed(p));
            }
        }
        static int inverted(int a)
        {
            int b = 0, multiply = 1 ;
            while (a > 0)
            {
                if (a%2==0) b+=multiply;
                a = a >> 1;
                multiply *= 2;
            }
            return b;
        }
        static int reversed(int a)
        {
            int[] bits = new int[70];
            int b=0,i=0;
            while (a > 0)
            {
                bits[i++] = a % 2;
                a = a >> 1;
            }
            int multiply = 1;
            for (int j = i-1; j >=0; j--)
            {
                if(bits[j]==1) b += multiply;
                multiply *= 2;
            }
            return b;
        }
    }
}
