using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3Firtree
{
    class Firtree
    {
        static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());
            int leftPosition = n - 1;
            int rightPosition = n - 1;
            for (int i = 0; i < n-1; i++)
            {

                for (int j = 0; j < (2*n - 3); j++)
                {
                    if (j >= leftPosition-1 && j <= rightPosition-1)
                        Console.Write('*');
                    else
                        Console.Write('.');
                }
                leftPosition--;
                rightPosition++;
                Console.WriteLine();
            }
            for (int i = 0; i < (2*n-3); i++)
            {
                if(i==n-2)
                    Console.Write('*');
                else
                    Console.Write('.');
            }
            Console.WriteLine();
            
        }
    }
}
