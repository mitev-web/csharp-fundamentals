using System;

namespace Problem4_WeAllLoveBits
{
    class WeAllLoveBits
    {
        static string consoleInputLine;
        static int N;
        static int[] numbers;
        static string stringNumber;
        static int convertedNumber = 0;

        static void GetNumbers()
        {
            numbers = new int[N];
            for (int i = 0; i < N; i++)
            {
                consoleInputLine = Console.ReadLine();
                numbers[i] = int.Parse(consoleInputLine);
            }
        }

        //Convert numbers using Mitko's algorithm
        static void PrintConvertedNumbers()
        {
            int invertedNumber;
            int reversedNumber;
            for (int i = 0; i < numbers.Length; i++)
			{
			    invertedNumber = ~numbers[i];
                invertedNumber = (~(1 << 31)) & invertedNumber;
                reversedNumber = GetReveresedNumber(numbers[i]);
                convertedNumber = ((numbers[i] ^ invertedNumber) & reversedNumber);
                Console.WriteLine(convertedNumber);
			}
        }

        static int GetReveresedNumber(int number)
        {
            stringNumber = Convert.ToString(number, 2);
            number = 0;
            for (int i = stringNumber.Length - 1; i >= 0; i--)
            {
                if (stringNumber[i] == '1')
                {
                    number += (int)Math.Pow(2, i);
                }
            }
            return number;
        }

        static void Main(string[] args)
        {
            consoleInputLine = Console.ReadLine();
            N = int.Parse(consoleInputLine);
            GetNumbers();
            PrintConvertedNumbers();
        }
    }
}
