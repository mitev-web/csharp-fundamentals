using System;

namespace FireTree
{
    class Program
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            if(N%2!=0)  
            {
            for (int row = 1; row < N+1; row++)
                {
                    for (int col = 1; col < ((N*2)-2); col++)
                    {

                        if ((row + col) > N - 1 && col < N && row < N)
                        {
                            Console.Write("*");
                            
                        }
                        else if (row == N && col == (N - 1))
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                        
                    }
                    
                    Console.WriteLine();
             }   
            }
        }
    }
}
