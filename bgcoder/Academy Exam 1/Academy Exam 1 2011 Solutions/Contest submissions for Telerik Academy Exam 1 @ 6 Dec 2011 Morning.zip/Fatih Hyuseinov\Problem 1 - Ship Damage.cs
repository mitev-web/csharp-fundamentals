using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01.Ship_Damage
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            line = Console.ReadLine();
            double sx1 = double.Parse(line);
            line = Console.ReadLine();
            double sy1 = double.Parse(line);
            line = Console.ReadLine();
            double sx2 = double.Parse(line);
            line = Console.ReadLine();
            double sy2 = double.Parse(line);
            line = Console.ReadLine();
            double h = double.Parse(line);
            line = Console.ReadLine();
            double cx1 = double.Parse(line);
            line = Console.ReadLine();
            double cy1 = double.Parse(line);
            line = Console.ReadLine();
            double cx2 = double.Parse(line);
            line = Console.ReadLine();
            double cy2 = double.Parse(line);
            line = Console.ReadLine();
            double cx3 = double.Parse(line);
            line = Console.ReadLine();
            double cy3 = double.Parse(line);

            double y1 = Math.Abs(cy1 - h);
            double y2 = Math.Abs(cy2 - h);
            double y3 = Math.Abs(cy3 - h);

            double change;
            if (sx1 > sx2)
            {
                change = sx1;
                sx1 = sx2;
                sx2 = change;
            }
            if (sy1 < sy2)
            {
                change = sy1;
                sy1 = sy2;
                sy2 = change;
            }

            double sum = 0;
            
            if (cx1 > sx1 && cx1 < sx2 && y1 + h > sy2 && y1 + h < sy1)
            {
                sum += 1;
            }
            
            if (cx1 == sx1 && y1 + h == sy2)
            {
                sum += 0.25;
            }
            if (cx1 == sx2 && y1 + h == sy2)
            {
                sum += 0.25;
            }
            if (cx1 == sx1 && y1 + h == sy1)
            {
                sum += 0.25;
            }
            if ( cx1 == sx2 && y1 + h == sy1)
            {
                sum += 0.25;
            }
            
            if (cx1 == sx1 && y1 + h > sy2 && y1 + h < sy1   )
            {
                sum +=0.50;
            }
            if (cx1 == sx2 && y1 + h > sy2 && y1 + h < sy1)
            {
                sum += 0.50;
            }
            if (cx1 > sx1 && cx1 < sx2 && y1 + h == sy1)
            {
                sum += 0.50;
            }
            if (cx1 > sx1 && cx1 < sx2 && y1 + h == sy2)
            {
                sum += 0.50;
            }

            
            if (cx2 > sx1 && cx2 < sx2 && y2 + h > sy2 && y2 + h < sy1)
            {
                sum += 1;
            }
            
            if (cx2 == sx1 && y2 + h == sy2 || cx2 == sx2 && y2 + h == sy2 || cx2 == sx1 && y2 + h == sy1 || cx2 == sx2 && y2 + h == sy1)
            {
                sum += 0.25;
            }
            
            if (cx2 == sx1 && y2 + h > sy2 && y2 + h < sy1 || cx2 == sx2 && y2 + h > sy2 && y2 + h < sy1 || cx2 > sx1 && cx2 < sx2 && y2 + h == sy1 || cx2 > sx1 && cx2 < sx2 && y2 + h == sy2)
            {
                sum += 0.50;
            }

            
            if (cx3 > sx1 && cx3 < sx2 && y3 + h > sy2 && y3 + h < sy1)
            {
                sum += 1;
            }
            
            if (cx3 == sx1 && y3 + h == sy2 || cx3 == sx2 && y3 + h == sy2 || cx3 == sx1 && y3 + h == sy1 || cx3 == sx2 && y3 + h == sy1)
            {
                sum += 0.25;
            }
            
            if (cx3 == sx1 && y3 + h > sy2 && y3 + h < sy1 || cx3 == sx2 && y3 + h > sy2 && y3 + h < sy1 || cx3 > sx1 && cx3 < sx2 && y3 + h == sy1 || cx3 > sx1 && cx3 < sx2 && y3 + h == sy2)
            {
                sum += 0.50;
            }
           
            Console.Write("{0:###%}", sum);

        }
    }
}
