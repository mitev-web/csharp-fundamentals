using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            double dmg1;
            if (Sy2-h == h-Cy3)
            {
                if (Cx3==Sx2)
                {
                    dmg1 = 25;
                    Console.WriteLine(dmg1);
                }
              
            }
            else if (Sy1-h == h- Cy3)
            {
                if (Cx3==Sx1)
                {
                    dmg1=25;
                    Console.WriteLine("{0}%",dmg1);
                }
            }
            
        }
    }
}