using System;

namespace RealExam04
{
    class RealExam04
    {
        static void Main()
        {
            int lines = int.Parse(Console.ReadLine());
            //ulong b = ulong.Parse(Console.ReadLine());
            string finalResult = null;
            ulong givenNumber = 0;
            ulong finalNumber = 0;
            uint mask = 1;
            ulong reserve = givenNumber;
            ulong fundament = givenNumber;
            
            for (int g = 1; g <= lines; g++)
            {
            givenNumber = ulong.Parse(Console.ReadLine());
            int full = (int)Math.Log(givenNumber, 2);
             reserve = givenNumber;
             fundament = givenNumber;

            // givenNumber = ulong.Parse(Console.ReadLine());

            for (int i = 0; i <= Math.Log(givenNumber, 2); i++)
            {
                mask = 1U << i;
                givenNumber ^= mask;
            }
            //Console.WriteLine(givenNumber);
            mask = 1;

            // }
            for (int i = 0; i <= full / 2; i++)
            {
                mask = 1U << i;
                uint mask2 = 1U << (full - i);

                bool checker = (mask & reserve) != 0;
                bool checker2 = (mask2 & reserve) != 0;

                if (checker && !checker2)
                {

                    reserve = reserve & (~(1U << i));

                }
                if (!checker && checker2)
                {

                    reserve = reserve | (1U << i);

                }
                if (checker2 && !checker)
                {

                    reserve = reserve & (~(1U << full - i));

                }
                if (!checker2 && checker)
                {

                    reserve = reserve | (1U << full - i);
                }
            }
            finalNumber = (fundament ^ givenNumber) & reserve;
                string stringNumber= finalNumber.ToString();

                finalResult = finalResult + stringNumber + "\n";
                // Console.WriteLine(reserve);
            }
           
            
            Console.WriteLine(finalResult);
        }
    }
}
