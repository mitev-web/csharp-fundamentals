using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int w = n + (n - 3);
            string[] width = new string[w];
            for (int i = 0; i < width.Length; i++)
            {
                width[i] = ".";
            }
            width[(w / 2)] = "*";
            foreach (string pos in width)
            {
                Console.Write(pos);
            }
            Console.WriteLine();
            for (int i = 1; i < (n-1); i++)
            {
                width[((w / 2) - i)] = "*";
                width[((w / 2) + i)] = "*";
                foreach (string newPos in width)
                {
                    Console.Write(newPos);
                }
                Console.WriteLine();
            }
            for (int i = 0; i < width.Length; i++)
            {
                width[i] = ".";
            }
            width[(w / 2)] = "*";
            foreach (string oldPos in width)
            {
                Console.Write(oldPos);
            }
        }
    }
}