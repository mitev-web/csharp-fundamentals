using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class WeAllLoveBits
{
    static void Main(string[] args)
    {
        int N = Int32.Parse(Console.ReadLine());
        
        for (int i = 0; i < N; i++)
        {
            int input = Int32.Parse(Console.ReadLine());

            // Find the leftmost significant bit
            int leftMostBitPos = 32;
            for (int j = 31; j>=0; j--) // 31, as 32 is the sign
            {
                if ((input & (1 << j)) != 0)
                {
                    leftMostBitPos = j;
                    break;
                }
            }

            int PZeroOne = 0;
            for (int j = 0; j <= leftMostBitPos; j++)
            {
                if ((input & (1 << j)) != 0)
                    continue;

                PZeroOne |= (1 << j);
            }

            int PReversed = 0;
            for (int j = 0; j <= leftMostBitPos; j++)
            {
                if ((input & (1 << j)) != 0)
                    PReversed |= (1 << (leftMostBitPos - j));
            }

            int result = (input ^ PZeroOne) & PReversed;
            Console.WriteLine(result);

        }
         
    }
}
