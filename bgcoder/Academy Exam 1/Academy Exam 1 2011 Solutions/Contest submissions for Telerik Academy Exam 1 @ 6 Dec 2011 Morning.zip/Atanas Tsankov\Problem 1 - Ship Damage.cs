using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            int impactC1x;
            int impactC1y;
            int impactC2x;
            int impactC2y;
            int impactC3x;
            int impactC3y;
            int sX3 = sX2;
            int sY3 = sY1;
            int sX4 = sX1;
            int sY4 = sY2;
            int damageCounter = 0;
            if (sX1 < sX2)
            {
                if (h == 0)
                {
                    impactC1x = cX1;
                    impactC1y = (cY1 * (-1));
                    impactC2x = cX2;
                    impactC2y = (cY2 * (-1));
                    impactC3x = cX3;
                    impactC3y = (cY3 * (-1));
                    if ((impactC1x == sX1) || (impactC1x == sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC1x > sX1) && (impactC1x < sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC2x == sX1) || (impactC2x == sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC2x > sX1) && (impactC2x < sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC3x == sX1) || (impactC3x == sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC3x > sX1) && (impactC3x < sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                }
                if (h > 0)
                {
                    impactC1x = cX1;
                    impactC1y = ((h + (cY1 * (-1)) + 1));
                    impactC2x = cX2;
                    impactC2y = ((h + (cY2 * (-1)) + 1));
                    impactC3x = cX3;
                    impactC3y = ((h + (cY3 * (-1)) + 1));

                    if ((impactC1x == sX1) || (impactC1x == sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC1x > sX1) && (impactC1x < sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC2x == sX1) || (impactC2x == sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC2x > sX1) && (impactC2x < sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC3x == sX1) || (impactC3x == sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC3x > sX1) && (impactC3x < sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }

                }
                if (h < 0)
                {
                    impactC1x = cX1;
                    impactC1y = ((h * (-1)) + (cY1 - h)) * (-1);
                    impactC2x = cX2;
                    impactC2y = ((h * (-1)) + (cY2 - h)) * (-1);
                    impactC3x = cX3;
                    impactC3y = ((h * (-1)) + (cY3 - h)) * (-1);
                    if ((impactC1x == sX1) || (impactC1x == sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC1x > sX1) && (impactC1x < sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC2x == sX1) || (impactC2x == sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC2x > sX1) && (impactC2x < sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC3x == sX1) || (impactC3x == sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC3x > sX1) && (impactC3x < sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                } Console.WriteLine(damageCounter + "%");
            }
            if (sX1 > sX2)
            {
                if (h == 0)
                {
                    impactC1x = cX1;
                    impactC1y = (cY1 * (-1));
                    impactC2x = cX2;
                    impactC2y = (cY2 * (-1));
                    impactC3x = cX3;
                    impactC3y = (cY3 * (-1));
                    if ((impactC1x == sX1) || (impactC1x == sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC1x < sX1) && (impactC1x > sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC2x == sX1) || (impactC2x == sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC2x < sX1) && (impactC2x > sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC3x == sX1) || (impactC3x == sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC3x < sX1) && (impactC3x > sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                }
                if (h > 0)
                {
                    impactC1x = cX1;
                    impactC1y = ((h + (cY1 * (-1)) + 1));
                    impactC2x = cX2;
                    impactC2y = ((h + (cY2 * (-1)) + 1));
                    impactC3x = cX3;
                    impactC3y = ((h + (cY3 * (-1)) + 1));

                    if ((impactC1x == sX1) || (impactC1x == sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC1x < sX1) && (impactC1x > sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC2x == sX1) || (impactC2x == sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC2x < sX1) && (impactC2x > sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC3x == sX1) || (impactC3x == sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC3x < sX1) && (impactC3x > sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }

                }
                if (h < 0)
                {
                    impactC1x = cX1;
                    impactC1y = ((h * (-1)) + (cY1 - h)) * (-1);
                    impactC2x = cX2;
                    impactC2y = ((h * (-1)) + (cY2 - h)) * (-1);
                    impactC3x = cX3;
                    impactC3y = ((h * (-1)) + (cY3 - h)) * (-1);
                    if ((impactC1x == sX1) || (impactC1x == sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC1x < sX1) && (impactC1x > sX2))
                    {
                        if ((impactC1y == sY1) || (impactC1y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC1y < sY1) && (impactC1y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC1y > sY1) && (impactC1y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC2x == sX1) || (impactC2x == sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC2x < sX1) && (impactC2x > sX2))
                    {
                        if ((impactC2y == sY1) || (impactC2y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC2y < sY1) && (impactC2y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC2y > sY1) && (impactC2y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                    if ((impactC3x == sX1) || (impactC3x == sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 25;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 50;
                            }
                        }
                    }
                    else if ((impactC3x < sX1) && (impactC3x > sX2))
                    {
                        if ((impactC3y == sY1) || (impactC3y == sY2))
                        {
                            damageCounter = damageCounter + 50;
                        }
                        else if (sY1 > sY2)
                        {
                            if ((impactC3y < sY1) && (impactC3y > sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                        else
                        {
                            if ((impactC3y > sY1) && (impactC3y < sY2))
                            {
                                damageCounter = damageCounter + 100;
                            }
                        }
                    }
                } Console.WriteLine(damageCounter + "%");
            }
            
        }
    }
}