using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class ShipDamage
{
        static void Main(string[] args)
    {
        int y, z;
        int ab,ac,aa;
        int ba, bb, bc, bd;
        int SxOne = int.Parse(Console.ReadLine());
        int SyOne = int.Parse(Console.ReadLine());
        int SxTwo = int.Parse(Console.ReadLine());
        int SyTwo = int.Parse(Console.ReadLine());
        int H = int.Parse(Console.ReadLine());
        int CxOne = int.Parse(Console.ReadLine());
        int CyOne = int.Parse(Console.ReadLine());
        int CxTwo = int.Parse(Console.ReadLine());
        int CyTwo = int.Parse(Console.ReadLine());
        int CxThree = int.Parse(Console.ReadLine());
        int CyThree = int.Parse(Console.ReadLine());
        if (H > 0)
        {
            y=-H;
            if (SxOne > SxTwo)
            {
                if (SxOne > CxOne && CxOne>SxTwo)
                {
                    aa=100;
                }
                if (SxOne > CxTwo && CxTwo > SxTwo)
                {
                    ab = 100;
                } 
                if (SxOne > CxThree && CxThree > SxTwo)
                {
                    ac = 100;
                }


                if (SxOne == CxOne && SyOne==CyOne+y || SxOne == CxTwo && SyOne==CyTwo+y || SxOne ==CxThree && SyOne==CyThree+y)
                {
                    ba = 25;
                }
                if (SxTwo == CxOne && SyTwo == CyOne + y || SxTwo == CxTwo && SyTwo == CyTwo + y || SxTwo == CxThree && SyTwo == CyThree + y)
                {
                    bb = 25;
                }
                if (SxOne - SxTwo == CxOne && SyOne - SyTwo == CyOne + y || SxOne - SxTwo == CxTwo && SyOne - SyTwo == CyTwo + y || SxOne - SxTwo == CxThree && SyOne - SyTwo == CyThree + y)
                {
                    bc = 25;
                }
                if (SxTwo == CxOne && SyTwo == CyOne + y || SxTwo == CxTwo && SyTwo == CyTwo + y || SxTwo == CxThree && SyTwo == CyThree + y)
                {
                    bd = 25;
                }
            }

        }
    }
}

