using System;
using System.Threading;
using System.Globalization;

namespace Exam1
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-us");
            int[,] ship =new int [2,2];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    ship[i, j] = int.Parse(Console.ReadLine());
                }
            }    
            int h = int.Parse(Console.ReadLine());
            int[,] guns = new int[3, 2];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    guns[i, j] = int.Parse(Console.ReadLine());
                }
            }
            for (int i = 0; i < 2; i++)
            {
                ship[i, 1] -= h; 
            }
            for (int i = 0; i < 3; i++)
            {
                guns[i, 1] -= h;
            }
            int result = 0;
            for (int i = 0; i < 3; i++)
            {
                if ((guns[i, 0] == ship[0, 0]) || (guns[i, 0] == ship[1, 0]))
                {
                    if ((guns[i, 1] == -ship[0, 1]) || (guns[i, 1] == -ship[1, 1]))
                    {
                        result += 25;
                    }
                    else if ((guns[i, 1] < -ship[0, 1]) && (guns[i, 1] > -ship[1, 1]) || (guns[i, 1] > -ship[0, 1]) && (guns[i, 1] < -ship[1, 1]))
                    {
                        result += 50;
                    }
                }
                else if (((guns[i, 0] > ship[0, 0]) && (guns[i, 0] < ship[1, 0])) || ((guns[i, 0] < ship[0, 0]) && (guns[i, 0] > ship[1, 0])))
                {
                    if ((guns[i, 1] == -ship[0, 1]) || (guns[i, 1] == -ship[1, 1]))
                    {
                        result += 50;
                    }
                    else if ((guns[i, 1] > -ship[0, 1]) && (guns[i, 1] < -ship[1, 1]) || ((guns[i, 1] < -ship[0, 1]) && (guns[i, 1] > -ship[1, 1])))
                    {
                        result += 100;
                    }
                }
            }
            Console.WriteLine(result + "%");
        }
    }
}
