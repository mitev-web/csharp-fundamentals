using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            int number;
            int remainder;
            int counterBits = 0;
            int flagPillars = 0;
            int leftside = 0;
            int sumLeftside = 0;
            int sumRightside = 0;
            int sumOfBits = 0;
            int righside = 0;
            int indexPillar=0;
            int[] bits = new int[8];
            for (int i = 0; i <8; i++)
            {
                number = int.Parse(Console.ReadLine());
                do
                {
                    remainder = number % 2;
                    number = number >> 1;
                    if (remainder == 1)
                    {
                        bits[counterBits]++;
                    }
                    counterBits++;
                } while (number != 0);
                counterBits = 0;
            }
            for (int k = 0; k <= 7; k++)
            {
                leftside = 7 - k;
                righside = 7 - leftside;
                for (int s = 0; s < righside; s++)
                {
                    sumRightside += bits[s];
                }
                for (int t = 7; t>k; t--)
                {
                    sumLeftside += bits[t]; 
                }
                if (sumRightside == sumLeftside)
                {
                    flagPillars = 1;
                    
                    if (indexPillar < k)
                    {
                        indexPillar = k;
                        sumOfBits = sumRightside;
                    }
                }
                sumRightside = 0;
                sumLeftside = 0;
            }
            if (flagPillars == 1)
            {
                Console.WriteLine(indexPillar);
                Console.WriteLine(sumOfBits);
            }
            if (flagPillars == 0)
            {
                Console.WriteLine("No");
            }

        }
    }
}
