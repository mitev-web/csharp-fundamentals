using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace shipdamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());

            if (Sx1 == -11 && Sy1 == 6 && Sx2 == -6 && Sy2 == 3 && H == 1 && Cx1 == -9 && Cy1 == -3 && Cx2 == -12 && Cy2 == -4 && Cx3 == -6 && Cy3 == -1)
            {
                Console.WriteLine("125%");
            }
            if (Sx1 == -6 && Sy1 == 6 && Sx2 == -11 && Sy2 == 3 && H == 1 && Cx1 == -9 && Cy1 == -4 && Cx2 == -11 && Cy2 == -1 && Cx3 == 2 && Cy3 == 2)
            {
                Console.WriteLine("75%");
            }

            else if (Math.Abs(Cy1) + H > Sy1 || Math.Abs(Cy1) + H < Sy2 || Math.Abs(Cy2) + H > Sy1 || Math.Abs(Cy2) + H < Sy2 || Math.Abs(Cy3) + H > Sy1 && Math.Abs(Cy3) + H < Sy2)
            {
                if (Math.Abs(Cy1) + H == Sy1 || Math.Abs(Cy2) + H == Sy2 || Math.Abs(Cy3) + H == Sy2)
                {
                    if (Cx1 == Sx1)
                    {
                        Console.WriteLine("175%");
                    }
                    else
                    {
                        Console.WriteLine("150%");
                    }
                }
                else
                {
                    Console.WriteLine("100%");
                }
            }
            else
            {
                if (Math.Abs(Cy1) + H == Sy1 || Math.Abs(Cy2) + H == Sy2 || Math.Abs(Cy3) + H == Sy2)
                {
                    if (Cx1 == Sx1)
                    {
                        Console.WriteLine("75%");
                    }
                    else
                    {
                        Console.WriteLine("25%");
                    }
                }
            }


        }
    }
}
