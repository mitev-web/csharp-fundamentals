using System;

class Pillars
{
    static void Main(string[] args)
    {
        byte[] grid = new byte[8];

        grid[0] = byte.Parse(Console.ReadLine());
        grid[1] = byte.Parse(Console.ReadLine());
        grid[2] = byte.Parse(Console.ReadLine());
        grid[3] = byte.Parse(Console.ReadLine());
        grid[4] = byte.Parse(Console.ReadLine());
        grid[5] = byte.Parse(Console.ReadLine());
        grid[6] = byte.Parse(Console.ReadLine());
        grid[7] = byte.Parse(Console.ReadLine());


        int line = 0;
        int counterRight = 0;
        int counterLeft = 0;
        int finalCounter = 0;

        for (int p = 0; p < 8; p++)
        {

            for (int j = 0; j < 8; j++)
            {

                for (int i = 0; i < 8; i++)
                {
                    if (i < p)
                    {
                        bool bit = (grid[j] & (1 << i)) != 0;
                        if (bit == true)
                        {
                            counterRight++;
                        }
                    }
                    else if (i > p)
                    {
                        bool bit = (grid[j] & (1 << i)) != 0;
                        if (bit == true)
                        {
                            counterLeft++;
                        }
                    }

                }
            }

            if (counterLeft == counterRight)
            {
                line = p;
                finalCounter = counterRight;
            }

            counterLeft = 0;
            counterRight = 0;
        }

        if (line > 0)
        {
            Console.WriteLine(line);
            Console.WriteLine(finalCounter);
        }
        else
        {
            Console.Write("No");
        }



    }

}
