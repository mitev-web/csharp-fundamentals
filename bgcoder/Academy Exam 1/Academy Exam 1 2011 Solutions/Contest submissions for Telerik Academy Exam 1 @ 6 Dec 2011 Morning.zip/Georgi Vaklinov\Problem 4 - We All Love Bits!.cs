using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bits
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int j = 0; j < n; j++)
            {

                int p = int.Parse(Console.ReadLine());
                int bits = 0;
                int test = p;
                while (test != 0)
                {
                    test /= 2;
                    bits++;
                }

                p = p << 1;
                int pNew = 0;
                for (int i = (bits - 1); i > 0; i--)
                {
                    p = p >> 1;
                    if ((p & 1) == 1)
                    {
                        pNew = pNew | (1 << i);
                    }
                    else
                    {
                        pNew = pNew & (~(1 << i));
                    }

                }
                Console.WriteLine(pNew + 1);
            }
        }
    }
}