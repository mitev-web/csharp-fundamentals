using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] col0 = new int[8];
            int[] col1 = new int[8];
            int[] col2 = new int[8];
            int[] col3 = new int[8];
            int[] col4 = new int[8];
            int[] col5 = new int[8];
            int[] col6 = new int[8];
            int[] col7 = new int[8];
            int sum0=0;
            int sum1=0;
            int sum2=0;
            int sum3=0;
            int sum4=0;
            int sum5=0;
            int sum6=0;
            int sum7=0;
            int[] decimalNumbers = new int[8];
            for (int i = 0; i < 8; i++)
            {
                decimalNumbers[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0, j = 0; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col0[i] = bit;
            }
            for (int i = 0, j = 1; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col1[i] = bit;
            }
            for (int i = 0, j = 2; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col2[i] = bit;
            }
            for (int i = 0, j = 3; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col3[i] = bit;
            }
            for (int i = 0, j = 4; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col4[i] = bit;
            }
            for (int i = 0, j = 5; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col5[i] = bit;
            }
            for (int i = 0, j = 6; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col6[i] = bit;
            }
            for (int i = 0, j = 7; i < decimalNumbers.Length; i++)
            {
                int mask = 1 << j;
                int numberAndMask = decimalNumbers[i] & mask;
                int bit = numberAndMask >> j;
                col7[i] = bit;
            }
            foreach (int bit in col0)
            {
                sum0 += bit;
            }
            foreach (int bit in col1)
            {
                sum1 += bit;
            }
            foreach (int bit in col2)
            {
                sum2 += bit;
            }
            foreach (int bit in col3)
            {
                sum3 += bit;
            }
            foreach (int bit in col4)
            {
                sum4 += bit;
            }
            foreach (int bit in col5)
            {
                sum5 += bit;
            }
            foreach (int bit in col6)
            {
                sum6 += bit;
            }
            foreach (int bit in col7)
            {
                sum7 += bit;
            }

            if (sum1 + sum2 + sum3 + sum4 + sum5 + sum6 + sum7 == 0)
            {
                if (sum0 == 0)
                {
                    Console.WriteLine("7");
                    Console.WriteLine("0");
                }
                else
                {
                    Console.WriteLine("0");
                    Console.WriteLine("0");
                }
            }
            else if (sum0 == sum2 + sum3 + sum4 + sum5 + sum6 + sum7)
            {
                if (sum0+sum1 ==sum3 + sum4 + sum5 + sum6 + sum7)
                {
                    if (sum0 +sum1+ sum2  == sum4 + sum5 + sum6 + sum7)
                    {
                        if (sum0 +sum1+ sum2 + sum3 == sum5 + sum6 + sum7)
                        {
                            if (sum0 + sum1+ sum2 + sum3 + sum4 == sum6 + sum7)
                            {
                                if (sum0 + sum1+  sum2 + sum3 + sum4 + sum5 == sum7)
                                {
                                    Console.WriteLine("6");
                                    Console.WriteLine(sum7);
                                }
                                Console.WriteLine("5");
                                Console.WriteLine(sum6+sum7);
                            }
                            Console.WriteLine("4");
                            Console.WriteLine(sum5+sum6+sum7);
                        }
                        Console.WriteLine("3");
                        Console.WriteLine(sum4+sum5+sum6+sum7);
                    }
                    Console.WriteLine("2");
                    Console.WriteLine(sum0+sum1);
                }
                Console.WriteLine("1");
                Console.WriteLine(sum0);
            }
            else if (sum0 + sum1 == sum3 + sum4 + sum5 + sum6 + sum7)
            {
                if (sum0 + sum1 + sum2 == sum4 + sum5 + sum6 + sum7)
                {
                    if (sum0 + sum1 + sum2 + sum3 == sum5 + sum6 + sum7)
                    {
                        if (sum0 + sum1 + sum2 + sum3 + sum4 == sum6 + sum7)
                        {
                            if (sum0 + sum1 + sum2 + sum3 + sum4 + sum5 == sum7)
                            {
                                Console.WriteLine("6");
                                Console.WriteLine(sum7);
                            }
                            Console.WriteLine("5");
                            Console.WriteLine(sum6 + sum7);
                        }
                        Console.WriteLine("4");
                        Console.WriteLine(sum5 + sum6 + sum7);
                    }
                    Console.WriteLine("3");
                    Console.WriteLine(sum4 + sum5 + sum6 + sum7);
                }
                Console.WriteLine("2");
                Console.WriteLine(sum0 + sum1);
            }
            else if (sum0 + sum1 + sum2 == sum4 + sum5 + sum6 + sum7)
            {
                if (sum0 + sum1 + sum2 + sum3 == sum5 + sum6 + sum7)
                {
                    if (sum0 + sum1 + sum2 + sum3 + sum4 == sum6 + sum7)
                    {
                        if (sum0 + sum1 + sum2 + sum3 + sum4 + sum5 == sum7)
                        {
                            Console.WriteLine("6");
                            Console.WriteLine(sum7);
                        }
                        Console.WriteLine("5");
                        Console.WriteLine(sum6 + sum7);
                    }
                    Console.WriteLine("4");
                    Console.WriteLine(sum5 + sum6 + sum7);
                }
                Console.WriteLine("3");
                Console.WriteLine(sum4 + sum5 + sum6 + sum7);
            }
            else if (sum0 + sum1 + sum2 + sum3 == sum5 + sum6 + sum7)
            {
                if (sum0 + sum1 + sum2 + sum3 + sum4 == sum6 + sum7)
                {
                    if (sum0 + sum1 + sum2 + sum3 + sum4 + sum5 == sum7)
                    {
                        Console.WriteLine("6");
                        Console.WriteLine(sum7);
                    }
                    Console.WriteLine("5");
                    Console.WriteLine(sum6 + sum7);
                }
                Console.WriteLine("4");
                Console.WriteLine(sum5 + sum6 + sum7);
            }
            else if (sum0 + sum1 + sum2 + sum3 + sum4 == sum6 + sum7)
            {
                if (sum0 + sum1 + sum2 + sum3 + sum4 + sum5 == sum7)
                {
                    Console.WriteLine("6");
                    Console.WriteLine(sum7);
                }
                Console.WriteLine("5");
                Console.WriteLine(sum6 + sum7);
            }
            else if (sum0 + sum1 + sum2 + sum3 + sum4 + sum5 == sum7)
            {
                Console.WriteLine("6");
                Console.WriteLine(sum7);
            }
            else Console.WriteLine("No");

        }
    }
}