using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Prob2_Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            string input;

            // read T1, T2, T3
            BigInteger[] t = new BigInteger[3];
            for (int i = 0; i < 3; i++)
            {
                input = Console.ReadLine();
                t[i] = BigInteger.Parse(input);
            }

            // read N
            input = Console.ReadLine();
            short n = short.Parse(input);

            BigInteger result = 0;

            if (n <= 3)
            {
                result = t[n - 1];
            }
            else
            {
                for (int i = 0; i < n - 3; i++)
                {
                    result = t[0] + t[1] + t[2];
                    t[0] = t[1];
                    t[1] = t[2];
                    t[2] = result;
                }
            }

            Console.WriteLine(result);
        }
    }
}
