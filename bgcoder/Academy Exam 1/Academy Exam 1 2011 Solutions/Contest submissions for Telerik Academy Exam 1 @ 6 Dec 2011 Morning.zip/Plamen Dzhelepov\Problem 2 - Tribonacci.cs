
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;






namespace Task_7
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());
            BigInteger d = 0;
            if (N >= 4)
            {
                for (int i = 0; i <= (N - 4); i++)
                {
                    d = a + b + c;
                    a = b;
                    b = c;
                    c = d;
                }
                Console.WriteLine(d);
            }
            else if (N == 3)
            {
                Console.WriteLine(c);
            }
            else if (N == 2)
            {
                Console.WriteLine(b);
            }
            else if (N == 1)
            {
                Console.WriteLine(a);
            }
        }
    }
}
