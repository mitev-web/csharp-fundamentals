using System;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int SX1 = int.Parse(Console.ReadLine());
            int SY1 = int.Parse(Console.ReadLine());
            int SX2 = int.Parse(Console.ReadLine());
            int SY2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int CX1 = int.Parse(Console.ReadLine());
            int CY1 = int.Parse(Console.ReadLine());
            int CX2 = int.Parse(Console.ReadLine());
            int CY2 = int.Parse(Console.ReadLine());
            int CX3 = int.Parse(Console.ReadLine());
            int CY3 = int.Parse(Console.ReadLine());
            int damage = 0;
            if (SX1 > 0 && SY1 > H && SX2 > 0 && SY2 > H)
            {
                if (CX1 < SX2 && CX1 > SX1 && CY1 < SY1 && CY1 > SY2)
                    damage += 0;
                else if(CX2 < SX2 && CX2 > SX1 && CY2 < SY1 && CY2 > SY2)
                    damage +=0;
                else if(CX3 < SX2 && CX3 > SX1 && CY3 < SY1 && CY3 > SY2)
                    damage+=0;
                else if (CX1 > SX2 && CX1 < SX1 && CY1 > SY1 && CY1 < SY2)
                    damage+=100;
                else if(CX2 > SX2 && CX2 < SX1 && CY2 > SY1 && CY2 < SY2)
                    damage+=100;
                else if(CX3 > SX2 && CX3 < SX1 && CY3 > SY1 && CY3 < SY2)
                    damage+=100;
                else if( CX1 == SX1 && CY1 == SY1 ||CX1 == SX2 && CY1 == SY2)
                    damage+=25;
                else if( CX2 == SX1 && CY2 == SY1 ||CX2 == SX2 && CY2 == SY2)
                    damage+=25;
                else if( CX3 == SX1 && CY3 == SY1 ||CX3 == SX2 && CY3 == SY2)
                    damage+=25;
                else if( CX1 == SX1 && CY1 != SY1 || CX1 == SX2 && CX1 != SX2)
                    damage+=50;
                else if( CX2 == SX1 && CY2 != SY1 || CX2 == SX2 && CX2 != SX2)
                    damage+=50;
                else if( CX3 == SX1 && CY3 != SY1 || CX3 == SX2 && CX3 != SX2)
                    damage+=50;
            }
            Console.WriteLine(damage + "%");
        }
    }
}
