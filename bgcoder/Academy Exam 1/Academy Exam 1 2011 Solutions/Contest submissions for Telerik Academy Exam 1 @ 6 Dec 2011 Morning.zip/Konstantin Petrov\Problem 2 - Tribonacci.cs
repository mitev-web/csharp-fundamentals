using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tribobacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            long firstElement = long.Parse(Console.ReadLine());
            long secondElement = long.Parse(Console.ReadLine());
            long thirdElement = long.Parse(Console.ReadLine());
            ushort nElement = ushort.Parse(Console.ReadLine());
            long tempElement = 0;
            

            for (int j = 3; j < nElement; j++)
                {
                    tempElement = firstElement + secondElement + thirdElement;
                    firstElement = secondElement;
                    secondElement = thirdElement;
                    thirdElement = tempElement;

                }


                Console.Write("{0}", tempElement);
            
        }
    }
}

