using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char[] output = new char[(n*2)-3];
            char[] outputModel = new char[(n*2)-3];
            for (int i = 0; i < output.Length; i++)
            {
                output[i] = '.';
                outputModel[i] = '.';
            }
            int k = n - 2;
            for (int j = 0; j < n-1; j++)
            {
                output[k - j] = '*';
                output[k + j] = '*';
                if (j == 0)
                {
                    outputModel[k - j] = '*';
                }
                for (int i = 0; i < output.Length; i++)
                {
                    Console.Write(output[i]);
                }
                Console.WriteLine();
            }
            for (int i = 0; i < output.Length; i++)
            {
                Console.Write(outputModel[i]);
            }
        }
    }
}
