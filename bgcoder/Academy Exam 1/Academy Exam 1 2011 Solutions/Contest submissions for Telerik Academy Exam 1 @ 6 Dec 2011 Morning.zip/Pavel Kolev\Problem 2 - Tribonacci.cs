using System;
using System.Threading;
using System.Globalization;
using System.Numerics;

namespace _3___Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-us");
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger[] mas = new BigInteger[n];
            mas[0] = t1;
            mas[1] = t2;
            mas[2] = t3;
            if (n == 1)
            {
                Console.WriteLine(t1);
            }
            else if (n == 2)
            {
                Console.WriteLine(t2);
            }
            else if (n == 3)
            {
                Console.WriteLine(t3);
            }
            else
            {
                for (int i = 3; i < n; i++)
                {
                    mas[i] = mas[i - 1] + mas[i - 2] + mas[i - 3];
                }
                Console.WriteLine(mas[n - 1]);
            }
        }
    }
}
