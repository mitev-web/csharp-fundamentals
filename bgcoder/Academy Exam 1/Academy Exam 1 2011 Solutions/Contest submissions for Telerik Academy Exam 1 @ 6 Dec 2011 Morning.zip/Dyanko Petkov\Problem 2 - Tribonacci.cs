using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem_2_Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger f, s, t;
            BigInteger result;
            int N;
            
            f = int.Parse(Console.ReadLine());
            s = int.Parse(Console.ReadLine());
            t = int.Parse(Console.ReadLine());
            N = int.Parse(Console.ReadLine());
            
            for (int i = 0; i <= N; i++)
            {

                result = f + s + t;
                if (i == N - 4)
                {
                    Console.WriteLine(result);
                }

                f = s;
                s = t;
                t = result;

            }

        }
    }
}
