using System;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int row = n;
            int col =  n + n - 3;
            for (row = 1; row <= n; row++)
            {
                for(col = 1; col <= n + n -3; col++)
                {
                    if (col == n - 1)
                    {
                        Console.Write("*");
                    }
                    else if ( row != 1 &&  row != n && col >= n - row && col <= n + row - 2)
                    {
                            Console.Write("*"); 
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
