using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tribonacci_02
{
    class Program
    {
        static void Main(string[] args)
        {
            long[] t=new long[3];

            for (int i = 0; i < 3; i++)
            {   
                t[i]=long.Parse(Console.ReadLine()); 
            }
            int n=int.Parse(Console.ReadLine());

            long[] tribunacci=new long[n+2];
            for (int i = 0; i < 3; i++)
            {
                tribunacci[i] = t[i];
            }
            for(int i=3;i<n;i++)
            {
                tribunacci[i]=tribunacci[i-1]+tribunacci[i-2]+tribunacci[i-3];
            }
            Console.WriteLine(tribunacci[n-1]);
        }
    }
}
