using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zad2_Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {    long a=Int32.Parse(Console.ReadLine());
             long b=Int32.Parse(Console.ReadLine());
              long c=Int32.Parse(Console.ReadLine()); 
                            int n=Int32.Parse(Console.ReadLine());
              
                  Console.WriteLine(TribonacciFumction(a, b,c, n));
 
              

        }

        public static long TribonacciFumction(long a, long b, long c, int n)
        {
           
         long prevminus = a;

         long prev = b;

         long final = c;



         for (int i = 0; i < n-3; i++)
          {
            long sum = prev+prevminus+final;
             prevminus = prev;
             prev = final;
           
            final = sum;
          }
        
          return final;
        }

        
        
    }
}
