using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zad3
{
    
    class Program
    {
        static void Main(string[] args)
        {
            int resultNumber = 0;
            int resultCount = 0; 
            int count = 0;
            byte[] a;
            a = new Byte[8];
            byte[] b = new Byte[8];
            byte bitmask = 1, bitmask2 = 1;
            for (int i = 0; i < 8; i++)
            {
                a[i] = Convert.ToByte(Console.ReadLine());
                b[i] = 0;
            }
            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    
                    if ((bitmask & a[i]) != 0)
                    {

                        b[j] = (byte)(b[j] | bitmask2);

                    }
                    bitmask2 <<= 1;
                }
                bitmask2 = 1;
                bitmask = (byte)(bitmask << 1);
            }

            bitmask = 1;
            bitmask2 = 1;
            int count2 = 0;
            count = 0;
            for (int i = 1; i < 7; i++)
            {   
                
                bitmask = 1;
                bitmask2 = 1;
                count = 0;
                count2 = 0;
                for (int j = 0; j < i; j++)
                {
                    for (int z = 0; z < 8; z++)
                    {
                        if ((bitmask & b[j]) != 0)
                            count++;
                        bitmask <<= 1;
                    }
                    bitmask = 1;
                }

                for (int j = i+1; j < 8; j++)
                {
                    for (int z = 0; z < 8; z++)
                    {
                        if ((bitmask2 & b[j]) != 0)
                            count2++;
                        bitmask2 <<= 1;
                    }
                    bitmask2 = 1;
                }
                if (count == count2)
                {
                    resultNumber = i;
                    resultCount = count;
                } 
            }
            if (resultNumber != 0)
            {
                Console.WriteLine(resultNumber);
                Console.WriteLine(resultCount);
            }
            else
                Console.WriteLine("No");
            if (resultNumber == 7)
                Console.WriteLine("No");

     
        }
    }
}
