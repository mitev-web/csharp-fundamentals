using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            for (int i = N - 1; i >= 1; i--)
            {
                for (int j = 1; j < N; j++)
                {
                    if (i > j)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                for (int j = N-1; j > 1; j--)
                {
                    if (i >= j)
                    {
                        Console.Write(".");
                    }
                    else
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }
            for (int i = 1; i < ((2 * N) - 2);i++ )
            {
                if (i == N - 1)
                {
                    Console.Write("*");
                }
                else 
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
            }
        }
    }