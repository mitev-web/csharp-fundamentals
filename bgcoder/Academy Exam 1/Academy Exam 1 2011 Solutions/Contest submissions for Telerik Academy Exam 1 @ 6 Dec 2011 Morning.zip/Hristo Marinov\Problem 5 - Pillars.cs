using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            int[] a = new int[] {0,0,0,0,0,0,0,0};
            int temp;
            for (int i = 0; i < 8; i++)
            {
                temp = int.Parse(Console.ReadLine());
                int j = 0;
                while (temp>0)
                {
                    a[j] += temp % 2;
                    temp /= 2;
                    j++;
                }
            }
            int brl = 0, brr = 0,anskol=0,ansbr=0;
            bool flag = false;
            for (int i = 0; i < 8; i++)
            {
                brl = 0;
                brr = 0;
                for (int j = 0; j < i; j++)
                    brl+=a[j];
                for (int j = i + 1; j < 8; j++)
                    brr+=a[j];
                if (brr == brl)
                {
                    anskol = i;
                    ansbr = brr;
                    flag = true;
                }
            }
            if (flag == false) Console.WriteLine("No");
            else
                Console.WriteLine("{0}\n{1}", anskol, ansbr);
        }
    }
}
