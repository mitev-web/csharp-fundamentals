using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prob5_Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            // numbers (rows of the table)
            byte[] n = new byte[8];
            string input;
            for (int i = 0; i < 8; i++)
            {
                input = Console.ReadLine();
                n[i] = byte.Parse(input);
            }

            // columns of the table
            byte[] c = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                c[i] = 0;
                for (int j = 0; j < 8; j++)
                {
                    if ((n[j] & (1 << i)) > 0)
                    {
                        c[i]++;
                    }
                }

            }

            string output = "";
            for (int i = 7; i >= 0; i--)
            {
                int sumLeft = 0;
                for (int j = 7; j > i; j--)
                {
                    sumLeft += c[j];
                }

                int sumRight = 0;
                for (int j = i - 1; j >= 0; j--)
                {
                    sumRight += c[j];
                }

                if (sumLeft == sumRight)
                {
                    output = i + "\n" + sumLeft;
                    break;
                }
                else
                {
                    output = "No";
                }
            }

            Console.WriteLine(output);


        }
    }
}
