using System;

namespace ExamProblem3
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int hight = int.Parse(Console.ReadLine());
            int row = hight - 1;
            int col = 2 * (hight - 1) - 1;
            char[,] tree = new char[row, col];

            for (int a = 0; a < row; a++)
            {
                for (int b = 0; b < col; b++)
                {
                    tree[a,b]='.';
                }
                
            }
            for (int i = 0; i < row; i++)
            {
                for (int j = (col / 2 - i); j <= (col / 2 + i); j++)
                {
                    tree[i, j] = '*';
                }
            }
            
            for (int a = 0; a < row; a++)
            {
                for (int b = 0; b < col; b++)
                {
                    Console.Write(tree[a, b] );
                }
                Console.WriteLine();
            }
            for (int j = 0; j <col; j++)
            {
                if (j == col / 2)
                {
                    Console.Write('*');
                }
                else 
                {
                    Console.Write('.');
                }
            }
            Console.WriteLine();
        }
    }
}