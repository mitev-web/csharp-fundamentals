using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _05.pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            int[] n = new int[8];
            for (int i = 0; i < 8; i++)
            {
                line = Console.ReadLine();
                n[i] = int.Parse(line);   
            }

            int j = 0;
            int[,] b = new int[8, 8];
            for (int i = 0; i < 8; i++)
            {
                j = 0;
                do
                {
                    b[i,j] = n[i] % 2;
                    n[i] /= 2;
                    j++;
                } while (n[i]!=0);    
            }
            //int br=0;
            //for (int i = 0; i < 8; i++)
            //{
            //    for (j = 7; j >= 0; j--)
            //    {
            //        //           Console.Write(b[i,j]);
            //        if (b[i, j] == 1)
            //        {
            //            br++;
            //        }
            //    }
            //    //     Console.WriteLine();
            // }
            int k1 = 0;
            int sum11 = 0;
            int p = 0;
            int flag = 0;
            int k=1;
            do
            {
                int sum1 = 0;
                int sum2 = 0;
            for (int i = 0; i < 8; i++)
            {
                for (j = k-1; j >= 0; j--)
                {
                    sum1 += b[i, j];
                }
                for (j  = 7; j >k; j--)
                {
                    sum2 += b[i, j];
                }
            }
                if (sum2 == sum1 && sum1 != 0)
                {
                    k1 = k;
                    sum11 = sum1;
                    //Console.WriteLine("{0}", k);
                    //Console.WriteLine("{0}", sum1);
                    flag = 1;
                    p = k;
                 // break;
               }
               k++;
            }while(k!=8);
           
            if (flag==1)
            {
                Console.WriteLine(k1);
                Console.WriteLine(sum11);
            } 
           if(flag==0)
               Console.WriteLine("No");

           //for (int i = 0; i < 8; i++)
           //{
           //    for ( j = 7; j > p; j--)
           //    {
           //        Console.Write(b[i,j]);
           //    }
           //    Console.WriteLine();
           //}
           //for (int i = 0; i < 8; i++)
           //{
           //    for (j = p-1; j >=0; j--)
           //    {
           //        Console.Write(b[i,j]);   
           //    }
           //    Console.WriteLine();
           //}
            
          //  Console.WriteLine(br/2);

        }
    }
}
