using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Pillars
{
    static void Main(string[] args)
    {
        byte[,] matrix = new byte[8, 8];
        int input;

        for (int i = 0; i < 8; i++)
        {
            input = Int32.Parse(Console.ReadLine());
            for (int j = 0; j < 8; j++)
            {
                if ((input & (1 << j)) != 0)
                    matrix[i, 7-j] = 1;
            }
        }

        /*
        //Print
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                Console.Write(matrix[i, j]);
            }
            Console.WriteLine();
        }
         */
        
        int[] columnCount = new int [8];
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (matrix[j, i] == 1)
                    columnCount[i]++;
            }
        }
        
        /*
        // Print columnCount
        for (int i = 0; i < 8; i++)
    	{
			 Console.WriteLine("Column {0} :{1}", i, columnCount[i]);
		}
        */

        int sum1 = 0, sum2 = 0;
        for (int i = 0; i <8; i++)
        {
            sum1 = 0;
            sum2 = 0;
            for (int j = 0; j < i; j++)
            {
                sum1 += columnCount[j];
            }

            for (int j = i+1; j <8; j++)
            {
                sum2 += columnCount[j];
            }
            if (sum1 == sum2 /*&& sum1 > 0*/)
            {
                Console.WriteLine(7-i);
                Console.WriteLine(sum1);
                return;
            }
        }
        if (sum1 == sum2 && sum1 == 0)
        {
            Console.WriteLine("7\n0\n");
            return;
        }
        Console.WriteLine("No");
        
    }
}
