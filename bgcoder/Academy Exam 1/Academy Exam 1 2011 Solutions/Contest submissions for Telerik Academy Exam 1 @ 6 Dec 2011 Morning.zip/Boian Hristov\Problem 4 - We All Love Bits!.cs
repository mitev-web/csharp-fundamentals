using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Bits
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        for (int j = 1; j <= n; j++)
        {
            int a = int.Parse(Console.ReadLine());
            

        }
    }
}
