using System;

class WeAllLoveBits
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        int n = int.Parse(line), p;
        for (int k = 0; k < n; k++)
        {
            line = Console.ReadLine();
            p = int.Parse(line);
            Print(p);
        }

    }
    static void Print(int x)
    {
        int pInverted = x, pReversed = 0, pTemp = x;
        for (int i = 0; i < 32 && pTemp != 0; i++)
        {
            if ((pInverted & (1 << i)) == 0)
            {
                pInverted |= (1 << i);
            }
            else
            {
                pInverted &= ~(1 << i);
            }
            pTemp >>= 1;
        }
        pTemp = x;
        for (int j = 0; j < 32 && pTemp != 0; j++)
        {
            if ((pTemp & 1) == 1)
            {
                pReversed |= 1;
            }
            pReversed <<= 1;
            pTemp >>= 1;
        }
        pReversed >>= 1;
        Console.WriteLine((x ^ pInverted) & pReversed);
    }
}