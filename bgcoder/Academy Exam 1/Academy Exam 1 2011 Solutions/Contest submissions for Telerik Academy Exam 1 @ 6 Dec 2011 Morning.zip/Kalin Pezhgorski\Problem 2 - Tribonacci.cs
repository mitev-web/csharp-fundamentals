using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger first = int.Parse(Console.ReadLine()) ;
            BigInteger second = int.Parse(Console.ReadLine());
            BigInteger third = int.Parse(Console.ReadLine());
            BigInteger forth = 0 ;
            int n = int.Parse(Console.ReadLine()) ;
            for (int i = 3; i < n; i++)
            {
                forth = first + second + third;
                first = second;
                second = third;
                third = forth;
            }
            switch (n)
            {
                case 1:
                    {
                        Console.WriteLine(first);
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine(second);
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine(third);
                        break;
                    }
                default:
                    {
                        Console.WriteLine(forth);
                        break;
                    }
            }
        }
    }
}
