using System;
using System.Threading;
using System.Globalization;
 
namespace _5___Bytes
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-us");
            byte n = 8;
            byte[] myList = new byte[n];
            for (int i = 0; i < n; i++)
            {
                myList[i] = byte.Parse(Console.ReadLine());
            }
            int flag = 0;
            int counterLeft = 0;
            int counterRight = 0;
            int m = 0;
            int resultm = 0;
            int resultCount = 0;
            while (m <= 8)
            {
                for (int p = 0; p < n; p++)
                {
                    for (int j = 0; j < m; j++)
                    {
                        int mask = 1 << j;
                        int nAndMask = myList[p] & mask;
                        bool bit = ((nAndMask >> j) == 1) ? true : false;
                        if (bit)
                        {
                            counterLeft++;
                        }
                    }
                    for (int j = m + 1; j < n; j++)
                    {
                        int mask = 1 << j;
                        int nAndMask = myList[p] & mask;
                        bool bit = ((nAndMask >> j) == 1) ? true : false;
                        if (bit)
                        {
                            counterRight++;
                        }
                    }
                }
                if (counterLeft == counterRight)
                {
                    resultm = m;
                    resultCount = counterLeft;
                    flag = 1;
                    //   break;
                }
                counterLeft = 0;
                counterRight = 0;
                m++;
            }
            if (flag != 1)
            {
                Console.WriteLine("No");
            }
            else
            {
                Console.WriteLine(resultm);
                Console.WriteLine(resultCount);
            }
        }
 
    }
}