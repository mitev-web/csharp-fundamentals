using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class FirTree
{
    static void Main(string[] args)
    {
        int N = Int32.Parse(Console.ReadLine());
        int width = 1;
        for (int i = 2; i < N; i++)
		{
			width+=2;
		}
               
        // Print header
        int dots = (width - 1) / 2;
        for (int i = 0; i < dots; i++)
        {
            Console.Write(".");
        }
        Console.Write("*");
        for (int i = 0; i < dots; i++)
        {
            Console.Write(".");
        }
        Console.WriteLine();

        int curDots = 0;
        int curStars = 3;
        for (int i = 0; i < N - 2; i++)
        {
            curDots = (width - curStars) / 2;
            for (int j = 0; j < curDots; j++)
            {
                Console.Write(".");
            }

            for (int j = 0; j < curStars; j++)
            {
                Console.Write("*");
            }

            for (int j = 0; j < curDots; j++)
            {
                Console.Write(".");
            }
            Console.WriteLine();
            curStars += 2;
        }





        // Print footer
        dots = (width - 1) / 2;
        for (int i = 0; i < dots; i++)
        {
            Console.Write(".");
        }
        Console.Write("*");
        for (int i = 0; i < dots; i++)
        {
            Console.Write(".");
        }
        Console.WriteLine();


    }
}

