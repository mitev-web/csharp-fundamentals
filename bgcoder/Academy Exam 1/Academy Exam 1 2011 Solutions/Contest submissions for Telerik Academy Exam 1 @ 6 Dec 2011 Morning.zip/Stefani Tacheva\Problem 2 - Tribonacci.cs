using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Problem_2
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger sum = 0;
            if (n == 1)
            {
                sum = a;
            }
            if (n == 2)
            {
                sum = b;
            }
            if (n == 3) 
            {
                sum = c;
            }
            else
            {
                for (int i = 3; i < n; i++)
                {
                    sum = a + b + c;
                    a = b;
                    b = c;
                    c = sum;
                }
            }
                Console.WriteLine(sum);
               
            }
        }
    }
