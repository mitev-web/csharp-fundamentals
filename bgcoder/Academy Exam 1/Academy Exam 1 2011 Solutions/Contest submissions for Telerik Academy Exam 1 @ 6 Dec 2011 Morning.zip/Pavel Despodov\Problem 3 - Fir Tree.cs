using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = byte.Parse(Console.ReadLine());
            char[] arr1 = new char[n+(n-3)];
            char dot = '.';
            char[] arr2 = new char[n + (n - 3)];
          
            for (int i = 0; i < n+(n-3); i++)
            {
                arr2[i] = '.';
                arr2[n-2] = '*';
            }
            for (int i = 0; i < n+(n-3); i++)
            {
                arr1[i] = '.';
            }
          //  for (int i = 0; i < n-2; i++)
           // {
                for (int j = 0; j < n-1; j++)
                {
                    arr1[(n-2) + j] = '*';
                    arr1[(n - 2) - j] = '*';
                    Console.WriteLine(arr1);
                    
                }
                Console.WriteLine(arr2);
           
        }
    }
}
