using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bitwiseGuy
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int p = int.Parse(Console.ReadLine());
            int Pnew;
            int p1=0;
            int p2 = 0;
            int pfirst = 0;
            int psecond = 0;
            int countP = (int)Math.Ceiling(Math.Log(p)/Math.Log(2));
            
            int countPdiv21 = countP / 2;
            int countPdiv2 = countP / 2;
            if (countP % 2 != 0)
            {
                countPdiv2++;
                countPdiv21--;
            }
            p1 = (~p)&((int)Math.Pow(2,countP)-1);

            for (int i = 0, p21 = 0, mask = 0,tap = 0; i <= countPdiv21; i++)
            {
                mask = 1 << i;
                p21 = p & mask;
                tap = p21 << (countPdiv21 - i);
                pfirst = tap ^ pfirst;
            }
            if (countP % 2 != 0)
            {
                
                int check = 0;
                check = 1 << (countPdiv2 - 1);
                p2 = check ^ p2;
            }
            for (int i = countPdiv2, p21 = 0, mask = 0,tap = 0,  t = 1; i < countP; i++)
            {
                mask = 1 << i;
                p21 = p & mask;
                tap = p21 << (countPdiv2-t);
                psecond = tap ^ psecond;
                //psecond = p21 ^ psecond;
                t++;
            }
            pfirst = pfirst << (countPdiv2);
            psecond = psecond >> (countPdiv2);
            p2 = pfirst ^ psecond^p2;

            Pnew = ((p ^ p1) & p2);
            Console.WriteLine(Pnew);

        }
    }
}
