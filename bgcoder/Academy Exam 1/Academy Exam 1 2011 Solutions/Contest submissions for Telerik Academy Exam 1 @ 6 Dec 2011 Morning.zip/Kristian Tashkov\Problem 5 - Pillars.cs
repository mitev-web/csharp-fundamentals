using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem5
{
    class Program
    {
        static void Main(string[] args)
        {
            int temp;
            int[] bits = new int[10];
            for (int i = 0; i < 8; i++)
            {
                temp = Int32.Parse(Console.ReadLine());
                int position = 7;
                while (temp > 0)
                {
                    if (temp % 2 == 1) bits[position]++;
                    temp /= 2;
                    position--;
                }
            }
            int k;
            for (k = 0; k <8; k++)
            {
                int sum1=0,sum2=0;
                for (int i = 0; i < k; i++)
                    sum1 += bits[i];
                for (int i = k + 1; i < 8; i++)
                    sum2 += bits[i];
                if (sum1 == sum2)
                {
                    Console.WriteLine("{0}\n{1}",7-k,sum1);
                    break;
                }
            }
            if (k == 8) Console.WriteLine("No");

        }
    }
}
