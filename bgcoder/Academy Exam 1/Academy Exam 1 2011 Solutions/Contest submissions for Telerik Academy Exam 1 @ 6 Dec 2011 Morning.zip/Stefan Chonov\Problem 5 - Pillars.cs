using System;

namespace Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            string readN0 = Console.ReadLine();
            string readN1 = Console.ReadLine();
            string readN2 = Console.ReadLine();
            string readN3 = Console.ReadLine();
            string readN4 = Console.ReadLine();
            string readN5 = Console.ReadLine();
            string readN6 = Console.ReadLine();
            string readN7 = Console.ReadLine();

            byte n0 = byte.Parse(readN0);
            byte n1 = byte.Parse(readN1);
            byte n2 = byte.Parse(readN2);
            byte n3 = byte.Parse(readN3);
            byte n4 = byte.Parse(readN4);
            byte n5 = byte.Parse(readN5);
            byte n6 = byte.Parse(readN6);
            byte n7 = byte.Parse(readN7);

            byte[] allNumbers = 
            {
                n0, n1, n2, n3,
                n4, n5, n6, n7
            };

            byte[,] matrix = new byte[8, 8];
            int currentNNumber = 0;

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                currentNNumber = allNumbers[i];

                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if ((currentNNumber % 2) == 1)
                    {
                        matrix[i, j] = 1;
                    }

                    currentNNumber = currentNNumber / 2;
                }
            }

            int counter = 0;

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] == 1)
                    {
                        counter++;
                    }
                }
            }

            int getHalfOfCounteredBits = counter / 2;
            int countFilledPosition = 0;
            int countFilledAfter = 0;
            int savePillarPosition = int.MinValue;

            for (int i = matrix.GetLength(1) - 1; i >= 0; i--)
            {
                for (int j = 0; j < matrix.GetLength(0); j++)
                {
                    if (matrix[j, i] == 1)
                    {
                        countFilledPosition++;
                    }
                }

                if ((i - 1) >= 0)
                {
                    for (int j = 0; j < matrix.GetLength(0); j++)
                    {
                        if (matrix[j, i - 1] == 1)
                        {
                            countFilledAfter++;
                        }
                    }
                }

                if (countFilledPosition == getHalfOfCounteredBits)
                {
                    if (((counter - countFilledAfter) / 2 ) == countFilledPosition)
                    {
                        savePillarPosition = i - 1;
                        break;
                    }
                }

                countFilledAfter = 0;
            }

            if (savePillarPosition > int.MinValue)
            {
                Console.WriteLine(savePillarPosition);
                Console.WriteLine(countFilledPosition);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}