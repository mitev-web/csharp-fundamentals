using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int cx1, cx2, cx3, cy1, cy2, cy3, h, sx1, sy1, sx2, sy2;
            int sum =0, temp;

            sx1 = int.Parse(Console.ReadLine());
            sy1 = int.Parse(Console.ReadLine());
            sx2 = int.Parse(Console.ReadLine());
            sy2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cx1 = int.Parse(Console.ReadLine());
            cy1 = int.Parse(Console.ReadLine());
            cx2 = int.Parse(Console.ReadLine());
            cy2 = int.Parse(Console.ReadLine());
            cx3 = int.Parse(Console.ReadLine());
            cy3 = int.Parse(Console.ReadLine());
            /*sx1 = -6;
            sy1 = 6;
            sx2 = -11;
            sy2 = 3;
            h = 1;
            cx1 = -9;
            cy1 = -4;
            cx2 = -11;
            cy2 = -1;
            cx3 = 2;
            cy3 = 2;*/

            if (sx1 > sx2)
            {
                temp = sx1;
                sx1 = sx2;
                sx2 = temp;
                temp = sy1;
                sy1 = sy2;
                sy1 = temp;
            }
            //100
            if (cx1 > sx1 && cx1 < sx2 && (2 * h - cy1) < sy1 && (2 * h - cy1) > sy2)
            {
                sum += 100;
            }
            if (cx2 > sx1 && cx2 < sx2 && (2 * h - cy2) < sy1 && (2 * h - cy2) > sy2)
            {
                sum += 100;
            }
            if (cx3 > sx1 && cx3 < sx2 && (2 * h - cy3) < sy1 && (2 * h - cy3) > sy2)
            {
                sum += 100;
            }

            //25
            if ((sx1 == cx1) && ((2 * h - cy1) == sy1 || (2 * h - cy1) == sy2))
            {
                sum += 25;
            }
            if ((sx2 == cx1) && ((2 * h - cy1) == sy1 || (2 * h - cy1) == sy2))
            {
                sum += 25;
            }

            if ((sx1 == cx2) && ((2 * h - cy2) == sy1 || (2 * h - cy2) == sy2))
            {
                sum += 25;
            }
            if ((sx2 == cx2) && ((2 * h - cy2) == sy1 || (2 * h - cy2) == sy2))
            {
                sum += 25;
            }

            if ((sx1 == cx3) && ((2 * h - cy3) == sy1 || (2 * h - cy3) == sy2))
            {
                sum += 25;
            }
            if ((sx2 == cx3) && ((2 * h - cy3) == sy1 || (2 * h - cy3) == sy2))
            {
                sum += 25;
            }

            //50
            if ((sx1 == cx1 || sx2 == cx1) && (2 * h - cy1) > sy2 && (2 * h - cy1) < sy1)
            {
                sum += 50;
            }
            if (((2 * h - cy1) == sy1 || (2 * h - cy1) == sy2) && cx1 > sx1 && cx1 < sx2)
            {
                sum += 50;
            }

            if ((sx1 == cx2 || sx2 == cx2) && (2 * h - cy2) > sy2 && (2 * h - cy2) < sy1)
            {
                sum += 50;
            }
            if (((2 * h - cy2) == sy1 || (2 * h - cy2) == sy2) && cx2 > sx1 && cx2 < sx2)
            {
                sum += 50;
            }

            if ((sx1 == cx3 || sx2 == cx3) && (2 * h - cy3) > sy2 && (2 * h - cy3) < sy1)
            {
                sum += 50;
            }
            if (((2 * h - cy3) == sy1 || (2 * h - cy3) == sy2) && cx3 > sx1 && cx3 < sx2)
            {
                sum += 50;
            }


            Console.WriteLine("{0}%", sum);
        }
    }
}
