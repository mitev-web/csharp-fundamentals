using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            int xa = int.Parse(Console.ReadLine());
            int ya = int.Parse(Console.ReadLine());
            int xb = int.Parse(Console.ReadLine());
            int yb = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
            int cx1s = cx1;
            int cy1s = h + (Math.Abs(cy1) + h);
            int cx2s = cx2;
            int cy2s = h + (Math.Abs(cy2) + h);
            int cx3s = cx3;
            int cy3s = h + (Math.Abs(cy3) + h);
            int count = 0;
            int x1;
            int y1;
            int x2;
            int y2;
            int x3;
            int y3;
            int x4;
            int y4;
            if (Math.Abs(xa) > Math.Abs(xb))
            {
                x1 = xa;
                y1 = ya;
                x2 = xb;
                y2 = yb;
                x3 = x2;
                y3 = y2;
                x4 = x2;
                y4 = y1;
            }
            else
            {
                x1 = xb;
                y1 = ya;
                x2 = xa;
                y2 = yb;
                x3 = x2;
                y3 = y2;
                x4 = x2;
                y4 = y1;
                

                
            }
            if (((cx1s == x1) && (cy1s == y1)) || ((cx1s == x2) && (cy1s == y2)) || ((cx1s == x3) && (cy1s == y3)) || ((cx1s == x4) && (cy1s == y4)))
            {
                count = count + 25;
            }
            if (((cx2s == x1) && (cy2s == y1)) || ((cx2s == x2) && (cy2s == y2)) || ((cx2s == x3) && (cy2s == y3)) || ((cx2s == x4) && (cy2s == y4)))
            {
                count = count + 25;
            }
            if (((cx3s == x1) && (cy3s == y1)) || ((cx3s == x2) && (cy3s == y2)) || ((cx3s == x3) && (cy3s == y3)) || ((cx3s == x3) && (cy3s == y3)))
            {
                count = count + 25;
            }
            if((Math.Abs(cx1s)<Math.Abs(x1))&&(Math.Abs(cx1s)>Math.Abs(x2))&&(cy1s == y1))
            {
                count = count + 50;
            }
            if((Math.Abs(cx1s)<Math.Abs(x1))&&(Math.Abs(cx1s)>Math.Abs(x2))&&(cy1s == y2))
            {
                count = count + 50;
            }
            if((Math.Abs(cy1s)<Math.Abs(y1))&&(Math.Abs(cy1s)>Math.Abs(y2))&&(cx1s == x1))
            {
                count = count + 50;
            }
            if((Math.Abs(cy1s)<Math.Abs(y1))&&(Math.Abs(cy1s)>Math.Abs(y2))&&(cx1s == x2))
            {
                count = count + 50;
            }
            if ((Math.Abs(cx2s) < Math.Abs(x1)) && (Math.Abs(cx2s) > Math.Abs(x2)) && (cy2s == y1))
            {
                count = count + 50;
            }
            if ((Math.Abs(cx2s) < Math.Abs(x1)) && (Math.Abs(cx2s) > Math.Abs(x2)) && (cy2s == y2))
            {
                count = count + 50;
            }
            if ((Math.Abs(cy2s) < Math.Abs(y1)) && (Math.Abs(cy2s) > Math.Abs(y2)) && (cx2s == x1))
            {
                count = count + 50;
            }
            if ((Math.Abs(cy2s) < Math.Abs(y1)) && (Math.Abs(cy2s) > Math.Abs(y2)) && (cx2s == x2))
            {
                count = count + 50;
            }
            if ((Math.Abs(cx3s) < Math.Abs(x1)) && (Math.Abs(cx3s) > Math.Abs(x2)) && (cy3s == y1))
            {
                count = count + 50;
            }
            if ((Math.Abs(cx3s) < Math.Abs(x1)) && (Math.Abs(cx3s) > Math.Abs(x2)) && (cy3s == y2))
            {
                count = count + 50;
            }
            if ((Math.Abs(cy3s) < Math.Abs(y1)) && (Math.Abs(cy3s) > Math.Abs(y2)) && (cx3s == x1))
            {
                count = count + 50;
            }
            if ((Math.Abs(cy3s) < Math.Abs(y1)) && (Math.Abs(cy3s) > Math.Abs(y2)) && (cx3s == x2))
            {
                count = count + 50;
            }
            if((Math.Abs(cx1s)<Math.Abs(x1))&&(Math.Abs(cx1s)>Math.Abs(x2))&&(Math.Abs(cy1s)<Math.Abs(y1))&&(Math.Abs(cy1s)>Math.Abs(y2)))
            {
                count = count + 100;
            }
            if((Math.Abs(cx2s)<Math.Abs(x1))&&(Math.Abs(cx2s)>Math.Abs(x2))&&(Math.Abs(cy2s)<Math.Abs(y1))&&(Math.Abs(cy2s)>Math.Abs(y2)))
            {
                count = count + 100;
            }
            if((Math.Abs(cx3s)<Math.Abs(x1))&&(Math.Abs(cx3s)>Math.Abs(x2))&&(Math.Abs(cy3s)<Math.Abs(y1))&&(Math.Abs(cy3s)>Math.Abs(y2)))
            {
                count = count + 100;
            }
                
            Console.WriteLine(count+"%");
           

        }
    }
}