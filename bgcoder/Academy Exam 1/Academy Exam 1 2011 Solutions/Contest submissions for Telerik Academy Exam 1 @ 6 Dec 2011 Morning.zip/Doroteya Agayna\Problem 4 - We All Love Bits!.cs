using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem4
{
    class Program
    {
        
        static int GetBitValue(int number, int index)
        {
            int mask = 0;
            mask = 1 << index;
            number = (number & mask) >> index;
            return number;
        }

        static int SetBitTo0(int number, int index)
        {
            int mask = 0;
            mask = ~(1 << index);
            number = number & mask;
            return number;
        }

        static int SetBitTo1(int number, int index)
        {
            int mask = 0;
            mask = 1 << index;
            number = number | mask;
            return number;
        }
        
        static int Reversed(int number)
        {
            int first, last;
            string temp = Convert.ToString(number, 2);
            int i, j;
            for (i = 0, j = temp.Length - 1; j > i; i++, j--)
            {
                first = GetBitValue(number, i);
                last = GetBitValue(number, j);
                if (first > last)
                {
                    number = SetBitTo0(number, i);
                    number = SetBitTo1(number, j);
                }
                else if (first < last)
                {
                    number = SetBitTo1(number, i);
                    number = SetBitTo0(number, j);
                }
            }
            return number;
        }

        static void Main(string[] args)
        {
            int[] numbers;
            int i, n;
            int temp;
            n = int.Parse(Console.ReadLine());
            numbers = new int[n];
            for (i = 0; i < n; i++)
            {
                temp = int.Parse(Console.ReadLine());
                numbers[i] = Convert.ToInt32(Reversed(temp));
            }
            for (i = 0; i < n; i++)
            {
                Console.WriteLine(numbers[i]);
            }
        }
    }
}
