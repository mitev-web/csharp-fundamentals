using System;

namespace _03.PrintFirTree
{
    class PrintFirTree
    {
        static void Main(string[] args)
        {
            byte N = byte.Parse(Console.ReadLine());
            byte asteriskCount = 1;
            byte asteriskCountCopy = asteriskCount;
            byte printed;
            byte height = N;
            byte width = (byte)(2 * N - 3);

            for (int column = 1; column <= width; column++)
            {
                if (column == N - 1)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }

            Console.WriteLine();

            for (int row = 2; row <= height-1; row++)
            {
                asteriskCount += 2;
                asteriskCountCopy = asteriskCount;
                printed = 0;
                for (int column = 1; column <= width; column++)
                {
                    if (column == N - row + printed && asteriskCountCopy > 0)
                    {
                        Console.Write("*");
                        asteriskCountCopy--;
                        printed++;
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();
            }

            for (int column = 1; column <= width; column++)
            {
                if (column == N - 1)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }

            Console.WriteLine();
        }
    }
}
