using System;
using System.Numerics;


namespace _2_Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger a, b, c;
            int n;
            c = BigInteger.Parse(Console.ReadLine());
            b = BigInteger.Parse(Console.ReadLine());
            a = BigInteger.Parse(Console.ReadLine());
            n = int.Parse(Console.ReadLine());

            if (n==1)
            {
                Console.WriteLine(c);                
            }
            if (n==2)
            {
                Console.WriteLine(b);
            }
            if (n==3)
            {
                Console.WriteLine(a);
            }
            int counter = 3;
            while (counter>=3 && counter<n)
            {
                BigInteger x = a; 
                a = a + b + c;
                c = b;
                b = x;                               
                counter++;
                if (counter==n)
                {
                    Console.WriteLine(a);
                }
            }
        }
    }
}
