using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task7
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger n1 = BigInteger.Parse(Console.ReadLine());
            BigInteger n2 = BigInteger.Parse(Console.ReadLine());
            BigInteger n3 = BigInteger.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            BigInteger s = 0;
            if (n > 3)
            {
                for (int i = 0; i < (n - 3); i++)
                {
                    s = n1 + n2 + n3;
                    n1 = n2;
                    n2 = n3;
                    n3 = s;
                }
                Console.WriteLine(s);
            }
            else
            {
                switch (n)
                {
                    case 1: Console.WriteLine(n1); break;
                    case 2: Console.WriteLine(n2); break;
                    case 3: Console.WriteLine(n3); break;
                    default:
                        break;
                }
            }
        }
    }
}