using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fir_tree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int c = n - 2;
            int width = (c * 2) + 1;
            

            for (int i = 1; i < n; i++)
            {
                for (int z = 0; z < width; z++)
                {
                    if (z <= ((width/2) - i))  
                    {
                        Console.Write(".");
                    }

                    if (z >= ((width / 2) + i))
                    {
                        Console.Write(".");
                    }

                    if ((z > ((width / 2) - i)) && (z < ((width / 2) + i)))
                    {
                        Console.Write("*");
                    }                   
                }

                Console.WriteLine();
            }
            
            int final = 0;
            while (final < 1)
            {
                for (int z = 0; z < width; z++)
                {
                    if (z <= ((width/2) - 1))  
                    {
                        Console.Write(".");
                    }

                    if (z >= ((width / 2) + 1))
                    {
                        Console.Write(".");
                    }

                    if ((z > ((width / 2) - 1)) && (z < ((width / 2) + 1)))
                    {
                        Console.Write("*");
                    }
                    final++;
                }
                Console.WriteLine();
            }
           

            
        }
    }
}
