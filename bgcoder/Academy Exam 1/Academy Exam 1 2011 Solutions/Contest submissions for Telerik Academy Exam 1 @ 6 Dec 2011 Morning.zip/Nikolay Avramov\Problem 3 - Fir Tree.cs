using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ecam6DecChristmasTree
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int n = int.Parse(Console.ReadLine());
            int p = 1;
            int p1 = 1;
            
            char star = '\x002A';
            char dot = '\x002E';
            
            for (int i = 1; i <= n; i++)
            {
                
                if(i!=n)
                {
                    p = 0;
                    while (p <= n-2-i)
                    {
                        Console.Write(dot);
                        p++;
                    }
                    p = 1;
                    while (p < 2*i)
                    {
                        Console.Write(star);
                        p++;
                    }
                    p1 = 0;
                    while (p1 <= n-2-i)
                    {
                        Console.Write(dot);
                        p1++;
                    }
                    Console.Write("\n");
                }
                else if(i==n-1)
                {
                    p = 0;
                    while (p <= 2*(n - 2 )+ i)
                    {
                        Console.Write(star);
                        p++;
                    }
                }
                else if (i == n)
                { 
                    p=1;
                    while (p <= n-2)
                    {
                        Console.Write(dot);
                        p++;
                    }
                    Console.Write(star);
                    p = 1;
                    while (p <= n - 2)
                    {
                        Console.Write(dot);
                        p++;
                    }
                    Console.WriteLine();
                }


            }
            
        }
    }
}
