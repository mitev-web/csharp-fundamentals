using System;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            string readN = Console.ReadLine();
            ushort n = ushort.Parse(readN);

            uint[] allPElements = new uint[n];

            for (int i = 0; i < n; i++)
            {
                allPElements[i] = uint.Parse(Console.ReadLine());
            }

            uint[] saveAllP2Result = new uint[n];
            uint currentP = 0;
            uint currentP2 = 0;
            uint p2 = 0;
            uint mask = 0;

            for (int i = 0; i < n; i++)
            {
                currentP2 = allPElements[i] ^ uint.MaxValue;
                currentP = allPElements[i];

                while (currentP != 0)
                {
                    mask = mask << 1;
                    mask = mask | 1;                    
                    currentP = currentP / 2;
                }

                p2 = currentP2 & mask;
                saveAllP2Result[i] = p2;
                p2 = 0;
            }

            uint[] saveAllP3Result = new uint[n];

            // Pnew
            for (int i = 0; i < n; i++)
            {
                uint tempP = allPElements[i];
                uint pNew = RevertBits(tempP);
                saveAllP3Result[i] = pNew;

                pNew = 0;
            }

            uint[] saveAllPNewResults = new uint[n];

            for (int i = 0; i < n; i++)
            {
                saveAllPNewResults[i] = (allPElements[i] ^ saveAllP2Result[i]) & saveAllP3Result[i];
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(saveAllPNewResults[i]);
            }
        }

        private static uint RevertBits(uint number)
        {
            uint tempP = number;
            uint pNew = 0;
            while (tempP != 0)
            {
                pNew = pNew << 1;
                if ((tempP % 2) == 1)
                {
                    pNew = pNew | 1;
                }

                tempP = tempP / 2;                
            }

            return pNew;
        }
    }
}