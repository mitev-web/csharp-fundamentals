using System;
using System.Linq;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            for (int i = 1; i <= N; i++)
            {
                for (int j = 1; j <= (2 * N - 3); j++)
                {
                    if ((i == 1 || i == N) && j == (N - 1))
                    {
                        Console.Write("*");
                    }
                    else if (i != 1 && i != N && (N - i) <= j && j <= (N + i - 2))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine();          
            }          
        }
    }
}
