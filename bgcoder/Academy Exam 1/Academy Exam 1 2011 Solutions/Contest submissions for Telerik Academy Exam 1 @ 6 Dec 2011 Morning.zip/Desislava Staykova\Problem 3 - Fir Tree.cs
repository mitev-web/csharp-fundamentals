using System;

namespace FirTree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int d = n - 5;
            char[,] array = new char[n, n + d + 2];
         
            int k,l;
            for (int i = 0; i < n; i++) 
            {
                for (int j = 0; j<d+n+2; j++) 
                {
                    for (k = 3, l = 3; l <= n + 3; l++) 
                    {
                        l++;
                        if (i + j >= k && i + j <= l && j <= i + 3) { array[i, j] = '*'; }
                        else { array[i, j] = '.'; } 
                    }
                    if (j == n  / 2+1) 
                    { array[i, j] = '*'; }
                    if (i == n - 1 )
                    { if(j != n / 2 + 1) array[i, j] = '.';
                    else { array[i, j] = '*'; }}
                    
                    Console.Write(array[i, j]);
                } Console.WriteLine();
            }


        }

    }
}
