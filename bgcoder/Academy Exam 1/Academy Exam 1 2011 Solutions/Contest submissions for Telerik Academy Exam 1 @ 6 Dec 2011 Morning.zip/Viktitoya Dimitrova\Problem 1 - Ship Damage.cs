using System;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());

           /* if (Math.Abs(x1) > Math.Abs(x2))
            {
                int temp = x1;
                x1 = x2;
                x2 = temp;
            }
            if (Math.Abs(y1) > Math.Abs(y2))
            {
                int temp = y1;
                y1 = y2;
                y2 = temp;
            }*/

            int h =  int.Parse(Console.ReadLine());

            y1 = y1 - h;
            y2 = y2 - h;

            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            cY1 = h - cY1;
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            cY2 = h - cY2;
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            cY3 = h - cY3;

            int result=0;


            if (cX1 < x1 && cX1 > x2 && cY1 > y1 && cY1 < y2 ||
                cX2 < x1 && cX2 > x2 && cY2 > y1 && cY2 < y2 || 
                cX3 < x1 && cX3 > x2 && cY3 > y1 && cY3 < y2)
            {
                result += 100;
            }
            if (cX1 < x1 && cX1 > x2 && (cY1 == y1 || cY1 == y2)||
                    cX2 < x1 && cX2 > x2 && (cY2 == y1 || cY2 == y2)||
                    cX3 < x1 && cX3 > x2 && (cY3 == y1 || cY3 == y2))
                {
                result += 50;
            }
            
            if (cY1 > y1 && cY1 < y2 && (cX1 == x1 && cX1 == x2)||
                     cY2 > y1 && cY2 < y2 && (cX2 == x1 && cX2== x2)||
                     cY3 > y1 && cY3 < y2 && (cX3 == x1 && cX3 == x2))
            {
                result += 50;
            }
            if ((cX1 == x1 || cX1 == x2) && (cY1 == y1 || cY1 == y2)||
                (cX2 == x1 || cX2 == x2) && (cY2 == y1 || cY2 == y2)||
                (cX3 == x1 || cX3 == x2) && (cY3 == y1 || cY3 == y2))
            {
                result += 25;
            }
            Console.WriteLine(result + "%");
            }
        }
    }
