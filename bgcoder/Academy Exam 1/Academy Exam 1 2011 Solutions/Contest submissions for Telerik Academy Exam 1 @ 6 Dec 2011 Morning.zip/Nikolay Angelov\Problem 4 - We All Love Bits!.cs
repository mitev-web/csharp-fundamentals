using System;

namespace ex4
{
    class Program
    {
        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] numbers = new int[n];
            for (int i = 0; i < n; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                int a = numbers[i];
                string b = Convert.ToString(a, 2); // convert
                b = ReverseString(b);
                Console.WriteLine(Convert.ToInt32(b, 2)); // print
            }
        }
    }
}
