using System;
using System.Numerics;

namespace Task02_Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)   
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            if (N < 1 || N > 15000)
            {
                return;
            }
            BigInteger tN = 0;
            if (N == 1)
            {
                Console.WriteLine(t1);
            }
            if (N == 2)
            {
                Console.WriteLine(t2);
            }
            if (N == 3)
            {
                Console.WriteLine(t3);
            }
            else if (N != 1 && N != 2 && N != 3)
            {
                for (int i = 0; i < N - 3; i++)
                {
                    tN = t1 + t2 + t3;
                    t1 = t2;
                    t2 = t3;
                    t3 = tN;
                }
                Console.WriteLine(tN);
            }
        }
    }
}
