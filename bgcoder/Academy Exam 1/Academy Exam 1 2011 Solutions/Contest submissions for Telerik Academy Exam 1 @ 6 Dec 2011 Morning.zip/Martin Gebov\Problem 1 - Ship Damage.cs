using System;

class ShipDamage
{
    static void Main(string[] args)
    {
        int Sx1, Sy1, Sx2, Sy2, H, Cx1, Cy1, Cx2, Cy2, Cx3, Cy3;
        int shipWidth, shipHeight;

        Sx1 = int.Parse(Console.ReadLine());
        Sy1 = int.Parse(Console.ReadLine());
        Sx2 = int.Parse(Console.ReadLine());
        Sy2 = int.Parse(Console.ReadLine());
        H = int.Parse(Console.ReadLine());
        Cx1 = int.Parse(Console.ReadLine());
        Cy1 = int.Parse(Console.ReadLine());
        Cx2 = int.Parse(Console.ReadLine());
        Cy2 = int.Parse(Console.ReadLine());
        Cx3 = int.Parse(Console.ReadLine());
        Cy3 = int.Parse(Console.ReadLine());

     

        if (H > 0)
        {
            Cy3 = Cy3 - H;
            Cy2 = Cy2 - H;
            Cy1 = Cy1 - H;

            Sy1 = Sy1 - H;
            Sy2 = Sy2 - H;
        }
        else if (H < 0)
        {
            Cy3 = Cy3 + H;
            Cy2 = Cy2 + H;
            Cy1 = Cy1 + H;

            Sy1 = Sy1 + H;
            Sy2 = Sy2 + H;
        }

        Sx1 = Math.Abs(Sx1);
        Sx2 = Math.Abs(Sx2);
        Sy1 = Math.Abs(Sy1);
        Sy2 = Math.Abs(Sy2);
        H = Math.Abs(H);
        Cx1 = Math.Abs(Cx1);
        Cy1 = Math.Abs(Cy1);
        Cx2 = Math.Abs(Cx2);
        Cy2 = Math.Abs(Cy2);
        Cx3 = Math.Abs(Cx3);
        Cy3 = Math.Abs(Cy3);

        shipWidth = Math.Abs(Sx1 - Sx2);
        shipHeight = Math.Abs(Sy1 - Sy2);
        int shipDamage = 0;
        
       
        Sx1=Math.Min(Sx1, Sx2);
        Sy1 = Math.Min(Sy1, Sy2);
      

        if ((Cx1 == Sx1 && Cy1 == Sy1) || (Cx1 == Sx1 + shipWidth && Cy1 == Sy1 + shipHeight) || (Cx1 == Sx1 + shipWidth && Cy1 == Sy1) || (Cx1 == Sx1 + shipWidth && Cy1 == Sy1 + shipHeight))
        {
            shipDamage += 25;
        }
        if ((Cx1 > Sx1 && Cx1 < Sx1 +shipWidth && Cy1 == Sy1) || (Cx1 > Sx1 && Cx1 < Sx1 +shipWidth && Cy1 == Sy1+ shipHeight))
        {
            shipDamage += 50;
        }
        if ((Cy1 > Sy1 && Cy1 < Sy1 +shipHeight && Cx1 == Sx1) || (Cy1 > Sy1 && Cy1 < Sy1 +shipHeight && Cx1 == Sx1+ shipWidth))
        {
            shipDamage += 50;
        }
        if (Cx1 > Sx1 && Cx1 < Sx1 + shipWidth && Cy1 > Sy1 && Cy1 < Sy1 + shipHeight)
        {
            shipDamage +=100;
        }

        if ((Cx2 == Sx1 && Cy2 == Sy1) || (Cx2 == Sx1 + shipWidth && Cy2 == Sy1 + shipHeight) || (Cx2 == Sx1 + shipWidth && Cy2 == Sy1) || (Cx2 == Sx1 + shipWidth && Cy2 == Sy1 + shipHeight))
        {
            shipDamage += 25;
        }
        if ((Cx2 > Sx1 && Cx2 < Sx1 + shipWidth && Cy2 == Sy1) || (Cx2 > Sx1 && Cx2 < Sx1 + shipWidth && Cy2 == Sy1 + shipHeight))
        {
            shipDamage += 50;
        }
        if ((Cy2 > Sy1 && Cy2 < Sy1 + shipHeight && Cx2 == Sx1) || (Cy2 > Sy1 && Cy2 < Sy1 + shipHeight && Cx2 == Sx1 + shipWidth))
        {
            shipDamage += 50;
        }
        if (Cx2 > Sx1 && Cx2 < Sx1 + shipWidth && Cy2 > Sy1 && Cy2 < Sy1 + shipHeight)
        {
            shipDamage += 100;
        }

        if ((Cx3 == Sx1 && Cy3 == Sy1) || (Cx3 == Sx1 + shipWidth && Cy3 == Sy1 + shipHeight) || (Cx3 == Sx1 + shipWidth && Cy3 == Sy1) || (Cx3 == Sx1 + shipWidth && Cy3 == Sy1 + shipHeight))
        {
            shipDamage += 25;
        }
        if ((Cx3 > Sx1 && Cx3 < Sx1 + shipWidth && Cy3 == Sy1) || (Cx3 > Sx1 && Cx3 < Sx1 + shipWidth && Cy3 == Sy1 + shipHeight))
        {
            shipDamage += 50;
        }
        if ((Cy3 > Sy1 && Cy3 < Sy1 + shipHeight && Cx3 == Sx1) || (Cy3 > Sy1 && Cy3 < Sy1 + shipHeight && Cx3 == Sx1 + shipWidth))
        {
            shipDamage += 50;
        }
        if (Cx3 > Sx1 && Cx3 < Sx1 + shipWidth && Cy3 > Sy1 && Cy3 < Sy1 + shipHeight)
        {
            shipDamage += 100;
        }

        Console.WriteLine(shipDamage+"%");



    }
}
