using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            short n, width= 0;
            n = short.Parse(Console.ReadLine());
            uint[] numbers = new uint[n];
            uint[] invertededNumbers = new uint[n];
            uint[] reversedNumbers = new uint[n];
            uint currentNumber;

            for (int i = 0; i < n; i++)
            {
                numbers[i] = (uint) int.Parse(Console.ReadLine());
                currentNumber = numbers[i];
                while (currentNumber != 0)
                {
                    currentNumber = currentNumber >> 1;
                    width++; 
                }
                currentNumber = numbers[i];
                currentNumber = currentNumber << (32 - width);
                invertededNumbers[i] = ~currentNumber;
                invertededNumbers[i] = invertededNumbers[i] >> (32 - width);
                currentNumber = numbers[i];

                while (currentNumber > 0)
                {
                    int mask = 1 << 0;
                    uint numberAndMask = currentNumber & (uint)mask;
                    reversedNumbers[i] += numberAndMask;
                    reversedNumbers[i] = reversedNumbers[i] << 1;
                    currentNumber = currentNumber >> 1;
                    
                }
                reversedNumbers[i] >>= 1;                
                width = 0;

                numbers[i] = (numbers[i] ^ invertededNumbers[i]) & reversedNumbers[i];
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(numbers[i]);
            }          
        }
    }
}
