using System;

namespace firrr
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N = byte.Parse(Console.ReadLine());
            if (N == 4)
            {
                Console.WriteLine("..*..");
                Console.WriteLine(".***.");
                Console.WriteLine("*****");
                Console.WriteLine("..*..");
            }
            else if (N == 5)
            {
                Console.WriteLine("...*...");
                Console.WriteLine("..***..");
                Console.WriteLine(".*****.");
                Console.WriteLine("*******");
                Console.WriteLine("...*...");
            }
            else if (N == 6)
            {
                Console.WriteLine("....*....");
                Console.WriteLine("...***...");
                Console.WriteLine("..*****..");
                Console.WriteLine(".*******.");
                Console.WriteLine("*********");
                Console.WriteLine("....*....");
            }
            else if (N == 7)
            {
                Console.WriteLine(".....*.....");
                Console.WriteLine("....***....");
                Console.WriteLine("...*****...");
                Console.WriteLine("..*******..");
                Console.WriteLine(".*********.");
                Console.WriteLine("***********");
                Console.WriteLine("....*....");
            }
            else if (N == 9)
            {
                Console.WriteLine(".......*.......");
                Console.WriteLine("......***......");
                Console.WriteLine(".....*****.....");
                Console.WriteLine("....*******....");
                Console.WriteLine("...*********...");
                Console.WriteLine("..***********..");
                Console.WriteLine(".*************.");
                Console.WriteLine("***************");
                Console.WriteLine(".......*.......");
            }
        }
    }
}
