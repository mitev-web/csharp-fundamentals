using System;


namespace Task03_FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int starPosition = (2 * n - 3) / 2 + 1;
            int k = starPosition;
            int p = starPosition;
            for (int i = 0; i < n; i++)
            {

                for (int j = 1; j <= 2*n - 3; j++)
                {



                    if (j >= k && j <= p && k >= 1 && p <= 2*n -3)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        if (j == starPosition)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                     
                    
      
                   
                }
                k--;
                p++;
                Console.WriteLine();
            }
        }
    }
}
