using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger current = 1;
            BigInteger last = 1;
            BigInteger beforeLast = 1;
            BigInteger beforeBeforeLast = 0;

            string input;
            input = Console.ReadLine();
            beforeBeforeLast = BigInteger.Parse(input);
            input = Console.ReadLine();
            beforeLast = BigInteger.Parse(input); 
            input = Console.ReadLine();
            last = BigInteger.Parse(input);

            current = last + beforeLast + beforeBeforeLast;

            input = Console.ReadLine();
            int n = int.Parse(input);

            if (n == 1)
            {
                Console.WriteLine(beforeBeforeLast);
                return;
            }
            if (n == 2)
            {
                Console.WriteLine(beforeLast);
                return;
            }
            if (n == 3)
            {
                Console.WriteLine(last);
            }

            for (int i = 0; i < n - 3; i++)
            {
                current = last + beforeLast + beforeBeforeLast;
                beforeBeforeLast = beforeLast;
                beforeLast = last;
                last = current;
            }

            Console.WriteLine(current);
        }
    }
}
