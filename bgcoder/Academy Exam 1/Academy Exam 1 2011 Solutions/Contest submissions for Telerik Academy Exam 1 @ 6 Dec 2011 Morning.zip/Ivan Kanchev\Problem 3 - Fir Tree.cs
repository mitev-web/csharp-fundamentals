using System;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int height = n;
        int middle;
        int bottom;
        if (n % 2 == 0)
        {
            middle = n-1;
            bottom = middle*2 - 1;
        }
        else
        {
            middle = n-1;
            bottom = middle*2 - 1;
        }
        int position = 1;
        for (int i = 0; i < n; i++)
        {
            for (int j = 1; j <= bottom; j++)
            {
                if (i < n - 1)
                {
                    if (i == 0)
                    {
                        if (j == middle)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                    else
                    {
                        if (j <= middle - i - 1 || j >= middle + i + 1)
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                    }
                }
                else
                {
                    if (j == middle)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
            }
            Console.WriteLine();
        }
    }
}
