using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task2Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            ushort n = ushort.Parse(Console.ReadLine());
            BigInteger c = 0;
            for (uint i = 3; i < n; i++)
            {
                c = t1 + t2 + t3;
                
                t1 = t2;
                t2 = t3;
                t3 = c;

            }
            Console.WriteLine(c);
            
        }
    }
}