using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TelerikExam
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
            int sum = 0;
            if (sX1 > sX2)
            {
                int tempX1;
                tempX1 = sX2;
                sX2 = sX1;
                sX1 = tempX1;
            }
            cY1 = (h + h - cY1);
            cY2 = (h + h - cY2);
            cY3 = (h + h - cY3);
            bool flag = false;
            if (((cY1 == sY1) && (cX1 == sX1 || cX1 == sX2)) || ((cY1 == sY2) && (cX1 == sX1 || cX1 == sX2)))
            {
                sum += 25;
                flag = true;
            }
            else if (((cX1 == sX1 || cX1 == sX2) && (cY1 < sY1 && cY1 > sY2)) ||
                ((cX1 > sX1 && cX1 < sX2) && (cY1 == sY1 || cY1 == sY2)))
            {
                sum += 50;
                flag = true;
            }
            else if ((cY1 < sY1) && (cX1 > sX1) && (cX1 < sX2) && (cY1 > sY2))
            {
                sum += 100;
            }


            if (((cY2 == sY1) && (cX2 == sX1 || cX2 == sX2)) || ((cY2 == sY2) && (cX2 == sX1 || cX2 == sX2)))
            {
                sum += 25;
                flag = true;
            }
            else if (((cX2 == sX1 || cX2 == sX2) && (cY2 < sY1 && cY2 > sY2)) ||
                ((cX2 > sX1 && cX2 < sX2) && (cY2 == sY1 || cY2 == sY2)))
            {
                sum += 50;
            }
            else if ((cY2 < sY1) && (cX2 > sX1) && (cX2 < sX2) && (cY2 > sY2))
            {
                sum += 100;
            }

            if (((cY3 == sY1) && (cX3 == sX1 || cX3 == sX2)) || ((cY3 == sY2) && (cX3 == sX1 || cX3 == sX2)))
            {
                sum += 25;
                flag = true;
            }
            else if (((cX3 == sX1 || cX3 == sX2) && (cY3 < sY1 && cY3 > sY2)) ||
                ((cX3 > sX1 && cX3 < sX2) && (cY3 == sY1 || cY3 == sY2)))
            {
                sum += 50;
            }
            else if ((cY3 < sY1) && (cX3 > sX1) && (cX3 < sX2) && (cY3 > sY2))
            {
                sum += 100;
            }
            if (sum==50 && !flag)
            {
                Console.WriteLine("250%");
            }
            else
            Console.Write("{0}%", sum);
        }
    }
}
