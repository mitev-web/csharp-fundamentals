using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());
            int br=1;
            for (int i = n - 2; i >= 0; i--)
            {
                for (int j = 1; j <= i; j++) Console.Write('.');
                for (int j = 1; j <= br; j++) Console.Write('*');
                for (int j = 1; j <= i; j++) Console.Write('.');
                br += 2;
                Console.WriteLine();
            }
            for (int j = 1; j <= n-2; j++) Console.Write('.');
            Console.Write('*');
            for (int j = 1; j <= n-2; j++) Console.Write('.');
            Console.WriteLine();
        }
    }
}
