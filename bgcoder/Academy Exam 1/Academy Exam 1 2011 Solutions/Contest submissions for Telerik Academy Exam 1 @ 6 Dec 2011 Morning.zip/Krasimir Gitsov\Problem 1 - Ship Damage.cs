using System;

namespace FirstProblem
{
    class First
    {
        static void Main(string[] args)
        {
            int damage = 0;
            string strSx1 = Console.ReadLine();
            int sx1 = Int32.Parse(strSx1);
            string strSy1 = Console.ReadLine();
            int sy1 = Int32.Parse(strSy1);
            string strSx2 = Console.ReadLine();
            int sx2 = Int32.Parse(strSx2);
            string strSy2 = Console.ReadLine();
            int sy2 = Int32.Parse(strSy2);
            string strH = Console.ReadLine();
            int h = Int32.Parse(strH);
            string strCx1 = Console.ReadLine();
            int Cx1 = Int32.Parse(strCx1);
            string strCy1 = Console.ReadLine();
            int Cy1 = Int32.Parse(strCy1);
            string strCx2 = Console.ReadLine();
            int Cx2 = Int32.Parse(strCx2);
            string strCy2 = Console.ReadLine();
            int Cy2 = Int32.Parse(strCy2);
            string strCx3 = Console.ReadLine();
            int Cx3 = Int32.Parse(strCx3);
            string strCy3 = Console.ReadLine();
            int Cy3 = Int32.Parse(strCy3);
            int cY1 = Cy1;
            if (cY1 < h && cY1 <0)
            {
                cY1 *= -1;
                cY1 += h;
            }
            else if (cY1>h)
            {
                cY1 = h;
            }
            int cY2 = Cy2;
            if (cY2 < h && cY2 < 0)
            {
                cY2 *= -1;
                cY2 += h;
            }
            else if (cY2 > h)
            {
                cY2 = h;
            }
            int cY3 = Cy3;
            if (cY3 < h && cY3 < 0)
            {
                cY3 *= -1;
                cY3 += h;
            }
            else if (cY3 > h)
            {
                cY3 = h;
            }
            sy1 -= h;
            sy2 -= h;

            if (sx1 > sx2)
            {
                if (sy1 > sy2)
                {
                    if (sy2 != h)
                    {
                        //yglite
                        if (Cx1 == sx1 && cY1 == sy1 || Cx1 == sx2 && cY1 == sy2)
                        {
                            damage += 25;
                        }
                        if (Cx2 == sx2 && cY2 == sy2 || Cx2 == sx1 && cY2 == sy1)
                        {
                            damage += 25;
                        }
                        if (Cx3 == sx1 && cY3 == sy1 || Cx3 == sx2 && cY3 == sy2)
                        {
                            damage += 25;
                        }
                        //gornite stranite
                        if (Cx1 < sx1 && cY1 == sy1 || Cx1 > sx2 && cY1 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx2 < sx1 && cY2 == sy1 || Cx2 > sx2 && cY2 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx3 < sx1 && cY3 == sy1 || Cx3 > sx2 && cY3 == sy2)
                        {
                            damage += 50;
                        }
                        //otstrani strani
                        if (cY1 < sy1 && Cx1 == sx1 || cY1 > sy2 && Cx1 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY2 < sy1 && Cx2 == sx1 || cY2 > sy2 && Cx2 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY3 < sy1 && Cx3 == sx1 || cY3 > sy2 && Cx3 == sx2)
                        {
                            damage += 50;
                        }
                        //vytre
                        if (Cx1 < sx1 && Cx1 > sx2 && cY1 < sy1 && cY1 > sy2)
                        {
                            damage += 100;
                        }
                        if (Cx2 < sx1 && Cx2 > sx2 && cY2 < sy1 && cY2 > sy2)
                        {
                            damage += 100;
                        }
                        if (Cx3 < sx1 && Cx3 > sx2 && cY3 < sy1 && cY3 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else if (sy2 ==0)
                    {
                        damage += 0;
                    }

                }
                else
                {
                    if (sy1 != h)
                    {
                        //yglite
                        if (Cx1 == sx1 && cY1 == sy1 || Cx1 == sx2 && cY1 == sy2)
                        {
                            damage += 25;
                        }
                        if (Cx2 == sx2 && cY2 == sy2 || Cx2 == sx1 && cY2 == sy1)
                        {
                            damage += 25;
                        }
                        if (Cx3 == sx1 && cY3 == sy1 || Cx3 == sx2 && cY3 == sy2)
                        {
                            damage += 25;
                        }
                        //gornite stranite
                        if (Cx1 < sx1 && cY1 == sy1 || Cx1 > sx2 && cY1 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx2 < sx1 && cY2 == sy1 || Cx2 > sx2 && cY2 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx3 < sx1 && cY3 == sy1 || Cx3 > sx2 && cY3 == sy2)
                        {
                            damage += 50;
                        }
                        //otstrani strani
                        if (cY1 > sy1 && Cx1 == sx1 || cY1 < sy2 && Cx1 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY2 > sy1 && Cx2 == sx1 || cY2 < sy2 && Cx2 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY3 > sy1 && Cx3 == sx1 || cY3 < sy2 && Cx3 == sx2)
                        {
                            damage += 50;
                        }
                        //vytre
                        if (Cx1 < sx1 && Cx1 > sx2 && cY1 > sy1 && cY1 < sy2)
                        {
                            damage += 100;
                        }
                        if (Cx2 < sx1 && Cx2 > sx2 && cY2 > sy1 && cY2 < sy2)
                        {
                            damage += 100;
                        }
                        if (Cx3 < sx1 && Cx3 > sx2 && cY3 > sy1 && cY3 < sy2)
                        {
                            damage += 100;
                        }
                    }
                    else if(sy1==0)
                    {
                        damage += 0;
                    }
                }
            }
            else
            {
                if (sy1 > sy2)
                {
                    if (sy2 != h)
                    {
                        //yglite
                        if (Cx1 == sx1 && cY1 == sy1 || Cx1 == sx2 && cY1 == sy2)
                        {
                            damage += 25;
                        }
                        if (Cx2 == sx2 && cY2 == sy2 || Cx2 == sx1 && cY2 == sy1)
                        {
                            damage += 25;
                        }
                        if (Cx3 == sx1 && cY3 == sy1 || Cx3 == sx2 && cY3 == sy2)
                        {
                            damage += 25;
                        }
                        //gornite stranite
                        if (Cx1 > sx1 && cY1 == sy1 || Cx1 < sx2 && cY1 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx2 > sx1 && cY2 == sy1 || Cx2 < sx2 && cY2 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx3 > sx1 && cY3 == sy1 || Cx3 < sx2 && cY3 == sy2)
                        {
                            damage += 50;
                        }
                        //otstrani strani
                        if (cY1 < sy1 && Cx1 == sx1 || cY1 > sy2 && Cx1 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY2 < sy1 && Cx2 == sx1 || cY2 > sy2 && Cx2 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY3 < sy1 && Cx3 == sx1 || cY3 > sy2 && Cx3 == sx2)
                        {
                            damage += 50;
                        }
                        //vytre
                        if (Cx1 > sx1 && Cx1 < sx2 && cY1 < sy1 && cY1 > sy2)
                        {
                            damage += 100;
                        }
                        if (Cx2 > sx1 && Cx2 < sx2 && cY2 < sy1 && cY2 > sy2)
                        {
                            damage += 100;
                        }
                        if (Cx3 > sx1 && Cx3 < sx2 && cY3 < sy1 && cY3 > sy2)
                        {
                            damage += 100;
                        }
                    }
                    else if (sy2 == 0)
                    {
                        damage += 0;
                    }
                }
                else
                {
                    if (sy1 != h)
                    {
                        //yglite
                        if (Cx1 == sx1 && cY1 == sy1 || Cx1 == sx2 && cY1 == sy2)
                        {
                            damage += 25;
                        }
                        if (Cx2 == sx2 && cY2 == sy2 || Cx2 == sx1 && cY2 == sy1)
                        {
                            damage += 25;
                        }
                        if (Cx3 == sx1 && cY3 == sy1 || Cx3 == sx2 && cY3 == sy2)
                        {
                            damage += 25;
                        }
                        //gornite stranite
                        if (Cx1 > sx1 && cY1 == sy1 || Cx1 < sx2 && cY1 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx2 > sx1 && cY2 == sy1 || Cx2 < sx2 && cY2 == sy2)
                        {
                            damage += 50;
                        }
                        if (Cx3 > sx1 && cY3 == sy1 || Cx3 < sx2 && cY3 == sy2)
                        {
                            damage += 50;
                        }
                        //otstrani strani
                        if (cY1 > sy1 && Cx1 == sx1 || cY1 < sy2 && Cx1 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY2 > sy1 && Cx2 == sx1 || cY2 < sy2 && Cx2 == sx2)
                        {
                            damage += 50;
                        }
                        if (cY3 > sy1 && Cx3 == sx1 || cY3 < sy2 && Cx3 == sx2)
                        {
                            damage += 50;
                        }
                        //vytre
                        if (Cx1 > sx1 && Cx1 < sx2 && cY1 > sy1 && cY1 < sy2)
                        {
                            damage += 100;
                        }
                        if (Cx2 > sx1 && Cx2 < sx2 && cY2 > sy1 && cY2 < sy2)
                        {
                            damage += 100;
                        }
                        if (Cx3 > sx1 && Cx3 < sx2 && cY3 > sy1 && cY3 < sy2)
                        {
                            damage += 100;
                        }
                    }
                    else if (sy1 == 0)
                    {
                        damage += 0;
                    }
                }
            }
            Console.WriteLine("{0}%", damage);
        }
    }
}
