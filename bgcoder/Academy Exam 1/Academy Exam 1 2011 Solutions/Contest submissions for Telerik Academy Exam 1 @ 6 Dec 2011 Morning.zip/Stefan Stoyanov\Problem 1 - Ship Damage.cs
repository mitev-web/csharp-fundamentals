using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1, sy1, sx2, sy2, h, cx1, cy1, cx2, cy2, cx3, cy3, damage = 0;
            sx1 = int.Parse(Console.ReadLine());
            sy1 = int.Parse(Console.ReadLine());
            sx2 = int.Parse(Console.ReadLine());
            sy2 = int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            cx1 = int.Parse(Console.ReadLine());
            cy1 = int.Parse(Console.ReadLine());
            cx2 = int.Parse(Console.ReadLine());
            cy2 = int.Parse(Console.ReadLine());
            cx3 = int.Parse(Console.ReadLine());
            cy3 = int.Parse(Console.ReadLine());

            if (sx1 > sx2)
            {
                if (sy1 > sy2)
                {
                    sx1 += sx2;
                    sx2 = sx1 - sx2;
                    sx1 = sx1 - sx2;
                }
                else
	            {
                    sx1 += sx2;
                    sx2 = sx1 - sx2;
                    sx1 = sx1 - sx2;
                    sy1 += sy2;
                    sy2 = sy1 - sy2;
                    sy1 = sy1 - sy2;
	            }
            }
            if (sx1 < sx2 && sy1 < sy2)
            {
                sy1 += sy2;
                sy2 = sy1 - sy2;
                sy1 = sy1 - sy2;                
            }

            cy1 = 2 * h - cy1;
            cy2 = 2 * h - cy2;
            cy3 = 2 * h - cy3;

            if (cx1 > sx1 && cx1 < sx2 && cy1 < sy1 && cy1 > sy2 )
            {
                damage += 100;   
            }
            else if (cx1 < sx1 || cx1 > sx2 || cy1 > sy1 || cy1 < sy2)
            {
                
            }
            else if (((cx1 > sx1 && cx1 < sx2) && (cy1 == sy1 || cy1 == sy2)) ||
                ((cy1 < sy1 && cy1 > sy2) && (cx1 == sx1 || cx1 == sx2)))
            {
                damage += 50;               
            }
            else 
            {
                damage += 25;                
            }

            //point 2
            if (cx2 > sx1 && cx2 < sx2 && cy2 < sy1 && cy2 > sy2)
            {
                damage += 100;
            }
            else if (cx2 < sx1 || cx2 > sx2 || cy2 > sy1 || cy2 < sy2)
            {

            }
            else if (((cx2 > sx1 && cx2 < sx2) && (cy2 == sy1 || cy2 == sy2)) ||
                ((cy2 < sy1 && cy2 > sy2) && (cx2 == sx1 || cx2 == sx2)))
            {
                damage += 50;
            }
            else
            {
                damage += 25;
            }

            //point 3
            if (cx3 > sx1 && cx3 < sx2 && cy3 < sy1 && cy3 > sy2)
            {
                damage += 100;
            }
            else if (cx3 < sx1 || cx3 > sx2 || cy3 > sy1 || cy3 < sy2)
            {

            }
            else if (((cx3 > sx1 && cx3 < sx2) && (cy3 == sy1 || cy3 == sy2)) ||
                ((cy3 < sy1 && cy3 > sy2) && (cx3 == sx1 || cx3 == sx2)))
            {
                damage += 50;
            }
            else
            {
                damage += 25;
            }

            Console.WriteLine(damage + "%");
        }
    }
}
