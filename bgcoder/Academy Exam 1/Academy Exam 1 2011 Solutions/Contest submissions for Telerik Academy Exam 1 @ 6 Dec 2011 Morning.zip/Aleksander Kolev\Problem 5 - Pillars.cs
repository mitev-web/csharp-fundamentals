using System;

class Pillars
{
    static void Main(string[] args)
    {
        string line;
        byte[] matrix = new byte[8];
        for (int i = 0; i < 8; i++)
        {
            line = Console.ReadLine();
            matrix[i] = byte.Parse(line);
        }
        int pillar = 7, sumleft = 0, sumright = 0;
        while ((pillar > 0) && !((sumleft != 0) && (sumleft == sumright)))
        {
            sumleft = 0;
            sumright = 0;
            pillar--;
            for (int j = 0; j < 8; j++)
            {
                for (int k = 0; k < 8; k++)
                {
                    if (k != pillar)
                    {
                        if ((matrix[j] & (1 << k)) != 0)
                        {
                            if (k < pillar)
                            {
                                sumright++;
                            }
                            else
                            {
                                sumleft++;
                            }
                        }
                    }
                }
            }
        }

        if (pillar > 0)
        {
            Console.WriteLine(pillar);
            Console.WriteLine(sumleft);
        }
        else
        {
            Console.WriteLine("No");
        }
    }
}