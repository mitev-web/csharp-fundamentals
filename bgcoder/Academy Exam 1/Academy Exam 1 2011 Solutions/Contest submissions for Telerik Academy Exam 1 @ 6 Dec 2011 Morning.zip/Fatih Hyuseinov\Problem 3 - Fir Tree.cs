using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _03.Fir_Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            int n = int.Parse(line);

            char[,] tree = new char[n, 2*(n-1)-1];
            int br = 0;
            int end = 2*(n-1)-1;
            for (int i = n-2; i >= 0; i--)
            {
                for (int j = br; j < end; j++)
                {
                    tree[i, j] = '*';
                }
                br++;
                end--;
            }
            for (int j = 0; j < 2*(n-1)-1; j++)
            {
                if (j == (2 * (n - 1) - 1) / 2 + 1)
                {
                    tree[n - 1, j-1] = '*';
                }
                else tree[n - 1, j] = '.';
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 2*(n-1)-1; j++)
                {
                    if (tree[i, j] != '*')
                    {
                        tree[i, j] = '.';
                    }
                    Console.Write(tree[i,j]);
                }
                Console.WriteLine();
            }
        }
    }
}
