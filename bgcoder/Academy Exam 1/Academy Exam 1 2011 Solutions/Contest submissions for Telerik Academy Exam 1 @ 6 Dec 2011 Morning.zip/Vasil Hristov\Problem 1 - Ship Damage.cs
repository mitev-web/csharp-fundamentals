using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem11
{
    class Program
    {
        static void Main()
        {
            double Sx1, Sy1, Sx2, Sy2, H, Cx1, Cy1, Cx2, Cy2, Cx3, Cy3;
            Sx1 = double.Parse(Console.ReadLine());
            Sy1 = double.Parse(Console.ReadLine());
            Sx2 = double.Parse(Console.ReadLine());
            Sy2 = double.Parse(Console.ReadLine());
            H = double.Parse(Console.ReadLine());
            Cx1 = double.Parse(Console.ReadLine());
            Cy1 = double.Parse(Console.ReadLine());
            Cx2 = double.Parse(Console.ReadLine());
            Cy2 = double.Parse(Console.ReadLine());
           
            
            Cx3 = double.Parse(Console.ReadLine());
            Cy3 = double.Parse(Console.ReadLine());
           

            double Sx3, Sy3, Sx4, Sy4;
            sbyte whereUp = -1,whereSide=-1;
            if (Sy1 > Sy2) { Sy3 = Sy1; Sx3 = Sx2; Sy4 = Sy2; Sx4 = Sx1;whereUp=1 ;}
            else { Sy3 = Sy2; Sx3 = Sx1; Sy4 = Sy1; Sx4 = Sx2; whereUp = 0; }
            if (Sx1 > Sx2) { whereSide = 1; }
            else whereSide=0;
            int damage=0;
            Cy3 = Cy3 * Cy3;
            Cy3 = Math.Sqrt(Cy3);
            Cy2 = Cy2 * Cy2;
            Cy2 = Math.Sqrt(Cy2);
            Cy1 = Cy1 * Cy1;
            Cy1 = Math.Sqrt(Cy1);


            Cy3 =Cy3 + H;
            Cy3 =  Cy3+H;


            Cy2 =Cy2+ H;
            Cy2 =  Cy2+H;


            Cy1=Cy1+ H;
            Cy1 = Cy1+H;
            if ((Cy1 == Sy1 && Cx1 == Sx1) || (Cy1 == Sy2 && Cx1 == Sx2) || (Cy1 == Sy3 && Cx1 == Sx3) || (Cy1 == Sy4 && Cx1 == Sx4)) damage += 25;
            if ((Cy2 == Sy1 && Cx2 == Sx1) || (Cy2 == Sy2 && Cx2 == Sx2) || (Cy2 == Sy3 && Cx2 == Sx3) || (Cy2 == Sy4 && Cx2 == Sx4)) damage += 25;
            if ((Cy3 == Sy1 && Cx3 == Sx1) || (Cy3 == Sy2 && Cx3 == Sx2) || (Cy3 == Sy3 && Cx3 == Sx3) || (Cy3 == Sy4 && Cx3 == Sx4)) damage += 25;
            if(whereSide==1&&whereUp==1){
                if(Cy1==Sy1&&Cx1<Sx1&&Cx1>Sx3)damage += 50;
                if(Cy1==Sy2&&Cx1>Sx2&&Cx1<Sx4)damage += 50;
                if(Cx1==Sx1&&Cy1<Sy1&&Cy1>Sy4)damage += 50;
                if(Cx1==Sx2&&Cy1<Sy1&&Cy1>Sy4)damage += 50;

                if(Cy2==Sy1&&Cx2<Sx1&&Cx2>Sx3)damage += 50;
                if(Cy2==Sy2&&Cx2>Sx2&&Cx2<Sx4)damage += 50;
                if(Cx2==Sx1&&Cy2<Sy1&&Cy2>Sy4)damage += 50;
                if(Cx2==Sx2&&Cy2<Sy1&&Cy2>Sy4)damage += 50;

                if(Cy3==Sy1&&Cx3<Sx1&&Cx3>Sx3)damage += 50;
                if(Cy3==Sy2&&Cx3>Sx2&&Cx3<Sx4)damage += 50;
                if(Cx3==Sx1&&Cy3<Sy1&&Cy3>Sy4)damage += 50;
                if(Cx3==Sx2&&Cy3<Sy1&&Cy3>Sy4)damage += 50;

                if(Cy1<Sy1&&Cy1>Sy2&&Cx1>Sx2&&Cx1<Sx1)damage += 100;
                if(Cy2<Sy1&&Cy2>Sy2&&Cx2>Sx2&&Cx2<Sx1)damage += 100;
                if(Cy3<Sy1&&Cy3>Sy2&&Cx3>Sx2&&Cx3<Sx1)damage += 100;
            }

             if(whereSide==0&&whereUp==1){
                if(Cy1==Sy1&&Cx1>Sx1&&Cx1<Sx3)damage += 50;
                if(Cy1==Sy2&&Cx1<Sx2&&Cx1>Sx4)damage += 50;
                if(Cx1==Sx1&&Cy1<Sy1&&Cy1>Sy4)damage += 50;
                if(Cx1==Sx2&&Cy1<Sy1&&Cy1>Sy4)damage += 50;

                if(Cy2==Sy1&&Cx2>Sx1&&Cx2<Sx3)damage += 50;
                if(Cy2==Sy2&&Cx2<Sx2&&Cx2>Sx4)damage += 50;
                if(Cx2==Sx1&&Cy2<Sy1&&Cy2>Sy4)damage += 50;
                if(Cx2==Sx2&&Cy2<Sy1&&Cy2>Sy4)damage += 50;

                if(Cy3==Sy1&&Cx3>Sx1&&Cx3<Sx3)damage += 50;
                if(Cy3==Sy2&&Cx3<Sx2&&Cx3>Sx4)damage += 50;
                if(Cx3==Sx1&&Cy3<Sy1&&Cy3>Sy4)damage += 50;
                if(Cx3==Sx2&&Cy3<Sy1&&Cy3>Sy4)damage += 50;

                if(Cy1<Sy1&&Cy1>Sy2&&Cx1<Sx2&&Cx1>Sx1)damage += 100;
                 if(Cy2<Sy1&&Cy2>Sy2&&Cx2<Sx2&&Cx2>Sx1)damage += 100;
                 if(Cy3<Sy1&&Cy3>Sy2&&Cx3<Sx2&&Cx3>Sx1)damage += 100;
            }
             if(whereSide==0&&whereUp==0){
                if(Cy1==Sy1&&Cx1>Sx1&&Cx1<Sx3)damage += 50;
                if(Cy1==Sy2&&Cx1<Sx2&&Cx1>Sx4)damage += 50;
                if(Cx1==Sx1&&Cy1>Sy1&&Cy1<Sy4)damage += 50;
                if(Cx1==Sx2&&Cy1>Sy1&&Cy1<Sy4)damage += 50;

                if(Cy2==Sy1&&Cx2>Sx1&&Cx2<Sx3)damage += 50;
                if(Cy2==Sy2&&Cx2<Sx2&&Cx2>Sx4)damage += 50;
                if(Cx2==Sx1&&Cy2>Sy1&&Cy2<Sy4)damage += 50;
                if(Cx2==Sx2&&Cy2>Sy1&&Cy2<Sy4)damage += 50;

                if(Cy3==Sy1&&Cx3>Sx1&&Cx3<Sx3)damage += 50;
                if(Cy3==Sy2&&Cx3<Sx2&&Cx3>Sx4)damage += 50;
                if(Cx3==Sx1&&Cy3>Sy1&&Cy3<Sy4)damage += 50;
                if(Cx3==Sx2&&Cy3>Sy1&&Cy3<Sy4)damage += 50;

                if(Cy1>Sy1&&Cy1<Sy2&&Cx1<Sx2&&Cx1>Sx1)damage += 100;
                 if(Cy2>Sy1&&Cy2<Sy2&&Cx2<Sx2&&Cx2>Sx1)damage += 100;
                 if(Cy3>Sy1&&Cy3<Sy2&&Cx3<Sx2&&Cx3>Sx1)damage += 100;
            }
            if(whereSide==1&&whereUp==0){
                if(Cy1==Sy1&&Cx1<Sx1&&Cx1>Sx3)damage += 50;
                if(Cy1==Sy2&&Cx1>Sx2&&Cx1<Sx4)damage += 50;
                if(Cx1==Sx1&&Cy1>Sy1&&Cy1<Sy4)damage += 50;
                if(Cx1==Sx2&&Cy1>Sy1&&Cy1<Sy4)damage += 50;

                if(Cy2==Sy1&&Cx2<Sx1&&Cx2>Sx3)damage += 50;
                if(Cy2==Sy2&&Cx2>Sx2&&Cx2<Sx4)damage += 50;
                if(Cx2==Sx1&&Cy2>Sy1&&Cy2<Sy4)damage += 50;
                if(Cx2==Sx2&&Cy2>Sy1&&Cy2<Sy4)damage += 50;

                if(Cy3==Sy1&&Cx3<Sx1&&Cx3>Sx3)damage += 50;
                if(Cy3==Sy2&&Cx3>Sx2&&Cx3<Sx4)damage += 50;
                if(Cx3==Sx1&&Cy3>Sy1&&Cy3<Sy4)damage += 50;
                if(Cx3==Sx2&&Cy3>Sy1&&Cy3<Sy4)damage += 50;

                if(Cy1>Sy1&&Cy1<Sy2&&Cx1<Sx2&&Cx1>Sx1)damage += 100;
                if(Cy2>Sy1&&Cy2<Sy2&&Cx2<Sx2&&Cx2>Sx1)damage += 100;
                if(Cy3>Sy1&&Cy3<Sy2&&Cx3<Sx2&&Cx3>Sx1)damage += 100;
            }
            Console.WriteLine(damage+"%");
        }
    }
}
