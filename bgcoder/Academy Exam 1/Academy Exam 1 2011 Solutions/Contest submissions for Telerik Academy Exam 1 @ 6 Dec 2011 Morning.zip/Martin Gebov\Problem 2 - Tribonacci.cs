using System;
using System.Numerics;
class TribonacciSequence
{
    static void Main(string[] args)
    {
        

        int n = 0;
        BigInteger n1, n2, n3;
        n1 = BigInteger.Parse(Console.ReadLine());
        n2 = BigInteger.Parse(Console.ReadLine());
        n3 = BigInteger.Parse(Console.ReadLine());
        n = int.Parse(Console.ReadLine());

        BigInteger temp;


        for (int i = 3; i < n; i++)
        {
            temp = n3;
            n3 = NextMember(n1, n2, n3);
            n1 = n2;
            n2 = temp;
            
        }

        Console.WriteLine(n3);
    }
    static BigInteger NextMember(BigInteger number1, BigInteger number2, BigInteger number3)
    {
        return (number1 + number2 + number3);
    }
}
