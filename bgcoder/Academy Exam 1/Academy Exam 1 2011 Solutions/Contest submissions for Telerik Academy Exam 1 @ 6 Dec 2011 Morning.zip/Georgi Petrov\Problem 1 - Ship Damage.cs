using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class ShipDamage
{
    static void Main(string[] args)
    {
        /*
        int S_x1 = 0;
        int S_y1 = 0;
        int S_x2 = 0;
        int S_y2 = 0;
        int H = 0;
        int C_x1 = 0;
        int C_y1 = 0;
        int C_x2 = 0;
        int C_y2 = 0;
        int C_x3 = 0;
        int C_y3 = 0;
        */
        
        int S_x1 = Int32.Parse(Console.ReadLine());
        int S_y1 = Int32.Parse(Console.ReadLine());
        int S_x2 = Int32.Parse(Console.ReadLine());
        int S_y2 = Int32.Parse(Console.ReadLine());
        int H = Int32.Parse(Console.ReadLine());
        int C_x1 = Int32.Parse(Console.ReadLine());
        int C_y1 = Int32.Parse(Console.ReadLine());
        int C_x2 = Int32.Parse(Console.ReadLine());
        int C_y2 = Int32.Parse(Console.ReadLine());
        int C_x3 = Int32.Parse(Console.ReadLine());
        int C_y3 = Int32.Parse(Console.ReadLine());
        

        // Make every horizontal coordinate positive
        int smallest = Int32.MaxValue;

        if (S_x1 < smallest)
            smallest = S_x1;

        if (S_x2 < smallest)
            smallest = S_x2;

        if (C_x1 < smallest)
            smallest = C_x1;

        if (C_x2 < smallest)
            smallest = C_x2;

        if (C_x3 < smallest)
            smallest = C_x3;

        smallest *= -1;

        S_x1 += smallest;
        S_x2 += smallest;
        C_x1 += smallest;
        C_x2 += smallest;
        C_x3 += smallest;

        // Make every vertical coordinate positive
        smallest = Int32.MaxValue;

        if (S_y1 < smallest)
            smallest = S_y1;

        if (S_y2 < smallest)
            smallest = S_y2;

        if (H < smallest)
            smallest = H;

        if (C_y1 < smallest)
            smallest = C_y1;

        if (C_y2 < smallest)
            smallest = C_y2;

        if (C_y3 < smallest)
            smallest = C_y3;

        smallest *= -1;

        S_y1 += smallest;
        S_y2 += smallest;
        H += smallest;
        C_y1 += smallest;
        C_y2 += smallest;
        C_y3 += smallest;

        // Now all our coordinates are shifted into quadrant 2 (upper right)

             // Let's shift C point's Y to the rectangle (catapult them)
        C_y1 = (H - C_y1) + H;
        C_y2 = (H - C_y2) + H;
        C_y3 = (H - C_y3) + H;

        // Now all C coordinates should be over the ship (catapulted)

        /*
        S_x1 = 2;
        S_y1 = 4;

        S_x2 = 5;
        S_y2 = 8;

        C_x1 = 3;
        C_y1 = 4;
        
        C_x2 = smallest;
        C_y2 = smallest;
        
        C_x3 = smallest;
        C_y3 = smallest;
         
        */

        // Let's define the 4 points of the rectangle

        int up_right_x = 0;
        int up_right_y = 0;
        int up_left_x = 0;
        int up_left_y = 0;
        int down_right_x = 0;
        int down_right_y = 0;
        int down_left_x = 0;
        int down_left_y = 0;

        if (S_x1 < S_x2 && S_y1 < S_y2)
        {
            down_left_x = S_x1;
            down_left_y = S_y1;
            up_right_x = S_x2;
            up_right_y = S_y2;
            up_left_x = S_x1;
            up_left_y = S_y2;
            down_right_x = S_x2;
            down_right_y = S_y1;
        }

        if (S_x2 < S_x1 && S_y2 < S_y1)
        {
            down_left_x = S_x2;
            down_left_y = S_y2;
            up_right_x = S_x1;
            up_right_y = S_y1;
            up_left_x = S_x2;
            up_left_y = S_y1;
            down_right_x = S_x1;
            down_right_y = S_y2;
        }

        if (S_x1 < S_x2 && S_y1 > S_y2)
        {
            down_left_x = S_x1;
            down_left_y = S_y2;
            up_right_x = S_x2;
            up_right_y = S_y1;
            up_left_x = S_x1;
            up_left_y = S_y1;
            down_right_x = S_x2;
            down_right_y = S_y2;
        }

        if (S_x2 < S_x1 && S_y2 > S_y1)
        {
            down_left_x = S_x2;
            down_left_y = S_y1;
            up_right_x = S_x1;
            up_right_y = S_y2;
            up_left_x = S_x2;
            up_left_y = S_y2;
            down_right_x = S_x1;
            down_right_y = S_y1;
        }

        // Let's check the damage

        /*
        Console.WriteLine();

        Console.WriteLine(S_x1);
        Console.WriteLine(S_y1);
        Console.WriteLine(S_x2);
        Console.WriteLine(S_y2);
        Console.WriteLine(H);
        Console.WriteLine(C_x1);
        Console.WriteLine(C_y1);
        Console.WriteLine(C_x2);
        Console.WriteLine(C_y2);
        Console.WriteLine(C_x3);
        Console.WriteLine(C_y3);

        Console.WriteLine();
         * */
        /*
        Console.WriteLine("down_left_x = {0}", down_left_x);
        Console.WriteLine("down_left_y = {0}", down_left_y);
        Console.WriteLine("up_right_x = {0}", up_right_x);
        Console.WriteLine("up_right_y = {0}", up_right_y);
        Console.WriteLine("up_left_x = {0}", up_left_x);
        Console.WriteLine("up_left_y = {0}", up_left_y);
        Console.WriteLine("down_right_x = {0}", down_right_x);
        Console.WriteLine("down_right_y = {0}", down_right_y);
       */

        int damage = 0;

        // Edges

        // Upper left

        if (C_x1 == up_left_x && C_y1 == up_left_y)
            damage += 25;

        if (C_x2 == up_left_x && C_y2 == up_left_y)
            damage += 25;

        if (C_x3 == up_left_x && C_y3 == up_left_y)
            damage += 25;

        // Upper right
        
        if (C_x1 == up_right_x && C_y1 == up_right_y)
            damage += 25;

        if (C_x2 == up_right_x && C_y2 == up_right_y)
            damage += 25;

        if (C_x3 == up_right_x && C_y3 == up_right_y)
            damage += 25;
        
        // Down right

        if (C_x1 == down_right_x && C_y1 == down_right_y)
            damage += 25;

        if (C_x2 == down_right_x && C_y2 == down_right_y)
            damage += 25;

        if (C_x3 == down_right_x && C_y3 == down_right_y)
            damage += 25;
        
        // Down left

        if (C_x1 == down_left_x && C_y1 == down_left_y)
            damage += 25;

        if (C_x2 == down_left_x && C_y2 == down_left_y)
            damage += 25;

        if (C_x3 == down_left_x && C_y3 == down_left_y)
            damage += 25;


        // Sides test

        // Up 

        if (C_y1 == up_left_y && C_x1 > up_left_x && C_x1 < up_right_x)
            damage+=50;

        if (C_y2 == up_left_y && C_x2 > up_left_x && C_x2 < up_right_x)
            damage += 50;
        
        if (C_y3 == up_left_y && C_x3 > up_left_x && C_x3 < up_right_x)
            damage += 50;

        // Down 

        if (C_y1 == down_left_y && C_x1 > down_left_x && C_x1 < down_right_x)
            damage += 50;

        if (C_y2 == down_left_y && C_x2 > down_left_x && C_x2 < down_right_x)
            damage += 50;

        if (C_y3 == down_left_y && C_x3 > down_left_x && C_x3 < down_right_x)
            damage += 50;
    
        // Left

        if (C_x1 == up_left_x && C_y1 > down_left_y && C_y1 < up_left_y)
            damage += 50;

        if (C_x2 == up_left_x && C_y2 > down_left_y && C_y2 < up_left_y)
            damage += 50;

        if (C_x3 == up_left_x && C_y3 > down_left_y && C_y3 < up_left_y)
            damage += 50;

        // Right

        if (C_x1 == up_right_x && C_y1 > down_right_y && C_y1 < up_right_y)
            damage += 50;

        if (C_x2 == up_right_x && C_y2 > down_right_y && C_y2 < up_right_y)
            damage += 50;

        if (C_x3 == up_right_x && C_y3 > down_right_y && C_y3 < up_right_y)
            damage += 50;

        // Test for ship damage

        if (C_x1 > up_left_x && C_x1 < up_right_x &&
            C_y1 > down_left_y && C_y1 < up_left_y)
            damage += 100;
        
        if (C_x2 > up_left_x && C_x2 < up_right_x &&
            C_y2 > down_left_y && C_y2 < up_left_y)
            damage += 100;

        if (C_x3 > up_left_x && C_x3 < up_right_x &&
            C_y3 > down_left_y && C_y3 < up_left_y)
            damage += 100;

        Console.WriteLine("{0}%", damage);
    }
}

