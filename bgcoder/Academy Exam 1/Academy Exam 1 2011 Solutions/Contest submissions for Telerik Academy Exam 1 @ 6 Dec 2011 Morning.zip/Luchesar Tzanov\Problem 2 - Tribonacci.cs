using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace TribuNAZI
{
    class Program
    {
        static void Main()
        {
            long first, second, third;
            first = Convert.ToInt64(Console.ReadLine());
            second = Convert.ToInt64(Console.ReadLine());
            third = Convert.ToInt64(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());
            if( n == 1)
            {
                Console.WriteLine(first);
                return;
            }
            else if( n == 2)
            {
                Console.WriteLine(second);
                return;
            }
            else if( n == 3)
            {
                Console.WriteLine(third);
                return;
            }
            long temp;
            for (int i = 3; i < n; i++)
            {
                temp = first + second + third;
                first = second;
                second = third;
                third = temp;
            }
            Console.WriteLine(third);
        }
    }
}