using System;

namespace Task04_WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            uint n = uint.Parse(Console.ReadLine());
            uint p;

            uint reversedP = 0;
            uint power = 1;
            uint result;
            string inBinary;
            uint bit;
            for (int k = 0; k < n; k++)
            {
                p = uint.Parse(Console.ReadLine());
                inBinary = Convert.ToString(p, 2);
                bit = uint.Parse(inBinary);
                long individualBits;
                for (int s = inBinary.Length-1, q = 0; s >= 0; q++, s--)
                {

                    individualBits = bit % 10;
                    bit = bit / 10;
                   
                    if (individualBits == 1)
                    {
                        for (int w = 0; w <= q; w++)
                        {
                            power = power * 2;
                        }
                        reversedP = reversedP + power;
                    }
                }
                result = (p ^ (~p)) & reversedP;
                Console.WriteLine(result);
                reversedP = 0;
            }        
        }
    }
}
