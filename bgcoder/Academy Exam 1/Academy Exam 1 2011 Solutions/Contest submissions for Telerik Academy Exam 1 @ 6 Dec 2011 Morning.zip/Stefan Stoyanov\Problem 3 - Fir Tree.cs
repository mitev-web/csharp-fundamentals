using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0, j = 0, star = 1, k = 0;
            byte n;
            n = byte.Parse(Console.ReadLine());
            int width = 1;
            for (int i = 2; i < n; i++)
            {
                width += 2;                
            }
            //Console.WriteLine(width);
            for (int i = 0; i < n - 1; i++)
            {
                //count = 0;
                while (j < (width/2 - count))
                {
                    Console.Write(".");
                    j++;
                }
                while (k < star)
                {
                    Console.Write("*");
                    k++;
                }
                j += star;
                while (j > (width / 2 + count) && j < width)
                {
                    Console.Write(".");
                    j++;
                }
                Console.WriteLine();
                count++;
                j = 0;
                k = 0;
                star += 2;
            }

            j = 0;
            k = 0;
            while (j < (width / 2))
            {
                Console.Write(".");
                j++;
            }
            Console.Write("*");
            j++;
            while (j > (width / 2) && j < width)
            {
                Console.Write(".");
                j++;
            }
            Console.WriteLine();
        }
    }
}
