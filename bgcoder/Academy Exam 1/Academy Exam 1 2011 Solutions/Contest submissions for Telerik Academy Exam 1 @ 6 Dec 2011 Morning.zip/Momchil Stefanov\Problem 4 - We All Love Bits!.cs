using System;

namespace _04.WeLoveBits
{
    class WeLoveBits
    {
        static void Main(string[] args)
        {
            short N = short.Parse(Console.ReadLine());

            for (int i = 0; i < N; i++)
            {
                int P = int.Parse(Console.ReadLine());
                int copyOfP = P;
                byte bitCount = 0;
                int invertP;
                int reverseP = 0;
                int newP;

                while (copyOfP > 0)
                {
                    copyOfP >>= 1;
                    bitCount++;
                }

                invertP = ~((int.MaxValue << bitCount) | P);

                copyOfP = P;
                for (uint j = 0; j < bitCount; j++)
                {
                    reverseP = (reverseP << 1) | (copyOfP & 1);
                    copyOfP >>= 1;
                }

                newP = (P ^ invertP) & reverseP;
                
                Console.WriteLine(newP);
            }
        }
    }
}
