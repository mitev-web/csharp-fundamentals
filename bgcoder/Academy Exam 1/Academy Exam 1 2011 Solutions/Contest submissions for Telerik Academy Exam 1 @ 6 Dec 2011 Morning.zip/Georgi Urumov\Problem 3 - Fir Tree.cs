using System;
using System.Numerics;


namespace zad3
{
    class zad3
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int W = (N - 1) * 2 - 1;
            int u = W / 2;
            char[,] elha = new char[N, W];
            for (int q = 0; q < N; q++)
            {
                for (int z = 0; z < W; z++)
                {
                    elha[q, z] = '.';

                }

            }


            for (int i = 0; i < N; i++)
            {
                if (i == N - 1)
                {
                    elha[i, u ] = '*';
                }
                else
                {
                    for (int j = i - i / W; j >= 0; j--)
                    {


                        elha[i, W / 2 - j] = '*';
                        elha[i, W / 2 + j] = '*';

                    }
                }
            }
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    if (j == W - 1)
                    {
                        Console.WriteLine(elha[i, j]);
                    }
                    else
                    {
                        Console.Write(elha[i, j]);
                    }
                }
            }
        }
    }
}

