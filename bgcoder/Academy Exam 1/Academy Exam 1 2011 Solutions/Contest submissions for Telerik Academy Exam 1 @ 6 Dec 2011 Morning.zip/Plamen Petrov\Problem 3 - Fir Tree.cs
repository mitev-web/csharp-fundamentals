using System;

using System.Collections.Generic;

using System.Text;



namespace Program
{

    class Program
    {

        static void Main(string[] args)
        {




            int[] myArray = new int[] { 1, 3, 5, 7, 9 };



      



            foreach (int intLoop in myArray)
            {

                



                for (int iSpace = 0; iSpace < ((myArray[4] - intLoop) / 2); iSpace++)
                {

                    System.Console.Write(".");

                }




                for (int i = 0; i < intLoop; i++)
                {

                    System.Console.Write("*");

                }






                for (int iSpace = 0; iSpace < ((myArray[4] - intLoop) / 2); iSpace++)
                {

                    System.Console.Write(".");

                }



          

                System.Console.WriteLine(".");

            }



         

            for (int iBase = 0; iBase < myArray[1]; iBase++)
            {




                for (int iSpaces = 0; iSpaces < myArray[1]; iSpaces++)
                {

                    System.Console.Write(".");

                }



                for (int iPipes = 0; iPipes < myArray[1]; iPipes++)
                {

                    System.Console.Write("");

                }





                for (int iSpaces = 0; iSpaces < myArray[1]; iSpaces++)
                {

                    System.Console.Write("*");

                }


                System.Console.WriteLine(".");

            }

        }

    }

}