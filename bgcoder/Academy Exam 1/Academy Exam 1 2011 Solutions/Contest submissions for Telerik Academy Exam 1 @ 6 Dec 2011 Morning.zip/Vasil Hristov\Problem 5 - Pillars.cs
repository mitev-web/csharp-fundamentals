using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem5
{
    class Program
    {
        static void Main()
        {
            int cell=10,numberr=0;
            int left = 0, right = 0;
            int sum = 0, red = 0;
            int[,] matrix = new int[9, 8];
            int[] numbers = new int[8];
            for (int i = 0; i < 8; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
            int[] output = new int[8];
            for (int i = 0; i < 8; i++)
            {

                sum += numbers[i];
                if (i == 7) red = numbers[i];
            }
            for (int i = 0; i < 8; i++)
            {
                if (numbers[i] >= 128) { matrix[i, 7] = 1; numbers[i] -= 128; }
                if (numbers[i] >= 64) { matrix[i, 6] = 1; numbers[i] -= 64; }
                if (numbers[i] >= 32) { matrix[i, 5] = 1; numbers[i] -= 32; }
                if (numbers[i] >= 16) { matrix[i, 4] = 1; numbers[i] -= 16; }
                if (numbers[i] >= 8) { matrix[i, 3] = 1; numbers[i] -= 8; }
                if (numbers[i] >= 4) { matrix[i, 2] = 1; numbers[i] -= 4; }
                if (numbers[i] >= 2) { matrix[i, 1] = 1; numbers[i] -= 2; }
                if (numbers[i] >= 1) { matrix[i, 0] = 1; numbers[i] -= 1; }
            }
            /*  for (int i = 0; i <8; i++)
               {
                   for (int j = 7; j >=0; j--)
                   {
                       Console.Write(matrix[i,j]);
                   }
                   Console.WriteLine();
               }
               Console.WriteLine();
           
               */
            for (int k = 7; k >= 0; k--)
			{

                right = 0;
                left = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if(j==k) continue;
                    if (matrix[i, j] == 1)
                    {
                        if (j > k) { right++; }
                        else if (j < k) { left++; }
                        
                    }
                }
            }
            if (left == right&&cell>k) { cell = k; numberr = left; }

                }
            if (cell != 10) { Console.WriteLine(cell); Console.WriteLine(numberr); }
            else Console.WriteLine("No");
        }
    }
}
