using System;
using System.Numerics;
class Program
{
    static void Main(string[] args)
    {
        BigInteger aa = BigInteger.Parse(Console.ReadLine());
        BigInteger bb = BigInteger.Parse(Console.ReadLine());
        BigInteger cc = BigInteger.Parse(Console.ReadLine());
        int n = Int16.Parse(Console.ReadLine());

        n -=3;
        checked
        {
            for (int i = 0; i < n; i++)
            {
                BigInteger next = aa + bb + cc;
                aa = bb;
                bb = cc;
                cc = next;

            }
        }
        Console.WriteLine(cc);
        
    }
}
