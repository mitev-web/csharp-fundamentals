using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1ProblemShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());
           


           // c11 (cx1;-(cy1)+ 2*H)
          //  c21 (cx2; -(cY2) +2*H);
          //  c31 (cX3; -(cY3)+ 2*H);

           

            int count1 = 0;
            int count2 = 0;
            int count3 = 0;
            int count4 = 0;
            int count5 = 0;
            int count6 = 0;

            if ((sX1 < cX1) && (sX2 >cX1) && (sY2 < -(cY1)+ 2*H) && (sY1 > -(cY1)+ 2*H))
            {
              //  Console.WriteLine("damage = 100%");
                count1 = 100;
            }
            else if ((sX1 == cX1) || (sX2 == cX1) || (sY2 == -(cY1)+ 2*H) || (sY1 == -(cY1)+ 2*H))
            {
              //  Console.WriteLine("damage = 25%");
                count2 = 25;
            }
            else 
            {
             //   Console.WriteLine("damage = 0%");
            }


            if ((sX1 < cX2) && (sX2 > cX2) && (sY2 < -(cY2) + 2 * H) && (sY1 > -(cY2) + (2 * H)))
            {
             //   Console.WriteLine("damage = 100%");
                count3 = 100;
            }
            else if ((sX1 == cX2) || (sX2 == cX2) || (sY2 == -(cY2) + 2 * H)) //|| (sY1 == -(cY2) + (2 * H))
            {
               Console.WriteLine("damage = 25%");
                count4 = 25;
            }
            else
            {
              //  Console.WriteLine("damage = 0%");
            }


            if ((sX1 < cX3) && (sX2 > cX3) && (sY2 < -(cY3) + 2 * H) && (sY1 > -(cY3) + (2 * H)))
            {
              //  Console.WriteLine("damage = 100%");
                count5 = 100;
            }
            else if ((sX1 == cX3) || (sX2 == cX3) || (sY2 == -(cY3) + 2 * H) || (sY1 == -(cY3) + (2 * H)))
            {
                
                count6 = 25;
            }
            else
            {
                
            }

            Console.WriteLine("{0}%", count1+count2+count3+count4+count5+count6);
        }
    }
}