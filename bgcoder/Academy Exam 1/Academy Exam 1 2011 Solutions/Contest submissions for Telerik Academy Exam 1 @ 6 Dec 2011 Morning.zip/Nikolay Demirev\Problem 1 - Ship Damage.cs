using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] xCoords = new int[5];
            int[] yCoords = new int[5];

            int h;

            string input;

            for (int i = 0; i < 2; i++)
            {
                input = Console.ReadLine();
                xCoords[i] = int.Parse(input);
                input = Console.ReadLine();
                yCoords[i] = int.Parse(input);
            }

            input = Console.ReadLine();
            h = int.Parse(input);

            for (int i = 2; i < 5; i++)
            {
                input = Console.ReadLine();
                xCoords[i] = int.Parse(input);
                input = Console.ReadLine();
                yCoords[i] = int.Parse(input);
            }

            int minx = int.MaxValue;

            for (int i = 0; i < 5; i++)
            {
                if (minx > xCoords[i])
                {
                    minx = xCoords[i];
                }
            }

            if (minx < 0)
            {
                for (int i = 0; i < 5; i++)
                {
                    xCoords[i] += Math.Abs(minx);
                }
            }

            int miny = int.MaxValue;

            for (int i = 0; i < 5; i++)
            {
                if (miny > yCoords[i])
                {
                    miny = yCoords[i];
                }
            }

            if (miny < 0)
            {
                for (int i = 0; i < 5; i++)
                {
                    yCoords[i] += Math.Abs(miny);
                }
            }

            h += Math.Abs(miny);

            if (xCoords[0] > xCoords[1])
            {
                int temp = xCoords[0];
                xCoords[0] = xCoords[1];
                xCoords[1] = temp;

                temp = yCoords[0];
                yCoords[0] = yCoords[1];
                yCoords[1] = yCoords[0];
            }

            if (xCoords[0] < xCoords[1] && yCoords[0] < yCoords[1])
            {
                int sideA = xCoords[1] - xCoords[0];
                int sideB = yCoords[0] - yCoords[1];
                xCoords[0] += sideA;
                xCoords[1] -= sideA;
                yCoords[0] += sideB;
                yCoords[1] -= sideB;
            }

            if (h > yCoords[2])
            {
                for (int i = 2; i < 5; i++)
                {
                    yCoords[i] += h;
                }
            }
            else
            {
                for (int i = 2; i < 5; i++)
                {
                    yCoords[i] -= h;
                }
            }

            int points = 0;

            for (int i = 2; i < 5; i++)
            {
                //corners
                if (xCoords[0] == xCoords[i] && yCoords[0] == yCoords[i])
                {
                    points += 25;
                }
                if (xCoords[1] == xCoords[i] && yCoords[1] == yCoords[i])
                {
                    points += 25;
                }
                if (xCoords[0] == xCoords[i] && yCoords[1] == yCoords[i])
                {
                    points += 25;
                }
                if (xCoords[1] == xCoords[i] && yCoords[0] == yCoords[i])
                {
                    points += 25;
                }

                //sides
                if (xCoords[0] < xCoords[i] && xCoords[1] > xCoords[i] && yCoords[0] == yCoords[i])
                {
                    points += 50;
                }
                if (xCoords[1] == xCoords[i] && yCoords[0] > yCoords[i] && yCoords[1] < yCoords[i])
                {
                    points += 50;
                }
                if (xCoords[1] < xCoords[i] && xCoords[0] > xCoords[i] && yCoords[1] == yCoords[i])
                {
                    points += 50;
                }
                if (xCoords[0] == xCoords[i] && yCoords[1] > yCoords[i] && yCoords[0] < yCoords[i])
                {
                    points += 50;
                }

                //inside

                if (xCoords[0] < xCoords[i] && xCoords[1] > xCoords[i] && yCoords[0] > yCoords[i] && yCoords[1] < yCoords[i])
                {
                    points += 100;
                }
            }

            Console.WriteLine("{0}%", points);
        }
    }
}