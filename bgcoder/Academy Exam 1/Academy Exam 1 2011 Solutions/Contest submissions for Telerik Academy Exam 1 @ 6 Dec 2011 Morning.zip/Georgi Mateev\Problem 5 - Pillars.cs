using System;


namespace _5_Pillars
{
    class Pillars
    {
        static void Main(string[] args)
        {
            byte[] numbers = new byte[8];
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }
                       
            int pillar = 8;
            int cells = 0;

            for (int p = 0; p < 8; p++)
            {
                int leftCounter = 0;
                int rightCounter = 0;

                for (int j = 0; j < p; j++)
                {
                    byte mask = 1;
                    mask <<= j;
                    foreach (var item in numbers)
                    {
                        byte bit = (byte)((item & mask) >> j);
                        if (bit==1)
                        {
                            rightCounter++;
                        }
                    }
                }
                for (int j = p+1; j < 8; j++)
                {
                    byte mask = 1;
                    mask <<= j;
                    foreach (var item in numbers)
                    {
                        byte bit = (byte)((item & mask) >> j);
                        if (bit==1)
                        {
                            leftCounter++;
                        }
                    }
                }
                if (leftCounter==rightCounter)
                {
                    pillar = p;
                    cells = rightCounter;
                }
            }
            if (pillar==8)
            {
                Console.WriteLine("No");
            }
            else
            {
                Console.WriteLine(pillar);
                Console.WriteLine(cells);
            }

        }
    }
}
