using System;
using System.Linq;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger T1, T2, T3,nextT=0;
            int N;
            T1 = BigInteger.Parse(Console.ReadLine());
            T2 = BigInteger.Parse(Console.ReadLine());
            T3 = BigInteger.Parse(Console.ReadLine());
            N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N-3; i++)
            {
                nextT = T1 + T2 + T3;
                T1 = T2;
                T2 = T3;
                T3 = nextT;
            }
            Console.WriteLine(T3);
        }
    }
}
