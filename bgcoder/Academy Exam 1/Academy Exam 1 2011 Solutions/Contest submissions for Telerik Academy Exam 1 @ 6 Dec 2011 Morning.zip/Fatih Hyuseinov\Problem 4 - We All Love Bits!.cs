using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplicabtion1
{
    class Program
    {
        static void Main(string[] args)
        {
            string line1 = Console.ReadLine();
            int n = int.Parse(line1);
            for (int t = 0; t < n; t++)
            {


                string line;
                line = Console.ReadLine();
                int p = int.Parse(line);
                double pp = p;
                int[] b = new int[32];
                int i = 0;
                double reverse = 0;
                double p1 = 0;
                do
                {
                    b[i] = p % 2;
                    i++;
                    p /= 2;
                } while (p != 0);
                double k = 0;
                for (int j = i - 1; j >= 0; j--)
                {

                    reverse += b[j] * Math.Pow(2, k);
                    k++;

                    if (b[j] == 0)
                    {
                        b[j] = 1;
                    }
                    else b[j] = 0;

                    p1 += b[j] * Math.Pow(2, j);
                }

              //  Console.WriteLine(reverse);
               // Console.WriteLine(p1);

                double pNew;
                pNew = ((int)pp ^ (int)p1) & (int)reverse;
                Console.WriteLine(pNew);

             //   Console.WriteLine(Convert.ToString((int)pp, 2));
               // Console.WriteLine(Convert.ToString((int)p1, 2));
                //Console.WriteLine(Convert.ToString((int)reverse, 2));
            }
        }
    }
}
