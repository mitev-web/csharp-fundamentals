using System;
using System.Numerics;


namespace zad4
{
    class zad4
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int[] numb = new int[N];
            BigInteger sum = 0;
            BigInteger[] numb1 = new BigInteger[N];
            BigInteger[] numb2 = new BigInteger[N];
            BigInteger[] ans = new BigInteger[N];
            double br = 0.0;
            for (int i = 0; i < N; i++)
            {
                numb[i] = int.Parse(Console.ReadLine());
            }
            for (int j = 0; j < N; j++)
            {
                int nu1 = numb[j];
                while (nu1 > 0)
                {
                    br++;
                    nu1 = nu1 / 2;
                }

                numb1[j] = (int)Math.Pow(2.0, br) - 1;
                int nu = numb[j];
                double iter = br-1;
                for (int z = 0; z < br; z++)
                {

                    int bit = nu % 2;
                    int newnumb =  nu >> 1 ;
                    sum += (int)Math.Pow(2, iter) * bit;
                    iter--;
                    nu = newnumb;
                }
                numb2[j] = sum;
                ans[j] = numb1[j] & numb2[j];
                br = 0;
                sum = 0;


            }
            for (int g = 0; g < N; g++)
            {
                Console.WriteLine(ans[g]);
            }
        }
    }
}
