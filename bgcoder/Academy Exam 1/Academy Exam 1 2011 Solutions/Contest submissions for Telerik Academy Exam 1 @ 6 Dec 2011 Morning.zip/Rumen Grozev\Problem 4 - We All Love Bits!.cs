using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem4WeAllLoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, n, t, temp, temp1;

            n = int.Parse(Console.ReadLine());
            int[] k = new int[32];

            int[] p1 = new int[n];
            int[] p2 = new int[n];
            int[] p = new int[n];
            
            for (i = 0; i < n; i++)
            {
                p[i] = int.Parse(Console.ReadLine());
            }

            for (i = 0; i < n; i++)
            {
                temp1 = p[i];
                j = 0;
                while (temp1 != 0)
                {
                    temp = temp1 & 1;
                    if (temp == 0)
                    {
                        p1[i] += 1 << j;
                    }
                    j++;
                    temp1 >>= 1;
                }
                //Console.WriteLine(Convert.ToString(p[i], 2).PadLeft(32, '0'));      
                //Console.WriteLine(Convert.ToString(p1[i], 2).PadLeft(32, '0'));

                temp1 = p[i];
                j = 0;
                while (temp1 != 0)
                {
                    k[j] = temp1 & 1;
                    //p1[i] += (int)Math.Pow(2, i);
                    j++;
                    temp1 >>= 1;
                }
                for (t = 0; t < j; t++)
                {
                    p2[i] += k[t] * 1 << (j - t - 1);//(int) Math.Pow(2, (j - t));
                }
                //Console.WriteLine(Convert.ToString(p2[i], 2).PadLeft(32, '0'));
                Console.WriteLine((p[i] ^ p1[i]) & p2[i]); 
            }
            
        }
    }
}
