using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.Write("");
            int n =int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int ii = 0; ii < n + ( n - 3); ii++)
                {
                    if ((ii == i + (n - 2)) || (ii + i - 1 == i + (n - 3)) || (ii + i - 3 == i + (n - 3)))
                          
                       
                    {
                        
                        Console.Write("*");
                        
                    }
                    else 
                    {
                        Console.Write(".");
                    }
                    
                }
                Console.WriteLine();
                
            }
        }
    }
}
