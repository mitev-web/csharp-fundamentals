using System;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int[] bit = new int[n];
        char[] arr = new char[n];
        int[] result = new int[n];
        string[] s = new string[n];
        int [] c = new int[n];
        for (int i = 0; i < n; i++)
        {
            bit[i]=int.Parse(Console.ReadLine());
            string array = Convert.ToString(bit[i], 2);
            char[] arr1 = array.ToCharArray();
            Array.Reverse(arr1);
            s[i] = new string(arr1);
            
        }
        for (int i = 0; i < n; i++)
        {
            int a = bit[i] ^ ~bit[i];
            
            
            
            int integer = Convert.ToInt32(s[i], 2);
            
            int test = a & integer;
            Console.WriteLine(test);
            
        }

    }
}