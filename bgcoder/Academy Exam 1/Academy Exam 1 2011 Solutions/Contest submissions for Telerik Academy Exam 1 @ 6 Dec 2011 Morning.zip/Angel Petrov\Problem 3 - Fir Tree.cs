using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree
{
    class FirTree
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int counter = 1;
            int middle = (((2*N)-3)/2) ;
            for (int i = 0; i < N; i++)
            {                
                if (i == 0 || i == (N - 1))
                {
                    for (int j = 0; j < (2 * N - 3); j++)
                    {
                        if (j != middle)
                        {
                            Console.Write(".");
                        }
                        if (j == middle)
                        {
                            Console.Write("*");
                        }
                    }
                    
                }
                if (i > 0 && i < (N - 1))
                {
                    for (int k = 0; k < (2 * N - 3); k++)
                    {
                        if (k < (middle - counter) || k > (middle + counter))
                        {
                            Console.Write(".");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                     
                    }
                    counter++;
                }
                Console.Write("\n");
            }
        }
    }
}
