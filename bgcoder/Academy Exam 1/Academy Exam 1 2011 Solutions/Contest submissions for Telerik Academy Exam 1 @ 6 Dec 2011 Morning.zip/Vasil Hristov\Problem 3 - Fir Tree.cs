using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Program
    {
        static void Main()
        {
            int mid;
            int N = int.Parse(Console.ReadLine());
            if (N % 2 == 0) { mid = ((N - 3) + N) / 2; }
            else { mid = (((N - 3) + N) )/2; }

            for (int i = 0,p = mid, k = p; i < N-1 ; i++)
            {
                for (int j = 0; j < ((N - 3) + N); j++)
                {
                    
                   if(j>p ||j<k) Console.Write(".");
                   else Console.Write("*");
                   
                }
                p++;
                k--;
                Console.WriteLine();
            }
           
            for (int j = 0; j < ((N - 3) + N); j++)
            {
                if (j == mid) Console.Write("*");
                else Console.Write(".");
            }
            Console.WriteLine();
        }
    }
}
