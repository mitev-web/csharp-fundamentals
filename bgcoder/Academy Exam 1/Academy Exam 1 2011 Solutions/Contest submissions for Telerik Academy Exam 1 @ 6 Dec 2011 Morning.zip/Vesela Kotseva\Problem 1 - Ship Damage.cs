using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShipDamage_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 0;
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = int.Parse(Console.ReadLine());
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = int.Parse(Console.ReadLine());
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = int.Parse(Console.ReadLine());
            int bufX = sx2;
            int bufY = sy2;
            if (sx1 > sx2)
            {
                sx2 = sx1;
                sx1 = bufX;
            }
            if (sy1 > sy2)
            {
                sy2 = sy1;
                sy1 = bufY;
            }

            if(cy1<h)
            {
                cy1 = h + Math.Abs(h - cy1);
                cy2 = h + Math.Abs(h - cy2);
                cy3 = h + Math.Abs(h - cy3);
            }else
            {
                cy1 = h - Math.Abs(h - cy1);
                cy2 = h - Math.Abs(h - cy2);
                cy3 = h - Math.Abs(h - cy3);
            }





            if ((cx1 == sx1) ^ (cx1 == sx2))
            {
                if ((cy1 == sy1) ^ (cy1 == sy2))
                {
                    score = score + 25;
                }
                else if (cy1 > sy1 && cy1 < sy2)
                {
                    score = score + 50;
                }
            }
            else if ((cy1 == sy1) ^ (cy1 == sy2))
            {

                if (cx1 > sx1 && cx1 < sx2)
                {
                    score = score + 50;
                }
            }
            else if ((cx1 > sx1 && cx1 < sx2) && (cy1 > sy1 && cy1 < sy2))
            {
                score = score + 100;
            }
            ///////////////////////
            if ((cx2 == sx1) ^ (cx2 == sx2))
            {
                if ((cy2 == sy1) ^ (cy2 == sy2))
                {
                    score = score + 25;
                }
                else if (cy2 > sy1 && cy2 < sy2)
                {
                    score = score + 50;
                }
            }
            else if ((cy2 == sy1) ^ (cy2 == sy2))
            {
                if (cx2 > sx1 && cx2 < sx2)
                {
                    score = score + 50;
                }
            }
            else if ((cx2 > sx1 && cx2 < sx2) && (cy2 > sy1 && cy2 < sy2))
            {
                score = score + 100;
            }
            ///////////////
            if ((cx3 == sx1) ^ (cx3 == sx2))
            {
                if ((cy3 == sy1) ^ (cy3 == sy2))
                {
                    score = score + 25;
                }
                else if (cy3 > sy1 && cy3 < sy2)
                {
                    score = score + 50;
                }
            }
            else if ((cy3 == sy1) ^ (cy3 == sy2))
            {
                if (cx3 > sx1 && cx3 < sx2)
                {
                    score = score + 50;
                }
            }
            else if ((cx3 > sx1 && cx3 < sx2) && (cy3 > sy1 && cy3 < sy2))
            {
                score = score + 100;
            }
            Console.WriteLine(score + "%");

        }
    }
}
