using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            

             for (int i = 1; i < n + 2; i++)
             { 
                 
                 Console.WriteLine(i <= n ? new String('*', i * 2 - 1).PadLeft(n+1) :"*".PadLeft(n-1));
             }
        }
    }
}

            