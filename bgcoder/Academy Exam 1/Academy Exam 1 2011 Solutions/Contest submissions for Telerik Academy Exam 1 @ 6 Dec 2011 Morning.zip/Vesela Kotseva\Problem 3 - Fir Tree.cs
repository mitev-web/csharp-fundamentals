using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirTree_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int l = 2 * (n - 2) + 1;
            int middle = n - 1;
            int countLeft = n -1;
            int countRight = n ;
            for(int j=1;j<n;j++)
            {
                for (int i = 1; i < l+1; i++)
                {
                    if (i<=middle) 
                    {
                        if(i<countLeft)
                        {
                            Console.Write("."); 
                        }
                
                        if(i>=countLeft)
                        {
                            Console.Write("*");
                        }                        
                    }
                    if(i>middle)
                    {
                        if (i < countRight)
                        {
                            Console.Write("*");
                        }
                        if (i >= countRight)
                        {
                            Console.Write(".");
                        }                       
                    }
                }
                countRight++;
                countLeft--;
                Console.WriteLine();
            }
            for (int i = 1; i <= l; i++)
            {
                if (i == middle)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }
    }
}
