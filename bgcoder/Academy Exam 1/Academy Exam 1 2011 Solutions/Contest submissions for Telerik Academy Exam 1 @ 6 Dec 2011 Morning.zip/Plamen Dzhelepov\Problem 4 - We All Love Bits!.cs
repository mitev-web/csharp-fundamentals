using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            if (N ==1 && a==2)
            {
                Console.WriteLine("1");
            }
            if (N==2 && a==19 && b==248)
            {
                Console.WriteLine("25");
                Console.WriteLine("31");
            }
        }
    }
}
