using System;
class Program
{
    const int INSIDE=1;
    const int OVER=0;
    const int OUTSIDE=-1;

    static void Main(string[] args)
    {
        int sx1 =int.Parse(Console.ReadLine());
        int sy1 = int.Parse(Console.ReadLine());
        int sx2 = int.Parse(Console.ReadLine());
        int sy2 = int.Parse(Console.ReadLine());

        int h = int.Parse(Console.ReadLine());

        int cx1 = int.Parse(Console.ReadLine());
        int cy1 = int.Parse(Console.ReadLine());

        int cx2 = int.Parse(Console.ReadLine());
        int cy2 = int.Parse(Console.ReadLine());

        int cx3 = int.Parse(Console.ReadLine());
        int cy3 = int.Parse(Console.ReadLine());

        int cz1=findLandingY(cy1, h);
        int cz2 = findLandingY(cy2, h);
        int cz3 = findLandingY(cy3, h);

        int damage = 0;
        damage += findDamage(sx1, sy1, sx2, sy2, cx1, cz1);
        damage += findDamage(sx1, sy1, sx2, sy2, cx2, cz2);
        damage += findDamage(sx1, sy1, sx2, sy2, cx3, cz3);
        Console.WriteLine("{0}%",damage);
    }

    static int findLandingY(int cannonY, int h) 
    {
        if (cannonY > h) 
        {
            int difference = cannonY - h;
            return (h - difference);
        }
        else if (cannonY < h) 
        {

            int difference = h - cannonY;
            return (h + difference);
        }
        else 
        {
            return h;
        }
    }

    static int findDamage(int sx1, int sy1, int sx2, int sy2,int cx, int cy)
    {
        int x;
        if(cx==sx1 || cx==sx2)
        {
            x=OVER;
        }
        else if((sx1>cx && sx2<cx)||(sx1<cx && sx2>cx))
        {
            x=INSIDE;
        }
        else
        {
            x=OUTSIDE;
        }

        int y;
        if (cy == sy1 || cy == sy2)
        {
            y = OVER;
        }
        else if ((sy1 > cy && sy2 < cy) || (sy1 < cy && sy2 > cy))
        {
            y = INSIDE;
        }
        else
        {
            y = OUTSIDE;
        }

        //inside
        if(x==INSIDE && y==INSIDE)
        {
            return 100;
        }
        //side
        else if((x==INSIDE && y==OVER)||(y==INSIDE && x==OVER))
        {
            return 50;
        }
        //corner
        else if(x==OVER && y==OVER)
        {
            return 25;
        }
        else
        {
            return 0;
        }
    }
}