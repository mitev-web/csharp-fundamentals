using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace problem1
{
    struct point
    {
        public int x,y;
        public point(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        public void input()
        {
            this.x = Int32.Parse(Console.ReadLine());
            this.y = Int32.Parse(Console.ReadLine());
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            point s1 = new point(), s2 = new point();
            point[] c=new point[3];
            s1.input();
            s2.input();
            if (s1.y > s2.y)
            {
                int temp;
                temp = s1.y;
                s1.y = s2.y;
                s2.y = temp;
            }
            if (s1.x > s2.x)
            {
                int temp;
                temp = s1.x;
                s1.x = s2.x;
                s2.x = temp;
            }
            int h = Int32.Parse(Console.ReadLine());
            for (int i = 0; i < 3; i++)
            {
                c[i].input();
            }
            int damage=0;
            for (int i = 0; i < 3; i++)
            {
                //if (c[i].y >= h) continue;
                damage += check(s1, s2, new point(c[i].x, c[i].y + 2 * (h-c[i].y)));
            }
            Console.WriteLine(damage + "%");
        }
        static int check(point s1, point s2, point c)
        {
            if((c.x==s1.x && c.y==s1.y) || (c.x==s1.x && c.y==s2.y) || (c.x==s2.x && c.y==s1.y) || (c.x==s2.x && c.y==s2.y)) return 25;
            if ((c.x == s1.x && c.y > s1.y && c.y < s2.y) || (c.x == s2.x && c.y > s1.y && c.y < s2.y) || (c.y == s1.y && c.x > s1.x && c.x < s2.x) || (c.y == s2.y && c.x > s1.x && c.x < s2.x)) return 50;
            if (c.x < s2.x && c.x > s1.x && c.y < s2.y && c.y > s1.y) return 100;
            return 0;
        }
    }
}
