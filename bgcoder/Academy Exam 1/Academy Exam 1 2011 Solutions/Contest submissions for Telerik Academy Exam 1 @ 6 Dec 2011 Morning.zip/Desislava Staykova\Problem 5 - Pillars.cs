using System;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int [,] array=new int[8,8];
            
            for (int i = 0; i < 8; i++) 
            {
                    int n = int.Parse(Console.ReadLine());
                    for (int k = 7; k >0; k--) 
                    {
                        array[i,k] = n % 2;
                        n /= 2;
                       
                    }
                }
            
            int br1 ,br2=0,count=0;
            br1=0;
            for (int i = 1; i < 6; i++) 
            {
                for (int k1 = 0; k1 < 8; k1++)
                {
                    for (int j1 = i; j1 > 0; j1--)
                    { if (array[k1, j1] == 1) { br1++; } }
                }
                for (int k2 = 0; k2 < 8;k2++ )
                    for (int j2 = 7; j2 > i+1; j2--)
                    {
                        if (array[k2, j2] == 1) { br2++; }

                    }
                if (br1 == br2 && br1!=0) { Console.WriteLine(i); count++; }
            }
            if (count == 0) { Console.WriteLine("No"); }


        }
    }
}
