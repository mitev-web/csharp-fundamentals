using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tree
{
   class Program
   {
      static void Main(string[] args)
      {
         int n = int.Parse(Console.ReadLine());
         for (int row = 0; row < n; row++)
         {
            for (int col = 1; col <= (2 * n - 2) - 1; col++)
            {
               if (row < n - col - 1 || row < col - n + 1 || row == n - 1 && col != n - 1)
               {
                  Console.Write(".");
                  continue;
               }
               Console.Write("*");
            }
            Console.WriteLine();
         }
      }
   }
}
