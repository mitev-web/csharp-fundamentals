using System;

class Program
{
    static void Main(string[] args)
    {
        int n = 8;
        int[] bit = new int[n];
        for (int i = 0; i < n; i++)
        {
            bit[i] = int.Parse(Console.ReadLine());
        }
        int count = 0;
        int count1 = 0;
        int pillar = 7;
        string ans = "";
        for (int i = 0; i < n; i++)
        {
            count = 0;
            count1 = 0;
            for (int j = 0; j < n; j++)
            {
                for (int pos = 0; pos <n; pos++)
                {
                    if ((bit[j]&(1<<pos)) != 0)
                    {
                        if (pos < i)
                        {
                            count++;
                        }
                        else if (pos > i)
                        {
                            count1++;
                        }
                    }
                    
                }

            }
            if (count > 0 && (count == count1))
            {
                pillar = i; break;
            }
            else if (i == 6 && (count !=count1))
            {
                ans = "No";
            }
        }
        if (ans != "No")
        {
            Console.WriteLine(pillar);
            Console.WriteLine(count);
        }
        else
        {
        Console.WriteLine(ans);
            }

    }
}
