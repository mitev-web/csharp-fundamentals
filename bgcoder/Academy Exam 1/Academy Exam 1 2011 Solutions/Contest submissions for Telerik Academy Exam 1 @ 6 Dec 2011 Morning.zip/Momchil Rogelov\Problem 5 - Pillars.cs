using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            List<byte> members = new List<byte>();
            for (int t = 0; t < 8; t++)
            {
                byte h = Byte.Parse(Console.ReadLine());
                members.Add(h);
            }

            int i = 7;
            bool solution = false;
            int solint=-1;
            int numberOfbytes=-1;
            
            while (i>=0)
            {
                int s =findIfSolution(members,i);
                if (s >= 0)
                {
                    solution = true;
                    solint = i;
                    numberOfbytes = s;
                    break;
                }
                i--;
            }

            if (solution) 
            {
                Console.WriteLine(solint);
                Console.WriteLine(numberOfbytes);
            }
            else
            {
                Console.WriteLine("No");
            }
        }

        static int findIfSolution( List<byte> members, int pillar)
        {
            int right = 0;
            int left = 0;
            foreach (byte m in members)
            {
                right += NumbersOfCells(m,pillar, true);
                left += NumbersOfCells(m,pillar, false);
            }
            if (right == left)
            {
                return right;
            }
            else 
            {
                return -1;
            }
        }
        static int NumbersOfCells(byte n, int pillar, bool right = false)
        {
            int number = 0;
            if (right)
            {
                for (int i = 0; i < pillar; i++)
                {
                    if (getBit(n, i) == 1) number++;
                }
            }
            else
            {
                for (int i = 7; i > pillar; i--)
                {
                    if (getBit(n, i) == 1) number++;
                }
            }
            return number;
        }

        static int getBit(byte myInt, int pos)
        {
            int mask = 1;
            int myInt2 = (int) myInt >> pos;
            return (myInt2 & mask);
        }

    }
}
