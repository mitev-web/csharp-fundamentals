using System;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            short n = short.Parse(Console.ReadLine());
            for (int i = 1; i <= n-3; i++)
            {
                BigInteger tmp1 = t3;
                BigInteger tmp2 = t2;
                t3 = t1 + t2 + t3;
                t2 = tmp1;
                t1 = tmp2;
            }
            Console.WriteLine(t3);
        }
    }
}