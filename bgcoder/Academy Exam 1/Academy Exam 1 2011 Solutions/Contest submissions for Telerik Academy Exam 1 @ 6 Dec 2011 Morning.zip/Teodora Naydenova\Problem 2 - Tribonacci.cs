using System;

namespace Tribonacci
{
    class Program
    {
        static void Main()
        {
            int T1 = int.Parse(Console.ReadLine());
            int T2 = int.Parse(Console.ReadLine());
            int T3 = int.Parse(Console.ReadLine());
            int N = int.Parse(Console.ReadLine());
            int T = 0;
            int z = 0;
            
            for (int i = 3; i <= N; i++)
            {
                T = T1 + T2 + T3;
                T1 = T2;
                T3 = z;
                z = T;
            }
            Console.WriteLine(T);
            
        }
    }
}
