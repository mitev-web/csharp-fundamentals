using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int sx1 = Convert.ToInt32(Console.ReadLine());
            int sy1 = Convert.ToInt32(Console.ReadLine());
            int sx2 = Convert.ToInt32(Console.ReadLine());
            int sy2 = Convert.ToInt32(Console.ReadLine());
            int h = Convert.ToInt32(Console.ReadLine());
            int cx1 = Convert.ToInt32(Console.ReadLine());
            int cy1 = Convert.ToInt32(Console.ReadLine());
            int cx2 = Convert.ToInt32(Console.ReadLine());
            int cy2 = Convert.ToInt32(Console.ReadLine());
            int cx3 = Convert.ToInt32(Console.ReadLine());
            int cy3 = Convert.ToInt32(Console.ReadLine());

            if (sy1 < sy2)
            {
                int z = sy1;
                sy1 = sy2;
                sy2 = z;
            }

            //if (cy1 < h)
            //{
                cy1 = -(cy1 - h);
            //}
            //if (cy2 < h)
            //{
                cy2 = -(cy2 - h);
            //}
            //if (cy3 < h)
            //{
                cy3 = -(cy3 - h);
            //}
            

            
            int a1;
            int a2;
            int a3;
            int b1;
            int b2;
            int b3;
            int c1;
            int c2;
            int c3;


            if (cx1 > sx1 && cx1 < sx2 && cy1 < sy1 && cy1 > sy2)
            {
                a1 = 100;
            }
            else
            {
                a1 = 0;
            }   
            if ((cx1 == sx1 && cy1 == sy1) || (cx1 == sx2 && cy1 == sy2))
            {
                b1 =  25;
            }
            else
            {
                b1 = 0;
            }
            if (cx1 == sx1 || cx1 == sx2 || cy1 == sy1 || cy1 == sy2)
            {                   
                c1 = 50;
            }
            else
            {
                c1 = 0;
            }  
            if (cx2 > sx1 && cx2 < sx2 && cy2 < sy1 && cy2 > sy2)
            {                       
                a2 = 100;
            }
            else
            {
                a2 = 0;
            }
            if (cx2 == sx1 || cx2 == sx2 && cy2 == sy1 || cy2 == sy2)
            {
                b2 = 25;
            }
            else
            {
                b2 = 25;
            }
            if (cx2 == sx1 || cx2 == sx2 && cy2 == sy1 || cy2 == sy2)
            {
                c2 = 50;
            }
            else
            {
                c2 = 0;
            }
            if (cx3 > sx1 && cx3 < sx2 && cy3 < sy1 && cy3 > sy2)
            {
                a3 = 100;
            }
            else
            {
                a3 = 0;
            }
            if (cx3 == sx1 || cx3 == sx2 && cy3 == sy1 || cy3 == sy2)
            {
                b3 = 25;
            }
            else
            {
                b3 = 0;
            }
            if (cx3 == sx1 || cx3 == sx2 && cy3 == sy1 || cy3 == sy2)
            {
                c3 = 50;
            }
            else
            {
                c3 = 0;
            }
                    
                
            Console.WriteLine("{0}%", (a1 + a2 + a3 + b1 + b2 + b3 + c1 + c2 + c3));
            


        }
    }
}
