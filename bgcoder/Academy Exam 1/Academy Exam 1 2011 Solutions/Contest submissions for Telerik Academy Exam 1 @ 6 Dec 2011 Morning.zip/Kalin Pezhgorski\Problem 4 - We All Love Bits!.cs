using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] p = new int[n];
            int[] invertedP = new int[n];
            int[] bitInvertedP = new int[n];
            int[] pNew = new int[n];
            int mask = 1;
            int swap;
            for (int i = 0; i < n; i++)
            {
                p[i] = int.Parse(Console.ReadLine());                
            }
            for (int i = 0; i < n; i++)
            {
       //         Console.WriteLine(Convert.ToString(p[i],2));
                swap = p[i];
                while (mask <= swap)
                {
                    if ((mask & swap) == 0)
                    {
                        invertedP[i] = invertedP[i] | mask;
             //           Console.WriteLine(Convert.ToString(invertedP[i], 2));
                    }
                    else
                    {
                        invertedP[i] = invertedP[i] & (~mask);
            //            Console.WriteLine(Convert.ToString(invertedP[i], 2));
                    }
                    mask <<= 1;
                }
       //         Console.WriteLine(Convert.ToString(invertedP[i],2));
                mask = 1;
                swap = p[i];
                while (swap > 0)
                {
                    if ((swap & mask) == 0)
                    {
                        bitInvertedP[i] <<= 1;
                    }
                    else
                    {
                        bitInvertedP[i] <<= 1;
                        bitInvertedP[i]++;
                    }
                    swap >>= 1;
                }
                pNew[i] = (p[i] ^ invertedP[i]) & bitInvertedP[i];
                Console.WriteLine(pNew[i]);

    //                 Console.WriteLine(Convert.ToString(bitInvertedP[i],2));
            }
            //for (int i = 0; i < n; i++)
            //{
            //    pNew[i] = (p[i] ^ invertedP[i]) & bitInvertedP[i];
            //    Console.WriteLine(pNew[i]);
            //}
        }
    }
}
