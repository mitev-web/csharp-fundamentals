using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pillarss
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] n = new char[8, 8];
            int Ni;

            for (int i = 0; i < 8; i++)
            {
                Ni = int.Parse(Console.ReadLine());
                string binary = Convert.ToString(Ni, 2);
                for (int j = 0; j < 8; j++)
                {
                    while (Ni > 0)
                    {
                        int bit = Ni & 1;
                        if (bit == 1)
                        {
                            n[i, j] = '1';
                        }
                        else
                        {
                            n[i, j] = '0';
                        }
                        Ni = Ni >> 1;
                        j++;
                    }
                    if (j < 8)
                    {
                        n[i, j] = '0';
                    }
                }
            }

            for (int k = 7; k >= 0; k--)
            {
                int leftCount = 0, rightCount = 0;
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 7; j > k; j--)
                    {
                        if (n[i, j] == '1')
                        {
                            leftCount++;
                        }
                    }

                    for (int j = k - 1; j >= 0; j--)
                    {
                        if (n[i, j] == '1')
                        {
                            rightCount++;
                        }
                    }
                }

                if (leftCount == rightCount)
                {
                    Console.WriteLine(k);
                    Console.WriteLine(leftCount);
                    return;
                }



            }
            Console.WriteLine("No");

        }
    }
}