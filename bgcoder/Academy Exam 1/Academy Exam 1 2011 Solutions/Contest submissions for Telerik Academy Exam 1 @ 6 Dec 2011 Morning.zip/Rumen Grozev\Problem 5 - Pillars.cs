using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem5_Pillars
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, tempSum = 0, sum1 = 0, sum2 = 0, k, count = 0, tempCol = -1;
            //int[] nums = new int[8] { 0, 64, 0, 8, 0, 12, 224, 0 };
            int[] nums = new int[8] { 3, 0, 0, 0, 0, 0, 0, 0 };
            int[,] bits = new int[8, 8];

            //Console.WriteLine((1 << 8 - 4));
            for (i = 0; i < 8; i++)
            {
                nums[i] = int.Parse(Console.ReadLine());
            }
            

            for (i = 0; i < 8; i++)
            {
                for (j = 7; j >= 0; j--)
                {
                    if ((nums[i] & (1 << j)) != 0)
                    {
                        bits[i, 7 - j] = 1;
                    }
                }
            }

            /*for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 8; j++)
                {
                    Console.Write(bits[i, j]);
                }
                Console.WriteLine();
            }*/

            for (i = 0; i < 8; i++)
            {
                sum1 = 0;
                for (j = 0; j < i; j++)
                {
                    for (k = 0; k < 8; k++)
                    {
                        if (bits[k, j] == 1)
                        {
                            sum1++;
                        }
                    }
                }
                sum2 = 0;
                for (j = i + 1; j < 8; j++)
                {
                    for (k = 0; k < 8; k++)
                    {
                        if (bits[k, j] == 1)
                        {
                            sum2++;
                        }
                    }
                }
                //Console.WriteLine("{0}, {1}", sum1, sum2);
                if (sum1 == sum2)
                {
                    count++;
                    if (count == 1)
                    {
                        tempCol = 7 - i;
                        tempSum = sum1;
                    }
                    //Console.WriteLine("{0}\n{1}",7 - i,sum1);
                }
            }
            if (count == 1)
            {
                Console.WriteLine("{0}\n{1}",tempCol,tempSum);
            }
            else if (count > 1)
            {
                Console.WriteLine(tempCol);
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
