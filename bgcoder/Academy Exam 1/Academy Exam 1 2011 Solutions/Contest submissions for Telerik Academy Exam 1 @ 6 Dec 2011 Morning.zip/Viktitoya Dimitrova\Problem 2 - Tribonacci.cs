using System;
using System.Numerics;

namespace Tribonac
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger n1 = BigInteger.Parse(Console.ReadLine());
            BigInteger n2 = BigInteger.Parse(Console.ReadLine());
            BigInteger n3 = BigInteger.Parse(Console.ReadLine());
            BigInteger n4 = 1;
            int n = int.Parse(Console.ReadLine());

            for (int i = 3; i < n; i++)
            {
                n4 = n3 + n2 + n1;
                BigInteger temp = n3;
                n3 = n4;
                BigInteger temp2 = n2;
                n2 = temp;
                n1 = temp2;
                
            }
            Console.WriteLine(n4);

                

        }
    }
}
