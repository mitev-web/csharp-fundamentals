using System;

namespace ThirdProblem
{
    class Third
    {
        static void Main(string[] args)
        {
            string readValue = Console.ReadLine();
            byte value = byte.Parse(readValue);
            for (int i = 0; i < value; i++)
            {
                int center = value - 1;
                if (i==0 || i==value-1)
	            {
		            for (int p = 0; p < value + (value-3); p++)
			        {
			            if (p == value - 2)
                        {
                            Console.Write("*");
                        }
                        else 
                        {
                            Console.Write(".");
                        }
			        }
	            }
                else if (i == value - 2)
                {
                    for (int u = 0; u < value + (value - 3); u++)
                    {
                        Console.Write("*");
                    }
                }
                else if (i >= 1 && i <= value - 2)
                {
                    for (int t = 0; t < value + (value - 3); t++)
                    {
                        if (t == center - i-1 )
                        {
                            Console.Write("*");
                        }
                        else if (t == center + i-1)
                        {
                            Console.Write("*");
                        }
                        else if (t > center - i - 1 && t < center + i - 1)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(".");
                        }
                    }
                }
                Console.WriteLine();
            } 
        }
    }
}
