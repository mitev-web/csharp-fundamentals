using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            
            double sum = 0;
            if (Cy1 < 0 || Cy2 < 0 || Cy3 < 0)
            {
                if (Sx1 + Sy1 - H == Cx1 - Cy1 + H)
                {
                    sum = sum + 0.25;
                }
                if (Sx2 + Sy2 - H == Cx1 - Cy1 + H)
                {
                    sum = sum + 0.25;
                }
                if (Sx1 + Sy1 - H == Cx2 - Cy2 + H)
                {
                    sum = sum + 0.25;
                }
                if (Sx2 + Sy2 - H == Cx2 - Cy2 + H)
                {
                    sum = sum + 0.25;
                }
                if (Sx1 + Sy1 - H == Cx3 - Cy3 + H)
                {
                    sum = sum + 0.25;
                }
                if (Sx2 + Sy2 - H == Cx3 - Cy3 + H)
                {
                    sum = sum + 0.25;
                }
                if (Sy1 - H == -Cy1 + H)
                {
                    sum = sum + 0.50;
                }
                if (Sy2 - H == -Cy1 + H)
                {
                    sum = sum + 0.50;
                }
                if (Sy1 - H == -Cy2 + H)
                {
                    sum = sum + 0.50;
                }
                if (Sy2 - H == -Cy2 + H)
                {
                    sum = sum + 0.50;
                }
                if (Sy1 - H == -Cy3 + H)
                {
                    sum = sum + 0.50;
                }
                if (Sy2 - H == -Cy3 + H)
                {
                    sum = sum + 0.50;
                }
            }
                if (Cy1 > 0 || Cy2 > 0 || Cy3 > 0)
                {
                    if (Sx1 + Sy1 - H == Cx1 + Cy1 + H)
                    {
                        sum = sum + 0.25;
                    }
                    if (Sx2 + Sy2 - H == Cx1 + Cy1 + H)
                    {
                        sum = sum + 0.25;
                    }
                    if (Sx1 + Sy1 - H == Cx2 + Cy2 + H)
                    {
                        sum = sum + 0.25;
                    }
                    if (Sx2 + Sy2 - H == Cx2 + Cy2 + H)
                    {
                        sum = sum + 0.25;
                    }
                    if (Sx1 + Sy1 - H == Cx3 + Cy3 + H)
                    {
                        sum = sum + 0.25;
                    }
                    if (Sx2 + Sy2 - H == Cx3 + Cy3 + H)
                    {
                        sum = sum + 0.25;
                    }
                    if (Sy1 - H == Cy1 + H)
                    {
                        sum = sum + 0.50;
                    }
                    if (Sy2 - H == Cy1 + H)
                    {
                        sum = sum + 0.50;
                    }
                    if (Sy1 - H == Cy2 + H)
                    {
                        sum = sum + 50;
                    }
                    if (Sy2 - H == Cy2 + H)
                    {
                        sum = sum + 0.50;
                    }
                    if (Sy1 - H == Cy3 + H)
                    {
                        sum = sum + 0.50;
                    }
                    if (Sy2 - H == Cy3 + H)
                    {
                        sum = sum + 0.50;
                    }
                
                   
                
 }
                
                
            Console.WriteLine("{0:P}",sum);
        }
    }
}
