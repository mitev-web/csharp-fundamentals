using System;

namespace ShipDamage
{
    class Program
    {
        static int GetOffsetedX(int H,int x)
        {
            return 2 * H - x;
        }
        static int GetIntersection(int maxx, int maxy, int minx, int miny,int ptx,int pty)
        {
            if (ptx < maxx && ptx > minx && pty < maxy && pty > miny) return 100;
            if ((ptx == maxx || ptx == minx) && pty > miny && pty < maxy) return 50;
            if ((pty == maxy || pty == miny) && ptx > minx && ptx < maxx) return 50;
            if (ptx == maxx && pty == maxy) return 25;
            if (ptx == maxx && pty == miny) return 25;
            if (ptx == minx && pty == maxy) return 25;
            if (ptx == minx && pty == miny) return 25;
            return 0;
        }
        static void Main(string[] args)
        {
            int sx1 = int.Parse(Console.ReadLine());
            int sy1 = int.Parse(Console.ReadLine());
            int sx2 = int.Parse(Console.ReadLine());
            int sy2 = int.Parse(Console.ReadLine());

            int H = int.Parse(Console.ReadLine());

            int cx1 = int.Parse(Console.ReadLine());
            int cy1 = GetOffsetedX(H, int.Parse(Console.ReadLine()));
            int cx2 = int.Parse(Console.ReadLine());
            int cy2 = GetOffsetedX(H, int.Parse(Console.ReadLine()));
            int cx3 = int.Parse(Console.ReadLine());
            int cy3 = GetOffsetedX(H, int.Parse(Console.ReadLine()));


            int maxX = Math.Max(sx1, sx2);
            int maxY = Math.Max(sy1, sy2);
            int minX = Math.Min(sx1, sx2);
            int minY = Math.Min(sy1, sy2);

            int result = GetIntersection(maxX, maxY, minX, minY, cx1, cy1);
            result += GetIntersection(maxX, maxY, minX, minY, cx2, cy2);
            result += GetIntersection(maxX, maxY, minX, minY, cx3, cy3);

            Console.WriteLine(result+"%");
        }
    }
}