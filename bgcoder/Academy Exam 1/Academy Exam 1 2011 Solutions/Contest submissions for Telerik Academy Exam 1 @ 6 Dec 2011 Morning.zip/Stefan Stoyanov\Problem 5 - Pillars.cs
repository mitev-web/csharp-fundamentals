using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FallDown
{
    class Program
    {
        static void Main(string[] args)
        {
            byte size = 8;
            byte[] numbers = new byte[size];
            bool[,] squareGrid = new bool[size, size];
            int rightCount = 0, leftCount = 0;
            bool l = true; 

            for (int i = 0; i < size; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }
            for (int i = 0; i < size; i++)
            {
                for (int k = size - 1; k >= 0; k--)
                {
                    if (numbers[i] % 2 == 0)
                    {
                        squareGrid[i, k] = false;
                    }
                    else
                    {
                        squareGrid[i, k] = true;
                    }
                    numbers[i] /= 2;
                    
                }              
            }

            for (int pillar = 0; pillar < size && l; pillar++)
            {
                for (int col = 0; col < pillar && l; col++)
                {
                    for (int row = 0; row < size; row++)
                    {
                        if (squareGrid[row, col])
                        {
                            rightCount++;
                        }
                    }
                }

                for (int col = pillar + 1; col < size; col++)
                {
                    for (int row = 0; row < size; row++)
                    {
                        if (squareGrid[row, col])
                        {
                            leftCount++;
                        }
                    }
                }

                    if (rightCount == leftCount)
                    {
                        if (rightCount == 0 && leftCount == 0)
                        {
                            Console.WriteLine(size - pillar - 1);
                            Console.WriteLine(rightCount);
                            l = false;
                        }
                        else
                        {
                            l = false;
                            Console.WriteLine(size - pillar - 1);
                            Console.WriteLine(rightCount);
                        }
                        
                    }
                
                leftCount = 0;
                rightCount = 0;
            }
            if (l)
            {
                Console.WriteLine("No");                
            }     
        }
    }
}
