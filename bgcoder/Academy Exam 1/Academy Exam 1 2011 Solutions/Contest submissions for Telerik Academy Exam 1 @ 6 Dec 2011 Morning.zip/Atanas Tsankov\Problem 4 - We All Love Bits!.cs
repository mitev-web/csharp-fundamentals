using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int newNumber;
                int backwardsP=0;
                int counter = 1;
                int number = int.Parse(Console.ReadLine());
                string mask = Convert.ToString(number, 2);
                BigInteger binaryNumber = BigInteger.Parse(mask);
                do
                {
                    binaryNumber = binaryNumber / 10;
                    counter++;
                } while (binaryNumber > 1);

                for (int j = 0; j < counter; j++)
                {

                    int temp = 1 << j;
                    int nAndTemp = number & temp;
                    int bit = nAndTemp >> j;
                    if (bit == 0)
                    {
                        int tempMask = ~(1 << ((counter - 1) - j));
                        newNumber = 0 & tempMask;
                    }
                    else
                    {
                        int tempMask = 1 << ((counter - 1) - j);
                        newNumber = 0 | tempMask;
                    }
                    backwardsP = backwardsP | newNumber;
                }
                int reverseP = ~(number);
                int newP = (number ^ reverseP) & backwardsP;
                Console.WriteLine(newP);
            }
        }
    }
}