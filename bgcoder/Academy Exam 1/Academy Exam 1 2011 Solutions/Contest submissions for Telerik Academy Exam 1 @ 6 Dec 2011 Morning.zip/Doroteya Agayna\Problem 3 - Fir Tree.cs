using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int size, start, count = 0;
            int i = 0, j;
            string last = "";
            n = byte.Parse(Console.ReadLine());
            size =  5 + (n - 4) * 2;
            start = (size / 2);
            count = 1;
            for (j = 0; j < n - 1; j++)
            {
                for (i = 0; i < size; i++)
                {
                    if (i < start || i >= (start + count))
                    {
                        Console.Write(".");
                        if (j == 0)
                        {
                            last = last + ".";
                        }
                    }
                    else
                    {
                        Console.Write("*");
                        if (j == 0)
                        {
                            last = last + "*";
                        }
                    }
                }
                start--;
                count = count + 2;
                Console.Write("\n");
            }
            Console.WriteLine(last);
        }
    }
}
