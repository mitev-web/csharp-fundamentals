using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());

            BigInteger n = BigInteger.Parse(Console.ReadLine());

            BigInteger d = 0;

            if (n == 1)
            {
                Console.WriteLine(a);
            }
            else if (n == 2)
            {
                Console.WriteLine(b);
            }
            else if (n == 3)
            {
                Console.WriteLine(c);
            }
            else
            {
                for (int i = 4; i <= n; i++)
                {
                    d = a + b + c;
                    a = b;
                    b = c;
                    c = d;

                }
                Console.WriteLine(d);
            }
            
        }
    }
}
