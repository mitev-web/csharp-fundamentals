using System;
using System.Numerics;


namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger t1 = BigInteger.Parse(Console.ReadLine());
            BigInteger t2 = BigInteger.Parse(Console.ReadLine());
            BigInteger t3 = BigInteger.Parse(Console.ReadLine());
            BigInteger n = BigInteger.Parse(Console.ReadLine());

            BigInteger temp;
            temp = t1 + t2 + t3;
             for (int i = 4; i < n; i++)
                {
                    t1 = t2;
                    t2 = t3;
                    t3 = temp;
                    temp =t1 + t2+t3;
                     
                }Console.WriteLine(temp);
          
            
            }
            
           
                    }
                
            }
