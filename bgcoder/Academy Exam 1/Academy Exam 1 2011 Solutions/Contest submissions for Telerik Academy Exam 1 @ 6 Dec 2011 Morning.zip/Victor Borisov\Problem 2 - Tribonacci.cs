using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Tribonacci
    {
        static void Main(string[] args)
        {
            BigInteger previous1 = BigInteger.Parse(Console.ReadLine());
            BigInteger previous2 = BigInteger.Parse(Console.ReadLine());
            BigInteger previous3 = BigInteger.Parse(Console.ReadLine());
            uint n = uint.Parse(Console.ReadLine());

            BigInteger currentNum;

            if (n == 1)
            {
                Console.WriteLine(previous1);
            }
            if (n == 2)
            {
                Console.WriteLine(previous2);
            }
            if (n == 3)
            {
                Console.WriteLine(previous3);
            }

            for (int i = 4; i <= n; i++)
            {
                currentNum = previous1 + previous2 + previous3;
                previous1 = previous2;
                previous2 = previous3;
                previous3 = currentNum;
                if (i == n)
                {
                    Console.WriteLine(currentNum);
                }
            }
        }
    }
}