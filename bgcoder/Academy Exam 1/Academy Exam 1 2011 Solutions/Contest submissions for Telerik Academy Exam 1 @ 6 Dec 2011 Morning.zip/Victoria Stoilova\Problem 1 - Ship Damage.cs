using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem1
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine();
            int Sx1 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int Sy1 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int Sx2 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int Sy2 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int H = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int Cx1 = int.Parse(Console.ReadLine());
            Console.WriteLine();
            int Cy1 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int Cx2 = int.Parse(Console.ReadLine());
            Console.WriteLine();
            int Cy2 = int.Parse(Console.ReadLine());

            Console.WriteLine();
            int Cx3 = int.Parse(Console.ReadLine());
            Console.WriteLine();
            int Cy3 = int.Parse(Console.ReadLine());

            int dmg1 = 25;
            int dmg2 = 50;
            int dmg3 = 100;
            int final;
            if (Cy1 < 0)
            { Cy1 = Cy1 * (-1); }
            int hit1y = H +Cy1;
            int hit1x = Cx1;
            int hit1 = 0;
            if (Cy2 < 0)
            { Cy2 = Cy2 * (-1); }
            int hit2y = H +Cy2;
            int hit2x = Cx2;
            int hit2 = 0;
            if (Cy3 < 0)
            { Cy3 = Cy3 * (-1); }
            int hit3y = H +Cy3;
            int hit3x = Cx3;
            int hit3 = 0;

            
            //corners hit

            if ((hit1x == Sx1 || hit1x == Sx2) && (hit1y == Sy1 || hit1y == Sy2))
            {
                hit1 = dmg1;
            }
            
            if ((hit2x == Sx1 || hit2x == Sx2) && (hit2y == Sy1 || hit2y == Sy2))
            {
                hit2 = dmg1;
            }
            
            if ((hit3x == Sx1 || hit3x == Sx2) && (hit3y == Sy1 || hit3y == Sy2))
            {
                hit3 = dmg1;
            }
            //inside hit
            if (hit1x > Sx1 && hit1x < Sx2 && hit1y < Sy1 && hit1y > Sy2)
            {
                hit1+= dmg3;
            }

            if (hit2x > Sx1 && hit2x < Sx2 && hit2y < Sy1 && hit2y > Sy2)
            {
                hit2 += dmg3;
            }

            if (hit3x > Sx1 && hit3x < Sx2 && hit3y < Sy1 && hit3y > Sy2)
            {
                hit3 += dmg3;

            }
            //lines hit
            if (hit1x == Sx1 || hit1x == Sx2 || hit1y == Sy1 || hit1y == Sy2)
            {
                hit1 += dmg2;
            }


            if (hit2x == Sx1 || hit2x == Sx2 || hit2y == Sy1 || hit2y == Sy2)
            {
                hit2 += dmg2;
            }

            if (hit3x == Sx1 || hit3x == Sx2 || hit3y == Sy1 || hit3y == Sy2)
            {
                hit3 += dmg2;
            }

            final = hit1 + hit2 + hit3;
            Console.WriteLine(final+"%");
        }
    }
}