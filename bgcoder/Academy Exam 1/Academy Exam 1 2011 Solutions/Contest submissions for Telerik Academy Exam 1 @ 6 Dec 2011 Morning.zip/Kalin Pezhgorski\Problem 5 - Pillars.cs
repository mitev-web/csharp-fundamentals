using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace Pillarrs
{
    class Pillars
    {
        static void Main(string[] args)
        {
            int countLeft = 1;
            int countRight = 1;
            byte[] numbers = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                numbers[i] = byte.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & (1 << 7)) != 0)
                {
                    countLeft++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & ((1 << 6) - 1)) != 0)
                {
                    countRight++;
                }
            }
            if (countLeft == countRight && countLeft != 0)
            {
                Console.WriteLine("6");
                Console.WriteLine(countRight);
                return;
            }
            countLeft = 0;
            countRight = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & (3 << 6)) != 0)
                {
                    countLeft++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & ((1 << 5) - 1)) != 0)
                {
                    countRight++;
                }
            }
            if (countLeft == countRight && countLeft != 0)
            {
                Console.WriteLine("5");
                Console.WriteLine(countRight);
                return;
            }
            countLeft = 0;
            countRight = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & (7 << 5)) != 0)
                {
                    countLeft++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & ((1 << 4) - 1)) != 0)
                {
                    countRight++;
                }
            }
            if (countLeft == countRight && countLeft != 0)
            {
                Console.WriteLine("4");
                Console.WriteLine(countRight);
                return;
            }
            countLeft = 0;
            countRight = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & (15 << 4)) != 0)
                {
                    countLeft++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & ((1 << 3) - 1)) != 0)
                {
                    countRight++;
                }
            }
            if (countLeft == countRight && countLeft != 0)
            {
                Console.WriteLine("3");
                Console.WriteLine(countRight);
                return;
            }
            countLeft = 0;
            countRight = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & (31 << 3)) != 0)
                {
                    countLeft++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & ((1 << 2) - 1)) != 0)
                {
                    countRight++;
                }
            }
            if (countLeft == countRight && countLeft != 0)
            {
                Console.WriteLine("2");
                Console.WriteLine(countRight);
                return;
            }
            countLeft = 0;
            countRight = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & (63 << 2)) != 0)
                {
                    countLeft++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                if ((numbers[i] & ((1 << 1) - 1)) != 0)
                {
                    countRight++;
                }
            }
            if (countLeft == countRight && countLeft != 0)
            {
                Console.WriteLine("1");
                Console.WriteLine(countRight);
                return;
            }
            Console.WriteLine("No");
        }
    }
}