using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeAllLoveBits
{
    class WeAllLoveBits
    {
        static void Main(string[] args)
        {
            int N;
            int pInverted = 0;
            int pReversed;
            int p;
            int msb;
            int lsb;
            int k = 0;
            int counter = 0;
            int counter2 = 0;
            N = int.Parse(Console.ReadLine());
            for (int i = 0; i < N; i++)
            {
                p = int.Parse(Console.ReadLine());
                pInverted = p;
                do
                {
                    pInverted = pInverted >> 1;
                    counter++;
                } while (pInverted != 0);
                pInverted = p;
                do
                {
                    pInverted ^= (1 << k);
                    k++;
                } while (k != counter);
                pReversed = p;
                int executions = counter / 2;
                do
                {
                    lsb = pReversed & (1 << counter2);
                    msb = pReversed & (1 << (counter - 1));
                    msb >>= counter - 1;
                    lsb >>= counter2;

                    if (lsb != msb)
                    {
                        pReversed ^= 1 << counter2;
                        pReversed ^= 1 << counter - 1;
                    }
                    counter2++;
                    counter--;
                } while (executions != counter2);
                counter = 0;
                counter2 = 0;
                k = 0;
                p = (p ^ pInverted) & pReversed;
                Console.WriteLine(p);
            }
        }
    }
}


