using System;
using System.Numerics;

namespace RealExam02
{
    class RealExam02
    {
        static void Main()
        {
            BigInteger a = BigInteger.Parse(Console.ReadLine());
            BigInteger b = BigInteger.Parse(Console.ReadLine());
            BigInteger c = BigInteger.Parse(Console.ReadLine());
            int lines = int.Parse(Console.ReadLine());
            BigInteger d = 0;

            for (int i = 0; i <lines-3; i++)
            {
                d = a + b + c;
                a = b;
                b = c;
                c = d;
            }
            Console.WriteLine(d);
        }  
    }
}
