using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ship_Damage
{
    class Program
    {
        static void Main(string[] args)
        {
            int sX1 = int.Parse(Console.ReadLine());
            int sY1 = int.Parse(Console.ReadLine());
            int sX2 = int.Parse(Console.ReadLine());
            int sY2 = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int cX1 = int.Parse(Console.ReadLine());
            int cY1 = int.Parse(Console.ReadLine());
            int cX2 = int.Parse(Console.ReadLine());
            int cY2 = int.Parse(Console.ReadLine());
            int cX3 = int.Parse(Console.ReadLine());
            int cY3 = int.Parse(Console.ReadLine());

            int damage = 0;

            int shot1X = cX1;
            int shot1Y = (System.Math.Abs(cY1) + 2*h);

            int shot2X = cX2;
            int shot2Y = (System.Math.Abs(cY2) + 2 * h);

            int shot3X = cX1;
            int shot3Y = (System.Math.Abs(cY3) + 2 * h);

            if (((shot1X > sX1) && (shot1X < sX2)) && ((shot1Y > sY2) && (shot1Y < sY1)))
            {
                damage += 100;
            }

            if ((shot1X == sX1) || (shot1X == sX2))
            {
                if ((shot1Y > sY2) && (shot1Y < sY1))
                {
                    damage += 50;
                }
            }

            if ((shot1X > sX1) && (shot1X < sX2))
            {
                if ((shot1Y == sY2) || (shot1Y == sY1))
                {
                    damage += 50;
                }
            }

            if (((shot1X == sX1) || (shot1X == sX2)) && (((shot1Y == sY2) || (shot1Y == sY1))))
            {
                    damage += 25;
            }

            if (((shot2X > sX1) && (shot2X < sX2)) && ((shot2Y > sY2) && (shot2Y < sY1)))
            {
                    damage += 100;
            }

            if ((shot2X == sX1) || (shot2X == sX2))
            {
                if ((shot2Y > sY2) && (shot2Y < sY1))
                {
                    damage += 50;
                }
            }

            if ((shot2X > sX1) && (shot2X < sX2))
            {
                if ((shot2Y == sY2) || (shot2Y == sY1))
                {
                    damage += 50;
                }
            }

            if (((shot2X == sX1) || (shot2X == sX2)) && (((shot2Y == sY2) || (shot2Y == sY1))))
            {
                    damage += 25;
            }

            if (((shot3X > sX1) && (shot3X < sX2)) && ((shot3Y > sY2) && (shot3Y < sY1)))
            {
                    damage += 100;
            }

            if ((shot3X == sX1) || (shot3X == sX2))
            {
                if ((shot3Y == sY2) || (shot3Y == sY1))
                {
                    damage += 25;
                }
            }

            else
            {
                if ((shot3X == sX1) || (shot3X == sX2))
                {
                    if ((shot3Y > sY2) && (shot3Y < sY1))
                    {
                        damage += 50;
                    }
                }
                else
                {
                    if ((shot3X > sX1) && (shot3X < sX2))
                    {
                        if ((shot3Y == sY2) || (shot3Y == sY1))
                        {
                            damage += 25;
                        }
                    }
                }
            }
            
            

            Console.WriteLine(damage + ("%"));



            

        }
    }
}
