using System;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger T1 = BigInteger.Parse(Console.ReadLine());
            BigInteger T2 = BigInteger.Parse(Console.ReadLine());
            BigInteger T3 = BigInteger.Parse(Console.ReadLine());
            BigInteger T0 = 0;
            ushort N = ushort.Parse(Console.ReadLine());
            for (int i = 4; i <= N; i++)
            {
                T0 = T1;
                T1 = T2;
                T2 = T3;
                T3 = T2 + T1 + T0;
            }
            Console.WriteLine(T3);
        }
    }
}
