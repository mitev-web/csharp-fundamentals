using System;

namespace Pillars
{
    class Program
    {
        static bool[,] TheGrid;
        static void InitializeGrid()
        {
            TheGrid = new bool[8, 8];
            for(int i=0;i<8;i++)
                for (int j = 0; j < 8; j++)
                {
                    TheGrid[i, j] = false;
                }
        }
        static int FindCellsInRegion(int a,int b)
        {
            int result = 0;
            for (int i = 0; i < 8; i++)
            {
                for (int j = a; j <= b; j++)
                {
                    if (TheGrid[i, j]) result++;
                }
            }
            return result;
        }
        static void FillGrid()
        {
            for (int i = 0; i < 8; i++)
            {
                short n = short.Parse(Console.ReadLine());
                for (int j = 0; j < 8; j++)
                {
                    if (n % 2 == 1) TheGrid[i, j] = true;
                    n = (short)(n >> 1);
                }
            }
        }
        static void Main(string[] args)
        {
            InitializeGrid();
            FillGrid();
            if(FindCellsInRegion(0,6)==0)
            {
                Console.WriteLine(7);
                Console.WriteLine(0);
                return;
            }
            for (int i = 6; i >= 1; i--)
            {
                if (FindCellsInRegion(i + 1, 7) == FindCellsInRegion(0, i - 1))
                {
                    Console.WriteLine(i);
                    Console.WriteLine(FindCellsInRegion(i + 1, 7));
                    return;
                }
            }
            if(FindCellsInRegion(1,7)==0)
            {
                Console.WriteLine(0);
                Console.WriteLine(0);
                return;
            }
            Console.WriteLine("No");
        }
    }
}
