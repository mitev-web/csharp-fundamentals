using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ship
{
    class Program
    {
        static void Main(string[] args)
        {
            int x1;
            int x3;
            int y1;
            int y3;

            x1 = int.Parse(Console.ReadLine());
            y1 = int.Parse(Console.ReadLine());
            x3 = int.Parse(Console.ReadLine());
            y3 = int.Parse(Console.ReadLine());
          
       

            int h;
            h = int.Parse(Console.ReadLine());

            int cx;
            int cy;
            int damage = 0;

            int br=0;
            while (br < 3)
            {
                cx = int.Parse(Console.ReadLine());
                cy = int.Parse(Console.ReadLine());
                cy = h + (h - cy);
                if(cx>Math.Min(x1,x3) && cx<Math.Max(x1,x3) && cy<Math.Max(y1,y3) && cy>Math.Min(y1,y3))
                {
                    damage = damage + 100;
                }
                if(cx==x1 && cy==y1)
                {
                    damage = damage + 25;
                }
                if (cx == x1 && cy == y3)
                {
                    damage = damage + 25;
                }
                if (cx == x3 && cy == y1)
                {
                    damage = damage + 25;
                }
                if (cx == x3 && cy == y3)
                {
                    damage = damage + 25;
                }


                if (cx < Math.Min(x1, x3) && cx > Math.Max(x1, x3) && cy > Math.Max(y1, y3) && cy < Math.Min(y1, y3))
                {

                }
                else
                {
                    damage = damage + 50;
                }




                br++;
            }   

            Console.WriteLine(damage);


            
            

        }
    }
}
