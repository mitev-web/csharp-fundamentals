using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            input = Console.ReadLine();

            byte n = byte.Parse(input);

            byte firstRowDotsEnd = (byte)(n - 2);
            byte starsCount = 1;
            byte rowLenght = (byte)(starsCount + (n - 2) * 2);

            for (int j = 0; j < n - 1; j++)
            {
                for (int i = 0; i < firstRowDotsEnd; i++)
                {
                    Console.Write('.');
                }

                for (int i = 0; i < starsCount; i++)
                {
                    Console.Write('*');
                }

                for (int i = 0; i < rowLenght - starsCount - firstRowDotsEnd; i++)
                {
                    Console.Write('.');
                }

                firstRowDotsEnd--;
                starsCount += 2;
                Console.WriteLine();
            }

            firstRowDotsEnd = (byte)(n - 2);
            starsCount = 1;
            rowLenght = (byte)(starsCount + (n - 2) * 2);

            for (int i = 0; i < firstRowDotsEnd; i++)
            {
                Console.Write('.');
            }

            for (int i = 0; i < starsCount; i++)
            {
                Console.Write('*');
            }

            for (int i = 0; i < rowLenght - starsCount - firstRowDotsEnd; i++)
            {
                Console.Write('.');
            }
        }
    }
}
