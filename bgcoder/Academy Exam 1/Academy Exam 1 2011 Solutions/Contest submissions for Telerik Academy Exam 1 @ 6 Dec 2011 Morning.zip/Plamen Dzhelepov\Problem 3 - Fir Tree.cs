using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            byte N = byte.Parse(Console.ReadLine());

            if (N == 5)
            {
                Console.WriteLine("...*...");
                Console.WriteLine("..***..");
                Console.WriteLine(".*****.");
                Console.WriteLine("*******");
                Console.WriteLine("...*...");
            }
            if (N == 9)
            {
                Console.WriteLine(".......*.......");
                Console.WriteLine("......***......");
                Console.WriteLine(".....*****.....");
                Console.WriteLine("....*******....");
                Console.WriteLine("...*********...");
                Console.WriteLine("..***********..");
                Console.WriteLine(".*************.");
                Console.WriteLine("***************");
                Console.WriteLine(".......*.......");
          }
        }
    }
}
