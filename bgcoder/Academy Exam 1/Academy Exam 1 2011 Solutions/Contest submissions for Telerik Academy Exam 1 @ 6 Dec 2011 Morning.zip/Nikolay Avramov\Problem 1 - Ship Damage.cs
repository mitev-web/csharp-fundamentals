using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exam6DecProblem1
{
    class Program
    {
        static void Main(string[] args)
        {
            int Sx1 = int.Parse(Console.ReadLine());
            int Sy1 = int.Parse(Console.ReadLine());
            int Sx2 = int.Parse(Console.ReadLine());
            int Sy2 = int.Parse(Console.ReadLine());
            int H = int.Parse(Console.ReadLine());
            int Cx1 = int.Parse(Console.ReadLine());
            int Cy1 = int.Parse(Console.ReadLine());
            int y1 = (-1)*Cy1 + 2 * H;
            int x1 = Cx1;
            int Cx2 = int.Parse(Console.ReadLine());
            int Cy2 = int.Parse(Console.ReadLine());
            int y2 = (-1)*Cy2 + 2 * H;
            int x2 = Cx2;
            int Cx3 = int.Parse(Console.ReadLine());
            int Cy3 = int.Parse(Console.ReadLine());
            int y3 = (-1)*Cy3 + 2 * H;
            int x3 = Cx3;
            int damage = 0;
            int bottom;
            int top;
            if (Sy1 < Sy2)
            {
                bottom = Sy1;
                top = Sy2;
            }
            else 
            {
                bottom = Sy2;
                top = Sy1;
            }
            int left;
            int right;
            if (Sx1 < Sx2)
            {
                right = Sx2;
                left = Sx1;
            }
            else
            {
                right = Sx1;
                left = Sx2;
            }


            if (x1 == left || x1 == right || x2 == left || x2 == right || x3 == left || x3 == right)
            {

                if ((y1 == top || y1 == bottom) && (x1 == left || x1 == right))
                {
                    damage += 25;
                }
                if ((y2 == top || y2 == bottom) && (x2 == left || x2 == right))
                {
                    damage += 25;
                }
                if ((y3 == top || y3 == bottom) && (x3 == left || x3 == right))
                {
                    damage += 25;
                }
                if (y1 > bottom && y1 < top && (x1 == left || x1 == right))
                {
                    damage += 50;
                }
                if (y2 > bottom && y2 < top && (x2 == left || x2 == right))
                {
                    damage += 50;
                }
                if (y3 > bottom && y3 < top && (x3 == left || x3 == right))
                {
                    damage += 50;
                }

            }
            if (y1 == top || y1 == bottom || y2 == top || y2 == bottom || y3 == top || y3 == bottom)
                {
                    if ((x1 > left && x1 < right) && (y1 == top || y1 == bottom))
                    {
                        damage += 50;
                    }
                    if ((x2 > left && x2 < right) && (y2 == top || y2 == bottom))
                    {
                        damage += 50;
                    }
                    if ((x3 > left && x3 < right) && (y3 == top || y3 == bottom))
                    {
                        damage += 50;
                    }
                }
            if ((y1 > bottom && y1 < top) || (y2 > bottom && y2 < top) || (y3 > bottom && y3 < top))
            {
                if ((x1 > left && x1 < right) && (y1 > bottom && y1 < top))
                {
                    damage += 100;
                }
                if ((x2 > left && x2 < right) && (y2 > bottom && y2 < top))
                {
                    damage += 100;
                }
                if ((x3 > left && x3 < right) && (y3 > bottom && y3 < top))
                {
                    damage += 100;
                }
            }
            
            Console.WriteLine(damage+"%");
        }
    }
}
