using System;

namespace examProblem5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());
            int num4 = int.Parse(Console.ReadLine());
            int num5 = int.Parse(Console.ReadLine()); 
            int num6 = int.Parse(Console.ReadLine());
            int num7 = int.Parse(Console.ReadLine());
            int num8 = int.Parse(Console.ReadLine());

            int[] nums = { num1, num2, num3, num4, num5, num6, num7, num8 };
            int[] arr = { 0, 0, 0, 0, 0, 0, 0, 0 };

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                   if((nums[i]&(1<<j))!=0)
                   {
                       arr[7 - j]++;
                   }
                }
            }
            int sum1 = 0;
            int sum2 = 0;
            int k;
            for (k = 1; k <= 6; k++)
            {
                for (int j = 0; j < k; j++)
                {
                    sum1 += arr[j];
                }
                for (int j = (k+1); j < 8; j++)
                {
                    sum2 += arr[j];
                }
                if (sum1 == sum2)
                {
                    break;
                }

            }
            if (sum1 == sum2)
            {
                Console.WriteLine(k);
                Console.WriteLine(sum1);
            }
            else
            {
                Console.WriteLine("No");
            }
            
        }
    }
}