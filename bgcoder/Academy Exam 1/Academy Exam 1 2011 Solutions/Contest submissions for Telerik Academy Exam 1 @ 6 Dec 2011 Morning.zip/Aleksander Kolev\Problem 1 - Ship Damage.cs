using System;

class ShipDamage
{
    static void Main(string[] args)
    {
        int sx1, sx2, sy1, sy2, h, cx, cy, dmg = 0;
        string line = Console.ReadLine();
        sx1 = int.Parse(line);
        line = Console.ReadLine();
        sy1 = int.Parse(line);
        line = Console.ReadLine();
        sx2 = int.Parse(line);
        line = Console.ReadLine();
        sy2 = int.Parse(line);
        if (sx1 > sx2)
        {
            h = sx1;
            sx1 = sx2;
            sx2 = h;
        }
        if (sy1 > sy2)
        {
            h = sy1;
            sy1 = sy2;
            sy2 = h;
        }
        line = Console.ReadLine();
        h = int.Parse(line);

        for (int i = 0; i < 3; i++)
        {
            line = Console.ReadLine();
            cx = int.Parse(line);
            line = Console.ReadLine();
            cy = int.Parse(line);
            cy = h + (h - cy);
            if ((cx >= sx1 && cx <= sx2) && (cy <= sy2 && cy >= sy1))
            {

                if (cx == sx1 || cx == sx2 || cy == sy1 || cy == sy2)
                {
                    if ((cx == sx1 && (cy == sy1 || cy == sy2)) || (cx == sx2 && (cy == sy1 || cy == sy2)))
                    {
                        dmg += 25;
                    }
                    else
                    {
                        dmg += 50;
                    }
                }
                else
                {
                    dmg += 100;
                }
            }
        }
        Console.WriteLine("{0}%", dmg);
    }
}