using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            BigInteger first = BigInteger.Parse(Console.ReadLine());
            BigInteger second = BigInteger.Parse(Console.ReadLine());
            BigInteger third = BigInteger.Parse(Console.ReadLine());
            ushort N = ushort.Parse(Console.ReadLine());

            for (ushort i = 0; i < N-3; i++)
            {
                BigInteger sum = (third + second + first);
                first = second;
                second = third;
                third = sum;
            }
            Console.WriteLine(third);
        }
    }
}