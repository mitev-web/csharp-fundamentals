using System;

namespace LoveBits
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int k = 0; k < n; k++)
            {
                int num = int.Parse(Console.ReadLine());
                //Console.WriteLine(Convert.ToString(num, 2).PadLeft(4, '0'));
                int counter = 0;
                int convertedNum = num;
                int reversedNum = num;
                int num2 = num;
                

                while (num != 0)
                {
                    num = num / 2;
                    counter++;
                }

                for (int p = 0; p < counter; p++)
                {
                    int mask = 1 << p;
                    int numAndMask = convertedNum & mask;
                    int bit = numAndMask >> p;
                    if (bit == 1)
                    {
                        mask = ~(1 << p);
                        convertedNum = convertedNum & mask;
                    }
                    else if (bit == 0)
                    {
                        convertedNum = convertedNum | mask;

                    }
                }
                //Console.WriteLine(convertedNum);
                //Console.WriteLine(Convert.ToString(convertedNum, 2).PadLeft(4, '0'));

                for (int p = 0; p < counter; p++)
                {
                    int mask1 = (1 << p);
                    int mask2 = 1 << (p + 1);
                    int numAndMask1 = reversedNum & mask1;
                    int numAndMask2 = reversedNum & mask2;
                    int bit1 = numAndMask1 >> p;
                    int bit2 = numAndMask2 >> (p+1);
                    
                        if (bit1 == 1 && bit2 == 0)
                        {
                            mask1 = ~(1 << p);
                            reversedNum = reversedNum & mask1;
                            reversedNum = reversedNum | mask2;
                        }
                        else if(bit1 == 0 && bit2 == 1)
                        {
                            mask2 = ~(1 << (p+1));
                            reversedNum = reversedNum & mask2;
                            reversedNum = reversedNum | mask1;
                        }
                    
                }
               
                Console.WriteLine(Convert.ToString(reversedNum, 2).PadLeft(4,'0'));
                //Console.WriteLine(Convert.ToString(newNum, 2).PadLeft(32, '0'));
                //Console.WriteLine(newNum);

                int result = (num2 ^ convertedNum) & reversedNum;
                Console.WriteLine(result);
            }
        }
    }
}
