using System;
using System.Numerics;

namespace Problem2_Tribonacci
{
    class Tribonacci
    { 
        static BigInteger T1;
        static BigInteger T2;
        static BigInteger T3;
        static BigInteger[] tribonacciNumbers;
        static int N;
        static string consoleInputLine;

        public static void PrintTribonacciN()
        {
            tribonacciNumbers = new BigInteger[3];
            tribonacciNumbers[0] = T1;
            tribonacciNumbers[1] = T2;
            tribonacciNumbers[2] = T3;
            if (N > 3)
            {
                tribonacciNumbers = new BigInteger[N];
                tribonacciNumbers[0] = T1;
                tribonacciNumbers[1] = T2;
                tribonacciNumbers[2] = T3;
                for (int index = 3; index < N; index++)
                {
                    tribonacciNumbers[index] = tribonacciNumbers[index - 1] + tribonacciNumbers[index - 2] + tribonacciNumbers[index - 3];
                }
            }
            Console.WriteLine(tribonacciNumbers[N - 1]);
        }

        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo("en-US");
            consoleInputLine = Console.ReadLine();
            T1 = BigInteger.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            T2 = BigInteger.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            T3 = BigInteger.Parse(consoleInputLine);
            consoleInputLine = Console.ReadLine();
            N = int.Parse(consoleInputLine);
            PrintTribonacciN();
        }
    }
}
