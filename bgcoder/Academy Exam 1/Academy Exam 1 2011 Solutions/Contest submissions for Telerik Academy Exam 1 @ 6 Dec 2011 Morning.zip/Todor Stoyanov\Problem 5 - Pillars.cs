using System;

namespace Problem5_Pillars
{
    class Pillars
    {
        static int[] numbers = new int[8];
        static int[,] grid = new int[8, 8];
        static int fullCellsCounterRight;
        static int fullCellsCounterLeft;
        static bool isSuchPillarExist = false;

        static void GetNumbers()
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = int.Parse(Console.ReadLine());
            }
        }

        static void DrawGrid()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = grid.GetLength(1) - 1; j >= 0; j--)
                {
                    if ((numbers[i] & 1) == 1)
                    {
                        grid[i, j] = 1;
                    }
                    numbers[i] = numbers[i] >> 1;
                }
            }
        }

        static void PrintGrid()
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    Console.Write(grid[i, j]);
                }
                Console.WriteLine();
            }
        }

        static void CheckBothPillarSides()
        {
            for (int pillarPosition = 0; pillarPosition < grid.GetLength(1); pillarPosition++)
            {
                fullCellsCounterRight = 0;
                fullCellsCounterLeft = 0;
                CheckLeftSide(pillarPosition);
                CheckRightSide(pillarPosition);
                if (fullCellsCounterRight == fullCellsCounterLeft)
                {
                    PrintResult(pillarPosition);
                    isSuchPillarExist = true;
                    break;
                }
            }
        }

        static void CheckLeftSide(int pillarPosition)
        {
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < pillarPosition; j++)
                {
                    if (grid[i, j] == 1)
                    {
                        fullCellsCounterLeft++;
                    }
                }
            }
        }

        static void CheckRightSide(int pillarPosition)
        {
            for (int  i = 0;  i < grid.GetLength(0);  i++)
            {
                for (int j = pillarPosition + 1; j < grid.GetLength(1); j++)
                {
                    if (grid[i, j] == 1)
                    {
                        fullCellsCounterRight++;
                    }
                }
            }
        }

        static void PrintResult(int pillarPosition)
        {
            Console.WriteLine(7 - pillarPosition);
            Console.WriteLine(fullCellsCounterLeft);
        }

        static void Main(string[] args)
        {
            GetNumbers();
            DrawGrid();
            //PrintGrid();
            //Console.WriteLine();
            CheckBothPillarSides();
            Console.Write(isSuchPillarExist ? "" : "No\n");
        }
    }
}
