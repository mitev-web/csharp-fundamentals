using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;


class Tribonacci
{
    static void Main(string[] args)
    {
        BigInteger t1 = BigInteger.Parse(Console.ReadLine());
        BigInteger t2 = BigInteger.Parse(Console.ReadLine());
        BigInteger t3 = BigInteger.Parse(Console.ReadLine());

        //double t1 = Double.Parse(Console.ReadLine());
        //double t2 = Double.Parse(Console.ReadLine());
        //double t3 = Double.Parse(Console.ReadLine());

        int N = Int32.Parse(Console.ReadLine());

        if (N==1)
        {
            Console.WriteLine(t1);
            return;
        }
        if (N==2)
        {
            Console.WriteLine(t2);
            return;
        }
        if (N==3)
        {
            Console.WriteLine(t3);
            return;
        }

        BigInteger temp = 0;
        for (int i = 3; i < N; i++)
    	{
            temp = t1+t2+t3;
            t1=t2;
            t2=t3;
            t3=temp;		 
		}
        Console.WriteLine(temp);

    }
}
