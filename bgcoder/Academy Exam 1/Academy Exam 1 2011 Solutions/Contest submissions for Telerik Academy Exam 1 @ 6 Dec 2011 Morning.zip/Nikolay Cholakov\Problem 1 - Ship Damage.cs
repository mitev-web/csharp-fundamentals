using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _1.ShipDamage
{
    class ShipDamage
    {
        static void Main(string[] args)
        {
            const int sX1Axis = -6;
            const int sX2Axis = -11;
            const int sY1Axis = 3;
            const int sY2Axis = 6;
            const int horrizonY = 1;
            int c1XAxis = 0;
            int c1YAxis = 0;
            int c2XAxis = 0;
            int c2YAxis = 0;
            int c3XAxis = 0;
            int c3YAxis = 0;

            c1XAxis = int.Parse(Console.ReadLine());
            c1YAxis = int.Parse(Console.ReadLine());

            
            if (c1XAxis == sX1Axis || c1XAxis == sX2Axis && Math.Abs(c1YAxis - 1) == (sX1Axis - horrizonY) || Math.Abs(c1YAxis - 1) == (sX2Axis - horrizonY))
            {
            }
            else
                if (c1XAxis == sX1Axis || c1XAxis == sX2Axis && Math.Abs(c1YAxis - 1) > (sX1Axis - horrizonY) || Math.Abs(c1YAxis - 1) < (sX2Axis - horrizonY))
                {
                }
                else
                    if (c1XAxis == sX1Axis || c1XAxis == sX2Axis && Math.Abs(c1YAxis - 1) > (sX1Axis - horrizonY) || Math.Abs(c1YAxis - 1) < (sX2Axis - horrizonY))
                    {
                    }
            c2XAxis = int.Parse(Console.ReadLine());
            c2YAxis = int.Parse(Console.ReadLine());

            if (c2XAxis == sX1Axis || c2XAxis == sX2Axis && Math.Abs(c2YAxis - 1) == (sX1Axis - horrizonY) || Math.Abs(c2YAxis - 1) == (sX2Axis - horrizonY))
            {
            }
            else
                if (c2XAxis == sX1Axis || c2XAxis == sX2Axis && Math.Abs(c2YAxis - 1) > (sX1Axis - horrizonY) || Math.Abs(c2YAxis - 1) < (sX2Axis - horrizonY))
                {
                }
                else
                    if (c2XAxis == sX1Axis || c2XAxis == sX2Axis && Math.Abs(c2YAxis - 1) > (sX1Axis - horrizonY) || Math.Abs(c2YAxis - 1) < (sX2Axis - horrizonY))
                    {
                    }
            c3XAxis = int.Parse(Console.ReadLine());
            c3YAxis = int.Parse(Console.ReadLine());

            if (c3XAxis == sX1Axis || c3XAxis == sX2Axis && Math.Abs(c3YAxis - 1) == (sX1Axis - horrizonY) || Math.Abs(c3YAxis - 1) == (sX2Axis - horrizonY))
            {
            }
            else
                if (c3XAxis == sX1Axis || c3XAxis == sX2Axis && Math.Abs(c3YAxis - 1) > (sX1Axis - horrizonY) || Math.Abs(c3YAxis - 1) < (sX2Axis - horrizonY))
                {
                }
                else
                    if (c3XAxis == sX1Axis || c3XAxis == sX2Axis && Math.Abs(c3YAxis - 1) > (sX1Axis - horrizonY) || Math.Abs(c3YAxis - 1) < (sX2Axis - horrizonY))
                    {
                    }
        }
    }
}
