using System;
using System.Threading;
using System.Globalization;

namespace ShipDamage
{
    class Program
    {
        static void Main(string[] args)
        {

            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            decimal sX1 = decimal.Parse(Console.ReadLine());
            decimal sY1 = decimal.Parse(Console.ReadLine());

            decimal sX2 = decimal.Parse(Console.ReadLine());
            decimal sY2 = decimal.Parse(Console.ReadLine());

            decimal minSX = Math.Min(sX1, sX2);
            decimal maxSX = Math.Max(sX1, sX2);

            decimal minSY = Math.Min(sY1, sY2);
            decimal maxSY = Math.Max(sY1, sY2);

            decimal h = decimal.Parse(Console.ReadLine());

            decimal cX1 = decimal.Parse(Console.ReadLine());
            decimal cY1 = decimal.Parse(Console.ReadLine());
            decimal cX2 = decimal.Parse(Console.ReadLine());
            decimal cY2 = decimal.Parse(Console.ReadLine());
            decimal cX3 = decimal.Parse(Console.ReadLine());
            decimal cY3 = decimal.Parse(Console.ReadLine());

            int damageCounterTotal = 0;
            int damageCounter1 = 0;
            int damageCounter2 = 0;
            int damageCounter3 = 0;

            decimal cY1new = 0;
            decimal cY2new = 0;
            decimal cY3new = 0;

            cY1new = h - cY1;
            cY1new = h + cY1new;
            cY2new = h - cY2;
            cY2new = h + cY2new;
            cY3new = h - cY3;
            cY3new = h + cY3new;

            if (cX1 == sX1 || cX1 == sX2)
            {
                if (cY1new == sY1 || cY1new == sY2)
                {
                    damageCounter1 =  25;
                }
            }
            else if (cX1 > minSX && cX1 < maxSX)
            {
                if (cY1new > minSY && cY1new < maxSY)
                {
                    damageCounter1 =  100;
                }
            
                if (cY1new == sY1 || cY1new == sY2)
                {
                    damageCounter1 =  50;
                }
            }
            else if (cY1new > minSY && cY1new < maxSY)
            {
                if (cX1 == sX1 || cX1 == sX2)
                {
                    damageCounter1 = 50;
                }
            }


            if (cX2 == sX1 || cX2 == sX2)
            {
                if (cY2new == sY1 || cY2new == sY2)
                {
                    damageCounter2 =  25;
                }
            }
            else if (cX2 > minSX && cX2 < maxSX)
            {
                if (cY2new > minSY && cY2new < maxSY)
                {
                    damageCounter2 =  100;
                }
            
                if (cY2new == minSY || cY2new == maxSY)
                {
                    damageCounter2 =  50;
                }
            }
            else if (cY2new > minSY && cY2new < maxSY)
            {
                if (cX2 == minSX || cX2 == maxSX)
                {
                    damageCounter2 =  50;
                }
            }


            if (cX3 == sX1 || cX3 == sX2)
            {
                if (cY3new == sY1 || cY3new == sY2)
                {
                    damageCounter3 =  25;
                }
            }
            else if (cX3 > minSX && cX3 < maxSX)
            {
                if (cY3new > minSY && cY3new < maxSY)
                {
                    damageCounter3 =  100;
                }
            }
            else if (cX3 > minSX && cX3 < maxSX)
            {
                if (cY3new == minSY || cY3new == maxSY)
                {
                    damageCounter3 =  50;
                }
            
                if (cX3 == minSX || cX3 == maxSX)
                {
                    damageCounter3 =  50;
                }
            }
            damageCounterTotal = damageCounter1 + damageCounter2 + damageCounter3;
            Console.WriteLine("{0}\u0025", damageCounterTotal);
        }
    }
}