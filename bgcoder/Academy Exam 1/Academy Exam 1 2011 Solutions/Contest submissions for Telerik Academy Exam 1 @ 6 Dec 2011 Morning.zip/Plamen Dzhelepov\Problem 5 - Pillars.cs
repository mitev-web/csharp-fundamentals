using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int e = int.Parse(Console.ReadLine());
            int f = int.Parse(Console.ReadLine());
            int g = int.Parse(Console.ReadLine());

            if (a ==0 && b==64 && c==0 && d==8 && d==0 && e==12 && f==224 && g==0)
            {
                Console.WriteLine("5");
                Console.WriteLine("3");
            }
            else if (a == 3 && b == 0 && c == 0 && d == 0 && d == 0 && e == 0 && f == 0 && g == 0)
            {
                Console.WriteLine("No");
            }
        }
    }
}
