using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int firstBit;
            uint n = uint.Parse(Console.ReadLine());
            uint[] numbers = new uint[n];

            for (uint i = 0; i < n; i++)
            {
                numbers[i] = uint.Parse(Console.ReadLine());
            }
            for (uint i = 0; i < n; i++)
            {
                while (numbers[i] != 0)
                {
                    firstBit = (int)numbers[i] & 1;

                    if (firstBit == 1)
                    {
                        firstBit = (int)numbers[i] & 1;
                    }
                    else
                    {
                        firstBit = (int)numbers[i] | 1;
                    }

                    numbers[i] = numbers[i] >> 1;
                }
            }
            
        }
    }
}