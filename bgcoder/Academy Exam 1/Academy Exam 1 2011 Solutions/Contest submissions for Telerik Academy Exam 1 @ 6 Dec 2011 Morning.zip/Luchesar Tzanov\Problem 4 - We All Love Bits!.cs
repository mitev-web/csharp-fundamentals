using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MakeLoveTOBits
{
    class Program
    {
        static void Main()
        {
            
            uint res = 0;
            int j;
            uint nullifyMask;
            uint temp1,temp2;
            int counter = 31;
            uint mask = 0x80000000;
            uint n = Convert.ToUInt32(Console.ReadLine());
            uint[] array = new uint[n];

            for (int i = 0; i < n; i++)
                array[i] = Convert.ToUInt32(Console.ReadLine());

            foreach (uint x in array)
            {
                res = x;
                while ((x & mask) == 0)
                {
                    counter--;
                    mask >>= 1;
                }
                for (int i = 0; i < counter; i++)
                {
                    j = counter - i;
                    if (i >= j)
                        break;
                    nullifyMask = (uint)(res & (0xFFFFFFFF ^ (1 << i) ^ (1 << j)));
                    temp1 = (uint)(res & (1 << j));
                    temp2 = (uint)(res & (1 << i));
                    res &= nullifyMask;
                    res = res | (temp1 >> (j - i));
                    res = res | (temp2 << (j - i));

                }
                Console.WriteLine((x ^ (~x)) & res);
                counter = 31;
                mask = 0x80000000;
            }
            
        }
    }
}
