using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tribonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            long first = long.Parse(Console.ReadLine());
            long second = long.Parse(Console.ReadLine());
            long third = long.Parse(Console.ReadLine());
            long n = long.Parse(Console.ReadLine());
            long[] answer = new long[15000];
            decimal realAnswer = 0;
            if (n == 1)
            {
                Console.WriteLine(first);
                Console.WriteLine();
            }
            else if (n == 2)
            {
                Console.WriteLine(second);
                Console.WriteLine();
            }
            else if (n == 3)
            {
                Console.WriteLine(third);
                Console.WriteLine();
            }
            else
            {
                for (int i = 0; i < (n-3); i++)
                {
                    answer[i] = first + second + third;
                    first = second;
                    second = third;
                    third = answer[i];
                    realAnswer = answer[i];
                }
            }
            Console.WriteLine(realAnswer);
        }
    }
}
