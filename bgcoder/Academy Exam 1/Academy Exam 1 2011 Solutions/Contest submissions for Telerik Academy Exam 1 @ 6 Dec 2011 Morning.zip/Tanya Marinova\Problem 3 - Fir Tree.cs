using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace zad3_Fir_Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(Console.ReadLine());
            int k = n - 1;
            int t = n - 2;
            int s = n;
            int f = n;
            for (int i = 1; i <= n +( n-3); i++)
            {
                for (int j = 1; j <= (n ) + (n - 3); j++)
                {
                    if (j <= n - 1)
                    {
                        if ((i % 2 != 0))
                        {
                            if (j >= k)
                            { Console.Write("*"); }
                            else { Console.Write(" "); }
                        }


                        if ((i % 2 == 0))
                        {
                            if (j <= t)
                            { Console.Write("."); }
                            else { Console.Write(" "); }
                        }

                    }
                    else
                    {
                        if ((i % 2 == 0))
                        {
                            if (j >= s)
                            { Console.Write("."); }
                            else { Console.Write(" "); }

                        }
                        else if ((i % 2 != 0) && (i > 1))
                        {
                            if (j <= f)
                            { Console.Write("*"); }
                            else { Console.Write(" "); }

                        }

                    }

                }

                Console.Write("\n");
                if (i % 2 == 0)
                {
                    t--;
                    s++;

                }
                else
                {
                    k--;
                    if (i > 1)
                        f++;

                }


            }
            for (int i = 0; i < 2; i++)
            {
                for (int j = 1; j <= ((n - 1) + (n - 2)); j++)
                {
                    if (i == 0)
                    {
                        if (j == n - 1) { Console.Write("*"); }
                        else { Console.Write(" "); }
                    }
                    else
                    {
                        if (j == n - 1) { Console.Write(" "); }
                        else { Console.Write("."); }
                    }





                }
                Console.WriteLine();

            }
        }
    }
}
